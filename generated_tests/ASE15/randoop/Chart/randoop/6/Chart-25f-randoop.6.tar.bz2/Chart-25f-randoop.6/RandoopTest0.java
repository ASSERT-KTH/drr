
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var4 = null;
    java.awt.Paint var5 = null;
    java.awt.Stroke var6 = null;
    java.awt.Paint var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var8 = new org.jfree.chart.LegendItem(var0, "hi!", "", "hi!", var4, var5, var6, var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }


    java.awt.Shape var4 = null;
    java.awt.Paint var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var6 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", var4, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }


    java.awt.Shape var0 = null;
    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.clone(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }


    java.awt.Shape var0 = null;
    org.jfree.chart.util.RectangleAnchor var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var0, var1, 100.0d, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }


    java.awt.Paint var0 = null;
    java.awt.Stroke var1 = null;
    org.jfree.chart.util.RectangleInsets var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.LineBorder var3 = new org.jfree.chart.block.LineBorder(var0, var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test6() {}
//   public void test6() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }
// 
// 
//     java.lang.Comparable[] var1 = new java.lang.Comparable[] { (-1)};
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { "hi!"};
//     double[] var4 = null;
//     double[][] var5 = new double[][] { var4};
//     org.jfree.data.category.CategoryDataset var6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(var1, var3, var5);
// 
//   }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }


    java.awt.Paint var1 = null;
    java.awt.Stroke var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.ValueMarker var3 = new org.jfree.chart.plot.ValueMarker((-1.0d), var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }


    org.jfree.chart.block.Arrangement var0 = null;
    org.jfree.data.general.Dataset var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.LegendItemBlockContainer var3 = new org.jfree.chart.title.LegendItemBlockContainer(var0, var1, (java.lang.Comparable)(short)10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTickUnit var3 = new org.jfree.chart.axis.NumberTickUnit(10.0d, var1, 100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test11() {}
//   public void test11() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("", var1, var2);
// 
//   }

  public void test12() {}
//   public void test12() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     java.lang.Comparable var1 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, var1);
// 
//   }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }


    java.awt.Color var1 = null;
    java.awt.Color var2 = java.awt.Color.getColor("hi!", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test17() {}
//   public void test17() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }
// 
// 
//     org.jfree.chart.plot.Plot var1 = null;
//     org.jfree.chart.JFreeChart var2 = new org.jfree.chart.JFreeChart("hi!", var1);
// 
//   }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextAnchor var4 = null;
    org.jfree.chart.text.TextAnchor var6 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, 10.0f, 10.0f, var4, 100.0d, var6);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }


    java.lang.Object var0 = null;
    org.jfree.chart.JFreeChart var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.ChartProgressEvent var4 = new org.jfree.chart.event.ChartProgressEvent(var0, var1, 0, 1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }


    int var3 = java.awt.Color.HSBtoRGB(0.0f, 10.0f, 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-123));

  }

  public void test22() {}
//   public void test22() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var1 = null;
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var1, 100.0d, 1.0f, 10.0f);
// 
//   }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }


    java.awt.Shape var5 = null;
    java.awt.Paint var7 = null;
    java.awt.Paint var9 = null;
    java.awt.Stroke var10 = null;
    java.awt.Shape var12 = null;
    java.awt.Stroke var13 = null;
    java.awt.Paint var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var15 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "hi!", true, var5, true, var7, true, var9, var10, true, var12, var13, var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }


    org.jfree.data.general.PieDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }


    java.awt.geom.Ellipse2D var0 = null;
    java.awt.geom.Ellipse2D var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    java.awt.Graphics2D var1 = null;
    org.jfree.chart.block.RectangleConstraint var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var3 = var0.arrange(var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }


    java.awt.Paint var1 = null;
    java.awt.Stroke var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.ValueMarker var3 = new org.jfree.chart.plot.ValueMarker(100.0d, var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test29() {}
//   public void test29() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle.Control var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("", var1, var2);
// 
//   }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Paint var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.LegendGraphic var3 = new org.jfree.chart.title.LegendGraphic(var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }


    org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();
    java.util.List var1 = var0.getLines();
    java.awt.Font var3 = null;
    java.awt.Paint var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addLine("hi!", var3, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }


    org.jfree.data.Range var1 = null;
    org.jfree.data.Range var3 = org.jfree.data.Range.expandToInclude(var1, (-1.0d));
    org.jfree.data.Range var4 = null;
    org.jfree.data.Range var6 = org.jfree.data.Range.expandToInclude(var4, (-1.0d));
    org.jfree.data.Range var7 = org.jfree.data.Range.combine(var3, var6);
    double var8 = var7.getLowerBound();
    org.jfree.chart.block.LengthConstraintType var9 = null;
    org.jfree.data.Range var11 = null;
    org.jfree.data.Range var13 = org.jfree.data.Range.expandToInclude(var11, (-1.0d));
    org.jfree.data.Range var14 = null;
    org.jfree.data.Range var16 = org.jfree.data.Range.expandToInclude(var14, (-1.0d));
    org.jfree.data.Range var17 = org.jfree.data.Range.combine(var13, var16);
    org.jfree.chart.block.LengthConstraintType var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.RectangleConstraint var19 = new org.jfree.chart.block.RectangleConstraint((-1.0d), var7, var9, (-1.0d), var17, var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }


    java.awt.Font var1 = null;
    java.awt.Paint var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextFragment var4 = new org.jfree.chart.text.TextFragment("hi!", var1, var2, 0.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    java.util.List var1 = var0.getColumnKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeColumn(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var2 = var0.getColumnKey(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    java.util.List var1 = var0.getColumnKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var3 = var0.getColumnKey(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.text.TextAnchor var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var2 = new org.jfree.chart.labels.ItemLabelPosition(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, (java.lang.Comparable)0.0f, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeRow((java.lang.Comparable)(byte)(-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.util.RectangleInsets var2 = var1.getItemLabelPadding();
    org.jfree.chart.util.RectangleAnchor var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLegendItemGraphicAnchor(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, (java.lang.Comparable)10, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }


    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Paint var8 = null;
    java.awt.Paint var10 = null;
    java.awt.Stroke var11 = null;
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Stroke var15 = null;
    java.awt.Paint var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var17 = new org.jfree.chart.LegendItem("", "hi!", "", "", true, var6, false, var8, false, var10, var11, false, var14, var15, var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }


    java.awt.geom.Line2D var0 = null;
    java.awt.geom.Line2D var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }


    org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.set(1, (java.lang.Object)10.0d);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.util.RectangleInsets var1 = var0.getPadding();
    java.awt.geom.Rectangle2D var2 = null;
    org.jfree.chart.util.LengthAdjustmentType var3 = null;
    org.jfree.chart.util.LengthAdjustmentType var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var5 = var1.createAdjustedRectangle(var2, var3, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }


    java.awt.Polygon var0 = null;
    java.awt.Polygon var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }


    org.jfree.chart.axis.AxisLocation var0 = null;
    org.jfree.chart.plot.PlotOrientation var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test51() {}
//   public void test51() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }
// 
// 
//     java.awt.geom.Rectangle2D var0 = null;
//     java.awt.geom.Rectangle2D var1 = null;
//     boolean var2 = org.jfree.chart.util.ShapeUtilities.intersects(var0, var1);
// 
//   }

  public void test52() {}
//   public void test52() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(var0, false);
// 
//   }

  public void test53() {}
//   public void test53() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.axis.CategoryLabelPosition var4 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.text.TextAnchor var5 = var4.getRotationAnchor();
//     org.jfree.chart.axis.CategoryLabelPosition var7 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.text.TextAnchor var8 = var7.getRotationAnchor();
//     java.awt.Shape var9 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("Range[-1.0,-1.0]", var1, 10.0f, 100.0f, var5, 100.0d, var8);
// 
//   }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = null;
    var0.setSeriesItemLabelsVisible(0, var2, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var6 = null;
    var0.setSeriesToolTipGenerator(1, var6, false);
    org.jfree.chart.labels.ItemLabelPosition var10 = new org.jfree.chart.labels.ItemLabelPosition();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesPositiveItemLabelPosition((-1), var10, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test55() {}
//   public void test55() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var1 = null;
//     var0.setBaseURLGenerator(var1);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var6 = null;
//     var4.setSeriesItemLabelsVisible(0, var6, false);
//     java.awt.Stroke var9 = var4.getErrorIndicatorStroke();
//     var0.setSeriesOutlineStroke(100, var9, false);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var4 and var0.", var4.equals(var0) == var0.equals(var4));
// 
//   }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    java.lang.Object var1 = var0.clone();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var3 = var0.getRowKey((-123));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }


    java.awt.Font var1 = null;
    java.awt.Paint var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextFragment var4 = new org.jfree.chart.text.TextFragment("", var1, var2, 0.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test58() {}
//   public void test58() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }
// 
// 
//     java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
//     org.jfree.chart.entity.ChartEntity var3 = new org.jfree.chart.entity.ChartEntity(var1, "Range[-1.0,-1.0]");
//     org.jfree.chart.imagemap.ToolTipTagFragmentGenerator var4 = null;
//     org.jfree.chart.imagemap.URLTagFragmentGenerator var5 = null;
//     java.lang.String var6 = var3.getImageMapAreaTag(var4, var5);
// 
//   }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    java.util.List var1 = var0.getColumnKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeColumn((-123));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }


    java.awt.Paint var0 = null;
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var8 = new org.jfree.chart.entity.ChartEntity(var6, "Range[-1.0,-1.0]");
    org.jfree.chart.renderer.category.StatisticalBarRenderer var9 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var11 = null;
    var9.setSeriesItemLabelsVisible(0, var11, false);
    java.awt.Stroke var14 = var9.getErrorIndicatorStroke();
    java.awt.Paint var15 = null;
    org.jfree.chart.LegendItem var16 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var6, var14, var15);
    org.jfree.chart.block.BlockContainer var17 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.util.RectangleInsets var18 = var17.getPadding();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.LineBorder var19 = new org.jfree.chart.block.LineBorder(var0, var14, var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var1 = null;
    var0.setBaseURLGenerator(var1);
    org.jfree.chart.annotations.CategoryAnnotation var3 = null;
    org.jfree.chart.util.Layer var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var3, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }


    org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(true);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeRow(10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }


    org.jfree.data.Range var0 = null;
    org.jfree.data.Range var2 = org.jfree.data.Range.expandToInclude(var0, (-1.0d));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var5 = org.jfree.data.Range.expand(var0, 2.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }


    java.awt.Font var1 = null;
    java.awt.Paint var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.LabelBlock var3 = new org.jfree.chart.block.LabelBlock("hi!", var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }


    org.jfree.chart.util.RectangleAnchor var0 = null;
    org.jfree.chart.text.TextBlockAnchor var1 = null;
    org.jfree.chart.axis.CategoryLabelPosition var2 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.text.TextAnchor var3 = var2.getRotationAnchor();
    org.jfree.chart.axis.CategoryLabelWidthType var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var7 = new org.jfree.chart.axis.CategoryLabelPosition(var0, var1, var3, (-1.0d), var5, (-1.0f));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = null;
    var0.setSeriesItemLabelsVisible(0, var2, false);
    java.awt.Stroke var5 = var0.getErrorIndicatorStroke();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var7 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var9 = null;
    var7.setSeriesItemLabelsVisible(0, var9, false);
    java.awt.Stroke var12 = var7.getErrorIndicatorStroke();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesStroke((-123), var12, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }


    org.jfree.chart.axis.AxisLocation var0 = null;
    org.jfree.chart.plot.PlotOrientation var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test71() {}
//   public void test71() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }
// 
// 
//     java.awt.geom.Line2D var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(var0, 100.0f);
// 
//   }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }


    java.awt.Shape var0 = null;
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.rotateShape(var0, 1.0d, 10.0f, 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var1 = null;
    var0.setBaseURLGenerator(var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelsVisible((-1), (java.lang.Boolean)true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test74() {}
//   public void test74() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var2 = null;
//     var0.setSeriesItemLabelsVisible(0, var2, false);
//     java.awt.Paint var5 = var0.getBaseOutlinePaint();
//     org.jfree.chart.block.BlockContainer var6 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.util.RectangleInsets var7 = var6.getPadding();
//     org.jfree.chart.util.HorizontalAlignment var8 = null;
//     org.jfree.chart.util.VerticalAlignment var9 = null;
//     org.jfree.chart.block.FlowArrangement var12 = new org.jfree.chart.block.FlowArrangement(var8, var9, 0.0d, 0.0d);
//     var6.setArrangement((org.jfree.chart.block.Arrangement)var12);
//     org.jfree.chart.block.BlockContainer var14 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.util.RectangleInsets var15 = var14.getPadding();
//     org.jfree.chart.util.HorizontalAlignment var16 = null;
//     org.jfree.chart.util.VerticalAlignment var17 = null;
//     org.jfree.chart.block.FlowArrangement var20 = new org.jfree.chart.block.FlowArrangement(var16, var17, 0.0d, 0.0d);
//     var14.setArrangement((org.jfree.chart.block.Arrangement)var20);
//     org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var12, (org.jfree.chart.block.Arrangement)var20);
//     
//     // Checks the contract:  equals-hashcode on var6 and var14
//     assertTrue("Contract failed: equals-hashcode on var6 and var14", var6.equals(var14) ? var6.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var6
//     assertTrue("Contract failed: equals-hashcode on var14 and var6", var14.equals(var6) ? var14.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var20
//     assertTrue("Contract failed: equals-hashcode on var12 and var20", var12.equals(var20) ? var12.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var12
//     assertTrue("Contract failed: equals-hashcode on var20 and var12", var20.equals(var12) ? var20.hashCode() == var12.hashCode() : true);
// 
//   }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }


    float[] var4 = new float[] { 10.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var5 = java.awt.Color.RGBtoHSB(1, 10, 10, var4);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }


    org.jfree.chart.ui.BasicProjectInfo var0 = new org.jfree.chart.ui.BasicProjectInfo();

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }


    org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();
    java.util.List var1 = var0.getLines();
    java.awt.Font var3 = null;
    org.jfree.chart.plot.DefaultDrawingSupplier var4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    boolean var6 = var4.equals((java.lang.Object)(short)10);
    java.awt.Paint var7 = var4.getNextFillPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addLine("", var3, var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test78() {}
//   public void test78() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }
// 
// 
//     org.jfree.chart.LegendItemSource var0 = null;
//     org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
//     java.awt.Graphics2D var2 = null;
//     java.awt.geom.Rectangle2D var3 = null;
//     java.lang.Object var4 = null;
//     java.lang.Object var5 = var1.draw(var2, var3, var4);
// 
//   }

  public void test79() {}
//   public void test79() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }
// 
// 
//     java.awt.geom.Line2D var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(var0, 10.0f);
// 
//   }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("");
    java.awt.Font var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setFont(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }


    int var3 = java.awt.Color.HSBtoRGB(100.0f, 0.0f, 0.95f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-855310));

  }

  public void test82() {}
//   public void test82() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var2 = var0.getSeriesItemLabelsVisible(100);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var3 = null;
//     var0.setBaseItemLabelGenerator(var3);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var6 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var8 = null;
//     var6.setSeriesItemLabelsVisible(0, var8, false);
//     java.awt.Paint var11 = var6.getBaseOutlinePaint();
//     var0.setSeriesOutlinePaint(1, var11, false);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var6 and var0.", var6.equals(var0) == var0.equals(var6));
// 
//   }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.util.RectangleInsets var1 = var0.getPadding();
    org.jfree.chart.LegendItemSource var2 = null;
    org.jfree.chart.title.LegendTitle var3 = new org.jfree.chart.title.LegendTitle(var2);
    org.jfree.chart.util.RectangleInsets var4 = var3.getItemLabelPadding();
    org.jfree.chart.util.VerticalAlignment var5 = var3.getVerticalAlignment();
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var13 = new org.jfree.chart.entity.ChartEntity(var11, "Range[-1.0,-1.0]");
    org.jfree.chart.renderer.category.StatisticalBarRenderer var14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var16 = null;
    var14.setSeriesItemLabelsVisible(0, var16, false);
    java.awt.Stroke var19 = var14.getErrorIndicatorStroke();
    java.awt.Paint var20 = null;
    org.jfree.chart.LegendItem var21 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var11, var19, var20);
    java.awt.Shape var22 = var21.getShape();
    org.jfree.data.general.Dataset var23 = null;
    var21.setDataset(var23);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.add((org.jfree.chart.block.Block)var3, (java.lang.Object)var21);
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(var0, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }


    java.awt.Font var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextFragment var2 = new org.jfree.chart.text.TextFragment("Range[-1.0,-1.0]", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }


    java.awt.Color var2 = java.awt.Color.getColor("", (-1));
    float[] var6 = new float[] { (-1.0f), 0.0f, 0.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var7 = var2.getComponents(var6);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = new org.jfree.data.Range(100.0d, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test89() {}
//   public void test89() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }
// 
// 
//     org.jfree.chart.block.BlockBorder var4 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 0.0d, 0.0d);
//     java.awt.Graphics2D var5 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     var4.draw(var5, var6);
// 
//   }

  public void test90() {}
//   public void test90() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var2 = null;
//     var0.setSeriesItemLabelsVisible(0, var2, false);
//     org.jfree.chart.labels.CategoryToolTipGenerator var6 = null;
//     var0.setSeriesToolTipGenerator(1, var6, false);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var12 = null;
//     var10.setSeriesItemLabelsVisible(0, var12, false);
//     java.awt.Stroke var15 = var10.getErrorIndicatorStroke();
//     var0.setSeriesStroke(10, var15);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var10 and var0.", var10.equals(var0) == var0.equals(var10));
// 
//   }

  public void test91() {}
//   public void test91() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }
// 
// 
//     org.jfree.chart.plot.Plot var0 = null;
//     org.jfree.chart.JFreeChart var1 = new org.jfree.chart.JFreeChart(var0);
// 
//   }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.text.TextAnchor var1 = null;
    org.jfree.chart.text.TextAnchor var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var4 = new org.jfree.chart.labels.ItemLabelPosition(var0, var1, var2, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }


    java.lang.Comparable var0 = null;
    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var4 = new org.jfree.chart.entity.ChartEntity(var2, "Range[-1.0,-1.0]");
    org.jfree.chart.entity.CategoryLabelEntity var7 = new org.jfree.chart.entity.CategoryLabelEntity(var0, var2, "hi!", "");
    org.jfree.chart.util.RectangleAnchor var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var2, var8, (-1.0d), 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test94() {}
//   public void test94() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, (java.lang.Comparable)'a');
// 
//   }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }


    java.awt.Font var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextLine var2 = new org.jfree.chart.text.TextLine("", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = var0.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var5 = var0.getPositiveItemLabelPosition(100, 0);
    org.jfree.chart.labels.ItemLabelPosition var7 = new org.jfree.chart.labels.ItemLabelPosition();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesNegativeItemLabelPosition((-1), var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var2 = var0.getColumnKey((-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test98() {}
//   public void test98() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Graphics2D var1 = null;
//     java.awt.geom.Rectangle2D var3 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.LegendItemSource var5 = null;
//     org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle(var5);
//     org.jfree.chart.util.RectangleEdge var7 = var6.getLegendItemGraphicEdge();
//     org.jfree.chart.util.RectangleEdge var8 = org.jfree.chart.util.RectangleEdge.opposite(var7);
//     boolean var9 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var8);
//     org.jfree.chart.plot.PlotRenderingInfo var10 = null;
//     org.jfree.chart.axis.AxisState var11 = var0.draw(var1, 1.0d, var3, var4, var8, var10);
// 
//   }

  public void test99() {}
//   public void test99() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }
// 
// 
//     java.lang.ClassLoader var0 = null;
//     java.util.ResourceBundle.clearCache(var0);
// 
//   }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }


    org.jfree.chart.plot.Plot var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.PlotChangeEvent var1 = new org.jfree.chart.event.PlotChangeEvent(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test101() {}
//   public void test101() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.axis.CategoryLabelPosition var4 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.text.TextAnchor var5 = var4.getRotationAnchor();
//     java.awt.geom.Rectangle2D var6 = org.jfree.chart.text.TextUtilities.drawAlignedString("", var1, 1.0f, 0.0f, var5);
// 
//   }

  public void test102() {}
//   public void test102() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var1 = var0.getPositiveItemLabelPositionFallback();
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.plot.CategoryPlot var3 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     var0.drawBackground(var2, var3, var4);
// 
//   }

  public void test103() {}
//   public void test103() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.chart.LegendItemSource var2 = null;
//     org.jfree.chart.title.LegendTitle var3 = new org.jfree.chart.title.LegendTitle(var2);
//     org.jfree.chart.util.RectangleEdge var4 = var3.getLegendItemGraphicEdge();
//     java.awt.Paint var5 = var3.getItemPaint();
//     java.awt.Graphics2D var8 = null;
//     org.jfree.chart.text.G2TextMeasurer var9 = new org.jfree.chart.text.G2TextMeasurer(var8);
//     org.jfree.chart.text.TextBlock var10 = org.jfree.chart.text.TextUtilities.createTextBlock("Range[-1.0,-1.0]", var1, var5, (-1.0f), (-123), (org.jfree.chart.text.TextMeasurer)var9);
// 
//   }

  public void test104() {}
//   public void test104() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var3 = null;
//     var2.setPlot(var3);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
//     java.awt.Graphics2D var7 = null;
//     java.awt.geom.Rectangle2D var9 = null;
//     java.awt.geom.Rectangle2D var10 = null;
//     org.jfree.chart.LegendItemSource var11 = null;
//     org.jfree.chart.title.LegendTitle var12 = new org.jfree.chart.title.LegendTitle(var11);
//     org.jfree.chart.util.RectangleEdge var13 = var12.getLegendItemGraphicEdge();
//     org.jfree.chart.util.RectangleEdge var14 = org.jfree.chart.util.RectangleEdge.opposite(var13);
//     org.jfree.chart.plot.PlotRenderingInfo var15 = null;
//     org.jfree.chart.axis.AxisState var16 = var2.draw(var7, 1.0d, var9, var10, var14, var15);
// 
//   }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = var0.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var5 = var0.getPositiveItemLabelPosition(100, 0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var6 = var0.getLegendItemToolTipGenerator();
    boolean var7 = var0.getAutoPopulateSeriesFillPaint();
    java.awt.Graphics2D var8 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var9 = null;
    java.awt.geom.Rectangle2D var10 = null;
    org.jfree.data.category.CategoryDataset var11 = null;
    org.jfree.chart.axis.CategoryAxis var12 = null;
    org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var14 = null;
    var13.setPlot(var14);
    org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var11, var12, (org.jfree.chart.axis.ValueAxis)var13, var16);
    var17.setAnchorValue(0.0d, true);
    org.jfree.chart.axis.CategoryAxis var21 = null;
    org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis();
    boolean var23 = var22.isNegativeArrowVisible();
    org.jfree.data.category.CategoryDataset var24 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.drawItem(var8, var9, var10, var17, var21, (org.jfree.chart.axis.ValueAxis)var22, var24, 100, (-123), (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.NumberTickUnit var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setTickUnit(var1, false, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test107() {}
//   public void test107() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.FontMetrics var2 = null;
//     java.awt.geom.Rectangle2D var3 = org.jfree.chart.text.TextUtilities.getTextBounds("Range[-1.0,-1.0]", var1, var2);
// 
//   }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    var6.setAnchorValue(0.0d, true);
    org.jfree.chart.axis.CategoryAxis var10 = var6.getDomainAxis();
    org.jfree.chart.plot.CategoryMarker var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.addDomainMarker(var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test109() {}
//   public void test109() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var1 = var0.getPositiveItemLabelPositionFallback();
//     java.awt.Paint var4 = var0.getItemLabelPaint((-123), (-1));
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var6 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var8 = var6.getSeriesItemLabelsVisible(100);
//     org.jfree.chart.labels.ItemLabelPosition var11 = var6.getPositiveItemLabelPosition(100, 0);
//     var0.setSeriesPositiveItemLabelPosition(100, var11, true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var6 and var0.", var6.equals(var0) == var0.equals(var6));
// 
//   }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    var6.setAnchorValue(0.0d, true);
    org.jfree.chart.axis.CategoryAxis var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setDomainAxis((-1), var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }


    boolean var0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == true);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }


    org.jfree.data.function.Function2D var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataset var5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(var0, 1.0d, 0.05d, 1, (java.lang.Comparable)(byte)0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var1 = null;
    var0.setPlot(var1);
    org.jfree.data.RangeType var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeType(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test116() {}
//   public void test116() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var3 = null;
//     var2.setPlot(var3);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
//     var6.setAnchorValue(0.0d, true);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var12 = null;
//     var10.setSeriesItemLabelsVisible(0, var12, false);
//     org.jfree.chart.labels.CategoryToolTipGenerator var16 = null;
//     var10.setSeriesToolTipGenerator(1, var16, false);
//     org.jfree.chart.urls.CategoryURLGenerator var19 = null;
//     var10.setBaseURLGenerator(var19);
//     java.awt.Graphics2D var21 = null;
//     org.jfree.chart.plot.CategoryPlot var22 = null;
//     org.jfree.chart.axis.ValueAxis var23 = null;
//     org.jfree.chart.plot.Marker var24 = null;
//     java.awt.geom.Rectangle2D var25 = null;
//     var10.drawRangeMarker(var21, var22, var23, var24, var25);
//     boolean var28 = var10.isSeriesVisibleInLegend(0);
//     var6.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
//     org.jfree.chart.plot.Marker var31 = null;
//     org.jfree.chart.util.Layer var32 = null;
//     var6.addRangeMarker(0, var31, var32);
// 
//   }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeRow(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var8 = null;
    var7.setPlot(var8);
    org.jfree.chart.axis.ValueAxis[] var10 = new org.jfree.chart.axis.ValueAxis[] { var7};
    var6.setRangeAxes(var10);
    org.jfree.data.category.CategoryDataset var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setDataset((-1), var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }


    java.lang.Object var0 = null;
    java.lang.Object var1 = null;
    boolean var2 = org.jfree.chart.util.ObjectUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = null;
    var0.setSeriesItemLabelsVisible(0, var2, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var6 = null;
    var0.setSeriesToolTipGenerator(1, var6, false);
    org.jfree.chart.urls.CategoryURLGenerator var9 = null;
    var0.setBaseURLGenerator(var9);
    java.awt.Graphics2D var11 = null;
    org.jfree.chart.plot.CategoryPlot var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.plot.Marker var14 = null;
    java.awt.geom.Rectangle2D var15 = null;
    var0.drawRangeMarker(var11, var12, var13, var14, var15);
    boolean var18 = var0.isSeriesVisibleInLegend(0);
    var0.setBaseItemLabelsVisible(false, true);
    java.awt.Graphics2D var22 = null;
    org.jfree.chart.plot.PlotRenderingInfo var23 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var24 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var23);
    double var25 = var24.getSeriesRunningTotal();
    java.awt.geom.Rectangle2D var26 = null;
    org.jfree.data.category.CategoryDataset var27 = null;
    org.jfree.chart.axis.CategoryAxis var28 = null;
    org.jfree.chart.axis.NumberAxis var29 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var30 = null;
    var29.setPlot(var30);
    org.jfree.chart.renderer.category.CategoryItemRenderer var32 = null;
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var27, var28, (org.jfree.chart.axis.ValueAxis)var29, var32);
    var33.setAnchorValue(0.0d, true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var37 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var39 = null;
    var37.setSeriesItemLabelsVisible(0, var39, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var43 = null;
    var37.setSeriesToolTipGenerator(1, var43, false);
    org.jfree.chart.urls.CategoryURLGenerator var46 = null;
    var37.setBaseURLGenerator(var46);
    java.awt.Graphics2D var48 = null;
    org.jfree.chart.plot.CategoryPlot var49 = null;
    org.jfree.chart.axis.ValueAxis var50 = null;
    org.jfree.chart.plot.Marker var51 = null;
    java.awt.geom.Rectangle2D var52 = null;
    var37.drawRangeMarker(var48, var49, var50, var51, var52);
    boolean var55 = var37.isSeriesVisibleInLegend(0);
    var33.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var37);
    org.jfree.chart.axis.CategoryAxis var57 = null;
    org.jfree.chart.axis.ValueAxis var58 = null;
    org.jfree.data.category.CategoryDataset var59 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.drawItem(var22, var24, var26, var33, var57, var58, var59, (-123), (-123), 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == true);

  }

  public void test121() {}
//   public void test121() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var4 = null;
//     var3.setPlot(var4);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var3, var6);
//     org.jfree.chart.LegendItemSource var8 = null;
//     org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
//     org.jfree.chart.util.RectangleEdge var10 = var9.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var12 = var11.getNextOutlinePaint();
//     var9.setBackgroundPaint(var12);
//     var7.setOutlinePaint(var12);
//     org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var7);
//     var15.fireChartChanged();
//     var15.setTextAntiAlias(false);
//     java.util.List var19 = var15.getSubtitles();
//     org.jfree.chart.ChartRenderingInfo var22 = null;
//     var15.handleClick(255, 1, var22);
// 
//   }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTickUnit var3 = new org.jfree.chart.axis.NumberTickUnit(100.0d, var1, (-855310));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.util.RectangleEdge var2 = var1.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var3 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var4 = var3.getNextOutlinePaint();
    var1.setBackgroundPaint(var4);
    org.jfree.chart.LegendItemSource var6 = null;
    org.jfree.chart.title.LegendTitle var7 = new org.jfree.chart.title.LegendTitle(var6);
    org.jfree.chart.util.RectangleInsets var8 = var7.getItemLabelPadding();
    var1.setItemLabelPadding(var8);
    java.awt.geom.Rectangle2D var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var11 = var8.createInsetRectangle(var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = var0.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var5 = var0.getPositiveItemLabelPosition(100, 0);
    org.jfree.chart.urls.CategoryURLGenerator var6 = var0.getBaseURLGenerator();
    java.lang.Boolean var8 = var0.getSeriesItemLabelsVisible((-855310));
    java.awt.Font var10 = var0.getSeriesItemLabelFont((-123));
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.95f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesShape((-123), var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test126() {}
//   public void test126() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var3 = null;
//     var2.setPlot(var3);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
//     var6.setAnchorValue(0.0d, true);
//     org.jfree.chart.axis.CategoryAxis var10 = var6.getDomainAxis();
//     org.jfree.data.category.CategoryDataset var11 = null;
//     org.jfree.chart.axis.CategoryAxis var12 = null;
//     org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var14 = null;
//     var13.setPlot(var14);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var11, var12, (org.jfree.chart.axis.ValueAxis)var13, var16);
//     java.awt.Stroke var18 = var13.getTickMarkStroke();
//     java.awt.Font var19 = var13.getLabelFont();
//     var6.setNoDataMessageFont(var19);
//     
//     // Checks the contract:  equals-hashcode on var6 and var17
//     assertTrue("Contract failed: equals-hashcode on var6 and var17", var6.equals(var17) ? var6.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var6
//     assertTrue("Contract failed: equals-hashcode on var17 and var6", var17.equals(var6) ? var17.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test127() {}
//   public void test127() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }
// 
// 
//     org.jfree.chart.text.TextBlock var1 = new org.jfree.chart.text.TextBlock();
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.util.Size2D var3 = var1.calculateDimensions(var2);
//     org.jfree.data.category.CategoryDataset var5 = null;
//     org.jfree.chart.axis.CategoryAxis var6 = null;
//     org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var8 = null;
//     var7.setPlot(var8);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot(var5, var6, (org.jfree.chart.axis.ValueAxis)var7, var10);
//     java.awt.Stroke var12 = var7.getTickMarkStroke();
//     java.awt.Font var13 = var7.getLabelFont();
//     java.awt.Color var16 = java.awt.Color.getColor("", (-1));
//     var1.addLine("CategoryLabelEntity: category=null, tooltip=hi!, url=", var13, (java.awt.Paint)var16);
//     org.jfree.data.category.CategoryDataset var18 = null;
//     org.jfree.chart.axis.CategoryAxis var19 = null;
//     org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var21 = null;
//     var20.setPlot(var21);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var23 = null;
//     org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot(var18, var19, (org.jfree.chart.axis.ValueAxis)var20, var23);
//     org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var26 = null;
//     var25.setPlot(var26);
//     org.jfree.chart.axis.ValueAxis[] var28 = new org.jfree.chart.axis.ValueAxis[] { var25};
//     var24.setRangeAxes(var28);
//     java.awt.Paint var30 = var24.getDomainGridlinePaint();
//     java.awt.Graphics2D var33 = null;
//     org.jfree.chart.text.G2TextMeasurer var34 = new org.jfree.chart.text.G2TextMeasurer(var33);
//     org.jfree.chart.text.TextBlock var35 = org.jfree.chart.text.TextUtilities.createTextBlock("CategoryLabelEntity: category=null, tooltip=hi!, url=", var13, var30, (-1.0f), 1, (org.jfree.chart.text.TextMeasurer)var34);
// 
//   }

  public void test128() {}
//   public void test128() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }
// 
// 
//     org.jfree.chart.block.BlockBorder var4 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 0.0d, 0.0d);
//     boolean var6 = var4.equals((java.lang.Object)(short)0);
//     java.awt.Graphics2D var7 = null;
//     org.jfree.chart.util.Size2D var8 = new org.jfree.chart.util.Size2D();
//     boolean var10 = var8.equals((java.lang.Object)(-1L));
//     double var11 = var8.getWidth();
//     double var12 = var8.getHeight();
//     org.jfree.chart.util.RectangleAnchor var15 = null;
//     java.awt.geom.Rectangle2D var16 = org.jfree.chart.util.RectangleAnchor.createRectangle(var8, 2.0d, (-1.0d), var15);
//     org.jfree.chart.axis.CategoryLabelPositions var19 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var20 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var21 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var19, var20);
//     org.jfree.chart.util.RectangleAnchor var22 = var20.getCategoryAnchor();
//     java.awt.geom.Rectangle2D var23 = org.jfree.chart.util.RectangleAnchor.createRectangle(var8, 2.0d, 1.0d, var22);
//     var4.draw(var7, var23);
// 
//   }

  public void test129() {}
//   public void test129() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var3 = null;
//     var2.setPlot(var3);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
//     org.jfree.chart.LegendItemSource var7 = null;
//     org.jfree.chart.title.LegendTitle var8 = new org.jfree.chart.title.LegendTitle(var7);
//     org.jfree.chart.util.RectangleEdge var9 = var8.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var10 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var11 = var10.getNextOutlinePaint();
//     var8.setBackgroundPaint(var11);
//     var6.setOutlinePaint(var11);
//     org.jfree.data.category.CategoryDataset var14 = null;
//     org.jfree.chart.axis.CategoryAxis var15 = null;
//     org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var17 = null;
//     var16.setPlot(var17);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var19 = null;
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot(var14, var15, (org.jfree.chart.axis.ValueAxis)var16, var19);
//     org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var22 = null;
//     var21.setPlot(var22);
//     org.jfree.chart.axis.ValueAxis[] var24 = new org.jfree.chart.axis.ValueAxis[] { var21};
//     var20.setRangeAxes(var24);
//     var6.setParent((org.jfree.chart.plot.Plot)var20);
//     org.jfree.chart.plot.Marker var28 = null;
//     org.jfree.chart.util.Layer var29 = null;
//     var6.addRangeMarker(1, var28, var29);
// 
//   }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = null;
    var0.setSeriesItemLabelsVisible(0, var2, false);
    java.awt.Stroke var5 = var0.getErrorIndicatorStroke();
    org.jfree.chart.plot.DrawingSupplier var6 = var0.getDrawingSupplier();
    java.lang.Boolean var8 = var0.getSeriesCreateEntities(10);
    java.awt.Paint var9 = var0.getBaseOutlinePaint();
    org.jfree.chart.labels.CategoryItemLabelGenerator var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelGenerator((-855310), var11, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = var0.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var5 = var0.getPositiveItemLabelPosition(100, 0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var6 = var0.getLegendItemToolTipGenerator();
    int var7 = var0.getColumnCount();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var9 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var10 = var9.getPositiveItemLabelPositionFallback();
    java.awt.Paint var13 = var9.getItemLabelPaint((-123), (-1));
    org.jfree.data.category.CategoryDataset var14 = null;
    org.jfree.chart.axis.CategoryAxis var15 = null;
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var17 = null;
    var16.setPlot(var17);
    org.jfree.chart.renderer.category.CategoryItemRenderer var19 = null;
    org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot(var14, var15, (org.jfree.chart.axis.ValueAxis)var16, var19);
    java.awt.Stroke var21 = var16.getTickMarkStroke();
    org.jfree.chart.LegendItemSource var22 = null;
    org.jfree.chart.title.LegendTitle var23 = new org.jfree.chart.title.LegendTitle(var22);
    org.jfree.chart.util.RectangleInsets var24 = var23.getItemLabelPadding();
    double var25 = var24.getTop();
    org.jfree.chart.block.LineBorder var26 = new org.jfree.chart.block.LineBorder(var13, var21, var24);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesStroke((-123), var21, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 2.0d);

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String[] var2 = var0.getStringArray("");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = null;
    var0.setSeriesItemLabelsVisible(0, var2, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var6 = null;
    var0.setSeriesToolTipGenerator(1, var6, false);
    org.jfree.chart.urls.CategoryURLGenerator var9 = null;
    var0.setBaseURLGenerator(var9);
    java.awt.Graphics2D var11 = null;
    org.jfree.chart.plot.CategoryPlot var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.plot.Marker var14 = null;
    java.awt.geom.Rectangle2D var15 = null;
    var0.drawRangeMarker(var11, var12, var13, var14, var15);
    boolean var18 = var0.isSeriesVisibleInLegend(0);
    var0.setBaseItemLabelsVisible(false, true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var23 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var25 = null;
    var23.setSeriesItemLabelsVisible(0, var25, false);
    java.awt.Paint var28 = var23.getBaseOutlinePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesOutlinePaint((-123), var28);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var4 = null;
    var3.setPlot(var4);
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var3, var6);
    org.jfree.chart.LegendItemSource var8 = null;
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
    org.jfree.chart.util.RectangleEdge var10 = var9.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var12 = var11.getNextOutlinePaint();
    var9.setBackgroundPaint(var12);
    var7.setOutlinePaint(var12);
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var7);
    var15.fireChartChanged();
    boolean var17 = var15.getAntiAlias();
    org.jfree.chart.ChartRenderingInfo var20 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var21 = var15.createBufferedImage((-123), (-1), var20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    org.jfree.chart.axis.CategoryAxis var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setDomainAxis((-123), var8, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test136() {}
//   public void test136() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }
// 
// 
//     org.jfree.chart.util.Size2D var0 = new org.jfree.chart.util.Size2D();
//     boolean var2 = var0.equals((java.lang.Object)(-1L));
//     org.jfree.chart.util.Size2D var5 = new org.jfree.chart.util.Size2D();
//     boolean var7 = var5.equals((java.lang.Object)(-1L));
//     double var8 = var5.getWidth();
//     double var9 = var5.getHeight();
//     org.jfree.chart.util.RectangleAnchor var12 = null;
//     java.awt.geom.Rectangle2D var13 = org.jfree.chart.util.RectangleAnchor.createRectangle(var5, 2.0d, (-1.0d), var12);
//     org.jfree.chart.axis.CategoryLabelPositions var16 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var17 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var18 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var16, var17);
//     org.jfree.chart.util.RectangleAnchor var19 = var17.getCategoryAnchor();
//     java.awt.geom.Rectangle2D var20 = org.jfree.chart.util.RectangleAnchor.createRectangle(var5, 2.0d, 1.0d, var19);
//     java.awt.geom.Rectangle2D var21 = org.jfree.chart.util.RectangleAnchor.createRectangle(var0, 1.0d, 100.0d, var19);
//     
//     // Checks the contract:  equals-hashcode on var0 and var5
//     assertTrue("Contract failed: equals-hashcode on var0 and var5", var0.equals(var5) ? var0.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var0
//     assertTrue("Contract failed: equals-hashcode on var5 and var0", var5.equals(var0) ? var5.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.util.RectangleEdge var2 = var1.getLegendItemGraphicEdge();
    org.jfree.chart.event.TitleChangeListener var3 = null;
    var1.addChangeListener(var3);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var5 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var7 = null;
    var5.setSeriesItemLabelsVisible(0, var7, false);
    java.awt.Paint var10 = var5.getBaseOutlinePaint();
    var1.setItemPaint(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test138() {}
//   public void test138() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }
// 
// 
//     org.jfree.chart.labels.ItemLabelPosition var0 = new org.jfree.chart.labels.ItemLabelPosition();
//     org.jfree.chart.LegendItemSource var1 = null;
//     org.jfree.chart.title.LegendTitle var2 = new org.jfree.chart.title.LegendTitle(var1);
//     org.jfree.chart.util.RectangleEdge var3 = var2.getLegendItemGraphicEdge();
//     org.jfree.chart.util.RectangleEdge var4 = org.jfree.chart.util.RectangleEdge.opposite(var3);
//     boolean var5 = var0.equals((java.lang.Object)var4);
//     org.jfree.chart.labels.ItemLabelAnchor var6 = var0.getItemLabelAnchor();
//     org.jfree.chart.axis.CategoryLabelPosition var7 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.text.TextAnchor var8 = var7.getRotationAnchor();
//     java.awt.Graphics2D var10 = null;
//     org.jfree.chart.axis.CategoryLabelPositions var13 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var14 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var15 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var13, var14);
//     org.jfree.chart.text.TextAnchor var16 = var14.getRotationAnchor();
//     org.jfree.chart.labels.ItemLabelPosition var18 = new org.jfree.chart.labels.ItemLabelPosition();
//     org.jfree.chart.LegendItemSource var19 = null;
//     org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle(var19);
//     org.jfree.chart.util.RectangleEdge var21 = var20.getLegendItemGraphicEdge();
//     org.jfree.chart.util.RectangleEdge var22 = org.jfree.chart.util.RectangleEdge.opposite(var21);
//     boolean var23 = var18.equals((java.lang.Object)var22);
//     org.jfree.chart.labels.ItemLabelAnchor var24 = var18.getItemLabelAnchor();
//     org.jfree.chart.axis.CategoryLabelPositions var25 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var26 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var27 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var25, var26);
//     org.jfree.chart.text.TextAnchor var28 = var26.getRotationAnchor();
//     org.jfree.chart.labels.ItemLabelPosition var29 = new org.jfree.chart.labels.ItemLabelPosition(var24, var28);
//     org.jfree.chart.text.TextUtilities.drawRotatedString("", var10, 100.0f, 0.0f, var16, 100.0d, var28);
//     org.jfree.chart.labels.ItemLabelPosition var32 = new org.jfree.chart.labels.ItemLabelPosition(var6, var8, var28, 2.0d);
//     
//     // Checks the contract:  equals-hashcode on var0 and var18
//     assertTrue("Contract failed: equals-hashcode on var0 and var18", var0.equals(var18) ? var0.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var0
//     assertTrue("Contract failed: equals-hashcode on var18 and var0", var18.equals(var0) ? var18.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = var0.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var5 = var0.getPositiveItemLabelPosition(100, 0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var6 = var0.getLegendItemToolTipGenerator();
    java.awt.Paint var9 = var0.getItemPaint(1, (-123));
    org.jfree.chart.renderer.category.StatisticalBarRenderer var11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var13 = var11.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var16 = var11.getPositiveItemLabelPosition(100, 0);
    org.jfree.chart.urls.CategoryURLGenerator var17 = var11.getBaseURLGenerator();
    java.lang.Boolean var19 = var11.getSeriesItemLabelsVisible((-855310));
    java.awt.Color var22 = java.awt.Color.getColor("", (-1));
    var11.setBasePaint((java.awt.Paint)var22, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelPaint((-1), (java.awt.Paint)var22);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }


    org.jfree.chart.util.StandardGradientPaintTransformer var0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    org.jfree.data.KeyedObjects2D var3 = new org.jfree.data.KeyedObjects2D();
    int var5 = var3.getRowIndex((java.lang.Comparable)(byte)1);
    boolean var6 = var0.equals((java.lang.Object)var5);
    java.lang.Object var7 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }


    org.jfree.chart.text.TextBlock var1 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var2 = null;
    org.jfree.chart.util.Size2D var3 = var1.calculateDimensions(var2);
    org.jfree.data.category.CategoryDataset var5 = null;
    org.jfree.chart.axis.CategoryAxis var6 = null;
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var8 = null;
    var7.setPlot(var8);
    org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot(var5, var6, (org.jfree.chart.axis.ValueAxis)var7, var10);
    java.awt.Stroke var12 = var7.getTickMarkStroke();
    java.awt.Font var13 = var7.getLabelFont();
    java.awt.Color var16 = java.awt.Color.getColor("", (-1));
    var1.addLine("CategoryLabelEntity: category=null, tooltip=hi!, url=", var13, (java.awt.Paint)var16);
    java.awt.Paint var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextLine var19 = new org.jfree.chart.text.TextLine("Range[-1.0,-1.0]", var13, var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = var0.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.CategoryItemLabelGenerator var3 = null;
    var0.setBaseItemLabelGenerator(var3);
    org.jfree.chart.plot.DefaultDrawingSupplier var5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var6 = var5.getNextOutlinePaint();
    var0.setErrorIndicatorPaint(var6);
    org.jfree.data.category.CategoryDataset var9 = null;
    org.jfree.chart.axis.CategoryAxis var10 = null;
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var12 = null;
    var11.setPlot(var12);
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var9, var10, (org.jfree.chart.axis.ValueAxis)var11, var14);
    org.jfree.chart.LegendItemSource var16 = null;
    org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle(var16);
    org.jfree.chart.util.RectangleEdge var18 = var17.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var19 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var20 = var19.getNextOutlinePaint();
    var17.setBackgroundPaint(var20);
    var15.setOutlinePaint(var20);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesFillPaint((-123), var20, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test143() {}
//   public void test143() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }
// 
// 
//     org.jfree.chart.LegendItemSource var0 = null;
//     org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
//     org.jfree.chart.util.RectangleInsets var2 = var1.getItemLabelPadding();
//     org.jfree.chart.LegendItemSource var3 = null;
//     org.jfree.chart.title.LegendTitle var4 = new org.jfree.chart.title.LegendTitle(var3);
//     org.jfree.chart.util.RectangleInsets var5 = var4.getItemLabelPadding();
//     double var6 = var5.getTop();
//     var1.setPadding(var5);
//     org.jfree.chart.util.Size2D var8 = new org.jfree.chart.util.Size2D();
//     boolean var10 = var8.equals((java.lang.Object)(-1L));
//     double var11 = var8.getWidth();
//     double var12 = var8.getHeight();
//     org.jfree.chart.util.RectangleAnchor var15 = null;
//     java.awt.geom.Rectangle2D var16 = org.jfree.chart.util.RectangleAnchor.createRectangle(var8, 2.0d, (-1.0d), var15);
//     org.jfree.chart.axis.CategoryLabelPositions var19 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var20 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var21 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var19, var20);
//     org.jfree.chart.util.RectangleAnchor var22 = var20.getCategoryAnchor();
//     java.awt.geom.Rectangle2D var23 = org.jfree.chart.util.RectangleAnchor.createRectangle(var8, 2.0d, 1.0d, var22);
//     java.awt.geom.Rectangle2D var24 = var5.createOutsetRectangle(var23);
//     org.jfree.chart.util.Size2D var25 = new org.jfree.chart.util.Size2D();
//     boolean var27 = var25.equals((java.lang.Object)(-1L));
//     double var28 = var25.getWidth();
//     double var29 = var25.getHeight();
//     org.jfree.chart.util.RectangleAnchor var32 = null;
//     java.awt.geom.Rectangle2D var33 = org.jfree.chart.util.RectangleAnchor.createRectangle(var25, 2.0d, (-1.0d), var32);
//     org.jfree.chart.axis.CategoryLabelPositions var36 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var37 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var38 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var36, var37);
//     org.jfree.chart.util.RectangleAnchor var39 = var37.getCategoryAnchor();
//     java.awt.geom.Rectangle2D var40 = org.jfree.chart.util.RectangleAnchor.createRectangle(var25, 2.0d, 1.0d, var39);
//     java.awt.geom.Point2D var41 = org.jfree.chart.util.RectangleAnchor.coordinates(var23, var39);
//     
//     // Checks the contract:  equals-hashcode on var8 and var25
//     assertTrue("Contract failed: equals-hashcode on var8 and var25", var8.equals(var25) ? var8.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var8
//     assertTrue("Contract failed: equals-hashcode on var25 and var8", var25.equals(var8) ? var25.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    java.util.Set var1 = var0.keySet();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var3 = var0.getString("");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test145() {}
//   public void test145() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("Range[-1.0,-1.0]", var1, 0.95f, 100.0f, 0.05d, 10.0f, 0.95f);
// 
//   }

  public void test146() {}
//   public void test146() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var2 = var0.getSeriesItemLabelsVisible(100);
//     org.jfree.chart.labels.ItemLabelPosition var5 = var0.getPositiveItemLabelPosition(100, 0);
//     org.jfree.chart.urls.CategoryURLGenerator var6 = var0.getBaseURLGenerator();
//     java.lang.Boolean var8 = var0.getSeriesItemLabelsVisible((-855310));
//     java.awt.Color var11 = java.awt.Color.getColor("", (-1));
//     var0.setBasePaint((java.awt.Paint)var11, true);
//     double var14 = var0.getLowerClip();
//     org.jfree.chart.labels.ItemLabelPosition var15 = new org.jfree.chart.labels.ItemLabelPosition();
//     org.jfree.chart.LegendItemSource var16 = null;
//     org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle(var16);
//     org.jfree.chart.util.RectangleEdge var18 = var17.getLegendItemGraphicEdge();
//     org.jfree.chart.util.RectangleEdge var19 = org.jfree.chart.util.RectangleEdge.opposite(var18);
//     boolean var20 = var15.equals((java.lang.Object)var19);
//     org.jfree.chart.labels.ItemLabelAnchor var21 = var15.getItemLabelAnchor();
//     org.jfree.chart.axis.CategoryLabelPositions var22 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var23 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var24 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var22, var23);
//     org.jfree.chart.text.TextAnchor var25 = var23.getRotationAnchor();
//     org.jfree.chart.labels.ItemLabelPosition var26 = new org.jfree.chart.labels.ItemLabelPosition(var21, var25);
//     var0.setBaseNegativeItemLabelPosition(var26);
//     
//     // Checks the contract:  equals-hashcode on var5 and var15
//     assertTrue("Contract failed: equals-hashcode on var5 and var15", var5.equals(var15) ? var5.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var5
//     assertTrue("Contract failed: equals-hashcode on var15 and var5", var15.equals(var5) ? var15.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test147() {}
//   public void test147() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle.Control var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("hi!", var1, var2);
// 
//   }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = null;
    var0.setSeriesItemLabelsVisible(0, var2, false);
    java.awt.Paint var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBaseOutlinePaint(var5, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test149() {}
//   public void test149() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }
// 
// 
//     org.jfree.chart.util.Size2D var0 = new org.jfree.chart.util.Size2D();
//     boolean var2 = var0.equals((java.lang.Object)(-1L));
//     double var3 = var0.getWidth();
//     double var4 = var0.getHeight();
//     org.jfree.chart.util.RectangleAnchor var7 = null;
//     java.awt.geom.Rectangle2D var8 = org.jfree.chart.util.RectangleAnchor.createRectangle(var0, 2.0d, (-1.0d), var7);
//     org.jfree.chart.axis.CategoryLabelPositions var11 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var12 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var13 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var11, var12);
//     org.jfree.chart.util.RectangleAnchor var14 = var12.getCategoryAnchor();
//     java.awt.geom.Rectangle2D var15 = org.jfree.chart.util.RectangleAnchor.createRectangle(var0, 2.0d, 1.0d, var14);
//     java.awt.geom.Rectangle2D var16 = null;
//     boolean var17 = org.jfree.chart.util.ShapeUtilities.contains(var15, var16);
// 
//   }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.LegendItemSource var1 = null;
    org.jfree.chart.title.LegendTitle var2 = new org.jfree.chart.title.LegendTitle(var1);
    org.jfree.chart.util.RectangleInsets var3 = var2.getItemLabelPadding();
    double var4 = var3.getTop();
    double var6 = var3.trimWidth(10.0d);
    var0.setMargin(var3);
    java.awt.geom.Rectangle2D var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var9 = var3.createOutsetRectangle(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 6.0d);

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(1.0d, Double.NaN);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTickUnit var2 = new org.jfree.chart.axis.NumberTickUnit(2.0d, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }


    org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextBlockAnchor var4 = null;
    var0.draw(var1, 100.0f, 100.0f, var4);
    org.jfree.chart.text.TextLine var6 = new org.jfree.chart.text.TextLine();
    org.jfree.chart.text.TextFragment var7 = var6.getFirstTextFragment();
    var0.addLine(var6);
    org.jfree.chart.text.TextFragment var9 = null;
    var6.addFragment(var9);
    org.jfree.chart.text.TextFragment var11 = null;
    var6.addFragment(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Range[-1.0,-1.0]", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }


    org.jfree.chart.axis.CategoryLabelPositions var0 = null;
    org.jfree.chart.axis.CategoryLabelPositions var1 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var2 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var3 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var1, var2);
    org.jfree.chart.text.TextAnchor var4 = var2.getRotationAnchor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var5 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(var0, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

//  public void test157() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }
//
//
//    java.lang.Class var1 = null;
//    java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("hi!", var1);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNull(var2);
//
//  }
//
  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    var6.setAnchorValue(0.0d, true);
    org.jfree.chart.axis.CategoryAxis var10 = var6.getDomainAxis();
    org.jfree.chart.util.RectangleEdge var11 = var6.getRangeAxisEdge();
    org.jfree.chart.util.SortOrder var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setRowRenderingOrder(var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 4.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test160() {}
//   public void test160() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }
// 
// 
//     org.jfree.chart.axis.TickType var0 = null;
//     java.awt.Graphics2D var4 = null;
//     org.jfree.chart.axis.CategoryLabelPositions var7 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var8 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var9 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var7, var8);
//     org.jfree.chart.text.TextAnchor var10 = var8.getRotationAnchor();
//     org.jfree.chart.labels.ItemLabelPosition var12 = new org.jfree.chart.labels.ItemLabelPosition();
//     org.jfree.chart.LegendItemSource var13 = null;
//     org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle(var13);
//     org.jfree.chart.util.RectangleEdge var15 = var14.getLegendItemGraphicEdge();
//     org.jfree.chart.util.RectangleEdge var16 = org.jfree.chart.util.RectangleEdge.opposite(var15);
//     boolean var17 = var12.equals((java.lang.Object)var16);
//     org.jfree.chart.labels.ItemLabelAnchor var18 = var12.getItemLabelAnchor();
//     org.jfree.chart.axis.CategoryLabelPositions var19 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var20 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var21 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var19, var20);
//     org.jfree.chart.text.TextAnchor var22 = var20.getRotationAnchor();
//     org.jfree.chart.labels.ItemLabelPosition var23 = new org.jfree.chart.labels.ItemLabelPosition(var18, var22);
//     org.jfree.chart.text.TextUtilities.drawRotatedString("", var4, 100.0f, 0.0f, var10, 100.0d, var22);
//     org.jfree.chart.text.TextBlock var26 = new org.jfree.chart.text.TextBlock();
//     java.util.List var27 = var26.getLines();
//     org.jfree.chart.text.TextLine var28 = null;
//     var26.addLine(var28);
//     org.jfree.chart.util.HorizontalAlignment var30 = var26.getLineAlignment();
//     org.jfree.chart.text.TextBlockAnchor var31 = null;
//     java.awt.Graphics2D var33 = null;
//     org.jfree.chart.labels.ItemLabelPosition var36 = new org.jfree.chart.labels.ItemLabelPosition();
//     org.jfree.chart.LegendItemSource var37 = null;
//     org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle(var37);
//     org.jfree.chart.util.RectangleEdge var39 = var38.getLegendItemGraphicEdge();
//     org.jfree.chart.util.RectangleEdge var40 = org.jfree.chart.util.RectangleEdge.opposite(var39);
//     boolean var41 = var36.equals((java.lang.Object)var40);
//     org.jfree.chart.labels.ItemLabelAnchor var42 = var36.getItemLabelAnchor();
//     org.jfree.chart.axis.CategoryLabelPositions var43 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var44 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var45 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var43, var44);
//     org.jfree.chart.text.TextAnchor var46 = var44.getRotationAnchor();
//     org.jfree.chart.labels.ItemLabelPosition var47 = new org.jfree.chart.labels.ItemLabelPosition(var42, var46);
//     org.jfree.chart.text.TextUtilities.drawRotatedString("", var33, 1.0f, (-1.0f), var46, 2.0d, 1.0f, 0.0f);
//     org.jfree.chart.axis.CategoryTick var53 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)(byte)0, var26, var31, var46, 0.0d);
//     org.jfree.chart.text.TextAnchor var54 = var53.getTextAnchor();
//     org.jfree.chart.axis.NumberTick var56 = new org.jfree.chart.axis.NumberTick(var0, 2.0d, "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", var10, var54, 4.0d);
//     
//     // Checks the contract:  equals-hashcode on var12 and var36
//     assertTrue("Contract failed: equals-hashcode on var12 and var36", var12.equals(var36) ? var12.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var47
//     assertTrue("Contract failed: equals-hashcode on var23 and var47", var23.equals(var47) ? var23.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var12
//     assertTrue("Contract failed: equals-hashcode on var36 and var12", var36.equals(var12) ? var36.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var23
//     assertTrue("Contract failed: equals-hashcode on var47 and var23", var47.equals(var23) ? var47.hashCode() == var23.hashCode() : true);
// 
//   }

  public void test161() {}
//   public void test161() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }
// 
// 
//     org.jfree.chart.LegendItemSource var0 = null;
//     org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
//     org.jfree.chart.util.RectangleEdge var2 = var1.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var3 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var4 = var3.getNextOutlinePaint();
//     var1.setBackgroundPaint(var4);
//     org.jfree.chart.util.HorizontalAlignment var6 = var1.getHorizontalAlignment();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var7 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var9 = var7.getSeriesItemLabelsVisible(100);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var10 = null;
//     var7.setBaseItemLabelGenerator(var10);
//     org.jfree.chart.plot.DefaultDrawingSupplier var12 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var13 = var12.getNextOutlinePaint();
//     var7.setErrorIndicatorPaint(var13);
//     var1.setItemPaint(var13);
//     
//     // Checks the contract:  equals-hashcode on var3 and var12
//     assertTrue("Contract failed: equals-hashcode on var3 and var12", var3.equals(var12) ? var3.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var3
//     assertTrue("Contract failed: equals-hashcode on var12 and var3", var12.equals(var3) ? var12.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test162() {}
//   public void test162() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var4 = null;
//     var3.setPlot(var4);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var3, var6);
//     org.jfree.chart.LegendItemSource var8 = null;
//     org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
//     org.jfree.chart.util.RectangleEdge var10 = var9.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var12 = var11.getNextOutlinePaint();
//     var9.setBackgroundPaint(var12);
//     var7.setOutlinePaint(var12);
//     org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var7);
//     org.jfree.chart.LegendItemSource var16 = null;
//     org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle(var16);
//     org.jfree.chart.util.RectangleEdge var18 = var17.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var19 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var20 = var19.getNextOutlinePaint();
//     var17.setBackgroundPaint(var20);
//     org.jfree.chart.text.TextBlock var22 = new org.jfree.chart.text.TextBlock();
//     java.util.List var23 = var22.getLines();
//     boolean var24 = var17.equals((java.lang.Object)var22);
//     org.jfree.chart.event.TitleChangeEvent var25 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title)var17);
//     var15.titleChanged(var25);
//     
//     // Checks the contract:  equals-hashcode on var11 and var19
//     assertTrue("Contract failed: equals-hashcode on var11 and var19", var11.equals(var19) ? var11.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var11
//     assertTrue("Contract failed: equals-hashcode on var19 and var11", var19.equals(var11) ? var19.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    var6.setAnchorValue(0.0d, true);
    org.jfree.chart.axis.CategoryAxis var10 = var6.getDomainAxis();
    org.jfree.chart.util.RectangleEdge var11 = var6.getRangeAxisEdge();
    org.jfree.chart.annotations.CategoryAnnotation var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.addAnnotation(var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }


    org.jfree.chart.util.Size2D var0 = new org.jfree.chart.util.Size2D();
    boolean var2 = var0.equals((java.lang.Object)(-1L));
    double var3 = var0.getWidth();
    double var4 = var0.getHeight();
    org.jfree.chart.util.RectangleAnchor var7 = null;
    java.awt.geom.Rectangle2D var8 = org.jfree.chart.util.RectangleAnchor.createRectangle(var0, 2.0d, (-1.0d), var7);
    org.jfree.chart.axis.CategoryLabelPositions var11 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var12 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var13 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var11, var12);
    org.jfree.chart.util.RectangleAnchor var14 = var12.getCategoryAnchor();
    java.awt.geom.Rectangle2D var15 = org.jfree.chart.util.RectangleAnchor.createRectangle(var0, 2.0d, 1.0d, var14);
    java.lang.String var16 = var14.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + "RectangleAnchor.CENTER"+ "'", var16.equals("RectangleAnchor.CENTER"));

  }

  public void test166() {}
//   public void test166() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var4 = null;
//     var3.setPlot(var4);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var3, var6);
//     org.jfree.chart.LegendItemSource var8 = null;
//     org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
//     org.jfree.chart.util.RectangleEdge var10 = var9.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var12 = var11.getNextOutlinePaint();
//     var9.setBackgroundPaint(var12);
//     var7.setOutlinePaint(var12);
//     org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var7);
//     var15.fireChartChanged();
//     boolean var17 = var15.getAntiAlias();
//     java.awt.Image var18 = var15.getBackgroundImage();
//     java.awt.Graphics2D var19 = null;
//     java.awt.Color var22 = java.awt.Color.getColor("", (-1));
//     java.awt.image.ColorModel var23 = null;
//     java.awt.Rectangle var24 = null;
//     org.jfree.chart.LegendItemSource var25 = null;
//     org.jfree.chart.title.LegendTitle var26 = new org.jfree.chart.title.LegendTitle(var25);
//     org.jfree.chart.util.RectangleInsets var27 = var26.getItemLabelPadding();
//     org.jfree.chart.LegendItemSource var28 = null;
//     org.jfree.chart.title.LegendTitle var29 = new org.jfree.chart.title.LegendTitle(var28);
//     org.jfree.chart.util.RectangleInsets var30 = var29.getItemLabelPadding();
//     double var31 = var30.getTop();
//     var26.setPadding(var30);
//     org.jfree.chart.util.Size2D var33 = new org.jfree.chart.util.Size2D();
//     boolean var35 = var33.equals((java.lang.Object)(-1L));
//     double var36 = var33.getWidth();
//     double var37 = var33.getHeight();
//     org.jfree.chart.util.RectangleAnchor var40 = null;
//     java.awt.geom.Rectangle2D var41 = org.jfree.chart.util.RectangleAnchor.createRectangle(var33, 2.0d, (-1.0d), var40);
//     org.jfree.chart.axis.CategoryLabelPositions var44 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var45 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var46 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var44, var45);
//     org.jfree.chart.util.RectangleAnchor var47 = var45.getCategoryAnchor();
//     java.awt.geom.Rectangle2D var48 = org.jfree.chart.util.RectangleAnchor.createRectangle(var33, 2.0d, 1.0d, var47);
//     java.awt.geom.Rectangle2D var49 = var30.createOutsetRectangle(var48);
//     java.awt.geom.AffineTransform var50 = null;
//     java.awt.RenderingHints var51 = null;
//     java.awt.PaintContext var52 = var22.createContext(var23, var24, var49, var50, var51);
//     var15.draw(var19, (java.awt.geom.Rectangle2D)var24);
// 
//   }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var4 = null;
    var3.setPlot(var4);
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var3, var6);
    org.jfree.chart.LegendItemSource var8 = null;
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
    org.jfree.chart.util.RectangleEdge var10 = var9.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var12 = var11.getNextOutlinePaint();
    var9.setBackgroundPaint(var12);
    var7.setOutlinePaint(var12);
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var7);
    var15.fireChartChanged();
    var15.setTextAntiAlias(false);
    java.util.List var19 = var15.getSubtitles();
    var15.setNotify(false);
    org.jfree.chart.ChartRenderingInfo var24 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var25 = var15.createBufferedImage(0, 0, var24);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }


    org.jfree.chart.plot.PlotRenderingInfo var0 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var1 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var0);
    double var2 = var1.getSeriesRunningTotal();
    double var3 = var1.getBarWidth();
    org.jfree.chart.plot.PlotRenderingInfo var4 = var1.getInfo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = var0.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var5 = var0.getPositiveItemLabelPosition(100, 0);
    org.jfree.chart.urls.CategoryURLGenerator var6 = var0.getBaseURLGenerator();
    java.lang.Boolean var8 = var0.getSeriesItemLabelsVisible((-855310));
    java.awt.Color var11 = java.awt.Color.getColor("", (-1));
    var0.setBasePaint((java.awt.Paint)var11, true);
    double var14 = var0.getLowerClip();
    java.lang.Boolean var16 = var0.getSeriesCreateEntities((-1));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesVisibleInLegend((-855310), (java.lang.Boolean)true, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }


    java.lang.Comparable var0 = null;
    org.jfree.data.KeyedValues var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.CategoryDataset var2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test171() {}
//   public void test171() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.axis.CategoryLabelPosition var4 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.text.TextAnchor var5 = var4.getRotationAnchor();
//     org.jfree.chart.text.TextBlock var8 = new org.jfree.chart.text.TextBlock();
//     java.util.List var9 = var8.getLines();
//     org.jfree.chart.text.TextLine var10 = null;
//     var8.addLine(var10);
//     org.jfree.chart.util.HorizontalAlignment var12 = var8.getLineAlignment();
//     org.jfree.chart.text.TextBlockAnchor var13 = null;
//     java.awt.Graphics2D var15 = null;
//     org.jfree.chart.labels.ItemLabelPosition var18 = new org.jfree.chart.labels.ItemLabelPosition();
//     org.jfree.chart.LegendItemSource var19 = null;
//     org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle(var19);
//     org.jfree.chart.util.RectangleEdge var21 = var20.getLegendItemGraphicEdge();
//     org.jfree.chart.util.RectangleEdge var22 = org.jfree.chart.util.RectangleEdge.opposite(var21);
//     boolean var23 = var18.equals((java.lang.Object)var22);
//     org.jfree.chart.labels.ItemLabelAnchor var24 = var18.getItemLabelAnchor();
//     org.jfree.chart.axis.CategoryLabelPositions var25 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var26 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var27 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var25, var26);
//     org.jfree.chart.text.TextAnchor var28 = var26.getRotationAnchor();
//     org.jfree.chart.labels.ItemLabelPosition var29 = new org.jfree.chart.labels.ItemLabelPosition(var24, var28);
//     org.jfree.chart.text.TextUtilities.drawRotatedString("", var15, 1.0f, (-1.0f), var28, 2.0d, 1.0f, 0.0f);
//     org.jfree.chart.axis.CategoryTick var35 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)(byte)0, var8, var13, var28, 0.0d);
//     org.jfree.chart.text.TextUtilities.drawRotatedString("NOID", var1, 0.95f, 0.95f, var5, 6.0d, var28);
// 
//   }

//  public void test172() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }
//
//
//    java.lang.Class var1 = null;
//    java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("", var1);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var2);
//
//  }
//
  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }


    org.jfree.chart.LegendItemCollection var0 = new org.jfree.chart.LegendItemCollection();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var2 = var0.get((-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }


    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    org.jfree.chart.block.BlockContainer var2 = new org.jfree.chart.block.BlockContainer();
    boolean var3 = var1.equals((java.lang.Object)var2);
    java.lang.Object var4 = var2.clone();
    org.jfree.chart.LegendItemSource var5 = null;
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle(var5);
    org.jfree.chart.util.RectangleEdge var7 = var6.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var8 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var9 = var8.getNextOutlinePaint();
    var6.setBackgroundPaint(var9);
    org.jfree.chart.text.TextBlock var11 = new org.jfree.chart.text.TextBlock();
    java.util.List var12 = var11.getLines();
    boolean var13 = var6.equals((java.lang.Object)var11);
    org.jfree.chart.event.TitleChangeEvent var14 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title)var6);
    org.jfree.chart.axis.AxisState var15 = new org.jfree.chart.axis.AxisState();
    org.jfree.chart.text.TextBlock var16 = new org.jfree.chart.text.TextBlock();
    java.util.List var17 = var16.getLines();
    var15.setTicks(var17);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.add((org.jfree.chart.block.Block)var6, (java.lang.Object)var15);
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test175() {}
//   public void test175() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, (-855310));
// 
//   }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }


    org.jfree.data.xy.XYDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    java.util.Set var1 = var0.keySet();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var3 = var0.getString("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var4 = null;
    var3.setPlot(var4);
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var3, var6);
    org.jfree.chart.LegendItemSource var8 = null;
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
    org.jfree.chart.util.RectangleEdge var10 = var9.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var12 = var11.getNextOutlinePaint();
    var9.setBackgroundPaint(var12);
    var7.setOutlinePaint(var12);
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var7);
    var15.fireChartChanged();
    var15.setTextAntiAlias(false);
    org.jfree.chart.ChartRenderingInfo var22 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var23 = var15.createBufferedImage(10, (-1), (-1), var22);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test179() {}
//   public void test179() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("HorizontalAlignment.CENTER", var1, Double.NaN, 1.0f, 0.95f);
// 
//   }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    org.jfree.chart.LegendItemSource var7 = null;
    org.jfree.chart.title.LegendTitle var8 = new org.jfree.chart.title.LegendTitle(var7);
    org.jfree.chart.util.RectangleEdge var9 = var8.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var10 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var11 = var10.getNextOutlinePaint();
    var8.setBackgroundPaint(var11);
    var6.setOutlinePaint(var11);
    var6.clearDomainMarkers();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var16 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var18 = var16.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var21 = var16.getPositiveItemLabelPosition(100, 0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var22 = var16.getLegendItemToolTipGenerator();
    int var23 = var16.getColumnCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setRenderer((-123), (org.jfree.chart.renderer.category.CategoryItemRenderer)var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var1 = null;
    var0.setPlot(var1);
    var0.setLowerBound(2.0d);
    java.lang.String var5 = var0.getLabelToolTip();
    org.jfree.data.category.CategoryDataset var6 = null;
    org.jfree.chart.axis.CategoryAxis var7 = null;
    org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var9 = null;
    var8.setPlot(var9);
    org.jfree.chart.renderer.category.CategoryItemRenderer var11 = null;
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot(var6, var7, (org.jfree.chart.axis.ValueAxis)var8, var11);
    java.awt.Stroke var13 = var8.getTickMarkStroke();
    var8.setVerticalTickLabels(false);
    org.jfree.data.category.CategoryDataset var16 = null;
    org.jfree.chart.axis.CategoryAxis var17 = null;
    org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var19 = null;
    var18.setPlot(var19);
    org.jfree.chart.renderer.category.CategoryItemRenderer var21 = null;
    org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot(var16, var17, (org.jfree.chart.axis.ValueAxis)var18, var21);
    var22.setAnchorValue(0.0d, true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var26 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var28 = null;
    var26.setSeriesItemLabelsVisible(0, var28, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var32 = null;
    var26.setSeriesToolTipGenerator(1, var32, false);
    org.jfree.chart.urls.CategoryURLGenerator var35 = null;
    var26.setBaseURLGenerator(var35);
    java.awt.Graphics2D var37 = null;
    org.jfree.chart.plot.CategoryPlot var38 = null;
    org.jfree.chart.axis.ValueAxis var39 = null;
    org.jfree.chart.plot.Marker var40 = null;
    java.awt.geom.Rectangle2D var41 = null;
    var26.drawRangeMarker(var37, var38, var39, var40, var41);
    boolean var44 = var26.isSeriesVisibleInLegend(0);
    var22.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var26);
    var8.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var22);
    var0.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var22);
    org.jfree.chart.plot.PlotRenderingInfo var49 = null;
    java.awt.geom.Point2D var50 = null;
    var22.zoomDomainAxes(2.0d, var49, var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == true);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    java.awt.Stroke var7 = var2.getTickMarkStroke();
    var2.zoomRange((-1.0d), 100.0d);
    org.jfree.chart.block.BlockContainer var11 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.util.RectangleInsets var12 = var11.getPadding();
    double var14 = var12.calculateTopInset(100.0d);
    var2.setLabelInsets(var12);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setAutoRangeMinimumSize(0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.95f, 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test184() {}
//   public void test184() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var2 = null;
//     var0.setSeriesItemLabelsVisible(0, var2, false);
//     org.jfree.chart.labels.CategoryToolTipGenerator var6 = null;
//     var0.setSeriesToolTipGenerator(1, var6, false);
//     org.jfree.chart.urls.CategoryURLGenerator var9 = null;
//     var0.setBaseURLGenerator(var9);
//     var0.setBaseCreateEntities(false, false);
//     java.awt.Graphics2D var14 = null;
//     org.jfree.data.category.CategoryDataset var15 = null;
//     org.jfree.chart.axis.CategoryAxis var16 = null;
//     org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var18 = null;
//     var17.setPlot(var18);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var15, var16, (org.jfree.chart.axis.ValueAxis)var17, var20);
//     org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var23 = null;
//     var22.setPlot(var23);
//     org.jfree.chart.axis.ValueAxis[] var25 = new org.jfree.chart.axis.ValueAxis[] { var22};
//     var21.setRangeAxes(var25);
//     java.awt.Paint var27 = var21.getDomainGridlinePaint();
//     float var28 = var21.getForegroundAlpha();
//     org.jfree.chart.LegendItemSource var29 = null;
//     org.jfree.chart.title.LegendTitle var30 = new org.jfree.chart.title.LegendTitle(var29);
//     org.jfree.chart.util.RectangleInsets var31 = var30.getItemLabelPadding();
//     org.jfree.chart.LegendItemSource var32 = null;
//     org.jfree.chart.title.LegendTitle var33 = new org.jfree.chart.title.LegendTitle(var32);
//     org.jfree.chart.util.RectangleInsets var34 = var33.getItemLabelPadding();
//     double var35 = var34.getTop();
//     var30.setPadding(var34);
//     org.jfree.chart.util.Size2D var37 = new org.jfree.chart.util.Size2D();
//     boolean var39 = var37.equals((java.lang.Object)(-1L));
//     double var40 = var37.getWidth();
//     double var41 = var37.getHeight();
//     org.jfree.chart.util.RectangleAnchor var44 = null;
//     java.awt.geom.Rectangle2D var45 = org.jfree.chart.util.RectangleAnchor.createRectangle(var37, 2.0d, (-1.0d), var44);
//     org.jfree.chart.axis.CategoryLabelPositions var48 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var49 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var50 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var48, var49);
//     org.jfree.chart.util.RectangleAnchor var51 = var49.getCategoryAnchor();
//     java.awt.geom.Rectangle2D var52 = org.jfree.chart.util.RectangleAnchor.createRectangle(var37, 2.0d, 1.0d, var51);
//     java.awt.geom.Rectangle2D var53 = var34.createOutsetRectangle(var52);
//     var0.drawOutline(var14, var21, var53);
// 
//   }

  public void test185() {}
//   public void test185() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var2 = null;
//     org.jfree.chart.axis.CategoryAxis var3 = null;
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var5 = null;
//     var4.setPlot(var5);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var2, var3, (org.jfree.chart.axis.ValueAxis)var4, var7);
//     java.awt.Stroke var9 = var4.getTickMarkStroke();
//     java.awt.Font var10 = var4.getLabelFont();
//     org.jfree.data.category.CategoryDataset var11 = null;
//     org.jfree.chart.axis.CategoryAxis var12 = null;
//     org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var14 = null;
//     var13.setPlot(var14);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var11, var12, (org.jfree.chart.axis.ValueAxis)var13, var16);
//     java.awt.Stroke var18 = var13.getTickMarkStroke();
//     var13.zoomRange((-1.0d), 100.0d);
//     org.jfree.chart.block.BlockContainer var22 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.util.RectangleInsets var23 = var22.getPadding();
//     double var25 = var23.calculateTopInset(100.0d);
//     var13.setLabelInsets(var23);
//     java.awt.Paint var27 = var13.getTickMarkPaint();
//     org.jfree.chart.text.TextFragment var29 = new org.jfree.chart.text.TextFragment("NOID", var10, var27, 10.0f);
//     org.jfree.data.category.CategoryDataset var30 = null;
//     org.jfree.chart.axis.CategoryAxis var31 = null;
//     org.jfree.chart.axis.NumberAxis var32 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var33 = null;
//     var32.setPlot(var33);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var35 = null;
//     org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot(var30, var31, (org.jfree.chart.axis.ValueAxis)var32, var35);
//     org.jfree.chart.LegendItemSource var37 = null;
//     org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle(var37);
//     org.jfree.chart.util.RectangleEdge var39 = var38.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var40 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var41 = var40.getNextOutlinePaint();
//     var38.setBackgroundPaint(var41);
//     var36.setOutlinePaint(var41);
//     java.awt.Stroke var44 = var36.getRangeCrosshairStroke();
//     java.awt.Paint var45 = null;
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var46 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var47 = var46.getPositiveItemLabelPositionFallback();
//     java.awt.Paint var50 = var46.getItemLabelPaint((-123), (-1));
//     org.jfree.data.category.CategoryDataset var51 = null;
//     org.jfree.chart.axis.CategoryAxis var52 = null;
//     org.jfree.chart.axis.NumberAxis var53 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var54 = null;
//     var53.setPlot(var54);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var56 = null;
//     org.jfree.chart.plot.CategoryPlot var57 = new org.jfree.chart.plot.CategoryPlot(var51, var52, (org.jfree.chart.axis.ValueAxis)var53, var56);
//     java.awt.Stroke var58 = var53.getTickMarkStroke();
//     org.jfree.chart.LegendItemSource var59 = null;
//     org.jfree.chart.title.LegendTitle var60 = new org.jfree.chart.title.LegendTitle(var59);
//     org.jfree.chart.util.RectangleInsets var61 = var60.getItemLabelPadding();
//     double var62 = var61.getTop();
//     org.jfree.chart.block.LineBorder var63 = new org.jfree.chart.block.LineBorder(var50, var58, var61);
//     java.awt.Stroke var64 = var63.getStroke();
//     org.jfree.chart.plot.ValueMarker var66 = new org.jfree.chart.plot.ValueMarker(4.0d, var27, var44, var45, var64, 1.0f);
//     
//     // Checks the contract:  equals-hashcode on var8 and var57
//     assertTrue("Contract failed: equals-hashcode on var8 and var57", var8.equals(var57) ? var8.hashCode() == var57.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var57 and var8
//     assertTrue("Contract failed: equals-hashcode on var57 and var8", var57.equals(var8) ? var57.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.data.KeyToGroupMap var1 = null;
    org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }


    org.jfree.data.Range var0 = null;
    org.jfree.data.Range var2 = org.jfree.data.Range.expandToInclude(var0, (-1.0d));
    org.jfree.data.Range var3 = null;
    org.jfree.data.Range var5 = org.jfree.data.Range.expandToInclude(var3, (-1.0d));
    org.jfree.data.Range var6 = org.jfree.data.Range.combine(var2, var5);
    boolean var9 = var2.intersects(1.0d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }


    org.jfree.chart.plot.DefaultDrawingSupplier var4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    boolean var6 = var4.equals((java.lang.Object)(short)10);
    java.awt.Paint var7 = var4.getNextFillPaint();
    java.awt.Paint var8 = var4.getNextPaint();
    java.awt.Shape var9 = var4.getNextShape();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var12 = var10.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var15 = var10.getPositiveItemLabelPosition(100, 0);
    org.jfree.chart.urls.CategoryURLGenerator var16 = var10.getBaseURLGenerator();
    java.lang.Boolean var18 = var10.getSeriesItemLabelsVisible((-855310));
    java.awt.Color var21 = java.awt.Color.getColor("", (-1));
    var10.setBasePaint((java.awt.Paint)var21, true);
    java.awt.Stroke var24 = null;
    org.jfree.chart.LegendItemSource var25 = null;
    org.jfree.chart.title.LegendTitle var26 = new org.jfree.chart.title.LegendTitle(var25);
    org.jfree.chart.util.RectangleEdge var27 = var26.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var28 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var29 = var28.getNextOutlinePaint();
    var26.setBackgroundPaint(var29);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var31 = new org.jfree.chart.LegendItem("RectangleAnchor.CENTER", "hi!", "", "NOID", var9, (java.awt.Paint)var21, var24, var29);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test189() {}
//   public void test189() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, (java.lang.Comparable)(byte)10);
// 
//   }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = var0.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.CategoryItemLabelGenerator var3 = null;
    var0.setBaseItemLabelGenerator(var3);
    org.jfree.chart.plot.DefaultDrawingSupplier var5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var6 = var5.getNextOutlinePaint();
    var0.setErrorIndicatorPaint(var6);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var9 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var11 = var9.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var14 = var9.getPositiveItemLabelPosition(100, 0);
    org.jfree.chart.urls.CategoryURLGenerator var15 = var9.getBaseURLGenerator();
    java.lang.Boolean var17 = var9.getSeriesItemLabelsVisible((-855310));
    org.jfree.data.category.CategoryDataset var18 = null;
    org.jfree.chart.axis.CategoryAxis var19 = null;
    org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var21 = null;
    var20.setPlot(var21);
    org.jfree.chart.renderer.category.CategoryItemRenderer var23 = null;
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot(var18, var19, (org.jfree.chart.axis.ValueAxis)var20, var23);
    java.awt.Stroke var25 = var20.getTickMarkStroke();
    var9.setBaseOutlineStroke(var25);
    org.jfree.chart.labels.ItemLabelPosition var27 = var9.getBaseNegativeItemLabelPosition();
    org.jfree.chart.block.BlockResult var28 = new org.jfree.chart.block.BlockResult();
    org.jfree.chart.entity.EntityCollection var29 = var28.getEntityCollection();
    boolean var30 = var27.equals((java.lang.Object)var28);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesPositiveItemLabelPosition((-855310), var27);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);

  }

  public void test191() {}
//   public void test191() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }
// 
// 
//     org.jfree.chart.LegendItemSource var0 = null;
//     org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
//     org.jfree.chart.util.RectangleEdge var2 = var1.getLegendItemGraphicEdge();
//     org.jfree.chart.event.TitleChangeListener var3 = null;
//     var1.addChangeListener(var3);
//     java.awt.Graphics2D var5 = null;
//     org.jfree.chart.block.RectangleConstraint var8 = new org.jfree.chart.block.RectangleConstraint(0.0d, 0.0d);
//     org.jfree.chart.block.RectangleConstraint var9 = var8.toUnconstrainedWidth();
//     double var10 = var8.getHeight();
//     org.jfree.chart.block.LengthConstraintType var11 = var8.getWidthConstraintType();
//     org.jfree.chart.util.Size2D var12 = var1.arrange(var5, var8);
// 
//   }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var1 = null;
    var0.setPlot(var1);
    var0.setLowerBound(2.0d);
    org.jfree.data.category.CategoryDataset var5 = null;
    org.jfree.chart.axis.CategoryAxis var6 = null;
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var8 = null;
    var7.setPlot(var8);
    org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot(var5, var6, (org.jfree.chart.axis.ValueAxis)var7, var10);
    java.awt.Stroke var12 = var7.getTickMarkStroke();
    var7.setVerticalTickLabels(false);
    org.jfree.data.category.CategoryDataset var15 = null;
    org.jfree.chart.axis.CategoryAxis var16 = null;
    org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var18 = null;
    var17.setPlot(var18);
    org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
    org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var15, var16, (org.jfree.chart.axis.ValueAxis)var17, var20);
    var21.setAnchorValue(0.0d, true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var25 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var27 = null;
    var25.setSeriesItemLabelsVisible(0, var27, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var25.setSeriesToolTipGenerator(1, var31, false);
    org.jfree.chart.urls.CategoryURLGenerator var34 = null;
    var25.setBaseURLGenerator(var34);
    java.awt.Graphics2D var36 = null;
    org.jfree.chart.plot.CategoryPlot var37 = null;
    org.jfree.chart.axis.ValueAxis var38 = null;
    org.jfree.chart.plot.Marker var39 = null;
    java.awt.geom.Rectangle2D var40 = null;
    var25.drawRangeMarker(var36, var37, var38, var39, var40);
    boolean var43 = var25.isSeriesVisibleInLegend(0);
    var21.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var25);
    var7.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var21);
    var0.addChangeListener((org.jfree.chart.event.AxisChangeListener)var21);
    java.text.NumberFormat var47 = null;
    var0.setNumberFormatOverride(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }


    java.text.AttributedString var0 = null;
    java.awt.Color var6 = java.awt.Color.getColor("", (-1));
    java.awt.image.ColorModel var7 = null;
    java.awt.Rectangle var8 = null;
    org.jfree.chart.LegendItemSource var9 = null;
    org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle(var9);
    org.jfree.chart.util.RectangleInsets var11 = var10.getItemLabelPadding();
    org.jfree.chart.LegendItemSource var12 = null;
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle(var12);
    org.jfree.chart.util.RectangleInsets var14 = var13.getItemLabelPadding();
    double var15 = var14.getTop();
    var10.setPadding(var14);
    org.jfree.chart.util.Size2D var17 = new org.jfree.chart.util.Size2D();
    boolean var19 = var17.equals((java.lang.Object)(-1L));
    double var20 = var17.getWidth();
    double var21 = var17.getHeight();
    org.jfree.chart.util.RectangleAnchor var24 = null;
    java.awt.geom.Rectangle2D var25 = org.jfree.chart.util.RectangleAnchor.createRectangle(var17, 2.0d, (-1.0d), var24);
    org.jfree.chart.axis.CategoryLabelPositions var28 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var29 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var30 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var28, var29);
    org.jfree.chart.util.RectangleAnchor var31 = var29.getCategoryAnchor();
    java.awt.geom.Rectangle2D var32 = org.jfree.chart.util.RectangleAnchor.createRectangle(var17, 2.0d, 1.0d, var31);
    java.awt.geom.Rectangle2D var33 = var14.createOutsetRectangle(var32);
    java.awt.geom.AffineTransform var34 = null;
    java.awt.RenderingHints var35 = null;
    java.awt.PaintContext var36 = var6.createContext(var7, var8, var33, var34, var35);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var37 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var38 = null;
    var37.setBaseURLGenerator(var38);
    org.jfree.data.category.CategoryDataset var41 = null;
    org.jfree.chart.axis.CategoryAxis var42 = null;
    org.jfree.chart.axis.NumberAxis var43 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var44 = null;
    var43.setPlot(var44);
    org.jfree.chart.renderer.category.CategoryItemRenderer var46 = null;
    org.jfree.chart.plot.CategoryPlot var47 = new org.jfree.chart.plot.CategoryPlot(var41, var42, (org.jfree.chart.axis.ValueAxis)var43, var46);
    org.jfree.chart.LegendItemSource var48 = null;
    org.jfree.chart.title.LegendTitle var49 = new org.jfree.chart.title.LegendTitle(var48);
    org.jfree.chart.util.RectangleEdge var50 = var49.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var51 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var52 = var51.getNextOutlinePaint();
    var49.setBackgroundPaint(var52);
    var47.setOutlinePaint(var52);
    var37.setSeriesPaint(1, var52, false);
    java.awt.Stroke var57 = null;
    org.jfree.data.category.CategoryDataset var58 = null;
    org.jfree.chart.axis.CategoryAxis var59 = null;
    org.jfree.chart.axis.NumberAxis var60 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var61 = null;
    var60.setPlot(var61);
    org.jfree.chart.renderer.category.CategoryItemRenderer var63 = null;
    org.jfree.chart.plot.CategoryPlot var64 = new org.jfree.chart.plot.CategoryPlot(var58, var59, (org.jfree.chart.axis.ValueAxis)var60, var63);
    var64.setAnchorValue(0.0d, true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var68 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var70 = null;
    var68.setSeriesItemLabelsVisible(0, var70, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var74 = null;
    var68.setSeriesToolTipGenerator(1, var74, false);
    org.jfree.chart.urls.CategoryURLGenerator var77 = null;
    var68.setBaseURLGenerator(var77);
    java.awt.Graphics2D var79 = null;
    org.jfree.chart.plot.CategoryPlot var80 = null;
    org.jfree.chart.axis.ValueAxis var81 = null;
    org.jfree.chart.plot.Marker var82 = null;
    java.awt.geom.Rectangle2D var83 = null;
    var68.drawRangeMarker(var79, var80, var81, var82, var83);
    boolean var86 = var68.isSeriesVisibleInLegend(0);
    var64.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var68);
    org.jfree.chart.axis.CategoryAxis var88 = null;
    java.util.List var89 = var64.getCategoriesForAxis(var88);
    java.awt.Paint var90 = var64.getNoDataMessagePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var91 = new org.jfree.chart.LegendItem(var0, "HorizontalAlignment.CENTER", "HorizontalAlignment.CENTER", "hi!", (java.awt.Shape)var33, var52, var57, var90);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);

  }

  public void test194() {}
//   public void test194() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var3 = null;
//     var2.setPlot(var3);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
//     java.util.List var7 = var6.getAnnotations();
//     org.jfree.chart.plot.PlotRenderingInfo var10 = null;
//     var6.handleClick((-1), 1, var10);
// 
//   }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, 0.0d, 0.95f, 100.0f);

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.95f);
    org.jfree.chart.plot.DefaultDrawingSupplier var6 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    boolean var8 = var6.equals((java.lang.Object)(short)10);
    java.awt.Paint var9 = var6.getNextFillPaint();
    java.awt.Paint var10 = var6.getNextPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var11 = new org.jfree.chart.LegendItem(var0, "NOID", "", "", var5, var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test197() {}
//   public void test197() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextBlock var5 = new org.jfree.chart.text.TextBlock();
//     java.util.List var6 = var5.getLines();
//     org.jfree.chart.text.TextLine var7 = null;
//     var5.addLine(var7);
//     org.jfree.chart.util.HorizontalAlignment var9 = var5.getLineAlignment();
//     org.jfree.chart.text.TextBlockAnchor var10 = null;
//     java.awt.Graphics2D var12 = null;
//     org.jfree.chart.labels.ItemLabelPosition var15 = new org.jfree.chart.labels.ItemLabelPosition();
//     org.jfree.chart.LegendItemSource var16 = null;
//     org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle(var16);
//     org.jfree.chart.util.RectangleEdge var18 = var17.getLegendItemGraphicEdge();
//     org.jfree.chart.util.RectangleEdge var19 = org.jfree.chart.util.RectangleEdge.opposite(var18);
//     boolean var20 = var15.equals((java.lang.Object)var19);
//     org.jfree.chart.labels.ItemLabelAnchor var21 = var15.getItemLabelAnchor();
//     org.jfree.chart.axis.CategoryLabelPositions var22 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var23 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var24 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var22, var23);
//     org.jfree.chart.text.TextAnchor var25 = var23.getRotationAnchor();
//     org.jfree.chart.labels.ItemLabelPosition var26 = new org.jfree.chart.labels.ItemLabelPosition(var21, var25);
//     org.jfree.chart.text.TextUtilities.drawRotatedString("", var12, 1.0f, (-1.0f), var25, 2.0d, 1.0f, 0.0f);
//     org.jfree.chart.axis.CategoryTick var32 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)(byte)0, var5, var10, var25, 0.0d);
//     org.jfree.chart.text.TextBlock var35 = new org.jfree.chart.text.TextBlock();
//     java.util.List var36 = var35.getLines();
//     org.jfree.chart.text.TextLine var37 = null;
//     var35.addLine(var37);
//     org.jfree.chart.util.HorizontalAlignment var39 = var35.getLineAlignment();
//     org.jfree.chart.text.TextBlockAnchor var40 = null;
//     java.awt.Graphics2D var42 = null;
//     org.jfree.chart.labels.ItemLabelPosition var45 = new org.jfree.chart.labels.ItemLabelPosition();
//     org.jfree.chart.LegendItemSource var46 = null;
//     org.jfree.chart.title.LegendTitle var47 = new org.jfree.chart.title.LegendTitle(var46);
//     org.jfree.chart.util.RectangleEdge var48 = var47.getLegendItemGraphicEdge();
//     org.jfree.chart.util.RectangleEdge var49 = org.jfree.chart.util.RectangleEdge.opposite(var48);
//     boolean var50 = var45.equals((java.lang.Object)var49);
//     org.jfree.chart.labels.ItemLabelAnchor var51 = var45.getItemLabelAnchor();
//     org.jfree.chart.axis.CategoryLabelPositions var52 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var53 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var54 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var52, var53);
//     org.jfree.chart.text.TextAnchor var55 = var53.getRotationAnchor();
//     org.jfree.chart.labels.ItemLabelPosition var56 = new org.jfree.chart.labels.ItemLabelPosition(var51, var55);
//     org.jfree.chart.text.TextUtilities.drawRotatedString("", var42, 1.0f, (-1.0f), var55, 2.0d, 1.0f, 0.0f);
//     org.jfree.chart.axis.CategoryTick var62 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)(byte)0, var35, var40, var55, 0.0d);
//     java.awt.Shape var63 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("Range[-1.0,-1.0]", var1, 0.95f, 0.5f, var25, Double.NaN, var55);
// 
//   }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }


    org.jfree.chart.axis.CategoryLabelPositions var0 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var1 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var2 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var0, var1);
    org.jfree.chart.axis.CategoryLabelPositions var3 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var4 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var5 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var3, var4);
    org.jfree.chart.axis.CategoryLabelPositions var6 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var7 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var8 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var6, var7);
    org.jfree.chart.axis.CategoryLabelPositions var9 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(var3, var7);
    org.jfree.chart.axis.CategoryLabelPositions var10 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(var2, var7);
    org.jfree.chart.axis.CategoryLabelWidthType var11 = var7.getWidthType();
    float var12 = var7.getWidthRatio();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.95f);

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.util.RectangleInsets var1 = var0.getPadding();
    double var2 = var0.getWidth();
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.block.RectangleConstraint var6 = new org.jfree.chart.block.RectangleConstraint(0.0d, 0.0d);
    org.jfree.chart.block.RectangleConstraint var7 = var6.toUnconstrainedWidth();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var8 = var0.arrange(var3, var7);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var4 = null;
    var3.setPlot(var4);
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var3, var6);
    org.jfree.chart.LegendItemSource var8 = null;
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
    org.jfree.chart.util.RectangleEdge var10 = var9.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var12 = var11.getNextOutlinePaint();
    var9.setBackgroundPaint(var12);
    var7.setOutlinePaint(var12);
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var7);
    var15.fireChartChanged();
    var15.setTextAntiAlias(false);
    java.util.List var19 = var15.getSubtitles();
    org.jfree.chart.util.RectangleInsets var20 = var15.getPadding();
    org.jfree.chart.plot.CategoryPlot var21 = var15.getCategoryPlot();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var24 = var15.createBufferedImage((-855310), 100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var4 = null;
    var3.setPlot(var4);
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var3, var6);
    org.jfree.chart.LegendItemSource var8 = null;
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
    org.jfree.chart.util.RectangleEdge var10 = var9.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var12 = var11.getNextOutlinePaint();
    var9.setBackgroundPaint(var12);
    var7.setOutlinePaint(var12);
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var7);
    org.jfree.chart.util.RectangleInsets var16 = var7.getAxisOffset();
    org.jfree.chart.axis.CategoryAxis var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.setDomainAxis((-855310), var18, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("AxisLocation.TOP_OR_RIGHT", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var4 = null;
    var3.setPlot(var4);
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var3, var6);
    org.jfree.chart.LegendItemSource var8 = null;
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
    org.jfree.chart.util.RectangleEdge var10 = var9.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var12 = var11.getNextOutlinePaint();
    var9.setBackgroundPaint(var12);
    var7.setOutlinePaint(var12);
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var7);
    var15.fireChartChanged();
    boolean var17 = var15.getAntiAlias();
    java.awt.Image var18 = var15.getBackgroundImage();
    org.jfree.chart.event.ChartChangeListener var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var15.addChangeListener(var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var1 = null;
    var0.setPlot(var1);
    var0.setLowerBound(2.0d);
    java.lang.String var5 = var0.getLabelToolTip();
    org.jfree.chart.axis.NumberTickUnit var6 = var0.getTickUnit();
    org.jfree.data.KeyedValues var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.CategoryDataset var8 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable)var6, var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.util.RectangleInsets var2 = var1.getItemLabelPadding();
    double var4 = var2.calculateTopOutset(4.0d);
    java.awt.Color var7 = java.awt.Color.getColor("", (-1));
    java.awt.image.ColorModel var8 = null;
    java.awt.Rectangle var9 = null;
    org.jfree.chart.LegendItemSource var10 = null;
    org.jfree.chart.title.LegendTitle var11 = new org.jfree.chart.title.LegendTitle(var10);
    org.jfree.chart.util.RectangleInsets var12 = var11.getItemLabelPadding();
    org.jfree.chart.LegendItemSource var13 = null;
    org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle(var13);
    org.jfree.chart.util.RectangleInsets var15 = var14.getItemLabelPadding();
    double var16 = var15.getTop();
    var11.setPadding(var15);
    org.jfree.chart.util.Size2D var18 = new org.jfree.chart.util.Size2D();
    boolean var20 = var18.equals((java.lang.Object)(-1L));
    double var21 = var18.getWidth();
    double var22 = var18.getHeight();
    org.jfree.chart.util.RectangleAnchor var25 = null;
    java.awt.geom.Rectangle2D var26 = org.jfree.chart.util.RectangleAnchor.createRectangle(var18, 2.0d, (-1.0d), var25);
    org.jfree.chart.axis.CategoryLabelPositions var29 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var30 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var31 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var29, var30);
    org.jfree.chart.util.RectangleAnchor var32 = var30.getCategoryAnchor();
    java.awt.geom.Rectangle2D var33 = org.jfree.chart.util.RectangleAnchor.createRectangle(var18, 2.0d, 1.0d, var32);
    java.awt.geom.Rectangle2D var34 = var15.createOutsetRectangle(var33);
    java.awt.geom.AffineTransform var35 = null;
    java.awt.RenderingHints var36 = null;
    java.awt.PaintContext var37 = var7.createContext(var8, var9, var34, var35, var36);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var40 = var2.createOutsetRectangle((java.awt.geom.Rectangle2D)var9, false, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("NOID");

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }


    java.awt.Graphics2D var1 = null;
    java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", var1, 0.0f, 0.5f, 1.0d, 10.0f, (-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }


    java.util.ResourceBundle.clearCache();

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    org.jfree.chart.LegendItemSource var7 = null;
    org.jfree.chart.title.LegendTitle var8 = new org.jfree.chart.title.LegendTitle(var7);
    org.jfree.chart.util.RectangleEdge var9 = var8.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var10 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var11 = var10.getNextOutlinePaint();
    var8.setBackgroundPaint(var11);
    var6.setOutlinePaint(var11);
    org.jfree.data.category.CategoryDataset var14 = null;
    org.jfree.chart.axis.CategoryAxis var15 = null;
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var17 = null;
    var16.setPlot(var17);
    org.jfree.chart.renderer.category.CategoryItemRenderer var19 = null;
    org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot(var14, var15, (org.jfree.chart.axis.ValueAxis)var16, var19);
    org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var22 = null;
    var21.setPlot(var22);
    org.jfree.chart.axis.ValueAxis[] var24 = new org.jfree.chart.axis.ValueAxis[] { var21};
    var20.setRangeAxes(var24);
    var6.setParent((org.jfree.chart.plot.Plot)var20);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var20.mapDatasetToRangeAxis((-855310), (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    boolean var1 = var0.isNegativeArrowVisible();
    java.lang.String var2 = var0.getLabelURL();
    var0.setLabelAngle(6.0d);
    var0.setAutoRange(false);
    java.lang.Object var7 = var0.clone();
    org.jfree.chart.util.RectangleInsets var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setLabelInsets(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test212() {}
//   public void test212() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.Graphics2D var5 = null;
//     org.jfree.chart.axis.CategoryLabelPositions var8 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var9 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var10 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var8, var9);
//     org.jfree.chart.text.TextAnchor var11 = var9.getRotationAnchor();
//     org.jfree.chart.labels.ItemLabelPosition var13 = new org.jfree.chart.labels.ItemLabelPosition();
//     org.jfree.chart.LegendItemSource var14 = null;
//     org.jfree.chart.title.LegendTitle var15 = new org.jfree.chart.title.LegendTitle(var14);
//     org.jfree.chart.util.RectangleEdge var16 = var15.getLegendItemGraphicEdge();
//     org.jfree.chart.util.RectangleEdge var17 = org.jfree.chart.util.RectangleEdge.opposite(var16);
//     boolean var18 = var13.equals((java.lang.Object)var17);
//     org.jfree.chart.labels.ItemLabelAnchor var19 = var13.getItemLabelAnchor();
//     org.jfree.chart.axis.CategoryLabelPositions var20 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var21 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var22 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var20, var21);
//     org.jfree.chart.text.TextAnchor var23 = var21.getRotationAnchor();
//     org.jfree.chart.labels.ItemLabelPosition var24 = new org.jfree.chart.labels.ItemLabelPosition(var19, var23);
//     org.jfree.chart.text.TextUtilities.drawRotatedString("", var5, 100.0f, 0.0f, var11, 100.0d, var23);
//     java.awt.Graphics2D var28 = null;
//     org.jfree.chart.labels.ItemLabelPosition var31 = new org.jfree.chart.labels.ItemLabelPosition();
//     org.jfree.chart.LegendItemSource var32 = null;
//     org.jfree.chart.title.LegendTitle var33 = new org.jfree.chart.title.LegendTitle(var32);
//     org.jfree.chart.util.RectangleEdge var34 = var33.getLegendItemGraphicEdge();
//     org.jfree.chart.util.RectangleEdge var35 = org.jfree.chart.util.RectangleEdge.opposite(var34);
//     boolean var36 = var31.equals((java.lang.Object)var35);
//     org.jfree.chart.labels.ItemLabelAnchor var37 = var31.getItemLabelAnchor();
//     org.jfree.chart.axis.CategoryLabelPositions var38 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var39 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var40 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var38, var39);
//     org.jfree.chart.text.TextAnchor var41 = var39.getRotationAnchor();
//     org.jfree.chart.labels.ItemLabelPosition var42 = new org.jfree.chart.labels.ItemLabelPosition(var37, var41);
//     org.jfree.chart.text.TextUtilities.drawRotatedString("", var28, 1.0f, (-1.0f), var41, 2.0d, 1.0f, 0.0f);
//     java.awt.Shape var47 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("CategoryLabelWidthType.CATEGORY", var1, 1.0f, 0.95f, var23, (-1.0d), var41);
// 
//   }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }


    org.jfree.chart.util.RectangleAnchor var0 = null;
    org.jfree.chart.axis.CategoryLabelPositions var1 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var2 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var3 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var1, var2);
    float var4 = var2.getWidthRatio();
    org.jfree.chart.text.TextBlockAnchor var5 = var2.getLabelAnchor();
    org.jfree.chart.labels.ItemLabelPosition var6 = new org.jfree.chart.labels.ItemLabelPosition();
    org.jfree.chart.LegendItemSource var7 = null;
    org.jfree.chart.title.LegendTitle var8 = new org.jfree.chart.title.LegendTitle(var7);
    org.jfree.chart.util.RectangleEdge var9 = var8.getLegendItemGraphicEdge();
    org.jfree.chart.util.RectangleEdge var10 = org.jfree.chart.util.RectangleEdge.opposite(var9);
    boolean var11 = var6.equals((java.lang.Object)var10);
    org.jfree.chart.labels.ItemLabelAnchor var12 = var6.getItemLabelAnchor();
    org.jfree.chart.axis.CategoryLabelPositions var13 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var14 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var15 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var13, var14);
    org.jfree.chart.text.TextAnchor var16 = var14.getRotationAnchor();
    org.jfree.chart.labels.ItemLabelPosition var17 = new org.jfree.chart.labels.ItemLabelPosition(var12, var16);
    org.jfree.chart.axis.CategoryLabelPositions var19 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var20 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var21 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var19, var20);
    org.jfree.chart.axis.CategoryLabelPositions var22 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var23 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var24 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var22, var23);
    org.jfree.chart.axis.CategoryLabelPositions var25 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var26 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var27 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var25, var26);
    org.jfree.chart.axis.CategoryLabelPositions var28 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(var22, var26);
    org.jfree.chart.axis.CategoryLabelPositions var29 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(var21, var26);
    org.jfree.chart.axis.CategoryLabelWidthType var30 = var26.getWidthType();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var32 = new org.jfree.chart.axis.CategoryLabelPosition(var0, var5, var16, (-8.0d), var30, 2.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.95f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }


    org.jfree.chart.block.BlockBorder var0 = new org.jfree.chart.block.BlockBorder();

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var8 = null;
    var7.setPlot(var8);
    org.jfree.chart.axis.ValueAxis[] var10 = new org.jfree.chart.axis.ValueAxis[] { var7};
    var6.setRangeAxes(var10);
    org.jfree.chart.plot.Plot var12 = var6.getParent();
    org.jfree.chart.plot.DatasetRenderingOrder var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setDatasetRenderingOrder(var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);

  }

  public void test216() {}
//   public void test216() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }
// 
// 
//     org.jfree.chart.block.CenterArrangement var0 = new org.jfree.chart.block.CenterArrangement();
//     org.jfree.chart.block.BlockContainer var1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var0);
//     org.jfree.chart.block.CenterArrangement var2 = new org.jfree.chart.block.CenterArrangement();
//     org.jfree.chart.block.BlockContainer var3 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var2);
//     java.lang.Object var4 = null;
//     var0.add((org.jfree.chart.block.Block)var3, var4);
//     
//     // Checks the contract:  equals-hashcode on var0 and var2
//     assertTrue("Contract failed: equals-hashcode on var0 and var2", var0.equals(var2) ? var0.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var0
//     assertTrue("Contract failed: equals-hashcode on var2 and var0", var2.equals(var0) ? var2.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var1 and var3
//     assertTrue("Contract failed: equals-hashcode on var1 and var3", var1.equals(var3) ? var1.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var1
//     assertTrue("Contract failed: equals-hashcode on var3 and var1", var3.equals(var1) ? var3.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = null;
    var0.setSeriesItemLabelsVisible(0, var2, false);
    java.awt.Stroke var5 = var0.getErrorIndicatorStroke();
    org.jfree.chart.plot.DrawingSupplier var6 = var0.getDrawingSupplier();
    java.lang.Boolean var8 = var0.getSeriesCreateEntities(10);
    java.awt.Paint var10 = var0.getSeriesItemLabelPaint((-855310));
    org.jfree.chart.labels.ItemLabelPosition var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBasePositiveItemLabelPosition(var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    boolean var1 = var0.isNegativeArrowVisible();
    java.lang.String var2 = var0.getLabelURL();
    var0.setLabelAngle(6.0d);
    var0.setAutoRangeMinimumSize(0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test219() {}
//   public void test219() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }
// 
// 
//     org.jfree.chart.text.TextBlock var1 = new org.jfree.chart.text.TextBlock();
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.util.Size2D var3 = var1.calculateDimensions(var2);
//     org.jfree.data.category.CategoryDataset var5 = null;
//     org.jfree.chart.axis.CategoryAxis var6 = null;
//     org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var8 = null;
//     var7.setPlot(var8);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot(var5, var6, (org.jfree.chart.axis.ValueAxis)var7, var10);
//     java.awt.Stroke var12 = var7.getTickMarkStroke();
//     java.awt.Font var13 = var7.getLabelFont();
//     java.awt.Color var16 = java.awt.Color.getColor("", (-1));
//     var1.addLine("CategoryLabelEntity: category=null, tooltip=hi!, url=", var13, (java.awt.Paint)var16);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var18 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var20 = var18.getSeriesItemLabelsVisible(100);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var21 = null;
//     var18.setBaseItemLabelGenerator(var21);
//     java.awt.Paint var25 = var18.getItemFillPaint(0, (-855310));
//     org.jfree.chart.text.TextFragment var27 = new org.jfree.chart.text.TextFragment("NOID", var13, var25, 2.0f);
//     java.awt.Graphics2D var28 = null;
//     org.jfree.chart.text.TextBlock var30 = new org.jfree.chart.text.TextBlock();
//     java.util.List var31 = var30.getLines();
//     org.jfree.chart.text.TextLine var32 = null;
//     var30.addLine(var32);
//     org.jfree.chart.util.HorizontalAlignment var34 = var30.getLineAlignment();
//     org.jfree.chart.text.TextBlockAnchor var35 = null;
//     java.awt.Graphics2D var37 = null;
//     org.jfree.chart.labels.ItemLabelPosition var40 = new org.jfree.chart.labels.ItemLabelPosition();
//     org.jfree.chart.LegendItemSource var41 = null;
//     org.jfree.chart.title.LegendTitle var42 = new org.jfree.chart.title.LegendTitle(var41);
//     org.jfree.chart.util.RectangleEdge var43 = var42.getLegendItemGraphicEdge();
//     org.jfree.chart.util.RectangleEdge var44 = org.jfree.chart.util.RectangleEdge.opposite(var43);
//     boolean var45 = var40.equals((java.lang.Object)var44);
//     org.jfree.chart.labels.ItemLabelAnchor var46 = var40.getItemLabelAnchor();
//     org.jfree.chart.axis.CategoryLabelPositions var47 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var48 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var49 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var47, var48);
//     org.jfree.chart.text.TextAnchor var50 = var48.getRotationAnchor();
//     org.jfree.chart.labels.ItemLabelPosition var51 = new org.jfree.chart.labels.ItemLabelPosition(var46, var50);
//     org.jfree.chart.text.TextUtilities.drawRotatedString("", var37, 1.0f, (-1.0f), var50, 2.0d, 1.0f, 0.0f);
//     org.jfree.chart.axis.CategoryTick var57 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)(byte)0, var30, var35, var50, 0.0d);
//     float var58 = var27.calculateBaselineOffset(var28, var50);
// 
//   }

  public void test220() {}
//   public void test220() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }
// 
// 
//     org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("");
//     java.awt.Graphics2D var2 = null;
//     java.awt.Graphics2D var6 = null;
//     org.jfree.chart.axis.CategoryLabelPositions var9 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var10 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var11 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var9, var10);
//     org.jfree.chart.text.TextAnchor var12 = var10.getRotationAnchor();
//     org.jfree.chart.labels.ItemLabelPosition var14 = new org.jfree.chart.labels.ItemLabelPosition();
//     org.jfree.chart.LegendItemSource var15 = null;
//     org.jfree.chart.title.LegendTitle var16 = new org.jfree.chart.title.LegendTitle(var15);
//     org.jfree.chart.util.RectangleEdge var17 = var16.getLegendItemGraphicEdge();
//     org.jfree.chart.util.RectangleEdge var18 = org.jfree.chart.util.RectangleEdge.opposite(var17);
//     boolean var19 = var14.equals((java.lang.Object)var18);
//     org.jfree.chart.labels.ItemLabelAnchor var20 = var14.getItemLabelAnchor();
//     org.jfree.chart.axis.CategoryLabelPositions var21 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var22 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var23 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var21, var22);
//     org.jfree.chart.text.TextAnchor var24 = var22.getRotationAnchor();
//     org.jfree.chart.labels.ItemLabelPosition var25 = new org.jfree.chart.labels.ItemLabelPosition(var20, var24);
//     org.jfree.chart.text.TextUtilities.drawRotatedString("", var6, 100.0f, 0.0f, var12, 100.0d, var24);
//     var1.draw(var2, 0.95f, 2.0f, var12, 10.0f, 0.0f, 0.0d);
// 
//   }

  public void test221() {}
//   public void test221() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }
// 
// 
//     org.jfree.chart.LegendItemSource var0 = null;
//     org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
//     org.jfree.chart.util.RectangleInsets var2 = var1.getItemLabelPadding();
//     org.jfree.chart.LegendItemSource var3 = null;
//     org.jfree.chart.title.LegendTitle var4 = new org.jfree.chart.title.LegendTitle(var3);
//     org.jfree.chart.util.RectangleInsets var5 = var4.getItemLabelPadding();
//     double var6 = var5.getTop();
//     var1.setPadding(var5);
//     org.jfree.chart.util.Size2D var8 = new org.jfree.chart.util.Size2D();
//     boolean var10 = var8.equals((java.lang.Object)(-1L));
//     double var11 = var8.getWidth();
//     double var12 = var8.getHeight();
//     org.jfree.chart.util.RectangleAnchor var15 = null;
//     java.awt.geom.Rectangle2D var16 = org.jfree.chart.util.RectangleAnchor.createRectangle(var8, 2.0d, (-1.0d), var15);
//     org.jfree.chart.axis.CategoryLabelPositions var19 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var20 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var21 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var19, var20);
//     org.jfree.chart.util.RectangleAnchor var22 = var20.getCategoryAnchor();
//     java.awt.geom.Rectangle2D var23 = org.jfree.chart.util.RectangleAnchor.createRectangle(var8, 2.0d, 1.0d, var22);
//     java.awt.geom.Rectangle2D var24 = var5.createOutsetRectangle(var23);
//     org.jfree.data.category.CategoryDataset var25 = null;
//     org.jfree.chart.axis.CategoryAxis var26 = null;
//     org.jfree.chart.axis.NumberAxis var27 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var28 = null;
//     var27.setPlot(var28);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var30 = null;
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot(var25, var26, (org.jfree.chart.axis.ValueAxis)var27, var30);
//     org.jfree.chart.LegendItemSource var32 = null;
//     org.jfree.chart.title.LegendTitle var33 = new org.jfree.chart.title.LegendTitle(var32);
//     org.jfree.chart.util.RectangleEdge var34 = var33.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var35 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var36 = var35.getNextOutlinePaint();
//     var33.setBackgroundPaint(var36);
//     var31.setOutlinePaint(var36);
//     org.jfree.data.category.CategoryDataset var39 = null;
//     org.jfree.chart.axis.CategoryAxis var40 = null;
//     org.jfree.chart.axis.NumberAxis var41 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var42 = null;
//     var41.setPlot(var42);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var44 = null;
//     org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot(var39, var40, (org.jfree.chart.axis.ValueAxis)var41, var44);
//     org.jfree.chart.axis.NumberAxis var46 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var47 = null;
//     var46.setPlot(var47);
//     org.jfree.chart.axis.ValueAxis[] var49 = new org.jfree.chart.axis.ValueAxis[] { var46};
//     var45.setRangeAxes(var49);
//     var31.setParent((org.jfree.chart.plot.Plot)var45);
//     java.awt.Stroke var52 = var45.getRangeCrosshairStroke();
//     java.awt.Graphics2D var53 = null;
//     org.jfree.chart.LegendItemSource var54 = null;
//     org.jfree.chart.title.LegendTitle var55 = new org.jfree.chart.title.LegendTitle(var54);
//     org.jfree.chart.util.RectangleInsets var56 = var55.getItemLabelPadding();
//     org.jfree.chart.LegendItemSource var57 = null;
//     org.jfree.chart.title.LegendTitle var58 = new org.jfree.chart.title.LegendTitle(var57);
//     org.jfree.chart.util.RectangleInsets var59 = var58.getItemLabelPadding();
//     double var60 = var59.getTop();
//     var55.setPadding(var59);
//     org.jfree.chart.util.Size2D var62 = new org.jfree.chart.util.Size2D();
//     boolean var64 = var62.equals((java.lang.Object)(-1L));
//     double var65 = var62.getWidth();
//     double var66 = var62.getHeight();
//     org.jfree.chart.util.RectangleAnchor var69 = null;
//     java.awt.geom.Rectangle2D var70 = org.jfree.chart.util.RectangleAnchor.createRectangle(var62, 2.0d, (-1.0d), var69);
//     org.jfree.chart.axis.CategoryLabelPositions var73 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var74 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var75 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var73, var74);
//     org.jfree.chart.util.RectangleAnchor var76 = var74.getCategoryAnchor();
//     java.awt.geom.Rectangle2D var77 = org.jfree.chart.util.RectangleAnchor.createRectangle(var62, 2.0d, 1.0d, var76);
//     java.awt.geom.Rectangle2D var78 = var59.createOutsetRectangle(var77);
//     org.jfree.chart.plot.PlotRenderingInfo var80 = null;
//     boolean var81 = var45.render(var53, var78, 255, var80);
//     var5.trim(var78);
//     
//     // Checks the contract:  equals-hashcode on var8 and var62
//     assertTrue("Contract failed: equals-hashcode on var8 and var62", var8.equals(var62) ? var8.hashCode() == var62.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var62 and var8
//     assertTrue("Contract failed: equals-hashcode on var62 and var8", var62.equals(var8) ? var62.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = var0.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.CategoryItemLabelGenerator var3 = null;
    var0.setBaseItemLabelGenerator(var3);
    org.jfree.chart.plot.DefaultDrawingSupplier var5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var6 = var5.getNextOutlinePaint();
    var0.setErrorIndicatorPaint(var6);
    java.awt.Paint var8 = var0.getErrorIndicatorPaint();
    java.awt.Paint var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBaseItemLabelPaint(var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    boolean var1 = var0.isNegativeArrowVisible();
    java.lang.String var2 = var0.getLabelURL();
    var0.setLabelAngle(6.0d);
    java.awt.Font var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setTickLabelFont(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test224() {}
//   public void test224() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var1 = var0.getPositiveItemLabelPositionFallback();
//     java.awt.Paint var4 = var0.getItemLabelPaint((-123), (-1));
//     org.jfree.data.category.CategoryDataset var5 = null;
//     org.jfree.chart.axis.CategoryAxis var6 = null;
//     org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var8 = null;
//     var7.setPlot(var8);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot(var5, var6, (org.jfree.chart.axis.ValueAxis)var7, var10);
//     java.awt.Stroke var12 = var7.getTickMarkStroke();
//     org.jfree.chart.LegendItemSource var13 = null;
//     org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle(var13);
//     org.jfree.chart.util.RectangleInsets var15 = var14.getItemLabelPadding();
//     double var16 = var15.getTop();
//     org.jfree.chart.block.LineBorder var17 = new org.jfree.chart.block.LineBorder(var4, var12, var15);
//     java.awt.Stroke var18 = var17.getStroke();
//     java.awt.Stroke var19 = var17.getStroke();
//     java.awt.Graphics2D var20 = null;
//     org.jfree.data.category.CategoryDataset var21 = null;
//     org.jfree.chart.axis.CategoryAxis var22 = null;
//     org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var24 = null;
//     var23.setPlot(var24);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var26 = null;
//     org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot(var21, var22, (org.jfree.chart.axis.ValueAxis)var23, var26);
//     org.jfree.chart.LegendItemSource var28 = null;
//     org.jfree.chart.title.LegendTitle var29 = new org.jfree.chart.title.LegendTitle(var28);
//     org.jfree.chart.util.RectangleEdge var30 = var29.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var31 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var32 = var31.getNextOutlinePaint();
//     var29.setBackgroundPaint(var32);
//     var27.setOutlinePaint(var32);
//     org.jfree.data.category.CategoryDataset var35 = null;
//     org.jfree.chart.axis.CategoryAxis var36 = null;
//     org.jfree.chart.axis.NumberAxis var37 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var38 = null;
//     var37.setPlot(var38);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var40 = null;
//     org.jfree.chart.plot.CategoryPlot var41 = new org.jfree.chart.plot.CategoryPlot(var35, var36, (org.jfree.chart.axis.ValueAxis)var37, var40);
//     org.jfree.chart.axis.NumberAxis var42 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var43 = null;
//     var42.setPlot(var43);
//     org.jfree.chart.axis.ValueAxis[] var45 = new org.jfree.chart.axis.ValueAxis[] { var42};
//     var41.setRangeAxes(var45);
//     var27.setParent((org.jfree.chart.plot.Plot)var41);
//     java.awt.Stroke var48 = var41.getRangeCrosshairStroke();
//     java.awt.Graphics2D var49 = null;
//     org.jfree.chart.LegendItemSource var50 = null;
//     org.jfree.chart.title.LegendTitle var51 = new org.jfree.chart.title.LegendTitle(var50);
//     org.jfree.chart.util.RectangleInsets var52 = var51.getItemLabelPadding();
//     org.jfree.chart.LegendItemSource var53 = null;
//     org.jfree.chart.title.LegendTitle var54 = new org.jfree.chart.title.LegendTitle(var53);
//     org.jfree.chart.util.RectangleInsets var55 = var54.getItemLabelPadding();
//     double var56 = var55.getTop();
//     var51.setPadding(var55);
//     org.jfree.chart.util.Size2D var58 = new org.jfree.chart.util.Size2D();
//     boolean var60 = var58.equals((java.lang.Object)(-1L));
//     double var61 = var58.getWidth();
//     double var62 = var58.getHeight();
//     org.jfree.chart.util.RectangleAnchor var65 = null;
//     java.awt.geom.Rectangle2D var66 = org.jfree.chart.util.RectangleAnchor.createRectangle(var58, 2.0d, (-1.0d), var65);
//     org.jfree.chart.axis.CategoryLabelPositions var69 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var70 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var71 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var69, var70);
//     org.jfree.chart.util.RectangleAnchor var72 = var70.getCategoryAnchor();
//     java.awt.geom.Rectangle2D var73 = org.jfree.chart.util.RectangleAnchor.createRectangle(var58, 2.0d, 1.0d, var72);
//     java.awt.geom.Rectangle2D var74 = var55.createOutsetRectangle(var73);
//     org.jfree.chart.plot.PlotRenderingInfo var76 = null;
//     boolean var77 = var41.render(var49, var74, 255, var76);
//     var17.draw(var20, var74);
// 
//   }

  public void test225() {}
//   public void test225() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }
// 
// 
//     org.jfree.chart.text.TextBlock var1 = new org.jfree.chart.text.TextBlock();
//     java.util.List var2 = var1.getLines();
//     org.jfree.chart.text.TextLine var3 = null;
//     var1.addLine(var3);
//     org.jfree.chart.util.HorizontalAlignment var5 = var1.getLineAlignment();
//     org.jfree.chart.text.TextBlockAnchor var6 = null;
//     java.awt.Graphics2D var8 = null;
//     org.jfree.chart.labels.ItemLabelPosition var11 = new org.jfree.chart.labels.ItemLabelPosition();
//     org.jfree.chart.LegendItemSource var12 = null;
//     org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle(var12);
//     org.jfree.chart.util.RectangleEdge var14 = var13.getLegendItemGraphicEdge();
//     org.jfree.chart.util.RectangleEdge var15 = org.jfree.chart.util.RectangleEdge.opposite(var14);
//     boolean var16 = var11.equals((java.lang.Object)var15);
//     org.jfree.chart.labels.ItemLabelAnchor var17 = var11.getItemLabelAnchor();
//     org.jfree.chart.axis.CategoryLabelPositions var18 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var19 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var20 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var18, var19);
//     org.jfree.chart.text.TextAnchor var21 = var19.getRotationAnchor();
//     org.jfree.chart.labels.ItemLabelPosition var22 = new org.jfree.chart.labels.ItemLabelPosition(var17, var21);
//     org.jfree.chart.text.TextUtilities.drawRotatedString("", var8, 1.0f, (-1.0f), var21, 2.0d, 1.0f, 0.0f);
//     org.jfree.chart.axis.CategoryTick var28 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)(byte)0, var1, var6, var21, 0.0d);
//     org.jfree.chart.labels.ItemLabelPosition var29 = new org.jfree.chart.labels.ItemLabelPosition();
//     org.jfree.chart.LegendItemSource var30 = null;
//     org.jfree.chart.title.LegendTitle var31 = new org.jfree.chart.title.LegendTitle(var30);
//     org.jfree.chart.util.RectangleEdge var32 = var31.getLegendItemGraphicEdge();
//     org.jfree.chart.util.RectangleEdge var33 = org.jfree.chart.util.RectangleEdge.opposite(var32);
//     boolean var34 = var29.equals((java.lang.Object)var33);
//     org.jfree.chart.labels.ItemLabelAnchor var35 = var29.getItemLabelAnchor();
//     org.jfree.chart.axis.CategoryLabelPositions var36 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var37 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var38 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var36, var37);
//     org.jfree.chart.text.TextAnchor var39 = var37.getRotationAnchor();
//     org.jfree.chart.labels.ItemLabelPosition var40 = new org.jfree.chart.labels.ItemLabelPosition(var35, var39);
//     boolean var41 = var28.equals((java.lang.Object)var40);
//     
//     // Checks the contract:  equals-hashcode on var11 and var29
//     assertTrue("Contract failed: equals-hashcode on var11 and var29", var11.equals(var29) ? var11.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var40
//     assertTrue("Contract failed: equals-hashcode on var22 and var40", var22.equals(var40) ? var22.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var11
//     assertTrue("Contract failed: equals-hashcode on var29 and var11", var29.equals(var11) ? var29.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var22
//     assertTrue("Contract failed: equals-hashcode on var40 and var22", var40.equals(var22) ? var40.hashCode() == var22.hashCode() : true);
// 
//   }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }


    org.jfree.chart.axis.TickUnitSource var0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test227() {}
//   public void test227() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }
// 
// 
//     org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("");
//     var1.setURLText("");
//     java.awt.Graphics2D var4 = null;
//     org.jfree.data.category.CategoryDataset var5 = null;
//     org.jfree.chart.axis.CategoryAxis var6 = null;
//     org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var8 = null;
//     var7.setPlot(var8);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot(var5, var6, (org.jfree.chart.axis.ValueAxis)var7, var10);
//     var11.setAnchorValue(0.0d, true);
//     org.jfree.chart.axis.CategoryAxis var15 = var11.getDomainAxis();
//     java.awt.Graphics2D var16 = null;
//     org.jfree.chart.LegendItemSource var17 = null;
//     org.jfree.chart.title.LegendTitle var18 = new org.jfree.chart.title.LegendTitle(var17);
//     org.jfree.chart.util.RectangleInsets var19 = var18.getItemLabelPadding();
//     org.jfree.chart.LegendItemSource var20 = null;
//     org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle(var20);
//     org.jfree.chart.util.RectangleInsets var22 = var21.getItemLabelPadding();
//     double var23 = var22.getTop();
//     var18.setPadding(var22);
//     org.jfree.chart.util.Size2D var25 = new org.jfree.chart.util.Size2D();
//     boolean var27 = var25.equals((java.lang.Object)(-1L));
//     double var28 = var25.getWidth();
//     double var29 = var25.getHeight();
//     org.jfree.chart.util.RectangleAnchor var32 = null;
//     java.awt.geom.Rectangle2D var33 = org.jfree.chart.util.RectangleAnchor.createRectangle(var25, 2.0d, (-1.0d), var32);
//     org.jfree.chart.axis.CategoryLabelPositions var36 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var37 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var38 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var36, var37);
//     org.jfree.chart.util.RectangleAnchor var39 = var37.getCategoryAnchor();
//     java.awt.geom.Rectangle2D var40 = org.jfree.chart.util.RectangleAnchor.createRectangle(var25, 2.0d, 1.0d, var39);
//     java.awt.geom.Rectangle2D var41 = var22.createOutsetRectangle(var40);
//     java.awt.geom.Point2D var42 = null;
//     org.jfree.chart.plot.PlotState var43 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var44 = null;
//     var11.draw(var16, var41, var42, var43, var44);
//     org.jfree.chart.entity.TickLabelEntity var48 = new org.jfree.chart.entity.TickLabelEntity((java.awt.Shape)var41, "hi!", "CategoryLabelEntity: category=null, tooltip=hi!, url=");
//     var1.draw(var4, var41);
// 
//   }

  public void test228() {}
//   public void test228() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("HorizontalAlignment.CENTER", var1);
// 
//   }

  public void test229() {}
//   public void test229() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }
// 
// 
//     org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.util.RectangleInsets var1 = var0.getPadding();
//     org.jfree.chart.util.HorizontalAlignment var2 = null;
//     org.jfree.chart.util.VerticalAlignment var3 = null;
//     org.jfree.chart.block.FlowArrangement var6 = new org.jfree.chart.block.FlowArrangement(var2, var3, 0.0d, 0.0d);
//     var0.setArrangement((org.jfree.chart.block.Arrangement)var6);
//     org.jfree.chart.block.BlockContainer var8 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var6);
//     
//     // Checks the contract:  equals-hashcode on var0 and var8
//     assertTrue("Contract failed: equals-hashcode on var0 and var8", var0.equals(var8) ? var0.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var0
//     assertTrue("Contract failed: equals-hashcode on var8 and var0", var8.equals(var0) ? var8.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }


    java.lang.Object var0 = null;
    org.jfree.data.category.CategoryDataset var2 = null;
    org.jfree.chart.axis.CategoryAxis var3 = null;
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var5 = null;
    var4.setPlot(var5);
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var2, var3, (org.jfree.chart.axis.ValueAxis)var4, var7);
    org.jfree.chart.LegendItemSource var9 = null;
    org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle(var9);
    org.jfree.chart.util.RectangleEdge var11 = var10.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var12 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var13 = var12.getNextOutlinePaint();
    var10.setBackgroundPaint(var13);
    var8.setOutlinePaint(var13);
    org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var8);
    var16.fireChartChanged();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.ChartChangeEvent var18 = new org.jfree.chart.event.ChartChangeEvent(var0, var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    java.awt.Stroke var7 = var2.getTickMarkStroke();
    java.awt.Font var8 = var2.getLabelFont();
    float var9 = var2.getTickMarkInsideLength();
    var2.setAutoRangeStickyZero(true);
    var2.resizeRange((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0f);

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    java.awt.Graphics2D var1 = null;
    org.jfree.data.Range var2 = null;
    org.jfree.data.Range var4 = org.jfree.data.Range.expandToInclude(var2, (-1.0d));
    org.jfree.data.Range var6 = org.jfree.data.Range.expandToInclude(var2, 10.0d);
    org.jfree.chart.block.RectangleConstraint var8 = new org.jfree.chart.block.RectangleConstraint(var2, (-1.0d));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var9 = var0.arrange(var1, var8);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var4 = null;
    var3.setPlot(var4);
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var3, var6);
    org.jfree.chart.LegendItemSource var8 = null;
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
    org.jfree.chart.util.RectangleEdge var10 = var9.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var12 = var11.getNextOutlinePaint();
    var9.setBackgroundPaint(var12);
    var7.setOutlinePaint(var12);
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var7);
    java.lang.Object var16 = var15.clone();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var19 = var15.createBufferedImage(100, (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test234() {}
//   public void test234() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var2 = var0.getSeriesItemLabelsVisible(100);
//     org.jfree.chart.labels.ItemLabelPosition var5 = var0.getPositiveItemLabelPosition(100, 0);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var6 = var0.getLegendItemToolTipGenerator();
//     var0.setItemLabelAnchorOffset(100.0d);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.data.category.CategoryDataset var10 = null;
//     org.jfree.chart.axis.CategoryAxis var11 = null;
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var13 = null;
//     var12.setPlot(var13);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var15 = null;
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var10, var11, (org.jfree.chart.axis.ValueAxis)var12, var15);
//     org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var18 = null;
//     var17.setPlot(var18);
//     org.jfree.chart.axis.ValueAxis[] var20 = new org.jfree.chart.axis.ValueAxis[] { var17};
//     var16.setRangeAxes(var20);
//     java.awt.Paint var22 = var16.getDomainGridlinePaint();
//     java.awt.Color var25 = java.awt.Color.getColor("", (-1));
//     java.awt.image.ColorModel var26 = null;
//     java.awt.Rectangle var27 = null;
//     org.jfree.chart.LegendItemSource var28 = null;
//     org.jfree.chart.title.LegendTitle var29 = new org.jfree.chart.title.LegendTitle(var28);
//     org.jfree.chart.util.RectangleInsets var30 = var29.getItemLabelPadding();
//     org.jfree.chart.LegendItemSource var31 = null;
//     org.jfree.chart.title.LegendTitle var32 = new org.jfree.chart.title.LegendTitle(var31);
//     org.jfree.chart.util.RectangleInsets var33 = var32.getItemLabelPadding();
//     double var34 = var33.getTop();
//     var29.setPadding(var33);
//     org.jfree.chart.util.Size2D var36 = new org.jfree.chart.util.Size2D();
//     boolean var38 = var36.equals((java.lang.Object)(-1L));
//     double var39 = var36.getWidth();
//     double var40 = var36.getHeight();
//     org.jfree.chart.util.RectangleAnchor var43 = null;
//     java.awt.geom.Rectangle2D var44 = org.jfree.chart.util.RectangleAnchor.createRectangle(var36, 2.0d, (-1.0d), var43);
//     org.jfree.chart.axis.CategoryLabelPositions var47 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var48 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var49 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var47, var48);
//     org.jfree.chart.util.RectangleAnchor var50 = var48.getCategoryAnchor();
//     java.awt.geom.Rectangle2D var51 = org.jfree.chart.util.RectangleAnchor.createRectangle(var36, 2.0d, 1.0d, var50);
//     java.awt.geom.Rectangle2D var52 = var33.createOutsetRectangle(var51);
//     java.awt.geom.AffineTransform var53 = null;
//     java.awt.RenderingHints var54 = null;
//     java.awt.PaintContext var55 = var25.createContext(var26, var27, var52, var53, var54);
//     var0.drawDomainGridline(var9, var16, (java.awt.geom.Rectangle2D)var27, 1.0E-8d);
// 
//   }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }


    org.jfree.chart.ui.ProjectInfo var0 = new org.jfree.chart.ui.ProjectInfo();
    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    boolean var3 = var0.equals((java.lang.Object)var2);
    java.awt.Image var4 = var0.getLogo();
    var0.setLicenceName("NOID");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = var0.getString("");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = var0.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var5 = var0.getPositiveItemLabelPosition(100, 0);
    org.jfree.chart.urls.CategoryURLGenerator var6 = var0.getBaseURLGenerator();
    int var7 = var0.getColumnCount();
    boolean var8 = var0.getAutoPopulateSeriesOutlineStroke();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var11 = var10.getPositiveItemLabelPositionFallback();
    java.awt.Paint var14 = var10.getItemLabelPaint((-123), (-1));
    org.jfree.data.category.CategoryDataset var15 = null;
    org.jfree.chart.axis.CategoryAxis var16 = null;
    org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var18 = null;
    var17.setPlot(var18);
    org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
    org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var15, var16, (org.jfree.chart.axis.ValueAxis)var17, var20);
    java.awt.Stroke var22 = var17.getTickMarkStroke();
    org.jfree.chart.LegendItemSource var23 = null;
    org.jfree.chart.title.LegendTitle var24 = new org.jfree.chart.title.LegendTitle(var23);
    org.jfree.chart.util.RectangleInsets var25 = var24.getItemLabelPadding();
    double var26 = var25.getTop();
    org.jfree.chart.block.LineBorder var27 = new org.jfree.chart.block.LineBorder(var14, var22, var25);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesStroke((-855310), var22);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 2.0d);

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }


    org.jfree.chart.util.PaintList var0 = new org.jfree.chart.util.PaintList();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var3 = var2.getPositiveItemLabelPositionFallback();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var5 = var4.getPositiveItemLabelPositionFallback();
    java.awt.Paint var8 = var4.getItemLabelPaint((-123), (-1));
    org.jfree.data.category.CategoryDataset var9 = null;
    org.jfree.chart.axis.CategoryAxis var10 = null;
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var12 = null;
    var11.setPlot(var12);
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var9, var10, (org.jfree.chart.axis.ValueAxis)var11, var14);
    java.awt.Stroke var16 = var11.getTickMarkStroke();
    org.jfree.chart.LegendItemSource var17 = null;
    org.jfree.chart.title.LegendTitle var18 = new org.jfree.chart.title.LegendTitle(var17);
    org.jfree.chart.util.RectangleInsets var19 = var18.getItemLabelPadding();
    double var20 = var19.getTop();
    org.jfree.chart.block.LineBorder var21 = new org.jfree.chart.block.LineBorder(var8, var16, var19);
    var2.setBaseOutlinePaint(var8);
    java.lang.Object var25 = null;
    org.jfree.data.KeyedObject var26 = new org.jfree.data.KeyedObject((java.lang.Comparable)' ', var25);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var27 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var29 = null;
    var27.setSeriesItemLabelsVisible(0, var29, false);
    java.awt.Paint var32 = var27.getBaseOutlinePaint();
    boolean var33 = var26.equals((java.lang.Object)var32);
    var2.setSeriesItemLabelPaint(100, var32, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setPaint((-123), var32);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.util.RectangleInsets var2 = var1.getItemLabelPadding();
    org.jfree.chart.LegendItemSource var3 = null;
    org.jfree.chart.title.LegendTitle var4 = new org.jfree.chart.title.LegendTitle(var3);
    org.jfree.chart.util.RectangleInsets var5 = var4.getItemLabelPadding();
    double var6 = var5.getTop();
    var1.setPadding(var5);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var8 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var5);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.0d);

  }

  public void test240() {}
//   public void test240() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(var0);
// 
//   }

  public void test241() {}
//   public void test241() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var3 = null;
//     var2.setPlot(var3);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
//     var2.setAutoRangeMinimumSize(2.0d);
//     java.awt.geom.Rectangle2D var10 = null;
//     org.jfree.chart.util.RectangleEdge var11 = null;
//     double var12 = var2.java2DToValue(0.0d, var10, var11);
//     var2.setAutoTickUnitSelection(true);
//     java.awt.Stroke var15 = var2.getAxisLineStroke();
//     boolean var16 = var2.isAutoRange();
//     java.awt.Graphics2D var17 = null;
//     java.awt.Color var21 = java.awt.Color.getColor("", (-1));
//     java.awt.image.ColorModel var22 = null;
//     java.awt.Rectangle var23 = null;
//     org.jfree.chart.LegendItemSource var24 = null;
//     org.jfree.chart.title.LegendTitle var25 = new org.jfree.chart.title.LegendTitle(var24);
//     org.jfree.chart.util.RectangleInsets var26 = var25.getItemLabelPadding();
//     org.jfree.chart.LegendItemSource var27 = null;
//     org.jfree.chart.title.LegendTitle var28 = new org.jfree.chart.title.LegendTitle(var27);
//     org.jfree.chart.util.RectangleInsets var29 = var28.getItemLabelPadding();
//     double var30 = var29.getTop();
//     var25.setPadding(var29);
//     org.jfree.chart.util.Size2D var32 = new org.jfree.chart.util.Size2D();
//     boolean var34 = var32.equals((java.lang.Object)(-1L));
//     double var35 = var32.getWidth();
//     double var36 = var32.getHeight();
//     org.jfree.chart.util.RectangleAnchor var39 = null;
//     java.awt.geom.Rectangle2D var40 = org.jfree.chart.util.RectangleAnchor.createRectangle(var32, 2.0d, (-1.0d), var39);
//     org.jfree.chart.axis.CategoryLabelPositions var43 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var44 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var45 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var43, var44);
//     org.jfree.chart.util.RectangleAnchor var46 = var44.getCategoryAnchor();
//     java.awt.geom.Rectangle2D var47 = org.jfree.chart.util.RectangleAnchor.createRectangle(var32, 2.0d, 1.0d, var46);
//     java.awt.geom.Rectangle2D var48 = var29.createOutsetRectangle(var47);
//     java.awt.geom.AffineTransform var49 = null;
//     java.awt.RenderingHints var50 = null;
//     java.awt.PaintContext var51 = var21.createContext(var22, var23, var48, var49, var50);
//     org.jfree.chart.LegendItemSource var52 = null;
//     org.jfree.chart.title.LegendTitle var53 = new org.jfree.chart.title.LegendTitle(var52);
//     org.jfree.chart.util.RectangleInsets var54 = var53.getItemLabelPadding();
//     org.jfree.chart.LegendItemSource var55 = null;
//     org.jfree.chart.title.LegendTitle var56 = new org.jfree.chart.title.LegendTitle(var55);
//     org.jfree.chart.util.RectangleInsets var57 = var56.getItemLabelPadding();
//     double var58 = var57.getTop();
//     var53.setPadding(var57);
//     org.jfree.chart.util.Size2D var60 = new org.jfree.chart.util.Size2D();
//     boolean var62 = var60.equals((java.lang.Object)(-1L));
//     double var63 = var60.getWidth();
//     double var64 = var60.getHeight();
//     org.jfree.chart.util.RectangleAnchor var67 = null;
//     java.awt.geom.Rectangle2D var68 = org.jfree.chart.util.RectangleAnchor.createRectangle(var60, 2.0d, (-1.0d), var67);
//     org.jfree.chart.axis.CategoryLabelPositions var71 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var72 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var73 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var71, var72);
//     org.jfree.chart.util.RectangleAnchor var74 = var72.getCategoryAnchor();
//     java.awt.geom.Rectangle2D var75 = org.jfree.chart.util.RectangleAnchor.createRectangle(var60, 2.0d, 1.0d, var74);
//     java.awt.geom.Rectangle2D var76 = var57.createOutsetRectangle(var75);
//     org.jfree.data.general.DatasetGroup var77 = new org.jfree.data.general.DatasetGroup();
//     org.jfree.chart.LegendItemSource var78 = null;
//     org.jfree.chart.title.LegendTitle var79 = new org.jfree.chart.title.LegendTitle(var78);
//     org.jfree.chart.util.RectangleEdge var80 = var79.getLegendItemGraphicEdge();
//     boolean var81 = var77.equals((java.lang.Object)var79);
//     org.jfree.chart.labels.ItemLabelPosition var82 = new org.jfree.chart.labels.ItemLabelPosition();
//     org.jfree.chart.LegendItemSource var83 = null;
//     org.jfree.chart.title.LegendTitle var84 = new org.jfree.chart.title.LegendTitle(var83);
//     org.jfree.chart.util.RectangleEdge var85 = var84.getLegendItemGraphicEdge();
//     org.jfree.chart.util.RectangleEdge var86 = org.jfree.chart.util.RectangleEdge.opposite(var85);
//     boolean var87 = var82.equals((java.lang.Object)var86);
//     var79.setLegendItemGraphicEdge(var86);
//     org.jfree.chart.plot.PlotRenderingInfo var89 = null;
//     org.jfree.chart.axis.AxisState var90 = var2.draw(var17, (-8.0d), var48, var76, var86, var89);
// 
//   }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.LegendItemSource var1 = null;
    org.jfree.chart.title.LegendTitle var2 = new org.jfree.chart.title.LegendTitle(var1);
    org.jfree.chart.util.RectangleInsets var3 = var2.getItemLabelPadding();
    org.jfree.chart.util.VerticalAlignment var4 = var2.getVerticalAlignment();
    org.jfree.chart.block.ColumnArrangement var7 = new org.jfree.chart.block.ColumnArrangement(var0, var4, 0.0d, 2.0d);
    org.jfree.data.general.Dataset var8 = null;
    org.jfree.chart.title.LegendItemBlockContainer var10 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var7, var8, (java.lang.Comparable)Double.NaN);
    var7.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test243() {}
//   public void test243() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }
// 
// 
//     org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("");
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.text.TextBlock var4 = new org.jfree.chart.text.TextBlock();
//     java.util.List var5 = var4.getLines();
//     org.jfree.chart.text.TextLine var6 = null;
//     var4.addLine(var6);
//     org.jfree.chart.util.HorizontalAlignment var8 = var4.getLineAlignment();
//     org.jfree.chart.axis.CategoryLabelPositions var9 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var10 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var11 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var9, var10);
//     float var12 = var10.getWidthRatio();
//     org.jfree.chart.text.TextBlockAnchor var13 = var10.getLabelAnchor();
//     java.awt.Graphics2D var15 = null;
//     org.jfree.chart.axis.CategoryLabelPositions var18 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var19 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var20 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var18, var19);
//     org.jfree.chart.text.TextAnchor var21 = var19.getRotationAnchor();
//     org.jfree.chart.labels.ItemLabelPosition var23 = new org.jfree.chart.labels.ItemLabelPosition();
//     org.jfree.chart.LegendItemSource var24 = null;
//     org.jfree.chart.title.LegendTitle var25 = new org.jfree.chart.title.LegendTitle(var24);
//     org.jfree.chart.util.RectangleEdge var26 = var25.getLegendItemGraphicEdge();
//     org.jfree.chart.util.RectangleEdge var27 = org.jfree.chart.util.RectangleEdge.opposite(var26);
//     boolean var28 = var23.equals((java.lang.Object)var27);
//     org.jfree.chart.labels.ItemLabelAnchor var29 = var23.getItemLabelAnchor();
//     org.jfree.chart.axis.CategoryLabelPositions var30 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var31 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var32 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var30, var31);
//     org.jfree.chart.text.TextAnchor var33 = var31.getRotationAnchor();
//     org.jfree.chart.labels.ItemLabelPosition var34 = new org.jfree.chart.labels.ItemLabelPosition(var29, var33);
//     org.jfree.chart.text.TextUtilities.drawRotatedString("", var15, 100.0f, 0.0f, var21, 100.0d, var33);
//     org.jfree.chart.axis.CategoryTick var37 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)(-1.0f), var4, var13, var33, 10.0d);
//     float var38 = var1.calculateBaselineOffset(var2, var33);
// 
//   }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }


    org.jfree.chart.axis.AxisState var0 = new org.jfree.chart.axis.AxisState();
    var0.setMax(0.0d);

  }

  public void test245() {}
//   public void test245() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextBlock var5 = new org.jfree.chart.text.TextBlock();
//     java.util.List var6 = var5.getLines();
//     org.jfree.chart.text.TextLine var7 = null;
//     var5.addLine(var7);
//     org.jfree.chart.util.HorizontalAlignment var9 = var5.getLineAlignment();
//     org.jfree.chart.text.TextBlockAnchor var10 = null;
//     java.awt.Graphics2D var12 = null;
//     org.jfree.chart.labels.ItemLabelPosition var15 = new org.jfree.chart.labels.ItemLabelPosition();
//     org.jfree.chart.LegendItemSource var16 = null;
//     org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle(var16);
//     org.jfree.chart.util.RectangleEdge var18 = var17.getLegendItemGraphicEdge();
//     org.jfree.chart.util.RectangleEdge var19 = org.jfree.chart.util.RectangleEdge.opposite(var18);
//     boolean var20 = var15.equals((java.lang.Object)var19);
//     org.jfree.chart.labels.ItemLabelAnchor var21 = var15.getItemLabelAnchor();
//     org.jfree.chart.axis.CategoryLabelPositions var22 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var23 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var24 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var22, var23);
//     org.jfree.chart.text.TextAnchor var25 = var23.getRotationAnchor();
//     org.jfree.chart.labels.ItemLabelPosition var26 = new org.jfree.chart.labels.ItemLabelPosition(var21, var25);
//     org.jfree.chart.text.TextUtilities.drawRotatedString("", var12, 1.0f, (-1.0f), var25, 2.0d, 1.0f, 0.0f);
//     org.jfree.chart.axis.CategoryTick var32 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)(byte)0, var5, var10, var25, 0.0d);
//     java.lang.String var33 = var32.getText();
//     org.jfree.chart.text.TextAnchor var34 = var32.getTextAnchor();
//     org.jfree.chart.text.TextAnchor var36 = null;
//     java.awt.Shape var37 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("NOID", var1, 100.0f, (-1.0f), var34, (-8.0d), var36);
// 
//   }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }


    org.jfree.chart.util.Size2D var0 = new org.jfree.chart.util.Size2D();
    boolean var2 = var0.equals((java.lang.Object)(-1L));
    double var3 = var0.getWidth();
    double var4 = var0.getHeight();
    org.jfree.chart.util.RectangleAnchor var7 = null;
    java.awt.geom.Rectangle2D var8 = org.jfree.chart.util.RectangleAnchor.createRectangle(var0, 2.0d, (-1.0d), var7);
    org.jfree.chart.axis.CategoryLabelPositions var11 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var12 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var13 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var11, var12);
    org.jfree.chart.util.RectangleAnchor var14 = var12.getCategoryAnchor();
    java.awt.geom.Rectangle2D var15 = org.jfree.chart.util.RectangleAnchor.createRectangle(var0, 2.0d, 1.0d, var14);
    org.jfree.chart.text.TextBlock var17 = new org.jfree.chart.text.TextBlock();
    java.util.List var18 = var17.getLines();
    org.jfree.chart.text.TextLine var19 = null;
    var17.addLine(var19);
    org.jfree.chart.util.HorizontalAlignment var21 = var17.getLineAlignment();
    org.jfree.chart.axis.CategoryLabelPositions var22 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var23 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var24 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var22, var23);
    float var25 = var23.getWidthRatio();
    org.jfree.chart.text.TextBlockAnchor var26 = var23.getLabelAnchor();
    java.awt.Graphics2D var28 = null;
    org.jfree.chart.axis.CategoryLabelPositions var31 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var32 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var33 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var31, var32);
    org.jfree.chart.text.TextAnchor var34 = var32.getRotationAnchor();
    org.jfree.chart.labels.ItemLabelPosition var36 = new org.jfree.chart.labels.ItemLabelPosition();
    org.jfree.chart.LegendItemSource var37 = null;
    org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle(var37);
    org.jfree.chart.util.RectangleEdge var39 = var38.getLegendItemGraphicEdge();
    org.jfree.chart.util.RectangleEdge var40 = org.jfree.chart.util.RectangleEdge.opposite(var39);
    boolean var41 = var36.equals((java.lang.Object)var40);
    org.jfree.chart.labels.ItemLabelAnchor var42 = var36.getItemLabelAnchor();
    org.jfree.chart.axis.CategoryLabelPositions var43 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var44 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var45 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var43, var44);
    org.jfree.chart.text.TextAnchor var46 = var44.getRotationAnchor();
    org.jfree.chart.labels.ItemLabelPosition var47 = new org.jfree.chart.labels.ItemLabelPosition(var42, var46);
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var28, 100.0f, 0.0f, var34, 100.0d, var46);
    org.jfree.chart.axis.CategoryTick var50 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)(-1.0f), var17, var26, var46, 10.0d);
    org.jfree.chart.axis.CategoryLabelPositions var51 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var52 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var53 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var51, var52);
    float var54 = var52.getWidthRatio();
    org.jfree.chart.text.TextBlockAnchor var55 = var52.getLabelAnchor();
    org.jfree.chart.axis.CategoryLabelWidthType var56 = var52.getWidthType();
    org.jfree.chart.axis.CategoryLabelPosition var58 = new org.jfree.chart.axis.CategoryLabelPosition(var14, var26, var56, (-1.0f));
    org.jfree.chart.axis.NumberAxis var59 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var60 = null;
    var59.setPlot(var60);
    org.jfree.chart.block.BlockContainer var62 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.util.RectangleInsets var63 = var62.getPadding();
    double var65 = var63.calculateTopInset(100.0d);
    double var67 = var63.calculateTopInset(2.0d);
    var59.setLabelInsets(var63);
    var59.setFixedAutoRange(10.0d);
    boolean var71 = var56.equals((java.lang.Object)var59);
    java.lang.String var72 = var56.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.95f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0.95f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var72 + "' != '" + "CategoryLabelWidthType.CATEGORY"+ "'", var72.equals("CategoryLabelWidthType.CATEGORY"));

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    org.jfree.chart.LegendItemSource var7 = null;
    org.jfree.chart.title.LegendTitle var8 = new org.jfree.chart.title.LegendTitle(var7);
    org.jfree.chart.util.RectangleEdge var9 = var8.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var10 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var11 = var10.getNextOutlinePaint();
    var8.setBackgroundPaint(var11);
    var6.setOutlinePaint(var11);
    var6.clearDomainMarkers();
    org.jfree.chart.annotations.CategoryAnnotation var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.addAnnotation(var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test248() {}
//   public void test248() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var3 = null;
//     var2.setPlot(var3);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
//     org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var8 = null;
//     var7.setPlot(var8);
//     org.jfree.chart.axis.ValueAxis[] var10 = new org.jfree.chart.axis.ValueAxis[] { var7};
//     var6.setRangeAxes(var10);
//     org.jfree.chart.text.TextBlock var13 = new org.jfree.chart.text.TextBlock();
//     java.awt.Graphics2D var14 = null;
//     org.jfree.chart.util.Size2D var15 = var13.calculateDimensions(var14);
//     org.jfree.data.category.CategoryDataset var17 = null;
//     org.jfree.chart.axis.CategoryAxis var18 = null;
//     org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var20 = null;
//     var19.setPlot(var20);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var22 = null;
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot(var17, var18, (org.jfree.chart.axis.ValueAxis)var19, var22);
//     java.awt.Stroke var24 = var19.getTickMarkStroke();
//     java.awt.Font var25 = var19.getLabelFont();
//     java.awt.Color var28 = java.awt.Color.getColor("", (-1));
//     var13.addLine("CategoryLabelEntity: category=null, tooltip=hi!, url=", var25, (java.awt.Paint)var28);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var30 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var32 = var30.getSeriesItemLabelsVisible(100);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var33 = null;
//     var30.setBaseItemLabelGenerator(var33);
//     java.awt.Paint var37 = var30.getItemFillPaint(0, (-855310));
//     org.jfree.chart.text.TextFragment var39 = new org.jfree.chart.text.TextFragment("NOID", var25, var37, 2.0f);
//     var6.setNoDataMessageFont(var25);
//     
//     // Checks the contract:  equals-hashcode on var6 and var23
//     assertTrue("Contract failed: equals-hashcode on var6 and var23", var6.equals(var23) ? var6.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var6
//     assertTrue("Contract failed: equals-hashcode on var23 and var6", var23.equals(var6) ? var23.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test250() {}
//   public void test250() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var3 = null;
//     var1.setSeriesItemLabelsVisible(0, var3, false);
//     java.awt.Stroke var6 = var1.getErrorIndicatorStroke();
//     org.jfree.chart.plot.DrawingSupplier var7 = var1.getDrawingSupplier();
//     java.lang.Boolean var9 = var1.getSeriesCreateEntities(10);
//     java.awt.Paint var10 = var1.getBaseOutlinePaint();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var14 = var12.getSeriesItemLabelsVisible(100);
//     org.jfree.chart.labels.ItemLabelPosition var17 = var12.getPositiveItemLabelPosition(100, 0);
//     org.jfree.chart.urls.CategoryURLGenerator var18 = var12.getBaseURLGenerator();
//     java.lang.Boolean var20 = var12.getSeriesItemLabelsVisible((-855310));
//     java.awt.Color var23 = java.awt.Color.getColor("", (-1));
//     var12.setBasePaint((java.awt.Paint)var23, true);
//     var1.setSeriesPaint(0, (java.awt.Paint)var23, false);
//     int var28 = var23.getRGB();
//     org.jfree.chart.LegendItemSource var29 = null;
//     org.jfree.chart.title.LegendTitle var30 = new org.jfree.chart.title.LegendTitle(var29);
//     org.jfree.chart.util.RectangleEdge var31 = var30.getLegendItemGraphicEdge();
//     java.awt.Paint var32 = var30.getItemPaint();
//     org.jfree.data.category.CategoryDataset var34 = null;
//     org.jfree.chart.axis.CategoryAxis var35 = null;
//     org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var37 = null;
//     var36.setPlot(var37);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var39 = null;
//     org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot(var34, var35, (org.jfree.chart.axis.ValueAxis)var36, var39);
//     org.jfree.chart.LegendItemSource var41 = null;
//     org.jfree.chart.title.LegendTitle var42 = new org.jfree.chart.title.LegendTitle(var41);
//     org.jfree.chart.util.RectangleEdge var43 = var42.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var44 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var45 = var44.getNextOutlinePaint();
//     var42.setBackgroundPaint(var45);
//     var40.setOutlinePaint(var45);
//     org.jfree.chart.JFreeChart var48 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var40);
//     var48.fireChartChanged();
//     boolean var50 = var48.getAntiAlias();
//     java.util.List var51 = var48.getSubtitles();
//     var30.addChangeListener((org.jfree.chart.event.TitleChangeListener)var48);
//     org.jfree.data.category.CategoryDataset var53 = null;
//     org.jfree.chart.axis.CategoryAxis var54 = null;
//     org.jfree.chart.axis.NumberAxis var55 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var56 = null;
//     var55.setPlot(var56);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var58 = null;
//     org.jfree.chart.plot.CategoryPlot var59 = new org.jfree.chart.plot.CategoryPlot(var53, var54, (org.jfree.chart.axis.ValueAxis)var55, var58);
//     var55.setAutoRangeMinimumSize(2.0d);
//     java.awt.geom.Rectangle2D var63 = null;
//     org.jfree.chart.util.RectangleEdge var64 = null;
//     double var65 = var55.java2DToValue(0.0d, var63, var64);
//     var55.setAutoTickUnitSelection(true);
//     java.awt.Stroke var68 = var55.getAxisLineStroke();
//     var48.setBorderStroke(var68);
//     org.jfree.chart.plot.ValueMarker var70 = new org.jfree.chart.plot.ValueMarker(Double.NaN, (java.awt.Paint)var23, var68);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var71 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var73 = null;
//     var71.setSeriesItemLabelsVisible(0, var73, false);
//     java.awt.Stroke var76 = var71.getErrorIndicatorStroke();
//     org.jfree.chart.plot.DrawingSupplier var77 = var71.getDrawingSupplier();
//     java.lang.Boolean var79 = var71.getSeriesCreateEntities(10);
//     java.awt.Paint var80 = var71.getBaseOutlinePaint();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var82 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var84 = var82.getSeriesItemLabelsVisible(100);
//     org.jfree.chart.labels.ItemLabelPosition var87 = var82.getPositiveItemLabelPosition(100, 0);
//     org.jfree.chart.urls.CategoryURLGenerator var88 = var82.getBaseURLGenerator();
//     java.lang.Boolean var90 = var82.getSeriesItemLabelsVisible((-855310));
//     java.awt.Color var93 = java.awt.Color.getColor("", (-1));
//     var82.setBasePaint((java.awt.Paint)var93, true);
//     var71.setSeriesPaint(0, (java.awt.Paint)var93, false);
//     var70.setOutlinePaint((java.awt.Paint)var93);
//     
//     // Checks the contract:  equals-hashcode on var17 and var87
//     assertTrue("Contract failed: equals-hashcode on var17 and var87", var17.equals(var87) ? var17.hashCode() == var87.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var87 and var17
//     assertTrue("Contract failed: equals-hashcode on var87 and var17", var87.equals(var17) ? var87.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test251() {}
//   public void test251() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }
// 
// 
//     org.jfree.chart.LegendItemSource var0 = null;
//     org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
//     org.jfree.chart.util.RectangleEdge var2 = var1.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var3 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var4 = var3.getNextOutlinePaint();
//     var1.setBackgroundPaint(var4);
//     org.jfree.chart.text.TextBlock var6 = new org.jfree.chart.text.TextBlock();
//     java.util.List var7 = var6.getLines();
//     boolean var8 = var1.equals((java.lang.Object)var6);
//     org.jfree.chart.util.RectangleEdge var9 = var1.getLegendItemGraphicEdge();
//     org.jfree.data.category.CategoryDataset var11 = null;
//     org.jfree.chart.axis.CategoryAxis var12 = null;
//     org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var14 = null;
//     var13.setPlot(var14);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var11, var12, (org.jfree.chart.axis.ValueAxis)var13, var16);
//     org.jfree.chart.LegendItemSource var18 = null;
//     org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle(var18);
//     org.jfree.chart.util.RectangleEdge var20 = var19.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var21 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var22 = var21.getNextOutlinePaint();
//     var19.setBackgroundPaint(var22);
//     var17.setOutlinePaint(var22);
//     org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var17);
//     var25.fireChartChanged();
//     var25.setTextAntiAlias(false);
//     java.util.List var29 = var25.getSubtitles();
//     var1.addChangeListener((org.jfree.chart.event.TitleChangeListener)var25);
//     
//     // Checks the contract:  equals-hashcode on var3 and var21
//     assertTrue("Contract failed: equals-hashcode on var3 and var21", var3.equals(var21) ? var3.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var3
//     assertTrue("Contract failed: equals-hashcode on var21 and var3", var21.equals(var3) ? var21.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test252() {}
//   public void test252() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var2 = var0.getSeriesItemLabelsVisible(100);
//     org.jfree.chart.labels.ItemLabelPosition var5 = var0.getPositiveItemLabelPosition(100, 0);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var6 = var0.getLegendItemToolTipGenerator();
//     boolean var7 = var0.getAutoPopulateSeriesFillPaint();
//     org.jfree.chart.renderer.category.BarRenderer var9 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var10 = var9.getBasePositiveItemLabelPosition();
//     java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
//     org.jfree.chart.entity.ChartEntity var22 = new org.jfree.chart.entity.ChartEntity(var20, "Range[-1.0,-1.0]");
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var23 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var25 = null;
//     var23.setSeriesItemLabelsVisible(0, var25, false);
//     java.awt.Stroke var28 = var23.getErrorIndicatorStroke();
//     java.awt.Paint var29 = null;
//     org.jfree.chart.LegendItem var30 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var20, var28, var29);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var31 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var32 = var31.getPositiveItemLabelPositionFallback();
//     java.awt.Paint var35 = var31.getItemLabelPaint((-123), (-1));
//     org.jfree.chart.LegendItem var36 = new org.jfree.chart.LegendItem("", "CategoryLabelEntity: category=null, tooltip=hi!, url=", "CategoryLabelEntity: category=null, tooltip=hi!, url=", "Range[-1.0,-1.0]", var20, var35);
//     java.awt.Paint var37 = var36.getOutlinePaint();
//     var9.setBasePaint(var37, true);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var40 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var41 = var40.getPositiveItemLabelPositionFallback();
//     java.awt.Paint var44 = var40.getItemLabelPaint((-123), (-1));
//     org.jfree.data.category.CategoryDataset var45 = null;
//     org.jfree.chart.axis.CategoryAxis var46 = null;
//     org.jfree.chart.axis.NumberAxis var47 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var48 = null;
//     var47.setPlot(var48);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var50 = null;
//     org.jfree.chart.plot.CategoryPlot var51 = new org.jfree.chart.plot.CategoryPlot(var45, var46, (org.jfree.chart.axis.ValueAxis)var47, var50);
//     java.awt.Stroke var52 = var47.getTickMarkStroke();
//     org.jfree.chart.LegendItemSource var53 = null;
//     org.jfree.chart.title.LegendTitle var54 = new org.jfree.chart.title.LegendTitle(var53);
//     org.jfree.chart.util.RectangleInsets var55 = var54.getItemLabelPadding();
//     double var56 = var55.getTop();
//     org.jfree.chart.block.LineBorder var57 = new org.jfree.chart.block.LineBorder(var44, var52, var55);
//     java.awt.Stroke var58 = var57.getStroke();
//     var9.setBaseStroke(var58);
//     var0.setSeriesOutlineStroke(255, var58, false);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var23 and var0.", var23.equals(var0) == var0.equals(var23));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var31 and var0.", var31.equals(var0) == var0.equals(var31));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var40 and var0.", var40.equals(var0) == var0.equals(var40));
//     
//     // Checks the contract:  equals-hashcode on var5 and var10
//     assertTrue("Contract failed: equals-hashcode on var5 and var10", var5.equals(var10) ? var5.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var5
//     assertTrue("Contract failed: equals-hashcode on var10 and var5", var10.equals(var5) ? var10.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test253() {}
//   public void test253() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var3 = null;
//     var2.setPlot(var3);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
//     org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var8 = null;
//     var7.setPlot(var8);
//     org.jfree.chart.axis.ValueAxis[] var10 = new org.jfree.chart.axis.ValueAxis[] { var7};
//     var6.setRangeAxes(var10);
//     java.awt.Paint var12 = var6.getDomainGridlinePaint();
//     float var13 = var6.getForegroundAlpha();
//     org.jfree.chart.axis.CategoryAxis var15 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.TOP_OR_RIGHT");
//     org.jfree.chart.axis.CategoryAxis[] var16 = new org.jfree.chart.axis.CategoryAxis[] { var15};
//     var6.setDomainAxes(var16);
//     java.awt.Graphics2D var18 = null;
//     java.awt.Color var21 = java.awt.Color.getColor("", (-1));
//     java.awt.image.ColorModel var22 = null;
//     java.awt.Rectangle var23 = null;
//     org.jfree.chart.LegendItemSource var24 = null;
//     org.jfree.chart.title.LegendTitle var25 = new org.jfree.chart.title.LegendTitle(var24);
//     org.jfree.chart.util.RectangleInsets var26 = var25.getItemLabelPadding();
//     org.jfree.chart.LegendItemSource var27 = null;
//     org.jfree.chart.title.LegendTitle var28 = new org.jfree.chart.title.LegendTitle(var27);
//     org.jfree.chart.util.RectangleInsets var29 = var28.getItemLabelPadding();
//     double var30 = var29.getTop();
//     var25.setPadding(var29);
//     org.jfree.chart.util.Size2D var32 = new org.jfree.chart.util.Size2D();
//     boolean var34 = var32.equals((java.lang.Object)(-1L));
//     double var35 = var32.getWidth();
//     double var36 = var32.getHeight();
//     org.jfree.chart.util.RectangleAnchor var39 = null;
//     java.awt.geom.Rectangle2D var40 = org.jfree.chart.util.RectangleAnchor.createRectangle(var32, 2.0d, (-1.0d), var39);
//     org.jfree.chart.axis.CategoryLabelPositions var43 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var44 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var45 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var43, var44);
//     org.jfree.chart.util.RectangleAnchor var46 = var44.getCategoryAnchor();
//     java.awt.geom.Rectangle2D var47 = org.jfree.chart.util.RectangleAnchor.createRectangle(var32, 2.0d, 1.0d, var46);
//     java.awt.geom.Rectangle2D var48 = var29.createOutsetRectangle(var47);
//     java.awt.geom.AffineTransform var49 = null;
//     java.awt.RenderingHints var50 = null;
//     java.awt.PaintContext var51 = var21.createContext(var22, var23, var48, var49, var50);
//     var6.drawOutline(var18, var48);
// 
//   }

  public void test254() {}
//   public void test254() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var4 = null;
//     var3.setPlot(var4);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var3, var6);
//     org.jfree.chart.LegendItemSource var8 = null;
//     org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
//     org.jfree.chart.util.RectangleEdge var10 = var9.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var12 = var11.getNextOutlinePaint();
//     var9.setBackgroundPaint(var12);
//     var7.setOutlinePaint(var12);
//     org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var7);
//     var15.fireChartChanged();
//     var15.setTextAntiAlias(false);
//     java.util.List var19 = var15.getSubtitles();
//     org.jfree.chart.util.RectangleInsets var20 = var15.getPadding();
//     org.jfree.chart.plot.CategoryPlot var21 = var15.getCategoryPlot();
//     org.jfree.chart.ChartRenderingInfo var24 = null;
//     var15.handleClick(0, 100, var24);
// 
//   }

  public void test255() {}
//   public void test255() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }
// 
// 
//     org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.util.RectangleInsets var1 = var0.getPadding();
//     double var2 = var0.getWidth();
//     java.lang.Object var3 = var0.clone();
//     java.awt.Graphics2D var4 = null;
//     org.jfree.chart.LegendItemSource var5 = null;
//     org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle(var5);
//     org.jfree.chart.util.RectangleInsets var7 = var6.getItemLabelPadding();
//     org.jfree.chart.util.VerticalAlignment var8 = var6.getVerticalAlignment();
//     org.jfree.chart.block.BlockContainer var9 = var6.getItemContainer();
//     org.jfree.chart.LegendItemSource var10 = null;
//     org.jfree.chart.title.LegendTitle var11 = new org.jfree.chart.title.LegendTitle(var10);
//     org.jfree.chart.util.RectangleInsets var12 = var11.getItemLabelPadding();
//     double var14 = var12.calculateTopOutset(4.0d);
//     var9.setMargin(var12);
//     java.awt.geom.Rectangle2D var16 = var9.getBounds();
//     org.jfree.data.category.CategoryDataset var17 = null;
//     org.jfree.chart.axis.CategoryAxis var18 = null;
//     org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var20 = null;
//     var19.setPlot(var20);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var22 = null;
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot(var17, var18, (org.jfree.chart.axis.ValueAxis)var19, var22);
//     var23.setAnchorValue(0.0d, true);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var27 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var29 = null;
//     var27.setSeriesItemLabelsVisible(0, var29, false);
//     org.jfree.chart.labels.CategoryToolTipGenerator var33 = null;
//     var27.setSeriesToolTipGenerator(1, var33, false);
//     org.jfree.chart.urls.CategoryURLGenerator var36 = null;
//     var27.setBaseURLGenerator(var36);
//     java.awt.Graphics2D var38 = null;
//     org.jfree.chart.plot.CategoryPlot var39 = null;
//     org.jfree.chart.axis.ValueAxis var40 = null;
//     org.jfree.chart.plot.Marker var41 = null;
//     java.awt.geom.Rectangle2D var42 = null;
//     var27.drawRangeMarker(var38, var39, var40, var41, var42);
//     boolean var45 = var27.isSeriesVisibleInLegend(0);
//     var23.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var27);
//     org.jfree.chart.axis.CategoryAxis var47 = null;
//     java.util.List var48 = var23.getCategoriesForAxis(var47);
//     java.awt.Font var49 = var23.getNoDataMessageFont();
//     java.lang.Object var50 = var0.draw(var4, var16, (java.lang.Object)var49);
// 
//   }

  public void test256() {}
//   public void test256() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(var0);
// 
//   }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }


    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var7 = new org.jfree.chart.entity.ChartEntity(var5, "Range[-1.0,-1.0]");
    org.jfree.chart.renderer.category.StatisticalBarRenderer var8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var10 = null;
    var8.setSeriesItemLabelsVisible(0, var10, false);
    java.awt.Stroke var13 = var8.getErrorIndicatorStroke();
    java.awt.Paint var14 = null;
    org.jfree.chart.LegendItem var15 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var5, var13, var14);
    boolean var16 = var15.isLineVisible();
    int var17 = var15.getDatasetIndex();
    boolean var18 = var15.isShapeVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }


    org.jfree.chart.LegendItemCollection var0 = new org.jfree.chart.LegendItemCollection();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var2 = var0.get(255);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }


    org.jfree.chart.util.StandardGradientPaintTransformer var0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    java.lang.Object var1 = var0.clone();
    org.jfree.chart.event.ChartChangeEvent var2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0);
    org.jfree.chart.event.ChartChangeEventType var3 = null;
    var2.setType(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test260() {}
//   public void test260() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextBlock var5 = new org.jfree.chart.text.TextBlock();
//     java.util.List var6 = var5.getLines();
//     org.jfree.chart.text.TextLine var7 = null;
//     var5.addLine(var7);
//     org.jfree.chart.util.HorizontalAlignment var9 = var5.getLineAlignment();
//     org.jfree.chart.text.TextBlockAnchor var10 = null;
//     java.awt.Graphics2D var12 = null;
//     org.jfree.chart.labels.ItemLabelPosition var15 = new org.jfree.chart.labels.ItemLabelPosition();
//     org.jfree.chart.LegendItemSource var16 = null;
//     org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle(var16);
//     org.jfree.chart.util.RectangleEdge var18 = var17.getLegendItemGraphicEdge();
//     org.jfree.chart.util.RectangleEdge var19 = org.jfree.chart.util.RectangleEdge.opposite(var18);
//     boolean var20 = var15.equals((java.lang.Object)var19);
//     org.jfree.chart.labels.ItemLabelAnchor var21 = var15.getItemLabelAnchor();
//     org.jfree.chart.axis.CategoryLabelPositions var22 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var23 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var24 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var22, var23);
//     org.jfree.chart.text.TextAnchor var25 = var23.getRotationAnchor();
//     org.jfree.chart.labels.ItemLabelPosition var26 = new org.jfree.chart.labels.ItemLabelPosition(var21, var25);
//     org.jfree.chart.text.TextUtilities.drawRotatedString("", var12, 1.0f, (-1.0f), var25, 2.0d, 1.0f, 0.0f);
//     org.jfree.chart.axis.CategoryTick var32 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)(byte)0, var5, var10, var25, 0.0d);
//     org.jfree.chart.text.TextAnchor var33 = var32.getTextAnchor();
//     org.jfree.chart.text.TextUtilities.drawRotatedString("NOID", var1, 2.0f, 10.0f, var33, 6.0d, 100.0f, 1.0f);
// 
//   }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    java.awt.Stroke var7 = var2.getTickMarkStroke();
    java.awt.Font var8 = var2.getLabelFont();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setRangeWithMargins(10.0d, 6.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test262() {}
//   public void test262() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var4 = null;
//     var3.setPlot(var4);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var3, var6);
//     java.awt.Stroke var8 = var3.getTickMarkStroke();
//     java.awt.Font var9 = var3.getLabelFont();
//     org.jfree.data.category.CategoryDataset var10 = null;
//     org.jfree.chart.axis.CategoryAxis var11 = null;
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var13 = null;
//     var12.setPlot(var13);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var15 = null;
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var10, var11, (org.jfree.chart.axis.ValueAxis)var12, var15);
//     java.awt.Stroke var17 = var12.getTickMarkStroke();
//     var12.zoomRange((-1.0d), 100.0d);
//     org.jfree.chart.block.BlockContainer var21 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.util.RectangleInsets var22 = var21.getPadding();
//     double var24 = var22.calculateTopInset(100.0d);
//     var12.setLabelInsets(var22);
//     java.awt.Paint var26 = var12.getTickMarkPaint();
//     org.jfree.chart.text.TextFragment var28 = new org.jfree.chart.text.TextFragment("NOID", var9, var26, 10.0f);
//     java.awt.Graphics2D var29 = null;
//     org.jfree.chart.util.Size2D var30 = var28.calculateDimensions(var29);
// 
//   }

  public void test263() {}
//   public void test263() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }
// 
// 
//     double[] var2 = null;
//     double[][] var3 = new double[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("CategoryLabelEntity: category=null, tooltip=hi!, url=", "AxisLocation.TOP_OR_RIGHT", var3);
// 
//   }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = var0.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var5 = var0.getPositiveItemLabelPosition(100, 0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var6 = var0.getLegendItemToolTipGenerator();
    var0.setItemLabelAnchorOffset(100.0d);
    org.jfree.chart.annotations.CategoryAnnotation var9 = null;
    boolean var10 = var0.removeAnnotation(var9);
    java.awt.Paint var11 = var0.getErrorIndicatorPaint();
    java.awt.Paint var12 = var0.getBaseFillPaint();
    org.jfree.data.category.CategoryDataset var15 = null;
    org.jfree.chart.axis.CategoryAxis var16 = null;
    org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var18 = null;
    var17.setPlot(var18);
    org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
    org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var15, var16, (org.jfree.chart.axis.ValueAxis)var17, var20);
    java.awt.Stroke var22 = var17.getTickMarkStroke();
    java.awt.Font var23 = var17.getLabelFont();
    org.jfree.data.category.CategoryDataset var24 = null;
    org.jfree.chart.axis.CategoryAxis var25 = null;
    org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var27 = null;
    var26.setPlot(var27);
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var24, var25, (org.jfree.chart.axis.ValueAxis)var26, var29);
    java.awt.Stroke var31 = var26.getTickMarkStroke();
    var26.zoomRange((-1.0d), 100.0d);
    org.jfree.chart.block.BlockContainer var35 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.util.RectangleInsets var36 = var35.getPadding();
    double var38 = var36.calculateTopInset(100.0d);
    var26.setLabelInsets(var36);
    java.awt.Paint var40 = var26.getTickMarkPaint();
    org.jfree.chart.text.TextFragment var42 = new org.jfree.chart.text.TextFragment("NOID", var23, var40, 10.0f);
    var0.setSeriesItemLabelPaint(10, var40, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);

  }

  public void test265() {}
//   public void test265() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var3 = null;
//     var2.setPlot(var3);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
//     org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var8 = null;
//     var7.setPlot(var8);
//     org.jfree.chart.axis.ValueAxis[] var10 = new org.jfree.chart.axis.ValueAxis[] { var7};
//     var6.setRangeAxes(var10);
//     org.jfree.data.category.CategoryDataset var12 = null;
//     org.jfree.chart.axis.CategoryAxis var13 = null;
//     org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var15 = null;
//     var14.setPlot(var15);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var12, var13, (org.jfree.chart.axis.ValueAxis)var14, var17);
//     var18.setAnchorValue(0.0d, true);
//     org.jfree.chart.axis.CategoryAxis var22 = var18.getDomainAxis();
//     java.awt.Graphics2D var23 = null;
//     org.jfree.chart.LegendItemSource var24 = null;
//     org.jfree.chart.title.LegendTitle var25 = new org.jfree.chart.title.LegendTitle(var24);
//     org.jfree.chart.util.RectangleInsets var26 = var25.getItemLabelPadding();
//     org.jfree.chart.LegendItemSource var27 = null;
//     org.jfree.chart.title.LegendTitle var28 = new org.jfree.chart.title.LegendTitle(var27);
//     org.jfree.chart.util.RectangleInsets var29 = var28.getItemLabelPadding();
//     double var30 = var29.getTop();
//     var25.setPadding(var29);
//     org.jfree.chart.util.Size2D var32 = new org.jfree.chart.util.Size2D();
//     boolean var34 = var32.equals((java.lang.Object)(-1L));
//     double var35 = var32.getWidth();
//     double var36 = var32.getHeight();
//     org.jfree.chart.util.RectangleAnchor var39 = null;
//     java.awt.geom.Rectangle2D var40 = org.jfree.chart.util.RectangleAnchor.createRectangle(var32, 2.0d, (-1.0d), var39);
//     org.jfree.chart.axis.CategoryLabelPositions var43 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var44 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var45 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var43, var44);
//     org.jfree.chart.util.RectangleAnchor var46 = var44.getCategoryAnchor();
//     java.awt.geom.Rectangle2D var47 = org.jfree.chart.util.RectangleAnchor.createRectangle(var32, 2.0d, 1.0d, var46);
//     java.awt.geom.Rectangle2D var48 = var29.createOutsetRectangle(var47);
//     java.awt.geom.Point2D var49 = null;
//     org.jfree.chart.plot.PlotState var50 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var51 = null;
//     var18.draw(var23, var48, var49, var50, var51);
//     org.jfree.chart.LegendItemSource var53 = null;
//     org.jfree.chart.title.LegendTitle var54 = new org.jfree.chart.title.LegendTitle(var53);
//     org.jfree.chart.util.RectangleEdge var55 = var54.getLegendItemGraphicEdge();
//     java.awt.Paint var56 = var54.getItemPaint();
//     org.jfree.data.category.CategoryDataset var58 = null;
//     org.jfree.chart.axis.CategoryAxis var59 = null;
//     org.jfree.chart.axis.NumberAxis var60 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var61 = null;
//     var60.setPlot(var61);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var63 = null;
//     org.jfree.chart.plot.CategoryPlot var64 = new org.jfree.chart.plot.CategoryPlot(var58, var59, (org.jfree.chart.axis.ValueAxis)var60, var63);
//     org.jfree.chart.LegendItemSource var65 = null;
//     org.jfree.chart.title.LegendTitle var66 = new org.jfree.chart.title.LegendTitle(var65);
//     org.jfree.chart.util.RectangleEdge var67 = var66.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var68 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var69 = var68.getNextOutlinePaint();
//     var66.setBackgroundPaint(var69);
//     var64.setOutlinePaint(var69);
//     org.jfree.chart.JFreeChart var72 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var64);
//     var72.fireChartChanged();
//     boolean var74 = var72.getAntiAlias();
//     java.util.List var75 = var72.getSubtitles();
//     var54.addChangeListener((org.jfree.chart.event.TitleChangeListener)var72);
//     var18.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var72);
//     double var78 = var18.getRangeCrosshairValue();
//     var6.setParent((org.jfree.chart.plot.Plot)var18);
//     
//     // Checks the contract:  equals-hashcode on var6 and var18
//     assertTrue("Contract failed: equals-hashcode on var6 and var18", var6.equals(var18) ? var6.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var6
//     assertTrue("Contract failed: equals-hashcode on var18 and var6", var18.equals(var6) ? var18.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }


    java.awt.Font var1 = null;
    org.jfree.chart.LegendItemSource var2 = null;
    org.jfree.chart.title.LegendTitle var3 = new org.jfree.chart.title.LegendTitle(var2);
    org.jfree.chart.util.RectangleEdge var4 = var3.getLegendItemGraphicEdge();
    java.awt.Paint var5 = var3.getItemPaint();
    java.awt.Paint var6 = var3.getItemPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextLine var7 = new org.jfree.chart.text.TextLine("", var1, var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test267() {}
//   public void test267() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var2 = null;
//     var0.setSeriesItemLabelsVisible(0, var2, false);
//     java.awt.Stroke var5 = var0.getErrorIndicatorStroke();
//     org.jfree.chart.plot.DrawingSupplier var6 = var0.getDrawingSupplier();
//     java.lang.Boolean var8 = var0.getSeriesCreateEntities(10);
//     java.awt.Paint var9 = var0.getBaseOutlinePaint();
//     java.awt.Graphics2D var10 = null;
//     org.jfree.data.category.CategoryDataset var11 = null;
//     org.jfree.chart.axis.CategoryAxis var12 = null;
//     org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var14 = null;
//     var13.setPlot(var14);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var11, var12, (org.jfree.chart.axis.ValueAxis)var13, var16);
//     org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var19 = null;
//     var18.setPlot(var19);
//     org.jfree.chart.axis.ValueAxis[] var21 = new org.jfree.chart.axis.ValueAxis[] { var18};
//     var17.setRangeAxes(var21);
//     java.awt.Paint var23 = var17.getDomainGridlinePaint();
//     float var24 = var17.getForegroundAlpha();
//     org.jfree.chart.axis.CategoryAxis var25 = new org.jfree.chart.axis.CategoryAxis();
//     var25.setMaximumCategoryLabelWidthRatio(0.95f);
//     org.jfree.chart.plot.CategoryMarker var28 = null;
//     java.awt.geom.Rectangle2D var29 = null;
//     var0.drawDomainMarker(var10, var17, var25, var28, var29);
// 
//   }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = null;
    var0.setSeriesItemLabelsVisible(0, var2, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var6 = null;
    var0.setSeriesToolTipGenerator(1, var6, false);
    double var9 = var0.getUpperClip();
    java.awt.Stroke var10 = var0.getBaseStroke();
    var0.setAutoPopulateSeriesStroke(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test269() {}
//   public void test269() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var3 = null;
//     var2.setPlot(var3);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
//     org.jfree.chart.LegendItemSource var7 = null;
//     org.jfree.chart.title.LegendTitle var8 = new org.jfree.chart.title.LegendTitle(var7);
//     org.jfree.chart.util.RectangleEdge var9 = var8.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var10 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var11 = var10.getNextOutlinePaint();
//     var8.setBackgroundPaint(var11);
//     var6.setOutlinePaint(var11);
//     org.jfree.data.category.CategoryDataset var14 = null;
//     org.jfree.chart.axis.CategoryAxis var15 = null;
//     org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var17 = null;
//     var16.setPlot(var17);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var19 = null;
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot(var14, var15, (org.jfree.chart.axis.ValueAxis)var16, var19);
//     org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var22 = null;
//     var21.setPlot(var22);
//     org.jfree.chart.axis.ValueAxis[] var24 = new org.jfree.chart.axis.ValueAxis[] { var21};
//     var20.setRangeAxes(var24);
//     var6.setParent((org.jfree.chart.plot.Plot)var20);
//     var20.setRangeCrosshairValue(10.0d, false);
//     org.jfree.chart.plot.PlotRenderingInfo var32 = null;
//     var20.handleClick((-123), 0, var32);
// 
//   }

  public void test270() {}
//   public void test270() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }
// 
// 
//     org.jfree.chart.block.BorderArrangement var0 = new org.jfree.chart.block.BorderArrangement();
//     org.jfree.chart.block.BlockContainer var1 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.util.RectangleInsets var2 = var1.getPadding();
//     var1.setHeight(10.0d);
//     java.awt.Graphics2D var5 = null;
//     org.jfree.chart.block.RectangleConstraint var8 = new org.jfree.chart.block.RectangleConstraint(0.0d, 0.0d);
//     org.jfree.chart.block.RectangleConstraint var9 = var8.toUnconstrainedWidth();
//     double var10 = var8.getHeight();
//     org.jfree.chart.block.LengthConstraintType var11 = var8.getWidthConstraintType();
//     org.jfree.chart.util.Size2D var12 = var0.arrange(var1, var5, var8);
//     org.jfree.chart.util.HorizontalAlignment var13 = null;
//     org.jfree.chart.LegendItemSource var14 = null;
//     org.jfree.chart.title.LegendTitle var15 = new org.jfree.chart.title.LegendTitle(var14);
//     org.jfree.chart.util.RectangleInsets var16 = var15.getItemLabelPadding();
//     org.jfree.chart.util.VerticalAlignment var17 = var15.getVerticalAlignment();
//     org.jfree.chart.block.ColumnArrangement var20 = new org.jfree.chart.block.ColumnArrangement(var13, var17, 0.0d, 2.0d);
//     org.jfree.chart.block.BlockContainer var21 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.util.RectangleInsets var22 = var21.getPadding();
//     java.awt.Graphics2D var23 = null;
//     org.jfree.chart.block.RectangleConstraint var26 = new org.jfree.chart.block.RectangleConstraint(0.0d, 0.0d);
//     org.jfree.chart.util.Size2D var27 = var20.arrange(var21, var23, var26);
//     org.jfree.chart.util.Size2D var28 = var8.calculateConstrainedSize(var27);
//     
//     // Checks the contract:  equals-hashcode on var12 and var27
//     assertTrue("Contract failed: equals-hashcode on var12 and var27", var12.equals(var27) ? var12.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var28
//     assertTrue("Contract failed: equals-hashcode on var12 and var28", var12.equals(var28) ? var12.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var12
//     assertTrue("Contract failed: equals-hashcode on var27 and var12", var27.equals(var12) ? var27.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var28
//     assertTrue("Contract failed: equals-hashcode on var27 and var28", var27.equals(var28) ? var27.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var12
//     assertTrue("Contract failed: equals-hashcode on var28 and var12", var28.equals(var12) ? var28.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var27
//     assertTrue("Contract failed: equals-hashcode on var28 and var27", var28.equals(var27) ? var28.hashCode() == var27.hashCode() : true);
// 
//   }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = var0.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var5 = var0.getPositiveItemLabelPosition(100, 0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var6 = var0.getLegendItemToolTipGenerator();
    var0.setItemLabelAnchorOffset(100.0d);
    org.jfree.chart.annotations.CategoryAnnotation var9 = null;
    boolean var10 = var0.removeAnnotation(var9);
    var0.setBaseSeriesVisible(true, true);
    java.awt.Paint var14 = var0.getErrorIndicatorPaint();
    org.jfree.chart.annotations.CategoryAnnotation var15 = null;
    org.jfree.chart.util.Layer var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var15, var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test272() {}
//   public void test272() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }
// 
// 
//     org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.util.Size2D var2 = var0.calculateDimensions(var1);
//     org.jfree.data.category.CategoryDataset var4 = null;
//     org.jfree.chart.axis.CategoryAxis var5 = null;
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var7 = null;
//     var6.setPlot(var7);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot(var4, var5, (org.jfree.chart.axis.ValueAxis)var6, var9);
//     java.awt.Stroke var11 = var6.getTickMarkStroke();
//     java.awt.Font var12 = var6.getLabelFont();
//     java.awt.Color var15 = java.awt.Color.getColor("", (-1));
//     var0.addLine("CategoryLabelEntity: category=null, tooltip=hi!, url=", var12, (java.awt.Paint)var15);
//     java.awt.Graphics2D var17 = null;
//     org.jfree.chart.util.Size2D var20 = new org.jfree.chart.util.Size2D();
//     boolean var22 = var20.equals((java.lang.Object)(-1L));
//     double var23 = var20.getWidth();
//     double var24 = var20.getHeight();
//     org.jfree.chart.util.RectangleAnchor var27 = null;
//     java.awt.geom.Rectangle2D var28 = org.jfree.chart.util.RectangleAnchor.createRectangle(var20, 2.0d, (-1.0d), var27);
//     org.jfree.chart.axis.CategoryLabelPositions var31 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var32 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var33 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var31, var32);
//     org.jfree.chart.util.RectangleAnchor var34 = var32.getCategoryAnchor();
//     java.awt.geom.Rectangle2D var35 = org.jfree.chart.util.RectangleAnchor.createRectangle(var20, 2.0d, 1.0d, var34);
//     org.jfree.chart.text.TextBlock var37 = new org.jfree.chart.text.TextBlock();
//     java.util.List var38 = var37.getLines();
//     org.jfree.chart.text.TextLine var39 = null;
//     var37.addLine(var39);
//     org.jfree.chart.util.HorizontalAlignment var41 = var37.getLineAlignment();
//     org.jfree.chart.axis.CategoryLabelPositions var42 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var43 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var44 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var42, var43);
//     float var45 = var43.getWidthRatio();
//     org.jfree.chart.text.TextBlockAnchor var46 = var43.getLabelAnchor();
//     java.awt.Graphics2D var48 = null;
//     org.jfree.chart.axis.CategoryLabelPositions var51 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var52 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var53 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var51, var52);
//     org.jfree.chart.text.TextAnchor var54 = var52.getRotationAnchor();
//     org.jfree.chart.labels.ItemLabelPosition var56 = new org.jfree.chart.labels.ItemLabelPosition();
//     org.jfree.chart.LegendItemSource var57 = null;
//     org.jfree.chart.title.LegendTitle var58 = new org.jfree.chart.title.LegendTitle(var57);
//     org.jfree.chart.util.RectangleEdge var59 = var58.getLegendItemGraphicEdge();
//     org.jfree.chart.util.RectangleEdge var60 = org.jfree.chart.util.RectangleEdge.opposite(var59);
//     boolean var61 = var56.equals((java.lang.Object)var60);
//     org.jfree.chart.labels.ItemLabelAnchor var62 = var56.getItemLabelAnchor();
//     org.jfree.chart.axis.CategoryLabelPositions var63 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var64 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var65 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var63, var64);
//     org.jfree.chart.text.TextAnchor var66 = var64.getRotationAnchor();
//     org.jfree.chart.labels.ItemLabelPosition var67 = new org.jfree.chart.labels.ItemLabelPosition(var62, var66);
//     org.jfree.chart.text.TextUtilities.drawRotatedString("", var48, 100.0f, 0.0f, var54, 100.0d, var66);
//     org.jfree.chart.axis.CategoryTick var70 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)(-1.0f), var37, var46, var66, 10.0d);
//     org.jfree.chart.axis.CategoryLabelPositions var71 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var72 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var73 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var71, var72);
//     float var74 = var72.getWidthRatio();
//     org.jfree.chart.text.TextBlockAnchor var75 = var72.getLabelAnchor();
//     org.jfree.chart.axis.CategoryLabelWidthType var76 = var72.getWidthType();
//     org.jfree.chart.axis.CategoryLabelPosition var78 = new org.jfree.chart.axis.CategoryLabelPosition(var34, var46, var76, (-1.0f));
//     java.awt.Shape var82 = var0.calculateBounds(var17, 0.0f, 2.0f, var46, 100.0f, (-1.0f), 0.05d);
// 
//   }

  public void test273() {}
//   public void test273() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var2 = var0.getSeriesItemLabelsVisible(100);
//     org.jfree.chart.labels.ItemLabelPosition var5 = var0.getPositiveItemLabelPosition(100, 0);
//     org.jfree.chart.urls.CategoryURLGenerator var6 = var0.getBaseURLGenerator();
//     java.lang.Boolean var8 = var0.getSeriesItemLabelsVisible((-855310));
//     org.jfree.data.category.CategoryDataset var9 = null;
//     org.jfree.chart.axis.CategoryAxis var10 = null;
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var12 = null;
//     var11.setPlot(var12);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var9, var10, (org.jfree.chart.axis.ValueAxis)var11, var14);
//     java.awt.Stroke var16 = var11.getTickMarkStroke();
//     var0.setBaseOutlineStroke(var16);
//     org.jfree.chart.labels.ItemLabelPosition var18 = var0.getBaseNegativeItemLabelPosition();
//     int var19 = var0.getPassCount();
//     var0.setSeriesCreateEntities(0, (java.lang.Boolean)false);
//     java.awt.Graphics2D var23 = null;
//     org.jfree.data.category.CategoryDataset var24 = null;
//     org.jfree.chart.axis.CategoryAxis var25 = null;
//     org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var27 = null;
//     var26.setPlot(var27);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var24, var25, (org.jfree.chart.axis.ValueAxis)var26, var29);
//     var30.setAnchorValue(0.0d, true);
//     org.jfree.chart.util.RectangleInsets var34 = var30.getAxisOffset();
//     org.jfree.chart.util.Layer var35 = null;
//     java.util.Collection var36 = var30.getDomainMarkers(var35);
//     org.jfree.data.category.CategoryDataset var37 = null;
//     org.jfree.chart.axis.CategoryAxis var38 = null;
//     org.jfree.chart.axis.NumberAxis var39 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var40 = null;
//     var39.setPlot(var40);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var42 = null;
//     org.jfree.chart.plot.CategoryPlot var43 = new org.jfree.chart.plot.CategoryPlot(var37, var38, (org.jfree.chart.axis.ValueAxis)var39, var42);
//     java.awt.Stroke var44 = var39.getTickMarkStroke();
//     java.awt.Font var45 = var39.getLabelFont();
//     float var46 = var39.getTickMarkInsideLength();
//     var39.setAutoRangeStickyZero(true);
//     org.jfree.chart.util.RectangleInsets var49 = var39.getTickLabelInsets();
//     org.jfree.chart.LegendItemSource var50 = null;
//     org.jfree.chart.title.LegendTitle var51 = new org.jfree.chart.title.LegendTitle(var50);
//     org.jfree.chart.util.RectangleInsets var52 = var51.getItemLabelPadding();
//     org.jfree.chart.LegendItemSource var53 = null;
//     org.jfree.chart.title.LegendTitle var54 = new org.jfree.chart.title.LegendTitle(var53);
//     org.jfree.chart.util.RectangleInsets var55 = var54.getItemLabelPadding();
//     double var56 = var55.getTop();
//     var51.setPadding(var55);
//     org.jfree.chart.util.Size2D var58 = new org.jfree.chart.util.Size2D();
//     boolean var60 = var58.equals((java.lang.Object)(-1L));
//     double var61 = var58.getWidth();
//     double var62 = var58.getHeight();
//     org.jfree.chart.util.RectangleAnchor var65 = null;
//     java.awt.geom.Rectangle2D var66 = org.jfree.chart.util.RectangleAnchor.createRectangle(var58, 2.0d, (-1.0d), var65);
//     org.jfree.chart.axis.CategoryLabelPositions var69 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var70 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var71 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var69, var70);
//     org.jfree.chart.util.RectangleAnchor var72 = var70.getCategoryAnchor();
//     java.awt.geom.Rectangle2D var73 = org.jfree.chart.util.RectangleAnchor.createRectangle(var58, 2.0d, 1.0d, var72);
//     java.awt.geom.Rectangle2D var74 = var55.createOutsetRectangle(var73);
//     var0.drawRangeGridline(var23, var30, (org.jfree.chart.axis.ValueAxis)var39, var73, 2.0d);
//     
//     // Checks the contract:  equals-hashcode on var15 and var30
//     assertTrue("Contract failed: equals-hashcode on var15 and var30", var15.equals(var30) ? var15.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var43
//     assertTrue("Contract failed: equals-hashcode on var15 and var43", var15.equals(var43) ? var15.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var15
//     assertTrue("Contract failed: equals-hashcode on var30 and var15", var30.equals(var15) ? var30.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var43
//     assertTrue("Contract failed: equals-hashcode on var30 and var43", var30.equals(var43) ? var30.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var15
//     assertTrue("Contract failed: equals-hashcode on var43 and var15", var43.equals(var15) ? var43.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var30
//     assertTrue("Contract failed: equals-hashcode on var43 and var30", var43.equals(var30) ? var43.hashCode() == var30.hashCode() : true);
// 
//   }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }


    java.awt.Color var4 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.0f);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var12 = new org.jfree.chart.entity.ChartEntity(var10, "Range[-1.0,-1.0]");
    org.jfree.chart.renderer.category.StatisticalBarRenderer var13 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var15 = null;
    var13.setSeriesItemLabelsVisible(0, var15, false);
    java.awt.Stroke var18 = var13.getErrorIndicatorStroke();
    java.awt.Paint var19 = null;
    org.jfree.chart.LegendItem var20 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var10, var18, var19);
    org.jfree.chart.plot.ValueMarker var21 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint)var4, var18);
    org.jfree.chart.text.TextAnchor var22 = var21.getLabelTextAnchor();
    org.jfree.chart.util.LengthAdjustmentType var23 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var21.setLabelOffsetType(var23);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }


    org.jfree.data.Range var3 = new org.jfree.data.Range(0.0d, 0.0d);
    org.jfree.data.Range var4 = null;
    org.jfree.data.Range var6 = org.jfree.data.Range.expandToInclude(var4, (-1.0d));
    org.jfree.data.Range var7 = null;
    org.jfree.data.Range var9 = org.jfree.data.Range.expandToInclude(var7, (-1.0d));
    org.jfree.data.Range var10 = org.jfree.data.Range.combine(var6, var9);
    java.lang.String var11 = var9.toString();
    double var12 = var9.getLowerBound();
    org.jfree.chart.block.RectangleConstraint var13 = new org.jfree.chart.block.RectangleConstraint(var3, var9);
    org.jfree.data.Range var16 = org.jfree.data.Range.shift(var9, 4.0d, true);
    org.jfree.chart.block.RectangleConstraint var17 = new org.jfree.chart.block.RectangleConstraint(0.0d, var16);
    org.jfree.chart.text.TextBlock var18 = new org.jfree.chart.text.TextBlock();
    java.util.List var19 = var18.getLines();
    org.jfree.chart.text.TextLine var20 = null;
    var18.addLine(var20);
    org.jfree.chart.util.HorizontalAlignment var22 = var18.getLineAlignment();
    org.jfree.chart.util.VerticalAlignment var23 = null;
    org.jfree.chart.block.ColumnArrangement var26 = new org.jfree.chart.block.ColumnArrangement(var22, var23, 1.0d, 100.0d);
    java.lang.String var27 = var22.toString();
    boolean var28 = var16.equals((java.lang.Object)var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "Range[-1.0,-1.0]"+ "'", var11.equals("Range[-1.0,-1.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + "HorizontalAlignment.CENTER"+ "'", var27.equals("HorizontalAlignment.CENTER"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);

  }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }


    org.jfree.chart.block.BorderArrangement var0 = new org.jfree.chart.block.BorderArrangement();
    org.jfree.chart.block.BlockContainer var1 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.util.RectangleInsets var2 = var1.getPadding();
    var1.setHeight(10.0d);
    java.awt.Graphics2D var5 = null;
    org.jfree.chart.block.RectangleConstraint var8 = new org.jfree.chart.block.RectangleConstraint(0.0d, 0.0d);
    org.jfree.chart.block.RectangleConstraint var9 = var8.toUnconstrainedWidth();
    double var10 = var8.getHeight();
    org.jfree.chart.block.LengthConstraintType var11 = var8.getWidthConstraintType();
    org.jfree.chart.util.Size2D var12 = var0.arrange(var1, var5, var8);
    org.jfree.chart.util.HorizontalAlignment var13 = null;
    org.jfree.chart.util.VerticalAlignment var14 = null;
    org.jfree.chart.block.FlowArrangement var17 = new org.jfree.chart.block.FlowArrangement(var13, var14, 0.0d, 0.0d);
    org.jfree.chart.block.BlockContainer var18 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var17);
    java.awt.Graphics2D var19 = null;
    org.jfree.chart.block.RectangleConstraint var22 = new org.jfree.chart.block.RectangleConstraint(0.0d, 1.0d);
    org.jfree.chart.block.RectangleConstraint var23 = var22.toUnconstrainedHeight();
    org.jfree.chart.util.Size2D var24 = var18.arrange(var19, var23);
    java.awt.Graphics2D var25 = null;
    org.jfree.chart.block.BlockContainer var26 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.util.RectangleInsets var27 = var26.getPadding();
    double var28 = var26.getWidth();
    java.awt.Graphics2D var29 = null;
    org.jfree.chart.block.RectangleConstraint var32 = new org.jfree.chart.block.RectangleConstraint(0.0d, 0.0d);
    org.jfree.data.Range var33 = null;
    org.jfree.data.Range var35 = org.jfree.data.Range.expandToInclude(var33, (-1.0d));
    org.jfree.data.Range var36 = null;
    org.jfree.data.Range var38 = org.jfree.data.Range.expandToInclude(var36, (-1.0d));
    org.jfree.data.Range var39 = org.jfree.data.Range.combine(var35, var38);
    double var40 = var38.getUpperBound();
    org.jfree.chart.block.RectangleConstraint var41 = var32.toRangeHeight(var38);
    org.jfree.chart.util.Size2D var42 = var26.arrange(var29, var41);
    org.jfree.chart.block.RectangleConstraint var43 = var41.toUnconstrainedWidth();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var44 = var0.arrange(var18, var25, var43);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);

  }

  public void test277() {}
//   public void test277() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }
// 
// 
//     org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.util.RectangleInsets var1 = var0.getPadding();
//     var0.setHeight(10.0d);
//     java.awt.Graphics2D var4 = null;
//     org.jfree.chart.ChartRenderingInfo var5 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var6 = new org.jfree.chart.plot.PlotRenderingInfo(var5);
//     java.lang.Object var7 = var6.clone();
//     org.jfree.chart.LegendItemSource var8 = null;
//     org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
//     org.jfree.chart.util.RectangleInsets var10 = var9.getItemLabelPadding();
//     double var12 = var10.calculateTopOutset(4.0d);
//     org.jfree.data.category.CategoryDataset var13 = null;
//     org.jfree.chart.axis.CategoryAxis var14 = null;
//     org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var16 = null;
//     var15.setPlot(var16);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var18 = null;
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot(var13, var14, (org.jfree.chart.axis.ValueAxis)var15, var18);
//     org.jfree.chart.LegendItemSource var20 = null;
//     org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle(var20);
//     org.jfree.chart.util.RectangleEdge var22 = var21.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var23 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var24 = var23.getNextOutlinePaint();
//     var21.setBackgroundPaint(var24);
//     var19.setOutlinePaint(var24);
//     org.jfree.data.category.CategoryDataset var27 = null;
//     org.jfree.chart.axis.CategoryAxis var28 = null;
//     org.jfree.chart.axis.NumberAxis var29 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var30 = null;
//     var29.setPlot(var30);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var32 = null;
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var27, var28, (org.jfree.chart.axis.ValueAxis)var29, var32);
//     org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var35 = null;
//     var34.setPlot(var35);
//     org.jfree.chart.axis.ValueAxis[] var37 = new org.jfree.chart.axis.ValueAxis[] { var34};
//     var33.setRangeAxes(var37);
//     var19.setParent((org.jfree.chart.plot.Plot)var33);
//     java.awt.Stroke var40 = var33.getRangeCrosshairStroke();
//     java.awt.Graphics2D var41 = null;
//     org.jfree.chart.LegendItemSource var42 = null;
//     org.jfree.chart.title.LegendTitle var43 = new org.jfree.chart.title.LegendTitle(var42);
//     org.jfree.chart.util.RectangleInsets var44 = var43.getItemLabelPadding();
//     org.jfree.chart.LegendItemSource var45 = null;
//     org.jfree.chart.title.LegendTitle var46 = new org.jfree.chart.title.LegendTitle(var45);
//     org.jfree.chart.util.RectangleInsets var47 = var46.getItemLabelPadding();
//     double var48 = var47.getTop();
//     var43.setPadding(var47);
//     org.jfree.chart.util.Size2D var50 = new org.jfree.chart.util.Size2D();
//     boolean var52 = var50.equals((java.lang.Object)(-1L));
//     double var53 = var50.getWidth();
//     double var54 = var50.getHeight();
//     org.jfree.chart.util.RectangleAnchor var57 = null;
//     java.awt.geom.Rectangle2D var58 = org.jfree.chart.util.RectangleAnchor.createRectangle(var50, 2.0d, (-1.0d), var57);
//     org.jfree.chart.axis.CategoryLabelPositions var61 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var62 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var63 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var61, var62);
//     org.jfree.chart.util.RectangleAnchor var64 = var62.getCategoryAnchor();
//     java.awt.geom.Rectangle2D var65 = org.jfree.chart.util.RectangleAnchor.createRectangle(var50, 2.0d, 1.0d, var64);
//     java.awt.geom.Rectangle2D var66 = var47.createOutsetRectangle(var65);
//     org.jfree.chart.plot.PlotRenderingInfo var68 = null;
//     boolean var69 = var33.render(var41, var66, 255, var68);
//     java.awt.geom.Rectangle2D var72 = var10.createInsetRectangle(var66, false, false);
//     var6.setDataArea(var66);
//     java.awt.geom.Rectangle2D var74 = var6.getDataArea();
//     java.awt.Shape var80 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
//     org.jfree.chart.entity.ChartEntity var82 = new org.jfree.chart.entity.ChartEntity(var80, "Range[-1.0,-1.0]");
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var83 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var85 = null;
//     var83.setSeriesItemLabelsVisible(0, var85, false);
//     java.awt.Stroke var88 = var83.getErrorIndicatorStroke();
//     java.awt.Paint var89 = null;
//     org.jfree.chart.LegendItem var90 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var80, var88, var89);
//     boolean var91 = var90.isLineVisible();
//     java.awt.Paint var92 = var90.getFillPaint();
//     java.lang.Object var93 = var0.draw(var4, var74, (java.lang.Object)var90);
// 
//   }

  public void test278() {}
//   public void test278() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }
// 
// 
//     org.jfree.chart.LegendItemSource var0 = null;
//     org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
//     org.jfree.chart.util.RectangleInsets var2 = var1.getItemLabelPadding();
//     org.jfree.chart.util.VerticalAlignment var3 = var1.getVerticalAlignment();
//     org.jfree.chart.block.BlockContainer var4 = var1.getItemContainer();
//     org.jfree.chart.LegendItemSource var5 = null;
//     org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle(var5);
//     org.jfree.chart.util.RectangleInsets var7 = var6.getItemLabelPadding();
//     double var9 = var7.calculateTopOutset(4.0d);
//     var4.setMargin(var7);
//     java.awt.Graphics2D var11 = null;
//     org.jfree.data.category.CategoryDataset var12 = null;
//     org.jfree.chart.axis.CategoryAxis var13 = null;
//     org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var15 = null;
//     var14.setPlot(var15);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var12, var13, (org.jfree.chart.axis.ValueAxis)var14, var17);
//     var18.setAnchorValue(0.0d, true);
//     org.jfree.chart.axis.CategoryAxis var22 = var18.getDomainAxis();
//     java.awt.Graphics2D var23 = null;
//     org.jfree.chart.LegendItemSource var24 = null;
//     org.jfree.chart.title.LegendTitle var25 = new org.jfree.chart.title.LegendTitle(var24);
//     org.jfree.chart.util.RectangleInsets var26 = var25.getItemLabelPadding();
//     org.jfree.chart.LegendItemSource var27 = null;
//     org.jfree.chart.title.LegendTitle var28 = new org.jfree.chart.title.LegendTitle(var27);
//     org.jfree.chart.util.RectangleInsets var29 = var28.getItemLabelPadding();
//     double var30 = var29.getTop();
//     var25.setPadding(var29);
//     org.jfree.chart.util.Size2D var32 = new org.jfree.chart.util.Size2D();
//     boolean var34 = var32.equals((java.lang.Object)(-1L));
//     double var35 = var32.getWidth();
//     double var36 = var32.getHeight();
//     org.jfree.chart.util.RectangleAnchor var39 = null;
//     java.awt.geom.Rectangle2D var40 = org.jfree.chart.util.RectangleAnchor.createRectangle(var32, 2.0d, (-1.0d), var39);
//     org.jfree.chart.axis.CategoryLabelPositions var43 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var44 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var45 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var43, var44);
//     org.jfree.chart.util.RectangleAnchor var46 = var44.getCategoryAnchor();
//     java.awt.geom.Rectangle2D var47 = org.jfree.chart.util.RectangleAnchor.createRectangle(var32, 2.0d, 1.0d, var46);
//     java.awt.geom.Rectangle2D var48 = var29.createOutsetRectangle(var47);
//     java.awt.geom.Point2D var49 = null;
//     org.jfree.chart.plot.PlotState var50 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var51 = null;
//     var18.draw(var23, var48, var49, var50, var51);
//     org.jfree.chart.entity.TickLabelEntity var55 = new org.jfree.chart.entity.TickLabelEntity((java.awt.Shape)var48, "hi!", "CategoryLabelEntity: category=null, tooltip=hi!, url=");
//     var4.draw(var11, var48);
// 
//   }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var4 = null;
    var3.setPlot(var4);
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var3, var6);
    org.jfree.chart.LegendItemSource var8 = null;
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
    org.jfree.chart.util.RectangleEdge var10 = var9.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var12 = var11.getNextOutlinePaint();
    var9.setBackgroundPaint(var12);
    var7.setOutlinePaint(var12);
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var7);
    java.lang.Object var16 = var15.clone();
    boolean var17 = var15.isNotify();
    org.jfree.data.category.CategoryDataset var18 = null;
    org.jfree.chart.axis.CategoryAxis var19 = null;
    org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var21 = null;
    var20.setPlot(var21);
    org.jfree.chart.renderer.category.CategoryItemRenderer var23 = null;
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot(var18, var19, (org.jfree.chart.axis.ValueAxis)var20, var23);
    java.awt.Stroke var25 = var20.getTickMarkStroke();
    var20.zoomRange((-1.0d), 100.0d);
    org.jfree.chart.block.BlockContainer var29 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.util.RectangleInsets var30 = var29.getPadding();
    double var32 = var30.calculateTopInset(100.0d);
    var20.setLabelInsets(var30);
    java.awt.Color var37 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.0f);
    var20.setTickLabelPaint((java.awt.Paint)var37);
    var15.setBorderPaint((java.awt.Paint)var37);
    var15.clearSubtitles();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test280() {}
//   public void test280() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var2 = null;
//     var0.setSeriesItemLabelsVisible(0, var2, false);
//     org.jfree.chart.labels.CategoryToolTipGenerator var6 = null;
//     var0.setSeriesToolTipGenerator(1, var6, false);
//     org.jfree.chart.urls.CategoryURLGenerator var9 = null;
//     var0.setBaseURLGenerator(var9);
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.plot.CategoryPlot var12 = null;
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     org.jfree.chart.plot.Marker var14 = null;
//     java.awt.geom.Rectangle2D var15 = null;
//     var0.drawRangeMarker(var11, var12, var13, var14, var15);
//     org.jfree.chart.urls.CategoryURLGenerator var17 = null;
//     var0.setBaseURLGenerator(var17, true);
//     org.jfree.data.statistics.MeanAndStandardDeviation var22 = new org.jfree.data.statistics.MeanAndStandardDeviation(100.0d, 0.0d);
//     boolean var24 = var22.equals((java.lang.Object)'a');
//     boolean var25 = var0.equals((java.lang.Object)var22);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var26 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var28 = var26.getSeriesItemLabelsVisible(100);
//     org.jfree.chart.labels.ItemLabelPosition var31 = var26.getPositiveItemLabelPosition(100, 0);
//     org.jfree.chart.urls.CategoryURLGenerator var32 = var26.getBaseURLGenerator();
//     java.lang.Boolean var34 = var26.getSeriesItemLabelsVisible((-855310));
//     org.jfree.data.category.CategoryDataset var35 = null;
//     org.jfree.chart.axis.CategoryAxis var36 = null;
//     org.jfree.chart.axis.NumberAxis var37 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var38 = null;
//     var37.setPlot(var38);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var40 = null;
//     org.jfree.chart.plot.CategoryPlot var41 = new org.jfree.chart.plot.CategoryPlot(var35, var36, (org.jfree.chart.axis.ValueAxis)var37, var40);
//     java.awt.Stroke var42 = var37.getTickMarkStroke();
//     var26.setBaseOutlineStroke(var42);
//     org.jfree.chart.labels.ItemLabelPosition var44 = var26.getBaseNegativeItemLabelPosition();
//     var0.setBasePositiveItemLabelPosition(var44, false);
//     org.jfree.chart.text.TextBlock var48 = new org.jfree.chart.text.TextBlock();
//     java.awt.Graphics2D var49 = null;
//     org.jfree.chart.util.Size2D var50 = var48.calculateDimensions(var49);
//     org.jfree.data.category.CategoryDataset var52 = null;
//     org.jfree.chart.axis.CategoryAxis var53 = null;
//     org.jfree.chart.axis.NumberAxis var54 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var55 = null;
//     var54.setPlot(var55);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var57 = null;
//     org.jfree.chart.plot.CategoryPlot var58 = new org.jfree.chart.plot.CategoryPlot(var52, var53, (org.jfree.chart.axis.ValueAxis)var54, var57);
//     java.awt.Stroke var59 = var54.getTickMarkStroke();
//     java.awt.Font var60 = var54.getLabelFont();
//     java.awt.Color var63 = java.awt.Color.getColor("", (-1));
//     var48.addLine("CategoryLabelEntity: category=null, tooltip=hi!, url=", var60, (java.awt.Paint)var63);
//     var0.setSeriesFillPaint(0, (java.awt.Paint)var63);
//     
//     // Checks the contract:  equals-hashcode on var41 and var58
//     assertTrue("Contract failed: equals-hashcode on var41 and var58", var41.equals(var58) ? var41.hashCode() == var58.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var58 and var41
//     assertTrue("Contract failed: equals-hashcode on var58 and var41", var58.equals(var41) ? var58.hashCode() == var41.hashCode() : true);
// 
//   }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var4 = null;
    var3.setPlot(var4);
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var3, var6);
    org.jfree.chart.LegendItemSource var8 = null;
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
    org.jfree.chart.util.RectangleEdge var10 = var9.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var12 = var11.getNextOutlinePaint();
    var9.setBackgroundPaint(var12);
    var7.setOutlinePaint(var12);
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var7);
    var15.fireChartChanged();
    var15.setTextAntiAlias(false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.XYPlot var19 = var15.getXYPlot();
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("CategoryLabelEntity: category=null, tooltip=hi!, url=", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }


    org.jfree.chart.text.TextBlock var1 = new org.jfree.chart.text.TextBlock();
    java.util.List var2 = var1.getLines();
    org.jfree.chart.text.TextLine var3 = null;
    var1.addLine(var3);
    org.jfree.chart.util.HorizontalAlignment var5 = var1.getLineAlignment();
    org.jfree.chart.text.TextBlockAnchor var6 = null;
    java.awt.Graphics2D var8 = null;
    org.jfree.chart.labels.ItemLabelPosition var11 = new org.jfree.chart.labels.ItemLabelPosition();
    org.jfree.chart.LegendItemSource var12 = null;
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle(var12);
    org.jfree.chart.util.RectangleEdge var14 = var13.getLegendItemGraphicEdge();
    org.jfree.chart.util.RectangleEdge var15 = org.jfree.chart.util.RectangleEdge.opposite(var14);
    boolean var16 = var11.equals((java.lang.Object)var15);
    org.jfree.chart.labels.ItemLabelAnchor var17 = var11.getItemLabelAnchor();
    org.jfree.chart.axis.CategoryLabelPositions var18 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var19 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var20 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var18, var19);
    org.jfree.chart.text.TextAnchor var21 = var19.getRotationAnchor();
    org.jfree.chart.labels.ItemLabelPosition var22 = new org.jfree.chart.labels.ItemLabelPosition(var17, var21);
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var8, 1.0f, (-1.0f), var21, 2.0d, 1.0f, 0.0f);
    org.jfree.chart.axis.CategoryTick var28 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)(byte)0, var1, var6, var21, 0.0d);
    org.jfree.chart.text.TextAnchor var29 = var28.getTextAnchor();
    java.lang.String var30 = var28.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + ""+ "'", var30.equals(""));

  }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var4 = null;
    var3.setPlot(var4);
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var3, var6);
    org.jfree.chart.LegendItemSource var8 = null;
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
    org.jfree.chart.util.RectangleEdge var10 = var9.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var12 = var11.getNextOutlinePaint();
    var9.setBackgroundPaint(var12);
    var7.setOutlinePaint(var12);
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var7);
    var15.fireChartChanged();
    var15.setTextAntiAlias(false);
    java.util.List var19 = var15.getSubtitles();
    org.jfree.chart.util.RectangleInsets var20 = var15.getPadding();
    org.jfree.chart.plot.CategoryPlot var21 = var15.getCategoryPlot();
    org.jfree.chart.renderer.category.BarRenderer var22 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var23 = var22.getBasePositiveItemLabelPosition();
    java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var35 = new org.jfree.chart.entity.ChartEntity(var33, "Range[-1.0,-1.0]");
    org.jfree.chart.renderer.category.StatisticalBarRenderer var36 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var38 = null;
    var36.setSeriesItemLabelsVisible(0, var38, false);
    java.awt.Stroke var41 = var36.getErrorIndicatorStroke();
    java.awt.Paint var42 = null;
    org.jfree.chart.LegendItem var43 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var33, var41, var42);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var44 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var45 = var44.getPositiveItemLabelPositionFallback();
    java.awt.Paint var48 = var44.getItemLabelPaint((-123), (-1));
    org.jfree.chart.LegendItem var49 = new org.jfree.chart.LegendItem("", "CategoryLabelEntity: category=null, tooltip=hi!, url=", "CategoryLabelEntity: category=null, tooltip=hi!, url=", "Range[-1.0,-1.0]", var33, var48);
    java.awt.Paint var50 = var49.getOutlinePaint();
    var22.setBasePaint(var50, true);
    var21.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var22, true);
    org.jfree.chart.axis.AxisLocation var55 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var21.setRangeAxisLocation(var55, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);

  }

  public void test286() {}
//   public void test286() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }
// 
// 
//     java.lang.Number[][] var2 = null;
//     org.jfree.data.category.CategoryDataset var3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("HorizontalAlignment.CENTER", "hi!", var2);
// 
//   }

  public void test287() {}
//   public void test287() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var2 = null;
//     var0.setSeriesItemLabelsVisible(0, var2, false);
//     java.awt.Stroke var5 = var0.getErrorIndicatorStroke();
//     org.jfree.chart.plot.DrawingSupplier var6 = var0.getDrawingSupplier();
//     java.lang.Boolean var8 = var0.getSeriesCreateEntities(10);
//     java.awt.Paint var9 = var0.getBaseOutlinePaint();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var10 = var0.getBaseItemLabelGenerator();
//     java.awt.Graphics2D var11 = null;
//     org.jfree.data.category.CategoryDataset var12 = null;
//     org.jfree.chart.axis.CategoryAxis var13 = null;
//     org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var15 = null;
//     var14.setPlot(var15);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var12, var13, (org.jfree.chart.axis.ValueAxis)var14, var17);
//     org.jfree.chart.LegendItemSource var19 = null;
//     org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle(var19);
//     org.jfree.chart.util.RectangleEdge var21 = var20.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var22 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var23 = var22.getNextOutlinePaint();
//     var20.setBackgroundPaint(var23);
//     var18.setOutlinePaint(var23);
//     org.jfree.chart.util.Size2D var26 = new org.jfree.chart.util.Size2D();
//     boolean var28 = var26.equals((java.lang.Object)(-1L));
//     double var29 = var26.getWidth();
//     double var30 = var26.getHeight();
//     org.jfree.chart.util.RectangleAnchor var33 = null;
//     java.awt.geom.Rectangle2D var34 = org.jfree.chart.util.RectangleAnchor.createRectangle(var26, 2.0d, (-1.0d), var33);
//     org.jfree.chart.axis.CategoryLabelPositions var37 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var38 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var39 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var37, var38);
//     org.jfree.chart.util.RectangleAnchor var40 = var38.getCategoryAnchor();
//     java.awt.geom.Rectangle2D var41 = org.jfree.chart.util.RectangleAnchor.createRectangle(var26, 2.0d, 1.0d, var40);
//     org.jfree.chart.entity.TickLabelEntity var44 = new org.jfree.chart.entity.TickLabelEntity((java.awt.Shape)var41, "Range[-1.0,-1.0]", "RectangleAnchor.CENTER");
//     var0.drawBackground(var11, var18, var41);
// 
//   }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }


    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var7 = new org.jfree.chart.entity.ChartEntity(var5, "Range[-1.0,-1.0]");
    org.jfree.chart.renderer.category.StatisticalBarRenderer var8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var10 = null;
    var8.setSeriesItemLabelsVisible(0, var10, false);
    java.awt.Stroke var13 = var8.getErrorIndicatorStroke();
    java.awt.Paint var14 = null;
    org.jfree.chart.LegendItem var15 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var5, var13, var14);
    boolean var16 = var15.isLineVisible();
    var15.setSeriesKey((java.lang.Comparable)0L);
    boolean var19 = var15.isShapeVisible();
    java.awt.Paint var20 = var15.getLinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);

  }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }


    org.jfree.chart.util.BooleanList var0 = new org.jfree.chart.util.BooleanList();
    org.jfree.chart.util.StandardGradientPaintTransformer var1 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    java.lang.Object var2 = var1.clone();
    org.jfree.chart.event.ChartChangeEvent var3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1);
    org.jfree.chart.event.ChartChangeEventType var4 = var3.getType();
    boolean var5 = var0.equals((java.lang.Object)var4);
    java.lang.String var6 = var4.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "ChartChangeEventType.GENERAL"+ "'", var6.equals("ChartChangeEventType.GENERAL"));

  }

  public void test290() {}
//   public void test290() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleAnchor.CENTER", var1, 0.0f, 1.0f, 3.0d, 0.0f, 0.95f);
// 
//   }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    boolean var7 = var6.isDomainZoomable();
    org.jfree.data.category.CategoryDataset var9 = var6.getDataset((-123));
    var6.clearRangeMarkers(0);
    int var12 = var6.getDatasetCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.mapDatasetToDomainAxis((-1), 255);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1);

  }

  public void test292() {}
//   public void test292() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var3 = null;
//     var2.setPlot(var3);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
//     java.awt.Stroke var7 = var2.getTickMarkStroke();
//     var2.zoomRange((-1.0d), 100.0d);
//     java.awt.Graphics2D var11 = null;
//     org.jfree.data.category.CategoryDataset var12 = null;
//     org.jfree.chart.axis.CategoryAxis var13 = null;
//     org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var15 = null;
//     var14.setPlot(var15);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var12, var13, (org.jfree.chart.axis.ValueAxis)var14, var17);
//     var18.setAnchorValue(0.0d, true);
//     org.jfree.chart.axis.CategoryAxis var22 = var18.getDomainAxis();
//     int var23 = var18.getWeight();
//     java.awt.geom.Rectangle2D var24 = null;
//     org.jfree.chart.LegendItemSource var25 = null;
//     org.jfree.chart.title.LegendTitle var26 = new org.jfree.chart.title.LegendTitle(var25);
//     org.jfree.chart.util.RectangleEdge var27 = var26.getLegendItemGraphicEdge();
//     org.jfree.chart.util.RectangleEdge var28 = org.jfree.chart.util.RectangleEdge.opposite(var27);
//     boolean var29 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var28);
//     org.jfree.chart.axis.AxisSpace var30 = new org.jfree.chart.axis.AxisSpace();
//     java.lang.Object var31 = var30.clone();
//     org.jfree.chart.axis.AxisCollection var32 = new org.jfree.chart.axis.AxisCollection();
//     java.util.List var33 = var32.getAxesAtTop();
//     boolean var34 = var30.equals((java.lang.Object)var32);
//     org.jfree.chart.axis.AxisSpace var35 = var2.reserveSpace(var11, (org.jfree.chart.plot.Plot)var18, var24, var28, var30);
// 
//   }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var4 = null;
    var3.setPlot(var4);
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var3, var6);
    org.jfree.chart.LegendItemSource var8 = null;
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
    org.jfree.chart.util.RectangleEdge var10 = var9.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var12 = var11.getNextOutlinePaint();
    var9.setBackgroundPaint(var12);
    var7.setOutlinePaint(var12);
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var7);
    var15.fireChartChanged();
    var15.setTextAntiAlias(false);
    org.jfree.chart.plot.CategoryPlot var19 = var15.getCategoryPlot();
    var19.clearRangeAxes();
    org.jfree.chart.block.LabelBlock var24 = new org.jfree.chart.block.LabelBlock("");
    java.awt.Font var25 = var24.getFont();
    java.awt.Color var29 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.95f);
    org.jfree.chart.text.TextBlock var30 = org.jfree.chart.text.TextUtilities.createTextBlock("CategoryLabelEntity: category=null, tooltip=hi!, url=", var25, (java.awt.Paint)var29);
    java.awt.Color var31 = java.awt.Color.getColor("CategoryLabelEntity: category=null, tooltip=hi!, url=", var29);
    var19.setDomainGridlinePaint((java.awt.Paint)var29);
    boolean var33 = var19.isRangeCrosshairLockedOnData();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = var0.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var5 = var0.getPositiveItemLabelPosition(100, 0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var6 = var0.getLegendItemToolTipGenerator();
    var0.setItemLabelAnchorOffset(100.0d);
    org.jfree.chart.annotations.CategoryAnnotation var9 = null;
    boolean var10 = var0.removeAnnotation(var9);
    var0.setBaseSeriesVisible(true, true);
    org.jfree.chart.labels.ItemLabelPosition var15 = new org.jfree.chart.labels.ItemLabelPosition();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesPositiveItemLabelPosition((-1), var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test295() {}
//   public void test295() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }
// 
// 
//     org.jfree.chart.LegendItemSource var0 = null;
//     org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
//     org.jfree.chart.util.RectangleInsets var2 = var1.getItemLabelPadding();
//     org.jfree.chart.util.VerticalAlignment var3 = var1.getVerticalAlignment();
//     org.jfree.chart.block.BlockContainer var4 = var1.getItemContainer();
//     org.jfree.chart.LegendItemSource var5 = null;
//     org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle(var5);
//     org.jfree.chart.util.RectangleInsets var7 = var6.getItemLabelPadding();
//     double var9 = var7.calculateTopOutset(4.0d);
//     var4.setMargin(var7);
//     java.awt.geom.Rectangle2D var11 = var4.getBounds();
//     java.awt.Graphics2D var12 = null;
//     org.jfree.chart.LegendItemSource var13 = null;
//     org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle(var13);
//     org.jfree.chart.util.RectangleInsets var15 = var14.getItemLabelPadding();
//     org.jfree.chart.util.VerticalAlignment var16 = var14.getVerticalAlignment();
//     org.jfree.chart.block.BlockContainer var17 = var14.getItemContainer();
//     org.jfree.chart.LegendItemSource var18 = null;
//     org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle(var18);
//     org.jfree.chart.util.RectangleInsets var20 = var19.getItemLabelPadding();
//     double var22 = var20.calculateTopOutset(4.0d);
//     var17.setMargin(var20);
//     java.awt.geom.Rectangle2D var24 = var17.getBounds();
//     org.jfree.chart.LegendItemSource var25 = null;
//     org.jfree.chart.title.LegendTitle var26 = new org.jfree.chart.title.LegendTitle(var25);
//     org.jfree.chart.util.RectangleInsets var27 = var26.getItemLabelPadding();
//     org.jfree.chart.util.RectangleAnchor var28 = var26.getLegendItemGraphicLocation();
//     java.awt.geom.Point2D var29 = org.jfree.chart.util.RectangleAnchor.coordinates(var24, var28);
//     org.jfree.chart.block.BlockContainer var30 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.util.RectangleInsets var31 = var30.getPadding();
//     double var32 = var30.getWidth();
//     java.awt.Graphics2D var33 = null;
//     org.jfree.chart.block.RectangleConstraint var36 = new org.jfree.chart.block.RectangleConstraint(0.0d, 0.0d);
//     org.jfree.data.Range var37 = null;
//     org.jfree.data.Range var39 = org.jfree.data.Range.expandToInclude(var37, (-1.0d));
//     org.jfree.data.Range var40 = null;
//     org.jfree.data.Range var42 = org.jfree.data.Range.expandToInclude(var40, (-1.0d));
//     org.jfree.data.Range var43 = org.jfree.data.Range.combine(var39, var42);
//     double var44 = var42.getUpperBound();
//     org.jfree.chart.block.RectangleConstraint var45 = var36.toRangeHeight(var42);
//     org.jfree.chart.util.Size2D var46 = var30.arrange(var33, var45);
//     java.lang.Object var47 = var4.draw(var12, var24, (java.lang.Object)var46);
// 
//   }

  public void test296() {}
//   public void test296() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }
// 
// 
//     org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();
//     java.util.List var1 = var0.getLines();
//     org.jfree.chart.text.TextLine var2 = null;
//     var0.addLine(var2);
//     java.awt.Graphics2D var4 = null;
//     org.jfree.chart.axis.CategoryLabelPositions var7 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var8 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var9 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var7, var8);
//     float var10 = var8.getWidthRatio();
//     org.jfree.chart.text.TextBlockAnchor var11 = var8.getLabelAnchor();
//     var0.draw(var4, 0.5f, 2.0f, var11);
// 
//   }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    java.awt.Stroke var7 = var2.getTickMarkStroke();
    var2.setNegativeArrowVisible(false);
    org.jfree.data.Range var10 = var2.getRange();
    var2.setAutoRange(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }


    java.awt.Graphics2D var1 = null;
    java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", var1, 2.0f, (-1.0f), 2.0d, (-1.0f), 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var4 = null;
    var3.setPlot(var4);
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var3, var6);
    org.jfree.chart.LegendItemSource var8 = null;
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
    org.jfree.chart.util.RectangleEdge var10 = var9.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var12 = var11.getNextOutlinePaint();
    var9.setBackgroundPaint(var12);
    var7.setOutlinePaint(var12);
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var7);
    var15.fireChartChanged();
    org.jfree.chart.plot.CategoryPlot var17 = var15.getCategoryPlot();
    boolean var18 = var15.getAntiAlias();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }


    org.jfree.chart.ui.ProjectInfo var0 = new org.jfree.chart.ui.ProjectInfo();
    java.lang.String var1 = var0.getLicenceText();
    java.util.List var2 = null;
    var0.setContributors(var2);
    java.awt.Image var4 = var0.getLogo();
    java.lang.String var5 = var0.getInfo();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var3 = var0.getStdDevValue(255, 255);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }


    java.awt.Color var4 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.0f);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var12 = new org.jfree.chart.entity.ChartEntity(var10, "Range[-1.0,-1.0]");
    org.jfree.chart.renderer.category.StatisticalBarRenderer var13 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var15 = null;
    var13.setSeriesItemLabelsVisible(0, var15, false);
    java.awt.Stroke var18 = var13.getErrorIndicatorStroke();
    java.awt.Paint var19 = null;
    org.jfree.chart.LegendItem var20 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var10, var18, var19);
    org.jfree.chart.plot.ValueMarker var21 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint)var4, var18);
    org.jfree.chart.text.TextAnchor var22 = var21.getLabelTextAnchor();
    org.jfree.chart.event.MarkerChangeEvent var23 = null;
    var21.notifyListeners(var23);
    java.awt.Paint var25 = var21.getLabelPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }


    java.awt.Color var4 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.0f);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var12 = new org.jfree.chart.entity.ChartEntity(var10, "Range[-1.0,-1.0]");
    org.jfree.chart.renderer.category.StatisticalBarRenderer var13 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var15 = null;
    var13.setSeriesItemLabelsVisible(0, var15, false);
    java.awt.Stroke var18 = var13.getErrorIndicatorStroke();
    java.awt.Paint var19 = null;
    org.jfree.chart.LegendItem var20 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var10, var18, var19);
    org.jfree.chart.plot.ValueMarker var21 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint)var4, var18);
    org.jfree.chart.text.TextAnchor var22 = var21.getLabelTextAnchor();
    org.jfree.chart.util.RectangleAnchor var23 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var21.setLabelAnchor(var23);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test304() {}
//   public void test304() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var3 = null;
//     var1.setSeriesItemLabelsVisible(0, var3, false);
//     java.awt.Stroke var6 = var1.getErrorIndicatorStroke();
//     org.jfree.chart.plot.DrawingSupplier var7 = var1.getDrawingSupplier();
//     java.lang.Boolean var9 = var1.getSeriesCreateEntities(10);
//     java.awt.Paint var10 = var1.getBaseOutlinePaint();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var14 = var12.getSeriesItemLabelsVisible(100);
//     org.jfree.chart.labels.ItemLabelPosition var17 = var12.getPositiveItemLabelPosition(100, 0);
//     org.jfree.chart.urls.CategoryURLGenerator var18 = var12.getBaseURLGenerator();
//     java.lang.Boolean var20 = var12.getSeriesItemLabelsVisible((-855310));
//     java.awt.Color var23 = java.awt.Color.getColor("", (-1));
//     var12.setBasePaint((java.awt.Paint)var23, true);
//     var1.setSeriesPaint(0, (java.awt.Paint)var23, false);
//     int var28 = var23.getRGB();
//     org.jfree.chart.LegendItemSource var29 = null;
//     org.jfree.chart.title.LegendTitle var30 = new org.jfree.chart.title.LegendTitle(var29);
//     org.jfree.chart.util.RectangleEdge var31 = var30.getLegendItemGraphicEdge();
//     java.awt.Paint var32 = var30.getItemPaint();
//     org.jfree.data.category.CategoryDataset var34 = null;
//     org.jfree.chart.axis.CategoryAxis var35 = null;
//     org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var37 = null;
//     var36.setPlot(var37);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var39 = null;
//     org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot(var34, var35, (org.jfree.chart.axis.ValueAxis)var36, var39);
//     org.jfree.chart.LegendItemSource var41 = null;
//     org.jfree.chart.title.LegendTitle var42 = new org.jfree.chart.title.LegendTitle(var41);
//     org.jfree.chart.util.RectangleEdge var43 = var42.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var44 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var45 = var44.getNextOutlinePaint();
//     var42.setBackgroundPaint(var45);
//     var40.setOutlinePaint(var45);
//     org.jfree.chart.JFreeChart var48 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var40);
//     var48.fireChartChanged();
//     boolean var50 = var48.getAntiAlias();
//     java.util.List var51 = var48.getSubtitles();
//     var30.addChangeListener((org.jfree.chart.event.TitleChangeListener)var48);
//     org.jfree.data.category.CategoryDataset var53 = null;
//     org.jfree.chart.axis.CategoryAxis var54 = null;
//     org.jfree.chart.axis.NumberAxis var55 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var56 = null;
//     var55.setPlot(var56);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var58 = null;
//     org.jfree.chart.plot.CategoryPlot var59 = new org.jfree.chart.plot.CategoryPlot(var53, var54, (org.jfree.chart.axis.ValueAxis)var55, var58);
//     var55.setAutoRangeMinimumSize(2.0d);
//     java.awt.geom.Rectangle2D var63 = null;
//     org.jfree.chart.util.RectangleEdge var64 = null;
//     double var65 = var55.java2DToValue(0.0d, var63, var64);
//     var55.setAutoTickUnitSelection(true);
//     java.awt.Stroke var68 = var55.getAxisLineStroke();
//     var48.setBorderStroke(var68);
//     org.jfree.chart.plot.ValueMarker var70 = new org.jfree.chart.plot.ValueMarker(Double.NaN, (java.awt.Paint)var23, var68);
//     java.awt.Paint var71 = var70.getPaint();
//     java.awt.Paint var72 = var70.getPaint();
//     double var73 = var70.getValue();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var74 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var75 = var74.getPositiveItemLabelPositionFallback();
//     java.awt.Paint var78 = var74.getItemLabelPaint((-123), (-1));
//     org.jfree.data.category.CategoryDataset var79 = null;
//     org.jfree.chart.axis.CategoryAxis var80 = null;
//     org.jfree.chart.axis.NumberAxis var81 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var82 = null;
//     var81.setPlot(var82);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var84 = null;
//     org.jfree.chart.plot.CategoryPlot var85 = new org.jfree.chart.plot.CategoryPlot(var79, var80, (org.jfree.chart.axis.ValueAxis)var81, var84);
//     java.awt.Stroke var86 = var81.getTickMarkStroke();
//     org.jfree.chart.LegendItemSource var87 = null;
//     org.jfree.chart.title.LegendTitle var88 = new org.jfree.chart.title.LegendTitle(var87);
//     org.jfree.chart.util.RectangleInsets var89 = var88.getItemLabelPadding();
//     double var90 = var89.getTop();
//     org.jfree.chart.block.LineBorder var91 = new org.jfree.chart.block.LineBorder(var78, var86, var89);
//     var70.setOutlineStroke(var86);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var74 and var1.", var74.equals(var1) == var1.equals(var74));
// 
//   }

  public void test305() {}
//   public void test305() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }
// 
// 
//     org.jfree.chart.block.LabelBlock var2 = new org.jfree.chart.block.LabelBlock("");
//     boolean var4 = var2.equals((java.lang.Object)' ');
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
//     boolean var6 = var5.isNegativeArrowVisible();
//     java.lang.String var7 = var5.getLabelURL();
//     var5.setLabelAngle(6.0d);
//     var5.setAutoRange(false);
//     java.awt.Font var12 = var5.getTickLabelFont();
//     var2.setFont(var12);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var15 = var14.getPositiveItemLabelPositionFallback();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var16 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var17 = var16.getPositiveItemLabelPositionFallback();
//     java.awt.Paint var20 = var16.getItemLabelPaint((-123), (-1));
//     org.jfree.data.category.CategoryDataset var21 = null;
//     org.jfree.chart.axis.CategoryAxis var22 = null;
//     org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var24 = null;
//     var23.setPlot(var24);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var26 = null;
//     org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot(var21, var22, (org.jfree.chart.axis.ValueAxis)var23, var26);
//     java.awt.Stroke var28 = var23.getTickMarkStroke();
//     org.jfree.chart.LegendItemSource var29 = null;
//     org.jfree.chart.title.LegendTitle var30 = new org.jfree.chart.title.LegendTitle(var29);
//     org.jfree.chart.util.RectangleInsets var31 = var30.getItemLabelPadding();
//     double var32 = var31.getTop();
//     org.jfree.chart.block.LineBorder var33 = new org.jfree.chart.block.LineBorder(var20, var28, var31);
//     var14.setBaseOutlinePaint(var20);
//     java.awt.Paint var35 = var14.getBaseFillPaint();
//     org.jfree.chart.LegendItemSource var36 = null;
//     org.jfree.chart.title.LegendTitle var37 = new org.jfree.chart.title.LegendTitle(var36);
//     org.jfree.chart.util.RectangleEdge var38 = var37.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var39 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var40 = var39.getNextOutlinePaint();
//     var37.setBackgroundPaint(var40);
//     org.jfree.chart.text.TextBlock var42 = new org.jfree.chart.text.TextBlock();
//     java.util.List var43 = var42.getLines();
//     boolean var44 = var37.equals((java.lang.Object)var42);
//     org.jfree.chart.util.RectangleEdge var45 = var37.getLegendItemGraphicEdge();
//     org.jfree.chart.LegendItemSource var46 = null;
//     org.jfree.chart.title.LegendTitle var47 = new org.jfree.chart.title.LegendTitle(var46);
//     org.jfree.chart.util.RectangleEdge var48 = var47.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var49 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var50 = var49.getNextOutlinePaint();
//     var47.setBackgroundPaint(var50);
//     org.jfree.chart.text.TextBlock var52 = new org.jfree.chart.text.TextBlock();
//     java.util.List var53 = var52.getLines();
//     boolean var54 = var47.equals((java.lang.Object)var52);
//     org.jfree.chart.util.RectangleEdge var55 = var47.getLegendItemGraphicEdge();
//     org.jfree.chart.block.BlockContainer var56 = new org.jfree.chart.block.BlockContainer();
//     var47.setWrapper(var56);
//     org.jfree.chart.util.HorizontalAlignment var58 = var47.getHorizontalAlignment();
//     org.jfree.chart.util.VerticalAlignment var59 = null;
//     org.jfree.chart.block.FlowArrangement var62 = new org.jfree.chart.block.FlowArrangement(var58, var59, (-8.0d), (-1.0d));
//     org.jfree.chart.LegendItemSource var63 = null;
//     org.jfree.chart.title.LegendTitle var64 = new org.jfree.chart.title.LegendTitle(var63);
//     org.jfree.chart.util.RectangleInsets var65 = var64.getItemLabelPadding();
//     org.jfree.chart.util.VerticalAlignment var66 = var64.getVerticalAlignment();
//     org.jfree.chart.LegendItemSource var67 = null;
//     org.jfree.chart.title.LegendTitle var68 = new org.jfree.chart.title.LegendTitle(var67);
//     org.jfree.chart.util.RectangleInsets var69 = var68.getItemLabelPadding();
//     double var71 = var69.calculateLeftInset(2.0d);
//     double var73 = var69.calculateBottomInset(6.0d);
//     org.jfree.chart.title.TextTitle var74 = new org.jfree.chart.title.TextTitle("CategoryLabelEntity: category=null, tooltip=hi!, url=", var12, var35, var45, var58, var66, var69);
//     
//     // Checks the contract:  equals-hashcode on var39 and var49
//     assertTrue("Contract failed: equals-hashcode on var39 and var49", var39.equals(var49) ? var39.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var39
//     assertTrue("Contract failed: equals-hashcode on var49 and var39", var49.equals(var39) ? var49.hashCode() == var39.hashCode() : true);
// 
//   }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var1 = null;
    var0.setBaseURLGenerator(var1);
    org.jfree.chart.labels.CategoryItemLabelGenerator var4 = null;
    var0.setSeriesItemLabelGenerator(100, var4, true);
    int var7 = var0.getPassCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = null;
    var0.setSeriesItemLabelsVisible(0, var2, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var6 = null;
    var0.setSeriesToolTipGenerator(1, var6, false);
    org.jfree.chart.urls.CategoryURLGenerator var9 = null;
    var0.setBaseURLGenerator(var9);
    var0.setAutoPopulateSeriesOutlineStroke(true);

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var7 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var8 = var7.getPositiveItemLabelPositionFallback();
    java.awt.Paint var11 = var7.getItemLabelPaint((-123), (-1));
    org.jfree.data.category.CategoryDataset var12 = null;
    org.jfree.chart.axis.CategoryAxis var13 = null;
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var15 = null;
    var14.setPlot(var15);
    org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var12, var13, (org.jfree.chart.axis.ValueAxis)var14, var17);
    java.awt.Stroke var19 = var14.getTickMarkStroke();
    org.jfree.chart.LegendItemSource var20 = null;
    org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle(var20);
    org.jfree.chart.util.RectangleInsets var22 = var21.getItemLabelPadding();
    double var23 = var22.getTop();
    org.jfree.chart.block.LineBorder var24 = new org.jfree.chart.block.LineBorder(var11, var19, var22);
    var6.setAxisOffset(var22);
    org.jfree.chart.axis.AxisSpace var26 = var6.getFixedDomainAxisSpace();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);

  }

  public void test309() {}
//   public void test309() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }
// 
// 
//     org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("");
//     java.awt.Graphics2D var2 = null;
//     java.awt.Graphics2D var4 = null;
//     org.jfree.chart.axis.CategoryLabelPositions var7 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var8 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var9 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var7, var8);
//     org.jfree.chart.text.TextAnchor var10 = var8.getRotationAnchor();
//     org.jfree.chart.labels.ItemLabelPosition var12 = new org.jfree.chart.labels.ItemLabelPosition();
//     org.jfree.chart.LegendItemSource var13 = null;
//     org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle(var13);
//     org.jfree.chart.util.RectangleEdge var15 = var14.getLegendItemGraphicEdge();
//     org.jfree.chart.util.RectangleEdge var16 = org.jfree.chart.util.RectangleEdge.opposite(var15);
//     boolean var17 = var12.equals((java.lang.Object)var16);
//     org.jfree.chart.labels.ItemLabelAnchor var18 = var12.getItemLabelAnchor();
//     org.jfree.chart.axis.CategoryLabelPositions var19 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var20 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var21 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var19, var20);
//     org.jfree.chart.text.TextAnchor var22 = var20.getRotationAnchor();
//     org.jfree.chart.labels.ItemLabelPosition var23 = new org.jfree.chart.labels.ItemLabelPosition(var18, var22);
//     org.jfree.chart.text.TextUtilities.drawRotatedString("", var4, 100.0f, 0.0f, var10, 100.0d, var22);
//     org.jfree.chart.LegendItemSource var25 = null;
//     org.jfree.chart.title.LegendTitle var26 = new org.jfree.chart.title.LegendTitle(var25);
//     org.jfree.chart.util.RectangleEdge var27 = var26.getLegendItemGraphicEdge();
//     java.awt.Paint var28 = var26.getItemPaint();
//     var26.setNotify(true);
//     java.awt.geom.Rectangle2D var31 = var26.getBounds();
//     boolean var32 = var22.equals((java.lang.Object)var31);
//     float var33 = var1.calculateBaselineOffset(var2, var22);
// 
//   }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = null;
    var0.setSeriesItemLabelsVisible(0, var2, false);
    java.awt.Stroke var5 = var0.getErrorIndicatorStroke();
    org.jfree.chart.plot.DrawingSupplier var6 = var0.getDrawingSupplier();
    java.lang.Boolean var8 = var0.getSeriesCreateEntities(10);
    var0.setAutoPopulateSeriesOutlineStroke(true);
    java.awt.Paint var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelPaint((-1), var12, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test311() {}
//   public void test311() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var3 = null;
//     var1.setSeriesItemLabelsVisible(0, var3, false);
//     java.awt.Stroke var6 = var1.getErrorIndicatorStroke();
//     org.jfree.chart.plot.DrawingSupplier var7 = var1.getDrawingSupplier();
//     java.lang.Boolean var9 = var1.getSeriesCreateEntities(10);
//     java.awt.Paint var10 = var1.getBaseOutlinePaint();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var14 = var12.getSeriesItemLabelsVisible(100);
//     org.jfree.chart.labels.ItemLabelPosition var17 = var12.getPositiveItemLabelPosition(100, 0);
//     org.jfree.chart.urls.CategoryURLGenerator var18 = var12.getBaseURLGenerator();
//     java.lang.Boolean var20 = var12.getSeriesItemLabelsVisible((-855310));
//     java.awt.Color var23 = java.awt.Color.getColor("", (-1));
//     var12.setBasePaint((java.awt.Paint)var23, true);
//     var1.setSeriesPaint(0, (java.awt.Paint)var23, false);
//     int var28 = var23.getRGB();
//     org.jfree.chart.LegendItemSource var29 = null;
//     org.jfree.chart.title.LegendTitle var30 = new org.jfree.chart.title.LegendTitle(var29);
//     org.jfree.chart.util.RectangleEdge var31 = var30.getLegendItemGraphicEdge();
//     java.awt.Paint var32 = var30.getItemPaint();
//     org.jfree.data.category.CategoryDataset var34 = null;
//     org.jfree.chart.axis.CategoryAxis var35 = null;
//     org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var37 = null;
//     var36.setPlot(var37);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var39 = null;
//     org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot(var34, var35, (org.jfree.chart.axis.ValueAxis)var36, var39);
//     org.jfree.chart.LegendItemSource var41 = null;
//     org.jfree.chart.title.LegendTitle var42 = new org.jfree.chart.title.LegendTitle(var41);
//     org.jfree.chart.util.RectangleEdge var43 = var42.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var44 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var45 = var44.getNextOutlinePaint();
//     var42.setBackgroundPaint(var45);
//     var40.setOutlinePaint(var45);
//     org.jfree.chart.JFreeChart var48 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var40);
//     var48.fireChartChanged();
//     boolean var50 = var48.getAntiAlias();
//     java.util.List var51 = var48.getSubtitles();
//     var30.addChangeListener((org.jfree.chart.event.TitleChangeListener)var48);
//     org.jfree.data.category.CategoryDataset var53 = null;
//     org.jfree.chart.axis.CategoryAxis var54 = null;
//     org.jfree.chart.axis.NumberAxis var55 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var56 = null;
//     var55.setPlot(var56);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var58 = null;
//     org.jfree.chart.plot.CategoryPlot var59 = new org.jfree.chart.plot.CategoryPlot(var53, var54, (org.jfree.chart.axis.ValueAxis)var55, var58);
//     var55.setAutoRangeMinimumSize(2.0d);
//     java.awt.geom.Rectangle2D var63 = null;
//     org.jfree.chart.util.RectangleEdge var64 = null;
//     double var65 = var55.java2DToValue(0.0d, var63, var64);
//     var55.setAutoTickUnitSelection(true);
//     java.awt.Stroke var68 = var55.getAxisLineStroke();
//     var48.setBorderStroke(var68);
//     org.jfree.chart.plot.ValueMarker var70 = new org.jfree.chart.plot.ValueMarker(Double.NaN, (java.awt.Paint)var23, var68);
//     java.awt.Color var75 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.0f);
//     java.awt.Shape var81 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
//     org.jfree.chart.entity.ChartEntity var83 = new org.jfree.chart.entity.ChartEntity(var81, "Range[-1.0,-1.0]");
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var84 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var86 = null;
//     var84.setSeriesItemLabelsVisible(0, var86, false);
//     java.awt.Stroke var89 = var84.getErrorIndicatorStroke();
//     java.awt.Paint var90 = null;
//     org.jfree.chart.LegendItem var91 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var81, var89, var90);
//     org.jfree.chart.plot.ValueMarker var92 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint)var75, var89);
//     var70.setOutlineStroke(var89);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var84 and var1.", var84.equals(var1) == var1.equals(var84));
// 
//   }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }


    org.jfree.chart.util.Size2D var0 = new org.jfree.chart.util.Size2D();
    boolean var2 = var0.equals((java.lang.Object)(-1L));
    double var3 = var0.getWidth();
    double var4 = var0.getHeight();
    org.jfree.chart.util.RectangleAnchor var7 = null;
    java.awt.geom.Rectangle2D var8 = org.jfree.chart.util.RectangleAnchor.createRectangle(var0, 2.0d, (-1.0d), var7);
    org.jfree.chart.axis.CategoryLabelPositions var11 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var12 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var13 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var11, var12);
    org.jfree.chart.util.RectangleAnchor var14 = var12.getCategoryAnchor();
    java.awt.geom.Rectangle2D var15 = org.jfree.chart.util.RectangleAnchor.createRectangle(var0, 2.0d, 1.0d, var14);
    org.jfree.chart.entity.TickLabelEntity var18 = new org.jfree.chart.entity.TickLabelEntity((java.awt.Shape)var15, "Range[-1.0,-1.0]", "RectangleAnchor.CENTER");
    java.lang.String var19 = var18.getToolTipText();
    java.awt.Shape var20 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var18.setArea(var20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "Range[-1.0,-1.0]"+ "'", var19.equals("Range[-1.0,-1.0]"));

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = var0.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var5 = var0.getPositiveItemLabelPosition(100, 0);
    org.jfree.chart.urls.CategoryURLGenerator var6 = var0.getBaseURLGenerator();
    java.lang.Boolean var8 = var0.getSeriesItemLabelsVisible((-855310));
    org.jfree.data.category.CategoryDataset var9 = null;
    org.jfree.chart.axis.CategoryAxis var10 = null;
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var12 = null;
    var11.setPlot(var12);
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var9, var10, (org.jfree.chart.axis.ValueAxis)var11, var14);
    java.awt.Stroke var16 = var11.getTickMarkStroke();
    var0.setBaseOutlineStroke(var16);
    org.jfree.chart.labels.ItemLabelPosition var18 = var0.getBaseNegativeItemLabelPosition();
    double var19 = var0.getItemLabelAnchorOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 2.0d);

  }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }


    org.jfree.data.Range var0 = null;
    org.jfree.data.Range var2 = org.jfree.data.Range.expandToInclude(var0, (-1.0d));
    org.jfree.data.Range var4 = org.jfree.data.Range.expandToInclude(var0, 10.0d);
    double var5 = var4.getLength();
    double var6 = var4.getLength();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Color var1 = java.awt.Color.decode("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
      fail("Expected exception of type java.lang.NumberFormatException");
    } catch (java.lang.NumberFormatException e) {
      // Expected exception.
    }

  }

  public void test316() {}
//   public void test316() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(var0);
// 
//   }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.util.RectangleInsets var1 = var0.getPadding();
    double var2 = var0.getWidth();
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.block.RectangleConstraint var6 = new org.jfree.chart.block.RectangleConstraint(0.0d, 0.0d);
    org.jfree.data.Range var7 = null;
    org.jfree.data.Range var9 = org.jfree.data.Range.expandToInclude(var7, (-1.0d));
    org.jfree.data.Range var10 = null;
    org.jfree.data.Range var12 = org.jfree.data.Range.expandToInclude(var10, (-1.0d));
    org.jfree.data.Range var13 = org.jfree.data.Range.combine(var9, var12);
    double var14 = var12.getUpperBound();
    org.jfree.chart.block.RectangleConstraint var15 = var6.toRangeHeight(var12);
    org.jfree.chart.util.Size2D var16 = var0.arrange(var3, var15);
    org.jfree.chart.block.RectangleConstraint var17 = var15.toUnconstrainedWidth();
    org.jfree.chart.block.RectangleConstraint var19 = var15.toFixedWidth(100.0d);
    org.jfree.data.Range var20 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.RectangleConstraint var21 = var15.toRangeWidth(var20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }


    org.jfree.data.KeyedValues var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.CategoryDataset var2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable)"CategoryLabelEntity: category=null, tooltip=hi!, url=", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test319() {}
//   public void test319() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var4 = null;
//     var3.setPlot(var4);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var3, var6);
//     org.jfree.chart.LegendItemSource var8 = null;
//     org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
//     org.jfree.chart.util.RectangleEdge var10 = var9.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var12 = var11.getNextOutlinePaint();
//     var9.setBackgroundPaint(var12);
//     var7.setOutlinePaint(var12);
//     org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var7);
//     java.lang.Object var16 = var15.clone();
//     boolean var17 = var15.isNotify();
//     java.awt.RenderingHints var18 = null;
//     var15.setRenderingHints(var18);
// 
//   }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }


    org.jfree.chart.axis.CategoryLabelPositions var0 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var1 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var2 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var0, var1);
    org.jfree.chart.text.TextAnchor var3 = var1.getRotationAnchor();
    org.jfree.chart.axis.CategoryLabelPositions var4 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var5 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var6 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var4, var5);
    org.jfree.chart.util.RectangleAnchor var7 = var5.getCategoryAnchor();
    org.jfree.chart.axis.CategoryLabelPositions var8 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var9 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var10 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var8, var9);
    org.jfree.chart.text.TextAnchor var11 = var9.getRotationAnchor();
    boolean var13 = var9.equals((java.lang.Object)6.0d);
    org.jfree.chart.axis.CategoryLabelPosition var14 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.text.TextAnchor var15 = var14.getRotationAnchor();
    org.jfree.chart.axis.CategoryLabelPositions var16 = new org.jfree.chart.axis.CategoryLabelPositions(var1, var5, var9, var14);
    float var17 = var14.getWidthRatio();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.95f);

  }

  public void test321() {}
//   public void test321() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("CategoryLabelEntity: category=null, tooltip=hi!, url=", var1);
// 
//   }

  public void test322() {}
//   public void test322() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }
// 
// 
//     org.jfree.data.Range var0 = null;
//     org.jfree.data.Range var2 = org.jfree.data.Range.expandToInclude(var0, (-1.0d));
//     double var4 = var2.constrain(Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test323() {}
//   public void test323() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }
// 
// 
//     java.text.AttributedString var0 = null;
//     java.awt.Shape var4 = null;
//     java.awt.Color var9 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.0f);
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
//     org.jfree.chart.entity.ChartEntity var17 = new org.jfree.chart.entity.ChartEntity(var15, "Range[-1.0,-1.0]");
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var18 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var20 = null;
//     var18.setSeriesItemLabelsVisible(0, var20, false);
//     java.awt.Stroke var23 = var18.getErrorIndicatorStroke();
//     java.awt.Paint var24 = null;
//     org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var15, var23, var24);
//     org.jfree.chart.plot.ValueMarker var26 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint)var9, var23);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var28 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var30 = null;
//     var28.setSeriesItemLabelsVisible(0, var30, false);
//     java.awt.Stroke var33 = var28.getErrorIndicatorStroke();
//     org.jfree.chart.plot.DrawingSupplier var34 = var28.getDrawingSupplier();
//     java.lang.Boolean var36 = var28.getSeriesCreateEntities(10);
//     java.awt.Paint var37 = var28.getBaseOutlinePaint();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var39 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var41 = var39.getSeriesItemLabelsVisible(100);
//     org.jfree.chart.labels.ItemLabelPosition var44 = var39.getPositiveItemLabelPosition(100, 0);
//     org.jfree.chart.urls.CategoryURLGenerator var45 = var39.getBaseURLGenerator();
//     java.lang.Boolean var47 = var39.getSeriesItemLabelsVisible((-855310));
//     java.awt.Color var50 = java.awt.Color.getColor("", (-1));
//     var39.setBasePaint((java.awt.Paint)var50, true);
//     var28.setSeriesPaint(0, (java.awt.Paint)var50, false);
//     int var55 = var50.getRGB();
//     org.jfree.chart.LegendItemSource var56 = null;
//     org.jfree.chart.title.LegendTitle var57 = new org.jfree.chart.title.LegendTitle(var56);
//     org.jfree.chart.util.RectangleEdge var58 = var57.getLegendItemGraphicEdge();
//     java.awt.Paint var59 = var57.getItemPaint();
//     org.jfree.data.category.CategoryDataset var61 = null;
//     org.jfree.chart.axis.CategoryAxis var62 = null;
//     org.jfree.chart.axis.NumberAxis var63 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var64 = null;
//     var63.setPlot(var64);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var66 = null;
//     org.jfree.chart.plot.CategoryPlot var67 = new org.jfree.chart.plot.CategoryPlot(var61, var62, (org.jfree.chart.axis.ValueAxis)var63, var66);
//     org.jfree.chart.LegendItemSource var68 = null;
//     org.jfree.chart.title.LegendTitle var69 = new org.jfree.chart.title.LegendTitle(var68);
//     org.jfree.chart.util.RectangleEdge var70 = var69.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var71 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var72 = var71.getNextOutlinePaint();
//     var69.setBackgroundPaint(var72);
//     var67.setOutlinePaint(var72);
//     org.jfree.chart.JFreeChart var75 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var67);
//     var75.fireChartChanged();
//     boolean var77 = var75.getAntiAlias();
//     java.util.List var78 = var75.getSubtitles();
//     var57.addChangeListener((org.jfree.chart.event.TitleChangeListener)var75);
//     org.jfree.data.category.CategoryDataset var80 = null;
//     org.jfree.chart.axis.CategoryAxis var81 = null;
//     org.jfree.chart.axis.NumberAxis var82 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var83 = null;
//     var82.setPlot(var83);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var85 = null;
//     org.jfree.chart.plot.CategoryPlot var86 = new org.jfree.chart.plot.CategoryPlot(var80, var81, (org.jfree.chart.axis.ValueAxis)var82, var85);
//     var82.setAutoRangeMinimumSize(2.0d);
//     java.awt.geom.Rectangle2D var90 = null;
//     org.jfree.chart.util.RectangleEdge var91 = null;
//     double var92 = var82.java2DToValue(0.0d, var90, var91);
//     var82.setAutoTickUnitSelection(true);
//     java.awt.Stroke var95 = var82.getAxisLineStroke();
//     var75.setBorderStroke(var95);
//     org.jfree.chart.plot.ValueMarker var97 = new org.jfree.chart.plot.ValueMarker(Double.NaN, (java.awt.Paint)var50, var95);
//     java.awt.Paint var98 = var97.getPaint();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.chart.LegendItem var99 = new org.jfree.chart.LegendItem(var0, "Range[-1.0,-1.0]", "CategoryLabelEntity: category=null, tooltip=hi!, url=", "java.awt.Color[r=242,g=242,b=242]", var4, var23, var98);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var70);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var72);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var77 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var78);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var92 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var95);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var98);
// 
//   }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.util.RectangleInsets var1 = var0.getPadding();
    double var3 = var1.calculateTopInset(100.0d);
    double var5 = var1.calculateTopInset(2.0d);
    double var6 = var1.getLeft();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.util.RectangleInsets var1 = var0.getPadding();
    org.jfree.chart.util.HorizontalAlignment var2 = null;
    org.jfree.chart.util.VerticalAlignment var3 = null;
    org.jfree.chart.block.FlowArrangement var6 = new org.jfree.chart.block.FlowArrangement(var2, var3, 0.0d, 0.0d);
    var0.setArrangement((org.jfree.chart.block.Arrangement)var6);
    var6.clear();
    var6.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTickUnit var2 = new org.jfree.chart.axis.NumberTickUnit(1.0E-8d, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test327() {}
//   public void test327() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }
// 
// 
//     org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.util.RectangleInsets var1 = var0.getPadding();
//     org.jfree.chart.util.HorizontalAlignment var2 = null;
//     org.jfree.chart.util.VerticalAlignment var3 = null;
//     org.jfree.chart.block.FlowArrangement var6 = new org.jfree.chart.block.FlowArrangement(var2, var3, 0.0d, 0.0d);
//     var0.setArrangement((org.jfree.chart.block.Arrangement)var6);
//     var6.clear();
//     org.jfree.chart.LegendItemSource var9 = null;
//     org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle(var9);
//     org.jfree.chart.util.RectangleEdge var11 = var10.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var12 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var13 = var12.getNextOutlinePaint();
//     var10.setBackgroundPaint(var13);
//     org.jfree.chart.LegendItemSource var15 = null;
//     org.jfree.chart.title.LegendTitle var16 = new org.jfree.chart.title.LegendTitle(var15);
//     org.jfree.chart.util.RectangleInsets var17 = var16.getItemLabelPadding();
//     org.jfree.chart.util.VerticalAlignment var18 = var16.getVerticalAlignment();
//     org.jfree.chart.block.BlockContainer var19 = var16.getItemContainer();
//     var10.setWrapper(var19);
//     org.jfree.data.category.CategoryDataset var22 = null;
//     org.jfree.chart.axis.CategoryAxis var23 = null;
//     org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var25 = null;
//     var24.setPlot(var25);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var27 = null;
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot(var22, var23, (org.jfree.chart.axis.ValueAxis)var24, var27);
//     org.jfree.chart.LegendItemSource var29 = null;
//     org.jfree.chart.title.LegendTitle var30 = new org.jfree.chart.title.LegendTitle(var29);
//     org.jfree.chart.util.RectangleEdge var31 = var30.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var32 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var33 = var32.getNextOutlinePaint();
//     var30.setBackgroundPaint(var33);
//     var28.setOutlinePaint(var33);
//     org.jfree.chart.JFreeChart var36 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var28);
//     var36.fireChartChanged();
//     var36.setTextAntiAlias(false);
//     org.jfree.chart.plot.CategoryPlot var40 = var36.getCategoryPlot();
//     var40.clearRangeAxes();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var42 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var44 = var42.getSeriesItemLabelsVisible(100);
//     org.jfree.chart.labels.ItemLabelPosition var47 = var42.getPositiveItemLabelPosition(100, 0);
//     org.jfree.data.general.Dataset var48 = null;
//     org.jfree.data.general.DatasetChangeEvent var49 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)0, var48);
//     var40.datasetChanged(var49);
//     org.jfree.chart.axis.AxisLocation var51 = var40.getDomainAxisLocation();
//     var6.add((org.jfree.chart.block.Block)var10, (java.lang.Object)var51);
//     
//     // Checks the contract:  equals-hashcode on var12 and var32
//     assertTrue("Contract failed: equals-hashcode on var12 and var32", var12.equals(var32) ? var12.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var12
//     assertTrue("Contract failed: equals-hashcode on var32 and var12", var32.equals(var12) ? var32.hashCode() == var12.hashCode() : true);
// 
//   }

  public void test328() {}
//   public void test328() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var1 = null;
//     var0.setBaseURLGenerator(var1);
//     org.jfree.data.category.CategoryDataset var4 = null;
//     org.jfree.chart.axis.CategoryAxis var5 = null;
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var7 = null;
//     var6.setPlot(var7);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot(var4, var5, (org.jfree.chart.axis.ValueAxis)var6, var9);
//     org.jfree.chart.LegendItemSource var11 = null;
//     org.jfree.chart.title.LegendTitle var12 = new org.jfree.chart.title.LegendTitle(var11);
//     org.jfree.chart.util.RectangleEdge var13 = var12.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var14 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var15 = var14.getNextOutlinePaint();
//     var12.setBackgroundPaint(var15);
//     var10.setOutlinePaint(var15);
//     var0.setSeriesPaint(1, var15, false);
//     org.jfree.chart.labels.ItemLabelPosition var22 = var0.getNegativeItemLabelPosition(10, 1);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var23 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var24 = null;
//     var23.setBaseURLGenerator(var24);
//     org.jfree.data.category.CategoryDataset var27 = null;
//     org.jfree.chart.axis.CategoryAxis var28 = null;
//     org.jfree.chart.axis.NumberAxis var29 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var30 = null;
//     var29.setPlot(var30);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var32 = null;
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var27, var28, (org.jfree.chart.axis.ValueAxis)var29, var32);
//     org.jfree.chart.LegendItemSource var34 = null;
//     org.jfree.chart.title.LegendTitle var35 = new org.jfree.chart.title.LegendTitle(var34);
//     org.jfree.chart.util.RectangleEdge var36 = var35.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var37 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var38 = var37.getNextOutlinePaint();
//     var35.setBackgroundPaint(var38);
//     var33.setOutlinePaint(var38);
//     var23.setSeriesPaint(1, var38, false);
//     var0.setBaseFillPaint(var38);
//     
//     // Checks the contract:  equals-hashcode on var10 and var33
//     assertTrue("Contract failed: equals-hashcode on var10 and var33", var10.equals(var33) ? var10.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var10
//     assertTrue("Contract failed: equals-hashcode on var33 and var10", var33.equals(var10) ? var33.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var37
//     assertTrue("Contract failed: equals-hashcode on var14 and var37", var14.equals(var37) ? var14.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var14
//     assertTrue("Contract failed: equals-hashcode on var37 and var14", var37.equals(var14) ? var37.hashCode() == var14.hashCode() : true);
// 
//   }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }


    java.awt.Color var1 = java.awt.Color.getColor("java.awt.Color[r=242,g=242,b=242]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test330() {}
//   public void test330() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }
// 
// 
//     org.jfree.chart.LegendItemSource var0 = null;
//     org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
//     org.jfree.chart.util.RectangleEdge var2 = var1.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var3 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var4 = var3.getNextOutlinePaint();
//     var1.setBackgroundPaint(var4);
//     org.jfree.chart.text.TextBlock var6 = new org.jfree.chart.text.TextBlock();
//     java.util.List var7 = var6.getLines();
//     boolean var8 = var1.equals((java.lang.Object)var6);
//     org.jfree.chart.util.RectangleEdge var9 = var1.getLegendItemGraphicEdge();
//     org.jfree.chart.block.BlockContainer var10 = new org.jfree.chart.block.BlockContainer();
//     var1.setWrapper(var10);
//     java.lang.Object var12 = var10.clone();
//     java.awt.Graphics2D var13 = null;
//     org.jfree.chart.axis.CategoryLabelPositions var14 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var15 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var16 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var14, var15);
//     float var17 = var15.getWidthRatio();
//     org.jfree.chart.text.TextBlockAnchor var18 = var15.getLabelAnchor();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var19 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var21 = null;
//     var19.setSeriesItemLabelsVisible(0, var21, false);
//     java.awt.Stroke var24 = var19.getErrorIndicatorStroke();
//     org.jfree.chart.LegendItemSource var26 = null;
//     org.jfree.chart.title.LegendTitle var27 = new org.jfree.chart.title.LegendTitle(var26);
//     org.jfree.chart.util.RectangleInsets var28 = var27.getItemLabelPadding();
//     double var30 = var28.calculateTopOutset(4.0d);
//     org.jfree.data.category.CategoryDataset var31 = null;
//     org.jfree.chart.axis.CategoryAxis var32 = null;
//     org.jfree.chart.axis.NumberAxis var33 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var34 = null;
//     var33.setPlot(var34);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var36 = null;
//     org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot(var31, var32, (org.jfree.chart.axis.ValueAxis)var33, var36);
//     org.jfree.chart.LegendItemSource var38 = null;
//     org.jfree.chart.title.LegendTitle var39 = new org.jfree.chart.title.LegendTitle(var38);
//     org.jfree.chart.util.RectangleEdge var40 = var39.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var41 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var42 = var41.getNextOutlinePaint();
//     var39.setBackgroundPaint(var42);
//     var37.setOutlinePaint(var42);
//     org.jfree.data.category.CategoryDataset var45 = null;
//     org.jfree.chart.axis.CategoryAxis var46 = null;
//     org.jfree.chart.axis.NumberAxis var47 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var48 = null;
//     var47.setPlot(var48);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var50 = null;
//     org.jfree.chart.plot.CategoryPlot var51 = new org.jfree.chart.plot.CategoryPlot(var45, var46, (org.jfree.chart.axis.ValueAxis)var47, var50);
//     org.jfree.chart.axis.NumberAxis var52 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var53 = null;
//     var52.setPlot(var53);
//     org.jfree.chart.axis.ValueAxis[] var55 = new org.jfree.chart.axis.ValueAxis[] { var52};
//     var51.setRangeAxes(var55);
//     var37.setParent((org.jfree.chart.plot.Plot)var51);
//     java.awt.Stroke var58 = var51.getRangeCrosshairStroke();
//     java.awt.Graphics2D var59 = null;
//     org.jfree.chart.LegendItemSource var60 = null;
//     org.jfree.chart.title.LegendTitle var61 = new org.jfree.chart.title.LegendTitle(var60);
//     org.jfree.chart.util.RectangleInsets var62 = var61.getItemLabelPadding();
//     org.jfree.chart.LegendItemSource var63 = null;
//     org.jfree.chart.title.LegendTitle var64 = new org.jfree.chart.title.LegendTitle(var63);
//     org.jfree.chart.util.RectangleInsets var65 = var64.getItemLabelPadding();
//     double var66 = var65.getTop();
//     var61.setPadding(var65);
//     org.jfree.chart.util.Size2D var68 = new org.jfree.chart.util.Size2D();
//     boolean var70 = var68.equals((java.lang.Object)(-1L));
//     double var71 = var68.getWidth();
//     double var72 = var68.getHeight();
//     org.jfree.chart.util.RectangleAnchor var75 = null;
//     java.awt.geom.Rectangle2D var76 = org.jfree.chart.util.RectangleAnchor.createRectangle(var68, 2.0d, (-1.0d), var75);
//     org.jfree.chart.axis.CategoryLabelPositions var79 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var80 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var81 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var79, var80);
//     org.jfree.chart.util.RectangleAnchor var82 = var80.getCategoryAnchor();
//     java.awt.geom.Rectangle2D var83 = org.jfree.chart.util.RectangleAnchor.createRectangle(var68, 2.0d, 1.0d, var82);
//     java.awt.geom.Rectangle2D var84 = var65.createOutsetRectangle(var83);
//     org.jfree.chart.plot.PlotRenderingInfo var86 = null;
//     boolean var87 = var51.render(var59, var84, 255, var86);
//     java.awt.geom.Rectangle2D var90 = var28.createInsetRectangle(var84, false, false);
//     var19.setSeriesShape(10, (java.awt.Shape)var84, true);
//     boolean var93 = var18.equals((java.lang.Object)var84);
//     org.jfree.chart.util.StandardGradientPaintTransformer var94 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     java.lang.Object var95 = var94.clone();
//     org.jfree.chart.event.ChartChangeEvent var96 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var94);
//     java.lang.Object var97 = var10.draw(var13, var84, (java.lang.Object)var96);
// 
//   }

  public void test331() {}
//   public void test331() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }
// 
// 
//     double[] var2 = null;
//     double[][] var3 = new double[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ChartChangeEventType.GENERAL", "hi!", var3);
// 
//   }

  public void test332() {}
//   public void test332() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }
// 
// 
//     org.jfree.chart.LegendItemSource var0 = null;
//     org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
//     org.jfree.chart.util.RectangleEdge var2 = var1.getLegendItemGraphicEdge();
//     java.awt.Paint var3 = var1.getItemPaint();
//     org.jfree.data.category.CategoryDataset var5 = null;
//     org.jfree.chart.axis.CategoryAxis var6 = null;
//     org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var8 = null;
//     var7.setPlot(var8);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot(var5, var6, (org.jfree.chart.axis.ValueAxis)var7, var10);
//     org.jfree.chart.LegendItemSource var12 = null;
//     org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle(var12);
//     org.jfree.chart.util.RectangleEdge var14 = var13.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var15 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var16 = var15.getNextOutlinePaint();
//     var13.setBackgroundPaint(var16);
//     var11.setOutlinePaint(var16);
//     org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var11);
//     var19.fireChartChanged();
//     boolean var21 = var19.getAntiAlias();
//     java.util.List var22 = var19.getSubtitles();
//     var1.addChangeListener((org.jfree.chart.event.TitleChangeListener)var19);
//     java.awt.Graphics2D var24 = null;
//     org.jfree.chart.LegendItemSource var25 = null;
//     org.jfree.chart.title.LegendTitle var26 = new org.jfree.chart.title.LegendTitle(var25);
//     org.jfree.chart.util.RectangleEdge var27 = var26.getLegendItemGraphicEdge();
//     java.awt.Paint var28 = var26.getItemPaint();
//     var26.setNotify(true);
//     java.awt.geom.Rectangle2D var31 = var26.getBounds();
//     org.jfree.chart.ChartRenderingInfo var32 = null;
//     var19.draw(var24, var31, var32);
// 
//   }

  public void test333() {}
//   public void test333() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var3 = null;
//     var2.setPlot(var3);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
//     var6.setAnchorValue(0.0d, true);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var12 = null;
//     var10.setSeriesItemLabelsVisible(0, var12, false);
//     org.jfree.chart.labels.CategoryToolTipGenerator var16 = null;
//     var10.setSeriesToolTipGenerator(1, var16, false);
//     org.jfree.chart.urls.CategoryURLGenerator var19 = null;
//     var10.setBaseURLGenerator(var19);
//     java.awt.Graphics2D var21 = null;
//     org.jfree.chart.plot.CategoryPlot var22 = null;
//     org.jfree.chart.axis.ValueAxis var23 = null;
//     org.jfree.chart.plot.Marker var24 = null;
//     java.awt.geom.Rectangle2D var25 = null;
//     var10.drawRangeMarker(var21, var22, var23, var24, var25);
//     boolean var28 = var10.isSeriesVisibleInLegend(0);
//     var6.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
//     org.jfree.chart.axis.CategoryAxis var30 = null;
//     java.util.List var31 = var6.getCategoriesForAxis(var30);
//     java.awt.Font var32 = var6.getNoDataMessageFont();
//     java.lang.String var33 = var6.getNoDataMessage();
//     java.awt.Graphics2D var34 = null;
//     java.awt.geom.Rectangle2D var35 = null;
//     var6.drawBackground(var34, var35);
// 
//   }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }


    java.awt.geom.GeneralPath var0 = null;
    java.awt.geom.GeneralPath var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }


    java.awt.Color var2 = java.awt.Color.getColor("Range[-1.0,-1.0]", 0);
    java.lang.String var3 = var2.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "java.awt.Color[r=0,g=0,b=0]"+ "'", var3.equals("java.awt.Color[r=0,g=0,b=0]"));

  }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var4 = null;
    var3.setPlot(var4);
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var3, var6);
    java.awt.Stroke var8 = var3.getTickMarkStroke();
    var3.zoomRange((-1.0d), 100.0d);
    org.jfree.chart.block.BlockContainer var12 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.util.RectangleInsets var13 = var12.getPadding();
    double var15 = var13.calculateTopInset(100.0d);
    var3.setLabelInsets(var13);
    java.awt.Paint var17 = var3.getTickMarkPaint();
    java.awt.Paint var18 = var3.getAxisLinePaint();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var19 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var20 = var19.getPositiveItemLabelPositionFallback();
    java.awt.Paint var23 = var19.getItemLabelPaint((-123), (-1));
    org.jfree.data.category.CategoryDataset var24 = null;
    org.jfree.chart.axis.CategoryAxis var25 = null;
    org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var27 = null;
    var26.setPlot(var27);
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var24, var25, (org.jfree.chart.axis.ValueAxis)var26, var29);
    java.awt.Stroke var31 = var26.getTickMarkStroke();
    org.jfree.chart.LegendItemSource var32 = null;
    org.jfree.chart.title.LegendTitle var33 = new org.jfree.chart.title.LegendTitle(var32);
    org.jfree.chart.util.RectangleInsets var34 = var33.getItemLabelPadding();
    double var35 = var34.getTop();
    org.jfree.chart.block.LineBorder var36 = new org.jfree.chart.block.LineBorder(var23, var31, var34);
    java.awt.Stroke var37 = var36.getStroke();
    java.awt.Stroke var38 = var36.getStroke();
    org.jfree.chart.LegendItemSource var39 = null;
    org.jfree.chart.title.LegendTitle var40 = new org.jfree.chart.title.LegendTitle(var39);
    org.jfree.chart.util.RectangleEdge var41 = var40.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var42 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var43 = var42.getNextOutlinePaint();
    var40.setBackgroundPaint(var43);
    org.jfree.data.category.CategoryDataset var45 = null;
    org.jfree.chart.axis.CategoryAxis var46 = null;
    org.jfree.chart.axis.NumberAxis var47 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var48 = null;
    var47.setPlot(var48);
    org.jfree.chart.renderer.category.CategoryItemRenderer var50 = null;
    org.jfree.chart.plot.CategoryPlot var51 = new org.jfree.chart.plot.CategoryPlot(var45, var46, (org.jfree.chart.axis.ValueAxis)var47, var50);
    boolean var52 = var51.isDomainZoomable();
    org.jfree.data.category.CategoryDataset var54 = var51.getDataset((-123));
    var51.clearRangeMarkers(0);
    java.awt.Color var61 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.0f);
    java.awt.Shape var67 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var69 = new org.jfree.chart.entity.ChartEntity(var67, "Range[-1.0,-1.0]");
    org.jfree.chart.renderer.category.StatisticalBarRenderer var70 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var72 = null;
    var70.setSeriesItemLabelsVisible(0, var72, false);
    java.awt.Stroke var75 = var70.getErrorIndicatorStroke();
    java.awt.Paint var76 = null;
    org.jfree.chart.LegendItem var77 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var67, var75, var76);
    org.jfree.chart.plot.ValueMarker var78 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint)var61, var75);
    var51.setDomainGridlineStroke(var75);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.ValueMarker var81 = new org.jfree.chart.plot.ValueMarker(1.0E-8d, var18, var38, var43, var75, 10.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);

  }

  public void test337() {}
//   public void test337() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var1 = null;
//     var0.setBaseURLGenerator(var1);
//     org.jfree.data.category.CategoryDataset var4 = null;
//     org.jfree.chart.axis.CategoryAxis var5 = null;
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var7 = null;
//     var6.setPlot(var7);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot(var4, var5, (org.jfree.chart.axis.ValueAxis)var6, var9);
//     org.jfree.chart.LegendItemSource var11 = null;
//     org.jfree.chart.title.LegendTitle var12 = new org.jfree.chart.title.LegendTitle(var11);
//     org.jfree.chart.util.RectangleEdge var13 = var12.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var14 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var15 = var14.getNextOutlinePaint();
//     var12.setBackgroundPaint(var15);
//     var10.setOutlinePaint(var15);
//     var0.setSeriesPaint(1, var15, false);
//     java.awt.Stroke var20 = var0.getBaseOutlineStroke();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var21 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var23 = var21.getSeriesItemLabelsVisible(100);
//     org.jfree.chart.labels.ItemLabelPosition var26 = var21.getPositiveItemLabelPosition(100, 0);
//     org.jfree.chart.urls.CategoryURLGenerator var27 = var21.getBaseURLGenerator();
//     java.lang.Boolean var29 = var21.getSeriesItemLabelsVisible((-855310));
//     java.awt.Color var32 = java.awt.Color.getColor("", (-1));
//     var21.setBasePaint((java.awt.Paint)var32, true);
//     boolean var35 = var0.equals((java.lang.Object)var21);
//     java.awt.Stroke var37 = var21.getSeriesOutlineStroke(10);
//     org.jfree.data.category.CategoryDataset var38 = null;
//     org.jfree.chart.axis.CategoryAxis var39 = null;
//     org.jfree.chart.axis.NumberAxis var40 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var41 = null;
//     var40.setPlot(var41);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var43 = null;
//     org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot(var38, var39, (org.jfree.chart.axis.ValueAxis)var40, var43);
//     org.jfree.chart.LegendItemSource var45 = null;
//     org.jfree.chart.title.LegendTitle var46 = new org.jfree.chart.title.LegendTitle(var45);
//     org.jfree.chart.util.RectangleEdge var47 = var46.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var48 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var49 = var48.getNextOutlinePaint();
//     var46.setBackgroundPaint(var49);
//     var44.setOutlinePaint(var49);
//     org.jfree.data.category.CategoryDataset var52 = null;
//     org.jfree.chart.axis.CategoryAxis var53 = null;
//     org.jfree.chart.axis.NumberAxis var54 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var55 = null;
//     var54.setPlot(var55);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var57 = null;
//     org.jfree.chart.plot.CategoryPlot var58 = new org.jfree.chart.plot.CategoryPlot(var52, var53, (org.jfree.chart.axis.ValueAxis)var54, var57);
//     org.jfree.chart.axis.NumberAxis var59 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var60 = null;
//     var59.setPlot(var60);
//     org.jfree.chart.axis.ValueAxis[] var62 = new org.jfree.chart.axis.ValueAxis[] { var59};
//     var58.setRangeAxes(var62);
//     var44.setParent((org.jfree.chart.plot.Plot)var58);
//     java.awt.Stroke var65 = var58.getRangeCrosshairStroke();
//     var21.setBaseOutlineStroke(var65);
//     
//     // Checks the contract:  equals-hashcode on var10 and var44
//     assertTrue("Contract failed: equals-hashcode on var10 and var44", var10.equals(var44) ? var10.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var10
//     assertTrue("Contract failed: equals-hashcode on var44 and var10", var44.equals(var10) ? var44.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var48
//     assertTrue("Contract failed: equals-hashcode on var14 and var48", var14.equals(var48) ? var14.hashCode() == var48.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var48 and var14
//     assertTrue("Contract failed: equals-hashcode on var48 and var14", var48.equals(var14) ? var48.hashCode() == var14.hashCode() : true);
// 
//   }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("java.awt.Color[r=0,g=0,b=0]", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    var6.setAnchorValue(0.0d, true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var12 = null;
    var10.setSeriesItemLabelsVisible(0, var12, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var16 = null;
    var10.setSeriesToolTipGenerator(1, var16, false);
    org.jfree.chart.urls.CategoryURLGenerator var19 = null;
    var10.setBaseURLGenerator(var19);
    java.awt.Graphics2D var21 = null;
    org.jfree.chart.plot.CategoryPlot var22 = null;
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.plot.Marker var24 = null;
    java.awt.geom.Rectangle2D var25 = null;
    var10.drawRangeMarker(var21, var22, var23, var24, var25);
    boolean var28 = var10.isSeriesVisibleInLegend(0);
    var6.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    org.jfree.chart.axis.CategoryAxis var30 = null;
    java.util.List var31 = var6.getCategoriesForAxis(var30);
    java.awt.Paint var32 = var6.getNoDataMessagePaint();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var33 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.chart.renderer.category.CategoryItemRenderer var34 = var6.getRendererForDataset((org.jfree.data.category.CategoryDataset)var33);
    org.jfree.chart.plot.DatasetRenderingOrder var35 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setDatasetRenderingOrder(var35);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);

  }

  public void test340() {}
//   public void test340() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var4 = null;
//     var3.setPlot(var4);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var3, var6);
//     org.jfree.chart.LegendItemSource var8 = null;
//     org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
//     org.jfree.chart.util.RectangleEdge var10 = var9.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var12 = var11.getNextOutlinePaint();
//     var9.setBackgroundPaint(var12);
//     var7.setOutlinePaint(var12);
//     org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var7);
//     var15.fireChartChanged();
//     var15.setTextAntiAlias(false);
//     org.jfree.chart.plot.CategoryPlot var19 = var15.getCategoryPlot();
//     var19.clearRangeAxes();
//     org.jfree.chart.plot.Plot var21 = var19.getParent();
//     org.jfree.chart.plot.Marker var22 = null;
//     var19.addRangeMarker(var22);
// 
//   }

  public void test341() {}
//   public void test341() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var1 = null;
//     var0.setBaseURLGenerator(var1);
//     org.jfree.data.category.CategoryDataset var4 = null;
//     org.jfree.chart.axis.CategoryAxis var5 = null;
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var7 = null;
//     var6.setPlot(var7);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot(var4, var5, (org.jfree.chart.axis.ValueAxis)var6, var9);
//     org.jfree.chart.LegendItemSource var11 = null;
//     org.jfree.chart.title.LegendTitle var12 = new org.jfree.chart.title.LegendTitle(var11);
//     org.jfree.chart.util.RectangleEdge var13 = var12.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var14 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var15 = var14.getNextOutlinePaint();
//     var12.setBackgroundPaint(var15);
//     var10.setOutlinePaint(var15);
//     var0.setSeriesPaint(1, var15, false);
//     java.awt.Stroke var20 = var0.getBaseOutlineStroke();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var21 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var22 = null;
//     var21.setBaseURLGenerator(var22);
//     org.jfree.data.category.CategoryDataset var25 = null;
//     org.jfree.chart.axis.CategoryAxis var26 = null;
//     org.jfree.chart.axis.NumberAxis var27 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var28 = null;
//     var27.setPlot(var28);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var30 = null;
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot(var25, var26, (org.jfree.chart.axis.ValueAxis)var27, var30);
//     org.jfree.chart.LegendItemSource var32 = null;
//     org.jfree.chart.title.LegendTitle var33 = new org.jfree.chart.title.LegendTitle(var32);
//     org.jfree.chart.util.RectangleEdge var34 = var33.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var35 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var36 = var35.getNextOutlinePaint();
//     var33.setBackgroundPaint(var36);
//     var31.setOutlinePaint(var36);
//     var21.setSeriesPaint(1, var36, false);
//     java.awt.Stroke var41 = var21.getBaseOutlineStroke();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var42 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var44 = var42.getSeriesItemLabelsVisible(100);
//     org.jfree.chart.labels.ItemLabelPosition var47 = var42.getPositiveItemLabelPosition(100, 0);
//     org.jfree.chart.urls.CategoryURLGenerator var48 = var42.getBaseURLGenerator();
//     java.lang.Boolean var50 = var42.getSeriesItemLabelsVisible((-855310));
//     java.awt.Color var53 = java.awt.Color.getColor("", (-1));
//     var42.setBasePaint((java.awt.Paint)var53, true);
//     boolean var56 = var21.equals((java.lang.Object)var42);
//     org.jfree.data.category.CategoryDataset var57 = null;
//     org.jfree.chart.axis.CategoryAxis var58 = null;
//     org.jfree.chart.axis.NumberAxis var59 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var60 = null;
//     var59.setPlot(var60);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var62 = null;
//     org.jfree.chart.plot.CategoryPlot var63 = new org.jfree.chart.plot.CategoryPlot(var57, var58, (org.jfree.chart.axis.ValueAxis)var59, var62);
//     java.awt.Stroke var64 = var59.getTickMarkStroke();
//     var42.setBaseStroke(var64);
//     var0.setBaseStroke(var64, true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var31
//     assertTrue("Contract failed: equals-hashcode on var10 and var31", var10.equals(var31) ? var10.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var10
//     assertTrue("Contract failed: equals-hashcode on var31 and var10", var31.equals(var10) ? var31.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var35
//     assertTrue("Contract failed: equals-hashcode on var14 and var35", var14.equals(var35) ? var14.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var14
//     assertTrue("Contract failed: equals-hashcode on var35 and var14", var35.equals(var14) ? var35.hashCode() == var14.hashCode() : true);
// 
//   }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = null;
    var0.setSeriesItemLabelsVisible(0, var2, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var6 = null;
    var0.setSeriesToolTipGenerator(1, var6, false);
    org.jfree.chart.urls.CategoryURLGenerator var9 = null;
    var0.setBaseURLGenerator(var9);
    var0.setBaseCreateEntities(false, false);
    var0.setSeriesVisibleInLegend(0, (java.lang.Boolean)false);
    org.jfree.chart.annotations.CategoryAnnotation var17 = null;
    org.jfree.chart.util.Layer var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var17, var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test343() {}
//   public void test343() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var3 = null;
//     var2.setPlot(var3);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
//     org.jfree.chart.LegendItemSource var7 = null;
//     org.jfree.chart.title.LegendTitle var8 = new org.jfree.chart.title.LegendTitle(var7);
//     org.jfree.chart.util.RectangleEdge var9 = var8.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var10 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var11 = var10.getNextOutlinePaint();
//     var8.setBackgroundPaint(var11);
//     var6.setOutlinePaint(var11);
//     org.jfree.data.category.CategoryDataset var14 = null;
//     org.jfree.chart.axis.CategoryAxis var15 = null;
//     org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var17 = null;
//     var16.setPlot(var17);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var19 = null;
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot(var14, var15, (org.jfree.chart.axis.ValueAxis)var16, var19);
//     org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var22 = null;
//     var21.setPlot(var22);
//     org.jfree.chart.axis.ValueAxis[] var24 = new org.jfree.chart.axis.ValueAxis[] { var21};
//     var20.setRangeAxes(var24);
//     var6.setParent((org.jfree.chart.plot.Plot)var20);
//     java.awt.Stroke var27 = var20.getRangeCrosshairStroke();
//     org.jfree.data.category.CategoryDataset var28 = null;
//     org.jfree.chart.axis.CategoryAxis var29 = null;
//     org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var31 = null;
//     var30.setPlot(var31);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var33 = null;
//     org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot(var28, var29, (org.jfree.chart.axis.ValueAxis)var30, var33);
//     org.jfree.chart.LegendItemSource var35 = null;
//     org.jfree.chart.title.LegendTitle var36 = new org.jfree.chart.title.LegendTitle(var35);
//     org.jfree.chart.util.RectangleEdge var37 = var36.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var38 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var39 = var38.getNextOutlinePaint();
//     var36.setBackgroundPaint(var39);
//     var34.setOutlinePaint(var39);
//     var34.clearDomainMarkers();
//     org.jfree.chart.util.SortOrder var43 = var34.getRowRenderingOrder();
//     java.lang.String var44 = var43.toString();
//     java.lang.String var45 = var43.toString();
//     var20.setRowRenderingOrder(var43);
//     
//     // Checks the contract:  equals-hashcode on var6 and var34
//     assertTrue("Contract failed: equals-hashcode on var6 and var34", var6.equals(var34) ? var6.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var6
//     assertTrue("Contract failed: equals-hashcode on var34 and var6", var34.equals(var6) ? var34.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var38
//     assertTrue("Contract failed: equals-hashcode on var10 and var38", var10.equals(var38) ? var10.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var10
//     assertTrue("Contract failed: equals-hashcode on var38 and var10", var38.equals(var10) ? var38.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }


    org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(false);

  }

  public void test345() {}
//   public void test345() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var4 = null;
//     var3.setPlot(var4);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var3, var6);
//     org.jfree.chart.LegendItemSource var8 = null;
//     org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
//     org.jfree.chart.util.RectangleEdge var10 = var9.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var12 = var11.getNextOutlinePaint();
//     var9.setBackgroundPaint(var12);
//     var7.setOutlinePaint(var12);
//     org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var7);
//     java.lang.Object var16 = var15.clone();
//     var15.setNotify(false);
//     java.awt.Graphics2D var19 = null;
//     org.jfree.chart.ChartRenderingInfo var20 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var21 = new org.jfree.chart.plot.PlotRenderingInfo(var20);
//     java.lang.Object var22 = var21.clone();
//     org.jfree.chart.LegendItemSource var23 = null;
//     org.jfree.chart.title.LegendTitle var24 = new org.jfree.chart.title.LegendTitle(var23);
//     org.jfree.chart.util.RectangleInsets var25 = var24.getItemLabelPadding();
//     double var27 = var25.calculateTopOutset(4.0d);
//     org.jfree.data.category.CategoryDataset var28 = null;
//     org.jfree.chart.axis.CategoryAxis var29 = null;
//     org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var31 = null;
//     var30.setPlot(var31);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var33 = null;
//     org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot(var28, var29, (org.jfree.chart.axis.ValueAxis)var30, var33);
//     org.jfree.chart.LegendItemSource var35 = null;
//     org.jfree.chart.title.LegendTitle var36 = new org.jfree.chart.title.LegendTitle(var35);
//     org.jfree.chart.util.RectangleEdge var37 = var36.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var38 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var39 = var38.getNextOutlinePaint();
//     var36.setBackgroundPaint(var39);
//     var34.setOutlinePaint(var39);
//     org.jfree.data.category.CategoryDataset var42 = null;
//     org.jfree.chart.axis.CategoryAxis var43 = null;
//     org.jfree.chart.axis.NumberAxis var44 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var45 = null;
//     var44.setPlot(var45);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var47 = null;
//     org.jfree.chart.plot.CategoryPlot var48 = new org.jfree.chart.plot.CategoryPlot(var42, var43, (org.jfree.chart.axis.ValueAxis)var44, var47);
//     org.jfree.chart.axis.NumberAxis var49 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var50 = null;
//     var49.setPlot(var50);
//     org.jfree.chart.axis.ValueAxis[] var52 = new org.jfree.chart.axis.ValueAxis[] { var49};
//     var48.setRangeAxes(var52);
//     var34.setParent((org.jfree.chart.plot.Plot)var48);
//     java.awt.Stroke var55 = var48.getRangeCrosshairStroke();
//     java.awt.Graphics2D var56 = null;
//     org.jfree.chart.LegendItemSource var57 = null;
//     org.jfree.chart.title.LegendTitle var58 = new org.jfree.chart.title.LegendTitle(var57);
//     org.jfree.chart.util.RectangleInsets var59 = var58.getItemLabelPadding();
//     org.jfree.chart.LegendItemSource var60 = null;
//     org.jfree.chart.title.LegendTitle var61 = new org.jfree.chart.title.LegendTitle(var60);
//     org.jfree.chart.util.RectangleInsets var62 = var61.getItemLabelPadding();
//     double var63 = var62.getTop();
//     var58.setPadding(var62);
//     org.jfree.chart.util.Size2D var65 = new org.jfree.chart.util.Size2D();
//     boolean var67 = var65.equals((java.lang.Object)(-1L));
//     double var68 = var65.getWidth();
//     double var69 = var65.getHeight();
//     org.jfree.chart.util.RectangleAnchor var72 = null;
//     java.awt.geom.Rectangle2D var73 = org.jfree.chart.util.RectangleAnchor.createRectangle(var65, 2.0d, (-1.0d), var72);
//     org.jfree.chart.axis.CategoryLabelPositions var76 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var77 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var78 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var76, var77);
//     org.jfree.chart.util.RectangleAnchor var79 = var77.getCategoryAnchor();
//     java.awt.geom.Rectangle2D var80 = org.jfree.chart.util.RectangleAnchor.createRectangle(var65, 2.0d, 1.0d, var79);
//     java.awt.geom.Rectangle2D var81 = var62.createOutsetRectangle(var80);
//     org.jfree.chart.plot.PlotRenderingInfo var83 = null;
//     boolean var84 = var48.render(var56, var81, 255, var83);
//     java.awt.geom.Rectangle2D var87 = var25.createInsetRectangle(var81, false, false);
//     var21.setDataArea(var81);
//     java.awt.geom.Rectangle2D var89 = var21.getDataArea();
//     var15.draw(var19, var89);
// 
//   }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    java.util.List var1 = var0.getColumnKeys();
    int var3 = var0.getRowIndex((java.lang.Comparable)100);
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
    boolean var5 = var4.isNegativeArrowVisible();
    java.lang.String var6 = var4.getLabelURL();
    var4.setLabelAngle(6.0d);
    var4.setAutoRange(false);
    java.awt.Font var11 = var4.getTickLabelFont();
    var0.setObject((java.lang.Object)var11, (java.lang.Comparable)"CategoryLabelEntity: category=null, tooltip=hi!, url=", (java.lang.Comparable)"CategoryLabelEntity: category=null, tooltip=hi!, url=");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeRow(4);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.util.RectangleInsets var1 = var0.getPadding();
    double var3 = var1.trimHeight((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1.0d));

  }

  public void test348() {}
//   public void test348() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }
// 
// 
//     org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.util.RectangleInsets var1 = var0.getPadding();
//     org.jfree.chart.util.HorizontalAlignment var2 = null;
//     org.jfree.chart.util.VerticalAlignment var3 = null;
//     org.jfree.chart.block.FlowArrangement var6 = new org.jfree.chart.block.FlowArrangement(var2, var3, 0.0d, 0.0d);
//     var0.setArrangement((org.jfree.chart.block.Arrangement)var6);
//     org.jfree.chart.block.BlockBorder var12 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 0.0d, 0.0d);
//     var0.setFrame((org.jfree.chart.block.BlockFrame)var12);
//     java.awt.Graphics2D var14 = null;
//     java.awt.geom.Rectangle2D var15 = null;
//     var12.draw(var14, var15);
// 
//   }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    org.jfree.chart.annotations.CategoryAnnotation var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.addAnnotation(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = var0.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var5 = var0.getPositiveItemLabelPosition(100, 0);
    org.jfree.chart.urls.CategoryURLGenerator var6 = var0.getBaseURLGenerator();
    java.lang.Boolean var8 = var0.getSeriesItemLabelsVisible((-855310));
    java.awt.Color var11 = java.awt.Color.getColor("", (-1));
    var0.setBasePaint((java.awt.Paint)var11, true);
    int var14 = var11.getGreen();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 255);

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = null;
    var0.setSeriesItemLabelsVisible(0, var2, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var6 = null;
    var0.setSeriesToolTipGenerator(1, var6, false);
    org.jfree.chart.urls.CategoryURLGenerator var9 = null;
    var0.setBaseURLGenerator(var9);
    java.awt.Graphics2D var11 = null;
    org.jfree.chart.plot.CategoryPlot var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.plot.Marker var14 = null;
    java.awt.geom.Rectangle2D var15 = null;
    var0.drawRangeMarker(var11, var12, var13, var14, var15);
    org.jfree.chart.urls.CategoryURLGenerator var17 = null;
    var0.setBaseURLGenerator(var17, true);
    org.jfree.data.statistics.MeanAndStandardDeviation var22 = new org.jfree.data.statistics.MeanAndStandardDeviation(100.0d, 0.0d);
    boolean var24 = var22.equals((java.lang.Object)'a');
    boolean var25 = var0.equals((java.lang.Object)var22);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var26 = var0.getLegendItemURLGenerator();
    java.awt.Stroke var28 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesOutlineStroke((-855310), var28);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);

  }

  public void test352() {}
//   public void test352() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }
// 
// 
//     java.awt.Color var4 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.0f);
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
//     org.jfree.chart.entity.ChartEntity var12 = new org.jfree.chart.entity.ChartEntity(var10, "Range[-1.0,-1.0]");
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var13 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var15 = null;
//     var13.setSeriesItemLabelsVisible(0, var15, false);
//     java.awt.Stroke var18 = var13.getErrorIndicatorStroke();
//     java.awt.Paint var19 = null;
//     org.jfree.chart.LegendItem var20 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var10, var18, var19);
//     org.jfree.chart.plot.ValueMarker var21 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint)var4, var18);
//     org.jfree.chart.text.TextAnchor var22 = var21.getLabelTextAnchor();
//     java.lang.Class var23 = null;
//     java.util.EventListener[] var24 = var21.getListeners(var23);
// 
//   }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var1 = null;
    var0.setPlot(var1);
    org.jfree.chart.block.BlockContainer var3 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.util.RectangleInsets var4 = var3.getPadding();
    double var6 = var4.calculateTopInset(100.0d);
    double var8 = var4.calculateTopInset(2.0d);
    var0.setLabelInsets(var4);
    java.awt.Shape var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRightArrow(var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var4 = null;
    var3.setPlot(var4);
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var3, var6);
    org.jfree.chart.LegendItemSource var8 = null;
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
    org.jfree.chart.util.RectangleEdge var10 = var9.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var12 = var11.getNextOutlinePaint();
    var9.setBackgroundPaint(var12);
    var7.setOutlinePaint(var12);
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var7);
    var15.fireChartChanged();
    org.jfree.chart.plot.CategoryPlot var17 = var15.getCategoryPlot();
    org.jfree.chart.plot.PlotOrientation var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var17.setOrientation(var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }


    org.jfree.chart.ui.Library var4 = new org.jfree.chart.ui.Library("hi!", "", "CategoryLabelEntity: category=null, tooltip=hi!, url=", "CategoryLabelEntity: category=null, tooltip=hi!, url=");

  }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    var6.setAnchorValue(0.0d, true);
    org.jfree.chart.axis.CategoryAxis var10 = var6.getDomainAxis();
    java.awt.Graphics2D var11 = null;
    org.jfree.chart.LegendItemSource var12 = null;
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle(var12);
    org.jfree.chart.util.RectangleInsets var14 = var13.getItemLabelPadding();
    org.jfree.chart.LegendItemSource var15 = null;
    org.jfree.chart.title.LegendTitle var16 = new org.jfree.chart.title.LegendTitle(var15);
    org.jfree.chart.util.RectangleInsets var17 = var16.getItemLabelPadding();
    double var18 = var17.getTop();
    var13.setPadding(var17);
    org.jfree.chart.util.Size2D var20 = new org.jfree.chart.util.Size2D();
    boolean var22 = var20.equals((java.lang.Object)(-1L));
    double var23 = var20.getWidth();
    double var24 = var20.getHeight();
    org.jfree.chart.util.RectangleAnchor var27 = null;
    java.awt.geom.Rectangle2D var28 = org.jfree.chart.util.RectangleAnchor.createRectangle(var20, 2.0d, (-1.0d), var27);
    org.jfree.chart.axis.CategoryLabelPositions var31 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var32 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var33 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var31, var32);
    org.jfree.chart.util.RectangleAnchor var34 = var32.getCategoryAnchor();
    java.awt.geom.Rectangle2D var35 = org.jfree.chart.util.RectangleAnchor.createRectangle(var20, 2.0d, 1.0d, var34);
    java.awt.geom.Rectangle2D var36 = var17.createOutsetRectangle(var35);
    java.awt.geom.Point2D var37 = null;
    org.jfree.chart.plot.PlotState var38 = null;
    org.jfree.chart.plot.PlotRenderingInfo var39 = null;
    var6.draw(var11, var36, var37, var38, var39);
    var6.setRangeCrosshairVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test357() {}
//   public void test357() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var4 = null;
//     var3.setPlot(var4);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var3, var6);
//     org.jfree.chart.LegendItemSource var8 = null;
//     org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
//     org.jfree.chart.util.RectangleEdge var10 = var9.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var12 = var11.getNextOutlinePaint();
//     var9.setBackgroundPaint(var12);
//     var7.setOutlinePaint(var12);
//     org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var7);
//     var15.fireChartChanged();
//     var15.setNotify(false);
//     var15.fireChartChanged();
//     org.jfree.chart.plot.CategoryPlot var20 = var15.getCategoryPlot();
//     boolean var21 = var15.getAntiAlias();
//     org.jfree.chart.ChartRenderingInfo var24 = null;
//     var15.handleClick(1, 255, var24);
// 
//   }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    boolean var2 = var0.containsKey("Size2D[width=0.0, height=0.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.util.RectangleInsets var1 = var0.getPadding();
    var0.setHeight(10.0d);
    org.jfree.chart.block.BlockFrame var4 = var0.getFrame();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }


    boolean var0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == true);

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = java.util.ResourceBundle.getBundle("hi!");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test362() {}
//   public void test362() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var1 = null;
//     var0.setPlot(var1);
//     var0.setLowerBound(2.0d);
//     java.lang.String var5 = var0.getLabelToolTip();
//     org.jfree.chart.axis.NumberTickUnit var6 = var0.getTickUnit();
//     org.jfree.data.Range var7 = var0.getRange();
//     org.jfree.data.category.CategoryDataset var9 = null;
//     org.jfree.chart.axis.CategoryAxis var10 = null;
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var12 = null;
//     var11.setPlot(var12);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var9, var10, (org.jfree.chart.axis.ValueAxis)var11, var14);
//     org.jfree.chart.LegendItemSource var16 = null;
//     org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle(var16);
//     org.jfree.chart.util.RectangleEdge var18 = var17.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var19 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var20 = var19.getNextOutlinePaint();
//     var17.setBackgroundPaint(var20);
//     var15.setOutlinePaint(var20);
//     org.jfree.chart.JFreeChart var23 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var15);
//     var23.fireChartChanged();
//     var23.setTextAntiAlias(false);
//     org.jfree.chart.plot.CategoryPlot var27 = var23.getCategoryPlot();
//     var27.clearRangeAxes();
//     org.jfree.chart.axis.AxisSpace var29 = new org.jfree.chart.axis.AxisSpace();
//     java.lang.Object var30 = var29.clone();
//     org.jfree.chart.axis.AxisSpace var31 = new org.jfree.chart.axis.AxisSpace();
//     var29.ensureAtLeast(var31);
//     double var33 = var31.getTop();
//     var27.setFixedRangeAxisSpace(var31);
//     var0.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var27);
//     org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.data.category.CategoryDataset var38 = null;
//     org.jfree.chart.axis.CategoryAxis var39 = null;
//     org.jfree.chart.axis.NumberAxis var40 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var41 = null;
//     var40.setPlot(var41);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var43 = null;
//     org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot(var38, var39, (org.jfree.chart.axis.ValueAxis)var40, var43);
//     org.jfree.chart.LegendItemSource var45 = null;
//     org.jfree.chart.title.LegendTitle var46 = new org.jfree.chart.title.LegendTitle(var45);
//     org.jfree.chart.util.RectangleEdge var47 = var46.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var48 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var49 = var48.getNextOutlinePaint();
//     var46.setBackgroundPaint(var49);
//     var44.setOutlinePaint(var49);
//     org.jfree.chart.JFreeChart var52 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var44);
//     var52.fireChartChanged();
//     var52.setTextAntiAlias(false);
//     java.util.List var56 = var52.getSubtitles();
//     org.jfree.chart.util.RectangleInsets var57 = var52.getPadding();
//     org.jfree.chart.plot.CategoryPlot var58 = var52.getCategoryPlot();
//     var36.addChangeListener((org.jfree.chart.event.AxisChangeListener)var58);
//     var27.setParent((org.jfree.chart.plot.Plot)var58);
//     
//     // Checks the contract:  equals-hashcode on var19 and var48
//     assertTrue("Contract failed: equals-hashcode on var19 and var48", var19.equals(var48) ? var19.hashCode() == var48.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var48 and var19
//     assertTrue("Contract failed: equals-hashcode on var48 and var19", var48.equals(var19) ? var48.hashCode() == var19.hashCode() : true);
// 
//   }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.util.RectangleEdge var2 = var1.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var3 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var4 = var3.getNextOutlinePaint();
    var1.setBackgroundPaint(var4);
    org.jfree.chart.text.TextBlock var6 = new org.jfree.chart.text.TextBlock();
    java.util.List var7 = var6.getLines();
    boolean var8 = var1.equals((java.lang.Object)var6);
    org.jfree.chart.event.TitleChangeEvent var9 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title)var1);
    org.jfree.chart.LegendItemSource var10 = null;
    org.jfree.chart.title.LegendTitle var11 = new org.jfree.chart.title.LegendTitle(var10);
    org.jfree.chart.util.RectangleInsets var12 = var11.getItemLabelPadding();
    org.jfree.chart.util.VerticalAlignment var13 = var11.getVerticalAlignment();
    org.jfree.chart.block.BlockContainer var14 = var11.getItemContainer();
    org.jfree.chart.LegendItemSource var15 = null;
    org.jfree.chart.title.LegendTitle var16 = new org.jfree.chart.title.LegendTitle(var15);
    org.jfree.chart.util.RectangleInsets var17 = var16.getItemLabelPadding();
    double var19 = var17.calculateTopOutset(4.0d);
    var14.setMargin(var17);
    java.awt.geom.Rectangle2D var21 = var14.getBounds();
    org.jfree.chart.LegendItemSource var22 = null;
    org.jfree.chart.title.LegendTitle var23 = new org.jfree.chart.title.LegendTitle(var22);
    org.jfree.chart.util.RectangleInsets var24 = var23.getItemLabelPadding();
    org.jfree.chart.util.RectangleAnchor var25 = var23.getLegendItemGraphicLocation();
    java.awt.geom.Point2D var26 = org.jfree.chart.util.RectangleAnchor.coordinates(var21, var25);
    var1.setLegendItemGraphicAnchor(var25);
    var1.setWidth(4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var4 = null;
    var3.setPlot(var4);
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var3, var6);
    var7.setAnchorValue(0.0d, true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var13 = null;
    var11.setSeriesItemLabelsVisible(0, var13, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var17 = null;
    var11.setSeriesToolTipGenerator(1, var17, false);
    org.jfree.chart.urls.CategoryURLGenerator var20 = null;
    var11.setBaseURLGenerator(var20);
    java.awt.Graphics2D var22 = null;
    org.jfree.chart.plot.CategoryPlot var23 = null;
    org.jfree.chart.axis.ValueAxis var24 = null;
    org.jfree.chart.plot.Marker var25 = null;
    java.awt.geom.Rectangle2D var26 = null;
    var11.drawRangeMarker(var22, var23, var24, var25, var26);
    boolean var29 = var11.isSeriesVisibleInLegend(0);
    var7.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var11);
    org.jfree.chart.axis.CategoryAxis var31 = null;
    java.util.List var32 = var7.getCategoriesForAxis(var31);
    java.awt.Paint var33 = var7.getNoDataMessagePaint();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var34 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.chart.renderer.category.CategoryItemRenderer var35 = var7.getRendererForDataset((org.jfree.data.category.CategoryDataset)var34);
    org.jfree.data.general.PieDataset var37 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var34, (java.lang.Comparable)(-1L));
    org.jfree.data.category.CategoryDataset var38 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable)' ', (org.jfree.data.KeyedValues)var37);
    org.jfree.data.Range var39 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);

  }

  public void test365() {}
//   public void test365() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }
// 
// 
//     org.jfree.chart.LegendItemSource var0 = null;
//     org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
//     org.jfree.chart.util.RectangleInsets var2 = var1.getItemLabelPadding();
//     org.jfree.chart.util.VerticalAlignment var3 = var1.getVerticalAlignment();
//     org.jfree.chart.block.BlockContainer var4 = var1.getItemContainer();
//     org.jfree.chart.LegendItemSource var5 = null;
//     org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle(var5);
//     org.jfree.chart.util.RectangleInsets var7 = var6.getItemLabelPadding();
//     double var9 = var7.calculateTopOutset(4.0d);
//     var4.setMargin(var7);
//     java.awt.geom.Rectangle2D var11 = var4.getBounds();
//     java.awt.Graphics2D var12 = null;
//     java.awt.geom.Rectangle2D var13 = null;
//     java.lang.Object var15 = var4.draw(var12, var13, (java.lang.Object)0.0f);
// 
//   }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    boolean var1 = var0.isNegativeArrowVisible();
    java.lang.String var2 = var0.getLabelURL();
    var0.setLabelAngle(6.0d);
    boolean var5 = var0.isVisible();
    var0.setUpperBound(Double.NaN);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test367() {}
//   public void test367() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }
// 
// 
//     org.jfree.chart.LegendItemSource var0 = null;
//     org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
//     org.jfree.chart.util.RectangleEdge var2 = var1.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var3 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var4 = var3.getNextOutlinePaint();
//     var1.setBackgroundPaint(var4);
//     org.jfree.chart.util.HorizontalAlignment var6 = var1.getHorizontalAlignment();
//     double var7 = var1.getContentYOffset();
//     java.awt.Graphics2D var8 = null;
//     org.jfree.chart.util.HorizontalAlignment var9 = null;
//     org.jfree.chart.LegendItemSource var10 = null;
//     org.jfree.chart.title.LegendTitle var11 = new org.jfree.chart.title.LegendTitle(var10);
//     org.jfree.chart.util.RectangleInsets var12 = var11.getItemLabelPadding();
//     org.jfree.chart.util.VerticalAlignment var13 = var11.getVerticalAlignment();
//     org.jfree.chart.block.ColumnArrangement var16 = new org.jfree.chart.block.ColumnArrangement(var9, var13, 0.0d, 2.0d);
//     org.jfree.chart.block.BlockContainer var17 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.util.RectangleInsets var18 = var17.getPadding();
//     java.awt.Graphics2D var19 = null;
//     org.jfree.chart.block.RectangleConstraint var22 = new org.jfree.chart.block.RectangleConstraint(0.0d, 0.0d);
//     org.jfree.chart.util.Size2D var23 = var16.arrange(var17, var19, var22);
//     org.jfree.chart.util.Size2D var24 = var1.arrange(var8, var22);
// 
//   }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var4 = null;
    var3.setPlot(var4);
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var3, var6);
    org.jfree.chart.LegendItemSource var8 = null;
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
    org.jfree.chart.util.RectangleEdge var10 = var9.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var12 = var11.getNextOutlinePaint();
    var9.setBackgroundPaint(var12);
    var7.setOutlinePaint(var12);
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var7);
    var15.fireChartChanged();
    var15.setNotify(false);
    java.awt.Paint var19 = var15.getBackgroundPaint();
    org.jfree.chart.ChartRenderingInfo var24 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var25 = var15.createBufferedImage(0, (-1), 4.0d, 6.0d, var24);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test369() {}
//   public void test369() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }
// 
// 
//     org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
//     java.util.List var1 = var0.getColumnKeys();
//     java.lang.Object var4 = var0.getObject((java.lang.Comparable)(-1), (java.lang.Comparable)0L);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var5 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var6 = var5.getPositiveItemLabelPositionFallback();
//     java.awt.Paint var9 = var5.getItemLabelPaint((-123), (-1));
//     org.jfree.data.category.CategoryDataset var10 = null;
//     org.jfree.chart.axis.CategoryAxis var11 = null;
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var13 = null;
//     var12.setPlot(var13);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var15 = null;
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var10, var11, (org.jfree.chart.axis.ValueAxis)var12, var15);
//     java.awt.Stroke var17 = var12.getTickMarkStroke();
//     org.jfree.chart.LegendItemSource var18 = null;
//     org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle(var18);
//     org.jfree.chart.util.RectangleInsets var20 = var19.getItemLabelPadding();
//     double var21 = var20.getTop();
//     org.jfree.chart.block.LineBorder var22 = new org.jfree.chart.block.LineBorder(var9, var17, var20);
//     java.awt.Stroke var23 = var22.getStroke();
//     var0.setObject((java.lang.Object)var22, (java.lang.Comparable)"", (java.lang.Comparable)4.0d);
//     java.awt.Graphics2D var27 = null;
//     org.jfree.chart.ChartRenderingInfo var28 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var29 = new org.jfree.chart.plot.PlotRenderingInfo(var28);
//     java.lang.Object var30 = var29.clone();
//     org.jfree.chart.LegendItemSource var31 = null;
//     org.jfree.chart.title.LegendTitle var32 = new org.jfree.chart.title.LegendTitle(var31);
//     org.jfree.chart.util.RectangleInsets var33 = var32.getItemLabelPadding();
//     double var35 = var33.calculateTopOutset(4.0d);
//     org.jfree.data.category.CategoryDataset var36 = null;
//     org.jfree.chart.axis.CategoryAxis var37 = null;
//     org.jfree.chart.axis.NumberAxis var38 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var39 = null;
//     var38.setPlot(var39);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var41 = null;
//     org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot(var36, var37, (org.jfree.chart.axis.ValueAxis)var38, var41);
//     org.jfree.chart.LegendItemSource var43 = null;
//     org.jfree.chart.title.LegendTitle var44 = new org.jfree.chart.title.LegendTitle(var43);
//     org.jfree.chart.util.RectangleEdge var45 = var44.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var46 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var47 = var46.getNextOutlinePaint();
//     var44.setBackgroundPaint(var47);
//     var42.setOutlinePaint(var47);
//     org.jfree.data.category.CategoryDataset var50 = null;
//     org.jfree.chart.axis.CategoryAxis var51 = null;
//     org.jfree.chart.axis.NumberAxis var52 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var53 = null;
//     var52.setPlot(var53);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var55 = null;
//     org.jfree.chart.plot.CategoryPlot var56 = new org.jfree.chart.plot.CategoryPlot(var50, var51, (org.jfree.chart.axis.ValueAxis)var52, var55);
//     org.jfree.chart.axis.NumberAxis var57 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var58 = null;
//     var57.setPlot(var58);
//     org.jfree.chart.axis.ValueAxis[] var60 = new org.jfree.chart.axis.ValueAxis[] { var57};
//     var56.setRangeAxes(var60);
//     var42.setParent((org.jfree.chart.plot.Plot)var56);
//     java.awt.Stroke var63 = var56.getRangeCrosshairStroke();
//     java.awt.Graphics2D var64 = null;
//     org.jfree.chart.LegendItemSource var65 = null;
//     org.jfree.chart.title.LegendTitle var66 = new org.jfree.chart.title.LegendTitle(var65);
//     org.jfree.chart.util.RectangleInsets var67 = var66.getItemLabelPadding();
//     org.jfree.chart.LegendItemSource var68 = null;
//     org.jfree.chart.title.LegendTitle var69 = new org.jfree.chart.title.LegendTitle(var68);
//     org.jfree.chart.util.RectangleInsets var70 = var69.getItemLabelPadding();
//     double var71 = var70.getTop();
//     var66.setPadding(var70);
//     org.jfree.chart.util.Size2D var73 = new org.jfree.chart.util.Size2D();
//     boolean var75 = var73.equals((java.lang.Object)(-1L));
//     double var76 = var73.getWidth();
//     double var77 = var73.getHeight();
//     org.jfree.chart.util.RectangleAnchor var80 = null;
//     java.awt.geom.Rectangle2D var81 = org.jfree.chart.util.RectangleAnchor.createRectangle(var73, 2.0d, (-1.0d), var80);
//     org.jfree.chart.axis.CategoryLabelPositions var84 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var85 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var86 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var84, var85);
//     org.jfree.chart.util.RectangleAnchor var87 = var85.getCategoryAnchor();
//     java.awt.geom.Rectangle2D var88 = org.jfree.chart.util.RectangleAnchor.createRectangle(var73, 2.0d, 1.0d, var87);
//     java.awt.geom.Rectangle2D var89 = var70.createOutsetRectangle(var88);
//     org.jfree.chart.plot.PlotRenderingInfo var91 = null;
//     boolean var92 = var56.render(var64, var89, 255, var91);
//     java.awt.geom.Rectangle2D var95 = var33.createInsetRectangle(var89, false, false);
//     var29.setDataArea(var89);
//     var22.draw(var27, var89);
// 
//   }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = var0.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var5 = var0.getPositiveItemLabelPosition(100, 0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var6 = var0.getLegendItemToolTipGenerator();
    var0.setItemLabelAnchorOffset(100.0d);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var16 = new org.jfree.chart.entity.ChartEntity(var14, "Range[-1.0,-1.0]");
    org.jfree.chart.renderer.category.StatisticalBarRenderer var17 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var19 = null;
    var17.setSeriesItemLabelsVisible(0, var19, false);
    java.awt.Stroke var22 = var17.getErrorIndicatorStroke();
    java.awt.Paint var23 = null;
    org.jfree.chart.LegendItem var24 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var14, var22, var23);
    boolean var25 = var24.isLineVisible();
    org.jfree.chart.util.StandardGradientPaintTransformer var26 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    java.lang.Object var27 = var26.clone();
    java.lang.Object var28 = var26.clone();
    var24.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var26);
    var0.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var26);
    var0.setSeriesVisible(255, (java.lang.Boolean)false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.util.RectangleInsets var1 = var0.getPadding();
    org.jfree.chart.util.HorizontalAlignment var2 = null;
    org.jfree.chart.util.VerticalAlignment var3 = null;
    org.jfree.chart.block.FlowArrangement var6 = new org.jfree.chart.block.FlowArrangement(var2, var3, 0.0d, 0.0d);
    var0.setArrangement((org.jfree.chart.block.Arrangement)var6);
    org.jfree.chart.LegendItemSource var8 = null;
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
    org.jfree.chart.util.RectangleEdge var10 = var9.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var12 = var11.getNextOutlinePaint();
    var9.setBackgroundPaint(var12);
    org.jfree.chart.LegendItemSource var14 = null;
    org.jfree.chart.title.LegendTitle var15 = new org.jfree.chart.title.LegendTitle(var14);
    org.jfree.chart.util.RectangleEdge var16 = var15.getLegendItemGraphicEdge();
    java.awt.Paint var17 = var15.getItemPaint();
    var15.setNotify(true);
    boolean var20 = var9.equals((java.lang.Object)var15);
    var0.add((org.jfree.chart.block.Block)var9);
    org.jfree.chart.block.Arrangement var22 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setArrangement(var22);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);

  }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String[] var2 = var0.getStringArray("hi!");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }


    org.jfree.chart.util.BooleanList var0 = new org.jfree.chart.util.BooleanList();
    org.jfree.chart.util.StandardGradientPaintTransformer var1 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    java.lang.Object var2 = var1.clone();
    org.jfree.chart.event.ChartChangeEvent var3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1);
    org.jfree.chart.event.ChartChangeEventType var4 = var3.getType();
    boolean var5 = var0.equals((java.lang.Object)var4);
    var0.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }


    org.jfree.data.statistics.MeanAndStandardDeviation var2 = new org.jfree.data.statistics.MeanAndStandardDeviation(100.0d, 0.0d);
    boolean var4 = var2.equals((java.lang.Object)'a');
    java.lang.Number var5 = var2.getMean();
    java.lang.Number var6 = var2.getMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 100.0d+ "'", var5.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 100.0d+ "'", var6.equals(100.0d));

  }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = java.util.ResourceBundle.getBundle("CategoryLabelWidthType.CATEGORY");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test376() {}
//   public void test376() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     var0.setMaximumCategoryLabelWidthRatio(0.95f);
//     double var3 = var0.getLowerMargin();
//     java.lang.Object var4 = var0.clone();
//     java.awt.Font var6 = var0.getTickLabelFont((java.lang.Comparable)"null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
//     int var7 = var0.getCategoryLabelPositionOffset();
//     float var8 = var0.getMaximumCategoryLabelWidthRatio();
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var11 = null;
//     var10.setPlot(var11);
//     var10.setLowerBound(2.0d);
//     java.lang.String var15 = var10.getLabelToolTip();
//     org.jfree.data.category.CategoryDataset var16 = null;
//     org.jfree.chart.axis.CategoryAxis var17 = null;
//     org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var19 = null;
//     var18.setPlot(var19);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var21 = null;
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot(var16, var17, (org.jfree.chart.axis.ValueAxis)var18, var21);
//     java.awt.Stroke var23 = var18.getTickMarkStroke();
//     var18.setVerticalTickLabels(false);
//     org.jfree.data.category.CategoryDataset var26 = null;
//     org.jfree.chart.axis.CategoryAxis var27 = null;
//     org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var29 = null;
//     var28.setPlot(var29);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var31 = null;
//     org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot(var26, var27, (org.jfree.chart.axis.ValueAxis)var28, var31);
//     var32.setAnchorValue(0.0d, true);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var36 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var38 = null;
//     var36.setSeriesItemLabelsVisible(0, var38, false);
//     org.jfree.chart.labels.CategoryToolTipGenerator var42 = null;
//     var36.setSeriesToolTipGenerator(1, var42, false);
//     org.jfree.chart.urls.CategoryURLGenerator var45 = null;
//     var36.setBaseURLGenerator(var45);
//     java.awt.Graphics2D var47 = null;
//     org.jfree.chart.plot.CategoryPlot var48 = null;
//     org.jfree.chart.axis.ValueAxis var49 = null;
//     org.jfree.chart.plot.Marker var50 = null;
//     java.awt.geom.Rectangle2D var51 = null;
//     var36.drawRangeMarker(var47, var48, var49, var50, var51);
//     boolean var54 = var36.isSeriesVisibleInLegend(0);
//     var32.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var36);
//     var18.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var32);
//     var10.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var32);
//     java.awt.geom.Rectangle2D var58 = null;
//     org.jfree.chart.axis.AxisSpace var59 = new org.jfree.chart.axis.AxisSpace();
//     org.jfree.chart.LegendItemSource var61 = null;
//     org.jfree.chart.title.LegendTitle var62 = new org.jfree.chart.title.LegendTitle(var61);
//     org.jfree.chart.util.RectangleEdge var63 = var62.getLegendItemGraphicEdge();
//     org.jfree.chart.util.RectangleEdge var64 = org.jfree.chart.util.RectangleEdge.opposite(var63);
//     var59.ensureAtLeast(100.0d, var64);
//     org.jfree.chart.axis.AxisSpace var66 = new org.jfree.chart.axis.AxisSpace();
//     org.jfree.chart.LegendItemSource var68 = null;
//     org.jfree.chart.title.LegendTitle var69 = new org.jfree.chart.title.LegendTitle(var68);
//     org.jfree.chart.util.RectangleEdge var70 = var69.getLegendItemGraphicEdge();
//     org.jfree.chart.util.RectangleEdge var71 = org.jfree.chart.util.RectangleEdge.opposite(var70);
//     var66.ensureAtLeast(100.0d, var71);
//     org.jfree.chart.axis.AxisSpace var73 = var0.reserveSpace(var9, (org.jfree.chart.plot.Plot)var32, var58, var64, var66);
// 
//   }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = var0.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var5 = var0.getPositiveItemLabelPosition(100, 0);
    org.jfree.chart.urls.CategoryURLGenerator var6 = var0.getBaseURLGenerator();
    int var7 = var0.getColumnCount();
    java.awt.Shape var9 = var0.getSeriesShape((-855310));
    org.jfree.chart.annotations.CategoryAnnotation var10 = null;
    org.jfree.chart.util.Layer var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var10, var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }


    org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
    java.lang.Object var1 = var0.clone();
    org.jfree.chart.axis.AxisCollection var2 = new org.jfree.chart.axis.AxisCollection();
    java.util.List var3 = var2.getAxesAtTop();
    boolean var4 = var0.equals((java.lang.Object)var2);
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var6 = null;
    var5.setPlot(var6);
    var5.setLowerBound(2.0d);
    java.lang.String var10 = var5.getLabelToolTip();
    java.awt.Shape var11 = var5.getRightArrow();
    org.jfree.chart.LegendItemSource var12 = null;
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle(var12);
    org.jfree.chart.util.RectangleEdge var14 = var13.getLegendItemGraphicEdge();
    org.jfree.chart.util.RectangleEdge var15 = org.jfree.chart.util.RectangleEdge.opposite(var14);
    boolean var16 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var15);
    var2.add((org.jfree.chart.axis.Axis)var5, var15);
    org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var19 = null;
    var18.setPlot(var19);
    var18.setLowerBound(2.0d);
    java.lang.String var23 = var18.getLabelToolTip();
    org.jfree.data.category.CategoryDataset var24 = null;
    org.jfree.chart.axis.CategoryAxis var25 = null;
    org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var27 = null;
    var26.setPlot(var27);
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var24, var25, (org.jfree.chart.axis.ValueAxis)var26, var29);
    org.jfree.chart.LegendItemSource var31 = null;
    org.jfree.chart.title.LegendTitle var32 = new org.jfree.chart.title.LegendTitle(var31);
    org.jfree.chart.util.RectangleEdge var33 = var32.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var34 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var35 = var34.getNextOutlinePaint();
    var32.setBackgroundPaint(var35);
    var30.setOutlinePaint(var35);
    org.jfree.data.category.CategoryDataset var38 = null;
    org.jfree.chart.axis.CategoryAxis var39 = null;
    org.jfree.chart.axis.NumberAxis var40 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var41 = null;
    var40.setPlot(var41);
    org.jfree.chart.renderer.category.CategoryItemRenderer var43 = null;
    org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot(var38, var39, (org.jfree.chart.axis.ValueAxis)var40, var43);
    org.jfree.chart.axis.NumberAxis var45 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var46 = null;
    var45.setPlot(var46);
    org.jfree.chart.axis.ValueAxis[] var48 = new org.jfree.chart.axis.ValueAxis[] { var45};
    var44.setRangeAxes(var48);
    var30.setParent((org.jfree.chart.plot.Plot)var44);
    java.awt.Stroke var51 = var44.getRangeCrosshairStroke();
    var18.addChangeListener((org.jfree.chart.event.AxisChangeListener)var44);
    org.jfree.chart.LegendItemSource var53 = null;
    org.jfree.chart.title.LegendTitle var54 = new org.jfree.chart.title.LegendTitle(var53);
    org.jfree.chart.util.RectangleEdge var55 = var54.getLegendItemGraphicEdge();
    org.jfree.chart.util.RectangleEdge var56 = org.jfree.chart.util.RectangleEdge.opposite(var55);
    boolean var57 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var56);
    var2.add((org.jfree.chart.axis.Axis)var18, var56);
    java.lang.Object var59 = var18.clone();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var18.setRange(2.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);

  }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = var0.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var5 = var0.getPositiveItemLabelPosition(100, 0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var6 = var0.getLegendItemToolTipGenerator();
    var0.setItemLabelAnchorOffset(100.0d);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var16 = new org.jfree.chart.entity.ChartEntity(var14, "Range[-1.0,-1.0]");
    org.jfree.chart.renderer.category.StatisticalBarRenderer var17 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var19 = null;
    var17.setSeriesItemLabelsVisible(0, var19, false);
    java.awt.Stroke var22 = var17.getErrorIndicatorStroke();
    java.awt.Paint var23 = null;
    org.jfree.chart.LegendItem var24 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var14, var22, var23);
    boolean var25 = var24.isLineVisible();
    org.jfree.chart.util.StandardGradientPaintTransformer var26 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    java.lang.Object var27 = var26.clone();
    java.lang.Object var28 = var26.clone();
    var24.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var26);
    var0.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var26);
    java.lang.Boolean var32 = var0.getSeriesVisibleInLegend((-855310));
    java.awt.Paint var35 = var0.getItemOutlinePaint((-1), 0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesVisibleInLegend((-1), (java.lang.Boolean)false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var0, 1.0E-8d, Double.NaN);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }


    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(1.0f);
    java.awt.Stroke var6 = null;
    java.lang.Object var8 = null;
    org.jfree.data.KeyedObject var9 = new org.jfree.data.KeyedObject((java.lang.Comparable)' ', var8);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var12 = null;
    var10.setSeriesItemLabelsVisible(0, var12, false);
    java.awt.Paint var15 = var10.getBaseOutlinePaint();
    boolean var16 = var9.equals((java.lang.Object)var15);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var17 = new org.jfree.chart.LegendItem("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", "Size2D[width=0.0, height=0.0]", "RectangleAnchor.CENTER", "java.awt.Color[r=0,g=0,b=0]", var5, var6, var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);

  }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }


    org.jfree.chart.block.FlowArrangement var0 = new org.jfree.chart.block.FlowArrangement();
    var0.clear();

  }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }


    org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
    java.lang.Object var1 = var0.clone();
    org.jfree.chart.axis.AxisCollection var2 = new org.jfree.chart.axis.AxisCollection();
    java.util.List var3 = var2.getAxesAtTop();
    boolean var4 = var0.equals((java.lang.Object)var2);
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var6 = null;
    var5.setPlot(var6);
    var5.setLowerBound(2.0d);
    java.lang.String var10 = var5.getLabelToolTip();
    java.awt.Shape var11 = var5.getRightArrow();
    org.jfree.chart.LegendItemSource var12 = null;
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle(var12);
    org.jfree.chart.util.RectangleEdge var14 = var13.getLegendItemGraphicEdge();
    org.jfree.chart.util.RectangleEdge var15 = org.jfree.chart.util.RectangleEdge.opposite(var14);
    boolean var16 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var15);
    var2.add((org.jfree.chart.axis.Axis)var5, var15);
    org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var19 = null;
    var18.setPlot(var19);
    var18.setLowerBound(2.0d);
    java.lang.String var23 = var18.getLabelToolTip();
    org.jfree.data.category.CategoryDataset var24 = null;
    org.jfree.chart.axis.CategoryAxis var25 = null;
    org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var27 = null;
    var26.setPlot(var27);
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var24, var25, (org.jfree.chart.axis.ValueAxis)var26, var29);
    org.jfree.chart.LegendItemSource var31 = null;
    org.jfree.chart.title.LegendTitle var32 = new org.jfree.chart.title.LegendTitle(var31);
    org.jfree.chart.util.RectangleEdge var33 = var32.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var34 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var35 = var34.getNextOutlinePaint();
    var32.setBackgroundPaint(var35);
    var30.setOutlinePaint(var35);
    org.jfree.data.category.CategoryDataset var38 = null;
    org.jfree.chart.axis.CategoryAxis var39 = null;
    org.jfree.chart.axis.NumberAxis var40 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var41 = null;
    var40.setPlot(var41);
    org.jfree.chart.renderer.category.CategoryItemRenderer var43 = null;
    org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot(var38, var39, (org.jfree.chart.axis.ValueAxis)var40, var43);
    org.jfree.chart.axis.NumberAxis var45 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var46 = null;
    var45.setPlot(var46);
    org.jfree.chart.axis.ValueAxis[] var48 = new org.jfree.chart.axis.ValueAxis[] { var45};
    var44.setRangeAxes(var48);
    var30.setParent((org.jfree.chart.plot.Plot)var44);
    java.awt.Stroke var51 = var44.getRangeCrosshairStroke();
    var18.addChangeListener((org.jfree.chart.event.AxisChangeListener)var44);
    org.jfree.chart.LegendItemSource var53 = null;
    org.jfree.chart.title.LegendTitle var54 = new org.jfree.chart.title.LegendTitle(var53);
    org.jfree.chart.util.RectangleEdge var55 = var54.getLegendItemGraphicEdge();
    org.jfree.chart.util.RectangleEdge var56 = org.jfree.chart.util.RectangleEdge.opposite(var55);
    boolean var57 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var56);
    var2.add((org.jfree.chart.axis.Axis)var18, var56);
    boolean var59 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);

  }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }


    org.jfree.data.Range var1 = null;
    org.jfree.data.Range var3 = org.jfree.data.Range.expandToInclude(var1, (-1.0d));
    org.jfree.data.Range var4 = null;
    org.jfree.data.Range var6 = org.jfree.data.Range.expandToInclude(var4, (-1.0d));
    org.jfree.data.Range var7 = org.jfree.data.Range.combine(var3, var6);
    double var8 = var7.getLength();
    boolean var10 = var7.contains(0.0d);
    org.jfree.chart.block.RectangleConstraint var11 = new org.jfree.chart.block.RectangleConstraint(10.0d, var7);
    org.jfree.chart.block.RectangleConstraint var13 = var11.toFixedWidth(6.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test385() {}
//   public void test385() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var2 = null;
//     var0.setSeriesItemLabelsVisible(0, var2, false);
//     java.awt.Stroke var5 = var0.getErrorIndicatorStroke();
//     org.jfree.chart.plot.DrawingSupplier var6 = var0.getDrawingSupplier();
//     java.lang.Boolean var8 = var0.getSeriesCreateEntities(10);
//     java.awt.Paint var9 = var0.getBaseOutlinePaint();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var13 = var11.getSeriesItemLabelsVisible(100);
//     org.jfree.chart.labels.ItemLabelPosition var16 = var11.getPositiveItemLabelPosition(100, 0);
//     org.jfree.chart.urls.CategoryURLGenerator var17 = var11.getBaseURLGenerator();
//     java.lang.Boolean var19 = var11.getSeriesItemLabelsVisible((-855310));
//     java.awt.Color var22 = java.awt.Color.getColor("", (-1));
//     var11.setBasePaint((java.awt.Paint)var22, true);
//     var0.setSeriesPaint(0, (java.awt.Paint)var22, false);
//     int var27 = var0.getRowCount();
//     org.jfree.chart.labels.ItemLabelPosition var29 = new org.jfree.chart.labels.ItemLabelPosition();
//     org.jfree.chart.LegendItemSource var30 = null;
//     org.jfree.chart.title.LegendTitle var31 = new org.jfree.chart.title.LegendTitle(var30);
//     org.jfree.chart.util.RectangleEdge var32 = var31.getLegendItemGraphicEdge();
//     org.jfree.chart.util.RectangleEdge var33 = org.jfree.chart.util.RectangleEdge.opposite(var32);
//     boolean var34 = var29.equals((java.lang.Object)var33);
//     java.lang.Object var35 = null;
//     boolean var36 = var29.equals(var35);
//     var0.setSeriesNegativeItemLabelPosition(255, var29);
//     
//     // Checks the contract:  equals-hashcode on var16 and var29
//     assertTrue("Contract failed: equals-hashcode on var16 and var29", var16.equals(var29) ? var16.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var16
//     assertTrue("Contract failed: equals-hashcode on var29 and var16", var29.equals(var16) ? var29.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(0.0d, 0.0d);
    double var3 = var2.getWidth();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);

  }

  public void test387() {}
//   public void test387() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }
// 
// 
//     org.jfree.data.KeyedObjects2D var1 = new org.jfree.data.KeyedObjects2D();
//     java.util.List var2 = var1.getColumnKeys();
//     int var4 = var1.getRowIndex((java.lang.Comparable)100);
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
//     boolean var6 = var5.isNegativeArrowVisible();
//     java.lang.String var7 = var5.getLabelURL();
//     var5.setLabelAngle(6.0d);
//     var5.setAutoRange(false);
//     java.awt.Font var12 = var5.getTickLabelFont();
//     var1.setObject((java.lang.Object)var12, (java.lang.Comparable)"CategoryLabelEntity: category=null, tooltip=hi!, url=", (java.lang.Comparable)"CategoryLabelEntity: category=null, tooltip=hi!, url=");
//     org.jfree.chart.block.LabelBlock var18 = new org.jfree.chart.block.LabelBlock("");
//     java.awt.Font var19 = var18.getFont();
//     java.awt.Color var23 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.95f);
//     org.jfree.chart.text.TextBlock var24 = org.jfree.chart.text.TextUtilities.createTextBlock("CategoryLabelEntity: category=null, tooltip=hi!, url=", var19, (java.awt.Paint)var23);
//     java.awt.Graphics2D var27 = null;
//     org.jfree.chart.text.G2TextMeasurer var28 = new org.jfree.chart.text.G2TextMeasurer(var27);
//     org.jfree.chart.text.TextBlock var29 = org.jfree.chart.text.TextUtilities.createTextBlock("ChartChangeEventType.GENERAL", var12, (java.awt.Paint)var23, 0.0f, 1, (org.jfree.chart.text.TextMeasurer)var28);
// 
//   }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var4 = null;
    var3.setPlot(var4);
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var3, var6);
    org.jfree.chart.LegendItemSource var8 = null;
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
    org.jfree.chart.util.RectangleEdge var10 = var9.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var12 = var11.getNextOutlinePaint();
    var9.setBackgroundPaint(var12);
    var7.setOutlinePaint(var12);
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var7);
    org.jfree.chart.util.RectangleInsets var16 = var7.getAxisOffset();
    org.jfree.chart.plot.PlotOrientation var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.setOrientation(var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }


    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var0 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();

  }

  public void test390() {}
//   public void test390() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }
// 
// 
//     java.util.ResourceBundle.Control var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("NOID", var1);
// 
//   }

  public void test391() {}
//   public void test391() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }
// 
// 
//     org.jfree.chart.LegendItemSource var0 = null;
//     org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
//     org.jfree.chart.util.RectangleEdge var2 = var1.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var3 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var4 = var3.getNextOutlinePaint();
//     var1.setBackgroundPaint(var4);
//     org.jfree.chart.text.TextBlock var6 = new org.jfree.chart.text.TextBlock();
//     java.util.List var7 = var6.getLines();
//     boolean var8 = var1.equals((java.lang.Object)var6);
//     org.jfree.chart.util.RectangleEdge var9 = var1.getLegendItemGraphicEdge();
//     org.jfree.chart.block.BlockContainer var10 = new org.jfree.chart.block.BlockContainer();
//     var1.setWrapper(var10);
//     java.awt.Graphics2D var12 = null;
//     org.jfree.chart.ChartRenderingInfo var13 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var14 = new org.jfree.chart.plot.PlotRenderingInfo(var13);
//     java.lang.Object var15 = var14.clone();
//     org.jfree.chart.LegendItemSource var16 = null;
//     org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle(var16);
//     org.jfree.chart.util.RectangleInsets var18 = var17.getItemLabelPadding();
//     double var20 = var18.calculateTopOutset(4.0d);
//     org.jfree.data.category.CategoryDataset var21 = null;
//     org.jfree.chart.axis.CategoryAxis var22 = null;
//     org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var24 = null;
//     var23.setPlot(var24);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var26 = null;
//     org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot(var21, var22, (org.jfree.chart.axis.ValueAxis)var23, var26);
//     org.jfree.chart.LegendItemSource var28 = null;
//     org.jfree.chart.title.LegendTitle var29 = new org.jfree.chart.title.LegendTitle(var28);
//     org.jfree.chart.util.RectangleEdge var30 = var29.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var31 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var32 = var31.getNextOutlinePaint();
//     var29.setBackgroundPaint(var32);
//     var27.setOutlinePaint(var32);
//     org.jfree.data.category.CategoryDataset var35 = null;
//     org.jfree.chart.axis.CategoryAxis var36 = null;
//     org.jfree.chart.axis.NumberAxis var37 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var38 = null;
//     var37.setPlot(var38);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var40 = null;
//     org.jfree.chart.plot.CategoryPlot var41 = new org.jfree.chart.plot.CategoryPlot(var35, var36, (org.jfree.chart.axis.ValueAxis)var37, var40);
//     org.jfree.chart.axis.NumberAxis var42 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var43 = null;
//     var42.setPlot(var43);
//     org.jfree.chart.axis.ValueAxis[] var45 = new org.jfree.chart.axis.ValueAxis[] { var42};
//     var41.setRangeAxes(var45);
//     var27.setParent((org.jfree.chart.plot.Plot)var41);
//     java.awt.Stroke var48 = var41.getRangeCrosshairStroke();
//     java.awt.Graphics2D var49 = null;
//     org.jfree.chart.LegendItemSource var50 = null;
//     org.jfree.chart.title.LegendTitle var51 = new org.jfree.chart.title.LegendTitle(var50);
//     org.jfree.chart.util.RectangleInsets var52 = var51.getItemLabelPadding();
//     org.jfree.chart.LegendItemSource var53 = null;
//     org.jfree.chart.title.LegendTitle var54 = new org.jfree.chart.title.LegendTitle(var53);
//     org.jfree.chart.util.RectangleInsets var55 = var54.getItemLabelPadding();
//     double var56 = var55.getTop();
//     var51.setPadding(var55);
//     org.jfree.chart.util.Size2D var58 = new org.jfree.chart.util.Size2D();
//     boolean var60 = var58.equals((java.lang.Object)(-1L));
//     double var61 = var58.getWidth();
//     double var62 = var58.getHeight();
//     org.jfree.chart.util.RectangleAnchor var65 = null;
//     java.awt.geom.Rectangle2D var66 = org.jfree.chart.util.RectangleAnchor.createRectangle(var58, 2.0d, (-1.0d), var65);
//     org.jfree.chart.axis.CategoryLabelPositions var69 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var70 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var71 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var69, var70);
//     org.jfree.chart.util.RectangleAnchor var72 = var70.getCategoryAnchor();
//     java.awt.geom.Rectangle2D var73 = org.jfree.chart.util.RectangleAnchor.createRectangle(var58, 2.0d, 1.0d, var72);
//     java.awt.geom.Rectangle2D var74 = var55.createOutsetRectangle(var73);
//     org.jfree.chart.plot.PlotRenderingInfo var76 = null;
//     boolean var77 = var41.render(var49, var74, 255, var76);
//     java.awt.geom.Rectangle2D var80 = var18.createInsetRectangle(var74, false, false);
//     var14.setDataArea(var74);
//     java.awt.geom.Rectangle2D var82 = var14.getDataArea();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var83 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var85 = var83.getSeriesItemLabelsVisible(100);
//     org.jfree.chart.labels.ItemLabelPosition var88 = var83.getPositiveItemLabelPosition(100, 0);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var89 = var83.getLegendItemToolTipGenerator();
//     var83.setItemLabelAnchorOffset(100.0d);
//     org.jfree.chart.annotations.CategoryAnnotation var92 = null;
//     boolean var93 = var83.removeAnnotation(var92);
//     java.awt.Paint var94 = var83.getErrorIndicatorPaint();
//     java.lang.Object var95 = var10.draw(var12, var82, (java.lang.Object)var94);
// 
//   }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.annotations.CategoryAnnotation var1 = null;
    boolean var2 = var0.removeAnnotation(var1);
    boolean var5 = var0.getItemCreateEntity(1, (-1));
    java.awt.Shape var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBaseShape(var6, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }


    org.jfree.chart.ui.ProjectInfo var0 = new org.jfree.chart.ui.ProjectInfo();
    java.lang.String var1 = var0.getLicenceText();
    java.util.List var2 = var0.getContributors();
    var0.setName("HorizontalAlignment.CENTER");
    var0.setCopyright("");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test394() {}
//   public void test394() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var6 = var4.getSeriesItemLabelsVisible(100);
//     org.jfree.chart.labels.ItemLabelPosition var9 = var4.getPositiveItemLabelPosition(100, 0);
//     org.jfree.chart.text.TextAnchor var10 = var9.getRotationAnchor();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var14 = var12.getSeriesItemLabelsVisible(100);
//     org.jfree.chart.labels.ItemLabelPosition var17 = var12.getPositiveItemLabelPosition(100, 0);
//     org.jfree.chart.text.TextAnchor var18 = var17.getRotationAnchor();
//     java.awt.Shape var19 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("CategoryLabelWidthType.CATEGORY", var1, 100.0f, 0.95f, var10, 0.0d, var18);
// 
//   }

  public void test395() {}
//   public void test395() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var2 = var0.getSeriesItemLabelsVisible(100);
//     org.jfree.chart.labels.ItemLabelPosition var5 = var0.getPositiveItemLabelPosition(100, 0);
//     org.jfree.chart.urls.CategoryURLGenerator var6 = var0.getBaseURLGenerator();
//     java.lang.Boolean var8 = var0.getSeriesItemLabelsVisible((-855310));
//     org.jfree.data.category.CategoryDataset var9 = null;
//     org.jfree.chart.axis.CategoryAxis var10 = null;
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var12 = null;
//     var11.setPlot(var12);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var9, var10, (org.jfree.chart.axis.ValueAxis)var11, var14);
//     java.awt.Stroke var16 = var11.getTickMarkStroke();
//     var0.setBaseOutlineStroke(var16);
//     org.jfree.chart.plot.CategoryPlot var18 = var0.getPlot();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var19 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.annotations.CategoryAnnotation var20 = null;
//     boolean var21 = var19.removeAnnotation(var20);
//     boolean var24 = var19.getItemCreateEntity(1, (-1));
//     var19.setAutoPopulateSeriesStroke(false);
//     java.lang.Comparable var27 = null;
//     org.jfree.chart.text.TextBlock var28 = new org.jfree.chart.text.TextBlock();
//     java.awt.Graphics2D var29 = null;
//     org.jfree.chart.util.Size2D var30 = var28.calculateDimensions(var29);
//     org.jfree.data.category.CategoryDataset var32 = null;
//     org.jfree.chart.axis.CategoryAxis var33 = null;
//     org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var35 = null;
//     var34.setPlot(var35);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var37 = null;
//     org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot(var32, var33, (org.jfree.chart.axis.ValueAxis)var34, var37);
//     java.awt.Stroke var39 = var34.getTickMarkStroke();
//     java.awt.Font var40 = var34.getLabelFont();
//     java.awt.Color var43 = java.awt.Color.getColor("", (-1));
//     var28.addLine("CategoryLabelEntity: category=null, tooltip=hi!, url=", var40, (java.awt.Paint)var43);
//     org.jfree.data.KeyedObject var45 = new org.jfree.data.KeyedObject(var27, (java.lang.Object)var40);
//     var19.setBaseItemLabelFont(var40, true);
//     var0.setBaseItemLabelFont(var40, true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var38
//     assertTrue("Contract failed: equals-hashcode on var15 and var38", var15.equals(var38) ? var15.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var15
//     assertTrue("Contract failed: equals-hashcode on var38 and var15", var38.equals(var15) ? var38.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    org.jfree.chart.axis.TickUnitSource var7 = var2.getStandardTickUnits();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var4 = null;
    var3.setPlot(var4);
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var3, var6);
    org.jfree.chart.LegendItemSource var8 = null;
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
    org.jfree.chart.util.RectangleEdge var10 = var9.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var12 = var11.getNextOutlinePaint();
    var9.setBackgroundPaint(var12);
    var7.setOutlinePaint(var12);
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var7);
    var15.fireChartChanged();
    var15.setTextAntiAlias(false);
    org.jfree.chart.plot.CategoryPlot var19 = var15.getCategoryPlot();
    var19.clearRangeAxes();
    org.jfree.chart.block.LabelBlock var24 = new org.jfree.chart.block.LabelBlock("");
    java.awt.Font var25 = var24.getFont();
    java.awt.Color var29 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.95f);
    org.jfree.chart.text.TextBlock var30 = org.jfree.chart.text.TextUtilities.createTextBlock("CategoryLabelEntity: category=null, tooltip=hi!, url=", var25, (java.awt.Paint)var29);
    java.awt.Color var31 = java.awt.Color.getColor("CategoryLabelEntity: category=null, tooltip=hi!, url=", var29);
    var19.setDomainGridlinePaint((java.awt.Paint)var29);
    org.jfree.chart.axis.CategoryAnchor var33 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var19.setDomainGridlinePosition(var33);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test398() {}
//   public void test398() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }
// 
// 
//     org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("");
//     java.awt.Graphics2D var2 = null;
//     java.awt.Graphics2D var6 = null;
//     org.jfree.chart.axis.CategoryLabelPositions var9 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var10 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var11 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var9, var10);
//     org.jfree.chart.text.TextAnchor var12 = var10.getRotationAnchor();
//     org.jfree.chart.labels.ItemLabelPosition var14 = new org.jfree.chart.labels.ItemLabelPosition();
//     org.jfree.chart.LegendItemSource var15 = null;
//     org.jfree.chart.title.LegendTitle var16 = new org.jfree.chart.title.LegendTitle(var15);
//     org.jfree.chart.util.RectangleEdge var17 = var16.getLegendItemGraphicEdge();
//     org.jfree.chart.util.RectangleEdge var18 = org.jfree.chart.util.RectangleEdge.opposite(var17);
//     boolean var19 = var14.equals((java.lang.Object)var18);
//     org.jfree.chart.labels.ItemLabelAnchor var20 = var14.getItemLabelAnchor();
//     org.jfree.chart.axis.CategoryLabelPositions var21 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var22 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var23 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var21, var22);
//     org.jfree.chart.text.TextAnchor var24 = var22.getRotationAnchor();
//     org.jfree.chart.labels.ItemLabelPosition var25 = new org.jfree.chart.labels.ItemLabelPosition(var20, var24);
//     org.jfree.chart.text.TextUtilities.drawRotatedString("", var6, 100.0f, 0.0f, var12, 100.0d, var24);
//     var1.draw(var2, 0.0f, 0.95f, var12, 0.5f, 10.0f, 0.05d);
// 
//   }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }


    org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnit var2 = var0.getCeilingTickUnit((-8.0d));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test400() {}
//   public void test400() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var4 = null;
//     var3.setPlot(var4);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var3, var6);
//     org.jfree.chart.LegendItemSource var8 = null;
//     org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
//     org.jfree.chart.util.RectangleEdge var10 = var9.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var12 = var11.getNextOutlinePaint();
//     var9.setBackgroundPaint(var12);
//     var7.setOutlinePaint(var12);
//     org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var7);
//     var15.fireChartChanged();
//     org.jfree.chart.plot.CategoryPlot var17 = var15.getCategoryPlot();
//     org.jfree.chart.title.TextTitle var18 = null;
//     var15.setTitle(var18);
//     java.awt.Graphics2D var20 = null;
//     org.jfree.chart.LegendItemSource var21 = null;
//     org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle(var21);
//     org.jfree.chart.util.RectangleInsets var23 = var22.getItemLabelPadding();
//     org.jfree.chart.LegendItemSource var24 = null;
//     org.jfree.chart.title.LegendTitle var25 = new org.jfree.chart.title.LegendTitle(var24);
//     org.jfree.chart.util.RectangleInsets var26 = var25.getItemLabelPadding();
//     double var27 = var26.getTop();
//     var22.setPadding(var26);
//     org.jfree.chart.util.Size2D var29 = new org.jfree.chart.util.Size2D();
//     boolean var31 = var29.equals((java.lang.Object)(-1L));
//     double var32 = var29.getWidth();
//     double var33 = var29.getHeight();
//     org.jfree.chart.util.RectangleAnchor var36 = null;
//     java.awt.geom.Rectangle2D var37 = org.jfree.chart.util.RectangleAnchor.createRectangle(var29, 2.0d, (-1.0d), var36);
//     org.jfree.chart.axis.CategoryLabelPositions var40 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var41 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var42 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var40, var41);
//     org.jfree.chart.util.RectangleAnchor var43 = var41.getCategoryAnchor();
//     java.awt.geom.Rectangle2D var44 = org.jfree.chart.util.RectangleAnchor.createRectangle(var29, 2.0d, 1.0d, var43);
//     java.awt.geom.Rectangle2D var45 = var26.createOutsetRectangle(var44);
//     org.jfree.chart.ChartRenderingInfo var46 = null;
//     var15.draw(var20, var44, var46);
// 
//   }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }


    org.jfree.chart.util.BooleanList var0 = new org.jfree.chart.util.BooleanList();
    org.jfree.chart.util.StandardGradientPaintTransformer var1 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    java.lang.Object var2 = var1.clone();
    org.jfree.chart.event.ChartChangeEvent var3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1);
    org.jfree.chart.event.ChartChangeEventType var4 = var3.getType();
    boolean var5 = var0.equals((java.lang.Object)var4);
    boolean var7 = var0.equals((java.lang.Object)"SortOrder.ASCENDING");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }


    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var7 = new org.jfree.chart.entity.ChartEntity(var5, "Range[-1.0,-1.0]");
    org.jfree.chart.renderer.category.StatisticalBarRenderer var8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var10 = null;
    var8.setSeriesItemLabelsVisible(0, var10, false);
    java.awt.Stroke var13 = var8.getErrorIndicatorStroke();
    java.awt.Paint var14 = null;
    org.jfree.chart.LegendItem var15 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var5, var13, var14);
    boolean var16 = var15.isLineVisible();
    boolean var17 = var15.isShapeOutlineVisible();
    org.jfree.data.general.Dataset var18 = var15.getDataset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);

  }

  public void test403() {}
//   public void test403() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }
// 
// 
//     org.jfree.chart.labels.ItemLabelPosition var0 = new org.jfree.chart.labels.ItemLabelPosition();
//     org.jfree.chart.LegendItemSource var1 = null;
//     org.jfree.chart.title.LegendTitle var2 = new org.jfree.chart.title.LegendTitle(var1);
//     org.jfree.chart.util.RectangleEdge var3 = var2.getLegendItemGraphicEdge();
//     org.jfree.chart.util.RectangleEdge var4 = org.jfree.chart.util.RectangleEdge.opposite(var3);
//     boolean var5 = var0.equals((java.lang.Object)var4);
//     org.jfree.chart.labels.ItemLabelAnchor var6 = var0.getItemLabelAnchor();
//     org.jfree.chart.axis.CategoryLabelPositions var7 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var8 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var9 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var7, var8);
//     org.jfree.chart.text.TextAnchor var10 = var8.getRotationAnchor();
//     org.jfree.chart.labels.ItemLabelPosition var11 = new org.jfree.chart.labels.ItemLabelPosition(var6, var10);
//     org.jfree.chart.text.TextBlock var13 = new org.jfree.chart.text.TextBlock();
//     java.util.List var14 = var13.getLines();
//     org.jfree.chart.text.TextLine var15 = null;
//     var13.addLine(var15);
//     org.jfree.chart.util.HorizontalAlignment var17 = var13.getLineAlignment();
//     org.jfree.chart.axis.CategoryLabelPositions var18 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var19 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var20 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var18, var19);
//     float var21 = var19.getWidthRatio();
//     org.jfree.chart.text.TextBlockAnchor var22 = var19.getLabelAnchor();
//     java.awt.Graphics2D var24 = null;
//     org.jfree.chart.axis.CategoryLabelPositions var27 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var28 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var29 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var27, var28);
//     org.jfree.chart.text.TextAnchor var30 = var28.getRotationAnchor();
//     org.jfree.chart.labels.ItemLabelPosition var32 = new org.jfree.chart.labels.ItemLabelPosition();
//     org.jfree.chart.LegendItemSource var33 = null;
//     org.jfree.chart.title.LegendTitle var34 = new org.jfree.chart.title.LegendTitle(var33);
//     org.jfree.chart.util.RectangleEdge var35 = var34.getLegendItemGraphicEdge();
//     org.jfree.chart.util.RectangleEdge var36 = org.jfree.chart.util.RectangleEdge.opposite(var35);
//     boolean var37 = var32.equals((java.lang.Object)var36);
//     org.jfree.chart.labels.ItemLabelAnchor var38 = var32.getItemLabelAnchor();
//     org.jfree.chart.axis.CategoryLabelPositions var39 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var40 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var41 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var39, var40);
//     org.jfree.chart.text.TextAnchor var42 = var40.getRotationAnchor();
//     org.jfree.chart.labels.ItemLabelPosition var43 = new org.jfree.chart.labels.ItemLabelPosition(var38, var42);
//     org.jfree.chart.text.TextUtilities.drawRotatedString("", var24, 100.0f, 0.0f, var30, 100.0d, var42);
//     org.jfree.chart.axis.CategoryTick var46 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)(-1.0f), var13, var22, var42, 10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var47 = new org.jfree.chart.labels.ItemLabelPosition(var6, var42);
//     
//     // Checks the contract:  equals-hashcode on var0 and var32
//     assertTrue("Contract failed: equals-hashcode on var0 and var32", var0.equals(var32) ? var0.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var43
//     assertTrue("Contract failed: equals-hashcode on var11 and var43", var11.equals(var43) ? var11.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var47
//     assertTrue("Contract failed: equals-hashcode on var11 and var47", var11.equals(var47) ? var11.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var0
//     assertTrue("Contract failed: equals-hashcode on var32 and var0", var32.equals(var0) ? var32.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var11
//     assertTrue("Contract failed: equals-hashcode on var43 and var11", var43.equals(var11) ? var43.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var47
//     assertTrue("Contract failed: equals-hashcode on var43 and var47", var43.equals(var47) ? var43.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var11
//     assertTrue("Contract failed: equals-hashcode on var47 and var11", var47.equals(var11) ? var47.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var43
//     assertTrue("Contract failed: equals-hashcode on var47 and var43", var47.equals(var43) ? var47.hashCode() == var43.hashCode() : true);
// 
//   }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }


    org.jfree.chart.axis.CategoryLabelPositions var0 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var1 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var2 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var0, var1);
    org.jfree.chart.axis.CategoryLabelPositions var3 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var4 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var5 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var3, var4);
    org.jfree.chart.axis.CategoryLabelPositions var6 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var7 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var8 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var6, var7);
    org.jfree.chart.axis.CategoryLabelPositions var9 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var10 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var11 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var9, var10);
    org.jfree.chart.axis.CategoryLabelPositions var12 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(var6, var10);
    org.jfree.chart.axis.CategoryLabelPositions var13 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(var5, var10);
    org.jfree.chart.axis.CategoryLabelWidthType var14 = var10.getWidthType();
    org.jfree.chart.block.LabelBlock var16 = new org.jfree.chart.block.LabelBlock("");
    java.awt.Font var17 = var16.getFont();
    boolean var18 = var10.equals((java.lang.Object)var17);
    org.jfree.chart.axis.CategoryLabelPositions var19 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(var2, var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test405() {}
//   public void test405() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("Range[-1.0,-1.0]");
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var5 = var4.getPositiveItemLabelPositionFallback();
//     java.awt.Paint var8 = var4.getItemLabelPaint((-123), (-1));
//     org.jfree.data.category.CategoryDataset var9 = null;
//     org.jfree.chart.axis.CategoryAxis var10 = null;
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var12 = null;
//     var11.setPlot(var12);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var9, var10, (org.jfree.chart.axis.ValueAxis)var11, var14);
//     java.awt.Stroke var16 = var11.getTickMarkStroke();
//     org.jfree.chart.LegendItemSource var17 = null;
//     org.jfree.chart.title.LegendTitle var18 = new org.jfree.chart.title.LegendTitle(var17);
//     org.jfree.chart.util.RectangleInsets var19 = var18.getItemLabelPadding();
//     double var20 = var19.getTop();
//     org.jfree.chart.block.LineBorder var21 = new org.jfree.chart.block.LineBorder(var8, var16, var19);
//     java.awt.Stroke var22 = var21.getStroke();
//     java.awt.Stroke var23 = var21.getStroke();
//     java.awt.Graphics2D var24 = null;
//     org.jfree.chart.LegendItemSource var25 = null;
//     org.jfree.chart.title.LegendTitle var26 = new org.jfree.chart.title.LegendTitle(var25);
//     org.jfree.chart.util.RectangleInsets var27 = var26.getItemLabelPadding();
//     org.jfree.chart.LegendItemSource var28 = null;
//     org.jfree.chart.title.LegendTitle var29 = new org.jfree.chart.title.LegendTitle(var28);
//     org.jfree.chart.util.RectangleInsets var30 = var29.getItemLabelPadding();
//     double var31 = var30.getTop();
//     var26.setPadding(var30);
//     org.jfree.chart.util.Size2D var33 = new org.jfree.chart.util.Size2D();
//     boolean var35 = var33.equals((java.lang.Object)(-1L));
//     double var36 = var33.getWidth();
//     double var37 = var33.getHeight();
//     org.jfree.chart.util.RectangleAnchor var40 = null;
//     java.awt.geom.Rectangle2D var41 = org.jfree.chart.util.RectangleAnchor.createRectangle(var33, 2.0d, (-1.0d), var40);
//     org.jfree.chart.axis.CategoryLabelPositions var44 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var45 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var46 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var44, var45);
//     org.jfree.chart.util.RectangleAnchor var47 = var45.getCategoryAnchor();
//     java.awt.geom.Rectangle2D var48 = org.jfree.chart.util.RectangleAnchor.createRectangle(var33, 2.0d, 1.0d, var47);
//     java.awt.geom.Rectangle2D var49 = var30.createOutsetRectangle(var48);
//     var21.draw(var24, var48);
//     org.jfree.chart.LegendItemSource var51 = null;
//     org.jfree.chart.title.LegendTitle var52 = new org.jfree.chart.title.LegendTitle(var51);
//     org.jfree.chart.util.RectangleEdge var53 = var52.getLegendItemGraphicEdge();
//     java.awt.Paint var54 = var52.getItemPaint();
//     var52.setNotify(true);
//     java.awt.geom.Rectangle2D var57 = var52.getBounds();
//     org.jfree.chart.axis.AxisSpace var58 = new org.jfree.chart.axis.AxisSpace();
//     org.jfree.data.category.CategoryDataset var60 = null;
//     org.jfree.chart.axis.CategoryAxis var61 = null;
//     org.jfree.chart.axis.NumberAxis var62 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var63 = null;
//     var62.setPlot(var63);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var65 = null;
//     org.jfree.chart.plot.CategoryPlot var66 = new org.jfree.chart.plot.CategoryPlot(var60, var61, (org.jfree.chart.axis.ValueAxis)var62, var65);
//     var66.setAnchorValue(0.0d, true);
//     org.jfree.chart.axis.CategoryAxis var70 = var66.getDomainAxis();
//     org.jfree.chart.util.RectangleEdge var71 = var66.getRangeAxisEdge();
//     var58.ensureAtLeast(1.0E-8d, var71);
//     org.jfree.data.category.CategoryDataset var73 = null;
//     org.jfree.chart.axis.CategoryAxis var74 = null;
//     org.jfree.chart.axis.NumberAxis var75 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var76 = null;
//     var75.setPlot(var76);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var78 = null;
//     org.jfree.chart.plot.CategoryPlot var79 = new org.jfree.chart.plot.CategoryPlot(var73, var74, (org.jfree.chart.axis.ValueAxis)var75, var78);
//     org.jfree.chart.LegendItemSource var80 = null;
//     org.jfree.chart.title.LegendTitle var81 = new org.jfree.chart.title.LegendTitle(var80);
//     org.jfree.chart.util.RectangleEdge var82 = var81.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var83 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var84 = var83.getNextOutlinePaint();
//     var81.setBackgroundPaint(var84);
//     var79.setOutlinePaint(var84);
//     org.jfree.chart.ChartRenderingInfo var89 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var90 = new org.jfree.chart.plot.PlotRenderingInfo(var89);
//     java.lang.Object var91 = var90.clone();
//     var79.handleClick(4, (-123), var90);
//     int var93 = var90.getSubplotCount();
//     org.jfree.chart.axis.AxisState var94 = var1.draw(var2, 10.0d, var48, var57, var71, var90);
// 
//   }

  public void test406() {}
//   public void test406() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var2 = var0.getSeriesItemLabelsVisible(100);
//     org.jfree.chart.labels.ItemLabelPosition var5 = var0.getPositiveItemLabelPosition(100, 0);
//     org.jfree.chart.urls.CategoryURLGenerator var6 = var0.getBaseURLGenerator();
//     java.lang.Boolean var8 = var0.getSeriesItemLabelsVisible((-855310));
//     org.jfree.data.category.CategoryDataset var9 = null;
//     org.jfree.chart.axis.CategoryAxis var10 = null;
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var12 = null;
//     var11.setPlot(var12);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var9, var10, (org.jfree.chart.axis.ValueAxis)var11, var14);
//     java.awt.Stroke var16 = var11.getTickMarkStroke();
//     var0.setBaseOutlineStroke(var16);
//     org.jfree.chart.labels.ItemLabelPosition var18 = var0.getBaseNegativeItemLabelPosition();
//     java.awt.Color var24 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.0f);
//     java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
//     org.jfree.chart.entity.ChartEntity var32 = new org.jfree.chart.entity.ChartEntity(var30, "Range[-1.0,-1.0]");
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var33 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var35 = null;
//     var33.setSeriesItemLabelsVisible(0, var35, false);
//     java.awt.Stroke var38 = var33.getErrorIndicatorStroke();
//     java.awt.Paint var39 = null;
//     org.jfree.chart.LegendItem var40 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var30, var38, var39);
//     org.jfree.chart.plot.ValueMarker var41 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint)var24, var38);
//     java.awt.color.ColorSpace var42 = var24.getColorSpace();
//     var0.setSeriesFillPaint(242, (java.awt.Paint)var24);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var33 and var0.", var33.equals(var0) == var0.equals(var33));
// 
//   }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }


    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var7 = new org.jfree.chart.entity.ChartEntity(var5, "Range[-1.0,-1.0]");
    org.jfree.chart.renderer.category.StatisticalBarRenderer var8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var10 = null;
    var8.setSeriesItemLabelsVisible(0, var10, false);
    java.awt.Stroke var13 = var8.getErrorIndicatorStroke();
    java.awt.Paint var14 = null;
    org.jfree.chart.LegendItem var15 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var5, var13, var14);
    java.awt.Shape var16 = var15.getShape();
    org.jfree.data.general.Dataset var17 = null;
    var15.setDataset(var17);
    int var19 = var15.getDatasetIndex();
    org.jfree.data.general.Dataset var20 = var15.getDataset();
    org.jfree.chart.util.GradientPaintTransformer var21 = var15.getFillPaintTransformer();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test408() {}
//   public void test408() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }
// 
// 
//     org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("Range[-1.0,-1.0]");
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.util.Size2D var3 = var1.arrange(var2);
// 
//   }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    var0.removeColumn((java.lang.Comparable)'a');
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var5 = var0.getObject((-855310), (-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var1 = var0.getBasePositiveItemLabelPosition();
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var9 = new org.jfree.chart.entity.ChartEntity(var7, "Range[-1.0,-1.0]");
    org.jfree.chart.renderer.category.StatisticalBarRenderer var10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var12 = null;
    var10.setSeriesItemLabelsVisible(0, var12, false);
    java.awt.Stroke var15 = var10.getErrorIndicatorStroke();
    java.awt.Paint var16 = null;
    org.jfree.chart.LegendItem var17 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var7, var15, var16);
    boolean var18 = var17.isLineVisible();
    var17.setSeriesKey((java.lang.Comparable)0L);
    boolean var21 = var17.isShapeVisible();
    org.jfree.chart.util.GradientPaintTransformer var22 = var17.getFillPaintTransformer();
    var0.setGradientPaintTransformer(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("");
    boolean var3 = var1.equals((java.lang.Object)' ');
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
    boolean var5 = var4.isNegativeArrowVisible();
    java.lang.String var6 = var4.getLabelURL();
    var4.setLabelAngle(6.0d);
    var4.setAutoRange(false);
    java.awt.Font var11 = var4.getTickLabelFont();
    var1.setFont(var11);
    java.lang.String var13 = var1.getURLText();
    java.lang.Object var14 = var1.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test412() {}
//   public void test412() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var2 = var0.getSeriesItemLabelsVisible(100);
//     org.jfree.chart.labels.ItemLabelPosition var5 = var0.getPositiveItemLabelPosition(100, 0);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var6 = var0.getLegendItemToolTipGenerator();
//     java.awt.Paint var9 = var0.getItemPaint(1, (-123));
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var12 = var10.getSeriesItemLabelsVisible(100);
//     org.jfree.chart.labels.ItemLabelPosition var15 = var10.getPositiveItemLabelPosition(100, 0);
//     org.jfree.chart.urls.CategoryURLGenerator var16 = var10.getBaseURLGenerator();
//     java.lang.Boolean var18 = var10.getSeriesItemLabelsVisible((-855310));
//     java.awt.Color var21 = java.awt.Color.getColor("", (-1));
//     var10.setBasePaint((java.awt.Paint)var21, true);
//     var0.setBasePaint((java.awt.Paint)var21, false);
//     
//     // Checks the contract:  equals-hashcode on var5 and var15
//     assertTrue("Contract failed: equals-hashcode on var5 and var15", var5.equals(var15) ? var5.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var5
//     assertTrue("Contract failed: equals-hashcode on var15 and var5", var15.equals(var5) ? var15.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.util.RectangleInsets var2 = var1.getItemLabelPadding();
    org.jfree.chart.util.VerticalAlignment var3 = var1.getVerticalAlignment();
    org.jfree.chart.block.BlockContainer var4 = var1.getItemContainer();
    org.jfree.chart.block.BlockFrame var5 = var4.getFrame();
    org.jfree.data.general.DatasetGroup var6 = new org.jfree.data.general.DatasetGroup();
    org.jfree.chart.LegendItemSource var7 = null;
    org.jfree.chart.title.LegendTitle var8 = new org.jfree.chart.title.LegendTitle(var7);
    org.jfree.chart.util.RectangleEdge var9 = var8.getLegendItemGraphicEdge();
    boolean var10 = var6.equals((java.lang.Object)var8);
    org.jfree.chart.labels.ItemLabelPosition var11 = new org.jfree.chart.labels.ItemLabelPosition();
    org.jfree.chart.LegendItemSource var12 = null;
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle(var12);
    org.jfree.chart.util.RectangleEdge var14 = var13.getLegendItemGraphicEdge();
    org.jfree.chart.util.RectangleEdge var15 = org.jfree.chart.util.RectangleEdge.opposite(var14);
    boolean var16 = var11.equals((java.lang.Object)var15);
    var8.setLegendItemGraphicEdge(var15);
    var4.add((org.jfree.chart.block.Block)var8);
    org.jfree.chart.LegendItemSource var19 = null;
    org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle(var19);
    org.jfree.chart.util.RectangleEdge var21 = var20.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var22 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var23 = var22.getNextOutlinePaint();
    var20.setBackgroundPaint(var23);
    org.jfree.chart.text.TextBlock var25 = new org.jfree.chart.text.TextBlock();
    java.util.List var26 = var25.getLines();
    boolean var27 = var20.equals((java.lang.Object)var25);
    org.jfree.chart.util.RectangleEdge var28 = var20.getLegendItemGraphicEdge();
    org.jfree.chart.util.RectangleAnchor var29 = var20.getLegendItemGraphicLocation();
    java.lang.Object var30 = var20.clone();
    org.jfree.chart.util.HorizontalAlignment var31 = var20.getHorizontalAlignment();
    boolean var32 = var8.equals((java.lang.Object)var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    double var5 = var2.getLowerMargin();
    java.awt.Shape var6 = var2.getDownArrow();
    var0.setShape(0, var6);
    boolean var9 = var0.equals((java.lang.Object)(short)1);
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var11 = null;
    var10.setPlot(var11);
    var10.setLowerBound(2.0d);
    java.lang.String var15 = var10.getLabelToolTip();
    java.awt.Shape var16 = var10.getRightArrow();
    boolean var17 = var0.equals((java.lang.Object)var10);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var19 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var20 = var19.getPositiveItemLabelPositionFallback();
    java.awt.Paint var23 = var19.getItemLabelPaint((-123), (-1));
    org.jfree.data.category.CategoryDataset var24 = null;
    org.jfree.chart.axis.CategoryAxis var25 = null;
    org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var27 = null;
    var26.setPlot(var27);
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var24, var25, (org.jfree.chart.axis.ValueAxis)var26, var29);
    java.awt.Stroke var31 = var26.getTickMarkStroke();
    org.jfree.chart.LegendItemSource var32 = null;
    org.jfree.chart.title.LegendTitle var33 = new org.jfree.chart.title.LegendTitle(var32);
    org.jfree.chart.util.RectangleInsets var34 = var33.getItemLabelPadding();
    double var35 = var34.getTop();
    org.jfree.chart.block.LineBorder var36 = new org.jfree.chart.block.LineBorder(var23, var31, var34);
    java.awt.Stroke var37 = var36.getStroke();
    java.awt.Stroke var38 = var36.getStroke();
    java.awt.Graphics2D var39 = null;
    org.jfree.chart.LegendItemSource var40 = null;
    org.jfree.chart.title.LegendTitle var41 = new org.jfree.chart.title.LegendTitle(var40);
    org.jfree.chart.util.RectangleInsets var42 = var41.getItemLabelPadding();
    org.jfree.chart.LegendItemSource var43 = null;
    org.jfree.chart.title.LegendTitle var44 = new org.jfree.chart.title.LegendTitle(var43);
    org.jfree.chart.util.RectangleInsets var45 = var44.getItemLabelPadding();
    double var46 = var45.getTop();
    var41.setPadding(var45);
    org.jfree.chart.util.Size2D var48 = new org.jfree.chart.util.Size2D();
    boolean var50 = var48.equals((java.lang.Object)(-1L));
    double var51 = var48.getWidth();
    double var52 = var48.getHeight();
    org.jfree.chart.util.RectangleAnchor var55 = null;
    java.awt.geom.Rectangle2D var56 = org.jfree.chart.util.RectangleAnchor.createRectangle(var48, 2.0d, (-1.0d), var55);
    org.jfree.chart.axis.CategoryLabelPositions var59 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var60 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var61 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var59, var60);
    org.jfree.chart.util.RectangleAnchor var62 = var60.getCategoryAnchor();
    java.awt.geom.Rectangle2D var63 = org.jfree.chart.util.RectangleAnchor.createRectangle(var48, 2.0d, 1.0d, var62);
    java.awt.geom.Rectangle2D var64 = var45.createOutsetRectangle(var63);
    var36.draw(var39, var63);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setShape((-855310), (java.awt.Shape)var63);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);

  }

  public void test415() {}
//   public void test415() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.FontMetrics var2 = null;
//     java.awt.geom.Rectangle2D var3 = org.jfree.chart.text.TextUtilities.getTextBounds("0,100,100,-100,-100,-100,-100,-100", var1, var2);
// 
//   }

  public void test416() {}
//   public void test416() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", var1);
// 
//   }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }


    org.jfree.chart.block.BlockBorder var4 = new org.jfree.chart.block.BlockBorder(0.05d, 1.0E-8d, 4.0d, 0.0d);

  }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }


    boolean var0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == false);

  }

  public void test419() {}
//   public void test419() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }
// 
// 
//     org.jfree.chart.util.StrokeList var0 = new org.jfree.chart.util.StrokeList();
//     int var1 = var0.size();
//     java.lang.Object var2 = var0.clone();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var5 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var7 = null;
//     var5.setSeriesItemLabelsVisible(0, var7, false);
//     java.awt.Stroke var10 = var5.getErrorIndicatorStroke();
//     org.jfree.chart.plot.DrawingSupplier var11 = var5.getDrawingSupplier();
//     java.lang.Boolean var13 = var5.getSeriesCreateEntities(10);
//     java.awt.Paint var14 = var5.getBaseOutlinePaint();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var16 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var18 = var16.getSeriesItemLabelsVisible(100);
//     org.jfree.chart.labels.ItemLabelPosition var21 = var16.getPositiveItemLabelPosition(100, 0);
//     org.jfree.chart.urls.CategoryURLGenerator var22 = var16.getBaseURLGenerator();
//     java.lang.Boolean var24 = var16.getSeriesItemLabelsVisible((-855310));
//     java.awt.Color var27 = java.awt.Color.getColor("", (-1));
//     var16.setBasePaint((java.awt.Paint)var27, true);
//     var5.setSeriesPaint(0, (java.awt.Paint)var27, false);
//     int var32 = var27.getRGB();
//     org.jfree.chart.LegendItemSource var33 = null;
//     org.jfree.chart.title.LegendTitle var34 = new org.jfree.chart.title.LegendTitle(var33);
//     org.jfree.chart.util.RectangleEdge var35 = var34.getLegendItemGraphicEdge();
//     java.awt.Paint var36 = var34.getItemPaint();
//     org.jfree.data.category.CategoryDataset var38 = null;
//     org.jfree.chart.axis.CategoryAxis var39 = null;
//     org.jfree.chart.axis.NumberAxis var40 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var41 = null;
//     var40.setPlot(var41);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var43 = null;
//     org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot(var38, var39, (org.jfree.chart.axis.ValueAxis)var40, var43);
//     org.jfree.chart.LegendItemSource var45 = null;
//     org.jfree.chart.title.LegendTitle var46 = new org.jfree.chart.title.LegendTitle(var45);
//     org.jfree.chart.util.RectangleEdge var47 = var46.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var48 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var49 = var48.getNextOutlinePaint();
//     var46.setBackgroundPaint(var49);
//     var44.setOutlinePaint(var49);
//     org.jfree.chart.JFreeChart var52 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var44);
//     var52.fireChartChanged();
//     boolean var54 = var52.getAntiAlias();
//     java.util.List var55 = var52.getSubtitles();
//     var34.addChangeListener((org.jfree.chart.event.TitleChangeListener)var52);
//     org.jfree.data.category.CategoryDataset var57 = null;
//     org.jfree.chart.axis.CategoryAxis var58 = null;
//     org.jfree.chart.axis.NumberAxis var59 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var60 = null;
//     var59.setPlot(var60);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var62 = null;
//     org.jfree.chart.plot.CategoryPlot var63 = new org.jfree.chart.plot.CategoryPlot(var57, var58, (org.jfree.chart.axis.ValueAxis)var59, var62);
//     var59.setAutoRangeMinimumSize(2.0d);
//     java.awt.geom.Rectangle2D var67 = null;
//     org.jfree.chart.util.RectangleEdge var68 = null;
//     double var69 = var59.java2DToValue(0.0d, var67, var68);
//     var59.setAutoTickUnitSelection(true);
//     java.awt.Stroke var72 = var59.getAxisLineStroke();
//     var52.setBorderStroke(var72);
//     org.jfree.chart.plot.ValueMarker var74 = new org.jfree.chart.plot.ValueMarker(Double.NaN, (java.awt.Paint)var27, var72);
//     java.awt.Paint var75 = var74.getPaint();
//     java.awt.Paint var76 = var74.getPaint();
//     java.awt.Stroke var77 = var74.getStroke();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setStroke((-1), var77);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var69 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var72);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var75);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
// 
//   }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }


    org.jfree.chart.axis.CategoryLabelPositions var0 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var1 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var2 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var0, var1);
    org.jfree.chart.axis.CategoryLabelPositions var3 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var4 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var5 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var3, var4);
    org.jfree.chart.axis.CategoryLabelPositions var6 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(var0, var4);
    boolean var8 = var6.equals((java.lang.Object)(-8.0d));
    org.jfree.chart.axis.CategoryLabelPosition var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var10 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(var6, var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test421() {}
//   public void test421() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }
// 
// 
//     org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("");
//     java.lang.String var2 = var1.getText();
//     java.awt.Graphics2D var3 = null;
//     java.awt.Graphics2D var7 = null;
//     org.jfree.chart.labels.ItemLabelPosition var10 = new org.jfree.chart.labels.ItemLabelPosition();
//     org.jfree.chart.LegendItemSource var11 = null;
//     org.jfree.chart.title.LegendTitle var12 = new org.jfree.chart.title.LegendTitle(var11);
//     org.jfree.chart.util.RectangleEdge var13 = var12.getLegendItemGraphicEdge();
//     org.jfree.chart.util.RectangleEdge var14 = org.jfree.chart.util.RectangleEdge.opposite(var13);
//     boolean var15 = var10.equals((java.lang.Object)var14);
//     org.jfree.chart.labels.ItemLabelAnchor var16 = var10.getItemLabelAnchor();
//     org.jfree.chart.axis.CategoryLabelPositions var17 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var18 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var19 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var17, var18);
//     org.jfree.chart.text.TextAnchor var20 = var18.getRotationAnchor();
//     org.jfree.chart.labels.ItemLabelPosition var21 = new org.jfree.chart.labels.ItemLabelPosition(var16, var20);
//     org.jfree.chart.text.TextUtilities.drawRotatedString("", var7, 1.0f, (-1.0f), var20, 2.0d, 1.0f, 0.0f);
//     var1.draw(var3, 100.0f, 100.0f, var20, 2.0f, 100.0f, 1.0d);
// 
//   }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }


    org.jfree.chart.ui.ProjectInfo var0 = new org.jfree.chart.ui.ProjectInfo();
    var0.setInfo("");
    java.awt.Image var3 = null;
    var0.setLogo(var3);
    java.lang.String var5 = var0.getLicenceName();
    java.lang.String var6 = var0.getLicenceText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }


    java.awt.Color var2 = java.awt.Color.getColor("", (-1));
    java.lang.String var3 = var2.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "java.awt.Color[r=255,g=255,b=255]"+ "'", var3.equals("java.awt.Color[r=255,g=255,b=255]"));

  }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    boolean var1 = var0.isNegativeArrowVisible();
    java.lang.String var2 = var0.getLabelURL();
    var0.setLabelAngle(6.0d);
    var0.setAutoRange(false);
    java.lang.Object var7 = var0.clone();
    double var8 = var0.getLowerMargin();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeWithMargins(10.0d, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.05d);

  }

  public void test425() {}
//   public void test425() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var2 = null;
//     var0.setSeriesItemLabelsVisible(0, var2, false);
//     java.awt.Stroke var5 = var0.getErrorIndicatorStroke();
//     org.jfree.chart.plot.DrawingSupplier var6 = var0.getDrawingSupplier();
//     java.lang.Boolean var8 = var0.getSeriesCreateEntities(10);
//     java.awt.Paint var9 = var0.getBaseOutlinePaint();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var13 = var11.getSeriesItemLabelsVisible(100);
//     org.jfree.chart.labels.ItemLabelPosition var16 = var11.getPositiveItemLabelPosition(100, 0);
//     org.jfree.chart.urls.CategoryURLGenerator var17 = var11.getBaseURLGenerator();
//     java.lang.Boolean var19 = var11.getSeriesItemLabelsVisible((-855310));
//     java.awt.Color var22 = java.awt.Color.getColor("", (-1));
//     var11.setBasePaint((java.awt.Paint)var22, true);
//     var0.setSeriesPaint(0, (java.awt.Paint)var22, false);
//     int var27 = var22.getRGB();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var28 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var30 = var28.getSeriesItemLabelsVisible(100);
//     org.jfree.chart.labels.ItemLabelPosition var33 = var28.getPositiveItemLabelPosition(100, 0);
//     org.jfree.chart.urls.CategoryURLGenerator var34 = var28.getBaseURLGenerator();
//     java.lang.Boolean var36 = var28.getSeriesItemLabelsVisible((-855310));
//     java.awt.Color var39 = java.awt.Color.getColor("", (-1));
//     var28.setBasePaint((java.awt.Paint)var39, true);
//     java.awt.Color var47 = java.awt.Color.getColor("", (-1));
//     float[] var48 = null;
//     float[] var49 = var47.getRGBComponents(var48);
//     float[] var50 = java.awt.Color.RGBtoHSB(0, (-123), 100, var49);
//     float[] var51 = var39.getRGBComponents(var49);
//     float[] var52 = var22.getComponents(var51);
//     
//     // Checks the contract:  equals-hashcode on var16 and var33
//     assertTrue("Contract failed: equals-hashcode on var16 and var33", var16.equals(var33) ? var16.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var16
//     assertTrue("Contract failed: equals-hashcode on var33 and var16", var33.equals(var16) ? var33.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }


    org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(false);

  }

  public void test427() {}
//   public void test427() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }
// 
// 
//     org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("");
//     org.jfree.chart.util.Size2D var2 = new org.jfree.chart.util.Size2D();
//     boolean var4 = var2.equals((java.lang.Object)(-1L));
//     java.lang.Object var5 = var2.clone();
//     boolean var6 = var1.equals(var5);
//     java.awt.Graphics2D var7 = null;
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.axis.CategoryLabelPositions var12 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var13 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var14 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var12, var13);
//     org.jfree.chart.text.TextAnchor var15 = var13.getRotationAnchor();
//     org.jfree.chart.labels.ItemLabelPosition var17 = new org.jfree.chart.labels.ItemLabelPosition();
//     org.jfree.chart.LegendItemSource var18 = null;
//     org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle(var18);
//     org.jfree.chart.util.RectangleEdge var20 = var19.getLegendItemGraphicEdge();
//     org.jfree.chart.util.RectangleEdge var21 = org.jfree.chart.util.RectangleEdge.opposite(var20);
//     boolean var22 = var17.equals((java.lang.Object)var21);
//     org.jfree.chart.labels.ItemLabelAnchor var23 = var17.getItemLabelAnchor();
//     org.jfree.chart.axis.CategoryLabelPositions var24 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var25 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var26 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var24, var25);
//     org.jfree.chart.text.TextAnchor var27 = var25.getRotationAnchor();
//     org.jfree.chart.labels.ItemLabelPosition var28 = new org.jfree.chart.labels.ItemLabelPosition(var23, var27);
//     org.jfree.chart.text.TextUtilities.drawRotatedString("", var9, 100.0f, 0.0f, var15, 100.0d, var27);
//     float var30 = var1.calculateBaselineOffset(var7, var27);
// 
//   }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTickUnit var3 = new org.jfree.chart.axis.NumberTickUnit((-1.0d), var1, 4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test430() {}
//   public void test430() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var4 = null;
//     var3.setPlot(var4);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var3, var6);
//     org.jfree.chart.LegendItemSource var8 = null;
//     org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
//     org.jfree.chart.util.RectangleEdge var10 = var9.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var12 = var11.getNextOutlinePaint();
//     var9.setBackgroundPaint(var12);
//     var7.setOutlinePaint(var12);
//     org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var7);
//     var15.fireChartChanged();
//     java.lang.Object var18 = null;
//     org.jfree.data.KeyedObject var19 = new org.jfree.data.KeyedObject((java.lang.Comparable)' ', var18);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var20 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var22 = null;
//     var20.setSeriesItemLabelsVisible(0, var22, false);
//     java.awt.Paint var25 = var20.getBaseOutlinePaint();
//     boolean var26 = var19.equals((java.lang.Object)var25);
//     var15.setBackgroundPaint(var25);
//     org.jfree.data.category.CategoryDataset var29 = null;
//     org.jfree.chart.axis.CategoryAxis var30 = null;
//     org.jfree.chart.axis.NumberAxis var31 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var32 = null;
//     var31.setPlot(var32);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var34 = null;
//     org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot(var29, var30, (org.jfree.chart.axis.ValueAxis)var31, var34);
//     org.jfree.chart.LegendItemSource var36 = null;
//     org.jfree.chart.title.LegendTitle var37 = new org.jfree.chart.title.LegendTitle(var36);
//     org.jfree.chart.util.RectangleEdge var38 = var37.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var39 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var40 = var39.getNextOutlinePaint();
//     var37.setBackgroundPaint(var40);
//     var35.setOutlinePaint(var40);
//     org.jfree.chart.JFreeChart var43 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var35);
//     var43.fireChartChanged();
//     org.jfree.chart.plot.CategoryPlot var45 = var43.getCategoryPlot();
//     java.awt.image.BufferedImage var48 = var43.createBufferedImage(1, 1);
//     var15.setBackgroundImage((java.awt.Image)var48);
//     
//     // Checks the contract:  equals-hashcode on var7 and var35
//     assertTrue("Contract failed: equals-hashcode on var7 and var35", var7.equals(var35) ? var7.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var45
//     assertTrue("Contract failed: equals-hashcode on var7 and var45", var7.equals(var45) ? var7.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var7
//     assertTrue("Contract failed: equals-hashcode on var35 and var7", var35.equals(var7) ? var35.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var7
//     assertTrue("Contract failed: equals-hashcode on var45 and var7", var45.equals(var7) ? var45.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var39
//     assertTrue("Contract failed: equals-hashcode on var11 and var39", var11.equals(var39) ? var11.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var11
//     assertTrue("Contract failed: equals-hashcode on var39 and var11", var39.equals(var11) ? var39.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    org.jfree.chart.LegendItemSource var7 = null;
    org.jfree.chart.title.LegendTitle var8 = new org.jfree.chart.title.LegendTitle(var7);
    org.jfree.chart.util.RectangleEdge var9 = var8.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var10 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var11 = var10.getNextOutlinePaint();
    var8.setBackgroundPaint(var11);
    var6.setOutlinePaint(var11);
    org.jfree.data.category.CategoryDataset var14 = null;
    org.jfree.chart.axis.CategoryAxis var15 = null;
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var17 = null;
    var16.setPlot(var17);
    org.jfree.chart.renderer.category.CategoryItemRenderer var19 = null;
    org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot(var14, var15, (org.jfree.chart.axis.ValueAxis)var16, var19);
    org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var22 = null;
    var21.setPlot(var22);
    org.jfree.chart.axis.ValueAxis[] var24 = new org.jfree.chart.axis.ValueAxis[] { var21};
    var20.setRangeAxes(var24);
    var6.setParent((org.jfree.chart.plot.Plot)var20);
    var6.setRangeGridlinesVisible(true);
    org.jfree.chart.plot.PlotOrientation var29 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setOrientation(var29);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }


    org.jfree.chart.ui.ProjectInfo var0 = new org.jfree.chart.ui.ProjectInfo();
    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    boolean var3 = var0.equals((java.lang.Object)var2);
    org.jfree.chart.ui.Library[] var4 = var0.getLibraries();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    var6.setAnchorValue(0.0d, true);
    org.jfree.chart.axis.CategoryAxis var10 = var6.getDomainAxis();
    java.awt.Graphics2D var11 = null;
    org.jfree.chart.LegendItemSource var12 = null;
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle(var12);
    org.jfree.chart.util.RectangleInsets var14 = var13.getItemLabelPadding();
    org.jfree.chart.LegendItemSource var15 = null;
    org.jfree.chart.title.LegendTitle var16 = new org.jfree.chart.title.LegendTitle(var15);
    org.jfree.chart.util.RectangleInsets var17 = var16.getItemLabelPadding();
    double var18 = var17.getTop();
    var13.setPadding(var17);
    org.jfree.chart.util.Size2D var20 = new org.jfree.chart.util.Size2D();
    boolean var22 = var20.equals((java.lang.Object)(-1L));
    double var23 = var20.getWidth();
    double var24 = var20.getHeight();
    org.jfree.chart.util.RectangleAnchor var27 = null;
    java.awt.geom.Rectangle2D var28 = org.jfree.chart.util.RectangleAnchor.createRectangle(var20, 2.0d, (-1.0d), var27);
    org.jfree.chart.axis.CategoryLabelPositions var31 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var32 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var33 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var31, var32);
    org.jfree.chart.util.RectangleAnchor var34 = var32.getCategoryAnchor();
    java.awt.geom.Rectangle2D var35 = org.jfree.chart.util.RectangleAnchor.createRectangle(var20, 2.0d, 1.0d, var34);
    java.awt.geom.Rectangle2D var36 = var17.createOutsetRectangle(var35);
    java.awt.geom.Point2D var37 = null;
    org.jfree.chart.plot.PlotState var38 = null;
    org.jfree.chart.plot.PlotRenderingInfo var39 = null;
    var6.draw(var11, var36, var37, var38, var39);
    org.jfree.chart.entity.TickLabelEntity var43 = new org.jfree.chart.entity.TickLabelEntity((java.awt.Shape)var36, "hi!", "CategoryLabelEntity: category=null, tooltip=hi!, url=");
    java.awt.Shape var49 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var51 = new org.jfree.chart.entity.ChartEntity(var49, "Range[-1.0,-1.0]");
    org.jfree.chart.renderer.category.StatisticalBarRenderer var52 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var54 = null;
    var52.setSeriesItemLabelsVisible(0, var54, false);
    java.awt.Stroke var57 = var52.getErrorIndicatorStroke();
    java.awt.Paint var58 = null;
    org.jfree.chart.LegendItem var59 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var49, var57, var58);
    boolean var60 = var59.isLineVisible();
    java.awt.Shape var61 = var59.getLine();
    var43.setArea(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);

  }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    java.awt.Stroke var7 = var2.getTickMarkStroke();
    var2.setVerticalTickLabels(false);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var17 = new org.jfree.chart.entity.ChartEntity(var15, "Range[-1.0,-1.0]");
    org.jfree.chart.renderer.category.StatisticalBarRenderer var18 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var20 = null;
    var18.setSeriesItemLabelsVisible(0, var20, false);
    java.awt.Stroke var23 = var18.getErrorIndicatorStroke();
    java.awt.Paint var24 = null;
    org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var15, var23, var24);
    var2.setDownArrow(var15);
    boolean var27 = var2.isTickLabelsVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);

  }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }


    org.jfree.chart.block.Arrangement var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.BlockContainer var1 = new org.jfree.chart.block.BlockContainer(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.util.EventListener var1 = null;
    boolean var2 = var0.hasListener(var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var5 = var0.getStdDevValue(0, 255);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test437() {}
//   public void test437() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }
// 
// 
//     java.util.ResourceBundle.Control var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("CategoryLabelEntity: category=null, tooltip=hi!, url=", var1);
// 
//   }

  public void test438() {}
//   public void test438() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }
// 
// 
//     org.jfree.chart.LegendItemSource var0 = null;
//     org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
//     org.jfree.chart.util.RectangleEdge var2 = var1.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var3 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var4 = var3.getNextOutlinePaint();
//     var1.setBackgroundPaint(var4);
//     org.jfree.chart.LegendItemSource var6 = null;
//     org.jfree.chart.title.LegendTitle var7 = new org.jfree.chart.title.LegendTitle(var6);
//     org.jfree.chart.util.RectangleInsets var8 = var7.getItemLabelPadding();
//     org.jfree.chart.util.VerticalAlignment var9 = var7.getVerticalAlignment();
//     org.jfree.chart.block.BlockContainer var10 = var7.getItemContainer();
//     var1.setWrapper(var10);
//     org.jfree.chart.util.RectangleInsets var12 = var1.getLegendItemGraphicPadding();
//     java.awt.Graphics2D var13 = null;
//     org.jfree.chart.block.RectangleConstraint var16 = new org.jfree.chart.block.RectangleConstraint(0.0d, 0.0d);
//     org.jfree.data.Range var17 = null;
//     org.jfree.data.Range var19 = org.jfree.data.Range.expandToInclude(var17, (-1.0d));
//     org.jfree.data.Range var20 = null;
//     org.jfree.data.Range var22 = org.jfree.data.Range.expandToInclude(var20, (-1.0d));
//     org.jfree.data.Range var23 = org.jfree.data.Range.combine(var19, var22);
//     double var24 = var22.getUpperBound();
//     org.jfree.chart.block.RectangleConstraint var25 = var16.toRangeHeight(var22);
//     org.jfree.chart.util.Size2D var26 = var1.arrange(var13, var16);
// 
//   }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    var6.setAnchorValue(0.0d, true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var12 = null;
    var10.setSeriesItemLabelsVisible(0, var12, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var16 = null;
    var10.setSeriesToolTipGenerator(1, var16, false);
    org.jfree.chart.urls.CategoryURLGenerator var19 = null;
    var10.setBaseURLGenerator(var19);
    java.awt.Graphics2D var21 = null;
    org.jfree.chart.plot.CategoryPlot var22 = null;
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.plot.Marker var24 = null;
    java.awt.geom.Rectangle2D var25 = null;
    var10.drawRangeMarker(var21, var22, var23, var24, var25);
    boolean var28 = var10.isSeriesVisibleInLegend(0);
    var6.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    org.jfree.chart.axis.CategoryAxis var30 = null;
    java.util.List var31 = var6.getCategoriesForAxis(var30);
    java.awt.Font var32 = var6.getNoDataMessageFont();
    org.jfree.data.category.CategoryDataset var33 = null;
    org.jfree.chart.axis.CategoryAxis var34 = null;
    org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var36 = null;
    var35.setPlot(var36);
    org.jfree.chart.renderer.category.CategoryItemRenderer var38 = null;
    org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot(var33, var34, (org.jfree.chart.axis.ValueAxis)var35, var38);
    org.jfree.chart.LegendItemSource var40 = null;
    org.jfree.chart.title.LegendTitle var41 = new org.jfree.chart.title.LegendTitle(var40);
    org.jfree.chart.util.RectangleEdge var42 = var41.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var43 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var44 = var43.getNextOutlinePaint();
    var41.setBackgroundPaint(var44);
    var39.setOutlinePaint(var44);
    var39.clearDomainMarkers();
    org.jfree.chart.util.SortOrder var48 = var39.getRowRenderingOrder();
    var6.setRowRenderingOrder(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);

  }

  public void test440() {}
//   public void test440() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var3 = null;
//     var2.setPlot(var3);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
//     var6.setAnchorValue(0.0d, true);
//     org.jfree.chart.axis.CategoryAxis var10 = var6.getDomainAxis();
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.LegendItemSource var12 = null;
//     org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle(var12);
//     org.jfree.chart.util.RectangleInsets var14 = var13.getItemLabelPadding();
//     org.jfree.chart.LegendItemSource var15 = null;
//     org.jfree.chart.title.LegendTitle var16 = new org.jfree.chart.title.LegendTitle(var15);
//     org.jfree.chart.util.RectangleInsets var17 = var16.getItemLabelPadding();
//     double var18 = var17.getTop();
//     var13.setPadding(var17);
//     org.jfree.chart.util.Size2D var20 = new org.jfree.chart.util.Size2D();
//     boolean var22 = var20.equals((java.lang.Object)(-1L));
//     double var23 = var20.getWidth();
//     double var24 = var20.getHeight();
//     org.jfree.chart.util.RectangleAnchor var27 = null;
//     java.awt.geom.Rectangle2D var28 = org.jfree.chart.util.RectangleAnchor.createRectangle(var20, 2.0d, (-1.0d), var27);
//     org.jfree.chart.axis.CategoryLabelPositions var31 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var32 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var33 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var31, var32);
//     org.jfree.chart.util.RectangleAnchor var34 = var32.getCategoryAnchor();
//     java.awt.geom.Rectangle2D var35 = org.jfree.chart.util.RectangleAnchor.createRectangle(var20, 2.0d, 1.0d, var34);
//     java.awt.geom.Rectangle2D var36 = var17.createOutsetRectangle(var35);
//     java.awt.geom.Point2D var37 = null;
//     org.jfree.chart.plot.PlotState var38 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var39 = null;
//     var6.draw(var11, var36, var37, var38, var39);
//     org.jfree.chart.axis.NumberAxis var41 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var42 = null;
//     var41.setPlot(var42);
//     double var44 = var41.getLowerMargin();
//     org.jfree.data.Range var45 = var6.getDataRange((org.jfree.chart.axis.ValueAxis)var41);
//     org.jfree.chart.plot.Plot var46 = var41.getPlot();
//     org.jfree.data.category.CategoryDataset var47 = null;
//     org.jfree.chart.axis.CategoryAxis var48 = null;
//     org.jfree.chart.axis.NumberAxis var49 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var50 = null;
//     var49.setPlot(var50);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var52 = null;
//     org.jfree.chart.plot.CategoryPlot var53 = new org.jfree.chart.plot.CategoryPlot(var47, var48, (org.jfree.chart.axis.ValueAxis)var49, var52);
//     org.jfree.chart.LegendItemSource var54 = null;
//     org.jfree.chart.title.LegendTitle var55 = new org.jfree.chart.title.LegendTitle(var54);
//     org.jfree.chart.util.RectangleEdge var56 = var55.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var57 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var58 = var57.getNextOutlinePaint();
//     var55.setBackgroundPaint(var58);
//     var53.setOutlinePaint(var58);
//     java.awt.Stroke var61 = var53.getRangeCrosshairStroke();
//     org.jfree.chart.plot.PlotRenderingInfo var64 = null;
//     java.awt.geom.Point2D var65 = null;
//     var53.zoomRangeAxes((-8.0d), 2.0d, var64, var65);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var67 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var68 = var67.getPositiveItemLabelPositionFallback();
//     java.awt.Paint var71 = var67.getItemLabelPaint((-123), (-1));
//     org.jfree.data.category.CategoryDataset var72 = null;
//     org.jfree.chart.axis.CategoryAxis var73 = null;
//     org.jfree.chart.axis.NumberAxis var74 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var75 = null;
//     var74.setPlot(var75);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var77 = null;
//     org.jfree.chart.plot.CategoryPlot var78 = new org.jfree.chart.plot.CategoryPlot(var72, var73, (org.jfree.chart.axis.ValueAxis)var74, var77);
//     java.awt.Stroke var79 = var74.getTickMarkStroke();
//     org.jfree.chart.LegendItemSource var80 = null;
//     org.jfree.chart.title.LegendTitle var81 = new org.jfree.chart.title.LegendTitle(var80);
//     org.jfree.chart.util.RectangleInsets var82 = var81.getItemLabelPadding();
//     double var83 = var82.getTop();
//     org.jfree.chart.block.LineBorder var84 = new org.jfree.chart.block.LineBorder(var71, var79, var82);
//     java.awt.Stroke var85 = var84.getStroke();
//     var53.setOutlineStroke(var85);
//     var53.setRangeCrosshairValue(6.0d, true);
//     boolean var90 = var41.hasListener((java.util.EventListener)var53);
//     
//     // Checks the contract:  equals-hashcode on var6 and var78
//     assertTrue("Contract failed: equals-hashcode on var6 and var78", var6.equals(var78) ? var6.hashCode() == var78.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var78 and var6
//     assertTrue("Contract failed: equals-hashcode on var78 and var6", var78.equals(var6) ? var78.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.util.RectangleEdge var2 = var1.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var3 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var4 = var3.getNextOutlinePaint();
    var1.setBackgroundPaint(var4);
    org.jfree.chart.LegendItemSource var6 = null;
    org.jfree.chart.title.LegendTitle var7 = new org.jfree.chart.title.LegendTitle(var6);
    org.jfree.chart.util.RectangleEdge var8 = var7.getLegendItemGraphicEdge();
    java.awt.Paint var9 = var7.getItemPaint();
    var7.setNotify(true);
    boolean var12 = var1.equals((java.lang.Object)var7);
    org.jfree.chart.util.HorizontalAlignment var13 = var1.getHorizontalAlignment();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var1 = null;
    var0.setPlot(var1);
    var0.setLowerBound(2.0d);
    org.jfree.data.category.CategoryDataset var5 = null;
    org.jfree.chart.axis.CategoryAxis var6 = null;
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var8 = null;
    var7.setPlot(var8);
    org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot(var5, var6, (org.jfree.chart.axis.ValueAxis)var7, var10);
    java.awt.Stroke var12 = var7.getTickMarkStroke();
    var7.setVerticalTickLabels(false);
    org.jfree.data.category.CategoryDataset var15 = null;
    org.jfree.chart.axis.CategoryAxis var16 = null;
    org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var18 = null;
    var17.setPlot(var18);
    org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
    org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var15, var16, (org.jfree.chart.axis.ValueAxis)var17, var20);
    var21.setAnchorValue(0.0d, true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var25 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var27 = null;
    var25.setSeriesItemLabelsVisible(0, var27, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var25.setSeriesToolTipGenerator(1, var31, false);
    org.jfree.chart.urls.CategoryURLGenerator var34 = null;
    var25.setBaseURLGenerator(var34);
    java.awt.Graphics2D var36 = null;
    org.jfree.chart.plot.CategoryPlot var37 = null;
    org.jfree.chart.axis.ValueAxis var38 = null;
    org.jfree.chart.plot.Marker var39 = null;
    java.awt.geom.Rectangle2D var40 = null;
    var25.drawRangeMarker(var36, var37, var38, var39, var40);
    boolean var43 = var25.isSeriesVisibleInLegend(0);
    var21.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var25);
    var7.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var21);
    var0.addChangeListener((org.jfree.chart.event.AxisChangeListener)var21);
    var0.configure();
    var0.setPositiveArrowVisible(false);
    var0.setVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);

  }

  public void test443() {}
//   public void test443() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("CategoryLabelEntity: category=null, tooltip=hi!, url=");
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.axis.AxisState var4 = new org.jfree.chart.axis.AxisState(0.0d);
//     org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis();
//     org.jfree.chart.axis.CategoryAnchor var10 = null;
//     org.jfree.chart.LegendItemSource var13 = null;
//     org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle(var13);
//     org.jfree.chart.util.RectangleInsets var15 = var14.getItemLabelPadding();
//     org.jfree.chart.LegendItemSource var16 = null;
//     org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle(var16);
//     org.jfree.chart.util.RectangleInsets var18 = var17.getItemLabelPadding();
//     double var19 = var18.getTop();
//     var14.setPadding(var18);
//     org.jfree.chart.util.Size2D var21 = new org.jfree.chart.util.Size2D();
//     boolean var23 = var21.equals((java.lang.Object)(-1L));
//     double var24 = var21.getWidth();
//     double var25 = var21.getHeight();
//     org.jfree.chart.util.RectangleAnchor var28 = null;
//     java.awt.geom.Rectangle2D var29 = org.jfree.chart.util.RectangleAnchor.createRectangle(var21, 2.0d, (-1.0d), var28);
//     org.jfree.chart.axis.CategoryLabelPositions var32 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var33 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var34 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var32, var33);
//     org.jfree.chart.util.RectangleAnchor var35 = var33.getCategoryAnchor();
//     java.awt.geom.Rectangle2D var36 = org.jfree.chart.util.RectangleAnchor.createRectangle(var21, 2.0d, 1.0d, var35);
//     java.awt.geom.Rectangle2D var37 = var18.createOutsetRectangle(var36);
//     org.jfree.chart.axis.AxisState var39 = new org.jfree.chart.axis.AxisState(2.0d);
//     org.jfree.chart.LegendItemSource var41 = null;
//     org.jfree.chart.title.LegendTitle var42 = new org.jfree.chart.title.LegendTitle(var41);
//     org.jfree.chart.util.RectangleEdge var43 = var42.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var44 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var45 = var44.getNextOutlinePaint();
//     var42.setBackgroundPaint(var45);
//     org.jfree.chart.text.TextBlock var47 = new org.jfree.chart.text.TextBlock();
//     java.util.List var48 = var47.getLines();
//     boolean var49 = var42.equals((java.lang.Object)var47);
//     org.jfree.chart.util.RectangleEdge var50 = var42.getLegendItemGraphicEdge();
//     var39.moveCursor(2.0d, var50);
//     double var52 = var9.getCategoryJava2DCoordinate(var10, (-123), 0, var37, var50);
//     java.awt.Shape var62 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
//     org.jfree.chart.entity.ChartEntity var64 = new org.jfree.chart.entity.ChartEntity(var62, "Range[-1.0,-1.0]");
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var65 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var67 = null;
//     var65.setSeriesItemLabelsVisible(0, var67, false);
//     java.awt.Stroke var70 = var65.getErrorIndicatorStroke();
//     java.awt.Paint var71 = null;
//     org.jfree.chart.LegendItem var72 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var62, var70, var71);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var73 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var74 = var73.getPositiveItemLabelPositionFallback();
//     java.awt.Paint var77 = var73.getItemLabelPaint((-123), (-1));
//     org.jfree.chart.LegendItem var78 = new org.jfree.chart.LegendItem("", "CategoryLabelEntity: category=null, tooltip=hi!, url=", "CategoryLabelEntity: category=null, tooltip=hi!, url=", "Range[-1.0,-1.0]", var62, var77);
//     org.jfree.chart.LegendItem var79 = new org.jfree.chart.LegendItem("hi!", "AxisLocation.TOP_OR_RIGHT", "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", "RectangleAnchor.CENTER", (java.awt.Shape)var37, var77);
//     org.jfree.data.category.CategoryDataset var80 = null;
//     org.jfree.chart.axis.CategoryAxis var81 = null;
//     org.jfree.chart.axis.NumberAxis var82 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var83 = null;
//     var82.setPlot(var83);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var85 = null;
//     org.jfree.chart.plot.CategoryPlot var86 = new org.jfree.chart.plot.CategoryPlot(var80, var81, (org.jfree.chart.axis.ValueAxis)var82, var85);
//     org.jfree.chart.axis.NumberAxis var87 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var88 = null;
//     var87.setPlot(var88);
//     org.jfree.chart.axis.ValueAxis[] var90 = new org.jfree.chart.axis.ValueAxis[] { var87};
//     var86.setRangeAxes(var90);
//     int var92 = var86.getRangeAxisCount();
//     org.jfree.chart.util.RectangleEdge var94 = var86.getDomainAxisEdge(0);
//     java.util.List var95 = var1.refreshTicks(var2, var4, var37, var94);
// 
//   }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, 6.0d, 100.0f, (-1.0f));

  }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    org.jfree.chart.LegendItemSource var7 = null;
    org.jfree.chart.title.LegendTitle var8 = new org.jfree.chart.title.LegendTitle(var7);
    org.jfree.chart.util.RectangleEdge var9 = var8.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var10 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var11 = var10.getNextOutlinePaint();
    var8.setBackgroundPaint(var11);
    var6.setOutlinePaint(var11);
    org.jfree.data.category.CategoryDataset var14 = null;
    org.jfree.chart.axis.CategoryAxis var15 = null;
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var17 = null;
    var16.setPlot(var17);
    org.jfree.chart.renderer.category.CategoryItemRenderer var19 = null;
    org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot(var14, var15, (org.jfree.chart.axis.ValueAxis)var16, var19);
    org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var22 = null;
    var21.setPlot(var22);
    org.jfree.chart.axis.ValueAxis[] var24 = new org.jfree.chart.axis.ValueAxis[] { var21};
    var20.setRangeAxes(var24);
    var6.setParent((org.jfree.chart.plot.Plot)var20);
    java.awt.Stroke var27 = var20.getRangeCrosshairStroke();
    org.jfree.chart.block.LabelBlock var29 = new org.jfree.chart.block.LabelBlock("Range[-1.0,-1.0]");
    java.awt.Paint var30 = var29.getPaint();
    var20.setRangeCrosshairPaint(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test446() {}
//   public void test446() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var3 = null;
//     var2.setPlot(var3);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
//     var2.setAutoRangeMinimumSize(2.0d);
//     java.awt.geom.Rectangle2D var10 = null;
//     org.jfree.chart.util.RectangleEdge var11 = null;
//     double var12 = var2.java2DToValue(0.0d, var10, var11);
//     org.jfree.chart.axis.NumberTickUnit var13 = var2.getTickUnit();
//     boolean var14 = var2.isAutoRange();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var2.setRange(10.0d, 0.0d);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == true);
// 
//   }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.95f);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var13 = new org.jfree.chart.entity.ChartEntity(var11, "Range[-1.0,-1.0]");
    org.jfree.chart.renderer.category.StatisticalBarRenderer var14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var16 = null;
    var14.setSeriesItemLabelsVisible(0, var16, false);
    java.awt.Stroke var19 = var14.getErrorIndicatorStroke();
    java.awt.Paint var20 = null;
    org.jfree.chart.LegendItem var21 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var11, var19, var20);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var23 = var22.getPositiveItemLabelPositionFallback();
    java.awt.Paint var26 = var22.getItemLabelPaint((-123), (-1));
    org.jfree.chart.LegendItem var27 = new org.jfree.chart.LegendItem("", "CategoryLabelEntity: category=null, tooltip=hi!, url=", "CategoryLabelEntity: category=null, tooltip=hi!, url=", "Range[-1.0,-1.0]", var11, var26);
    boolean var28 = org.jfree.chart.util.ShapeUtilities.equal(var1, var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);

  }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }


    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var7 = new org.jfree.chart.entity.ChartEntity(var5, "Range[-1.0,-1.0]");
    org.jfree.chart.renderer.category.StatisticalBarRenderer var8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var10 = null;
    var8.setSeriesItemLabelsVisible(0, var10, false);
    java.awt.Stroke var13 = var8.getErrorIndicatorStroke();
    java.awt.Paint var14 = null;
    org.jfree.chart.LegendItem var15 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var5, var13, var14);
    java.lang.String var16 = var15.getLabel();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + "hi!"+ "'", var16.equals("hi!"));

  }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    java.lang.Object var2 = null;
    var0.addObject((java.lang.Comparable)'#', var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeValue((java.lang.Comparable)1L);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = null;
    var0.setSeriesItemLabelsVisible(0, var2, false);
    org.jfree.data.category.CategoryDataset var5 = null;
    org.jfree.chart.axis.CategoryAxis var6 = null;
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var8 = null;
    var7.setPlot(var8);
    org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot(var5, var6, (org.jfree.chart.axis.ValueAxis)var7, var10);
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var13 = null;
    var12.setPlot(var13);
    org.jfree.chart.axis.ValueAxis[] var15 = new org.jfree.chart.axis.ValueAxis[] { var12};
    var11.setRangeAxes(var15);
    java.awt.Paint var17 = var11.getDomainGridlinePaint();
    boolean var18 = var0.equals((java.lang.Object)var11);
    org.jfree.chart.axis.CategoryAnchor var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.setDomainGridlinePosition(var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDiamond(1.0f);
    org.jfree.data.category.CategoryDataset var6 = null;
    org.jfree.chart.axis.CategoryAxis var7 = null;
    org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var9 = null;
    var8.setPlot(var9);
    org.jfree.chart.renderer.category.CategoryItemRenderer var11 = null;
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot(var6, var7, (org.jfree.chart.axis.ValueAxis)var8, var11);
    java.awt.Stroke var13 = var8.getTickMarkStroke();
    java.awt.Font var14 = var8.getLabelFont();
    float var15 = var8.getTickMarkInsideLength();
    java.lang.String var16 = var8.getLabelURL();
    org.jfree.data.category.CategoryDataset var18 = null;
    org.jfree.chart.axis.CategoryAxis var19 = null;
    org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var21 = null;
    var20.setPlot(var21);
    org.jfree.chart.renderer.category.CategoryItemRenderer var23 = null;
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot(var18, var19, (org.jfree.chart.axis.ValueAxis)var20, var23);
    org.jfree.chart.LegendItemSource var25 = null;
    org.jfree.chart.title.LegendTitle var26 = new org.jfree.chart.title.LegendTitle(var25);
    org.jfree.chart.util.RectangleEdge var27 = var26.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var28 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var29 = var28.getNextOutlinePaint();
    var26.setBackgroundPaint(var29);
    var24.setOutlinePaint(var29);
    org.jfree.chart.JFreeChart var32 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var24);
    var32.fireChartChanged();
    var32.setTextAntiAlias(false);
    org.jfree.chart.plot.CategoryPlot var36 = var32.getCategoryPlot();
    var36.clearRangeAxes();
    org.jfree.chart.block.LabelBlock var41 = new org.jfree.chart.block.LabelBlock("");
    java.awt.Font var42 = var41.getFont();
    java.awt.Color var46 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.95f);
    org.jfree.chart.text.TextBlock var47 = org.jfree.chart.text.TextUtilities.createTextBlock("CategoryLabelEntity: category=null, tooltip=hi!, url=", var42, (java.awt.Paint)var46);
    java.awt.Color var48 = java.awt.Color.getColor("CategoryLabelEntity: category=null, tooltip=hi!, url=", var46);
    var36.setDomainGridlinePaint((java.awt.Paint)var46);
    var8.setTickLabelPaint((java.awt.Paint)var46);
    org.jfree.data.category.CategoryDataset var51 = null;
    org.jfree.chart.axis.CategoryAxis var52 = null;
    org.jfree.chart.axis.NumberAxis var53 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var54 = null;
    var53.setPlot(var54);
    org.jfree.chart.renderer.category.CategoryItemRenderer var56 = null;
    org.jfree.chart.plot.CategoryPlot var57 = new org.jfree.chart.plot.CategoryPlot(var51, var52, (org.jfree.chart.axis.ValueAxis)var53, var56);
    java.awt.Stroke var58 = var53.getTickMarkStroke();
    java.awt.Font var59 = var53.getLabelFont();
    float var60 = var53.getTickMarkInsideLength();
    java.lang.String var61 = var53.getLabelURL();
    boolean var62 = var53.getAutoRangeStickyZero();
    java.awt.Stroke var63 = var53.getTickMarkStroke();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var64 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var65 = null;
    var64.setBaseURLGenerator(var65);
    org.jfree.data.category.CategoryDataset var68 = null;
    org.jfree.chart.axis.CategoryAxis var69 = null;
    org.jfree.chart.axis.NumberAxis var70 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var71 = null;
    var70.setPlot(var71);
    org.jfree.chart.renderer.category.CategoryItemRenderer var73 = null;
    org.jfree.chart.plot.CategoryPlot var74 = new org.jfree.chart.plot.CategoryPlot(var68, var69, (org.jfree.chart.axis.ValueAxis)var70, var73);
    org.jfree.chart.LegendItemSource var75 = null;
    org.jfree.chart.title.LegendTitle var76 = new org.jfree.chart.title.LegendTitle(var75);
    org.jfree.chart.util.RectangleEdge var77 = var76.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var78 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var79 = var78.getNextOutlinePaint();
    var76.setBackgroundPaint(var79);
    var74.setOutlinePaint(var79);
    var64.setSeriesPaint(1, var79, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var84 = new org.jfree.chart.LegendItem(var0, "java.awt.Color[r=255,g=255,b=255]", "java.awt.Color[r=0,g=0,b=0]", "TextBlockAnchor.BOTTOM_CENTER", var5, (java.awt.Paint)var46, var63, var79);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);

  }

  public void test453() {}
//   public void test453() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var4 = null;
//     var3.setPlot(var4);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var3, var6);
//     org.jfree.chart.LegendItemSource var8 = null;
//     org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
//     org.jfree.chart.util.RectangleEdge var10 = var9.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var12 = var11.getNextOutlinePaint();
//     var9.setBackgroundPaint(var12);
//     var7.setOutlinePaint(var12);
//     org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var7);
//     java.lang.Object var16 = var15.clone();
//     boolean var17 = var15.isNotify();
//     org.jfree.data.category.CategoryDataset var18 = null;
//     org.jfree.chart.axis.CategoryAxis var19 = null;
//     org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var21 = null;
//     var20.setPlot(var21);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var23 = null;
//     org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot(var18, var19, (org.jfree.chart.axis.ValueAxis)var20, var23);
//     java.awt.Stroke var25 = var20.getTickMarkStroke();
//     var20.zoomRange((-1.0d), 100.0d);
//     org.jfree.chart.block.BlockContainer var29 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.util.RectangleInsets var30 = var29.getPadding();
//     double var32 = var30.calculateTopInset(100.0d);
//     var20.setLabelInsets(var30);
//     java.awt.Color var37 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.0f);
//     var20.setTickLabelPaint((java.awt.Paint)var37);
//     var15.setBorderPaint((java.awt.Paint)var37);
//     var15.setBorderVisible(true);
//     org.jfree.chart.block.BlockContainer var42 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.util.RectangleInsets var43 = var42.getPadding();
//     org.jfree.chart.util.HorizontalAlignment var44 = null;
//     org.jfree.chart.util.VerticalAlignment var45 = null;
//     org.jfree.chart.block.FlowArrangement var48 = new org.jfree.chart.block.FlowArrangement(var44, var45, 0.0d, 0.0d);
//     var42.setArrangement((org.jfree.chart.block.Arrangement)var48);
//     org.jfree.chart.LegendItemSource var50 = null;
//     org.jfree.chart.title.LegendTitle var51 = new org.jfree.chart.title.LegendTitle(var50);
//     org.jfree.chart.util.RectangleEdge var52 = var51.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var53 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var54 = var53.getNextOutlinePaint();
//     var51.setBackgroundPaint(var54);
//     org.jfree.chart.LegendItemSource var56 = null;
//     org.jfree.chart.title.LegendTitle var57 = new org.jfree.chart.title.LegendTitle(var56);
//     org.jfree.chart.util.RectangleEdge var58 = var57.getLegendItemGraphicEdge();
//     java.awt.Paint var59 = var57.getItemPaint();
//     var57.setNotify(true);
//     boolean var62 = var51.equals((java.lang.Object)var57);
//     var42.add((org.jfree.chart.block.Block)var51);
//     var15.removeSubtitle((org.jfree.chart.title.Title)var51);
//     
//     // Checks the contract:  equals-hashcode on var11 and var53
//     assertTrue("Contract failed: equals-hashcode on var11 and var53", var11.equals(var53) ? var11.hashCode() == var53.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var53 and var11
//     assertTrue("Contract failed: equals-hashcode on var53 and var11", var53.equals(var11) ? var53.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    java.util.List var1 = var0.getColumnKeys();
    java.lang.Object var4 = var0.getObject((java.lang.Comparable)(-1), (java.lang.Comparable)0L);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var5 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var6 = var5.getPositiveItemLabelPositionFallback();
    java.awt.Paint var9 = var5.getItemLabelPaint((-123), (-1));
    org.jfree.data.category.CategoryDataset var10 = null;
    org.jfree.chart.axis.CategoryAxis var11 = null;
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var13 = null;
    var12.setPlot(var13);
    org.jfree.chart.renderer.category.CategoryItemRenderer var15 = null;
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var10, var11, (org.jfree.chart.axis.ValueAxis)var12, var15);
    java.awt.Stroke var17 = var12.getTickMarkStroke();
    org.jfree.chart.LegendItemSource var18 = null;
    org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle(var18);
    org.jfree.chart.util.RectangleInsets var20 = var19.getItemLabelPadding();
    double var21 = var20.getTop();
    org.jfree.chart.block.LineBorder var22 = new org.jfree.chart.block.LineBorder(var9, var17, var20);
    java.awt.Stroke var23 = var22.getStroke();
    var0.setObject((java.lang.Object)var22, (java.lang.Comparable)"", (java.lang.Comparable)4.0d);
    java.lang.Object var27 = var0.clone();
    java.lang.Object var28 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test455() {}
//   public void test455() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }
// 
// 
//     org.jfree.chart.LegendItemSource var0 = null;
//     org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
//     org.jfree.chart.util.RectangleEdge var2 = var1.getLegendItemGraphicEdge();
//     org.jfree.chart.util.RectangleAnchor var3 = null;
//     var1.setLegendItemGraphicLocation(var3);
//     org.jfree.chart.util.HorizontalAlignment var5 = null;
//     org.jfree.chart.LegendItemSource var6 = null;
//     org.jfree.chart.title.LegendTitle var7 = new org.jfree.chart.title.LegendTitle(var6);
//     org.jfree.chart.util.RectangleInsets var8 = var7.getItemLabelPadding();
//     org.jfree.chart.util.VerticalAlignment var9 = var7.getVerticalAlignment();
//     org.jfree.chart.block.ColumnArrangement var12 = new org.jfree.chart.block.ColumnArrangement(var5, var9, 0.0d, 2.0d);
//     org.jfree.chart.block.BlockContainer var13 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.util.RectangleInsets var14 = var13.getPadding();
//     java.awt.Graphics2D var15 = null;
//     org.jfree.chart.block.RectangleConstraint var18 = new org.jfree.chart.block.RectangleConstraint(0.0d, 0.0d);
//     org.jfree.chart.util.Size2D var19 = var12.arrange(var13, var15, var18);
//     var1.setWrapper(var13);
//     org.jfree.chart.util.RectangleAnchor var21 = var1.getLegendItemGraphicLocation();
//     org.jfree.chart.util.RectangleInsets var22 = var1.getMargin();
//     org.jfree.data.category.CategoryDataset var23 = null;
//     org.jfree.chart.axis.CategoryAxis var24 = null;
//     org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var26 = null;
//     var25.setPlot(var26);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var28 = null;
//     org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot(var23, var24, (org.jfree.chart.axis.ValueAxis)var25, var28);
//     var25.setAutoRangeMinimumSize(2.0d);
//     java.awt.geom.Rectangle2D var33 = null;
//     org.jfree.chart.util.RectangleEdge var34 = null;
//     double var35 = var25.java2DToValue(0.0d, var33, var34);
//     var25.setAutoTickUnitSelection(true);
//     var25.setUpperMargin(0.0d);
//     org.jfree.chart.LegendItemSource var40 = null;
//     org.jfree.chart.title.LegendTitle var41 = new org.jfree.chart.title.LegendTitle(var40);
//     org.jfree.chart.util.RectangleInsets var42 = var41.getItemLabelPadding();
//     org.jfree.chart.util.VerticalAlignment var43 = var41.getVerticalAlignment();
//     org.jfree.chart.block.BlockContainer var44 = var41.getItemContainer();
//     org.jfree.chart.LegendItemSource var45 = null;
//     org.jfree.chart.title.LegendTitle var46 = new org.jfree.chart.title.LegendTitle(var45);
//     org.jfree.chart.util.RectangleInsets var47 = var46.getItemLabelPadding();
//     double var49 = var47.calculateTopOutset(4.0d);
//     var44.setMargin(var47);
//     java.awt.geom.Rectangle2D var51 = var44.getBounds();
//     org.jfree.chart.LegendItemSource var52 = null;
//     org.jfree.chart.title.LegendTitle var53 = new org.jfree.chart.title.LegendTitle(var52);
//     org.jfree.chart.util.RectangleInsets var54 = var53.getItemLabelPadding();
//     org.jfree.chart.util.RectangleAnchor var55 = var53.getLegendItemGraphicLocation();
//     java.awt.geom.Point2D var56 = org.jfree.chart.util.RectangleAnchor.coordinates(var51, var55);
//     var25.setDownArrow((java.awt.Shape)var51);
//     org.jfree.chart.util.LengthAdjustmentType var58 = null;
//     org.jfree.chart.util.LengthAdjustmentType var59 = null;
//     java.awt.geom.Rectangle2D var60 = var22.createAdjustedRectangle(var51, var58, var59);
//     org.jfree.chart.LegendItemSource var61 = null;
//     org.jfree.chart.title.LegendTitle var62 = new org.jfree.chart.title.LegendTitle(var61);
//     org.jfree.chart.util.RectangleInsets var63 = var62.getItemLabelPadding();
//     org.jfree.chart.LegendItemSource var64 = null;
//     org.jfree.chart.title.LegendTitle var65 = new org.jfree.chart.title.LegendTitle(var64);
//     org.jfree.chart.util.RectangleInsets var66 = var65.getItemLabelPadding();
//     double var67 = var66.getTop();
//     var62.setPadding(var66);
//     org.jfree.chart.util.Size2D var69 = new org.jfree.chart.util.Size2D();
//     boolean var71 = var69.equals((java.lang.Object)(-1L));
//     double var72 = var69.getWidth();
//     double var73 = var69.getHeight();
//     org.jfree.chart.util.RectangleAnchor var76 = null;
//     java.awt.geom.Rectangle2D var77 = org.jfree.chart.util.RectangleAnchor.createRectangle(var69, 2.0d, (-1.0d), var76);
//     org.jfree.chart.axis.CategoryLabelPositions var80 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var81 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var82 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var80, var81);
//     org.jfree.chart.util.RectangleAnchor var83 = var81.getCategoryAnchor();
//     java.awt.geom.Rectangle2D var84 = org.jfree.chart.util.RectangleAnchor.createRectangle(var69, 2.0d, 1.0d, var83);
//     java.awt.geom.Rectangle2D var85 = var66.createOutsetRectangle(var84);
//     boolean var86 = org.jfree.chart.util.ShapeUtilities.contains(var60, var85);
//     
//     // Checks the contract:  equals-hashcode on var19 and var69
//     assertTrue("Contract failed: equals-hashcode on var19 and var69", var19.equals(var69) ? var19.hashCode() == var69.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var69 and var19
//     assertTrue("Contract failed: equals-hashcode on var69 and var19", var69.equals(var19) ? var69.hashCode() == var19.hashCode() : true);
// 
//   }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = null;
    var0.setSeriesItemLabelsVisible(0, var2, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var6 = null;
    var0.setSeriesToolTipGenerator(1, var6, false);
    org.jfree.chart.urls.CategoryURLGenerator var9 = null;
    var0.setBaseURLGenerator(var9);
    var0.setBaseCreateEntities(false, false);
    var0.setSeriesVisibleInLegend(0, (java.lang.Boolean)false);
    boolean var17 = var0.getBaseSeriesVisibleInLegend();
    org.jfree.chart.urls.CategoryURLGenerator var18 = null;
    var0.setBaseURLGenerator(var18, false);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var24 = var22.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var27 = var22.getPositiveItemLabelPosition(100, 0);
    org.jfree.chart.urls.CategoryURLGenerator var28 = var22.getBaseURLGenerator();
    java.lang.Boolean var30 = var22.getSeriesItemLabelsVisible((-855310));
    org.jfree.data.category.CategoryDataset var31 = null;
    org.jfree.chart.axis.CategoryAxis var32 = null;
    org.jfree.chart.axis.NumberAxis var33 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var34 = null;
    var33.setPlot(var34);
    org.jfree.chart.renderer.category.CategoryItemRenderer var36 = null;
    org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot(var31, var32, (org.jfree.chart.axis.ValueAxis)var33, var36);
    java.awt.Stroke var38 = var33.getTickMarkStroke();
    var22.setBaseOutlineStroke(var38);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesStroke((-123), var38, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test457() {}
//   public void test457() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }
// 
// 
//     org.jfree.chart.LegendItemSource var0 = null;
//     org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
//     org.jfree.chart.util.RectangleInsets var2 = var1.getItemLabelPadding();
//     double var4 = var2.calculateTopOutset(4.0d);
//     org.jfree.data.category.CategoryDataset var5 = null;
//     org.jfree.chart.axis.CategoryAxis var6 = null;
//     org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var8 = null;
//     var7.setPlot(var8);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot(var5, var6, (org.jfree.chart.axis.ValueAxis)var7, var10);
//     org.jfree.chart.LegendItemSource var12 = null;
//     org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle(var12);
//     org.jfree.chart.util.RectangleEdge var14 = var13.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var15 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var16 = var15.getNextOutlinePaint();
//     var13.setBackgroundPaint(var16);
//     var11.setOutlinePaint(var16);
//     org.jfree.data.category.CategoryDataset var19 = null;
//     org.jfree.chart.axis.CategoryAxis var20 = null;
//     org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var22 = null;
//     var21.setPlot(var22);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var24 = null;
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot(var19, var20, (org.jfree.chart.axis.ValueAxis)var21, var24);
//     org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var27 = null;
//     var26.setPlot(var27);
//     org.jfree.chart.axis.ValueAxis[] var29 = new org.jfree.chart.axis.ValueAxis[] { var26};
//     var25.setRangeAxes(var29);
//     var11.setParent((org.jfree.chart.plot.Plot)var25);
//     java.awt.Stroke var32 = var25.getRangeCrosshairStroke();
//     java.awt.Graphics2D var33 = null;
//     org.jfree.chart.LegendItemSource var34 = null;
//     org.jfree.chart.title.LegendTitle var35 = new org.jfree.chart.title.LegendTitle(var34);
//     org.jfree.chart.util.RectangleInsets var36 = var35.getItemLabelPadding();
//     org.jfree.chart.LegendItemSource var37 = null;
//     org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle(var37);
//     org.jfree.chart.util.RectangleInsets var39 = var38.getItemLabelPadding();
//     double var40 = var39.getTop();
//     var35.setPadding(var39);
//     org.jfree.chart.util.Size2D var42 = new org.jfree.chart.util.Size2D();
//     boolean var44 = var42.equals((java.lang.Object)(-1L));
//     double var45 = var42.getWidth();
//     double var46 = var42.getHeight();
//     org.jfree.chart.util.RectangleAnchor var49 = null;
//     java.awt.geom.Rectangle2D var50 = org.jfree.chart.util.RectangleAnchor.createRectangle(var42, 2.0d, (-1.0d), var49);
//     org.jfree.chart.axis.CategoryLabelPositions var53 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var54 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var55 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var53, var54);
//     org.jfree.chart.util.RectangleAnchor var56 = var54.getCategoryAnchor();
//     java.awt.geom.Rectangle2D var57 = org.jfree.chart.util.RectangleAnchor.createRectangle(var42, 2.0d, 1.0d, var56);
//     java.awt.geom.Rectangle2D var58 = var39.createOutsetRectangle(var57);
//     org.jfree.chart.plot.PlotRenderingInfo var60 = null;
//     boolean var61 = var25.render(var33, var58, 255, var60);
//     java.awt.geom.Rectangle2D var64 = var2.createInsetRectangle(var58, false, false);
//     org.jfree.data.category.CategoryDataset var66 = null;
//     org.jfree.chart.axis.CategoryAxis var67 = null;
//     org.jfree.chart.axis.NumberAxis var68 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var69 = null;
//     var68.setPlot(var69);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var71 = null;
//     org.jfree.chart.plot.CategoryPlot var72 = new org.jfree.chart.plot.CategoryPlot(var66, var67, (org.jfree.chart.axis.ValueAxis)var68, var71);
//     org.jfree.chart.LegendItemSource var73 = null;
//     org.jfree.chart.title.LegendTitle var74 = new org.jfree.chart.title.LegendTitle(var73);
//     org.jfree.chart.util.RectangleEdge var75 = var74.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var76 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var77 = var76.getNextOutlinePaint();
//     var74.setBackgroundPaint(var77);
//     var72.setOutlinePaint(var77);
//     org.jfree.chart.JFreeChart var80 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var72);
//     var80.fireChartChanged();
//     var80.setTextAntiAlias(false);
//     org.jfree.chart.plot.CategoryPlot var84 = var80.getCategoryPlot();
//     org.jfree.chart.util.RectangleEdge var85 = var84.getRangeAxisEdge();
//     double var86 = org.jfree.chart.util.RectangleEdge.coordinate(var64, var85);
//     
//     // Checks the contract:  equals-hashcode on var11 and var72
//     assertTrue("Contract failed: equals-hashcode on var11 and var72", var11.equals(var72) ? var11.hashCode() == var72.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var84
//     assertTrue("Contract failed: equals-hashcode on var11 and var84", var11.equals(var84) ? var11.hashCode() == var84.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var72 and var11
//     assertTrue("Contract failed: equals-hashcode on var72 and var11", var72.equals(var11) ? var72.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var84 and var11
//     assertTrue("Contract failed: equals-hashcode on var84 and var11", var84.equals(var11) ? var84.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var76
//     assertTrue("Contract failed: equals-hashcode on var15 and var76", var15.equals(var76) ? var15.hashCode() == var76.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var76 and var15
//     assertTrue("Contract failed: equals-hashcode on var76 and var15", var76.equals(var15) ? var76.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = null;
    var0.setSeriesItemLabelsVisible(0, var2, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var6 = null;
    var0.setSeriesToolTipGenerator(1, var6, false);
    org.jfree.chart.urls.CategoryURLGenerator var9 = null;
    var0.setBaseURLGenerator(var9);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var18 = new org.jfree.chart.entity.ChartEntity(var16, "Range[-1.0,-1.0]");
    org.jfree.chart.renderer.category.StatisticalBarRenderer var19 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var21 = null;
    var19.setSeriesItemLabelsVisible(0, var21, false);
    java.awt.Stroke var24 = var19.getErrorIndicatorStroke();
    java.awt.Paint var25 = null;
    org.jfree.chart.LegendItem var26 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var16, var24, var25);
    var0.setBaseStroke(var24, false);
    org.jfree.chart.LegendItemCollection var29 = var0.getLegendItems();
    var0.setMinimumBarLength(3.0d);
    org.jfree.chart.labels.CategoryItemLabelGenerator var33 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelGenerator((-123), var33);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var4 = null;
    var3.setPlot(var4);
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var3, var6);
    org.jfree.chart.LegendItemSource var8 = null;
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
    org.jfree.chart.util.RectangleEdge var10 = var9.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var12 = var11.getNextOutlinePaint();
    var9.setBackgroundPaint(var12);
    var7.setOutlinePaint(var12);
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var7);
    var15.fireChartChanged();
    boolean var17 = var15.getAntiAlias();
    java.awt.Stroke var18 = var15.getBorderStroke();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var19 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var21 = var19.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.CategoryItemLabelGenerator var22 = null;
    var19.setBaseItemLabelGenerator(var22);
    java.awt.Paint var26 = var19.getItemFillPaint(0, (-855310));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var15.setTextAntiAlias((java.lang.Object)0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Comparable var3 = null;
    var0.add((java.lang.Number)(short)0, (java.lang.Number)2.0d, var3, (java.lang.Comparable)"RectangleAnchor.CENTER");
    java.util.List var6 = var0.getColumnKeys();
    java.lang.Comparable var9 = null;
    var0.add((java.lang.Number)100.0f, (java.lang.Number)(short)10, var9, (java.lang.Comparable)1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test461() {}
//   public void test461() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }
// 
// 
//     org.jfree.chart.LegendItemSource var0 = null;
//     org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
//     org.jfree.chart.util.RectangleEdge var2 = var1.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var3 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var4 = var3.getNextOutlinePaint();
//     var1.setBackgroundPaint(var4);
//     org.jfree.chart.LegendItemSource var6 = null;
//     org.jfree.chart.title.LegendTitle var7 = new org.jfree.chart.title.LegendTitle(var6);
//     org.jfree.chart.util.RectangleInsets var8 = var7.getItemLabelPadding();
//     org.jfree.chart.util.VerticalAlignment var9 = var7.getVerticalAlignment();
//     org.jfree.chart.block.BlockContainer var10 = var7.getItemContainer();
//     var1.setWrapper(var10);
//     org.jfree.chart.block.LabelBlock var13 = new org.jfree.chart.block.LabelBlock("");
//     java.awt.Font var14 = var13.getFont();
//     org.jfree.data.category.CategoryDataset var15 = null;
//     org.jfree.chart.axis.CategoryAxis var16 = null;
//     org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var18 = null;
//     var17.setPlot(var18);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var15, var16, (org.jfree.chart.axis.ValueAxis)var17, var20);
//     java.awt.Stroke var22 = var17.getTickMarkStroke();
//     var17.setNegativeArrowVisible(false);
//     var10.add((org.jfree.chart.block.Block)var13, (java.lang.Object)false);
//     java.awt.Graphics2D var26 = null;
//     java.awt.Color var29 = java.awt.Color.getColor("", (-1));
//     java.awt.image.ColorModel var30 = null;
//     java.awt.Rectangle var31 = null;
//     org.jfree.chart.LegendItemSource var32 = null;
//     org.jfree.chart.title.LegendTitle var33 = new org.jfree.chart.title.LegendTitle(var32);
//     org.jfree.chart.util.RectangleInsets var34 = var33.getItemLabelPadding();
//     org.jfree.chart.LegendItemSource var35 = null;
//     org.jfree.chart.title.LegendTitle var36 = new org.jfree.chart.title.LegendTitle(var35);
//     org.jfree.chart.util.RectangleInsets var37 = var36.getItemLabelPadding();
//     double var38 = var37.getTop();
//     var33.setPadding(var37);
//     org.jfree.chart.util.Size2D var40 = new org.jfree.chart.util.Size2D();
//     boolean var42 = var40.equals((java.lang.Object)(-1L));
//     double var43 = var40.getWidth();
//     double var44 = var40.getHeight();
//     org.jfree.chart.util.RectangleAnchor var47 = null;
//     java.awt.geom.Rectangle2D var48 = org.jfree.chart.util.RectangleAnchor.createRectangle(var40, 2.0d, (-1.0d), var47);
//     org.jfree.chart.axis.CategoryLabelPositions var51 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var52 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var53 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var51, var52);
//     org.jfree.chart.util.RectangleAnchor var54 = var52.getCategoryAnchor();
//     java.awt.geom.Rectangle2D var55 = org.jfree.chart.util.RectangleAnchor.createRectangle(var40, 2.0d, 1.0d, var54);
//     java.awt.geom.Rectangle2D var56 = var37.createOutsetRectangle(var55);
//     java.awt.geom.AffineTransform var57 = null;
//     java.awt.RenderingHints var58 = null;
//     java.awt.PaintContext var59 = var29.createContext(var30, var31, var56, var57, var58);
//     org.jfree.chart.text.TextBlock var60 = new org.jfree.chart.text.TextBlock();
//     java.awt.Graphics2D var61 = null;
//     org.jfree.chart.text.TextBlockAnchor var64 = null;
//     var60.draw(var61, 100.0f, 100.0f, var64);
//     org.jfree.chart.text.TextLine var66 = new org.jfree.chart.text.TextLine();
//     org.jfree.chart.text.TextFragment var67 = var66.getFirstTextFragment();
//     var60.addLine(var66);
//     java.util.List var69 = var60.getLines();
//     java.lang.Object var70 = var10.draw(var26, (java.awt.geom.Rectangle2D)var31, (java.lang.Object)var60);
// 
//   }

  public void test462() {}
//   public void test462() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("java.awt.Color[r=242,g=242,b=242]", var1, 1.0f, (-1.0f), (-0.55d), 10.0f, 1.0f);
// 
//   }

  public void test463() {}
//   public void test463() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var4 = null;
//     var3.setPlot(var4);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var3, var6);
//     org.jfree.chart.LegendItemSource var8 = null;
//     org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
//     org.jfree.chart.util.RectangleEdge var10 = var9.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var12 = var11.getNextOutlinePaint();
//     var9.setBackgroundPaint(var12);
//     var7.setOutlinePaint(var12);
//     org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var7);
//     java.lang.Object var16 = var15.clone();
//     org.jfree.chart.plot.CategoryPlot var17 = var15.getCategoryPlot();
//     java.awt.Graphics2D var18 = null;
//     org.jfree.chart.LegendItemSource var19 = null;
//     org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle(var19);
//     org.jfree.chart.util.RectangleEdge var21 = var20.getLegendItemGraphicEdge();
//     org.jfree.chart.util.RectangleAnchor var22 = null;
//     var20.setLegendItemGraphicLocation(var22);
//     org.jfree.chart.util.HorizontalAlignment var24 = null;
//     org.jfree.chart.LegendItemSource var25 = null;
//     org.jfree.chart.title.LegendTitle var26 = new org.jfree.chart.title.LegendTitle(var25);
//     org.jfree.chart.util.RectangleInsets var27 = var26.getItemLabelPadding();
//     org.jfree.chart.util.VerticalAlignment var28 = var26.getVerticalAlignment();
//     org.jfree.chart.block.ColumnArrangement var31 = new org.jfree.chart.block.ColumnArrangement(var24, var28, 0.0d, 2.0d);
//     org.jfree.chart.block.BlockContainer var32 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.util.RectangleInsets var33 = var32.getPadding();
//     java.awt.Graphics2D var34 = null;
//     org.jfree.chart.block.RectangleConstraint var37 = new org.jfree.chart.block.RectangleConstraint(0.0d, 0.0d);
//     org.jfree.chart.util.Size2D var38 = var31.arrange(var32, var34, var37);
//     var20.setWrapper(var32);
//     org.jfree.chart.util.RectangleAnchor var40 = var20.getLegendItemGraphicLocation();
//     org.jfree.chart.util.RectangleInsets var41 = var20.getMargin();
//     org.jfree.data.category.CategoryDataset var42 = null;
//     org.jfree.chart.axis.CategoryAxis var43 = null;
//     org.jfree.chart.axis.NumberAxis var44 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var45 = null;
//     var44.setPlot(var45);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var47 = null;
//     org.jfree.chart.plot.CategoryPlot var48 = new org.jfree.chart.plot.CategoryPlot(var42, var43, (org.jfree.chart.axis.ValueAxis)var44, var47);
//     var44.setAutoRangeMinimumSize(2.0d);
//     java.awt.geom.Rectangle2D var52 = null;
//     org.jfree.chart.util.RectangleEdge var53 = null;
//     double var54 = var44.java2DToValue(0.0d, var52, var53);
//     var44.setAutoTickUnitSelection(true);
//     var44.setUpperMargin(0.0d);
//     org.jfree.chart.LegendItemSource var59 = null;
//     org.jfree.chart.title.LegendTitle var60 = new org.jfree.chart.title.LegendTitle(var59);
//     org.jfree.chart.util.RectangleInsets var61 = var60.getItemLabelPadding();
//     org.jfree.chart.util.VerticalAlignment var62 = var60.getVerticalAlignment();
//     org.jfree.chart.block.BlockContainer var63 = var60.getItemContainer();
//     org.jfree.chart.LegendItemSource var64 = null;
//     org.jfree.chart.title.LegendTitle var65 = new org.jfree.chart.title.LegendTitle(var64);
//     org.jfree.chart.util.RectangleInsets var66 = var65.getItemLabelPadding();
//     double var68 = var66.calculateTopOutset(4.0d);
//     var63.setMargin(var66);
//     java.awt.geom.Rectangle2D var70 = var63.getBounds();
//     org.jfree.chart.LegendItemSource var71 = null;
//     org.jfree.chart.title.LegendTitle var72 = new org.jfree.chart.title.LegendTitle(var71);
//     org.jfree.chart.util.RectangleInsets var73 = var72.getItemLabelPadding();
//     org.jfree.chart.util.RectangleAnchor var74 = var72.getLegendItemGraphicLocation();
//     java.awt.geom.Point2D var75 = org.jfree.chart.util.RectangleAnchor.coordinates(var70, var74);
//     var44.setDownArrow((java.awt.Shape)var70);
//     org.jfree.chart.util.LengthAdjustmentType var77 = null;
//     org.jfree.chart.util.LengthAdjustmentType var78 = null;
//     java.awt.geom.Rectangle2D var79 = var41.createAdjustedRectangle(var70, var77, var78);
//     org.jfree.chart.ChartRenderingInfo var80 = null;
//     var15.draw(var18, var79, var80);
// 
//   }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var1 = null;
    var0.setPlot(var1);
    var0.setLowerBound(2.0d);
    java.lang.String var5 = var0.getLabelToolTip();
    org.jfree.chart.util.RectangleInsets var6 = var0.getLabelInsets();
    double var8 = var6.calculateRightInset(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 3.0d);

  }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.util.RectangleInsets var1 = var0.getPadding();
    double var2 = var0.getWidth();
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.block.RectangleConstraint var6 = new org.jfree.chart.block.RectangleConstraint(0.0d, 0.0d);
    org.jfree.data.Range var7 = null;
    org.jfree.data.Range var9 = org.jfree.data.Range.expandToInclude(var7, (-1.0d));
    org.jfree.data.Range var10 = null;
    org.jfree.data.Range var12 = org.jfree.data.Range.expandToInclude(var10, (-1.0d));
    org.jfree.data.Range var13 = org.jfree.data.Range.combine(var9, var12);
    double var14 = var12.getUpperBound();
    org.jfree.chart.block.RectangleConstraint var15 = var6.toRangeHeight(var12);
    org.jfree.chart.util.Size2D var16 = var0.arrange(var3, var15);
    java.lang.String var17 = var16.toString();
    java.lang.String var18 = var16.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + "Size2D[width=0.0, height=-1.0]"+ "'", var17.equals("Size2D[width=0.0, height=-1.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + "Size2D[width=0.0, height=-1.0]"+ "'", var18.equals("Size2D[width=0.0, height=-1.0]"));

  }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var1 = var0.getPositiveItemLabelPositionFallback();
    java.awt.Paint var4 = var0.getItemLabelPaint((-123), (-1));
    org.jfree.data.category.CategoryDataset var5 = null;
    org.jfree.chart.axis.CategoryAxis var6 = null;
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var8 = null;
    var7.setPlot(var8);
    org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot(var5, var6, (org.jfree.chart.axis.ValueAxis)var7, var10);
    java.awt.Stroke var12 = var7.getTickMarkStroke();
    org.jfree.chart.LegendItemSource var13 = null;
    org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle(var13);
    org.jfree.chart.util.RectangleInsets var15 = var14.getItemLabelPadding();
    double var16 = var15.getTop();
    org.jfree.chart.block.LineBorder var17 = new org.jfree.chart.block.LineBorder(var4, var12, var15);
    java.awt.Paint var18 = var17.getPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = var0.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var5 = var0.getPositiveItemLabelPosition(100, 0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var6 = var0.getLegendItemToolTipGenerator();
    boolean var7 = var0.getAutoPopulateSeriesFillPaint();
    var0.setBaseCreateEntities(true, false);
    org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var12 = var11.getNextOutlinePaint();
    var0.setErrorIndicatorPaint(var12);
    org.jfree.chart.event.RendererChangeEvent var14 = null;
    var0.notifyListeners(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test468() {}
//   public void test468() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }
// 
// 
//     org.jfree.chart.LegendItemSource var0 = null;
//     org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
//     org.jfree.chart.util.RectangleEdge var2 = var1.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var3 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var4 = var3.getNextOutlinePaint();
//     var1.setBackgroundPaint(var4);
//     org.jfree.chart.text.TextBlock var6 = new org.jfree.chart.text.TextBlock();
//     java.util.List var7 = var6.getLines();
//     boolean var8 = var1.equals((java.lang.Object)var6);
//     org.jfree.chart.LegendItemSource var9 = null;
//     org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle(var9);
//     org.jfree.chart.util.RectangleEdge var11 = var10.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var12 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var13 = var12.getNextOutlinePaint();
//     var10.setBackgroundPaint(var13);
//     org.jfree.chart.util.HorizontalAlignment var15 = var10.getHorizontalAlignment();
//     org.jfree.chart.block.BlockContainer var16 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.LegendItemSource var17 = null;
//     org.jfree.chart.title.LegendTitle var18 = new org.jfree.chart.title.LegendTitle(var17);
//     org.jfree.chart.util.RectangleInsets var19 = var18.getItemLabelPadding();
//     double var20 = var19.getTop();
//     double var22 = var19.trimWidth(10.0d);
//     var16.setMargin(var19);
//     var10.setLegendItemGraphicPadding(var19);
//     double var26 = var19.extendWidth((-1.0d));
//     var1.setLegendItemGraphicPadding(var19);
//     
//     // Checks the contract:  equals-hashcode on var3 and var12
//     assertTrue("Contract failed: equals-hashcode on var3 and var12", var3.equals(var12) ? var3.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var3
//     assertTrue("Contract failed: equals-hashcode on var12 and var3", var12.equals(var3) ? var12.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }


    org.jfree.chart.plot.PlotRenderingInfo var0 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var1 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var0);
    double var2 = var1.getSeriesRunningTotal();
    double var3 = var1.getBarWidth();
    org.jfree.chart.entity.EntityCollection var4 = var1.getEntityCollection();
    org.jfree.chart.entity.EntityCollection var5 = var1.getEntityCollection();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test470() {}
//   public void test470() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("CategoryLabelWidthType.CATEGORY", var1, 1.0f, 1.0f, 0.0d, (-1.0f), 0.0f);
// 
//   }

  public void test471() {}
//   public void test471() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, 4);
// 
//   }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }


    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var7 = new org.jfree.chart.entity.ChartEntity(var5, "Range[-1.0,-1.0]");
    org.jfree.chart.renderer.category.StatisticalBarRenderer var8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var10 = null;
    var8.setSeriesItemLabelsVisible(0, var10, false);
    java.awt.Stroke var13 = var8.getErrorIndicatorStroke();
    java.awt.Paint var14 = null;
    org.jfree.chart.LegendItem var15 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var5, var13, var14);
    boolean var16 = var15.isLineVisible();
    var15.setSeriesKey((java.lang.Comparable)0L);
    boolean var19 = var15.isShapeVisible();
    boolean var20 = var15.isShapeVisible();
    java.awt.Paint var21 = var15.getLinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);

  }

  public void test473() {}
//   public void test473() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }
// 
// 
//     org.jfree.chart.util.StandardGradientPaintTransformer var0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     java.lang.Object var1 = var0.clone();
//     java.lang.Object var2 = var0.clone();
//     org.jfree.chart.LegendItemSource var3 = null;
//     org.jfree.chart.title.LegendTitle var4 = new org.jfree.chart.title.LegendTitle(var3);
//     org.jfree.chart.util.RectangleEdge var5 = var4.getLegendItemGraphicEdge();
//     java.awt.Paint var6 = var4.getItemPaint();
//     org.jfree.data.category.CategoryDataset var8 = null;
//     org.jfree.chart.axis.CategoryAxis var9 = null;
//     org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var11 = null;
//     var10.setPlot(var11);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var13 = null;
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot(var8, var9, (org.jfree.chart.axis.ValueAxis)var10, var13);
//     org.jfree.chart.LegendItemSource var15 = null;
//     org.jfree.chart.title.LegendTitle var16 = new org.jfree.chart.title.LegendTitle(var15);
//     org.jfree.chart.util.RectangleEdge var17 = var16.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var18 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var19 = var18.getNextOutlinePaint();
//     var16.setBackgroundPaint(var19);
//     var14.setOutlinePaint(var19);
//     org.jfree.chart.JFreeChart var22 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var14);
//     var22.fireChartChanged();
//     boolean var24 = var22.getAntiAlias();
//     java.util.List var25 = var22.getSubtitles();
//     var4.addChangeListener((org.jfree.chart.event.TitleChangeListener)var22);
//     org.jfree.data.category.CategoryDataset var27 = null;
//     org.jfree.chart.axis.CategoryAxis var28 = null;
//     org.jfree.chart.axis.NumberAxis var29 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var30 = null;
//     var29.setPlot(var30);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var32 = null;
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var27, var28, (org.jfree.chart.axis.ValueAxis)var29, var32);
//     var29.setAutoRangeMinimumSize(2.0d);
//     java.awt.geom.Rectangle2D var37 = null;
//     org.jfree.chart.util.RectangleEdge var38 = null;
//     double var39 = var29.java2DToValue(0.0d, var37, var38);
//     var29.setAutoTickUnitSelection(true);
//     java.awt.Stroke var42 = var29.getAxisLineStroke();
//     var22.setBorderStroke(var42);
//     var22.setTextAntiAlias(false);
//     org.jfree.chart.event.ChartChangeEvent var46 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0, var22);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.awt.image.BufferedImage var49 = var22.createBufferedImage(255, 0);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
// 
//   }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.util.EventListener var1 = null;
    boolean var2 = var0.hasListener(var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var5 = var0.getValue(100, 1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    var6.setAnchorValue(0.0d, true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var12 = null;
    var10.setSeriesItemLabelsVisible(0, var12, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var16 = null;
    var10.setSeriesToolTipGenerator(1, var16, false);
    org.jfree.chart.urls.CategoryURLGenerator var19 = null;
    var10.setBaseURLGenerator(var19);
    java.awt.Graphics2D var21 = null;
    org.jfree.chart.plot.CategoryPlot var22 = null;
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.plot.Marker var24 = null;
    java.awt.geom.Rectangle2D var25 = null;
    var10.drawRangeMarker(var21, var22, var23, var24, var25);
    boolean var28 = var10.isSeriesVisibleInLegend(0);
    var6.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    org.jfree.chart.axis.CategoryAxis var30 = null;
    java.util.List var31 = var6.getCategoriesForAxis(var30);
    java.awt.Paint var32 = var6.getNoDataMessagePaint();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var33 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.chart.renderer.category.CategoryItemRenderer var34 = var6.getRendererForDataset((org.jfree.data.category.CategoryDataset)var33);
    org.jfree.data.general.PieDataset var36 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var33, 255);
    org.jfree.data.general.DatasetGroup var37 = new org.jfree.data.general.DatasetGroup();
    java.lang.String var38 = var37.getID();
    var33.setGroup(var37);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var41 = var33.getRowKey((-123));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var38 + "' != '" + "NOID"+ "'", var38.equals("NOID"));

  }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(0.0f, (-1.0f), 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var4 = null;
    var3.setPlot(var4);
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var3, var6);
    org.jfree.chart.LegendItemSource var8 = null;
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
    org.jfree.chart.util.RectangleEdge var10 = var9.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var12 = var11.getNextOutlinePaint();
    var9.setBackgroundPaint(var12);
    var7.setOutlinePaint(var12);
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var7);
    var15.fireChartChanged();
    var15.setTextAntiAlias(false);
    java.util.List var19 = var15.getSubtitles();
    org.jfree.chart.util.RectangleInsets var20 = var15.getPadding();
    org.jfree.chart.plot.CategoryPlot var21 = var15.getCategoryPlot();
    java.awt.Shape var26 = null;
    org.jfree.chart.renderer.category.StatisticalBarRenderer var27 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var29 = null;
    var27.setSeriesItemLabelsVisible(0, var29, false);
    java.awt.Stroke var32 = var27.getErrorIndicatorStroke();
    org.jfree.chart.plot.DrawingSupplier var33 = var27.getDrawingSupplier();
    java.lang.Boolean var35 = var27.getSeriesCreateEntities(10);
    java.awt.Paint var36 = var27.getBaseOutlinePaint();
    java.lang.Object var38 = null;
    org.jfree.data.KeyedObject var39 = new org.jfree.data.KeyedObject((java.lang.Comparable)' ', var38);
    java.lang.Object var40 = var39.getObject();
    java.lang.Comparable var41 = var39.getKey();
    org.jfree.data.category.CategoryDataset var42 = null;
    org.jfree.chart.axis.CategoryAxis var43 = null;
    org.jfree.chart.axis.NumberAxis var44 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var45 = null;
    var44.setPlot(var45);
    org.jfree.chart.renderer.category.CategoryItemRenderer var47 = null;
    org.jfree.chart.plot.CategoryPlot var48 = new org.jfree.chart.plot.CategoryPlot(var42, var43, (org.jfree.chart.axis.ValueAxis)var44, var47);
    org.jfree.chart.LegendItemSource var49 = null;
    org.jfree.chart.title.LegendTitle var50 = new org.jfree.chart.title.LegendTitle(var49);
    org.jfree.chart.util.RectangleEdge var51 = var50.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var52 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var53 = var52.getNextOutlinePaint();
    var50.setBackgroundPaint(var53);
    var48.setOutlinePaint(var53);
    java.awt.Stroke var56 = var48.getRangeCrosshairStroke();
    boolean var57 = var39.equals((java.lang.Object)var56);
    java.awt.Color var62 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.0f);
    java.awt.Shape var68 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var70 = new org.jfree.chart.entity.ChartEntity(var68, "Range[-1.0,-1.0]");
    org.jfree.chart.renderer.category.StatisticalBarRenderer var71 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var73 = null;
    var71.setSeriesItemLabelsVisible(0, var73, false);
    java.awt.Stroke var76 = var71.getErrorIndicatorStroke();
    java.awt.Paint var77 = null;
    org.jfree.chart.LegendItem var78 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var68, var76, var77);
    org.jfree.chart.plot.ValueMarker var79 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint)var62, var76);
    int var80 = var62.getTransparency();
    org.jfree.chart.LegendItem var81 = new org.jfree.chart.LegendItem("SortOrder.ASCENDING", "SortOrder.ASCENDING", "HorizontalAlignment.CENTER", "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", var26, var36, var56, (java.awt.Paint)var62);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var15.setTextAntiAlias((java.lang.Object)var81);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var41 + "' != '" + ' '+ "'", var41.equals(' '));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == 1);

  }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    var6.setAnchorValue(0.0d, true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var12 = null;
    var10.setSeriesItemLabelsVisible(0, var12, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var16 = null;
    var10.setSeriesToolTipGenerator(1, var16, false);
    org.jfree.chart.urls.CategoryURLGenerator var19 = null;
    var10.setBaseURLGenerator(var19);
    java.awt.Graphics2D var21 = null;
    org.jfree.chart.plot.CategoryPlot var22 = null;
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.plot.Marker var24 = null;
    java.awt.geom.Rectangle2D var25 = null;
    var10.drawRangeMarker(var21, var22, var23, var24, var25);
    boolean var28 = var10.isSeriesVisibleInLegend(0);
    var6.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    org.jfree.chart.axis.CategoryAxis var30 = null;
    java.util.List var31 = var6.getCategoriesForAxis(var30);
    java.awt.Paint var32 = var6.getNoDataMessagePaint();
    org.jfree.data.general.DatasetChangeEvent var33 = null;
    var6.datasetChanged(var33);
    org.jfree.chart.event.AxisChangeEvent var35 = null;
    var6.axisChanged(var35);
    org.jfree.chart.axis.CategoryAxis var38 = var6.getDomainAxis(242);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);

  }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }


    int var3 = java.awt.Color.HSBtoRGB(0.95f, 0.95f, 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-621738));

  }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }


    java.awt.geom.Arc2D var0 = null;
    java.awt.geom.Arc2D var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }


    org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
    org.jfree.chart.LegendItemSource var2 = null;
    org.jfree.chart.title.LegendTitle var3 = new org.jfree.chart.title.LegendTitle(var2);
    org.jfree.chart.util.RectangleEdge var4 = var3.getLegendItemGraphicEdge();
    org.jfree.chart.util.RectangleEdge var5 = org.jfree.chart.util.RectangleEdge.opposite(var4);
    var0.ensureAtLeast(100.0d, var5);
    var0.setRight(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }


    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    java.lang.Object var2 = var1.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = null;
    var0.setSeriesItemLabelsVisible(0, var2, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var6 = null;
    var0.setSeriesToolTipGenerator(1, var6, false);
    org.jfree.chart.urls.CategoryURLGenerator var9 = null;
    var0.setBaseURLGenerator(var9);
    java.awt.Graphics2D var11 = null;
    org.jfree.chart.plot.CategoryPlot var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.plot.Marker var14 = null;
    java.awt.geom.Rectangle2D var15 = null;
    var0.drawRangeMarker(var11, var12, var13, var14, var15);
    boolean var18 = var0.isSeriesVisibleInLegend(0);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var19 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var21 = var19.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var24 = var19.getPositiveItemLabelPosition(100, 0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var25 = var19.getLegendItemToolTipGenerator();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var27 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    var19.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var27);
    var0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var27);
    java.lang.Object var30 = var27.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test484() {}
//   public void test484() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }
// 
// 
//     org.jfree.data.KeyedObjects2D var1 = new org.jfree.data.KeyedObjects2D();
//     java.util.List var2 = var1.getColumnKeys();
//     int var4 = var1.getRowIndex((java.lang.Comparable)100);
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
//     boolean var6 = var5.isNegativeArrowVisible();
//     java.lang.String var7 = var5.getLabelURL();
//     var5.setLabelAngle(6.0d);
//     var5.setAutoRange(false);
//     java.awt.Font var12 = var5.getTickLabelFont();
//     var1.setObject((java.lang.Object)var12, (java.lang.Comparable)"CategoryLabelEntity: category=null, tooltip=hi!, url=", (java.lang.Comparable)"CategoryLabelEntity: category=null, tooltip=hi!, url=");
//     org.jfree.data.category.CategoryDataset var16 = null;
//     org.jfree.chart.axis.CategoryAxis var17 = null;
//     org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var19 = null;
//     var18.setPlot(var19);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var21 = null;
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot(var16, var17, (org.jfree.chart.axis.ValueAxis)var18, var21);
//     java.awt.Stroke var23 = var18.getTickMarkStroke();
//     var18.zoomRange((-1.0d), 100.0d);
//     org.jfree.chart.block.BlockContainer var27 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.util.RectangleInsets var28 = var27.getPadding();
//     double var30 = var28.calculateTopInset(100.0d);
//     var18.setLabelInsets(var28);
//     java.awt.Paint var32 = var18.getTickMarkPaint();
//     java.awt.Paint var33 = var18.getAxisLinePaint();
//     java.awt.Graphics2D var36 = null;
//     org.jfree.chart.text.G2TextMeasurer var37 = new org.jfree.chart.text.G2TextMeasurer(var36);
//     org.jfree.chart.text.TextBlock var38 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", var12, var33, 10.0f, 100, (org.jfree.chart.text.TextMeasurer)var37);
// 
//   }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }


    org.jfree.chart.util.BooleanList var0 = new org.jfree.chart.util.BooleanList();
    var0.setBoolean(1, (java.lang.Boolean)false);
    var0.setBoolean(255, (java.lang.Boolean)false);

  }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }


    java.awt.Color var4 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.0f);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var12 = new org.jfree.chart.entity.ChartEntity(var10, "Range[-1.0,-1.0]");
    org.jfree.chart.renderer.category.StatisticalBarRenderer var13 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var15 = null;
    var13.setSeriesItemLabelsVisible(0, var15, false);
    java.awt.Stroke var18 = var13.getErrorIndicatorStroke();
    java.awt.Paint var19 = null;
    org.jfree.chart.LegendItem var20 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var10, var18, var19);
    org.jfree.chart.plot.ValueMarker var21 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint)var4, var18);
    org.jfree.chart.text.TextAnchor var22 = var21.getLabelTextAnchor();
    java.lang.String var23 = var21.getLabel();
    java.awt.Paint var24 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var21.setPaint(var24);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);

  }

  public void test487() {}
//   public void test487() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }
// 
// 
//     org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();
//     java.util.List var1 = var0.getLines();
//     org.jfree.chart.text.TextLine var2 = null;
//     var0.addLine(var2);
//     java.awt.Graphics2D var4 = null;
//     org.jfree.chart.util.Size2D var5 = var0.calculateDimensions(var4);
// 
//   }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }


    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var7 = new org.jfree.chart.entity.ChartEntity(var5, "Range[-1.0,-1.0]");
    org.jfree.chart.renderer.category.StatisticalBarRenderer var8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var10 = null;
    var8.setSeriesItemLabelsVisible(0, var10, false);
    java.awt.Stroke var13 = var8.getErrorIndicatorStroke();
    java.awt.Paint var14 = null;
    org.jfree.chart.LegendItem var15 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var5, var13, var14);
    java.awt.Shape var16 = var15.getShape();
    org.jfree.data.general.Dataset var17 = null;
    var15.setDataset(var17);
    int var19 = var15.getDatasetIndex();
    boolean var20 = var15.isLineVisible();
    var15.setDatasetIndex((-855310));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);

  }

  public void test489() {}
//   public void test489() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var4 = null;
//     var3.setPlot(var4);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var3, var6);
//     org.jfree.chart.LegendItemSource var8 = null;
//     org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
//     org.jfree.chart.util.RectangleEdge var10 = var9.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var12 = var11.getNextOutlinePaint();
//     var9.setBackgroundPaint(var12);
//     var7.setOutlinePaint(var12);
//     org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var7);
//     org.jfree.chart.util.RectangleInsets var16 = var7.getAxisOffset();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var17 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var19 = null;
//     var17.setSeriesItemLabelsVisible(0, var19, false);
//     java.awt.Stroke var22 = var17.getErrorIndicatorStroke();
//     org.jfree.chart.plot.DrawingSupplier var23 = var17.getDrawingSupplier();
//     java.lang.Boolean var25 = var17.getSeriesCreateEntities(10);
//     java.awt.Paint var26 = var17.getBaseOutlinePaint();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var28 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var30 = var28.getSeriesItemLabelsVisible(100);
//     org.jfree.chart.labels.ItemLabelPosition var33 = var28.getPositiveItemLabelPosition(100, 0);
//     org.jfree.chart.urls.CategoryURLGenerator var34 = var28.getBaseURLGenerator();
//     java.lang.Boolean var36 = var28.getSeriesItemLabelsVisible((-855310));
//     java.awt.Color var39 = java.awt.Color.getColor("", (-1));
//     var28.setBasePaint((java.awt.Paint)var39, true);
//     var17.setSeriesPaint(0, (java.awt.Paint)var39, false);
//     int var44 = var39.getBlue();
//     org.jfree.chart.block.BlockBorder var45 = new org.jfree.chart.block.BlockBorder(var16, (java.awt.Paint)var39);
//     java.awt.Graphics2D var46 = null;
//     org.jfree.data.category.CategoryDataset var47 = null;
//     org.jfree.chart.axis.CategoryAxis var48 = null;
//     org.jfree.chart.axis.NumberAxis var49 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var50 = null;
//     var49.setPlot(var50);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var52 = null;
//     org.jfree.chart.plot.CategoryPlot var53 = new org.jfree.chart.plot.CategoryPlot(var47, var48, (org.jfree.chart.axis.ValueAxis)var49, var52);
//     var49.setAutoRangeMinimumSize(2.0d);
//     java.awt.geom.Rectangle2D var57 = null;
//     org.jfree.chart.util.RectangleEdge var58 = null;
//     double var59 = var49.java2DToValue(0.0d, var57, var58);
//     var49.setAutoTickUnitSelection(true);
//     var49.setUpperMargin(0.0d);
//     org.jfree.chart.LegendItemSource var64 = null;
//     org.jfree.chart.title.LegendTitle var65 = new org.jfree.chart.title.LegendTitle(var64);
//     org.jfree.chart.util.RectangleInsets var66 = var65.getItemLabelPadding();
//     org.jfree.chart.util.VerticalAlignment var67 = var65.getVerticalAlignment();
//     org.jfree.chart.block.BlockContainer var68 = var65.getItemContainer();
//     org.jfree.chart.LegendItemSource var69 = null;
//     org.jfree.chart.title.LegendTitle var70 = new org.jfree.chart.title.LegendTitle(var69);
//     org.jfree.chart.util.RectangleInsets var71 = var70.getItemLabelPadding();
//     double var73 = var71.calculateTopOutset(4.0d);
//     var68.setMargin(var71);
//     java.awt.geom.Rectangle2D var75 = var68.getBounds();
//     org.jfree.chart.LegendItemSource var76 = null;
//     org.jfree.chart.title.LegendTitle var77 = new org.jfree.chart.title.LegendTitle(var76);
//     org.jfree.chart.util.RectangleInsets var78 = var77.getItemLabelPadding();
//     org.jfree.chart.util.RectangleAnchor var79 = var77.getLegendItemGraphicLocation();
//     java.awt.geom.Point2D var80 = org.jfree.chart.util.RectangleAnchor.coordinates(var75, var79);
//     var49.setDownArrow((java.awt.Shape)var75);
//     var45.draw(var46, var75);
// 
//   }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    org.jfree.chart.LegendItemSource var7 = null;
    org.jfree.chart.title.LegendTitle var8 = new org.jfree.chart.title.LegendTitle(var7);
    org.jfree.chart.util.RectangleEdge var9 = var8.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var10 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var11 = var10.getNextOutlinePaint();
    var8.setBackgroundPaint(var11);
    var6.setOutlinePaint(var11);
    org.jfree.data.category.CategoryDataset var14 = null;
    org.jfree.chart.axis.CategoryAxis var15 = null;
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var17 = null;
    var16.setPlot(var17);
    org.jfree.chart.renderer.category.CategoryItemRenderer var19 = null;
    org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot(var14, var15, (org.jfree.chart.axis.ValueAxis)var16, var19);
    org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var22 = null;
    var21.setPlot(var22);
    org.jfree.chart.axis.ValueAxis[] var24 = new org.jfree.chart.axis.ValueAxis[] { var21};
    var20.setRangeAxes(var24);
    var6.setParent((org.jfree.chart.plot.Plot)var20);
    var20.setRangeCrosshairValue(10.0d, false);
    boolean var30 = var20.getDrawSharedDomainAxis();
    org.jfree.chart.block.BlockContainer var31 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.util.RectangleInsets var32 = var31.getPadding();
    double var34 = var32.calculateTopInset(100.0d);
    double var36 = var32.calculateTopInset(1.0d);
    var20.setInsets(var32, false);
    org.jfree.chart.annotations.CategoryAnnotation var39 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var40 = var20.removeAnnotation(var39);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);

  }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.5f, 0.5f);
    org.jfree.chart.entity.TickLabelEntity var5 = new org.jfree.chart.entity.TickLabelEntity(var2, "0", "SortOrder.ASCENDING");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var3 = null;
    var2.setPlot(var3);
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var5);
    java.awt.Stroke var7 = var2.getTickMarkStroke();
    var2.zoomRange((-1.0d), 100.0d);
    org.jfree.chart.block.BlockContainer var11 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.util.RectangleInsets var12 = var11.getPadding();
    double var14 = var12.calculateTopInset(100.0d);
    var2.setLabelInsets(var12);
    java.awt.Color var19 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.0f);
    var2.setTickLabelPaint((java.awt.Paint)var19);
    var2.centerRange((-0.55d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test493() {}
//   public void test493() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }
// 
// 
//     org.jfree.chart.labels.ItemLabelPosition var0 = new org.jfree.chart.labels.ItemLabelPosition();
//     org.jfree.chart.LegendItemSource var1 = null;
//     org.jfree.chart.title.LegendTitle var2 = new org.jfree.chart.title.LegendTitle(var1);
//     org.jfree.chart.util.RectangleEdge var3 = var2.getLegendItemGraphicEdge();
//     org.jfree.chart.util.RectangleEdge var4 = org.jfree.chart.util.RectangleEdge.opposite(var3);
//     boolean var5 = var0.equals((java.lang.Object)var4);
//     org.jfree.chart.labels.ItemLabelAnchor var6 = var0.getItemLabelAnchor();
//     org.jfree.chart.axis.CategoryLabelPositions var7 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var8 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var9 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var7, var8);
//     org.jfree.chart.text.TextAnchor var10 = var8.getRotationAnchor();
//     org.jfree.chart.labels.ItemLabelPosition var11 = new org.jfree.chart.labels.ItemLabelPosition(var6, var10);
//     org.jfree.chart.plot.DefaultDrawingSupplier var12 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     boolean var14 = var12.equals((java.lang.Object)(short)10);
//     java.awt.Paint var15 = var12.getNextFillPaint();
//     java.awt.Paint var16 = var12.getNextPaint();
//     java.awt.Shape var17 = var12.getNextShape();
//     boolean var18 = var6.equals((java.lang.Object)var12);
//     org.jfree.chart.text.TextBlock var20 = new org.jfree.chart.text.TextBlock();
//     java.util.List var21 = var20.getLines();
//     org.jfree.chart.text.TextLine var22 = null;
//     var20.addLine(var22);
//     org.jfree.chart.util.HorizontalAlignment var24 = var20.getLineAlignment();
//     org.jfree.chart.text.TextBlockAnchor var25 = null;
//     java.awt.Graphics2D var27 = null;
//     org.jfree.chart.labels.ItemLabelPosition var30 = new org.jfree.chart.labels.ItemLabelPosition();
//     org.jfree.chart.LegendItemSource var31 = null;
//     org.jfree.chart.title.LegendTitle var32 = new org.jfree.chart.title.LegendTitle(var31);
//     org.jfree.chart.util.RectangleEdge var33 = var32.getLegendItemGraphicEdge();
//     org.jfree.chart.util.RectangleEdge var34 = org.jfree.chart.util.RectangleEdge.opposite(var33);
//     boolean var35 = var30.equals((java.lang.Object)var34);
//     org.jfree.chart.labels.ItemLabelAnchor var36 = var30.getItemLabelAnchor();
//     org.jfree.chart.axis.CategoryLabelPositions var37 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var38 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var39 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var37, var38);
//     org.jfree.chart.text.TextAnchor var40 = var38.getRotationAnchor();
//     org.jfree.chart.labels.ItemLabelPosition var41 = new org.jfree.chart.labels.ItemLabelPosition(var36, var40);
//     org.jfree.chart.text.TextUtilities.drawRotatedString("", var27, 1.0f, (-1.0f), var40, 2.0d, 1.0f, 0.0f);
//     org.jfree.chart.axis.CategoryTick var47 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)(byte)0, var20, var25, var40, 0.0d);
//     java.lang.String var48 = var47.getText();
//     org.jfree.chart.text.TextAnchor var49 = var47.getTextAnchor();
//     org.jfree.chart.text.TextBlock var51 = new org.jfree.chart.text.TextBlock();
//     java.util.List var52 = var51.getLines();
//     org.jfree.chart.text.TextLine var53 = null;
//     var51.addLine(var53);
//     org.jfree.chart.util.HorizontalAlignment var55 = var51.getLineAlignment();
//     org.jfree.chart.text.TextBlockAnchor var56 = null;
//     java.awt.Graphics2D var58 = null;
//     org.jfree.chart.labels.ItemLabelPosition var61 = new org.jfree.chart.labels.ItemLabelPosition();
//     org.jfree.chart.LegendItemSource var62 = null;
//     org.jfree.chart.title.LegendTitle var63 = new org.jfree.chart.title.LegendTitle(var62);
//     org.jfree.chart.util.RectangleEdge var64 = var63.getLegendItemGraphicEdge();
//     org.jfree.chart.util.RectangleEdge var65 = org.jfree.chart.util.RectangleEdge.opposite(var64);
//     boolean var66 = var61.equals((java.lang.Object)var65);
//     org.jfree.chart.labels.ItemLabelAnchor var67 = var61.getItemLabelAnchor();
//     org.jfree.chart.axis.CategoryLabelPositions var68 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var69 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var70 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var68, var69);
//     org.jfree.chart.text.TextAnchor var71 = var69.getRotationAnchor();
//     org.jfree.chart.labels.ItemLabelPosition var72 = new org.jfree.chart.labels.ItemLabelPosition(var67, var71);
//     org.jfree.chart.text.TextUtilities.drawRotatedString("", var58, 1.0f, (-1.0f), var71, 2.0d, 1.0f, 0.0f);
//     org.jfree.chart.axis.CategoryTick var78 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)(byte)0, var51, var56, var71, 0.0d);
//     java.lang.String var79 = var78.getText();
//     org.jfree.chart.text.TextAnchor var80 = var78.getTextAnchor();
//     org.jfree.chart.labels.ItemLabelPosition var82 = new org.jfree.chart.labels.ItemLabelPosition(var6, var49, var80, 6.0d);
//     
//     // Checks the contract:  equals-hashcode on var0 and var30
//     assertTrue("Contract failed: equals-hashcode on var0 and var30", var0.equals(var30) ? var0.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var0 and var61
//     assertTrue("Contract failed: equals-hashcode on var0 and var61", var0.equals(var61) ? var0.hashCode() == var61.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var41
//     assertTrue("Contract failed: equals-hashcode on var11 and var41", var11.equals(var41) ? var11.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var72
//     assertTrue("Contract failed: equals-hashcode on var11 and var72", var11.equals(var72) ? var11.hashCode() == var72.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var0
//     assertTrue("Contract failed: equals-hashcode on var30 and var0", var30.equals(var0) ? var30.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var61
//     assertTrue("Contract failed: equals-hashcode on var30 and var61", var30.equals(var61) ? var30.hashCode() == var61.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var11
//     assertTrue("Contract failed: equals-hashcode on var41 and var11", var41.equals(var11) ? var41.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var72
//     assertTrue("Contract failed: equals-hashcode on var41 and var72", var41.equals(var72) ? var41.hashCode() == var72.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var61 and var0
//     assertTrue("Contract failed: equals-hashcode on var61 and var0", var61.equals(var0) ? var61.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var61 and var30
//     assertTrue("Contract failed: equals-hashcode on var61 and var30", var61.equals(var30) ? var61.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var72 and var11
//     assertTrue("Contract failed: equals-hashcode on var72 and var11", var72.equals(var11) ? var72.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var72 and var41
//     assertTrue("Contract failed: equals-hashcode on var72 and var41", var72.equals(var41) ? var72.hashCode() == var41.hashCode() : true);
// 
//   }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var4 = null;
    var3.setPlot(var4);
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var3, var6);
    org.jfree.chart.LegendItemSource var8 = null;
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
    org.jfree.chart.util.RectangleEdge var10 = var9.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var12 = var11.getNextOutlinePaint();
    var9.setBackgroundPaint(var12);
    var7.setOutlinePaint(var12);
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var7);
    var15.fireChartChanged();
    org.jfree.chart.plot.CategoryPlot var17 = var15.getCategoryPlot();
    org.jfree.chart.title.TextTitle var18 = null;
    var15.setTitle(var18);
    var15.setAntiAlias(false);
    org.jfree.chart.ChartRenderingInfo var26 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var27 = var15.createBufferedImage((-1), (-855310), 0.0d, 0.2d, var26);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.util.RectangleInsets var1 = var0.getPadding();
    double var3 = var1.calculateBottomOutset(6.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);

  }

  public void test496() {}
//   public void test496() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var2 = null;
//     var0.setSeriesItemLabelsVisible(0, var2, false);
//     org.jfree.chart.labels.CategoryToolTipGenerator var6 = null;
//     var0.setSeriesToolTipGenerator(1, var6, false);
//     org.jfree.chart.urls.CategoryURLGenerator var9 = null;
//     var0.setBaseURLGenerator(var9);
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.plot.CategoryPlot var12 = null;
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     org.jfree.chart.plot.Marker var14 = null;
//     java.awt.geom.Rectangle2D var15 = null;
//     var0.drawRangeMarker(var11, var12, var13, var14, var15);
//     org.jfree.data.category.CategoryDataset var18 = null;
//     org.jfree.chart.axis.CategoryAxis var19 = null;
//     org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var21 = null;
//     var20.setPlot(var21);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var23 = null;
//     org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot(var18, var19, (org.jfree.chart.axis.ValueAxis)var20, var23);
//     org.jfree.chart.LegendItemSource var25 = null;
//     org.jfree.chart.title.LegendTitle var26 = new org.jfree.chart.title.LegendTitle(var25);
//     org.jfree.chart.util.RectangleEdge var27 = var26.getLegendItemGraphicEdge();
//     org.jfree.chart.plot.DefaultDrawingSupplier var28 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Paint var29 = var28.getNextOutlinePaint();
//     var26.setBackgroundPaint(var29);
//     var24.setOutlinePaint(var29);
//     org.jfree.data.category.CategoryDataset var32 = null;
//     org.jfree.chart.axis.CategoryAxis var33 = null;
//     org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var35 = null;
//     var34.setPlot(var35);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var37 = null;
//     org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot(var32, var33, (org.jfree.chart.axis.ValueAxis)var34, var37);
//     org.jfree.chart.axis.NumberAxis var39 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var40 = null;
//     var39.setPlot(var40);
//     org.jfree.chart.axis.ValueAxis[] var42 = new org.jfree.chart.axis.ValueAxis[] { var39};
//     var38.setRangeAxes(var42);
//     var24.setParent((org.jfree.chart.plot.Plot)var38);
//     var38.setRangeCrosshairValue(10.0d, false);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var48 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var49 = var48.getPositiveItemLabelPositionFallback();
//     java.awt.Paint var52 = var48.getItemLabelPaint((-123), (-1));
//     org.jfree.data.category.CategoryDataset var53 = null;
//     org.jfree.chart.axis.CategoryAxis var54 = null;
//     org.jfree.chart.axis.NumberAxis var55 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.Plot var56 = null;
//     var55.setPlot(var56);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var58 = null;
//     org.jfree.chart.plot.CategoryPlot var59 = new org.jfree.chart.plot.CategoryPlot(var53, var54, (org.jfree.chart.axis.ValueAxis)var55, var58);
//     java.awt.Stroke var60 = var55.getTickMarkStroke();
//     org.jfree.chart.LegendItemSource var61 = null;
//     org.jfree.chart.title.LegendTitle var62 = new org.jfree.chart.title.LegendTitle(var61);
//     org.jfree.chart.util.RectangleInsets var63 = var62.getItemLabelPadding();
//     double var64 = var63.getTop();
//     org.jfree.chart.block.LineBorder var65 = new org.jfree.chart.block.LineBorder(var52, var60, var63);
//     java.awt.Stroke var66 = var65.getStroke();
//     java.awt.Stroke var67 = var65.getStroke();
//     var38.setOutlineStroke(var67);
//     java.awt.Stroke var69 = var38.getRangeCrosshairStroke();
//     var0.setSeriesOutlineStroke(0, var69);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var48 and var0.", var48.equals(var0) == var0.equals(var48));
// 
//   }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var4 = null;
    var3.setPlot(var4);
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var3, var6);
    org.jfree.chart.LegendItemSource var8 = null;
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
    org.jfree.chart.util.RectangleEdge var10 = var9.getLegendItemGraphicEdge();
    org.jfree.chart.plot.DefaultDrawingSupplier var11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var12 = var11.getNextOutlinePaint();
    var9.setBackgroundPaint(var12);
    var7.setOutlinePaint(var12);
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var7);
    var15.fireChartChanged();
    var15.setTextAntiAlias(false);
    java.util.List var19 = var15.getSubtitles();
    org.jfree.chart.util.RectangleInsets var20 = var15.getPadding();
    org.jfree.chart.plot.CategoryPlot var21 = var15.getCategoryPlot();
    java.awt.Color var26 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.0f);
    java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var34 = new org.jfree.chart.entity.ChartEntity(var32, "Range[-1.0,-1.0]");
    org.jfree.chart.renderer.category.StatisticalBarRenderer var35 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var37 = null;
    var35.setSeriesItemLabelsVisible(0, var37, false);
    java.awt.Stroke var40 = var35.getErrorIndicatorStroke();
    java.awt.Paint var41 = null;
    org.jfree.chart.LegendItem var42 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var32, var40, var41);
    org.jfree.chart.plot.ValueMarker var43 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint)var26, var40);
    org.jfree.chart.text.TextAnchor var44 = var43.getLabelTextAnchor();
    org.jfree.chart.event.MarkerChangeEvent var45 = null;
    var43.notifyListeners(var45);
    org.jfree.data.category.CategoryDataset var47 = null;
    org.jfree.chart.axis.CategoryAxis var48 = null;
    org.jfree.chart.axis.NumberAxis var49 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.Plot var50 = null;
    var49.setPlot(var50);
    org.jfree.chart.renderer.category.CategoryItemRenderer var52 = null;
    org.jfree.chart.plot.CategoryPlot var53 = new org.jfree.chart.plot.CategoryPlot(var47, var48, (org.jfree.chart.axis.ValueAxis)var49, var52);
    var53.setAnchorValue(0.0d, true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var57 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var59 = null;
    var57.setSeriesItemLabelsVisible(0, var59, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var63 = null;
    var57.setSeriesToolTipGenerator(1, var63, false);
    org.jfree.chart.urls.CategoryURLGenerator var66 = null;
    var57.setBaseURLGenerator(var66);
    java.awt.Graphics2D var68 = null;
    org.jfree.chart.plot.CategoryPlot var69 = null;
    org.jfree.chart.axis.ValueAxis var70 = null;
    org.jfree.chart.plot.Marker var71 = null;
    java.awt.geom.Rectangle2D var72 = null;
    var57.drawRangeMarker(var68, var69, var70, var71, var72);
    boolean var75 = var57.isSeriesVisibleInLegend(0);
    var53.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var57);
    org.jfree.chart.axis.CategoryAxis var77 = null;
    java.util.List var78 = var53.getCategoriesForAxis(var77);
    var43.removeChangeListener((org.jfree.chart.event.MarkerChangeListener)var53);
    var21.addRangeMarker((org.jfree.chart.plot.Marker)var43);
    org.jfree.chart.util.RectangleInsets var81 = var43.getLabelOffset();
    org.jfree.chart.util.LengthAdjustmentType var82 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var43.setLabelOffsetType(var82);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);

  }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = null;
    var0.setSeriesItemLabelsVisible(0, var2, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var6 = null;
    var0.setSeriesToolTipGenerator(1, var6, false);
    org.jfree.chart.urls.CategoryURLGenerator var9 = null;
    var0.setBaseURLGenerator(var9);
    java.awt.Graphics2D var11 = null;
    org.jfree.chart.plot.CategoryPlot var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.plot.Marker var14 = null;
    java.awt.geom.Rectangle2D var15 = null;
    var0.drawRangeMarker(var11, var12, var13, var14, var15);
    boolean var18 = var0.isSeriesVisibleInLegend(0);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var19 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.chart.axis.NumberTickUnit var24 = new org.jfree.chart.axis.NumberTickUnit(1.0E-8d);
    var19.add((java.lang.Number)(-1.0d), (java.lang.Number)(-855310), (java.lang.Comparable)0.05d, (java.lang.Comparable)1.0E-8d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var26 = var0.findRangeBounds((org.jfree.data.category.CategoryDataset)var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);

  }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }


    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    org.jfree.chart.block.BlockContainer var2 = new org.jfree.chart.block.BlockContainer();
    boolean var3 = var1.equals((java.lang.Object)var2);
    double var4 = var2.getWidth();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);

  }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = var0.getSeriesItemLabelsVisible(100);
    org.jfree.chart.labels.ItemLabelPosition var5 = var0.getPositiveItemLabelPosition(100, 0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var6 = var0.getLegendItemToolTipGenerator();
    var0.setItemLabelAnchorOffset(100.0d);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.entity.ChartEntity var16 = new org.jfree.chart.entity.ChartEntity(var14, "Range[-1.0,-1.0]");
    org.jfree.chart.renderer.category.StatisticalBarRenderer var17 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var19 = null;
    var17.setSeriesItemLabelsVisible(0, var19, false);
    java.awt.Stroke var22 = var17.getErrorIndicatorStroke();
    java.awt.Paint var23 = null;
    org.jfree.chart.LegendItem var24 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var14, var22, var23);
    boolean var25 = var24.isLineVisible();
    org.jfree.chart.util.StandardGradientPaintTransformer var26 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    java.lang.Object var27 = var26.clone();
    java.lang.Object var28 = var26.clone();
    var24.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var26);
    var0.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var26);
    java.lang.Boolean var32 = var0.getSeriesVisibleInLegend((-855310));
    java.awt.Paint var35 = var0.getItemOutlinePaint((-1), 0);
    double var36 = var0.getMaximumBarWidth();
    org.jfree.chart.urls.CategoryURLGenerator var38 = null;
    var0.setSeriesURLGenerator(242, var38, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 1.0d);

  }

}
