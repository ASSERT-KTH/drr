
import junit.framework.*;

public class RandoopTest1 extends TestCase {

  public static boolean debug = false;

  public void test1() {}
//   public void test1() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test1"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(1.322456124528837d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test2"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    int var4 = var1.nextZipf(100, 10.0d);
    var1.reSeedSecure((-1L));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var9 = var1.nextGaussian((-2.1805166473703887d), 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test3"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    int var4 = var3.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = var3.copy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setContractionCriteria(0.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test4() {}
//   public void test4() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test4"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
//     java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
//     java.math.BigInteger var5 = null;
//     java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 0L);
//     java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, var5);
// 
//   }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test5"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil((-0.21452323545111215d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.0d));

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test6"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(7, 1399408473);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test7"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(10, 10.0f);

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test8"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(15, 9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 15);

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test9"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(0.9254962739500686d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.8439600399218803d);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test10"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var3.setElement(3, (-0.7853981633974483d));
    int var7 = var3.getNumElements();
    double var9 = var3.substituteMostRecentElement((-0.7853981633974483d));
    float var10 = var3.getExpansionFactor();
    var3.contract();
    int var12 = var3.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-0.7853981633974483d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test11"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var3.setElement(3, (-0.7853981633974483d));
    var3.contract();
    var3.contract();
    double[] var11 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var11);
    double var14 = var12.getElement(0);
    var12.addElement(0.5403023058681398d);
    var12.discardFrontElements(0);
    double[] var19 = var12.getInternalValues();
    var3.addElements(var19);
    int var21 = var3.getNumElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 8);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test12"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    java.lang.String var3 = var1.toString();
    java.lang.String var4 = var1.name();
    org.apache.commons.math3.distribution.NormalDistribution var8 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var11 = var8.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var12 = var8.getNumericalMean();
    double[] var14 = var8.sample(15);
    boolean var15 = var8.isSupportLowerBoundInclusive();
    boolean var16 = var1.equals((java.lang.Object)var8);
    boolean var18 = var1.equals((java.lang.Object)0.9152952197546206d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "AVERAGE"+ "'", var3.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "AVERAGE"+ "'", var4.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test13() {}
//   public void test13() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test13"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy var1 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var3 = var2.getTiesStrategy();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var3);
//     java.lang.String var5 = var3.name();
//     java.lang.Class var6 = var3.getDeclaringClass();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var7 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var3);
//     org.apache.commons.math3.distribution.NormalDistribution var11 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
//     double var14 = var11.cumulativeProbability(0.0d, 0.1690925369322372d);
//     double var15 = var11.getNumericalMean();
//     double[] var17 = var11.sample(1);
//     double var19 = var11.density(979.3393873505228d);
//     double[] var21 = var11.sample(2);
//     double[] var24 = new double[] { 0.0d, 100.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var25 = new org.apache.commons.math3.util.ResizableDoubleArray(var24);
//     double[] var26 = var25.getElements();
//     double[] var27 = var25.getInternalValues();
//     double var28 = var7.mannWhitneyU(var21, var27);
// 
//   }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test14"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(4.1972216218988037E-35d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test15() {}
//   public void test15() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test15"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(3.1780538303479458d);
//     double var5 = var1.nextExponential(19.39006869589386d);
//     double var8 = var1.nextBeta(4.499378297809863d, 1.8328655053227587d);
//     int[] var11 = var1.nextPermutation(10000, 10000);
//     double var13 = var1.nextChiSquare(10.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var1.nextChiSquare((-0.15278468894698005d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.578220490227376d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 11.576705576424832d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.6832159203222692d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 5.658916064257967d);
// 
//   }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test16"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(9.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 8103.083927575384d);

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test17"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getNumericalMean();
    double[] var9 = var3.sample(1);
    double var11 = var3.density(979.3393873505228d);
    double var13 = var3.density(3921225.0d);
    boolean var14 = var3.isSupportLowerBoundInclusive();
    double[] var16 = var3.sample(4);
    boolean var17 = var3.isSupportLowerBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test18"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians((-2.3306405007995967d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.0406773504192825d));

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test19"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(10.000001f, (-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10.000001f);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test20"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd((-3L), 5040L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3L);

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test21"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var3.setElement(3, (-0.7853981633974483d));
    int var7 = var3.getNumElements();
    var3.setNumElements(4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 4);

  }

  public void test22() {}
//   public void test22() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test22"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.sqrt((-0.07474017391621185d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test23"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var5 = var3.getElement(0);
    int var6 = var3.start();
    int var7 = var3.getExpansionMode();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setExpansionFactor(10.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test24"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)1.893344644644389d);

  }

  public void test25() {}
//   public void test25() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test25"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(7.589578294334879d, (-0.4402198698105254d), 0.649680406496415d, 17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test26"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(5, 9.536743E-7f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test27() {}
//   public void test27() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test27"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(3.1780538303479458d);
//     double var6 = var1.nextUniform((-2.1805166473703887d), 5.26885534061425E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 9.281695778419678d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1.3173720911599616d));
// 
//   }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test28"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.025185327490526228d, (java.lang.Number)2, (java.lang.Number)0.452360517355225d);

  }

  public void test29() {}
//   public void test29() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test29"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)100.0d, (java.lang.Number)(-2.1805166473703887d), true);
//     java.lang.Number var5 = var4.getArgument();
//     org.apache.commons.math3.exception.MathInternalError var6 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var4);
// 
//   }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test30"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.5403023058681398d, 0.5403023058681399d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.7641028487401796d);

  }

  public void test31() {}
//   public void test31() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test31"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(3.1780538303479458d);
//     double var5 = var1.nextExponential(19.39006869589386d);
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var1.nextUniform(0.0d, (-0.48741290436643614d), false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2.5162836790741103d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.0400512828858173d);
// 
//   }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test32"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(1.5707963267948966d, 979.3393873505228d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.02632107492174142d);

  }

  public void test33() {}
//   public void test33() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test33"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextWeibull(1.6815545646570225d, 0.037062153555774406d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var8 = var1.nextUniform(6.658240041118693E-4d, (-0.9444050156042171d), false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.06059384077480105d);
// 
//   }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test34"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(7.198232315471589E-18d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.198232315471589E-18d);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test35"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(1.0f, 1.6873352971776172d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0000001f);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test36"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var5 = var3.getElement(0);
    int var6 = var3.getNumElements();
    int var7 = var3.getExpansionMode();
    var3.contract();
    var3.addElement((-8.541939077859835d));
    boolean var12 = var3.equals((java.lang.Object)0.7105235543492688d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test37"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-1.777309158100993d), (java.lang.Number)10000, false);

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test38"); }


    double var2 = org.apache.commons.math3.special.Erf.erf((-0.49035942660728515d), 71.34241022211371d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.5119872053626813d);

  }

  public void test39() {}
//   public void test39() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test39"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(3.1780538303479458d);
//     double var5 = var1.nextExponential(19.39006869589386d);
//     double var8 = var1.nextBeta(4.499378297809863d, 1.8328655053227587d);
//     double var11 = var1.nextGamma(968.8343073325332d, (-20.34054861465728d));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var1.nextChiSquare((-0.0d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 5.3332699051693915d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 14.368216079036026d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.8452269095000841d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-21672.042499281273d));
// 
//   }

  public void test40() {}
//   public void test40() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test40"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.649680406496415d, Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test41"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setContractionCriteria(0.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test42"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(4, 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test43"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs((-0.7333114255659123d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7333114255659123d);

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test44"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(-0.7853981633974483d), (java.lang.Number)1, true);
    java.lang.Number var5 = var4.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1+ "'", var5.equals(1));

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test45"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)10.0d, (java.lang.Number)1L, (java.lang.Number)1);
    java.lang.Number var5 = var4.getHi();
    org.apache.commons.math3.exception.NumberIsTooLargeException var9 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10.0d, (java.lang.Number)1.0f, true);
    java.lang.Number var10 = var9.getMax();
    var4.addSuppressed((java.lang.Throwable)var9);
    java.lang.Number var12 = var4.getLo();
    java.lang.Number var13 = var4.getArgument();
    java.lang.Throwable[] var14 = var4.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1+ "'", var5.equals(1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + 1.0f+ "'", var10.equals(1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 1L+ "'", var12.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + 10.0d+ "'", var13.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test46"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var3 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var2);
    java.lang.String var4 = var2.name();
    java.lang.Class var5 = var2.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var7 = java.lang.Enum.<java.lang.Enum>valueOf(var5, "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "AVERAGE"+ "'", var4.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test47() {}
//   public void test47() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test47"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(1.7453292519943295d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test48"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(2.47859452775542d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1873155246411504d);

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test49"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var5 = var3.getElement(0);
    double[] var6 = var3.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = var3.copy();
    double var9 = var3.addElementRolling(122.7902212423532d);
    double[] var12 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray(var12);
    var13.setElement(3, (-0.7853981633974483d));
    int var17 = var13.getNumElements();
    double var19 = var13.substituteMostRecentElement((-0.7853981633974483d));
    float var20 = var13.getExpansionFactor();
    double var22 = var13.getElement(0);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var3, var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == (-0.7853981633974483d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test50"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)0.5866841190102328d, true);

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test51"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-2.0832984452539125d), (java.lang.Number)9.536743E-7f, false);
    boolean var4 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test52() {}
//   public void test52() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test52"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh((-1.3173720911599616d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test53"); }


    double var1 = org.apache.commons.math3.special.Gamma.logGamma(2.70805020110221d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.44124929225463694d);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test54"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(1);
    var1.setElement(0, (-0.9880458431278127d));
    var1.setExpansionFactor(2.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setExpansionMode(10);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test55"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var5 = var3.cumulativeProbability(0.5513122819358196d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);

  }

  public void test56() {}
//   public void test56() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test56"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     double var7 = var1.nextCauchy(0.15560730683937996d, 3.1780538303479458d);
//     long var9 = var1.nextPoisson(1.5707963267948966d);
//     var1.reSeed(101L);
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution(979.3393873505228d, 8.00736706798333d);
//     double var15 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var18 = var1.nextLong(10L, 3L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 4.011186337296827d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 968.8343073325332d);
// 
//   }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test57"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = var0.nextUniform(0.02318656797210774d, (-0.48741290436643614d), false);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test58"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10.0d, (java.lang.Number)1.0f, true);
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var6 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var4, (java.lang.Number)(short)100);
    var3.addSuppressed((java.lang.Throwable)var6);
    boolean var8 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test59"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(101L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 101L);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test60"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var5 = var3.getElement(0);
    int var6 = var3.getNumElements();
    int var7 = var3.getExpansionMode();
    double var9 = var3.substituteMostRecentElement(1.5707963267948966d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.discardFrontElements((-7));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 100.0d);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test61"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(4.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4);

  }

  public void test62() {}
//   public void test62() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test62"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy var1 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var1);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var2.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var2.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var2.getTiesStrategy();
//     double[] var8 = new double[] { 0.0d, 100.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
//     double[] var10 = var9.getElements();
//     double[] var11 = var9.getInternalValues();
//     int var12 = var9.start();
//     double[] var15 = new double[] { 0.0d, 100.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray(var15);
//     double var18 = var16.getElement(0);
//     var16.addElement(0.5403023058681398d);
//     var16.discardFrontElements(0);
//     double[] var23 = var16.getInternalValues();
//     var9.addElements(var23);
//     double[] var25 = var2.rank(var23);
// 
//   }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test63"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(100L, 102L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test64"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(1);
    var1.setElement(0, (-0.9880458431278127d));
    double var6 = var1.substituteMostRecentElement((-3.1903387268750403d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-0.9880458431278127d));

  }

  public void test65() {}
//   public void test65() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test65"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(3.1780538303479458d);
//     double var5 = var1.nextExponential(19.39006869589386d);
//     var1.reSeedSecure(9223372036854775807L);
//     var1.reSeedSecure(2L);
//     var1.reSeed();
//     int var13 = var1.nextBinomial(100, 0.0d);
//     double var16 = var1.nextGamma(0.0d, 0.5403023058681398d);
//     int var19 = var1.nextPascal(17, 0.7333114255659123d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.336819898262453d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 11.093291396075893d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 6);
// 
//   }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test66"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)45.82685605718666d, (java.lang.Number)4.810477380965351d, (java.lang.Number)11.332278829291482d);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test67"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getNumericalMean();
    double[] var9 = var3.sample(1);
    double var11 = var3.density((-0.8390715290764524d));
    double var12 = var3.getNumericalMean();
    boolean var13 = var3.isSupportUpperBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test68"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(9.536743E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9.536743E-7f);

  }

  public void test69() {}
//   public void test69() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test69"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
//     double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
//     double var7 = var3.getNumericalMean();
//     double[] var9 = var3.sample(1);
//     double var11 = var3.density(979.3393873505228d);
//     double var13 = var3.density(3921225.0d);
//     boolean var14 = var3.isSupportLowerBoundInclusive();
//     double[] var16 = var3.sample(4);
//     double var17 = var3.sample();
//     double var19 = var3.probability(0.7099849575852162d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.3235780930645504d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.348220504432292d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.0d);
// 
//   }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test70"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(2.8174083705609023d, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2885.026171454364d);

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test71"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(29, 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 29);

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test72"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(17, 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1700);

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test73"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)4.315213397797969d, (java.lang.Number)3, false);

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test74"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(1399408473, 14);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test75"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(2, 1398870649);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test76"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var5 = var3.getElement(0);
    int var6 = var3.getNumElements();
    int var7 = var3.getExpansionMode();
    var3.contract();
    var3.addElement((-8.541939077859835d));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setContractionCriteria(1.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test77"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var5 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MathIllegalArgumentException var6 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var4, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError(var3, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MaxCountExceededException var8 = new org.apache.commons.math3.exception.MaxCountExceededException(var1, (java.lang.Number)100L, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MathIllegalArgumentException var9 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test78"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getNumericalMean();
    double[] var9 = var3.sample(1);
    double var11 = var3.density(979.3393873505228d);
    double var13 = var3.density(3921225.0d);
    boolean var14 = var3.isSupportLowerBoundInclusive();
    double var15 = var3.getMean();
    double[] var17 = var3.sample(10000);
    double var18 = var3.getMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1.3235780930645504d);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test79"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-98), (-98));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-196));

  }

  public void test80() {}
//   public void test80() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test80"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(3.1780538303479458d);
//     double var5 = var1.nextExponential(19.39006869589386d);
//     var1.reSeedSecure(9223372036854775807L);
//     var1.reSeedSecure(2L);
//     double var12 = var1.nextWeibull(0.5403023058681398d, 0.43549250150289726d);
//     var1.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.088731025128343d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.5238660486506794d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 2.1928027555236245d);
// 
//   }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test81"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(2.3841858E-7f, 10.000001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10.000001f);

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test82"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(14, 10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1491846144);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test83"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10.0d, (java.lang.Number)1.0f, true);
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    java.lang.Object[] var7 = new java.lang.Object[] { (short)1};
    org.apache.commons.math3.exception.MathArithmeticException var8 = new org.apache.commons.math3.exception.MathArithmeticException(var5, var7);
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, var7);
    org.apache.commons.math3.exception.NumberIsTooLargeException var13 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10L, (java.lang.Number)3921225.0d, true);
    var3.addSuppressed((java.lang.Throwable)var13);
    org.apache.commons.math3.exception.util.ExceptionContext var15 = var13.getContext();
    boolean var16 = var13.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test84"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(1.348220504432292d, 122.7902212423532d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test85"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var5 = var3.cumulativeProbability(0.0d);
    double var6 = var3.getSupportLowerBound();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var3.inverseCumulativeProbability((-0.8390715290764524d));
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == Double.NEGATIVE_INFINITY);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test86"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    java.lang.String var3 = var1.toString();
    java.lang.String var4 = var1.name();
    int var5 = var1.ordinal();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "AVERAGE"+ "'", var3.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "AVERAGE"+ "'", var4.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 3);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test87"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(-0.7853981633974483d), (java.lang.Number)1, true);
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test88"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 10.000001f);

  }

  public void test89() {}
//   public void test89() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test89"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     var1.reSeedSecure(10L);
//     double var9 = var1.nextCauchy(1.762747174039086d, 0.025803565724757293d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var12 = var1.nextPermutation(3, 1491846144);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.7897951680742463d);
// 
//   }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test90"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getNumericalMean();
    double[] var9 = var3.sample(1);
    double var11 = var3.density(979.3393873505228d);
    double var13 = var3.density(3921225.0d);
    boolean var14 = var3.isSupportLowerBoundInclusive();
    double var15 = var3.getNumericalMean();
    boolean var16 = var3.isSupportUpperBoundInclusive();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var18 = var3.inverseCumulativeProbability(3.5247804145401362d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test91"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test92"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, var1, (java.lang.Number)1.7792833636531957d, (java.lang.Number)0.6750463740655989d);

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test93"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(9.536743E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test94"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getNumericalMean();
    double[] var9 = var3.sample(1);
    double var11 = var3.density(979.3393873505228d);
    double var13 = var3.density(3921225.0d);
    double[] var15 = var3.sample(10000);
    boolean var16 = var3.isSupportUpperBoundInclusive();
    double var18 = var3.cumulativeProbability(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test95"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(2.127929429721528d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4994259604654114d);

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test96"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(1.6873352971776172d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5231505373286716d);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test97"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt((-0.7333114255659123d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.9017707629176819d));

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test98"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10.0d, (java.lang.Number)1.0f, true);
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    java.lang.Object[] var7 = new java.lang.Object[] { (short)1};
    org.apache.commons.math3.exception.MathArithmeticException var8 = new org.apache.commons.math3.exception.MathArithmeticException(var5, var7);
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, var7);
    boolean var10 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);

  }

  public void test99() {}
//   public void test99() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test99"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy[] var2 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
//     org.apache.commons.math3.exception.MaxCountExceededException var3 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)0.007895180433873628d, (java.lang.Object[])var2);
//     java.lang.String var4 = var3.toString();
// 
//   }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test100"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(1);
    var1.setElement(0, (-0.9880458431278127d));
    var1.setNumElements(9);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.discardMostRecentElements(15);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test101"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(9.536743E-7f, 15.996697063082339d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.536744E-7f);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test102"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.6725605152305536d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.6725605152305536d);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test103"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(101L, 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test104"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(1.8328655053227587d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test105"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var5 = var3.getElement(0);
    var3.setElement(4, (-0.8309074630677628d));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setExpansionFactor((-1.0f));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test106"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(9.536743E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-20));

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test107"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(3.088731025128343d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.440892098500626E-16d);

  }

  public void test108() {}
//   public void test108() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test108"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(3.1780538303479458d);
//     double var5 = var1.nextExponential(19.39006869589386d);
//     var1.reSeedSecure(9223372036854775807L);
//     var1.reSeedSecure(2L);
//     var1.reSeed();
//     int var13 = var1.nextBinomial(100, 0.0d);
//     double var15 = var1.nextExponential(3.474865488735192d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2.5164150335575357d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.10147708278577372d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 28.77905591265581d);
// 
//   }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test109"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.0d, (-1.777309158100993d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test110"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(100, 9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9);

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test111"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray((-196), (-1.0f), 0.0f, 18);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test112() {}
//   public void test112() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test112"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy var1 = null;
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var2 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var1);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
//     double var9 = var6.cumulativeProbability(0.0d, 0.1690925369322372d);
//     double var10 = var6.getNumericalMean();
//     double[] var12 = var6.sample(15);
//     double[] var15 = new double[] { 0.0d, 100.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray(var15);
//     double[] var17 = var16.getElements();
//     double[] var18 = var16.getInternalValues();
//     int var19 = var16.start();
//     double[] var22 = new double[] { 0.0d, 100.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var23 = new org.apache.commons.math3.util.ResizableDoubleArray(var22);
//     double var25 = var23.getElement(0);
//     var23.addElement(0.5403023058681398d);
//     var23.discardFrontElements(0);
//     double[] var30 = var23.getInternalValues();
//     var16.addElements(var30);
//     double var32 = var2.mannWhitneyUTest(var12, var30);
// 
//   }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test113"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(9L, 100L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6627890308811632801L);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test114"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var5 = var3.getElement(0);
    double[] var6 = var3.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = var3.copy();
    double var9 = var3.addElementRolling(122.7902212423532d);
    var3.addElement(0.705287720983563d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test115"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray((-1431655765), 1.0000001f, 2.5f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test116"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var3.discardFrontElements(2);
    var3.setElement(6, (-0.3738789406485615d));
    float var9 = var3.getContractionCriteria();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 2.5f);

  }

  public void test117() {}
//   public void test117() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test117"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     double var7 = var1.nextCauchy(0.15560730683937996d, 3.1780538303479458d);
//     long var9 = var1.nextPoisson(1.5707963267948966d);
//     var1.reSeed(101L);
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution(979.3393873505228d, 8.00736706798333d);
//     double var15 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     double var17 = var1.nextExponential(0.43549250150289726d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 3.4372222997317032d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 968.8343073325332d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.0438509658141657d);
// 
//   }

  public void test118() {}
//   public void test118() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test118"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextSecureInt(2, 10);
//     var1.reSeed(3L);
//     double var9 = var1.nextF(0.09409951665194471d, 34.62483743197144d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var1.nextUniform(0.037062153555774406d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.3013419654212052d);
// 
//   }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test119"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble(1700);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test120"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(4.440892098500626E-16d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-35.35050620855721d));

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test121"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var6 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MathIllegalArgumentException var7 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var5, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MathInternalError var8 = new org.apache.commons.math3.exception.MathInternalError(var4, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MathArithmeticException var9 = new org.apache.commons.math3.exception.MathArithmeticException(var3, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MaxCountExceededException var10 = new org.apache.commons.math3.exception.MaxCountExceededException(var1, (java.lang.Number)0.023190724476818098d, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test122"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(1.252532938915154d, 0.9864231484692195d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.5196265085690617d);

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test123"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(0.6991252484815342d, 0.7241199936737109d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9018588507146864d);

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test124"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(7, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test125"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo((-7227766516491148288L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test126() {}
//   public void test126() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test126"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(3.1780538303479458d);
//     double var6 = var1.nextWeibull(968.8343073325332d, 0.9149287324253481d);
//     double var9 = var1.nextGaussian(0.9018588507146864d, 0.4833507072637169d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 5.410266968958382d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.9093102466862683d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.7676325300101949d);
// 
//   }

  public void test127() {}
//   public void test127() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test127"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(3.1780538303479458d);
//     double var6 = var1.nextWeibull(968.8343073325332d, 0.9149287324253481d);
//     double var9 = var1.nextGaussian(0.0d, Double.POSITIVE_INFINITY);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var12 = var1.nextSecureLong(101L, 2L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.46459575877498316d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.9134041830930704d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == Double.POSITIVE_INFINITY);
// 
//   }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test128"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(4.189149606287355d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.7334893091042638d);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test129"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(0.6273326199925041d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5562127834021756d);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test130"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(0, (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.NEGATIVE_INFINITY);

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test131"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(5, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test132"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(979.3393873505228d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9);

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test133"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(100L, 9223372036854775807L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100L);

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test134"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(1.8439600399218803d, 101.73677860378969d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.8439600399218803d);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test135"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(short)1);
    java.lang.Number var3 = var2.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + (short)1+ "'", var3.equals((short)1));

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test136"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(0.7425040618985324d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.29772693774983194d));

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test137"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(0, 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test138"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 8);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, (-196));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test139"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(10000, 0.0f, 1.1920929E-7f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test140"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(1.0000001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test141() {}
//   public void test141() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test141"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     double var7 = var1.nextCauchy(0.15560730683937996d, 3.1780538303479458d);
//     double var11 = var1.nextUniform((-0.6740495597759653d), (-0.016482976994642014d), true);
//     int var14 = var1.nextPascal(5, 0.9864231484692195d);
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var18 = var1.nextSecureInt(58347, 58347);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 3.355755155352868d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.5632733758194343d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
// 
//   }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test142"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var1 = null;
    org.apache.commons.math3.exception.MathArithmeticException var2 = new org.apache.commons.math3.exception.MathArithmeticException(var0, var1);

  }

  public void test143() {}
//   public void test143() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test143"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-0.016482976994642014d), (java.lang.Number)0.9864231484692195d, false);
//     org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var4);
// 
//   }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test144"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(70L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test145"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh((-3.1903387268750403d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.8769778981583525d));

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test146"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(0.686579669341957d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6865796693419571d);

  }

  public void test147() {}
//   public void test147() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test147"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Number var2 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)(-1.0d), var2, (java.lang.Number)100.0f);
//     org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var4);
// 
//   }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test148"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(1.3440585709080678E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 43.1284181946612d);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test149"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)10000, (java.lang.Number)(-196), (java.lang.Number)6.00114357701874d);

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test150"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var5 = var3.getElement(0);
    float var6 = var3.getContractionCriteria();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setExpansionFactor(4.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.5f);

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test151"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    int var4 = var3.getNumElements();
    int var5 = var3.getNumElements();
    double[] var6 = var3.getInternalValues();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test152"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum((-0.49035942660728515d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test153"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(6, 10000);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2);

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test154"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(8.594124866502801d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test155() {}
//   public void test155() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test155"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var1 = null;
//     java.math.BigInteger var3 = org.apache.commons.math3.util.ArithmeticUtils.pow(var1, 0L);
//     java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var1, 0L);
//     java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 8);
//     java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, var7);
// 
//   }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test156"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    java.lang.String var3 = var1.toString();
    java.lang.String var4 = var1.name();
    java.lang.Class var5 = var1.getDeclaringClass();
    int var6 = var1.ordinal();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "AVERAGE"+ "'", var3.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "AVERAGE"+ "'", var4.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 3);

  }

  public void test157() {}
//   public void test157() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test157"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     double var7 = var1.nextCauchy(0.15560730683937996d, 3.1780538303479458d);
//     double var11 = var1.nextUniform((-0.6740495597759653d), (-0.016482976994642014d), true);
//     int var14 = var1.nextPascal(2, 0.5403023058681399d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var16 = var1.nextChiSquare(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.4143615924433202d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.22829430422710129d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 3);
// 
//   }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test158"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var2 = new java.lang.Object[] { (short)1};
    org.apache.commons.math3.exception.MathArithmeticException var3 = new org.apache.commons.math3.exception.MathArithmeticException(var0, var2);
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var3.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var3.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var6 = var3.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test159"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(5.258584046449211d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999999999998969d);

  }

  public void test160() {}
//   public void test160() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test160"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(3.1780538303479458d);
//     double var6 = var1.nextWeibull(968.8343073325332d, 0.9149287324253481d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var8 = var1.nextT(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.0644853483666201d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.9148495098810773d);
// 
//   }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test161"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var3.setElement(3, (-0.7853981633974483d));
    float var7 = var3.getContractionCriteria();
    double var9 = var3.addElementRolling(1.9124153064037224d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test162"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(3.657242590218247d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2967094728211648d);

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test163"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(2.3841858E-7f, 58347);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.POSITIVE_INFINITY);

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test164"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 100.00000000000001d);

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test165"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(0.9152952197546206d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 13.909208911282622d);

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test166"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(40320L, 100L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test167"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)0.7333114255659123d);

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test168"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(15.996697063082339d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 8856807.675726483d);

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test169"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(4.7683716E-7f, 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.7683716E-7f);

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test170"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var3.setElement(3, (-0.7853981633974483d));
    int var7 = var3.getNumElements();
    double[] var8 = var3.getInternalValues();
    double var10 = var3.substituteMostRecentElement(100.0d);
    var3.setExpansionMode(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-0.7853981633974483d));

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test171"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test172() {}
//   public void test172() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test172"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     double var7 = var1.nextCauchy(0.15560730683937996d, 3.1780538303479458d);
//     var1.reSeed(101L);
//     java.lang.String var11 = var1.nextSecureHexString(100);
//     double var13 = var1.nextExponential(0.9098704402818677d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-67.37989615938413d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "959e7d74b527fae3cd8d1947430516e29e8a75a9b271dff39200aa1a17fa0b646148ce36723ef17f1f94a72ba258d41dc969"+ "'", var11.equals("959e7d74b527fae3cd8d1947430516e29e8a75a9b271dff39200aa1a17fa0b646148ce36723ef17f1f94a72ba258d41dc969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 2.361841710139455d);
// 
//   }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test173"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(0.9149287324253481d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test174"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)5.258584046449211d, (java.lang.Number)0.5573731387105724d, false);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test175"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(1.893344644644389d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.245488905632156d);

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test176"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var5 = var3.getElement(0);
    var3.setElement(4, (-0.8309074630677628d));
    double var10 = var3.substituteMostRecentElement(6.938893903907228E-18d);
    var3.contract();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-0.8309074630677628d));

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test177"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(102L, 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1061208L);

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test178"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(1061208L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test179"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(9.536743E-7f, Float.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.536743E-7f);

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test180"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog((-1));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test181"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(10000, 9.536744E-7f, 9.536744E-7f, 29);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test182"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(10.923276331316844d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.7763568394002505E-15d);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test183"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(0.9152952197546206d, 0.6273326199925041d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9152952197546206d);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test184"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var3.setElement(3, (-0.7853981633974483d));
    double[] var7 = var3.getElements();
    var3.setElement(0, (-20.34054861465728d));
    var3.addElement((-0.07846360586397706d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test185"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(4.189149606287355d, 2.5842611209158894d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.5842611209158894d);

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test186"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(70L, 40320L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-40250L));

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test187"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Object[] var5 = new java.lang.Object[] { (byte)1};
    org.apache.commons.math3.exception.MathIllegalStateException var6 = new org.apache.commons.math3.exception.MathIllegalStateException(var3, var5);
    org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, var5);
    org.apache.commons.math3.exception.MathInternalError var8 = new org.apache.commons.math3.exception.MathInternalError(var1, var5);
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test188"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(0.9999999958776927d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1L);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test189"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(7, (-1431655765));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1431655772);

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test190"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(4.130828839435178d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test191"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(9.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.140641475065075d);

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test192"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var3.setElement(3, (-0.7853981633974483d));
    int var7 = var3.getNumElements();
    double var9 = var3.substituteMostRecentElement((-0.7853981633974483d));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.discardMostRecentElements((-98));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-0.7853981633974483d));

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test193"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(0.0010231502395483475d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-977.9491016880288d));

  }

  public void test194() {}
//   public void test194() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test194"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     var1.reSeedSecure(10L);
//     double var9 = var1.nextF(1.0d, 47.71468531505997d);
//     double var11 = var1.nextT(4.810477380965351d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var1.nextHypergeometric(9, (-7), (-1431655765));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 3.064038500565503d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.5134849367134914d));
// 
//   }

  public void test195() {}
//   public void test195() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test195"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     double var7 = var1.nextCauchy(0.15560730683937996d, 3.1780538303479458d);
//     long var9 = var1.nextPoisson(1.5707963267948966d);
//     var1.reSeed(101L);
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution(979.3393873505228d, 8.00736706798333d);
//     double var15 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     double var16 = var14.getStandardDeviation();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double[] var18 = var14.sample(1491846144);
//       fail("Expected exception of type java.lang.OutOfMemoryError");
//     } catch (java.lang.OutOfMemoryError e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-120.14970288051391d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 968.8343073325332d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 8.00736706798333d);
// 
//   }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test196"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(11.28403526992695d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.19694356837139235d);

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test197"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(short)1);
    boolean var3 = var2.getBoundIsAllowed();
    boolean var4 = var2.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test198"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1L);

  }

  public void test199() {}
//   public void test199() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test199"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     var1.reSeedSecure((-1L));
//     long var9 = var1.nextSecureLong(0L, 201L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 38L);
// 
//   }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test200"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(40320L, (-98));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test201() {}
//   public void test201() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test201"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     var1.reSeedSecure(10L);
//     double var9 = var1.nextF(1.0d, 47.71468531505997d);
//     long var12 = var1.nextSecureLong(1L, 10L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var1.nextWeibull(0.0d, 5.26885534061425E-4d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.2022180788215944d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 8L);
// 
//   }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test202"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var5 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var4);
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var4);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var7 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var4);
    org.apache.commons.math3.exception.NumberIsTooLargeException var11 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-0.11387786884182144d), (java.lang.Number)979.3393873505228d, true);
    org.apache.commons.math3.exception.MathInternalError var12 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var11);
    boolean var13 = var4.equals((java.lang.Object)var11);
    org.apache.commons.math3.exception.util.Localizable var14 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var18 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)10000, (java.lang.Number)1.3440585709080678E43d, true);
    org.apache.commons.math3.exception.util.Localizable var19 = null;
    org.apache.commons.math3.exception.util.Localizable var20 = null;
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var22 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MathIllegalArgumentException var23 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var21, (java.lang.Object[])var22);
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var20, (java.lang.Object[])var22);
    org.apache.commons.math3.exception.MathIllegalStateException var25 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var18, var19, (java.lang.Object[])var22);
    org.apache.commons.math3.exception.MathIllegalStateException var26 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var11, var14, (java.lang.Object[])var22);
    org.apache.commons.math3.exception.util.Localizable var27 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var28 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var29 = var28.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var30 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var29);
    java.lang.String var31 = var29.toString();
    java.lang.String var32 = var29.name();
    org.apache.commons.math3.distribution.NormalDistribution var36 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var39 = var36.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var40 = var36.getNumericalMean();
    double[] var42 = var36.sample(15);
    boolean var43 = var36.isSupportLowerBoundInclusive();
    boolean var44 = var29.equals((java.lang.Object)var36);
    org.apache.commons.math3.stat.ranking.NaturalRanking var45 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var29);
    java.lang.Object[] var46 = new java.lang.Object[] { var45};
    org.apache.commons.math3.exception.MathIllegalStateException var47 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var11, var27, var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var31 + "' != '" + "AVERAGE"+ "'", var31.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var32 + "' != '" + "AVERAGE"+ "'", var32.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test203"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(6.491753541596189d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.417956092243527d);

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test204"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0, (java.lang.Number)100.0d, (java.lang.Number)(short)0);
    java.lang.Number var4 = var3.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (short)0+ "'", var4.equals((short)0));

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test205"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(0.7105235543492688d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8923313678787291d);

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test206"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var5 = var3.getElement(0);
    double[] var6 = var3.getElements();
    float var7 = var3.getExpansionFactor();
    double[] var10 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var10);
    var11.setElement(3, (-0.7853981633974483d));
    var11.discardMostRecentElements(0);
    double[] var19 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray(var19);
    double var22 = var20.getElement(0);
    double[] var23 = var20.getInternalValues();
    var11.addElements(var23);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var3, var11);
    org.apache.commons.math3.util.ResizableDoubleArray var26 = new org.apache.commons.math3.util.ResizableDoubleArray(var11);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.setExpansionMode(1399408473);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test207() {}
//   public void test207() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test207"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     var1.reSeedSecure(10L);
//     double var9 = var1.nextF(1.0d, 47.71468531505997d);
//     double var13 = var1.nextUniform(0.3404631721379325d, 1.5707963267948966d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var16 = var1.nextCauchy(0.686579669341957d, (-0.15278468894698005d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.26960773290548923d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.500537196385816d);
// 
//   }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test208"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(0.34943406609505034d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.3569670254374492d);

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test209"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(101L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test210() {}
//   public void test210() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test210"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)3L, (java.lang.Number)0.5964546144007504d, (java.lang.Number)14);
//     org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var4);
// 
//   }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test211"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var3.setElement(3, (-0.7853981633974483d));
    var3.contract();
    var3.contract();
    double[] var11 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var11);
    double var14 = var12.getElement(0);
    var12.addElement(0.5403023058681398d);
    var12.discardFrontElements(0);
    double[] var19 = var12.getInternalValues();
    var3.addElements(var19);
    var3.addElement(0.060647843842351036d);
    var3.contract();
    var3.setNumElements(7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test212"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(2.1928027555236245d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.535947486464549d);

  }

  public void test213() {}
//   public void test213() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test213"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy var1 = null;
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var2 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var1);
//     double[] var5 = new double[] { 0.0d, 100.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray(var5);
//     double var8 = var6.getElement(0);
//     double[] var9 = var6.getElements();
//     double[] var12 = new double[] { 0.0d, 100.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray(var12);
//     double[] var14 = var13.getElements();
//     double[] var15 = var13.getInternalValues();
//     double var16 = var2.mannWhitneyU(var9, var15);
// 
//   }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test214"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(9223372036854775807L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test215"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(0.3646904086155498d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.3646904086155498d);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test216"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.7676325300101949d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test217"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog(14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 25.19122118273868d);

  }

  public void test218() {}
//   public void test218() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test218"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy var1 = null;
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var2 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var1);
//     double[] var5 = new double[] { 0.0d, 100.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray(var5);
//     var6.setElement(3, (-0.7853981633974483d));
//     var6.contract();
//     var6.contract();
//     double[] var14 = new double[] { 0.0d, 100.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
//     double var17 = var15.getElement(0);
//     var15.addElement(0.5403023058681398d);
//     var15.discardFrontElements(0);
//     double[] var22 = var15.getInternalValues();
//     var6.addElements(var22);
//     double[] var26 = new double[] { 0.0d, 100.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var27 = new org.apache.commons.math3.util.ResizableDoubleArray(var26);
//     double[] var28 = var27.getElements();
//     double[] var29 = var27.getInternalValues();
//     int var30 = var27.start();
//     double[] var33 = new double[] { 0.0d, 100.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var34 = new org.apache.commons.math3.util.ResizableDoubleArray(var33);
//     double var36 = var34.getElement(0);
//     var34.addElement(0.5403023058681398d);
//     var34.discardFrontElements(0);
//     double[] var41 = var34.getInternalValues();
//     var27.addElements(var41);
//     double var43 = var2.mannWhitneyUTest(var22, var41);
// 
//   }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test219"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(1399408473, 18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1399408455);

  }

  public void test220() {}
//   public void test220() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test220"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     double var7 = var1.nextCauchy(0.15560730683937996d, 3.1780538303479458d);
//     double var11 = var1.nextUniform((-0.6740495597759653d), (-0.016482976994642014d), true);
//     int var14 = var1.nextPascal(2, 0.5403023058681399d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var16 = var1.nextSecureHexString(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 3.302077763283201d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.14257352828716768d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1);
// 
//   }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test221"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.9093102466862683d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test222"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(1.1920929E-7f, 1.1920929E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.1920929E-7f);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test223"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(3, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3);

  }

  public void test224() {}
//   public void test224() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test224"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextSecureInt(2, 10);
//     double var7 = var1.nextCauchy(0.037062153555774406d, 3.5247804145401362d);
//     double var10 = var1.nextBeta(0.7607318203617716d, 2.6489183762783663d);
//     org.apache.commons.math3.distribution.RealDistribution var11 = null;
//     double var12 = var1.nextInversionDeviate(var11);
// 
//   }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test225"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(1399408455, 9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 176.73201156338953d);

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test226"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getNumericalMean();
    double[] var9 = var3.sample(1);
    double var11 = var3.density(979.3393873505228d);
    var3.reseedRandomGenerator(0L);
    double var14 = var3.sample();
    double var16 = var3.cumulativeProbability(0.5403023058681398d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var18 = var3.sample(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.322456124528837d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);

  }

  public void test227() {}
//   public void test227() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test227"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)1.0000001f, (java.lang.Number)(-9.602370808556296d), false);
//     java.lang.String var5 = var4.toString();
// 
//   }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test228"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma((-0.4833507072637169d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.18528215992489017d);

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test229"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    java.lang.String var3 = var1.toString();
    java.lang.String var4 = var1.name();
    java.lang.Class var5 = var1.getDeclaringClass();
    java.lang.Enum var7 = java.lang.Enum.<java.lang.Enum>valueOf(var5, "AVERAGE");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var9 = java.lang.Enum.<java.lang.Enum>valueOf(var5, "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (3,921,225)");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "AVERAGE"+ "'", var3.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "AVERAGE"+ "'", var4.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test230"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(1.1920929E-7f, 1.0000001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.1920929E-7f);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test231"); }


    long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 355687428096000L);

  }

  public void test232() {}
//   public void test232() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test232"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     var1.reSeedSecure(10L);
//     double var9 = var1.nextF(1.0d, 47.71468531505997d);
//     var1.reSeedSecure(0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2.9715526190865114d);
// 
//   }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test233"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)8.800174227572448d, (java.lang.Number)3.474865488735192d, true);
    java.lang.Number var5 = var4.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 8.800174227572448d+ "'", var5.equals(8.800174227572448d));

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test234"); }


    double var1 = org.apache.commons.math3.util.FastMath.acos((-0.15278468894698005d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.724181760803743d);

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test235"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(0, 2.3841858E-7f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test236"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign((-1.0f), 9.536744E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0f);

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test237"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getNumericalMean();
    double[] var9 = var3.sample(1);
    double var11 = var3.density(979.3393873505228d);
    var3.reseedRandomGenerator(0L);
    double var14 = var3.sample();
    double var16 = var3.cumulativeProbability(0.5403023058681398d);
    double var17 = var3.getNumericalMean();
    double var18 = var3.getStandardDeviation();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.322456124528837d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.025803565724757293d);

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test238"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(9, 29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 38);

  }

  public void test239() {}
//   public void test239() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test239"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     double var7 = var1.nextCauchy(0.15560730683937996d, 3.1780538303479458d);
//     double var11 = var1.nextUniform((-0.6740495597759653d), (-0.016482976994642014d), true);
//     long var14 = var1.nextLong(0L, 1030301L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var18 = var1.nextHypergeometric(15, 1700, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 121.29723855741268d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.11741888131446807d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 462493L);
// 
//   }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test240"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos((-20.34054861465728d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5091610255820427d);

  }

  public void test241() {}
//   public void test241() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test241"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextSecureInt(2, 10);
//     double var7 = var1.nextCauchy(0.037062153555774406d, 3.5247804145401362d);
//     double var10 = var1.nextBeta(0.7607318203617716d, 2.6489183762783663d);
//     double var13 = var1.nextGamma((-0.016483723377414404d), (-2.3306405007995967d));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var16 = var1.nextGaussian(0.3404631721379325d, (-0.20109115859833598d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.06730378597540268d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.35636813408613915d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-5.713724490759675d));
// 
//   }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test242"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(0, 2.5f, 1.1920929E-7f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test243"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3);

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test244"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test245"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var3.setElement(3, (-0.7853981633974483d));
    var3.discardMostRecentElements(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.discardMostRecentElements(14);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test246"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(201L, 201L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-3017481761840155127L));

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test247"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(4, 17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 68);

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test248"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(8, 1700);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test249"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(1399408455);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test250"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(0.11209838020920855d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8740383559599469d);

  }

  public void test251() {}
//   public void test251() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test251"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(3.1780538303479458d);
//     double var5 = var1.nextExponential(19.39006869589386d);
//     double var8 = var1.nextBeta(4.499378297809863d, 1.8328655053227587d);
//     int var11 = var1.nextBinomial(14, 0.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("ede9f08", "ede9f08");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 13.741115337211088d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 7.636764362753695d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.9595750755200013d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0);
// 
//   }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test252"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(12.492495498705182d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.07380793801109557d));

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test253"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10.0d, (java.lang.Number)1.0f, true);
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var6 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var4, (java.lang.Number)(short)100);
    var3.addSuppressed((java.lang.Throwable)var6);
    boolean var8 = var6.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test254() {}
//   public void test254() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test254"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     var1.reSeedSecure(10L);
//     double var9 = var1.nextCauchy(1.762747174039086d, 0.025803565724757293d);
//     double var11 = var1.nextExponential(6.938893903907228E-18d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var14 = var1.nextSecureLong(355687428096000L, 201L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.691639533839679d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 9.533715068413576E-19d);
// 
//   }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test255"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(40.67914158740765d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2875462117406118d);

  }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test256"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)1.6815545646570225d);

  }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test257"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(18, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 18);

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test258"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.2803387459042875d);

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test259"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees((-35.35050620855721d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-2025.4348094013417d));

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test260"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(101.73677860378969d, 1399408473);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.POSITIVE_INFINITY);

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test261"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getStandardDeviation();
    double[] var9 = var3.sample(6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.025803565724757293d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test262"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(0.9999999958776927d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7615941542245016d);

  }

  public void test263() {}
//   public void test263() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test263"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     double var7 = var1.nextCauchy(0.15560730683937996d, 3.1780538303479458d);
//     double var11 = var1.nextUniform((-0.6740495597759653d), (-0.016482976994642014d), true);
//     int var14 = var1.nextPascal(2, 0.5403023058681399d);
//     double var16 = var1.nextT(0.5403023058681398d);
//     double var18 = var1.nextExponential(1.35183754101305d);
//     double var21 = var1.nextGamma((-352.69596618548d), 1.6815545646570225d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var24 = var1.nextSecureInt(1700, 18);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-0.48392068788146303d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.036218875070377965d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == (-2.9680312982405033d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.6420572006668126d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == Double.NaN);
// 
//   }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test264"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin((-0.03791546974136306d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.03792456006137928d));

  }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test265"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getNumericalMean();
    double[] var9 = var3.sample(1);
    double var10 = var3.getNumericalMean();
    double var11 = var3.getMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1.3235780930645504d);

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test266"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(0.6225116311094179d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.671947921623892d);

  }

  public void test267() {}
//   public void test267() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test267"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     var1.reSeedSecure(10L);
//     double var9 = var1.nextBeta(11.332278829291482d, 13.221239069499132d);
//     int var12 = var1.nextBinomial(0, 0.9864231484692195d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.5395249741582591d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
// 
//   }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test268"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(10.000001f, 2.8094479062051723d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10.0f);

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test269"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(5.410266968958382d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.688298438952937d);

  }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test270"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7);

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test271"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)0.8144772166995121d);

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test272"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(0.9927689477197732d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.0072573230589590134d));

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test273"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(0L, (-40250L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test274() {}
//   public void test274() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test274"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     var1.reSeedSecure(10L);
//     double var9 = var1.nextF(1.0d, 47.71468531505997d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("org.apache.commons.math3.exception.NotPositiveException: 0 is smaller than the minimum (0)", "");
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.20680134960917626d);
// 
//   }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test275"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3506254701664102d, 1.2967094728211648d, 3.657242590218247d);

  }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test276"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.OutOfRangeException var8 = new org.apache.commons.math3.exception.OutOfRangeException(var4, (java.lang.Number)10.0d, (java.lang.Number)1L, (java.lang.Number)1);
    java.lang.Number var9 = var8.getHi();
    org.apache.commons.math3.exception.NumberIsTooLargeException var13 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10.0d, (java.lang.Number)1.0f, true);
    java.lang.Number var14 = var13.getMax();
    var8.addSuppressed((java.lang.Throwable)var13);
    java.lang.Throwable[] var16 = var8.getSuppressed();
    org.apache.commons.math3.exception.MaxCountExceededException var17 = new org.apache.commons.math3.exception.MaxCountExceededException(var2, (java.lang.Number)1.762747174039086d, (java.lang.Object[])var16);
    org.apache.commons.math3.exception.MathIllegalStateException var18 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, (java.lang.Object[])var16);
    org.apache.commons.math3.exception.MathIllegalStateException var19 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + 1+ "'", var9.equals(1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + 1.0f+ "'", var14.equals(1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test277() {}
//   public void test277() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test277"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP((-0.9017707629176819d), 1.3235780930645504d, 0.037062153555774406d, 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test278() {}
//   public void test278() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test278"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log1p((-1.3173720911599616d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test279"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(0, (-20));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-20));

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test280"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(6);
    double[] var2 = var1.getInternalValues();
    var1.setElement(58347, 0.6225116311094179d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test281"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)10.0d, (java.lang.Number)1L, (java.lang.Number)1);
    java.lang.Number var5 = var4.getHi();
    java.lang.Number var6 = var4.getLo();
    java.lang.Number var7 = var4.getLo();
    java.lang.Number var8 = var4.getLo();
    java.lang.Number var9 = var4.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1+ "'", var5.equals(1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 1L+ "'", var6.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 1L+ "'", var7.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 1L+ "'", var8.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + 1L+ "'", var9.equals(1L));

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test282"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var5 = var3.getElement(0);
    double[] var6 = var3.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(10);
    double var10 = var8.addElementRolling((-20.34054861465728d));
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var3, var8);
    float var12 = var3.getExpansionFactor();
    int var13 = var3.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test283"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh(0.5395249741582591d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6034852839804553d);

  }

  public void test284() {}
//   public void test284() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test284"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     double var7 = var1.nextCauchy(0.15560730683937996d, 3.1780538303479458d);
//     long var9 = var1.nextPoisson(1.5707963267948966d);
//     var1.reSeed(101L);
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution(979.3393873505228d, 8.00736706798333d);
//     double var15 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     double var16 = var14.getStandardDeviation();
//     double var17 = var14.getStandardDeviation();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-0.6910036896710812d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 968.8343073325332d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 8.00736706798333d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 8.00736706798333d);
// 
//   }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test285"); }


    java.lang.Throwable var0 = null;
    org.apache.commons.math3.exception.MathInternalError var1 = new org.apache.commons.math3.exception.MathInternalError(var0);

  }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test286"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(5.2827420214093905d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2);

  }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test287"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(8.498710698501613d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 8.0d);

  }

  public void test288() {}
//   public void test288() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test288"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     var1.reSeedSecure(10L);
//     double var9 = var1.nextF(1.0d, 47.71468531505997d);
//     int var12 = var1.nextZipf(18, 0.049034116126541086d);
//     var1.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var1.nextZipf(18, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.07963160363249441d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1);
// 
//   }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test289"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test290"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(4.7683716E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-21));

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test291"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.08772462544619851d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test292() {}
//   public void test292() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test292"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log1p((-3.657242590218247d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test293"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (3,921,225)");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test294"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(short)1);
    boolean var3 = var2.getBoundIsAllowed();
    java.lang.Number var4 = var2.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0+ "'", var4.equals(0));

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test295"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.9254962739500686d, 5.26885534061425E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9254962739500686d);

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test296"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.9999999999998969d, 0.5231505373286716d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.1285771948374075d);

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test297"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(18, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2);

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test298"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(1061208L, 9L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9L);

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test299"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot((-0.9444050156042171d), 0.3646904086155498d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0123734131409112d);

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test300"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getNumericalMean();
    double[] var9 = var3.sample(1);
    double var11 = var3.density((-0.8390715290764524d));
    double var12 = var3.getSupportUpperBound();
    double var13 = var3.getStandardDeviation();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.025803565724757293d);

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test301"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(0, 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test302"); }


    java.lang.Throwable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var6 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10.0d, (java.lang.Number)1.0f, true);
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    java.lang.Object[] var10 = new java.lang.Object[] { (short)1};
    org.apache.commons.math3.exception.MathArithmeticException var11 = new org.apache.commons.math3.exception.MathArithmeticException(var8, var10);
    org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var6, var7, var10);
    java.lang.Throwable[] var13 = var6.getSuppressed();
    org.apache.commons.math3.exception.MathInternalError var14 = new org.apache.commons.math3.exception.MathInternalError(var2, (java.lang.Object[])var13);
    org.apache.commons.math3.exception.MathIllegalStateException var15 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var1, (java.lang.Object[])var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test303"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(1.9124153064037221d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.068982739122645d);

  }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test304"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(2.5842611209158894d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.47121968285336924d);

  }

  public void test305() {}
//   public void test305() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test305"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(3.1780538303479458d);
//     double var5 = var1.nextExponential(19.39006869589386d);
//     double var8 = var1.nextBeta(4.499378297809863d, 1.8328655053227587d);
//     int[] var11 = var1.nextPermutation(10000, 10000);
//     java.util.Collection var12 = null;
//     java.lang.Object[] var14 = var1.nextSample(var12, 17);
// 
//   }

  public void test306() {}
//   public void test306() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test306"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh((-67.37989615938413d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test307"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(4.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test308"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getStandardDeviation();
    double var9 = var3.cumulativeProbability(4.157279707691014d);
    double var10 = var3.getSupportUpperBound();
    boolean var11 = var3.isSupportUpperBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.025803565724757293d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test309"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(477733L, 9223372036854775807L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9223372036854775807L);

  }

  public void test310() {}
//   public void test310() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test310"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.tan(Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test311() {}
//   public void test311() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test311"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(1.322456124528837d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test312"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.NEGATIVE_INFINITY);

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test313"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(1.762747174039086d, (-0.49035942660728515d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.7627471740390859d);

  }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test314"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(1.688298438952937d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.11723191177832543d));

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test315"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var3.setElement(3, (-0.7853981633974483d));
    double[] var7 = var3.getElements();
    float var8 = var3.getExpansionFactor();
    double var10 = var3.addElementRolling((-0.6740495597759653d));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setExpansionFactor((-1.0f));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test316"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(2.9715526190865114d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.47298342497840623d);

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test317"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(0.0f, 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test318"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(10);
    double var3 = var1.addElementRolling((-20.34054861465728d));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setExpansionMode((-196));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);

  }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test319"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(477733L, 3L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test320"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    int var4 = var3.getNumElements();
    int var5 = var3.getNumElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var7 = var3.getElement(5);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2);

  }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test321"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(8, 5040L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test322"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(1.35183754101305d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test323() {}
//   public void test323() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test323"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextSecureInt(2, 10);
//     var1.reSeed(3L);
//     int var9 = var1.nextInt(0, 10);
//     var1.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var1.nextGaussian((-0.9444050156042171d), (-3.889934788209016d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 9);
// 
//   }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test324"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("d");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test325"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(0, (-7));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test326"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(12.992787532971414d, (-0.03791546974136306d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.0427625336239976d));

  }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test327"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test328"); }


    long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1307674368000L);

  }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test329"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(0.705287720983563d, 3.4034724091276374d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.2043338125509242d);

  }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test330"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)0.8292744355322256d);

  }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test331"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(3.69593234647658d, 11013.232920103323d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.69593234647658d);

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test332"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(1030301L, (-3L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1030301L);

  }

  public void test333() {}
//   public void test333() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test333"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(3.1780538303479458d);
//     double var5 = var1.nextExponential(19.39006869589386d);
//     double var8 = var1.nextBeta(4.499378297809863d, 1.8328655053227587d);
//     int var11 = var1.nextBinomial(14, 0.0d);
//     long var14 = var1.nextLong(2L, 1030301L);
//     org.apache.commons.math3.distribution.IntegerDistribution var15 = null;
//     int var16 = var1.nextInversionDeviate(var15);
// 
//   }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test334"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(2.354644375697275d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0d);

  }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test335"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var3.setElement(3, (-0.7853981633974483d));
    double[] var7 = var3.getElements();
    float var8 = var3.getExpansionFactor();
    var3.setNumElements(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.0f);

  }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test336"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh((-2.3306405007995967d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.9812684076861612d));

  }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test337"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(0.6725605152305536d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.01173839540968263d);

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test338"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)0.05690637728745587d, (java.lang.Number)(-67.37989615938413d), false);

  }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test339"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(10.60460290274525d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.38108667823090486d));

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test340"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2);

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test341"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(1.7334893091042638d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-6.092219684841774d));

  }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test342"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var4 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MathIllegalArgumentException var5 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.MathInternalError var6 = new org.apache.commons.math3.exception.MathInternalError(var2, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.MathArithmeticException var7 = new org.apache.commons.math3.exception.MathArithmeticException(var1, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.MathArithmeticException var8 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test343"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var5 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var4);
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var4);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var7 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var4);
    org.apache.commons.math3.exception.NumberIsTooLargeException var11 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-0.11387786884182144d), (java.lang.Number)979.3393873505228d, true);
    org.apache.commons.math3.exception.MathInternalError var12 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var11);
    boolean var13 = var4.equals((java.lang.Object)var11);
    org.apache.commons.math3.exception.util.Localizable var14 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var18 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)10000, (java.lang.Number)1.3440585709080678E43d, true);
    org.apache.commons.math3.exception.util.Localizable var19 = null;
    org.apache.commons.math3.exception.util.Localizable var20 = null;
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var22 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MathIllegalArgumentException var23 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var21, (java.lang.Object[])var22);
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var20, (java.lang.Object[])var22);
    org.apache.commons.math3.exception.MathIllegalStateException var25 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var18, var19, (java.lang.Object[])var22);
    org.apache.commons.math3.exception.MathIllegalStateException var26 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var11, var14, (java.lang.Object[])var22);
    boolean var27 = var11.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test344"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray((-98), 0.0f, 0.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test345"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.5782351942081396d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.7828891994911502d);

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test346"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(4, (-71));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test347"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(3921225.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 21);

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test348"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(1307674368000L, 101L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test349() {}
//   public void test349() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test349"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextSecureInt(2, 10);
//     var1.reSeed(3L);
//     int var9 = var1.nextInt(4, 9);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var1.nextT((-0.4833507072637169d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 9);
// 
//   }

  public void test350() {}
//   public void test350() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test350"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextSecureInt(2, 10);
//     var1.reSeed(3L);
//     int var9 = var1.nextInt(4, 9);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var1.nextInt(29, 10);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 9);
// 
//   }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test351"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(0.6725605152305536d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9592475867535211d);

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test352"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(0.686579669341957d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7567741732634853d);

  }

  public void test353() {}
//   public void test353() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test353"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextSecureInt(2, 10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("c", "");
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 7);
// 
//   }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test354"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(1.688298438952937d, 6.658240041118693E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-2.3123547476369948E-4d));

  }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test355"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(10.000001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 10.000002f);

  }

  public void test356() {}
//   public void test356() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test356"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ((-0.2590796335125806d), 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test357"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    java.lang.String var3 = var1.toString();
    java.lang.String var4 = var1.name();
    java.lang.Class var5 = var1.getDeclaringClass();
    java.lang.String var6 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "AVERAGE"+ "'", var3.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "AVERAGE"+ "'", var4.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "AVERAGE"+ "'", var6.equals("AVERAGE"));

  }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test358"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(0.9215012794164503d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8074933757497784d);

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test359"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(10000, 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 41.26320996706553d);

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test360"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(2.361841710139455d, 3.4372222997317032d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.6020406313070579d);

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test361"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(1);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = var1.copy();
    int var3 = var2.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test362"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(0.9592475867535211d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7646011298895667d);

  }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test363"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(0.037062153555774406d, (-0.2386431858481304d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.3060553039878718d));

  }

  public void test364() {}
//   public void test364() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test364"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos((-1.0185982056725795d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test365() {}
//   public void test365() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test365"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     var1.reSeedSecure(10L);
//     double var9 = var1.nextF(1.0d, 47.71468531505997d);
//     long var12 = var1.nextSecureLong(1L, 10L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("5ebbbe32e7a320e83f", "2068346a96");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.39114833491453044d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 8L);
// 
//   }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test366"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(40320L, 477733L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 19262194560L);

  }

  public void test367() {}
//   public void test367() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test367"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     var1.reSeedSecure(10L);
//     double var9 = var1.nextF(1.0d, 47.71468531505997d);
//     long var12 = var1.nextSecureLong(1L, 10L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var1.nextChiSquare((-14.334846207121842d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.2680030484777771d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 5L);
// 
//   }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test368"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 15);

  }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test369"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(4.315213397797969d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.3418258826721026d);

  }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test370"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(2.4823187300238665d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 10.968985112160745d);

  }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test371"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getNumericalMean();
    double[] var9 = var3.sample(1);
    double var11 = var3.density(979.3393873505228d);
    var3.reseedRandomGenerator(0L);
    double var14 = var3.sample();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var16 = var3.inverseCumulativeProbability(2.8174083705609023d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.322456124528837d);

  }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test372"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(14, (-1431655765));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1431655779);

  }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test373"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    java.lang.String var4 = var2.toString();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var5 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "AVERAGE"+ "'", var4.equals("AVERAGE"));

  }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test374"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0, (java.lang.Number)100.0d, (java.lang.Number)(short)0);
    java.lang.Number var4 = var3.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 100.0d+ "'", var4.equals(100.0d));

  }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test375"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor((-0.24076193928529432d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test376"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(1431655779, 29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1431655779);

  }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test377"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var1 = null;
    org.apache.commons.math3.exception.NullArgumentException var2 = new org.apache.commons.math3.exception.NullArgumentException(var0, var1);
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.OutOfRangeException var7 = new org.apache.commons.math3.exception.OutOfRangeException(var3, (java.lang.Number)10.0d, (java.lang.Number)1L, (java.lang.Number)1);
    java.lang.Number var8 = var7.getHi();
    java.lang.Number var9 = var7.getHi();
    var2.addSuppressed((java.lang.Throwable)var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 1+ "'", var8.equals(1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + 1+ "'", var9.equals(1));

  }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test378"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(1.417956092243527d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test379"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(1.6574543343244341d, 45.82685605718666d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.1384588012921568E10d);

  }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test380"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos((-0.43684372706947217d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 69.74306029434739d);

  }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test381"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    int var4 = var3.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = var3.copy();
    var3.setNumElements(15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test382"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(6627890308811632801L, 1307674368000L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test383"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog(21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 45.38013889847691d);

  }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test384"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan((-0.6740495597759653d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.7988667594075136d));

  }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test385"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, var1, var2, (java.lang.Number)17);

  }

  public void test386() {}
//   public void test386() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test386"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.686579669341957d, 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test387"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(0.3646904086155498d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.3109275960372989d);

  }

  public void test388() {}
//   public void test388() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test388"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     double var7 = var1.nextCauchy(0.15560730683937996d, 3.1780538303479458d);
//     long var9 = var1.nextPoisson(1.5707963267948966d);
//     int var12 = var1.nextInt(0, 7);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("17f8789cc43bb2106dfbda8a540d6d9b774b8ed025f9ccf3a610e661aacb917f64a8802d7a68fd069f87939570a60c437206", "");
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 4.041390647312441d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 7);
// 
//   }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test389"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3);

  }

  public void test390() {}
//   public void test390() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test390"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextSecureInt(2, 10);
//     double var7 = var1.nextCauchy(0.037062153555774406d, 3.5247804145401362d);
//     double var10 = var1.nextBeta(0.7607318203617716d, 2.6489183762783663d);
//     double var13 = var1.nextGamma((-0.016483723377414404d), (-2.3306405007995967d));
//     var1.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.2475823134422788d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.11634237698850738d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-3.487382421758058d));
// 
//   }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test391"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh(0.9999999999998969d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 15.297919505711578d);

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test392"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.08772462544619851d, 0.0d, 1.3485725592600977d, 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);

  }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test393"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)10.0d, (java.lang.Number)1L, (java.lang.Number)1);
    java.lang.Number var5 = var4.getHi();
    org.apache.commons.math3.exception.NumberIsTooLargeException var9 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10.0d, (java.lang.Number)1.0f, true);
    java.lang.Number var10 = var9.getMax();
    var4.addSuppressed((java.lang.Throwable)var9);
    java.lang.Number var12 = var4.getLo();
    java.lang.Number var13 = var4.getArgument();
    java.lang.Number var14 = var4.getLo();
    java.lang.Number var15 = var4.getLo();
    java.lang.Number var16 = var4.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1+ "'", var5.equals(1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + 1.0f+ "'", var10.equals(1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 1L+ "'", var12.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + 10.0d+ "'", var13.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + 1L+ "'", var14.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + 1L+ "'", var15.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + 1L+ "'", var16.equals(1L));

  }

  public void test394() {}
//   public void test394() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test394"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy var1 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var1);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var2.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var2.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var5 = var2.getNanStrategy();
//     double[] var8 = new double[] { 0.0d, 100.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
//     double var11 = var9.getElement(0);
//     double[] var12 = var9.getElements();
//     float var13 = var9.getExpansionFactor();
//     double[] var16 = new double[] { 0.0d, 100.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var17 = new org.apache.commons.math3.util.ResizableDoubleArray(var16);
//     var17.setElement(3, (-0.7853981633974483d));
//     double[] var21 = var17.getElements();
//     var9.addElements(var21);
//     double[] var23 = var2.rank(var21);
// 
//   }

  public void test395() {}
//   public void test395() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test395"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     double var7 = var1.nextCauchy(0.15560730683937996d, 3.1780538303479458d);
//     long var9 = var1.nextPoisson(1.5707963267948966d);
//     var1.reSeed(101L);
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution(979.3393873505228d, 8.00736706798333d);
//     double var15 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var18 = var1.nextSecureInt(100, 2);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-3.8345032841501547d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 5L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 968.8343073325332d);
// 
//   }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test396"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(3L, 81L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-5278486589563110205L));

  }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test397"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(9.536743E-7f, 10.000002f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.536743E-7f);

  }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test398"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(10L, 102L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2L);

  }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test399"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getNumericalMean();
    double[] var9 = var3.sample(1);
    double var11 = var3.density(979.3393873505228d);
    double var13 = var3.density(3921225.0d);
    boolean var14 = var3.isSupportLowerBoundInclusive();
    double var15 = var3.getMean();
    double var16 = var3.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == Double.NEGATIVE_INFINITY);

  }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test400"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(9.536744E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test401"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(10.0f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10.0f);

  }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test402"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd((-5278486589563110205L), (-7227766516491148288L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test403"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck((-7227766516491148288L), 70L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-7227766516491148358L));

  }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test404"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var5 = var3.getElement(0);
    int var6 = var3.start();
    int var7 = var3.getExpansionMode();
    org.apache.commons.math3.util.ResizableDoubleArray var8 = var3.copy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var8.setExpansionMode(1399408455);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test405"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)355687428096000L, (java.lang.Number)48.674113367678494d, (java.lang.Number)0.08076789388642387d);

  }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test406"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm((-1), 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test407"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)1.3485725592600977d);

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test408"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(1.7334893091042638d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9867946630223895d);

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test409"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(2.9708636732544953d, (-38.38421194679636d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.9708636732544953d);

  }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test410"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(1);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = var1.copy();
    var1.contract();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test411"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    int var4 = var1.nextZipf(100, 10.0d);
    var1.reSeedSecure(10L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var9 = var1.nextLong(9223372036854775807L, 19262194560L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test412"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(18, 2.5f);
    var2.contract();
    double[] var4 = var2.getElements();
    int var5 = var2.getExpansionMode();
    int var6 = var2.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test413"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    int var4 = var3.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = var3.copy();
    var3.setExpansionFactor(1.0000001f);
    double var9 = var3.substituteMostRecentElement((-3.889934788209016d));
    var3.contract();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var12 = var3.getElement(17);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 100.0d);

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test414"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(18, 2.5f);
    var2.setElement(38, 0.08772462544619851d);

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test415"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(38L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 38L);

  }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test416"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getNumericalMean();
    double[] var9 = var3.sample(1);
    double var11 = var3.density(979.3393873505228d);
    double var13 = var3.density(3921225.0d);
    boolean var14 = var3.isSupportLowerBoundInclusive();
    double var15 = var3.getNumericalMean();
    boolean var16 = var3.isSupportUpperBoundInclusive();
    double var17 = var3.getSupportUpperBound();
    double var18 = var3.getMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1.3235780930645504d);

  }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test417"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(1030301L, (-40250L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 990051L);

  }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test418"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getNumericalMean();
    double[] var9 = var3.sample(15);
    boolean var10 = var3.isSupportLowerBoundInclusive();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var12 = var3.sample(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test419"); }


    double var2 = org.apache.commons.math3.util.FastMath.max((-2.0278706351190294d), 3.69593234647658d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.69593234647658d);

  }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test420"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.7646011298895667d, 1.3440585709080678E43d, 0.40669696534821026d);

  }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test421"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp((-3.7772236948708247d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.022886142218984447d);

  }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test422"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)1.3418258826721026d);
    java.lang.Number var3 = var2.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));

  }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test423"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(2.589870215356601d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.605207487501684d);

  }

  public void test424() {}
//   public void test424() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test424"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     var1.reSeedSecure(10L);
//     double var9 = var1.nextCauchy(1.762747174039086d, 0.025803565724757293d);
//     java.util.Collection var10 = null;
//     java.lang.Object[] var12 = var1.nextSample(var10, 5);
// 
//   }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test425"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(21, (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-21));

  }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test426"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-3L), 17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-129140163L));

  }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test427"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(9.536743E-7f, 1.0000001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.536743E-7f);

  }

  public void test428() {}
//   public void test428() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test428"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
//     java.lang.String var4 = var2.toString();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var5 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var2);
//     org.apache.commons.math3.distribution.NormalDistribution var8 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 0.5866841190102328d);
//     double[] var10 = var8.sample(3);
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
//     double var17 = var14.cumulativeProbability(0.0d, 0.1690925369322372d);
//     double var18 = var14.getNumericalMean();
//     double[] var20 = var14.sample(1);
//     double var22 = var14.density(979.3393873505228d);
//     double var24 = var14.density(3921225.0d);
//     double[] var26 = var14.sample(10000);
//     double var27 = var5.mannWhitneyU(var10, var26);
// 
//   }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test429"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(1491846144, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1491846144);

  }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test430"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getNumericalMean();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var9 = var3.sample(1399408473);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.3235780930645504d);

  }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test431"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(10.968985112160745d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 628.4765524686446d);

  }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test432"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(58347, 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 58343);

  }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test433"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians((-0.38108667823090486d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.006651217270617489d));

  }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test434"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.05525892401327309d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-5));

  }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test435"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)10.0d, (java.lang.Number)1L, (java.lang.Number)1);
    java.lang.Number var5 = var4.getArgument();
    java.lang.Number var6 = var4.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 10.0d+ "'", var5.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 1+ "'", var6.equals(1));

  }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test436"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.730978507528758d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7445215087468096d);

  }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test437"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0986122886681098d);

  }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test438"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var5 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10.0d, (java.lang.Number)1.0f, true);
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    java.lang.Object[] var9 = new java.lang.Object[] { (short)1};
    org.apache.commons.math3.exception.MathArithmeticException var10 = new org.apache.commons.math3.exception.MathArithmeticException(var7, var9);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var5, var6, var9);
    java.lang.Throwable[] var12 = var5.getSuppressed();
    org.apache.commons.math3.exception.MathArithmeticException var13 = new org.apache.commons.math3.exception.MathArithmeticException(var1, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.MathArithmeticException var14 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test439"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)69.74306029434739d, (java.lang.Number)0.4105991453937372d, (java.lang.Number)0.4105991453937372d);

  }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test440"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(990051L, 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 970448963025102651L);

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test441"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint((-0.07380793801109557d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.0d));

  }

  public void test442() {}
//   public void test442() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test442"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     double var7 = var1.nextCauchy(0.15560730683937996d, 3.1780538303479458d);
//     long var9 = var1.nextPoisson(1.5707963267948966d);
//     var1.reSeed(101L);
//     var1.reSeed(70L);
//     double var15 = var1.nextExponential(48.674113367678494d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 6.443881309850754d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 3L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 168.45284854576104d);
// 
//   }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test443"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh((-0.5109473648972219d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1333982703353287d);

  }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test444"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-0.8309074630677628d), (java.lang.Number)(-1.777309158100993d), true);
    org.apache.commons.math3.exception.NumberIsTooLargeException var8 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10.0d, (java.lang.Number)1.0f, true);
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    java.lang.Object[] var12 = new java.lang.Object[] { (short)1};
    org.apache.commons.math3.exception.MathArithmeticException var13 = new org.apache.commons.math3.exception.MathArithmeticException(var10, var12);
    org.apache.commons.math3.exception.MathIllegalStateException var14 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var8, var9, var12);
    org.apache.commons.math3.exception.MathInternalError var15 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var8);
    var4.addSuppressed((java.lang.Throwable)var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test445"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var8 = var3.cumulativeProbability(10.0d);
    double var9 = var3.getNumericalVariance();
    double var10 = var3.getNumericalMean();
    var3.reseedRandomGenerator(102L);
    double var13 = var3.getNumericalVariance();
    boolean var14 = var3.isSupportLowerBoundInclusive();
    double[] var16 = var3.sample(21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 6.658240041118693E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 6.658240041118693E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test446() {}
//   public void test446() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test446"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var5 = new org.apache.commons.math3.exception.OutOfRangeException(var1, (java.lang.Number)10.0d, (java.lang.Number)1L, (java.lang.Number)1);
//     java.lang.Number var6 = var5.getHi();
//     org.apache.commons.math3.exception.NumberIsTooLargeException var10 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10.0d, (java.lang.Number)1.0f, true);
//     java.lang.Number var11 = var10.getMax();
//     var5.addSuppressed((java.lang.Throwable)var10);
//     java.lang.Throwable[] var13 = var5.getSuppressed();
//     org.apache.commons.math3.exception.NullArgumentException var14 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var13);
//     org.apache.commons.math3.exception.util.ExceptionContext var15 = var14.getContext();
//     org.apache.commons.math3.exception.util.Localizable var16 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy var17 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy var18 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy var19 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var21 = var20.getTiesStrategy();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var22 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var19, var21);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var18, var21);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var24 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var17, var21);
//     org.apache.commons.math3.exception.NumberIsTooLargeException var28 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-0.11387786884182144d), (java.lang.Number)979.3393873505228d, true);
//     org.apache.commons.math3.exception.MathInternalError var29 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var28);
//     boolean var30 = var21.equals((java.lang.Object)var28);
//     org.apache.commons.math3.exception.util.Localizable var31 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var35 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)10000, (java.lang.Number)1.3440585709080678E43d, true);
//     org.apache.commons.math3.exception.util.Localizable var36 = null;
//     org.apache.commons.math3.exception.util.Localizable var37 = null;
//     org.apache.commons.math3.exception.util.Localizable var38 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy[] var39 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
//     org.apache.commons.math3.exception.MathIllegalArgumentException var40 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var38, (java.lang.Object[])var39);
//     org.apache.commons.math3.exception.MathInternalError var41 = new org.apache.commons.math3.exception.MathInternalError(var37, (java.lang.Object[])var39);
//     org.apache.commons.math3.exception.MathIllegalStateException var42 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var35, var36, (java.lang.Object[])var39);
//     org.apache.commons.math3.exception.MathIllegalStateException var43 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var28, var31, (java.lang.Object[])var39);
//     org.apache.commons.math3.exception.MathIllegalStateException var44 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var14, var16, (java.lang.Object[])var39);
// 
//   }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test447"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var3 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var2);
    java.lang.String var4 = var2.name();
    java.lang.Class var5 = var2.getDeclaringClass();
    java.lang.Enum var7 = java.lang.Enum.<java.lang.Enum>valueOf(var5, "AVERAGE");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var9 = java.lang.Enum.<java.lang.Enum>valueOf(var5, "959e7d74b527fae3cd8d1947430516e29e8a75a9b271dff39200aa1a17fa0b646148ce36723ef17f1f94a72ba258d41dc969");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "AVERAGE"+ "'", var4.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test448() {}
//   public void test448() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test448"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.log((-0.9880458431278127d), 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test449"); }


    long var2 = org.apache.commons.math3.util.FastMath.max((-40250L), (-5278486589563110205L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-40250L));

  }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test450"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs((-20));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 20);

  }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test451"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(1.3440585709080678E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.6661404377193025E21d);

  }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test452"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double[] var4 = var3.getElements();
    double[] var5 = var3.getInternalValues();
    int var6 = var3.start();
    var3.contract();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);

  }

  public void test453() {}
//   public void test453() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test453"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextSecureInt(2, 10);
//     double var7 = var1.nextCauchy(0.037062153555774406d, 3.5247804145401362d);
//     double var10 = var1.nextBeta(0.7607318203617716d, 2.6489183762783663d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var1.nextWeibull(0.007895180433873628d, (-1.194247194430087d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 7.629357783860926d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.08412171154994892d);
// 
//   }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test454"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(8.985875073756691d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 8.985875073756691d);

  }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test455"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4E-45f);

  }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test456"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-9.602370808556296d), (java.lang.Number)1.762747174039086d, false);
    boolean var4 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test457"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(19.804501413383605d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.9901174614615124E8d);

  }

  public void test458() {}
//   public void test458() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test458"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(1.561776313341697d, (-5.370559615655605d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test459"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)3.0d);

  }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test460"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0f);

  }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test461"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin((-0.20109115859833598d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.20247170671153375d));

  }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test462"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test463"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getStandardDeviation();
    double var9 = var3.cumulativeProbability(4.157279707691014d);
    double var11 = var3.probability((-0.549132653311572d));
    double var12 = var3.getNumericalVariance();
    double var13 = var3.getMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.025803565724757293d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 6.658240041118693E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1.3235780930645504d);

  }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test464"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(1431655772, 4.0f, 1.0f, (-1431655765));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test465"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var5 = var3.getElement(0);
    int var6 = var3.getNumElements();
    int var7 = var3.getExpansionMode();
    double var9 = var3.substituteMostRecentElement(1.5707963267948966d);
    java.lang.Object var10 = null;
    boolean var11 = var3.equals(var10);
    var3.contract();
    double[] var15 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray(var15);
    double var18 = var16.getElement(0);
    int var19 = var16.getNumElements();
    int var20 = var16.getExpansionMode();
    double var22 = var16.substituteMostRecentElement(1.5707963267948966d);
    java.lang.Object var23 = null;
    boolean var24 = var16.equals(var23);
    var16.contract();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var3, var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);

  }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test466"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 17);

  }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test467"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)33.595489456385046d, var1, false);

  }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test468"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(477733L, 70L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 477803L);

  }

  public void test469() {}
//   public void test469() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test469"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     double var7 = var1.nextCauchy(0.15560730683937996d, 3.1780538303479458d);
//     double var11 = var1.nextUniform((-0.6740495597759653d), (-0.016482976994642014d), true);
//     int var14 = var1.nextPascal(5, 0.9864231484692195d);
//     double var17 = var1.nextUniform((-2.0832984452539125d), 0.060647843842351036d);
//     int var21 = var1.nextHypergeometric(8, 2, 5);
//     var1.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 5.649970281277403d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.563322524538508d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-0.008727371957788256d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0);
// 
//   }

  public void test470() {}
//   public void test470() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test470"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.log((-0.3738789406485615d), 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test471"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(709139L, 20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1040868107005177007L));

  }

  public void test472() {}
//   public void test472() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test472"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     double var7 = var1.nextCauchy(0.15560730683937996d, 3.1780538303479458d);
//     double var11 = var1.nextUniform((-0.6740495597759653d), (-0.016482976994642014d), true);
//     int var14 = var1.nextPascal(5, 0.9864231484692195d);
//     var1.reSeedSecure();
//     int var18 = var1.nextInt(0, 7);
//     long var20 = var1.nextPoisson(71.34241022211371d);
//     double var22 = var1.nextChiSquare(0.08772462544619851d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var25 = var1.nextWeibull(0.3646904086155498d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-6.611667943328182d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.529912721278556d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 62L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0.0d);
// 
//   }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test473"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(20, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 12.126791314602455d);

  }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test474"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var5 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var4);
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var4);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var7 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var4);
    org.apache.commons.math3.exception.NumberIsTooLargeException var11 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-0.11387786884182144d), (java.lang.Number)979.3393873505228d, true);
    org.apache.commons.math3.exception.MathInternalError var12 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var11);
    boolean var13 = var4.equals((java.lang.Object)var11);
    org.apache.commons.math3.exception.util.Localizable var14 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var18 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)10000, (java.lang.Number)1.3440585709080678E43d, true);
    org.apache.commons.math3.exception.util.Localizable var19 = null;
    org.apache.commons.math3.exception.util.Localizable var20 = null;
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var22 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MathIllegalArgumentException var23 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var21, (java.lang.Object[])var22);
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var20, (java.lang.Object[])var22);
    org.apache.commons.math3.exception.MathIllegalStateException var25 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var18, var19, (java.lang.Object[])var22);
    org.apache.commons.math3.exception.MathIllegalStateException var26 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var11, var14, (java.lang.Object[])var22);
    java.lang.Number var27 = var11.getMax();
    org.apache.commons.math3.exception.NumberIsTooLargeException var31 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10.0d, (java.lang.Number)1.0f, true);
    org.apache.commons.math3.exception.util.Localizable var32 = null;
    org.apache.commons.math3.exception.util.Localizable var33 = null;
    java.lang.Object[] var35 = new java.lang.Object[] { (short)1};
    org.apache.commons.math3.exception.MathArithmeticException var36 = new org.apache.commons.math3.exception.MathArithmeticException(var33, var35);
    org.apache.commons.math3.exception.MathIllegalStateException var37 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var31, var32, var35);
    org.apache.commons.math3.exception.NumberIsTooLargeException var41 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10L, (java.lang.Number)3921225.0d, true);
    var31.addSuppressed((java.lang.Throwable)var41);
    java.lang.String var43 = var41.toString();
    java.lang.Number var44 = var41.getArgument();
    var11.addSuppressed((java.lang.Throwable)var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + 979.3393873505228d+ "'", var27.equals(979.3393873505228d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var43 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (3,921,225)"+ "'", var43.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (3,921,225)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var44 + "' != '" + 10L+ "'", var44.equals(10L));

  }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test475"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getNumericalMean();
    double[] var9 = var3.sample(1);
    double var11 = var3.density(979.3393873505228d);
    var3.reseedRandomGenerator(0L);
    double[] var15 = var3.sample(10);
    boolean var16 = var3.isSupportUpperBoundInclusive();
    double var18 = var3.cumulativeProbability(60.06124336900233d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1.0d);

  }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test476"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(1.1920929E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-23));

  }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test477"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(0.7105235543492688d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6522307253250917d);

  }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test478"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getNumericalMean();
    double[] var9 = var3.sample(1);
    double var11 = var3.density(979.3393873505228d);
    double[] var13 = var3.sample(2);
    boolean var14 = var3.isSupportConnected();
    double var15 = var3.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 6.658240041118693E-4d);

  }

  public void test479() {}
//   public void test479() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test479"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(3.1780538303479458d);
//     double var5 = var1.nextExponential(19.39006869589386d);
//     var1.reSeedSecure();
//     double var8 = var1.nextExponential(1.3261490724357603d);
//     int[] var11 = var1.nextPermutation(3, 3);
//     long var14 = var1.nextLong(9L, 10L);
//     java.util.Collection var15 = null;
//     java.lang.Object[] var17 = var1.nextSample(var15, 17);
// 
//   }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test480"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(343642L, (-1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 343641L);

  }

  public void test481() {}
//   public void test481() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test481"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.log(2.127929429721528d, (-0.7988667594075136d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test482"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck((-98), 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-9800));

  }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test483"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(1.1920929E-7f, 1.3506254701664102d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.192093E-7f);

  }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test484"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(0, 9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test485"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)10.0d, (java.lang.Number)1L, (java.lang.Number)1);
    java.lang.Number var5 = var4.getHi();
    java.lang.Number var6 = var4.getLo();
    java.lang.Throwable[] var7 = var4.getSuppressed();
    org.apache.commons.math3.exception.util.ExceptionContext var8 = var4.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1+ "'", var5.equals(1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 1L+ "'", var6.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test486"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(0.8793310149527617d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.9908614038474906d);

  }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test487"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    java.lang.String var3 = var1.toString();
    java.lang.String var4 = var1.name();
    java.lang.String var5 = var1.name();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "AVERAGE"+ "'", var3.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "AVERAGE"+ "'", var4.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "AVERAGE"+ "'", var5.equals("AVERAGE"));

  }

  public void test488() {}
//   public void test488() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test488"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.0d, 1.9908614038474906d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test489() {}
//   public void test489() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test489"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy var1 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var3 = var2.getTiesStrategy();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var3);
//     java.lang.String var5 = var3.name();
//     java.lang.Class var6 = var3.getDeclaringClass();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var7 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var3);
//     double[] var10 = new double[] { 0.0d, 100.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var10);
//     double[] var12 = var11.getElements();
//     double[] var13 = var11.getInternalValues();
//     org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var13);
//     double[] var17 = new double[] { 0.0d, 100.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray(var17);
//     var18.setElement(3, (-0.7853981633974483d));
//     var18.discardMostRecentElements(0);
//     double[] var26 = new double[] { 0.0d, 100.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var27 = new org.apache.commons.math3.util.ResizableDoubleArray(var26);
//     double var29 = var27.getElement(0);
//     double[] var30 = var27.getInternalValues();
//     var18.addElements(var30);
//     double var32 = var7.mannWhitneyUTest(var13, var30);
// 
//   }

  public void test490() {}
//   public void test490() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test490"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.hypot(0.9152952197546206d, Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test491"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)1.0143302387887994d);

  }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test492"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(5.081775104347323d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 8.881784197001252E-16d);

  }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test493"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 0.5866841190102328d);
    double var5 = var2.cumulativeProbability(0.0d, 0.037062153555774406d);
    var2.reseedRandomGenerator(19262194560L);
    double var9 = var2.probability(0.44124929225463694d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.025185327490526228d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);

  }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test494"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)10.000001f, (java.lang.Number)0.9254962739500686d, (java.lang.Number)11013.232920103323d);
    java.lang.Number var5 = var4.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.9254962739500686d+ "'", var5.equals(0.9254962739500686d));

  }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test495"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 0.5866841190102328d);
    double[] var4 = var2.sample(3);
    boolean var5 = var2.isSupportLowerBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test496"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(17, 2.5f);
    var2.discardFrontElements(0);
    var2.setElement(1763, 1.2967094728211648d);

  }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test497"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var3.setElement(3, (-0.7853981633974483d));
    var3.contract();
    var3.contract();
    double[] var11 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var11);
    double var14 = var12.getElement(0);
    var12.addElement(0.5403023058681398d);
    var12.discardFrontElements(0);
    double[] var19 = var12.getInternalValues();
    var3.addElements(var19);
    var3.addElement(0.060647843842351036d);
    var3.contract();
    int var24 = var3.getExpansionMode();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);

  }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test498"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(-0.11387786884182144d));
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var4 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var5 = new org.apache.commons.math3.exception.NullArgumentException(var3, (java.lang.Object[])var4);
    var2.addSuppressed((java.lang.Throwable)var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test499() {}
//   public void test499() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test499"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(11.093291396075893d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test500"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("ede9f08");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

}
