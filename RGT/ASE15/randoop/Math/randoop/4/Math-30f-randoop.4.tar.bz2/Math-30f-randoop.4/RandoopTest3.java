
import junit.framework.*;

public class RandoopTest3 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test1"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    java.lang.String var6 = var4.toString();
    java.lang.String var7 = var4.name();
    java.lang.Class var8 = var4.getDeclaringClass();
    java.lang.Enum var10 = java.lang.Enum.<java.lang.Enum>valueOf(var8, "AVERAGE");
    boolean var11 = var1.equals((java.lang.Object)var10);
    java.lang.Class var12 = var10.getDeclaringClass();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "AVERAGE"+ "'", var6.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "AVERAGE"+ "'", var7.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test2"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(1.059294183193564d, 1.0986122886681098d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0653284629007906d);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test3"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(3L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3L);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test4"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(0, 21);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test5() {}
//   public void test5() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test5"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.sqrt((-67.37989615938413d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test6"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(0.9999999999998969d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5430806348151225d);

  }

  public void test7() {}
//   public void test7() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test7"); }
// 
// 
//     org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10.0d, (java.lang.Number)1.0f, true);
//     org.apache.commons.math3.exception.util.Localizable var4 = null;
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     java.lang.Object[] var7 = new java.lang.Object[] { (short)1};
//     org.apache.commons.math3.exception.MathArithmeticException var8 = new org.apache.commons.math3.exception.MathArithmeticException(var5, var7);
//     org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, var7);
//     org.apache.commons.math3.exception.NumberIsTooLargeException var13 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10L, (java.lang.Number)3921225.0d, true);
//     var3.addSuppressed((java.lang.Throwable)var13);
//     java.lang.Number var15 = var3.getMax();
//     java.lang.Throwable var16 = null;
//     var3.addSuppressed(var16);
// 
//   }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test8"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(2.1928027555236245d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.5707963267948966d);

  }

  public void test9() {}
//   public void test9() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test9"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     double var7 = var1.nextCauchy(0.15560730683937996d, 3.1780538303479458d);
//     double var11 = var1.nextUniform((-0.6740495597759653d), (-0.016482976994642014d), true);
//     int var14 = var1.nextPascal(5, 0.9864231484692195d);
//     double var17 = var1.nextUniform((-2.0832984452539125d), 0.060647843842351036d);
//     int var21 = var1.nextHypergeometric(8, 2, 5);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var24 = var1.nextCauchy(1.059294183193564d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.9621450702576992d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.11383106658879229d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-0.5496660245984387d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0);
// 
//   }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test10"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(1.302408900530079d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.3024089005300792d);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test11"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(10463584, 7.378698E20f, 10.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test12"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    java.lang.String var3 = var1.toString();
    java.lang.String var4 = var1.name();
    org.apache.commons.math3.distribution.NormalDistribution var8 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var11 = var8.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var12 = var8.getNumericalMean();
    double[] var14 = var8.sample(15);
    boolean var15 = var8.isSupportLowerBoundInclusive();
    boolean var16 = var1.equals((java.lang.Object)var8);
    double var18 = var8.probability(42.19646737175651d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "AVERAGE"+ "'", var3.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "AVERAGE"+ "'", var4.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test13"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var5 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var4);
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var4);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var7 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var4);
    org.apache.commons.math3.exception.NumberIsTooLargeException var11 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-0.11387786884182144d), (java.lang.Number)979.3393873505228d, true);
    org.apache.commons.math3.exception.MathInternalError var12 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var11);
    boolean var13 = var4.equals((java.lang.Object)var11);
    java.lang.String var14 = var4.name();
    java.lang.String var15 = var4.name();
    java.lang.Class var16 = var4.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var18 = java.lang.Enum.<java.lang.Enum>valueOf(var16, "5ebbbe32e7a320e83f");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "AVERAGE"+ "'", var14.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "AVERAGE"+ "'", var15.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test14"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(348476L, (-7227766516491148288L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test15"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(970448963025102651L, (-3L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 970448963025102651L);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test16"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin((-0.8390715290764524d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.7440230792707043d));

  }

  public void test17() {}
//   public void test17() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test17"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ((-0.7988667594075136d), 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test18"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(3.2563639434140504E-7d, 1.1384588012921568E10d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9999996325586766d);

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test19"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, var1, (java.lang.Number)100.0f, false);
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
    java.lang.Number var6 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 100.0f+ "'", var6.equals(100.0f));

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test20"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh((-0.2386431858481304d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.24333486561039752d));

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test21"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var8 = var3.cumulativeProbability(10.0d);
    double var9 = var3.getNumericalVariance();
    double var10 = var3.getMean();
    double var11 = var3.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 6.658240041118693E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 6.658240041118693E-4d);

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test22"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(5.208924279490875d, 248.820958136101d);

  }

  public void test23() {}
//   public void test23() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test23"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     var1.reSeedSecure(10L);
//     double var9 = var1.nextF(1.0d, 47.71468531505997d);
//     int var12 = var1.nextZipf(18, 0.049034116126541086d);
//     var1.reSeed();
//     int var16 = var1.nextSecureInt(7, 10463584);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2.121343718047379d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 7558349);
// 
//   }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test24"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var5 = null;
    java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 0L);
    java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 0L);
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 8);
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, var9);
    java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, 17);
    java.math.BigInteger var16 = org.apache.commons.math3.util.ArithmeticUtils.pow(var14, 2);
    java.math.BigInteger var18 = org.apache.commons.math3.util.ArithmeticUtils.pow(var14, 18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test25() {}
//   public void test25() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test25"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextSecureInt(2, 10);
//     var1.reSeed(3L);
//     java.lang.String var8 = var1.nextSecureHexString(18);
//     var1.reSeed();
//     double var11 = var1.nextChiSquare(1.2863038544739316E-112d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var1.nextHypergeometric(5, (-9800), 2);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "2eb8f0735348835ce2"+ "'", var8.equals("2eb8f0735348835ce2"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
// 
//   }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test26"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)2.6225756482573077d, (java.lang.Number)14.104332570968813d, (java.lang.Number)1.5407439555097887E-33d);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test27"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(0.0d, 3.2563639434140504E-7d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test28"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(3, 1861);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5583);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test29"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getNumericalMean();
    double[] var9 = var3.sample(1);
    double var11 = var3.density(979.3393873505228d);
    double var13 = var3.density(3921225.0d);
    double[] var15 = var3.sample(10000);
    var3.reseedRandomGenerator(201L);
    boolean var18 = var3.isSupportLowerBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test30() {}
//   public void test30() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test30"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.random.RandomGenerator var1 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var1);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var2.getNanStrategy();
//     double[] var4 = null;
//     double[] var5 = var2.rank(var4);
// 
//   }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test31"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(8, 4.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = var2.substituteMostRecentElement((-1.777309158100993d));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException");
    } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
      // Expected exception.
    }

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test32"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var5 = null;
    java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 0L);
    java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 0L);
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 8);
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, var9);
    java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, 3);
    java.math.BigInteger var16 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, 352277L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test33"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.43914693321042364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5513832203590072d);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test34"); }


    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(4, 2.0f, 10.000002f);

  }

  public void test35() {}
//   public void test35() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test35"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.max((-0.6206008190792572d), Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test36"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(0.7929931743433503d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test37() {}
//   public void test37() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test37"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     double var7 = var1.nextCauchy(0.15560730683937996d, 3.1780538303479458d);
//     var1.reSeed(101L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var1.nextBeta((-0.3738789406485615d), 0.21452323545111215d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 10.930406203726623d);
// 
//   }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test38"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var5 = var3.getElement(0);
    double[] var6 = var3.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(10);
    double var10 = var8.addElementRolling((-20.34054861465728d));
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var3, var8);
    int var12 = var8.getExpansionMode();
    var8.clear();
    int var14 = var8.getNumElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);

  }

  public void test39() {}
//   public void test39() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test39"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(3.1780538303479458d);
//     double var5 = var1.nextExponential(19.39006869589386d);
//     double var8 = var1.nextBeta(4.499378297809863d, 1.8328655053227587d);
//     int var12 = var1.nextHypergeometric(3, 0, 2);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var1.nextWeibull(1.059294183193564d, (-3.487382421758058d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 9.184514549156695d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 12.147927080115508d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.8237548421215815d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
// 
//   }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test40"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh(0.705287720983563d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8777447858790949d);

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test41"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getStandardDeviation();
    double var9 = var3.cumulativeProbability(4.157279707691014d);
    double var11 = var3.probability((-0.549132653311572d));
    double var13 = var3.cumulativeProbability(0.6225116311094179d);
    double var15 = var3.probability(0.6034852839804553d);
    double var17 = var3.probability((-0.3556025929135851d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.025803565724757293d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);

  }

  public void test42() {}
//   public void test42() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test42"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     double var7 = var1.nextCauchy(0.15560730683937996d, 3.1780538303479458d);
//     long var9 = var1.nextPoisson(1.5707963267948966d);
//     var1.reSeed(101L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var1.nextUniform(34.29040217973706d, 0.3569670254374492d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 5.290803276315234d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1L);
// 
//   }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test43"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double[] var4 = var3.getElements();
    double[] var5 = var3.getInternalValues();
    int var6 = var3.start();
    double[] var7 = var3.getInternalValues();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setContractionCriteria(4.7683716E-7f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test44"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)(-1.0d), var2, (java.lang.Number)100.0f);
    java.lang.Number var5 = var4.getHi();
    java.lang.Number var6 = var4.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 100.0f+ "'", var5.equals(100.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test45() {}
//   public void test45() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test45"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextSecureInt(2, 10);
//     double var7 = var1.nextCauchy(0.037062153555774406d, 3.5247804145401362d);
//     double var9 = var1.nextChiSquare(8.00736706798333d);
//     int var12 = var1.nextPascal(9, 0.686579669341957d);
//     double var14 = var1.nextExponential(2.140641475065075d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var17 = var1.nextUniform(25.19122118273868d, 0.3646904086155498d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.8383317570289559d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 11.658705965664025d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.748681170278762d);
// 
//   }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test46"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    java.lang.String var3 = var1.toString();
    java.lang.String var4 = var1.name();
    org.apache.commons.math3.distribution.NormalDistribution var8 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var11 = var8.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var12 = var8.getNumericalMean();
    double[] var14 = var8.sample(15);
    boolean var15 = var8.isSupportLowerBoundInclusive();
    boolean var16 = var1.equals((java.lang.Object)var8);
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.TiesStrategy var18 = var17.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var19 = var17.getTiesStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "AVERAGE"+ "'", var3.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "AVERAGE"+ "'", var4.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test47"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(29, 108576323);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test48() {}
//   public void test48() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test48"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(3.1780538303479458d);
//     double var5 = var1.nextExponential(19.39006869589386d);
//     double var7 = var1.nextChiSquare(2.1928027555236245d);
//     long var10 = var1.nextSecureLong((-1040868107005177007L), 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.919033887853235d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 25.074431327212167d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.4113184637563598d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-796666328165262592L));
// 
//   }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test49"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(40320L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test50"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1567, 9.536744E-7f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test51"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var2.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var2.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var2.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var2.getNanStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test52"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1.1519447188851685E-11d, (java.lang.Number)1.7334893091042638d, true);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test53"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(12.492495498705182d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0064416999674073d);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test54"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(1540232095);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1540232095);

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test55"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(Float.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2147483647);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test56"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(1564);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test57"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck((-1431655765), 7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1431655772));

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test58"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var5 = var3.getElement(0);
    double[] var6 = var3.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = var3.copy();
    var3.addElement(3.657242590218247d);
    org.apache.commons.math3.util.ResizableDoubleArray var10 = var3.copy();
    int var11 = var10.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test59"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var3.setElement(3, (-0.7853981633974483d));
    float var7 = var3.getContractionCriteria();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setContractionCriteria((-1.0f));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.5f);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test60"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.9999998885745217d, (java.lang.Number)0.34943406609505034d, false);
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test61"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var5 = var3.getElement(0);
    int var6 = var3.getNumElements();
    var3.contract();
    double var9 = var3.substituteMostRecentElement(4.754806993644028d);
    boolean var11 = var3.equals((java.lang.Object)0.0010231502395483475d);
    float var12 = var3.getContractionCriteria();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 2.5f);

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test62"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.0d, 25.074431327212167d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 25.074431327212167d);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test63"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    int var4 = var3.getNumElements();
    int var5 = var3.getExpansionMode();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setExpansionFactor(1.192093E-7f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test64"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.distribution.NormalDistribution var5 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var8 = var5.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var9 = var5.getNumericalMean();
    double[] var11 = var5.sample(1);
    double var13 = var5.density(979.3393873505228d);
    double var15 = var5.density(3921225.0d);
    boolean var16 = var5.isSupportLowerBoundInclusive();
    double[] var18 = var5.sample(4);
    double[] var19 = var1.rank(var18);
    org.apache.commons.math3.stat.ranking.NaNStrategy var20 = var1.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var21 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var22 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var24 = var23.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var25 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var22, var24);
    java.lang.String var26 = var24.name();
    java.lang.Class var27 = var24.getDeclaringClass();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var28 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var21, var24);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var29 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var20, var24);
    org.apache.commons.math3.stat.ranking.NaNStrategy var30 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var31 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var32 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var33 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var34 = var33.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var35 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var32, var34);
    org.apache.commons.math3.stat.ranking.NaturalRanking var36 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var31, var34);
    org.apache.commons.math3.stat.ranking.NaturalRanking var37 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var30, var34);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var38 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var20, var34);
    double[] var41 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var42 = new org.apache.commons.math3.util.ResizableDoubleArray(var41);
    var42.discardMostRecentElements(0);
    double[] var45 = var42.getElements();
    org.apache.commons.math3.distribution.NormalDistribution var49 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var52 = var49.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var53 = var49.getNumericalMean();
    double[] var55 = var49.sample(15);
    org.apache.commons.math3.util.ResizableDoubleArray var56 = new org.apache.commons.math3.util.ResizableDoubleArray(var55);
    double var57 = var38.mannWhitneyU(var45, var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + "AVERAGE"+ "'", var26.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 15.0d);

  }

  public void test65() {}
//   public void test65() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test65"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(3.1780538303479458d);
//     double var5 = var1.nextExponential(19.39006869589386d);
//     double var8 = var1.nextBeta(4.499378297809863d, 1.8328655053227587d);
//     int var11 = var1.nextBinomial(14, 0.0d);
//     double var15 = var1.nextUniform(1.893344644644389d, 3.0d, false);
//     java.util.Collection var16 = null;
//     java.lang.Object[] var18 = var1.nextSample(var16, 1399408473);
// 
//   }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test66"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var3 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MathIllegalArgumentException var4 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, (java.lang.Object[])var3);
    org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError(var1, (java.lang.Object[])var3);
    org.apache.commons.math3.exception.MathArithmeticException var6 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var3);
    org.apache.commons.math3.exception.util.ExceptionContext var7 = var6.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test67"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb((-0.99999994f), (-21));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-4.7683713E-7f));

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test68"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getNumericalMean();
    double var8 = var3.getMean();
    boolean var9 = var3.isSupportUpperBoundInclusive();
    double var11 = var3.probability(1.7792833636531957d);
    boolean var12 = var3.isSupportLowerBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test69"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin((-0.4543072568479274d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.4715944350633355d));

  }

  public void test70() {}
//   public void test70() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test70"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     var1.reSeedSecure(10L);
//     double var9 = var1.nextCauchy(1.762747174039086d, 0.025803565724757293d);
//     double var11 = var1.nextExponential(6.938893903907228E-18d);
//     int var15 = var1.nextHypergeometric(5, 0, 0);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var19 = var1.nextHypergeometric(0, 27, 29);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.7923415179004323d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 6.8689037667368865E-18d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0);
// 
//   }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test71"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(0.2400570802362589d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 13.754257539771002d);

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test72"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var5 = var3.getElement(0);
    double[] var6 = var3.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = var3.copy();
    var3.addElement(3.657242590218247d);
    org.apache.commons.math3.util.ResizableDoubleArray var10 = var3.copy();
    double[] var11 = var3.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test73"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(0.99999994f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test74"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(0.0f, (-23));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test75"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter((-0.35149565402094446d), 3.079921804415884d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.3514956540209444d));

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test76"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var2 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MathIllegalArgumentException var3 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, (java.lang.Object[])var2);
    org.apache.commons.math3.exception.NullArgumentException var4 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test77"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(10.000001f, 1.0000001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10.000001f);

  }

  public void test78() {}
//   public void test78() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test78"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     var1.reSeedSecure(10L);
//     double var9 = var1.nextF(1.0d, 47.71468531505997d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var1.nextHypergeometric(10463584, 1431655779, 3);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.7877171292097009d);
// 
//   }

  public void test79() {}
//   public void test79() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test79"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     double var7 = var1.nextCauchy(0.15560730683937996d, 3.1780538303479458d);
//     double var11 = var1.nextUniform((-0.6740495597759653d), (-0.016482976994642014d), true);
//     int var14 = var1.nextPascal(5, 0.9864231484692195d);
//     var1.reSeedSecure();
//     int var18 = var1.nextInt(0, 7);
//     long var20 = var1.nextPoisson(71.34241022211371d);
//     double var22 = var1.nextChiSquare(0.08772462544619851d);
//     double var24 = var1.nextT(4.021374286912368d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 5.879598775599154d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.4766013146398294d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 85L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0.20531383856295668d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0.20398377488506508d);
// 
//   }

  public void test80() {}
//   public void test80() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test80"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextSecureInt(2, 10);
//     double var7 = var1.nextCauchy(0.037062153555774406d, 3.5247804145401362d);
//     double var9 = var1.nextChiSquare(8.00736706798333d);
//     java.util.Collection var10 = null;
//     java.lang.Object[] var12 = var1.nextSample(var10, (-20));
// 
//   }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test81"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(6);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    java.lang.Object var3 = null;
    boolean var4 = var1.equals(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test82"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(11.28403526992695d, 0.7641028487401796d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 11.30987644213712d);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test83"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(1);
    var1.setElement(0, (-0.9880458431278127d));
    var1.setNumElements(9);
    var1.contract();

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test84"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0L);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test85"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(70L, 76817L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-76747L));

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test86"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(1.1638480075030244d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1638480075030244d);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test87"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(355687428096000L, 42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test88"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var5 = var3.getElement(0);
    double[] var6 = var3.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(10);
    double var10 = var8.addElementRolling((-20.34054861465728d));
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var3, var8);
    int var12 = var8.getNumElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 2);

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test89"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(1399408473, 263);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 263);

  }

  public void test90() {}
//   public void test90() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test90"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(3.1780538303479458d);
//     double var5 = var1.nextExponential(19.39006869589386d);
//     var1.reSeedSecure();
//     double var8 = var1.nextExponential(1.3261490724357603d);
//     int[] var11 = var1.nextPermutation(3, 3);
//     int var14 = var1.nextBinomial(29, 0.956037264045509d);
//     double var17 = var1.nextCauchy((-0.16759298660669747d), 1.605207487501684d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.5018178535811711d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2.9225484517515947d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.24292849342982767d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 2.0839634641424114d);
// 
//   }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test91"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(0.0d, 1399408482);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test92"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var8 = var3.cumulativeProbability(10.0d);
    double var9 = var3.getNumericalVariance();
    double var10 = var3.getNumericalMean();
    var3.reseedRandomGenerator(102L);
    double var14 = var3.density(0.9535776039139491d);
    boolean var15 = var3.isSupportLowerBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 6.658240041118693E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 3.4793013433993797E-44d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test93"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var3.setElement(3, (-0.7853981633974483d));
    var3.contract();
    var3.contract();
    double[] var11 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var11);
    double var14 = var12.getElement(0);
    var12.addElement(0.5403023058681398d);
    var12.discardFrontElements(0);
    double[] var19 = var12.getInternalValues();
    var3.addElements(var19);
    var3.addElement(0.060647843842351036d);
    var3.contract();
    var3.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var25 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var27 = var25.getElement(17);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test94() {}
//   public void test94() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test94"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
//     double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
//     double var7 = var3.getNumericalMean();
//     double[] var9 = var3.sample(1);
//     double var10 = var3.sample();
//     double var11 = var3.getSupportLowerBound();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.3235780930645504d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.3682859760506667d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == Double.NEGATIVE_INFINITY);
// 
//   }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test95"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)Float.POSITIVE_INFINITY);
    java.lang.Number var3 = var2.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + Float.POSITIVE_INFINITY+ "'", var3.equals(Float.POSITIVE_INFINITY));

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test96"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(4.883582255643798E-9d, 0.7099849575852162d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6.878430596971689E-9d);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test97"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var8 = var3.cumulativeProbability(10.0d);
    double var9 = var3.getNumericalVariance();
    double var10 = var3.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 6.658240041118693E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == Double.NEGATIVE_INFINITY);

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test98"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(34.24420874191639d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.9513184727710529d));

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test99"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(1.702737351127573d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test100() {}
//   public void test100() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test100"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(3.1780538303479458d);
//     double var6 = var1.nextWeibull(968.8343073325332d, 0.9149287324253481d);
//     double var9 = var1.nextGaussian(0.0d, Double.POSITIVE_INFINITY);
//     var1.reSeed((-7227766516491148288L));
//     var1.reSeed(0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.9865912406801023d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.9154580050030031d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == Double.NEGATIVE_INFINITY);
// 
//   }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test101"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-2.672797868849784d), 10.923276331316844d);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test102"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(1.7792833636531957d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 8.668128447986332d);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test103"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var6 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10.0d, (java.lang.Number)1.0f, true);
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    java.lang.Object[] var10 = new java.lang.Object[] { (short)1};
    org.apache.commons.math3.exception.MathArithmeticException var11 = new org.apache.commons.math3.exception.MathArithmeticException(var8, var10);
    org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var6, var7, var10);
    java.lang.Throwable[] var13 = var6.getSuppressed();
    org.apache.commons.math3.exception.MathInternalError var14 = new org.apache.commons.math3.exception.MathInternalError(var2, (java.lang.Object[])var13);
    org.apache.commons.math3.exception.MathInternalError var15 = new org.apache.commons.math3.exception.MathInternalError(var1, (java.lang.Object[])var13);
    org.apache.commons.math3.exception.MathInternalError var16 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test104"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var3 = var2.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3);
    java.lang.String var5 = var3.toString();
    java.lang.String var6 = var3.name();
    org.apache.commons.math3.distribution.NormalDistribution var10 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var13 = var10.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var14 = var10.getNumericalMean();
    double[] var16 = var10.sample(15);
    boolean var17 = var10.isSupportLowerBoundInclusive();
    boolean var18 = var3.equals((java.lang.Object)var10);
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3);
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var3);
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var3);
    java.lang.Class var22 = var3.getDeclaringClass();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "AVERAGE"+ "'", var5.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "AVERAGE"+ "'", var6.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test105() {}
//   public void test105() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test105"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var6 = new org.apache.commons.math3.exception.OutOfRangeException(var2, (java.lang.Number)10.0d, (java.lang.Number)1L, (java.lang.Number)1);
//     java.lang.Number var7 = var6.getHi();
//     org.apache.commons.math3.exception.NumberIsTooLargeException var11 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10.0d, (java.lang.Number)1.0f, true);
//     java.lang.Number var12 = var11.getMax();
//     var6.addSuppressed((java.lang.Throwable)var11);
//     java.lang.Throwable[] var14 = var6.getSuppressed();
//     org.apache.commons.math3.exception.NullArgumentException var15 = new org.apache.commons.math3.exception.NullArgumentException(var1, (java.lang.Object[])var14);
//     org.apache.commons.math3.exception.MathIllegalStateException var16 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var14);
//     org.apache.commons.math3.exception.util.Localizable var17 = null;
//     org.apache.commons.math3.exception.util.Localizable var18 = null;
//     java.lang.Object[] var20 = new java.lang.Object[] { (byte)1};
//     org.apache.commons.math3.exception.MathIllegalStateException var21 = new org.apache.commons.math3.exception.MathIllegalStateException(var18, var20);
//     org.apache.commons.math3.exception.MathIllegalStateException var22 = new org.apache.commons.math3.exception.MathIllegalStateException(var17, var20);
//     var16.addSuppressed((java.lang.Throwable)var22);
//     org.apache.commons.math3.exception.util.ExceptionContext var24 = var16.getContext();
//     org.apache.commons.math3.exception.util.Localizable var25 = null;
//     org.apache.commons.math3.exception.util.Localizable var26 = null;
//     org.apache.commons.math3.exception.util.Localizable var27 = null;
//     org.apache.commons.math3.exception.util.Localizable var28 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var32 = new org.apache.commons.math3.exception.OutOfRangeException(var28, (java.lang.Number)10.0d, (java.lang.Number)1L, (java.lang.Number)1);
//     java.lang.Number var33 = var32.getHi();
//     org.apache.commons.math3.exception.NumberIsTooLargeException var37 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10.0d, (java.lang.Number)1.0f, true);
//     java.lang.Number var38 = var37.getMax();
//     var32.addSuppressed((java.lang.Throwable)var37);
//     java.lang.Throwable[] var40 = var32.getSuppressed();
//     org.apache.commons.math3.exception.NullArgumentException var41 = new org.apache.commons.math3.exception.NullArgumentException(var27, (java.lang.Object[])var40);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var42 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var26, (java.lang.Object[])var40);
//     org.apache.commons.math3.exception.MathIllegalStateException var43 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var16, var25, (java.lang.Object[])var40);
// 
//   }

  public void test106() {}
//   public void test106() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test106"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(1.8640991091503671d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test107() {}
//   public void test107() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test107"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
//     org.apache.commons.math3.distribution.NormalDistribution var5 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
//     double var8 = var5.cumulativeProbability(0.0d, 0.1690925369322372d);
//     double var9 = var5.getNumericalMean();
//     double[] var11 = var5.sample(1);
//     double var13 = var5.density(979.3393873505228d);
//     double var15 = var5.density(3921225.0d);
//     boolean var16 = var5.isSupportLowerBoundInclusive();
//     double[] var18 = var5.sample(4);
//     double[] var19 = var1.rank(var18);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var20 = var1.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var21 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy var22 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var24 = var23.getTiesStrategy();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var25 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var22, var24);
//     java.lang.String var26 = var24.name();
//     java.lang.Class var27 = var24.getDeclaringClass();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var28 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var21, var24);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var29 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var20, var24);
//     double[] var32 = new double[] { 0.0d, 100.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var33 = new org.apache.commons.math3.util.ResizableDoubleArray(var32);
//     double var35 = var33.getElement(0);
//     int var36 = var33.getNumElements();
//     int var37 = var33.getExpansionMode();
//     double var39 = var33.substituteMostRecentElement(1.5707963267948966d);
//     java.lang.Object var40 = null;
//     boolean var41 = var33.equals(var40);
//     var33.contract();
//     org.apache.commons.math3.util.ResizableDoubleArray var43 = var33.copy();
//     org.apache.commons.math3.random.RandomGenerator var44 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var45 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var44);
//     org.apache.commons.math3.distribution.NormalDistribution var49 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
//     double var52 = var49.cumulativeProbability(0.0d, 0.1690925369322372d);
//     double var53 = var49.getNumericalMean();
//     double[] var55 = var49.sample(1);
//     double var57 = var49.density(979.3393873505228d);
//     double var59 = var49.density(3921225.0d);
//     boolean var60 = var49.isSupportLowerBoundInclusive();
//     double[] var62 = var49.sample(4);
//     double[] var63 = var45.rank(var62);
//     var33.addElements(var62);
//     org.apache.commons.math3.distribution.NormalDistribution var68 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
//     double var71 = var68.cumulativeProbability(0.0d, 0.1690925369322372d);
//     double var73 = var68.cumulativeProbability(10.0d);
//     double var74 = var68.getNumericalVariance();
//     double var75 = var68.getNumericalMean();
//     double[] var77 = var68.sample(7);
//     double var78 = var29.mannWhitneyU(var62, var77);
//     double[] var79 = null;
//     org.apache.commons.math3.util.ResizableDoubleArray var82 = new org.apache.commons.math3.util.ResizableDoubleArray(18, 2.5f);
//     var82.contract();
//     double[] var84 = var82.getElements();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var85 = var29.mannWhitneyU(var79, var84);
//       fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
//     } catch (org.apache.commons.math3.exception.NullArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.3235780930645504d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var26 + "' != '" + "AVERAGE"+ "'", var26.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 1.3235780930645504d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var71 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var73 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var74 == 6.658240041118693E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var75 == 1.3235780930645504d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var78 == 18.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var84);
// 
//   }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test108"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(11.332278829291482d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 41736.51351813645d);

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test109"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(1552, 27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1552);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test110"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-67.37989615938413d), (java.lang.Number)(-1.3173720911599616d), true);
    java.lang.Number var5 = var4.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-67.37989615938413d)+ "'", var5.equals((-67.37989615938413d)));

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test111"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(979.3393873505228d, 8.00736706798333d);
    boolean var3 = var2.isSupportConnected();
    double[] var5 = var2.sample(2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test112"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray((-1431655765), 7.378698E20f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test113"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(1.7006991033646932d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.477775584762308d);

  }

  public void test114() {}
//   public void test114() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test114"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(3.1780538303479458d);
//     double var5 = var1.nextExponential(19.39006869589386d);
//     var1.reSeedSecure(9223372036854775807L);
//     var1.reSeedSecure(2L);
//     var1.reSeed();
//     int var13 = var1.nextBinomial(100, 0.0d);
//     var1.reSeedSecure(100L);
//     var1.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.361344537390401d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 3.777231596997706d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0);
// 
//   }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test115"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var3.setElement(3, (-0.7853981633974483d));
    double[] var7 = var3.getElements();
    float var8 = var3.getExpansionFactor();
    double var10 = var3.addElementRolling((-0.6740495597759653d));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.discardFrontElements(20);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test116"); }


    double var1 = org.apache.commons.math3.special.Gamma.logGamma(2.3062436640636736d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.15794646568933812d);

  }

  public void test117() {}
//   public void test117() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test117"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     var1.reSeedSecure(10L);
//     double var9 = var1.nextF(1.0d, 47.71468531505997d);
//     double var11 = var1.nextT(4.810477380965351d);
//     double var14 = var1.nextGamma(0.7641028487401796d, 0.0d);
//     int var17 = var1.nextZipf(161, 34.24420874191639d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.7294195667689811d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.9429808773691619d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
// 
//   }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test118"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var3.setElement(3, (-0.7853981633974483d));
    var3.contract();
    var3.contract();
    double[] var11 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var11);
    double var14 = var12.getElement(0);
    var12.addElement(0.5403023058681398d);
    var12.discardFrontElements(0);
    double[] var19 = var12.getInternalValues();
    var3.addElements(var19);
    org.apache.commons.math3.util.ResizableDoubleArray var21 = new org.apache.commons.math3.util.ResizableDoubleArray(var19);
    org.apache.commons.math3.util.ResizableDoubleArray var22 = new org.apache.commons.math3.util.ResizableDoubleArray(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test119() {}
//   public void test119() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test119"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     var1.reSeedSecure(10L);
//     double var9 = var1.nextF(1.0d, 47.71468531505997d);
//     long var12 = var1.nextSecureLong(1L, 10L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var14 = var1.nextHexString(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.6939030171481448d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 4L);
// 
//   }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test120"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var5 = var3.getElement(0);
    var3.setElement(4, (-0.8309074630677628d));
    int var9 = var3.getExpansionMode();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test121"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble(17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.55687428096E14d);

  }

  public void test122() {}
//   public void test122() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test122"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextSecureInt(2, 10);
//     double var8 = var1.nextUniform(3.1780538303479458d, 4.810477380965351d, false);
//     java.lang.String var10 = var1.nextHexString(1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 4.6650348313788585d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "7"+ "'", var10.equals("7"));
// 
//   }

  public void test123() {}
//   public void test123() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test123"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(3.1780538303479458d);
//     double var5 = var1.nextExponential(19.39006869589386d);
//     var1.reSeedSecure(9223372036854775807L);
//     var1.reSeedSecure(2L);
//     var1.reSeed();
//     java.lang.String var12 = var1.nextHexString(7);
//     double var14 = var1.nextT(2.8627981112072765d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var17 = var1.nextSecureInt(263, (-196));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.4075622729938797d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 6.560576512736663d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "de78303"+ "'", var12.equals("de78303"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.793909134860017d);
// 
//   }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test124"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(1.7926162465313784E-18d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.7926162465313784E-18d);

  }

  public void test125() {}
//   public void test125() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test125"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh((-0.11387786884182144d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test126"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)(-0.016483723377414404d), (java.lang.Number)10000);
    java.lang.Number var4 = var3.getLo();
    java.lang.Number var5 = var3.getHi();
    java.lang.Number var6 = var3.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (-0.016483723377414404d)+ "'", var4.equals((-0.016483723377414404d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 10000+ "'", var5.equals(10000));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 10000+ "'", var6.equals(10000));

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test127"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(2.5f, 1.40737488E14f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.5f);

  }

  public void test128() {}
//   public void test128() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test128"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     double var7 = var1.nextCauchy(0.15560730683937996d, 3.1780538303479458d);
//     double var10 = var1.nextBeta(8.985875073756691d, 1.7792833636531957d);
//     int[] var13 = var1.nextPermutation(14, 6);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var16 = var1.nextSecureLong(1307673890267L, 1061208L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-2.3399888301378584d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.8449786328071343d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
// 
//   }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test129"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getStandardDeviation();
    double var9 = var3.cumulativeProbability(4.157279707691014d);
    double var11 = var3.probability((-0.549132653311572d));
    double var12 = var3.getNumericalVariance();
    double var13 = var3.getNumericalVariance();
    double var15 = var3.probability(658.6791243661528d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.025803565724757293d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 6.658240041118693E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 6.658240041118693E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test130"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)10.0d, (java.lang.Number)1L, (java.lang.Number)1);
    java.lang.Number var5 = var4.getHi();
    org.apache.commons.math3.exception.NumberIsTooLargeException var9 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10.0d, (java.lang.Number)1.0f, true);
    java.lang.Number var10 = var9.getMax();
    var4.addSuppressed((java.lang.Throwable)var9);
    java.lang.Number var12 = var4.getLo();
    java.lang.Number var13 = var4.getArgument();
    java.lang.Number var14 = var4.getLo();
    java.lang.Number var15 = var4.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1+ "'", var5.equals(1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + 1.0f+ "'", var10.equals(1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 1L+ "'", var12.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + 10.0d+ "'", var13.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + 1L+ "'", var14.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + 10.0d+ "'", var15.equals(10.0d));

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test131"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getNumericalMean();
    double[] var9 = var3.sample(1);
    double var11 = var3.density(979.3393873505228d);
    double var13 = var3.density(3921225.0d);
    double[] var15 = var3.sample(10000);
    var3.reseedRandomGenerator(201L);
    double var18 = var3.getStandardDeviation();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var20 = var3.sample(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.025803565724757293d);

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test132"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var3 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalArgumentException var4 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, (java.lang.Object[])var3);
    org.apache.commons.math3.exception.MathArithmeticException var5 = new org.apache.commons.math3.exception.MathArithmeticException(var1, (java.lang.Object[])var3);
    org.apache.commons.math3.exception.NullArgumentException var6 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test133"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(-0.9880458431278127d));

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test134"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var5 = var3.getElement(0);
    int var6 = var3.getNumElements();
    int var7 = var3.getExpansionMode();
    double var9 = var3.substituteMostRecentElement(1.5707963267948966d);
    java.lang.Object var10 = null;
    boolean var11 = var3.equals(var10);
    double[] var14 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    var15.setElement(3, (-0.7853981633974483d));
    float var19 = var15.getContractionCriteria();
    boolean var20 = var3.equals((java.lang.Object)var15);
    double[] var21 = var15.getInternalValues();
    var15.setNumElements(7558349);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test135"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("5105a9c0a6b2a82017");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test136() {}
//   public void test136() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test136"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     double var7 = var1.nextCauchy(0.15560730683937996d, 3.1780538303479458d);
//     double var11 = var1.nextUniform((-0.6740495597759653d), (-0.016482976994642014d), true);
//     int var14 = var1.nextPascal(5, 0.9864231484692195d);
//     var1.reSeedSecure();
//     double var18 = var1.nextGamma(5.410266968958382d, (-20.34054861465728d));
//     java.lang.String var20 = var1.nextHexString(58347);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 12.888106616310557d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.3310798590234192d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-91.67579480422823d));
// 
//   }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test137"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(18, 2.5f);
    int var3 = var2.getExpansionMode();
    double[] var6 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    double var9 = var7.getElement(0);
    int var10 = var7.getNumElements();
    int var11 = var7.getExpansionMode();
    double var13 = var7.addElementRolling((-0.21452323545111215d));
    int var14 = var7.start();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var2, var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test138"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.distribution.NormalDistribution var5 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var8 = var5.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var9 = var5.getNumericalMean();
    double[] var11 = var5.sample(1);
    double var13 = var5.density(979.3393873505228d);
    double var15 = var5.density(3921225.0d);
    boolean var16 = var5.isSupportLowerBoundInclusive();
    double[] var18 = var5.sample(4);
    double[] var19 = var1.rank(var18);
    org.apache.commons.math3.stat.ranking.NaNStrategy var20 = var1.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20);
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20);
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test139"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var3.discardFrontElements(2);
    var3.addElement(0.0d);
    double[] var8 = var3.getElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test140"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var5 = var3.getElement(0);
    int var6 = var3.start();
    int var7 = var3.getExpansionMode();
    org.apache.commons.math3.util.ResizableDoubleArray var8 = var3.copy();
    var3.setExpansionFactor(2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test141() {}
//   public void test141() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test141"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     java.util.Collection var5 = null;
//     java.lang.Object[] var7 = var1.nextSample(var5, 7);
// 
//   }

  public void test142() {}
//   public void test142() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test142"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     var1.reSeedSecure(10L);
//     double var9 = var1.nextF(1.0d, 47.71468531505997d);
//     double var13 = var1.nextUniform(0.3404631721379325d, 1.5707963267948966d, false);
//     double var16 = var1.nextBeta(0.33034911277798823d, 1.3024089005300792d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.011496821869134213d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.4379038493140889d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.09205319082947833d);
// 
//   }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test143"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble((-23));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test144() {}
//   public void test144() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test144"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     double var7 = var1.nextCauchy(0.15560730683937996d, 3.1780538303479458d);
//     double var11 = var1.nextUniform((-0.6740495597759653d), (-0.016482976994642014d), true);
//     int var14 = var1.nextPascal(5, 0.9864231484692195d);
//     var1.reSeedSecure();
//     double var18 = var1.nextGamma(5.410266968958382d, (-20.34054861465728d));
//     int var21 = var1.nextSecureInt((-196), 6);
//     long var24 = var1.nextLong(100L, 201L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.546330226060174d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.06762901280105516d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-80.83448551745833d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == (-27));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 159L);
// 
//   }

  public void test145() {}
//   public void test145() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test145"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(1.0584618047656464d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test146() {}
//   public void test146() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test146"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextSecureInt(2, 10);
//     var1.reSeed(3L);
//     double var9 = var1.nextCauchy(1.2285491878461101d, 0.05525892401327309d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.3275400505729926d);
// 
//   }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test147"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getNumericalMean();
    double[] var9 = var3.sample(1);
    double var11 = var3.density(979.3393873505228d);
    double var13 = var3.density(3921225.0d);
    double[] var15 = var3.sample(10000);
    var3.reseedRandomGenerator(201L);
    double var18 = var3.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 6.658240041118693E-4d);

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test148"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(100, 522115706);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test149() {}
//   public void test149() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test149"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(3.1780538303479458d);
//     double var5 = var1.nextExponential(19.39006869589386d);
//     var1.reSeedSecure(9223372036854775807L);
//     long var10 = var1.nextLong(38L, 201L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 6.802378138932291d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 16.191116807682942d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 75L);
// 
//   }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test150"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)0.025803565724757293d);
    java.lang.Number var2 = var1.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0.025803565724757293d+ "'", var2.equals(0.025803565724757293d));

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test151"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(Float.POSITIVE_INFINITY, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.POSITIVE_INFINITY);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test152"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var5 = var3.getElement(0);
    var3.setElement(4, (-0.8309074630677628d));
    double var10 = var3.substituteMostRecentElement(6.938893903907228E-18d);
    boolean var12 = var3.equals((java.lang.Object)(-0.7333114255659123d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-0.8309074630677628d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test153"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(28.744463535493573d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5016855304138128d);

  }

  public void test154() {}
//   public void test154() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test154"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     var1.reSeedSecure(10L);
//     double var9 = var1.nextF(1.0d, 47.71468531505997d);
//     var1.reSeed(1L);
//     long var14 = var1.nextLong((-7227766516491148358L), 349189L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var18 = var1.nextHypergeometric(1431657535, 0, (-71));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 3.1122173158378454d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-6701751110436810752L));
// 
//   }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test155"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    double[] var3 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.setElement(3, (-0.7853981633974483d));
    int var8 = var4.getNumElements();
    java.lang.Object[] var9 = new java.lang.Object[] { var8};
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var9);
    org.apache.commons.math3.exception.util.ExceptionContext var11 = var10.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test156"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.distribution.NormalDistribution var5 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var8 = var5.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var9 = var5.getNumericalMean();
    double[] var11 = var5.sample(1);
    double var13 = var5.density(979.3393873505228d);
    double var15 = var5.density(3921225.0d);
    boolean var16 = var5.isSupportLowerBoundInclusive();
    double[] var18 = var5.sample(4);
    double[] var19 = var1.rank(var18);
    org.apache.commons.math3.stat.ranking.NaNStrategy var20 = var1.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20);
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20);
    org.apache.commons.math3.stat.ranking.TiesStrategy var23 = var22.getTiesStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test157"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(0, 20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-20));

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test158"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var5 = var3.getElement(0);
    int var6 = var3.getNumElements();
    org.apache.commons.math3.exception.MaxCountExceededException var8 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)1.8328655053227587d);
    org.apache.commons.math3.exception.util.ExceptionContext var9 = var8.getContext();
    boolean var10 = var3.equals((java.lang.Object)var8);
    int var11 = var3.start();
    var3.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test159"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(2147483647, (-1.0f), 10.000001f, 100);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test160"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1.3682859760506667d, (java.lang.Number)2.266703980515175d, false);

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test161"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(10);
    double var3 = var1.addElementRolling((-20.34054861465728d));
    int var4 = var1.start();
    int var5 = var1.getExpansionMode();
    float var6 = var1.getExpansionFactor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setContractionCriteria(5.9604645E-8f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.0f);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test162"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10.0d, (java.lang.Number)1.0f, true);
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    java.lang.Object[] var7 = new java.lang.Object[] { (short)1};
    org.apache.commons.math3.exception.MathArithmeticException var8 = new org.apache.commons.math3.exception.MathArithmeticException(var5, var7);
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, var7);
    org.apache.commons.math3.exception.NumberIsTooLargeException var13 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10L, (java.lang.Number)3921225.0d, true);
    var3.addSuppressed((java.lang.Throwable)var13);
    org.apache.commons.math3.exception.util.ExceptionContext var15 = var13.getContext();
    java.lang.Number var16 = var13.getArgument();
    java.lang.Number var17 = var13.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + 10L+ "'", var16.equals(10L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + 10L+ "'", var17.equals(10L));

  }

  public void test163() {}
//   public void test163() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test163"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(3.1780538303479458d);
//     double var5 = var1.nextExponential(19.39006869589386d);
//     var1.reSeedSecure(9223372036854775807L);
//     var1.reSeedSecure(2L);
//     var1.reSeed();
//     java.lang.String var12 = var1.nextHexString(7);
//     long var14 = var1.nextPoisson(0.4148624190190518d);
//     double var17 = var1.nextCauchy(1.0438509658141657d, 0.3013419654212052d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 4.075167575736332d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 17.820927645830835d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "73ea34e"+ "'", var12.equals("73ea34e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.8705693994405159d);
// 
//   }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test164"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.distribution.NormalDistribution var5 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var8 = var5.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var9 = var5.getNumericalMean();
    double[] var11 = var5.sample(1);
    double var13 = var5.density(979.3393873505228d);
    double var15 = var5.density(3921225.0d);
    boolean var16 = var5.isSupportLowerBoundInclusive();
    double[] var18 = var5.sample(4);
    double[] var19 = var1.rank(var18);
    org.apache.commons.math3.stat.ranking.NaNStrategy var20 = var1.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var21 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20, var21);
    org.apache.commons.math3.random.RandomGenerator var23 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var23);
    org.apache.commons.math3.distribution.NormalDistribution var28 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var31 = var28.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var32 = var28.getNumericalMean();
    double[] var34 = var28.sample(1);
    double var36 = var28.density(979.3393873505228d);
    double var38 = var28.density(3921225.0d);
    boolean var39 = var28.isSupportLowerBoundInclusive();
    double[] var41 = var28.sample(4);
    double[] var42 = var24.rank(var41);
    org.apache.commons.math3.stat.ranking.NaNStrategy var43 = var24.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var44 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var45 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var46 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var47 = var46.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var48 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var45, var47);
    java.lang.String var49 = var47.name();
    java.lang.Class var50 = var47.getDeclaringClass();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var51 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var44, var47);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var52 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var43, var47);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var53 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var20, var47);
    org.apache.commons.math3.stat.ranking.NaturalRanking var54 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var55 = var54.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var56 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var55);
    java.lang.String var57 = var55.toString();
    java.lang.Class var58 = var55.getDeclaringClass();
    java.lang.String var59 = var55.toString();
    boolean var61 = var55.equals((java.lang.Object)0.05690637728745587d);
    java.lang.String var62 = var55.toString();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var63 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var20, var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var49 + "' != '" + "AVERAGE"+ "'", var49.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var57 + "' != '" + "AVERAGE"+ "'", var57.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var59 + "' != '" + "AVERAGE"+ "'", var59.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var62 + "' != '" + "AVERAGE"+ "'", var62.equals("AVERAGE"));

  }

  public void test165() {}
//   public void test165() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test165"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     double var7 = var1.nextCauchy(0.15560730683937996d, 3.1780538303479458d);
//     long var9 = var1.nextPoisson(1.5707963267948966d);
//     var1.reSeed(101L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("ba5a064cc9fb3eed21", "org.apache.commons.math3.exception.NotPositiveException: 0 is smaller than the minimum (0)");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-3.430963160403445d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 4L);
// 
//   }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test166"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(1.7453292519943295d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.24389738082415968d);

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test167"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter((-0.006651217270617489d), (-0.0072573230589590134d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.00665121727061749d));

  }

  public void test168() {}
//   public void test168() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test168"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(2.4796438758057278d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test169"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(1552, 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4);

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test170"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(0.0d, 1.4210854715202004E-14d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test171"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var4 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalArgumentException var5 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.NullArgumentException var6 = new org.apache.commons.math3.exception.NullArgumentException(var2, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.MaxCountExceededException var7 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)1.0487286688968165d, (java.lang.Object[])var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test172"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var5 = var3.getElement(0);
    int var6 = var3.getNumElements();
    int var7 = var3.getExpansionMode();
    var3.contract();
    var3.setExpansionMode(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setExpansionFactor((-1.0f));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test173"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("cb988cd6e14466a973");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test174() {}
//   public void test174() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test174"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     double var7 = var1.nextCauchy(0.15560730683937996d, 3.1780538303479458d);
//     double var11 = var1.nextUniform((-0.6740495597759653d), (-0.016482976994642014d), true);
//     int var14 = var1.nextPascal(5, 0.9864231484692195d);
//     var1.reSeedSecure();
//     int var18 = var1.nextInt(0, 7);
//     double var20 = var1.nextExponential(8.21034137237765d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-0.9481065603919439d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.45958046997408497d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 27.583377952756944d);
// 
//   }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test175"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(0.671947921623892d, 67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.916201072845585E19d);

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test176"); }


    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(18, 100.0f, 7.378698E20f);

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test177"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)10000, (java.lang.Number)1.3440585709080678E43d, true);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var8 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MathIllegalArgumentException var9 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var7, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var5, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathArithmeticException var12 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test178"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(1.4210855E-14f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.6940659E-21f);

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test179"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getNumericalMean();
    double[] var9 = var3.sample(1);
    double var11 = var3.density(979.3393873505228d);
    double var13 = var3.density(3921225.0d);
    boolean var14 = var3.isSupportLowerBoundInclusive();
    var3.reseedRandomGenerator(0L);
    double var18 = var3.density((-0.6981152095798223d));
    boolean var19 = var3.isSupportLowerBoundInclusive();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var21 = var3.sample(1398870649);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test180"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh((-1.1562769898876681d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.4317118669969366d));

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test181"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)Double.NaN, (java.lang.Number)1.7763568394002505E-15d, false);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test182"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(0.5964546144007503d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5964546144007504d);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test183"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(4.7683716E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test184"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0.8488722679890092d);

  }

  public void test185() {}
//   public void test185() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test185"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Object[] var1 = null;
//     org.apache.commons.math3.exception.NullArgumentException var2 = new org.apache.commons.math3.exception.NullArgumentException(var0, var1);
//     org.apache.commons.math3.exception.MathInternalError var3 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var2);
// 
//   }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test186"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(2.8627981112072765d, 1.6847603917884783E13d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.6992316089341568E-13d);

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test187"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(0.4379038493140889d, 8.881784197001252E-16d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.4642743809572135d));

  }

  public void test188() {}
//   public void test188() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test188"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log((-3.425465364898763d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test189"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)10.0d, (java.lang.Number)1L, (java.lang.Number)1);
    java.lang.Number var5 = var4.getHi();
    java.lang.Number var6 = var4.getLo();
    java.lang.Number var7 = var4.getLo();
    java.lang.Number var8 = var4.getHi();
    java.lang.Number var9 = var4.getLo();
    org.apache.commons.math3.exception.NumberIsTooLargeException var13 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10L, (java.lang.Number)3921225.0d, true);
    java.lang.Number var14 = var13.getMax();
    var4.addSuppressed((java.lang.Throwable)var13);
    java.lang.Number var16 = var4.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1+ "'", var5.equals(1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 1L+ "'", var6.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 1L+ "'", var7.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 1+ "'", var8.equals(1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + 1L+ "'", var9.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + 3921225.0d+ "'", var14.equals(3921225.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + 1L+ "'", var16.equals(1L));

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test190"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var3.setElement(3, (-0.7853981633974483d));
    var3.contract();
    var3.contract();
    double[] var11 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var11);
    double var14 = var12.getElement(0);
    var12.addElement(0.5403023058681398d);
    var12.discardFrontElements(0);
    double[] var19 = var12.getInternalValues();
    var3.addElements(var19);
    org.apache.commons.math3.util.ResizableDoubleArray var21 = new org.apache.commons.math3.util.ResizableDoubleArray(var19);
    double[] var22 = var21.getInternalValues();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test191"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(6);
    double[] var2 = var1.getInternalValues();
    int var3 = var1.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);

  }

  public void test192() {}
//   public void test192() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test192"); }
// 
// 
//     double var1 = org.apache.commons.math3.special.Gamma.lanczos(Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test193"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getNumericalMean();
    double[] var9 = var3.sample(1);
    double var10 = var3.getNumericalMean();
    double var12 = var3.density((-2.20725760697381d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test194"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(2.5000002f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.5000002f);

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test195"); }


    double var1 = org.apache.commons.math3.special.Gamma.logGamma(0.049034116126541086d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.9888674787143743d);

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test196"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(1.6940659E-21f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.694066E-21f);

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test197"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var7 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var3, (java.lang.Number)100.0d, (java.lang.Number)(-2.1805166473703887d), true);
    java.lang.Number var8 = var7.getArgument();
    java.lang.Throwable[] var9 = var7.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.MathInternalError var11 = new org.apache.commons.math3.exception.MathInternalError(var1, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.MathIllegalArgumentException var12 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 100.0d+ "'", var8.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test198"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var5 = var3.getElement(0);
    int var6 = var3.getNumElements();
    int var7 = var3.getExpansionMode();
    var3.contract();
    var3.setExpansionMode(0);
    var3.setExpansionFactor(2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test199"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.distribution.NormalDistribution var5 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var8 = var5.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var9 = var5.getNumericalMean();
    double[] var11 = var5.sample(1);
    double var13 = var5.density(979.3393873505228d);
    double var15 = var5.density(3921225.0d);
    boolean var16 = var5.isSupportLowerBoundInclusive();
    double[] var18 = var5.sample(4);
    double[] var19 = var1.rank(var18);
    org.apache.commons.math3.stat.ranking.TiesStrategy var20 = var1.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var21 = var1.getTiesStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test200"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.10594880406917834d, (java.lang.Number)(-2.3123547476369948E-4d), (java.lang.Number)0.9334690638538092d);

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test201"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)100.0f);
    boolean var2 = var1.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test202"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getNumericalMean();
    double[] var9 = var3.sample(1);
    double var11 = var3.density(979.3393873505228d);
    double var13 = var3.density(3921225.0d);
    boolean var14 = var3.isSupportLowerBoundInclusive();
    double var15 = var3.getMean();
    double[] var17 = var3.sample(10000);
    double var18 = var3.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1.3235780930645504d);

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test203"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(528685031872420288L, (-796666328165262592L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-267981296292842304L));

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test204"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan((-4.8505253310531895d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.193119976601626d);

  }

  public void test205() {}
//   public void test205() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test205"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(2.8260076973785733d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test206"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(4.499378297809863d, 0.0016675857736243153d, 2.038940829865108d, 21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.9999999999999939d);

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test207"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getStandardDeviation();
    double var10 = var3.cumulativeProbability(0.0d, 13.909208911282622d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.025803565724757293d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1.0d);

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test208"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(0.04562592067384483d, 3921225.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.04562592067384483d);

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test209"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray((-5), 7.3786976E20f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test210"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("f");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test211"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var3 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)1.1638480075030244d, (java.lang.Number)(-2.3306405007995967d), var3);

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test212"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(10);
    double var3 = var1.addElementRolling((-20.34054861465728d));
    var1.addElement(0.43549250150289726d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test213"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    java.lang.String var3 = var1.toString();
    java.lang.String var4 = var1.name();
    java.lang.Class var5 = var1.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "AVERAGE"+ "'", var3.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "AVERAGE"+ "'", var4.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test214"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.distribution.NormalDistribution var5 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var8 = var5.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var9 = var5.getNumericalMean();
    double[] var11 = var5.sample(1);
    double var13 = var5.density(979.3393873505228d);
    double var15 = var5.density(3921225.0d);
    boolean var16 = var5.isSupportLowerBoundInclusive();
    double[] var18 = var5.sample(4);
    double[] var19 = var1.rank(var18);
    org.apache.commons.math3.stat.ranking.NaNStrategy var20 = var1.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var21 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var22 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var24 = var23.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var25 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var22, var24);
    java.lang.String var26 = var24.name();
    java.lang.Class var27 = var24.getDeclaringClass();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var28 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var21, var24);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var29 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var20, var24);
    org.apache.commons.math3.stat.ranking.NaturalRanking var30 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var31 = var30.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var32 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var31);
    java.lang.String var33 = var31.toString();
    java.lang.String var34 = var31.name();
    org.apache.commons.math3.distribution.NormalDistribution var38 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var41 = var38.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var42 = var38.getNumericalMean();
    double[] var44 = var38.sample(15);
    boolean var45 = var38.isSupportLowerBoundInclusive();
    boolean var46 = var31.equals((java.lang.Object)var38);
    org.apache.commons.math3.stat.ranking.NaturalRanking var47 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20, var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + "AVERAGE"+ "'", var26.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var33 + "' != '" + "AVERAGE"+ "'", var33.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var34 + "' != '" + "AVERAGE"+ "'", var34.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);

  }

  public void test215() {}
//   public void test215() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test215"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(3.1780538303479458d);
//     double var5 = var1.nextExponential(19.39006869589386d);
//     var1.reSeedSecure(9223372036854775807L);
//     var1.reSeedSecure(2L);
//     var1.reSeed();
//     java.lang.String var12 = var1.nextHexString(7);
//     double var14 = var1.nextT(2.8627981112072765d);
//     int var17 = var1.nextInt((-9800), 8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.9729955278956557d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 17.0394726164075d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "c07df64"+ "'", var12.equals("c07df64"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-0.18562362377293312d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-7174));
// 
//   }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test216"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getNumericalMean();
    double[] var9 = var3.sample(1);
    double var11 = var3.density(979.3393873505228d);
    double[] var13 = var3.sample(2);
    boolean var14 = var3.isSupportConnected();
    double var16 = var3.probability(0.0d);
    double var17 = var3.getNumericalVariance();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var20 = var3.cumulativeProbability((-0.4642743809572135d), (-2.0832984452539125d));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 6.658240041118693E-4d);

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test217"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)20.664810710668892d, (java.lang.Number)477803L, false);

  }

  public void test218() {}
//   public void test218() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test218"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     double var7 = var1.nextCauchy(0.15560730683937996d, 3.1780538303479458d);
//     var1.reSeed(101L);
//     java.lang.String var11 = var1.nextSecureHexString(100);
//     var1.reSeed();
//     double var14 = var1.nextChiSquare(3.69593234647658d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-8.026745774137865d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "353cb773f7d29a0dee2c40282f8896e069af30afff3b1eef96ff21af9339c2b3bfaa1304728f5a3d3025ea46e98d37399468"+ "'", var11.equals("353cb773f7d29a0dee2c40282f8896e069af30afff3b1eef96ff21af9339c2b3bfaa1304728f5a3d3025ea46e98d37399468"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 4.172873086077649d);
// 
//   }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test219"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(2.4202055129036895d, 2.4202055129036895d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.41451009082537316d);

  }

  public void test220() {}
//   public void test220() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test220"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextSecureInt(2, 10);
//     var1.reSeed(3L);
//     java.lang.String var8 = var1.nextSecureHexString(18);
//     double var10 = var1.nextT(1.777309158100993d);
//     long var13 = var1.nextLong((-7227766516491148288L), 930313L);
//     var1.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "85a91cff8d23a33be6"+ "'", var8.equals("85a91cff8d23a33be6"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.3469938909522605d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-255076864576885600L));
// 
//   }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test221"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(0.7241199936737109d, 0.5403023058681399d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.7241199936737109d);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test222"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.9562162008454188d, 0.9927689477197732d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.378382967943188d);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test223"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(0, 46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 46);

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test224"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var5 = new org.apache.commons.math3.exception.OutOfRangeException(var1, (java.lang.Number)10.0d, (java.lang.Number)1L, (java.lang.Number)1);
    java.lang.Number var6 = var5.getHi();
    org.apache.commons.math3.exception.NumberIsTooLargeException var10 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10.0d, (java.lang.Number)1.0f, true);
    java.lang.Number var11 = var10.getMax();
    var5.addSuppressed((java.lang.Throwable)var10);
    java.lang.Throwable[] var13 = var5.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var14 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var13);
    org.apache.commons.math3.exception.util.ExceptionContext var15 = var14.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 1+ "'", var6.equals(1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + 1.0f+ "'", var11.equals(1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test225"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(100, 1.6940659E-21f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test226"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(5.081775104347323d, 5.753824499105662d);

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test227"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (1)");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test228"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(68, 1.4E-45f, 9.536743E-7f, 5);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test229"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray((-21), 1.0000001f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test230"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(0.11634237698850738d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.11608150321558243d);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test231"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent((-8.026745774137865d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3);

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test232"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)0.9093102466862683d);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test233"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt((-7.8502096530181795d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.9874387436695358d));

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test234"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(1564, (-1431655765));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1431657329);

  }

  public void test235() {}
//   public void test235() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test235"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     double var7 = var1.nextCauchy(0.15560730683937996d, 3.1780538303479458d);
//     double var11 = var1.nextUniform((-0.6740495597759653d), (-0.016482976994642014d), true);
//     long var14 = var1.nextLong(0L, 1030301L);
//     var1.reSeed();
//     java.util.Collection var16 = null;
//     java.lang.Object[] var18 = var1.nextSample(var16, 5583);
// 
//   }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test236"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getNumericalMean();
    double[] var9 = var3.sample(1);
    double var11 = var3.density(979.3393873505228d);
    double var13 = var3.density(3921225.0d);
    boolean var14 = var3.isSupportLowerBoundInclusive();
    double[] var16 = var3.sample(4);
    double var18 = var3.density(0.6725605152305536d);
    double var19 = var3.getSupportLowerBound();
    boolean var20 = var3.isSupportLowerBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 9.252005376524419E-138d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test237"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs((-0.775944101461304d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.775944101461304d);

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test238"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getNumericalMean();
    double[] var9 = var3.sample(1);
    double var11 = var3.density((-0.8390715290764524d));
    double var12 = var3.getSupportUpperBound();
    double var14 = var3.probability(5.26885534061425E-4d);
    double var15 = var3.getMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1.3235780930645504d);

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test239"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var8 = var3.cumulativeProbability(10.0d);
    double var9 = var3.getNumericalVariance();
    double[] var11 = var3.sample(14);
    double var12 = var3.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 6.658240041118693E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == Double.NEGATIVE_INFINITY);

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test240"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getNumericalMean();
    double[] var9 = var3.sample(1);
    double var11 = var3.density(979.3393873505228d);
    double var13 = var3.density(3921225.0d);
    boolean var14 = var3.isSupportLowerBoundInclusive();
    double[] var16 = var3.sample(4);
    double var18 = var3.density(0.6725605152305536d);
    double var19 = var3.getSupportLowerBound();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var21 = var3.sample(1431657535);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 9.252005376524419E-138d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == Double.NEGATIVE_INFINITY);

  }

  public void test241() {}
//   public void test241() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test241"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     java.lang.Object[] var4 = new java.lang.Object[] { (byte)1};
//     org.apache.commons.math3.exception.MathIllegalStateException var5 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, var4);
//     org.apache.commons.math3.exception.MathIllegalStateException var6 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, var4);
//     org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError(var0, var4);
//     org.apache.commons.math3.exception.util.ExceptionContext var8 = var7.getContext();
//     org.apache.commons.math3.exception.util.ExceptionContext var9 = var7.getContext();
//     org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var7);
// 
//   }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test242"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-0.009884735861183967d));

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test243"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getNumericalMean();
    double[] var9 = var3.sample(1);
    boolean var10 = var3.isSupportUpperBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test244"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(9.536743E-7f, (-4.7683713E-7f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-9.536743E-7f));

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test245"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var3 = var1.getTiesStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test246"); }


    double var2 = org.apache.commons.math3.util.FastMath.min((-2.7777495517594706d), 0.7719082228224953d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-2.7777495517594706d));

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test247"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var4 = var3.getNumericalVariance();
    double var5 = var3.getSupportLowerBound();
    double var7 = var3.cumulativeProbability(3.6661404377193025E21d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 6.658240041118693E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.0d);

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test248"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(522116695, (-9800));
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test249"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(4);

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test250"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var5 = var3.substituteMostRecentElement(1.3235780930645504d);
    double[] var8 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var3, var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test251"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck((-7), (-4));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-3));

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test252"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1((-0.49810022948185106d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.39231597600484736d));

  }

  public void test253() {}
//   public void test253() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test253"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(3.1780538303479458d);
//     double var5 = var1.nextExponential(19.39006869589386d);
//     double var8 = var1.nextBeta(4.499378297809863d, 1.8328655053227587d);
//     int var11 = var1.nextBinomial(14, 0.0d);
//     long var14 = var1.nextLong(2L, 1030301L);
//     java.util.Collection var15 = null;
//     java.lang.Object[] var17 = var1.nextSample(var15, 17);
// 
//   }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test254"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var5 = var3.getElement(0);
    int var6 = var3.getNumElements();
    int var7 = var3.getExpansionMode();
    var3.contract();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var3.getElement((-7));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test255"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck((-20), 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-25));

  }

  public void test256() {}
//   public void test256() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test256"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     var1.reSeedSecure(10L);
//     double var9 = var1.nextCauchy(1.762747174039086d, 0.025803565724757293d);
//     double var11 = var1.nextExponential(6.938893903907228E-18d);
//     double var14 = var1.nextCauchy(108.227459172826d, 0.9864231484692195d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.7770070454655067d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 7.124946134441802E-18d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 109.792947723851d);
// 
//   }

  public void test257() {}
//   public void test257() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test257"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     double var7 = var1.nextCauchy(0.15560730683937996d, 3.1780538303479458d);
//     long var9 = var1.nextPoisson(1.5707963267948966d);
//     var1.reSeed(349189L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-20.986704087523112d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2L);
// 
//   }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test258"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog((-7174), 2);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test259"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(3.5803271935147514d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9984481126619811d);

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test260"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0);
    java.lang.String var2 = var1.toString();
    boolean var3 = var1.getBoundIsAllowed();
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var7 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalArgumentException var8 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var6, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var1, var4, (java.lang.Object[])var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "org.apache.commons.math3.exception.NotPositiveException: 0 is smaller than the minimum (0)"+ "'", var2.equals("org.apache.commons.math3.exception.NotPositiveException: 0 is smaller than the minimum (0)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test261() {}
//   public void test261() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test261"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextSecureInt(2, 10);
//     var1.reSeed(3L);
//     int var9 = var1.nextInt(0, 10);
//     var1.reSeed();
//     long var12 = var1.nextPoisson(9.629750005793149d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 9L);
// 
//   }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test262"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(10);
    double[] var4 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    var5.addElement(0.11634237698850738d);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test263() {}
//   public void test263() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test263"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     double var7 = var1.nextCauchy(0.15560730683937996d, 3.1780538303479458d);
//     double var11 = var1.nextUniform((-0.6740495597759653d), (-0.016482976994642014d), true);
//     long var14 = var1.nextLong(0L, 1030301L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var17 = var1.nextF((-3.1903387268750403d), (-38.38421194679636d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.9691864735789149d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.23083937910968108d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 126246L);
// 
//   }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test264"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(0L, 5040L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test265"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(2.9888674787143743d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.47550665958964206d);

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test266"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)30.604942315720642d, (java.lang.Number)0.9867946630223895d, false);

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test267"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(2.4823187300238665d, 0.44124929225463694d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.4823187300238665d);

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test268"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(11.6178909758517d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.5351157255444883d);

  }

  public void test269() {}
//   public void test269() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test269"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     var1.reSeedSecure(10L);
//     double var9 = var1.nextF(1.0d, 47.71468531505997d);
//     long var12 = var1.nextSecureLong(1L, 10L);
//     long var15 = var1.nextSecureLong(100L, 477733L);
//     var1.reSeed(9L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("d", "b7668135312ebfb291");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.5970720890725796d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 274766L);
// 
//   }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test270"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1.6873352971776172d, (java.lang.Number)4.189149606287355d, false);
    java.lang.Throwable[] var5 = var4.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test271"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(3, 0.0f, 1.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test272() {}
//   public void test272() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test272"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     double var7 = var1.nextCauchy(0.15560730683937996d, 3.1780538303479458d);
//     int var10 = var1.nextZipf(1700, 8.881784197001252E-16d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var13 = var1.nextSecureLong(0L, (-7227766516491148288L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 106.58815799358995d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 453);
// 
//   }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test273"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(27, 522116695);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-522116668));

  }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test274"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(3.088731025128343d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9958572207816866d);

  }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test275"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var5 = var3.getElement(0);
    double[] var6 = var3.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = var3.copy();
    double var9 = var3.addElementRolling(122.7902212423532d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setExpansionFactor((-1.0f));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);

  }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test276"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(210L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test277"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    int var3 = var2.ordinal();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 3);

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test278"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test279"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(5, 1.192093E-7f, 7.1054274E-15f, 18);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test280"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(short)10);
    java.lang.Number var3 = var2.getMin();
    boolean var4 = var2.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test281"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(0.0d, 1398870649);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test282"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck((-10684L), 709139L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-719823L));

  }

  public void test283() {}
//   public void test283() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test283"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextSecureInt(2, 10);
//     var1.reSeed(3L);
//     java.lang.String var8 = var1.nextSecureHexString(18);
//     var1.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var1.nextPascal(1540232095, (-67.37989615938413d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "b27904086270e66d39"+ "'", var8.equals("b27904086270e66d39"));
// 
//   }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test284"); }


    int var1 = org.apache.commons.math3.util.FastMath.round((-0.99999994f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test285"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm((-127), 152444951);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test286"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(17, 482773L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-33902767));

  }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test287"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var5 = var3.getElement(0);
    var3.setElement(4, (-0.8309074630677628d));
    double var10 = var3.substituteMostRecentElement(6.938893903907228E-18d);
    var3.setElement(5, 122.7902212423532d);
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(1);
    var15.setElement(0, (-0.9880458431278127d));
    var15.setNumElements(9);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var3, var15);
    org.apache.commons.math3.util.ResizableDoubleArray var22 = new org.apache.commons.math3.util.ResizableDoubleArray(var15);
    var22.setExpansionMode(0);
    var22.addElement(1.5430806348151225d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-0.8309074630677628d));

  }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test288"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)2.3062436640636736d, (java.lang.Number)(-80.83448551745833d), false);

  }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test289"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    java.lang.String var3 = var1.toString();
    java.lang.String var4 = var1.name();
    org.apache.commons.math3.distribution.NormalDistribution var8 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var11 = var8.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var12 = var8.getNumericalMean();
    double[] var14 = var8.sample(15);
    boolean var15 = var8.isSupportLowerBoundInclusive();
    boolean var16 = var1.equals((java.lang.Object)var8);
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    java.lang.String var18 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "AVERAGE"+ "'", var3.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "AVERAGE"+ "'", var4.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + "AVERAGE"+ "'", var18.equals("AVERAGE"));

  }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test290"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var3.setElement(3, (-0.7853981633974483d));
    var3.contract();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setExpansionFactor(9.536743E-7f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test291"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(1.1920929E-7f, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.1920929E-7f);

  }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test292"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)4.01128793503116d);

  }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test293"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)10.0d, (java.lang.Number)1L, (java.lang.Number)1);
    java.lang.Number var5 = var4.getHi();
    org.apache.commons.math3.exception.NumberIsTooLargeException var9 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10.0d, (java.lang.Number)1.0f, true);
    java.lang.Number var10 = var9.getMax();
    var4.addSuppressed((java.lang.Throwable)var9);
    java.lang.Number var12 = var4.getLo();
    java.lang.Number var13 = var4.getArgument();
    java.lang.Number var14 = var4.getLo();
    java.lang.Number var15 = var4.getLo();
    java.lang.Number var16 = var4.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1+ "'", var5.equals(1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + 1.0f+ "'", var10.equals(1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 1L+ "'", var12.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + 10.0d+ "'", var13.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + 1L+ "'", var14.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + 1L+ "'", var15.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + 1+ "'", var16.equals(1));

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test294"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var5 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10.0d, (java.lang.Number)1.0f, true);
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    java.lang.Object[] var9 = new java.lang.Object[] { (short)1};
    org.apache.commons.math3.exception.MathArithmeticException var10 = new org.apache.commons.math3.exception.MathArithmeticException(var7, var9);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var5, var6, var9);
    java.lang.Throwable[] var12 = var5.getSuppressed();
    org.apache.commons.math3.exception.MathInternalError var13 = new org.apache.commons.math3.exception.MathInternalError(var1, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.NullArgumentException var14 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test295() {}
//   public void test295() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test295"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(1552);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "407e5623092697fe1d97dc948aa71520f60b7177d433d452c753b60c7c14453f0036ac4e34352797981b4aba6d3fe3e21336829c63e5f3464faee4dab3e4b85cb5b303647ca2a12bfe0fbbb947bb3c7a44e85e680c744b28d287e33131eeed3723a94162e0feab6466636a6d7af5f05fbadfdd3805077dc4e922794d68a8f9f8491d1f7a634cb21ec1d959a35feb888d7efb9467690bac821123bdff3708e29abc45ec2e994f273e43b06d89713a2fb95ab80f274c23e92aac0d9c6267ed5da0ef9e3a86faa9edd8a56d2abb52ba2cedf265e059b5a8759996c8be946782674d7148bde89c9ec5936c72e6f78c04f20b2ab72c1837178a7eaffc04741443e93c3932571377250bca5391ace6ca1266b4ba5a8b033b53d1be4361187034493dbbfc62c4ea413a28313d9d81602df9dc434a603e3a958d11637ffdb5c12ce22ff74c99c7d9dd057c7fb98b689f227e1c01ed1c0e29c840d549e1cb956467bb6f704b8f8d27ba53f1a8f95d39dd01c1d1512bbc9466c0d475e88d18c327cc9305a2e9c958375627bde64f64792e527af042e8ffae5ec687c811c6e9d20c18766697fa34f34317d744643bfbcbcd7c38b08f7d8cb503fbb4695a78e7976c781b1fcdacd22dcab6d285227422d03d770b0334357fcca1f1730507973a6222f1f9c8b15bae7409158ba9d3f7fb65758aa4d8415e2b4c33258f77774eb12254ee3b855dc1f90e8c6523964ccc3546e2bb2f43b7246763bd823c8f19816d16c938d70b0e446cf0e22e583cc8cefafb65fe450241f093842b1690e65f657f440d8334846ae182f0933a50fd01e259e60e603bcdc921ea74110a9de1b24a2abf45d2cce917ed2eed40ec0e41d2232e0c95637202925b3c947d6dfca717b7df86e666fa47d50cc5d430287a4607677e6c140f6a1c87e3da6144e3d54f25ac5c35a19cdc546744223a0c1abde3e95c07b89dadd940e5bc98ee242889812f980408eba3b555a8286088a683edf626adf7bd34a43fd83808fbc71af785b02ad9c131c8552934ca32ce0ac74aa8f7543c7926b95fc616e22c9cb421f5a49ca9164383f084094ac3343c7719cd1c735e"+ "'", var3.equals("407e5623092697fe1d97dc948aa71520f60b7177d433d452c753b60c7c14453f0036ac4e34352797981b4aba6d3fe3e21336829c63e5f3464faee4dab3e4b85cb5b303647ca2a12bfe0fbbb947bb3c7a44e85e680c744b28d287e33131eeed3723a94162e0feab6466636a6d7af5f05fbadfdd3805077dc4e922794d68a8f9f8491d1f7a634cb21ec1d959a35feb888d7efb9467690bac821123bdff3708e29abc45ec2e994f273e43b06d89713a2fb95ab80f274c23e92aac0d9c6267ed5da0ef9e3a86faa9edd8a56d2abb52ba2cedf265e059b5a8759996c8be946782674d7148bde89c9ec5936c72e6f78c04f20b2ab72c1837178a7eaffc04741443e93c3932571377250bca5391ace6ca1266b4ba5a8b033b53d1be4361187034493dbbfc62c4ea413a28313d9d81602df9dc434a603e3a958d11637ffdb5c12ce22ff74c99c7d9dd057c7fb98b689f227e1c01ed1c0e29c840d549e1cb956467bb6f704b8f8d27ba53f1a8f95d39dd01c1d1512bbc9466c0d475e88d18c327cc9305a2e9c958375627bde64f64792e527af042e8ffae5ec687c811c6e9d20c18766697fa34f34317d744643bfbcbcd7c38b08f7d8cb503fbb4695a78e7976c781b1fcdacd22dcab6d285227422d03d770b0334357fcca1f1730507973a6222f1f9c8b15bae7409158ba9d3f7fb65758aa4d8415e2b4c33258f77774eb12254ee3b855dc1f90e8c6523964ccc3546e2bb2f43b7246763bd823c8f19816d16c938d70b0e446cf0e22e583cc8cefafb65fe450241f093842b1690e65f657f440d8334846ae182f0933a50fd01e259e60e603bcdc921ea74110a9de1b24a2abf45d2cce917ed2eed40ec0e41d2232e0c95637202925b3c947d6dfca717b7df86e666fa47d50cc5d430287a4607677e6c140f6a1c87e3da6144e3d54f25ac5c35a19cdc546744223a0c1abde3e95c07b89dadd940e5bc98ee242889812f980408eba3b555a8286088a683edf626adf7bd34a43fd83808fbc71af785b02ad9c131c8552934ca32ce0ac74aa8f7543c7926b95fc616e22c9cb421f5a49ca9164383f084094ac3343c7719cd1c735e"));
// 
//   }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test296"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(7.193119976601626d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.9303635186116421d);

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test297"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(979.3393873505228d, 8.00736706798333d);
    double var3 = var2.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 64.11792736142394d);

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test298"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getNumericalMean();
    double[] var9 = var3.sample(1);
    double var11 = var3.density(979.3393873505228d);
    var3.reseedRandomGenerator(0L);
    double var14 = var3.sample();
    double var16 = var3.cumulativeProbability(0.5403023058681398d);
    double var17 = var3.getNumericalVariance();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var19 = var3.inverseCumulativeProbability(3.666486994447429d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.322456124528837d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 6.658240041118693E-4d);

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test299"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(0.44124929225463694d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.4557079410259654d);

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test300"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)(-0.48741290436643614d), (java.lang.Number)0.33034911277798823d, (java.lang.Number)21.61405867713461d);

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test301"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(10000);
    org.apache.commons.math3.distribution.NormalDistribution var5 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var8 = var5.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var9 = var5.getNumericalMean();
    double[] var11 = var5.sample(1);
    double var13 = var5.density(979.3393873505228d);
    var5.reseedRandomGenerator(0L);
    double var16 = var5.sample();
    double var17 = var5.getMean();
    double var18 = var5.getNumericalMean();
    double var20 = var5.probability(0.05525892401327309d);
    boolean var21 = var1.equals((java.lang.Object)var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1.322456124528837d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test302"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.9152952197546206d, (-0.0d));
    boolean var4 = var3.isSupportConnected();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var7 = var3.cumulativeProbability(101.73677860378969d, (-0.4715944350633355d));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test303"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(3.316337078504644d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3L);

  }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test304"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var4 = var3.getNumericalVariance();
    double[] var6 = var3.sample(6);
    double var7 = var3.getSupportUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 6.658240041118693E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == Double.POSITIVE_INFINITY);

  }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test305"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd((-1L), (-6701751110436810752L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test306"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test307"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)6627890308811632798L, (java.lang.Number)1.0986122886681098d, false);

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test308"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(1.3485725592600977d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.11546675370793957d));

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test309"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(2.559024807187035d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.0d);

  }

  public void test310() {}
//   public void test310() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test310"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     var1.reSeedSecure(10L);
//     double var9 = var1.nextCauchy(1.762747174039086d, 0.025803565724757293d);
//     double var12 = var1.nextWeibull(9.281695778419678d, 71.34241022211371d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var1.nextHypergeometric((-98), (-33902767), 6);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.7517109708752394d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 58.179078868431915d);
// 
//   }

  public void test311() {}
//   public void test311() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test311"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextSecureInt(2, 10);
//     double var6 = var1.nextExponential(1.7763568394002505E-15d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var1.nextUniform(0.8144772166995121d, 0.8144772166995121d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.527511271116495E-16d);
// 
//   }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test312"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var5 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var1, (java.lang.Number)100.0d, (java.lang.Number)(-2.1805166473703887d), true);
    java.lang.Number var6 = var5.getArgument();
    java.lang.Throwable[] var7 = var5.getSuppressed();
    org.apache.commons.math3.exception.NullArgumentException var8 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 100.0d+ "'", var6.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test313"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(17, 2.5f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.discardMostRecentElements(42);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test314() {}
//   public void test314() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test314"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(3.1780538303479458d);
//     double var5 = var1.nextExponential(19.39006869589386d);
//     var1.reSeedSecure(9223372036854775807L);
//     var1.reSeedSecure(2L);
//     var1.reSeed();
//     int var13 = var1.nextBinomial(100, 0.0d);
//     double var16 = var1.nextGamma(0.0d, 0.5403023058681398d);
//     var1.reSeedSecure();
//     int var20 = var1.nextBinomial(1431657535, 0.3646904086155498d);
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var24 = var1.nextInt(1398870649, 21);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.1842450629438275d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.3657838295482549d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 522109767);
// 
//   }

  public void test315() {}
//   public void test315() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test315"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextSecureInt(2, 10);
//     var1.reSeed(3L);
//     int var9 = var1.nextInt(0, 10);
//     var1.reSeed(1030301L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var1.nextBeta(0.9999999999998969d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 9);
// 
//   }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test316"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getNumericalMean();
    double[] var9 = var3.sample(1);
    double var11 = var3.density(979.3393873505228d);
    double var13 = var3.density(3921225.0d);
    boolean var14 = var3.isSupportLowerBoundInclusive();
    double var15 = var3.getMean();
    double[] var17 = var3.sample(10000);
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test317"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees((-623.2007982752439d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-35706.77553035527d));

  }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test318"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(10.0d, 4.535947486464549d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.017940507607563546d);

  }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test319"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)1.566234879235391d, var2, (java.lang.Number)1.2475823134422788d);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var10 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var6, (java.lang.Number)100.0d, (java.lang.Number)(-2.1805166473703887d), true);
    java.lang.Number var11 = var10.getArgument();
    java.lang.Throwable[] var12 = var10.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException(var5, (java.lang.Object[])var12);
    var4.addSuppressed((java.lang.Throwable)var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + 100.0d+ "'", var11.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test320() {}
//   public void test320() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test320"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     double var7 = var1.nextCauchy(0.15560730683937996d, 3.1780538303479458d);
//     long var9 = var1.nextPoisson(1.5707963267948966d);
//     var1.reSeed(101L);
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution(979.3393873505228d, 8.00736706798333d);
//     double var15 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     int var18 = var1.nextSecureInt(7, 6742);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-1.746809500433789d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 968.8343073325332d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 3665);
// 
//   }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test321"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var3.setElement(3, (-0.7853981633974483d));
    var3.contract();
    var3.contract();
    double[] var11 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var11);
    double var14 = var12.getElement(0);
    var12.addElement(0.5403023058681398d);
    var12.discardFrontElements(0);
    double[] var19 = var12.getInternalValues();
    var3.addElements(var19);
    var3.addElement(0.060647843842351036d);
    org.apache.commons.math3.util.ResizableDoubleArray var23 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var23.addElement(0.0d);
    int var26 = var23.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);

  }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test322"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(477803L, (-7227766516491148288L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7227766516491626091L);

  }

//  public void test323() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest3.test323"); }
//
//
//    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
//    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
//    double var7 = var3.getNumericalMean();
//    double[] var9 = var3.sample(1);
//    double var11 = var3.density(979.3393873505228d);
//    double var13 = var3.density(3921225.0d);
//    boolean var14 = var3.isSupportLowerBoundInclusive();
//    var3.reseedRandomGenerator(0L);
//    // The following exception was thrown during execution.
//    // This behavior will recorded for regression testing.
//    try {
//      double[] var18 = var3.sample(522116695);
//      fail("Expected exception of type java.lang.OutOfMemoryError");
//    } catch (java.lang.OutOfMemoryError e) {
//      // Expected exception.
//    }
//    
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var6 == 0.0d);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var7 == 1.3235780930645504d);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var9);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var11 == 0.0d);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var13 == 0.0d);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var14 == false);
//
//  }
//
  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test324"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.distribution.NormalDistribution var5 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var8 = var5.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var9 = var5.getNumericalMean();
    double[] var11 = var5.sample(1);
    double var13 = var5.density(979.3393873505228d);
    double var15 = var5.density(3921225.0d);
    boolean var16 = var5.isSupportLowerBoundInclusive();
    double[] var18 = var5.sample(4);
    double[] var19 = var1.rank(var18);
    org.apache.commons.math3.stat.ranking.NaNStrategy var20 = var1.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var21 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var22 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var24 = var23.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var25 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var22, var24);
    java.lang.String var26 = var24.name();
    java.lang.Class var27 = var24.getDeclaringClass();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var28 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var21, var24);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var29 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var20, var24);
    org.apache.commons.math3.stat.ranking.NaturalRanking var30 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + "AVERAGE"+ "'", var26.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test325"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)34.24420874191639d, (java.lang.Number)(-6.092219684841774d), (java.lang.Number)(-0.4642743809572135d));

  }

  public void test326() {}
//   public void test326() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test326"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.7607318203617716d, (-0.013707783890401887d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test327"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(68);

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test328"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var5 = null;
    java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 0L);
    java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 0L);
    java.math.BigInteger var10 = null;
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var10, 0L);
    java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var10, 0L);
    java.math.BigInteger var16 = org.apache.commons.math3.util.ArithmeticUtils.pow(var14, 8);
    java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, var14);
    java.math.BigInteger var19 = org.apache.commons.math3.util.ArithmeticUtils.pow(var17, 3);
    java.math.BigInteger var20 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, var19);
    java.math.BigInteger var22 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test329"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)101L, (java.lang.Number)(-127), true);

  }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test330"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0.6506795676521677d);

  }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test331"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck((-3017481761840155127L), 6627890308811632798L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test332"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp((-0.16759298660669747d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.16759298660669744d));

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test333"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)522116695);

  }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test334"); }


    double var2 = org.apache.commons.math3.util.FastMath.min((-0.549132653311572d), 1.7530749741780902d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.549132653311572d));

  }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test335"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var3 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)14.080133439244888d, (java.lang.Number)100, var3);

  }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test336"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    int var4 = var1.nextZipf(100, 10.0d);
    var1.reSeedSecure(10L);
    var1.reSeedSecure(100L);
    int[] var11 = var1.nextPermutation(18, 7);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var15 = var1.nextHypergeometric(522115706, 1700, (-1431655765));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test337"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)10.0d, (java.lang.Number)1L, (java.lang.Number)1);
    java.lang.Number var5 = var4.getHi();
    java.lang.Number var6 = var4.getLo();
    java.lang.Number var7 = var4.getLo();
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var12 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var8, (java.lang.Number)13.14778027539684d, (java.lang.Number)(byte)100, false);
    java.lang.Throwable[] var13 = var12.getSuppressed();
    var4.addSuppressed((java.lang.Throwable)var12);
    java.lang.Number var15 = var4.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1+ "'", var5.equals(1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 1L+ "'", var6.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 1L+ "'", var7.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + 1+ "'", var15.equals(1));

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test338"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.distribution.NormalDistribution var5 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var8 = var5.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var9 = var5.getNumericalMean();
    double[] var11 = var5.sample(1);
    double var13 = var5.density(979.3393873505228d);
    double var15 = var5.density(3921225.0d);
    boolean var16 = var5.isSupportLowerBoundInclusive();
    double[] var18 = var5.sample(4);
    double[] var19 = var1.rank(var18);
    org.apache.commons.math3.stat.ranking.NaNStrategy var20 = var1.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var21 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20, var21);
    org.apache.commons.math3.random.RandomGenerator var23 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var23);
    org.apache.commons.math3.distribution.NormalDistribution var28 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var31 = var28.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var32 = var28.getNumericalMean();
    double[] var34 = var28.sample(1);
    double var36 = var28.density(979.3393873505228d);
    double var38 = var28.density(3921225.0d);
    boolean var39 = var28.isSupportLowerBoundInclusive();
    double[] var41 = var28.sample(4);
    double[] var42 = var24.rank(var41);
    org.apache.commons.math3.stat.ranking.NaNStrategy var43 = var24.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var44 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var45 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var46 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var47 = var46.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var48 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var45, var47);
    java.lang.String var49 = var47.name();
    java.lang.Class var50 = var47.getDeclaringClass();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var51 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var44, var47);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var52 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var43, var47);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var53 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var20, var47);
    org.apache.commons.math3.random.RandomGenerator var54 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var55 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20, var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var49 + "' != '" + "AVERAGE"+ "'", var49.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);

  }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test339"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(0.6245357497845453d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test340"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.9152952197546206d, (-0.0d));
    boolean var4 = var3.isSupportConnected();
    double var5 = var3.getSupportLowerBound();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var7 = var3.inverseCumulativeProbability(12154.909104551542d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == Double.NEGATIVE_INFINITY);

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test341"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.distribution.NormalDistribution var5 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var8 = var5.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var9 = var5.getNumericalMean();
    double[] var11 = var5.sample(1);
    double var13 = var5.density(979.3393873505228d);
    double var15 = var5.density(3921225.0d);
    boolean var16 = var5.isSupportLowerBoundInclusive();
    double[] var18 = var5.sample(4);
    double[] var19 = var1.rank(var18);
    org.apache.commons.math3.stat.ranking.TiesStrategy var20 = var1.getTiesStrategy();
    int var21 = var20.ordinal();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 4);

  }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test342"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getNumericalMean();
    double[] var9 = var3.sample(1);
    double var11 = var3.density(979.3393873505228d);
    var3.reseedRandomGenerator(0L);
    double var14 = var3.sample();
    double var16 = var3.cumulativeProbability(0.5403023058681398d);
    double var17 = var3.getNumericalMean();
    boolean var18 = var3.isSupportConnected();
    double var19 = var3.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.322456124528837d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.3235780930645504d);

  }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test343"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp((-0.07380793801109557d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.3877787807814457E-17d);

  }

  public void test344() {}
//   public void test344() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test344"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.sqrt((-0.6910036896710812d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test345"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(263, (-20));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test346"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException(var0);
    java.lang.String var2 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "org.apache.commons.math3.exception.NotPositiveException: null is smaller than the minimum (0)"+ "'", var2.equals("org.apache.commons.math3.exception.NotPositiveException: null is smaller than the minimum (0)"));

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test347"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd((-2149118271877359L), (-6701751110436810752L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test348"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp((-2.4004099376309673d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.440892098500626E-16d);

  }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test349"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(10.0f, 1.192093E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10.0f);

  }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test350"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var5 = var3.getElement(0);
    var3.addElement(0.5403023058681398d);
    var3.discardFrontElements(0);
    double[] var10 = var3.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var10);
    double var13 = var11.addElementRolling(1.3235780930645504d);
    var11.setContractionCriteria(7.378698E20f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test351"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.9152952197546206d, (-0.0d));
    double var4 = var3.getSupportUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.POSITIVE_INFINITY);

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test352"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var3 = var2.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var3);
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var3);
    java.lang.String var6 = var3.name();
    java.lang.String var7 = var3.name();
    int var8 = var3.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "AVERAGE"+ "'", var6.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "AVERAGE"+ "'", var7.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 3);

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test353"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(0.0d, 1.4994259604654114d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test354() {}
//   public void test354() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test354"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
//     java.lang.String var4 = var2.toString();
//     java.lang.Class var5 = var2.getDeclaringClass();
//     java.lang.String var6 = var2.toString();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var7 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var2);
//     double[] var10 = new double[] { 0.0d, 100.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var10);
//     double[] var12 = var11.getElements();
//     org.apache.commons.math3.random.RandomGenerator var13 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var13);
//     org.apache.commons.math3.distribution.NormalDistribution var18 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
//     double var21 = var18.cumulativeProbability(0.0d, 0.1690925369322372d);
//     double var22 = var18.getNumericalMean();
//     double[] var24 = var18.sample(1);
//     double var26 = var18.density(979.3393873505228d);
//     double var28 = var18.density(3921225.0d);
//     boolean var29 = var18.isSupportLowerBoundInclusive();
//     double[] var31 = var18.sample(4);
//     double[] var32 = var14.rank(var31);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var33 = var14.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var34 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy var35 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var36 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var37 = var36.getTiesStrategy();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var38 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var35, var37);
//     java.lang.String var39 = var37.name();
//     java.lang.Class var40 = var37.getDeclaringClass();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var41 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var34, var37);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var42 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var33, var37);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var43 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy var44 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy var45 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var46 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var47 = var46.getTiesStrategy();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var48 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var45, var47);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var49 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var44, var47);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var50 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var43, var47);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var51 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var33, var47);
//     double[] var54 = new double[] { 0.0d, 100.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var55 = new org.apache.commons.math3.util.ResizableDoubleArray(var54);
//     double var57 = var55.getElement(0);
//     double[] var58 = var55.getElements();
//     org.apache.commons.math3.util.ResizableDoubleArray var59 = var55.copy();
//     var55.addElement(3.657242590218247d);
//     org.apache.commons.math3.util.ResizableDoubleArray var62 = var55.copy();
//     double[] var63 = var55.getInternalValues();
//     org.apache.commons.math3.distribution.NormalDistribution var67 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
//     double var70 = var67.cumulativeProbability(0.0d, 0.1690925369322372d);
//     double var72 = var67.cumulativeProbability(10.0d);
//     double var73 = var67.getNumericalVariance();
//     double[] var75 = var67.sample(14);
//     double var76 = var51.mannWhitneyU(var63, var75);
//     double var77 = var7.mannWhitneyU(var12, var63);
// 
//   }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test355"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var5 = var3.getElement(0);
    int var6 = var3.getNumElements();
    int var7 = var3.getExpansionMode();
    double var9 = var3.substituteMostRecentElement(1.5707963267948966d);
    java.lang.Object var10 = null;
    boolean var11 = var3.equals(var10);
    var3.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var13 = var3.copy();
    double var15 = var3.addElementRolling(45.82685605718666d);
    var3.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);

  }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test356"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var3.setElement(3, (-0.7853981633974483d));
    var3.contract();
    var3.contract();
    double[] var11 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var11);
    double var14 = var12.getElement(0);
    var12.addElement(0.5403023058681398d);
    var12.discardFrontElements(0);
    double[] var19 = var12.getInternalValues();
    var3.addElements(var19);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setExpansionMode(3665);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test357() {}
//   public void test357() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test357"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(1.7770070454655067d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test358() {}
//   public void test358() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test358"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     double var7 = var1.nextCauchy(0.15560730683937996d, 3.1780538303479458d);
//     double var11 = var1.nextUniform((-0.6740495597759653d), (-0.016482976994642014d), true);
//     java.lang.String var13 = var1.nextHexString(3665);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 12.724963755175784d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.3705902110351007d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "4f5c9b9a2a83ea4f7109e25c7fcd56a2c48fbeafda635f98354b59acadffc86b99371197edcd9462a68d11a2b995239b1d15f4d46d9ac158c93db897569cda3b0bb3d548943da9ce67e6c6c7288e205be7734b623250072681d873ad73aeb86517dc6f79d76280a912e04c36a5a088b44f5366042c4c5ba25d8fda3f728cba91210573f8babc7fbb424b038172747f80bcf15c0f5e7bcf96d2e2498283777dfe5281911216cbdf94df6e36427f2016c47b675d6dd85e5fe15c60ed3d15e04ba85f08299e695bd225bb51eb76a559c1786a024a7f70741dcb43df6b1265f55eb0a95f20934f124909bb8157dccec870c5e67135ab5dad82ede873b650c68379212d6750b2b966f018a3d2254217a505f48c77f3a9ffa2176c3347b811b0dab2bb772ae35c47f1ebb8323833fe8d4b3ec391a93e12a4f97d67ffccaeb1d2fcdd16af4b8d423055fb32e060e38ea950a0b8a363269fc10902b7eda7332f0f7e2ce1db5c3db12ec014d1fe8636ff0d7494bef4d156def0adfcc100eb6a8dcadf28290abe3a55908560b2ae5a8c5611691835214a4479b0a113d384b8f7cc29c92c5362ecb7cba514bfdc4351f2c7089d3f9cd20d58a7d7c08c1df3f2c2b1eaa504171ee9d891c5680c556ab6891c0ef452fe9eefd6e0707613b4784edc22e593ae2fd73d832a68cf41121b8d037b96b9d0942497fabfa956f9b0bbb76edf95d2da609125026e8b0b5021f95f671606e0721676dbe125e4c1e8ea82ecdeaaf54b7134c7ffb22dfc3a9d42b42c476ba89ff1d4d921c7b46d1da7c8240cc78cf75aaf2e0e21ea79d016e6a1f90a4599cc256395eb33630425d0b2ff298e9eaa751e6cc0af3af598dc19e893814a04b7606dabd91674ebdd752664c742ad92d907de3ca36be452eaad883351dce06a2dce4d67b2cc9551d122fbfe75e2be4fe1687b53b953304ef1927b4f6adb66615b072f9f11406c5ad72ecb4ef36829a6b74322e78f1dd4096f299ce514fcf77bebb13b37a10c13df2fa51492731090b298dca2c93a5f2988b0bfb8aa291905df409479dbd68978500c0d801e5d35996e9d92903f1a3a2104066ee271cf0b8ec23debcc79593d2271b43c3757b38d89b99a2a2129ca0891764c9b9c88bd435d8f81010e07ed02efae71d96c86053a356d8a1902182f695d77e6ddc05e309ba31e840624a8a835b113cbc5a148afb0a5b0b4e73fedb56e1520d38e41735415f8e26d5cbbb6cea51538caf3ec45dc2f4eeee5ba93e7e40d0baa2fc1bd42d4f43f8ad4daac34632aa97e6a46cc5336a78030d52ca349f987fa1f1f3bdd18aa00cd57a7def45c390134215a0b592d98e65aeea0f77ad1b46628937ef1220a17f4cb3f768cbfd3700ad6a5a49a1a45180059af5058c711bc89987450c5bd974a936dc4dcfd2151410df2b81f1d9cd548b58530a441f05cf8178d85227aeb1b1f0ea3c58a23379f93d8afef73be8f3bdf3a2303bd456f48d022da36958068c3472fe12cc598211d28d8e50a48faf2aafd2c3fd9d14cd54c099faceffa264322364fc7da678d89ff3dc0fb36fdfbb57bc3aa760faab76ba9fefc32542fdb35b4f4ab67bf90888033ce41768253c0e4846b7b9c9d85b918dd75cccad7be5318e9af9a9f1f91ab7da8b92d1443a76cacc402f8eac78a9363d3b336c9371e5a2562b1c1830dd4f822e03cb086f1ade3832648bcb65c4bcceeb08d519a109e185f5274a3a292b9d14d293fe12e324d518a8e329ada9596bf136a60b128e088c8a4ac7e473712b7da6223235a40b42d0ec565a3190b6fb31a564631f75dad2e15e7e1f9631d4301375b5f07f5db80a442c9bfb35a665bd52192f1565f879d9f3d87ee0215728f75162239bc88ce88a6cb55e5fcb9a0695e5a059f0c9d42058ef6a440b2f8eaf5bef952b81147f835d8718eb663d34ddd5f51adb42a2584e5cd009111fb598e85de0d0877b0420d8fc2b9c25fc42939c369e8b731b6984be637f507b0ebafdc93b75e358b1657b6a598f4f349239b6417d3140dbb96ddf2e4210013e901e0dbd1f5e7182f19bb3493beae0c04be98d6ee6906475783dfcdda65ed43d49a68fd69fdc2b4c94512cc84fc58a9e8a84cd70b58e219f11033061f0af6647959e512c53c0e0f0bc3ea680ff4a4306ee142fa9f1da349da8bc1986e3121a8a9f03f5aea5d15de48602d77de6bccd0399873b12ae9acab678927ad0873832f5d518021f9ac1bfe75689fa34ef2868ddb256948add355617f10788107b476f77ecb3c1cffd791e8afd3a8ff052f9490dfcc78e2d5540afffb6939f4680fb69ac3e8ee90189427208feb84043ead336cced06ca16812fe69629163c154107de855c9bcaecd758d00bf648f6eda37db9ac5d1a8657b747fbec25a002ea6f10b492535c10cfed43c0fe7db63fe6fb56ee169c975824f97b47f1790818ff68dfb1796c62375910a4da0f3efb0852cadd8a8c5d3515221968952e99e41c7c47cf2fed247bbf7fec2c9451c07eb6369cbb926338e0175ea668fa8f017eb288b383a16bbfac4be22a865fa519de886e09e2c1d981cce918af05917e94a15b28c7d456dbd2f3"+ "'", var13.equals("4f5c9b9a2a83ea4f7109e25c7fcd56a2c48fbeafda635f98354b59acadffc86b99371197edcd9462a68d11a2b995239b1d15f4d46d9ac158c93db897569cda3b0bb3d548943da9ce67e6c6c7288e205be7734b623250072681d873ad73aeb86517dc6f79d76280a912e04c36a5a088b44f5366042c4c5ba25d8fda3f728cba91210573f8babc7fbb424b038172747f80bcf15c0f5e7bcf96d2e2498283777dfe5281911216cbdf94df6e36427f2016c47b675d6dd85e5fe15c60ed3d15e04ba85f08299e695bd225bb51eb76a559c1786a024a7f70741dcb43df6b1265f55eb0a95f20934f124909bb8157dccec870c5e67135ab5dad82ede873b650c68379212d6750b2b966f018a3d2254217a505f48c77f3a9ffa2176c3347b811b0dab2bb772ae35c47f1ebb8323833fe8d4b3ec391a93e12a4f97d67ffccaeb1d2fcdd16af4b8d423055fb32e060e38ea950a0b8a363269fc10902b7eda7332f0f7e2ce1db5c3db12ec014d1fe8636ff0d7494bef4d156def0adfcc100eb6a8dcadf28290abe3a55908560b2ae5a8c5611691835214a4479b0a113d384b8f7cc29c92c5362ecb7cba514bfdc4351f2c7089d3f9cd20d58a7d7c08c1df3f2c2b1eaa504171ee9d891c5680c556ab6891c0ef452fe9eefd6e0707613b4784edc22e593ae2fd73d832a68cf41121b8d037b96b9d0942497fabfa956f9b0bbb76edf95d2da609125026e8b0b5021f95f671606e0721676dbe125e4c1e8ea82ecdeaaf54b7134c7ffb22dfc3a9d42b42c476ba89ff1d4d921c7b46d1da7c8240cc78cf75aaf2e0e21ea79d016e6a1f90a4599cc256395eb33630425d0b2ff298e9eaa751e6cc0af3af598dc19e893814a04b7606dabd91674ebdd752664c742ad92d907de3ca36be452eaad883351dce06a2dce4d67b2cc9551d122fbfe75e2be4fe1687b53b953304ef1927b4f6adb66615b072f9f11406c5ad72ecb4ef36829a6b74322e78f1dd4096f299ce514fcf77bebb13b37a10c13df2fa51492731090b298dca2c93a5f2988b0bfb8aa291905df409479dbd68978500c0d801e5d35996e9d92903f1a3a2104066ee271cf0b8ec23debcc79593d2271b43c3757b38d89b99a2a2129ca0891764c9b9c88bd435d8f81010e07ed02efae71d96c86053a356d8a1902182f695d77e6ddc05e309ba31e840624a8a835b113cbc5a148afb0a5b0b4e73fedb56e1520d38e41735415f8e26d5cbbb6cea51538caf3ec45dc2f4eeee5ba93e7e40d0baa2fc1bd42d4f43f8ad4daac34632aa97e6a46cc5336a78030d52ca349f987fa1f1f3bdd18aa00cd57a7def45c390134215a0b592d98e65aeea0f77ad1b46628937ef1220a17f4cb3f768cbfd3700ad6a5a49a1a45180059af5058c711bc89987450c5bd974a936dc4dcfd2151410df2b81f1d9cd548b58530a441f05cf8178d85227aeb1b1f0ea3c58a23379f93d8afef73be8f3bdf3a2303bd456f48d022da36958068c3472fe12cc598211d28d8e50a48faf2aafd2c3fd9d14cd54c099faceffa264322364fc7da678d89ff3dc0fb36fdfbb57bc3aa760faab76ba9fefc32542fdb35b4f4ab67bf90888033ce41768253c0e4846b7b9c9d85b918dd75cccad7be5318e9af9a9f1f91ab7da8b92d1443a76cacc402f8eac78a9363d3b336c9371e5a2562b1c1830dd4f822e03cb086f1ade3832648bcb65c4bcceeb08d519a109e185f5274a3a292b9d14d293fe12e324d518a8e329ada9596bf136a60b128e088c8a4ac7e473712b7da6223235a40b42d0ec565a3190b6fb31a564631f75dad2e15e7e1f9631d4301375b5f07f5db80a442c9bfb35a665bd52192f1565f879d9f3d87ee0215728f75162239bc88ce88a6cb55e5fcb9a0695e5a059f0c9d42058ef6a440b2f8eaf5bef952b81147f835d8718eb663d34ddd5f51adb42a2584e5cd009111fb598e85de0d0877b0420d8fc2b9c25fc42939c369e8b731b6984be637f507b0ebafdc93b75e358b1657b6a598f4f349239b6417d3140dbb96ddf2e4210013e901e0dbd1f5e7182f19bb3493beae0c04be98d6ee6906475783dfcdda65ed43d49a68fd69fdc2b4c94512cc84fc58a9e8a84cd70b58e219f11033061f0af6647959e512c53c0e0f0bc3ea680ff4a4306ee142fa9f1da349da8bc1986e3121a8a9f03f5aea5d15de48602d77de6bccd0399873b12ae9acab678927ad0873832f5d518021f9ac1bfe75689fa34ef2868ddb256948add355617f10788107b476f77ecb3c1cffd791e8afd3a8ff052f9490dfcc78e2d5540afffb6939f4680fb69ac3e8ee90189427208feb84043ead336cced06ca16812fe69629163c154107de855c9bcaecd758d00bf648f6eda37db9ac5d1a8657b747fbec25a002ea6f10b492535c10cfed43c0fe7db63fe6fb56ee169c975824f97b47f1790818ff68dfb1796c62375910a4da0f3efb0852cadd8a8c5d3515221968952e99e41c7c47cf2fed247bbf7fec2c9451c07eb6369cbb926338e0175ea668fa8f017eb288b383a16bbfac4be22a865fa519de886e09e2c1d981cce918af05917e94a15b28c7d456dbd2f3"));
// 
//   }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test359"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var5 = var3.substituteMostRecentElement(1.3235780930645504d);
    float var6 = var3.getExpansionFactor();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = var3.copy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setContractionCriteria(1.694066E-21f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test360"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10.0d, (java.lang.Number)1.0f, true);
    java.lang.Number var4 = var3.getMax();
    java.lang.Number var5 = var3.getMax();
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.exception.OutOfRangeException var12 = new org.apache.commons.math3.exception.OutOfRangeException(var8, (java.lang.Number)10.0d, (java.lang.Number)1L, (java.lang.Number)1);
    java.lang.Number var13 = var12.getHi();
    org.apache.commons.math3.exception.NumberIsTooLargeException var17 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10.0d, (java.lang.Number)1.0f, true);
    java.lang.Number var18 = var17.getMax();
    var12.addSuppressed((java.lang.Throwable)var17);
    java.lang.Throwable[] var20 = var12.getSuppressed();
    org.apache.commons.math3.exception.NullArgumentException var21 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var20);
    org.apache.commons.math3.exception.MathIllegalStateException var22 = new org.apache.commons.math3.exception.MathIllegalStateException(var6, (java.lang.Object[])var20);
    var3.addSuppressed((java.lang.Throwable)var22);
    java.lang.Number var24 = var3.getArgument();
    org.apache.commons.math3.exception.util.ExceptionContext var25 = var3.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 1.0f+ "'", var4.equals(1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1.0f+ "'", var5.equals(1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + 1+ "'", var13.equals(1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + 1.0f+ "'", var18.equals(1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + 10.0d+ "'", var24.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test361"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(2149118271877359L, 970448963025102651L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-968299844753225292L));

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test362"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(34.24420874191639d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1962.0486336768074d);

  }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test363"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.math.BigInteger var1 = null;
    java.math.BigInteger var3 = org.apache.commons.math3.util.ArithmeticUtils.pow(var1, 0L);
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var1, 0L);
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var10 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10.0d, (java.lang.Number)1.0f, true);
    org.apache.commons.math3.exception.util.Localizable var11 = null;
    org.apache.commons.math3.exception.util.Localizable var12 = null;
    java.lang.Object[] var14 = new java.lang.Object[] { (short)1};
    org.apache.commons.math3.exception.MathArithmeticException var15 = new org.apache.commons.math3.exception.MathArithmeticException(var12, var14);
    org.apache.commons.math3.exception.MathIllegalStateException var16 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var10, var11, var14);
    java.lang.Throwable[] var17 = var10.getSuppressed();
    org.apache.commons.math3.exception.MathArithmeticException var18 = new org.apache.commons.math3.exception.MathArithmeticException(var6, (java.lang.Object[])var17);
    org.apache.commons.math3.exception.MaxCountExceededException var19 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)var5, (java.lang.Object[])var17);
    org.apache.commons.math3.exception.util.Localizable var20 = null;
    java.math.BigInteger var21 = null;
    java.math.BigInteger var23 = org.apache.commons.math3.util.ArithmeticUtils.pow(var21, 0L);
    java.math.BigInteger var25 = org.apache.commons.math3.util.ArithmeticUtils.pow(var21, 0L);
    org.apache.commons.math3.exception.util.Localizable var26 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var30 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10.0d, (java.lang.Number)1.0f, true);
    org.apache.commons.math3.exception.util.Localizable var31 = null;
    org.apache.commons.math3.exception.util.Localizable var32 = null;
    java.lang.Object[] var34 = new java.lang.Object[] { (short)1};
    org.apache.commons.math3.exception.MathArithmeticException var35 = new org.apache.commons.math3.exception.MathArithmeticException(var32, var34);
    org.apache.commons.math3.exception.MathIllegalStateException var36 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var30, var31, var34);
    java.lang.Throwable[] var37 = var30.getSuppressed();
    org.apache.commons.math3.exception.MathArithmeticException var38 = new org.apache.commons.math3.exception.MathArithmeticException(var26, (java.lang.Object[])var37);
    org.apache.commons.math3.exception.MaxCountExceededException var39 = new org.apache.commons.math3.exception.MaxCountExceededException(var20, (java.lang.Number)var25, (java.lang.Object[])var37);
    java.math.BigInteger var40 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, var25);
    java.math.BigInteger var42 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 1061208L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test364"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test365"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(7.589578294334879d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 8.0d);

  }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test366"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(1.361344537390401d, 18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 356868.30240966927d);

  }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test367"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(29.534874591935314d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1692.223662566063d);

  }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test368"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)9.536743E-7f, (java.lang.Number)(-7), (java.lang.Number)(-3.657242590218247d));

  }

  public void test369() {}
//   public void test369() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test369"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextSecureInt(2, 10);
//     double var7 = var1.nextCauchy(0.037062153555774406d, 3.5247804145401362d);
//     double var9 = var1.nextChiSquare(8.00736706798333d);
//     int var12 = var1.nextPascal(9, 0.686579669341957d);
//     double var16 = var1.nextUniform(0.5573731387105724d, 1.1873155246411504d, true);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var18 = var1.nextExponential(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-2.7091058555506398d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 5.024042409748907d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1.0336845121475273d);
// 
//   }

  public void test370() {}
//   public void test370() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test370"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
//     org.apache.commons.math3.distribution.NormalDistribution var5 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
//     double var8 = var5.cumulativeProbability(0.0d, 0.1690925369322372d);
//     double var9 = var5.getNumericalMean();
//     double[] var11 = var5.sample(1);
//     double var13 = var5.density(979.3393873505228d);
//     double var15 = var5.density(3921225.0d);
//     boolean var16 = var5.isSupportLowerBoundInclusive();
//     double[] var18 = var5.sample(4);
//     double[] var19 = var1.rank(var18);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var20 = var1.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var21 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy var22 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var24 = var23.getTiesStrategy();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var25 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var22, var24);
//     java.lang.String var26 = var24.name();
//     java.lang.Class var27 = var24.getDeclaringClass();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var28 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var21, var24);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var29 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var20, var24);
//     org.apache.commons.math3.random.RandomGenerator var30 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var31 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var30);
//     org.apache.commons.math3.random.RandomGenerator var32 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var33 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var32);
//     org.apache.commons.math3.distribution.NormalDistribution var37 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
//     double var40 = var37.cumulativeProbability(0.0d, 0.1690925369322372d);
//     double var41 = var37.getNumericalMean();
//     double[] var43 = var37.sample(1);
//     double var45 = var37.density(979.3393873505228d);
//     double var47 = var37.density(3921225.0d);
//     boolean var48 = var37.isSupportLowerBoundInclusive();
//     double[] var50 = var37.sample(4);
//     double[] var51 = var33.rank(var50);
//     double[] var52 = var31.rank(var51);
//     org.apache.commons.math3.distribution.NormalDistribution var55 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 0.5866841190102328d);
//     double[] var57 = var55.sample(3);
//     double var58 = var29.mannWhitneyUTest(var52, var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.3235780930645504d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var26 + "' != '" + "AVERAGE"+ "'", var26.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 1.3235780930645504d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == 0.0770998717435416d);
// 
//   }

//  public void test371() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest3.test371"); }
//
//
//    double[] var2 = new double[] { 0.0d, 100.0d};
//    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
//    double[] var4 = var3.getElements();
//    double[] var5 = var3.getInternalValues();
//    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray(var5);
//    var6.clear();
//    // The following exception was thrown during execution.
//    // This behavior will recorded for regression testing.
//    try {
//      var6.setElement(522116695, 3.760344905943776d);
//      fail("Expected exception of type java.lang.OutOfMemoryError");
//    } catch (java.lang.OutOfMemoryError e) {
//      // Expected exception.
//    }
//    
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var2);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var4);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var5);
//
//  }
//
  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test372"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(673053L, 112460126646364816L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 112460126646364816L);

  }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test373"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var4 = var3.getNumericalVariance();
    double var5 = var3.getSupportLowerBound();
    double var6 = var3.getMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 6.658240041118693E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.3235780930645504d);

  }

  public void test374() {}
//   public void test374() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test374"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP((-0.7792322490867346d), 0.050807334874102675d, (-9.602370808556296d), (-23));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test375"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(3.088731025128343d, 3.7593867989550986d, 0.9152952197546206d, 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.6020391860284307d);

  }

  public void test376() {}
//   public void test376() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test376"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
//     double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
//     double var7 = var3.getNumericalMean();
//     double[] var9 = var3.sample(1);
//     double var11 = var3.density(979.3393873505228d);
//     double var13 = var3.density(3921225.0d);
//     boolean var14 = var3.isSupportLowerBoundInclusive();
//     double var15 = var3.getNumericalMean();
//     boolean var16 = var3.isSupportUpperBoundInclusive();
//     double var17 = var3.getSupportUpperBound();
//     double var18 = var3.sample();
//     double var19 = var3.sample();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.3235780930645504d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.3235780930645504d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1.371688108192673d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1.3616832743194123d);
// 
//   }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test377"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb((-0.4543072568479274d), 8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-116.30265775306941d));

  }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test378"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)14.0d, (java.lang.Number)(-3.724836690523139d), true);

  }

  public void test379() {}
//   public void test379() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test379"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(3.1780538303479458d);
//     double var5 = var1.nextExponential(19.39006869589386d);
//     var1.reSeedSecure(9223372036854775807L);
//     var1.reSeedSecure(2L);
//     var1.reSeed();
//     int var13 = var1.nextBinomial(100, 0.0d);
//     double var16 = var1.nextGamma(0.0d, 0.5403023058681398d);
//     var1.reSeedSecure();
//     int var20 = var1.nextBinomial(100, 0.7241199936737109d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var23 = var1.nextUniform(4.189149606287355d, 0.775944101461304d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 4.763275864506525d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 173.36013990922325d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 68);
// 
//   }

  public void test380() {}
//   public void test380() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test380"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(1.0487286688968165d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test381() {}
//   public void test381() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test381"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     double var7 = var1.nextCauchy(0.15560730683937996d, 3.1780538303479458d);
//     double var10 = var1.nextBeta(8.985875073756691d, 1.7792833636531957d);
//     int var13 = var1.nextSecureInt(38, 10000);
//     var1.reSeed();
//     org.apache.commons.math3.distribution.IntegerDistribution var15 = null;
//     int var16 = var1.nextInversionDeviate(var15);
// 
//   }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test382"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var3 = var2.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var3);
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var3);
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3);
    java.lang.String var7 = var3.toString();
    java.lang.Object var8 = null;
    boolean var9 = var3.equals(var8);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "AVERAGE"+ "'", var7.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test383"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    int var4 = var3.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = var3.copy();
    var5.discardMostRecentElements(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test384() {}
//   public void test384() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test384"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     var1.reSeedSecure(10L);
//     double var9 = var1.nextCauchy(1.762747174039086d, 0.025803565724757293d);
//     var1.reSeed();
//     var1.reSeedSecure(9L);
//     java.lang.String var14 = var1.nextHexString(152444951);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.7958576033930682d);
// 
//   }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test385"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test386"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    int var4 = var3.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = var3.copy();
    var3.setExpansionFactor(1.0000001f);
    double var9 = var3.substituteMostRecentElement((-3.889934788209016d));
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(6);
    double[] var12 = var11.getInternalValues();
    var3.addElements(var12);
    double var15 = var3.substituteMostRecentElement(0.24389738082415968d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);

  }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test387"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.lang.Object[] var4 = new java.lang.Object[] { (byte)1};
    org.apache.commons.math3.exception.MathIllegalStateException var5 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, var4);
    org.apache.commons.math3.exception.MathIllegalStateException var6 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, var4);
    org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError(var0, var4);
    org.apache.commons.math3.exception.util.ExceptionContext var8 = var7.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var9 = var7.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var10 = var7.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test388"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var3 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.setElement(3, (-0.7853981633974483d));
    var4.discardMostRecentElements(0);
    double[] var12 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray(var12);
    double var15 = var13.getElement(0);
    double[] var16 = var13.getInternalValues();
    var4.addElements(var16);
    org.apache.commons.math3.distribution.NormalDistribution var21 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var24 = var21.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var25 = var21.getNumericalMean();
    double[] var27 = var21.sample(1);
    double var29 = var21.density(979.3393873505228d);
    double var31 = var21.density(3921225.0d);
    boolean var32 = var21.isSupportLowerBoundInclusive();
    double var33 = var21.getMean();
    double[] var35 = var21.sample(10000);
    double var36 = var0.mannWhitneyU(var16, var35);
    double[] var39 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var40 = new org.apache.commons.math3.util.ResizableDoubleArray(var39);
    var40.discardMostRecentElements(0);
    double[] var43 = var40.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var45 = new org.apache.commons.math3.util.ResizableDoubleArray(1);
    org.apache.commons.math3.util.ResizableDoubleArray var46 = var45.copy();
    double[] var47 = var45.getElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var48 = var0.mannWhitneyU(var43, var47);
      fail("Expected exception of type org.apache.commons.math3.exception.NoDataException");
    } catch (org.apache.commons.math3.exception.NoDataException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 10000.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);

  }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test389"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)1491846144, (java.lang.Number)109.792947723851d, true);
    java.lang.Number var5 = var4.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 109.792947723851d+ "'", var5.equals(109.792947723851d));

  }

  public void test390() {}
//   public void test390() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test390"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(3.1780538303479458d);
//     double var6 = var1.nextWeibull(968.8343073325332d, 0.9149287324253481d);
//     double var9 = var1.nextGaussian(0.0d, Double.POSITIVE_INFINITY);
//     double var12 = var1.nextBeta(2.038940829865108d, 176.73201156338953d);
//     int var15 = var1.nextInt(10463584, 1431657329);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.6158435329407055d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.9112611869448629d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.014464045084889972d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 925199453);
// 
//   }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test391"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getNumericalMean();
    double[] var9 = var3.sample(1);
    double var11 = var3.density(979.3393873505228d);
    double var13 = var3.density(3921225.0d);
    double[] var15 = var3.sample(10000);
    var3.reseedRandomGenerator(201L);
    boolean var18 = var3.isSupportConnected();
    double var20 = var3.density(1.9124153064037221d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.286303854474297E-112d);

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test392"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.math.BigInteger var1 = null;
    java.math.BigInteger var3 = org.apache.commons.math3.util.ArithmeticUtils.pow(var1, 0L);
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var1, 0L);
    java.math.BigInteger var6 = null;
    java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, 0L);
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, 0L);
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var10, 8);
    java.math.BigInteger var13 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, var10);
    java.math.BigInteger var15 = org.apache.commons.math3.util.ArithmeticUtils.pow(var13, 17);
    java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var15, 0);
    org.apache.commons.math3.exception.OutOfRangeException var20 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0, (java.lang.Number)0.5197187016610063d, (java.lang.Number)(-9800));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test393"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(4.7683716E-7f, 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.7683716E-7f);

  }

  public void test394() {}
//   public void test394() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test394"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(2.5164150335575357d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test395"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(0.9215012794164503d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1102230246251565E-16d);

  }

}
