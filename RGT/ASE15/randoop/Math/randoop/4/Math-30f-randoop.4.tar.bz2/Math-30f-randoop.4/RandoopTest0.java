
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(100);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(0.0f, 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(3, 0.0f, 100.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(10.0d, 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10.0d);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5403023058681398d);

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 10.0d);

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(10L, 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(10, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(0.5403023058681398d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.777309158100993d));

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2((-1.777309158100993d), (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-2.0832984452539125d));

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 100);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos((-2.0832984452539125d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.49035942660728515d));

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0f);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(0.0d, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.3440585709080678E43d);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(0, (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.7853981633974483d));

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(1L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test21() {}
//   public void test21() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Object[] var2 = new java.lang.Object[] { (short)1};
//     org.apache.commons.math3.exception.MathArithmeticException var3 = new org.apache.commons.math3.exception.MathArithmeticException(var0, var2);
//     org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
// 
//   }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }


    long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2L);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 32.94631867978169d);

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var5 = var3.getElement(0);
    int var6 = var3.getNumElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setExpansionMode(100);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var5 = var3.getElement(0);
    double[] var6 = var3.getInternalValues();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setContractionCriteria(1.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(10.0f, 32.94631867978169d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10.000001f);

  }

  public void test27() {}
//   public void test27() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }
// 
// 
//     java.lang.Class var0 = null;
//     java.lang.Enum var2 = java.lang.Enum.<java.lang.Enum>valueOf(var0, "hi!");
// 
//   }

  public void test28() {}
//   public void test28() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var1 = null;
//     java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, var1);
// 
//   }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma((-0.7853981633974483d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-3.657242590218247d));

  }

  public void test30() {}
//   public void test30() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 3);
// 
//   }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd((-1), 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test32() {}
//   public void test32() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.0d, 100.0d, (-0.49035942660728515d), (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(10.0d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.5707963267948966d);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(4, (-1.0f), 10.0f, 1);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(3, (-1));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var1);
    org.apache.commons.math3.stat.ranking.TiesStrategy var3 = var2.getTiesStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(10.0d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(100L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100L);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(100L, (-1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 101L);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh((-1.777309158100993d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.9444050156042171d));

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians((-0.9444050156042171d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.016482976994642014d));

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(3, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test43() {}
//   public void test43() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.nextAfter(Double.NaN, 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test44() {}
//   public void test44() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log((-0.9444050156042171d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(10, 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)100.0f);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(32.94631867978169d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.5247804145401362d);

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh((-3.657242590218247d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 19.39006869589386d);

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999999958776927d);

  }

  public void test50() {}
//   public void test50() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 1L);
// 
//   }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(10L, 10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100L);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(1L, 2L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent((-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.7453292519943295d);

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(1L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos((-0.9444050156042171d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 979.3393873505228d);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp((-1.777309158100993d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.1690925369322372d);

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var3.setElement(3, (-0.7853981633974483d));
    double[] var7 = var3.getElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setExpansionMode(100);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog(4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.1780538303479458d);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(0L, (-1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1L));

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(1.3440585709080678E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9223372036854775807L);

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var2 = new java.lang.Object[] { (byte)1};
    org.apache.commons.math3.exception.MathIllegalStateException var3 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var2);
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var3.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var3.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(1.0f, 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0f);

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }


    double var1 = org.apache.commons.math3.util.FastMath.acos(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5707963267948966d);

  }

  public void test65() {}
//   public void test65() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.random.RandomGenerator var1 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var1);
//     double[] var5 = new double[] { 0.0d, 100.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray(var5);
//     var6.setElement(3, (-0.7853981633974483d));
//     double[] var10 = var6.getElements();
//     double[] var11 = var2.rank(var10);
// 
//   }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(100, 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3921225.0d);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(100L, 100L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(1.3440585709080678E43d, 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.02318656797210774d);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(1.5707963267948966d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.810477380965351d);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(10, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10);

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("hi!");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(2, 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-98));

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1((-1.777309158100993d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.8309074630677628d));

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(1.7453292519943295d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.3235780930645504d);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(10, 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 14);

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var5 = var3.getElement(0);
    double[] var6 = var3.getInternalValues();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setExpansionFactor((-1.0f));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(9223372036854775807L, 14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient((-1), (-1));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("hi!");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test81() {}
//   public void test81() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }
// 
// 
//     double[] var2 = new double[] { 0.0d, 100.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
//     var3.setElement(3, (-0.7853981633974483d));
//     int var7 = var3.getNumElements();
//     double var9 = var3.substituteMostRecentElement((-0.7853981633974483d));
//     float var10 = var3.getExpansionFactor();
//     double var12 = var3.getElement(0);
//     double[] var13 = null;
//     var3.addElements(var13);
// 
//   }

  public void test82() {}
//   public void test82() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)10.0d, (java.lang.Number)1L, (java.lang.Number)1);
//     org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var4);
// 
//   }

  public void test83() {}
//   public void test83() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy var1 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var1);
//     double[] var3 = null;
//     double[] var4 = var2.rank(var3);
// 
//   }

  public void test84() {}
//   public void test84() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0);
// 
//   }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var4 = var1.nextPermutation(1, 14);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(10, 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }


    double var1 = org.apache.commons.math3.special.Erf.erf((-1.777309158100993d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.9880458431278127d));

  }

  public void test88() {}
//   public void test88() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP((-0.9444050156042171d), 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(0.0d, 32.94631867978169d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var4 = var1.nextBinomial((-98), 10.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test91() {}
//   public void test91() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }
// 
// 
//     double var0 = org.apache.commons.math3.util.FastMath.random();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var0 == 0.15560730683937996d);
// 
//   }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)2.0f, (java.lang.Number)(-1L), (java.lang.Number)1.5707963267948966d);

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(1.7453292519943295d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9864231484692195d);

  }

  public void test94() {}
//   public void test94() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.util.Collection var2 = null;
//     java.lang.Object[] var4 = var1.nextSample(var2, 14);
// 
//   }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign((-3.657242590218247d), 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.657242590218247d);

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var5 = var3.getElement(0);
    int var6 = var3.getNumElements();
    int var7 = var3.getExpansionMode();
    float var8 = var3.getExpansionFactor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setNumElements((-1));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.0f);

  }

  public void test97() {}
//   public void test97() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextSecureInt(2, 10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var6 = var1.nextPoisson(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 5);
// 
//   }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(10.0d, 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9999998885745217d);

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(14, (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 15);

  }

  public void test100() {}
//   public void test100() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos((-2.0832984452539125d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }


    double var1 = org.apache.commons.math3.special.Erf.erf((-0.016482976994642014d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.01859736360708744d));

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble((-1));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test103() {}
//   public void test103() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(3.1780538303479458d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var7 = var1.nextHypergeometric(2, 4, 15);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 18.032259167817568d);
// 
//   }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var5 = var3.getElement(0);
    int var6 = var3.getNumElements();
    int var7 = var3.getExpansionMode();
    var3.contract();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setExpansionMode((-1));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(1.0d, 3.657242590218247d, 100.0d, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.025803565724757293d);

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)10L, (java.lang.Number)(byte)10, false);

  }

  public void test107() {}
//   public void test107() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP((-0.7853981633974483d), (-2.0832984452539125d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test108() {}
//   public void test108() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextSecureInt(2, 10);
//     double var8 = var1.nextUniform(3.1780538303479458d, 4.810477380965351d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var1.nextInt(15, 1);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 3.7994037097939133d);
// 
//   }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var3.inverseCumulativeProbability(100.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p((-0.49035942660728515d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.6740495597759653d));

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)(short)1, var2, (java.lang.Number)1.5707963267948966d);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var5 = var3.getElement(0);
    int var6 = var3.getNumElements();
    int var7 = var3.getExpansionMode();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setExpansionMode(10);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)10.0d, (java.lang.Number)1L, (java.lang.Number)1);
    java.lang.Number var5 = var4.getHi();
    java.lang.Number var6 = var4.getHi();
    java.lang.Number var7 = var4.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1+ "'", var5.equals(1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 1+ "'", var6.equals(1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 1L+ "'", var7.equals(1L));

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(0.1690925369322372d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0143302387887994d);

  }

  public void test116() {}
//   public void test116() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }
// 
// 
//     double[] var2 = new double[] { 0.0d, 100.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
//     double var5 = var3.getElement(0);
//     double[] var6 = var3.getElements();
//     double[] var7 = null;
//     var3.addElements(var7);
// 
//   }

  public void test117() {}
//   public void test117() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     double var7 = var1.nextCauchy(0.15560730683937996d, 3.1780538303479458d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var1.nextUniform(979.3393873505228d, 0.9999999958776927d, true);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-0.0876843047227352d));
// 
//   }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var5 = var3.getElement(0);
    int var6 = var3.start();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setExpansionFactor((-1.0f));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(3.5247804145401362d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.0d);

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.5707963267948966d, (java.lang.Number)2.0f, false);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog((-98), 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test122() {}
//   public void test122() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)10.0d, (java.lang.Number)1L, (java.lang.Number)1);
//     java.lang.Number var5 = var4.getHi();
//     java.lang.Number var6 = var4.getHi();
//     java.lang.String var7 = var4.toString();
// 
//   }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(2L, (-1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3L);

  }

  public void test124() {}
//   public void test124() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(3.1780538303479458d);
//     double var5 = var1.nextExponential(19.39006869589386d);
//     var1.reSeedSecure(9223372036854775807L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var1.nextGaussian(3.1780538303479458d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.9860066545641275d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 7.277065213583589d);
// 
//   }

  public void test125() {}
//   public void test125() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 2);
// 
//   }

  public void test126() {}
//   public void test126() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh((-1.777309158100993d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }


    long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1L);

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(1L, 3L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(6.491753541596189d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 658.6791243661528d);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(short)10, (java.lang.Number)2.0f, false);

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(10.0d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10.0d);

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin((-0.016482976994642014d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.016483723458541454d));

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var4 = var1.nextPascal(0, 658.6791243661528d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(100L, 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }


    org.apache.commons.math3.exception.NoDataException var0 = new org.apache.commons.math3.exception.NoDataException();

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.8390715290764524d));

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(100.0d, 32.94631867978169d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.252532938915154d);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.9999998885745217d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)10.0d, (java.lang.Number)1L, (java.lang.Number)1);
    java.lang.Number var5 = var4.getHi();
    java.lang.Number var6 = var4.getLo();
    java.lang.Throwable[] var7 = var4.getSuppressed();
    java.lang.Number var8 = var4.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1+ "'", var5.equals(1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 1L+ "'", var6.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 1L+ "'", var8.equals(1L));

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.5403023058681398d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-1), 10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test143() {}
//   public void test143() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     double var7 = var1.nextCauchy(0.15560730683937996d, 3.1780538303479458d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var1.nextWeibull(0.0d, 0.5403023058681398d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 3.4406063406716347d);
// 
//   }

  public void test144() {}
//   public void test144() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log10((-0.9880458431278127d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(979.3393873505228d, (-3.657242590218247d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.1519447188851685E-11d);

  }

  public void test146() {}
//   public void test146() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }
// 
// 
//     double[] var2 = new double[] { 0.0d, 100.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
//     double var5 = var3.getElement(0);
//     double[] var6 = var3.getElements();
//     org.apache.commons.math3.util.ResizableDoubleArray var7 = var3.copy();
//     double[] var8 = null;
//     var3.addElements(var8);
// 
//   }

  public void test147() {}
//   public void test147() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(4.499378297809863d, (-0.7853981633974483d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck((-1L), 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0f);

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getNumericalMean();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var3.cumulativeProbability(658.6791243661528d, 0.02318656797210774d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.3235780930645504d);

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    double[] var4 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    var5.setElement(3, (-0.7853981633974483d));
    int var9 = var5.getNumElements();
    java.lang.Object[] var10 = new java.lang.Object[] { var9};
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, var10);
    org.apache.commons.math3.exception.MathIllegalArgumentException var12 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var5 = var3.substituteMostRecentElement(1.3235780930645504d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.discardMostRecentElements(3);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 100.0d);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.025803565724757293d, 71.34241022211371d, 0.15560730683937996d, 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 4.1972216218988037E-35d);

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(0L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    int var4 = var1.nextZipf(100, 10.0d);
    var1.reSeedSecure(10L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var8 = var1.nextSecureHexString(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(3, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-7));

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(0, 100.0f, 1.0f, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(3L, (-1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(15, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 8.00736706798333d);

  }

  public void test160() {}
//   public void test160() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log10((-1.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(0.5403023058681398d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5403023058681399d);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)32.94631867978169d);

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, var1, (java.lang.Number)100L, (java.lang.Number)4.810477380965351d);

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(3.474865488735192d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.8640991091503671d);

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(658.6791243661528d, (-0.016483723458541454d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.0185982056725795d));

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(0.1690925369322372d, 0.025803565724757293d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.057741374677837d);

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(1L, 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2L);

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(0.5573731387105724d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5866841190102328d);

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(100, 2L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10000);

  }

  public void test171() {}
//   public void test171() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }
// 
// 
//     java.lang.Class var0 = null;
//     java.lang.Enum var2 = java.lang.Enum.<java.lang.Enum>valueOf(var0, "");
// 
//   }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(0.0d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test173() {}
//   public void test173() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(3.1780538303479458d);
//     double var5 = var1.nextExponential(19.39006869589386d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var8 = var1.nextPascal(1, 1.8328655053227587d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 4.936712728401891d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 12.391600832277183d);
// 
//   }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10L, (java.lang.Number)3921225.0d, true);
    java.lang.Number var4 = var3.getMax();
    java.lang.Number var5 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 3921225.0d+ "'", var4.equals(3921225.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 3921225.0d+ "'", var5.equals(3921225.0d));

  }

  public void test175() {}
//   public void test175() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextSecureInt(2, 10);
//     double var8 = var1.nextUniform(3.1780538303479458d, 4.810477380965351d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("", "d");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 4.141439017145137d);
// 
//   }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(0, 100L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(4.157279707691014d, 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.037062153555774406d);

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(10, 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.787491742782046d);

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(10.000001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 10);

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray((-1), 10.0f, 1.0f, (-7));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test181() {}
//   public void test181() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(3.1780538303479458d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var6 = var1.nextInt(5, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.935753304645121d);
// 
//   }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(14, 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 537824);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(9, 100.0f, 100.0f, 3);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-0.016483723458541454d), (java.lang.Number)4.499378297809863d, false);

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(3, 9223372036854775807L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1431655765));

  }

  public void test186() {}
//   public void test186() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }
// 
// 
//     double var1 = org.apache.commons.math3.special.Gamma.logGamma(0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan((-0.8390715290764524d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.6981152095798223d));

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(4.810477380965351d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 122.7902212423532d);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.762747174039086d);

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign((-1.777309158100993d), 3.9333619378282223d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.777309158100993d);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(100.0d, 49.1466895834365d, 2.057741374677837d, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException");
    } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
      // Expected exception.
    }

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(3.5247804145401362d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.3738789406485615d));

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(4.754806993644028d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.6815545646570225d);

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var3.setElement(3, (-0.7853981633974483d));
    var3.discardMostRecentElements(0);
    double[] var11 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var11);
    double var14 = var12.getElement(0);
    double[] var15 = var12.getInternalValues();
    var3.addElements(var15);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setExpansionMode((-1431655765));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(9, (-98));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(979.3393873505228d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(100.0f, 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100.0f);

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    int var4 = var1.nextZipf(100, 10.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var8 = var1.nextHypergeometric(100, (-1), 3);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }


    double var2 = org.apache.commons.math3.util.FastMath.min((-0.6981152095798223d), 1.6815545646570225d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.6981152095798223d));

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter((-0.7853981633974483d), 1.7453292519943295d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.7853981633974482d));

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.5403023058681398d, 1.6815545646570225d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9254962739500686d);

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(3.474865488735192d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.060647843842351036d);

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.1752011936438014d));

  }

  public void test204() {}
//   public void test204() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(2.057741374677837d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    int var4 = var1.nextZipf(100, 10.0d);
    var1.reSeedSecure(1L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var1.nextT(Double.NaN);
      fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
    } catch (org.apache.commons.math3.exception.NoBracketingException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-7), 101L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1399408473);

  }

  public void test207() {}
//   public void test207() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(3.474865488735192d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("org.apache.commons.math3.exception.NotPositiveException: 0 is smaller than the minimum (0)");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-7), (java.lang.Number)0.5866841190102328d, false);

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getNumericalMean();
    double[] var9 = var3.sample(1);
    double var11 = var3.density(979.3393873505228d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var13 = var3.inverseCumulativeProbability((-0.3738789406485615d));
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(8.00736706798333d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.15278468894698005d));

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getStandardDeviation();
    double var9 = var3.cumulativeProbability(4.157279707691014d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var11 = var3.inverseCumulativeProbability((-1.777309158100993d));
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.025803565724757293d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(0.5403023058681398d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8144772166995121d);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9.536743E-7f);

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(3L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3L);

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(10000, 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-7), 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-7));

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var2 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.9999998885745217d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.718281525573209d);

  }

  public void test224() {}
//   public void test224() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(3.1780538303479458d);
//     double var5 = var1.nextExponential(19.39006869589386d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var7 = var1.nextSecureHexString((-7));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.6659797383201367d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 46.85077730076413d);
// 
//   }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }


    double var2 = org.apache.commons.math3.special.Erf.erf((-3.657242590218247d), (-0.6740495597759653d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.3404631721379325d);

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)1.8328655053227587d);
    java.lang.Number var2 = var1.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 1.8328655053227587d+ "'", var2.equals(1.8328655053227587d));

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(0.43549250150289726d, 4.754806993644028d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.43549250150289726d);

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(0.037062153555774406d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6.938893903907228E-18d);

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }


    org.apache.commons.math3.exception.MathIllegalStateException var0 = new org.apache.commons.math3.exception.MathIllegalStateException();

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(0, 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(0, 10.000001f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var3 = var1.nextChiSquare((-0.3738789406485615d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0000001f);

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double[] var4 = var3.getElements();
    var3.setElement(6, 0.9254962739500686d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(2.718281525573209d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.6574543343244341d);

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray((-1431655765));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(6.938893903907228E-18d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }


    double var2 = org.apache.commons.math3.util.FastMath.min((-1.777309158100993d), 0.5866841190102328d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.777309158100993d));

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getNumericalMean();
    double[] var9 = var3.sample(1);
    double var11 = var3.density(979.3393873505228d);
    double var13 = var3.density(3921225.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var15 = var3.sample(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);

  }

  public void test240() {}
//   public void test240() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.util.Collection var2 = null;
//     java.lang.Object[] var4 = var1.nextSample(var2, 7);
// 
//   }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(6, 100.0f);

  }

  public void test242() {}
//   public void test242() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextSecureInt(2, 10);
//     double var7 = var1.nextCauchy(0.037062153555774406d, 3.5247804145401362d);
//     double var9 = var1.nextChiSquare(8.00736706798333d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var1.nextBinomial((-98), 6.658240041118693E-4d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-0.4436533240939084d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 7.059454866647101d);
// 
//   }

  public void test243() {}
//   public void test243() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }
// 
// 
//     java.lang.Class var0 = null;
//     java.lang.Enum var2 = java.lang.Enum.<java.lang.Enum>valueOf(var0, "org.apache.commons.math3.exception.NotPositiveException: 0 is smaller than the minimum (0)");
// 
//   }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh((-0.6740495597759653d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.6312775868089657d));

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }


    double var1 = org.apache.commons.math3.special.Erf.erf((-0.7853981633974483d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.7333114255659123d));

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(100L, 101L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 201L);

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(3.1780538303479458d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4702361029356772d);

  }

  public void test249() {}
//   public void test249() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextSecureInt(2, 10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var7 = var1.nextUniform(4.754806993644028d, 0.08193630735653556d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 6);
// 
//   }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(4.754806993644028d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4503293580384904d);

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(0.0f, 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma((-3.657242590218247d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 12.492495498705182d);

  }

  public void test254() {}
//   public void test254() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     var1.reSeedSecure(10L);
//     double var9 = var1.nextBeta(11.332278829291482d, 13.221239069499132d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var12 = var1.nextLong(9L, 3L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.3072030054966341d);
// 
//   }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.5964546144007504d, (-0.49035942660728515d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.5964546144007503d);

  }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(3L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3L);

  }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(71.34241022211371d, 108.227459172826d, (-0.6981152095798223d));

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(0.15560730683937996d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(10, 8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 18);

  }

  public void test260() {}
//   public void test260() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.util.Collection var1 = null;
//     java.lang.Object[] var3 = var0.nextSample(var1, 15);
// 
//   }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(1, 1399408473);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(1399408473, 2.0f, (-1.0f));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test263() {}
//   public void test263() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     var1.reSeedSecure(10L);
//     double var9 = var1.nextF(1.0d, 47.71468531505997d);
//     var1.reSeedSecure(101L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.08076789388642387d);
// 
//   }

  public void test264() {}
//   public void test264() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(3.1780538303479458d, (-1.0d), 5.258584046449211d, 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(19.39006869589386d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.403415571564176d);

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp((-0.49035942660728515d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6124062395251123d);

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.08076789388642387d, 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5.26885534061425E-4d);

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 11013.232920103323d);

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10.0d, (java.lang.Number)1.0f, true);
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    java.lang.Object[] var7 = new java.lang.Object[] { (short)1};
    org.apache.commons.math3.exception.MathArithmeticException var8 = new org.apache.commons.math3.exception.MathArithmeticException(var5, var7);
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, var7);
    java.lang.Throwable[] var10 = var3.getSuppressed();
    java.lang.Number var11 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + 1.0f+ "'", var11.equals(1.0f));

  }

  public void test270() {}
//   public void test270() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     double var7 = var1.nextCauchy(0.15560730683937996d, 3.1780538303479458d);
//     double var11 = var1.nextUniform((-0.6740495597759653d), (-0.016482976994642014d), true);
//     int var14 = var1.nextPascal(5, 0.9864231484692195d);
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("org.apache.commons.math3.exception.NotPositiveException: 0 is smaller than the minimum (0)", "org.apache.commons.math3.exception.NotPositiveException: 0 is smaller than the minimum (0)");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2.291553587885077d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.6326460980992363d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
// 
//   }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(Double.POSITIVE_INFINITY, 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.5707963267948966d);

  }

  public void test272() {}
//   public void test272() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh(0.5866841190102328d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(201L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(1.9124153064037224d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.3646904086155498d);

  }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getNumericalMean();
    double var8 = var3.getSupportUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == Double.POSITIVE_INFINITY);

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(100.0d, (-0.7853981633974483d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100.0d);

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(4.403415571564176d, Double.POSITIVE_INFINITY, 0.0d, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException");
    } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
      // Expected exception.
    }

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var3.setElement(3, (-0.7853981633974483d));
    var3.discardMostRecentElements(0);
    int var9 = var3.getExpansionMode();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(0, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test282() {}
//   public void test282() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(Double.NaN, 1.9124153064037224d, 49.1466895834365d, 1399408473);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(9.536743E-7f, 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.536743E-7f);

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(15, 0.0f, 2.5f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(8.594124866502801d, 0.9864231484692195d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9999974851203858d);

  }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var3.discardMostRecentElements(0);
    double[] var6 = var3.getElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setExpansionFactor(0.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getNumericalMean();
    double var8 = var3.getMean();
    double var10 = var3.probability(1.3440585709080678E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);

  }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(5.258584046449211d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.561776313341697d);

  }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(0, (-1431655765));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }


    long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 40320L);

  }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(3, 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test293() {}
//   public void test293() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 40320L);
// 
//   }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)10.0d, (java.lang.Number)1L, (java.lang.Number)1);
    java.lang.Number var5 = var4.getHi();
    org.apache.commons.math3.exception.NumberIsTooLargeException var9 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10.0d, (java.lang.Number)1.0f, true);
    java.lang.Number var10 = var9.getMax();
    var4.addSuppressed((java.lang.Throwable)var9);
    java.lang.Number var12 = var4.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1+ "'", var5.equals(1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + 1.0f+ "'", var10.equals(1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 1+ "'", var12.equals(1));

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(101L, 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1030301L);

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(9L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9L);

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(1.0d, 2.057741374677837d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.452360517355225d);

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(1.0f, 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.0f);

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(4.157279707691014d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.038940829865108d);

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-98), 1399408473);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    int var4 = var1.nextZipf(100, 10.0d);
    var1.reSeedSecure(1L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var1.nextChiSquare((-0.3738789406485615d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test304() {}
//   public void test304() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.log((-0.7333114255659123d), (-1.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test305() {}
//   public void test305() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(4.157279707691014d, (-1.449245914654094d), 32.94631867978169d, 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(979.3393873505228d, 8.00736706798333d);
    double var3 = var2.getStandardDeviation();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 8.00736706798333d);

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var3.setElement(3, (-0.7853981633974483d));
    float var7 = var3.getContractionCriteria();
    int var8 = var3.getNumElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var3.getElement((-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 4);

  }

  public void test308() {}
//   public void test308() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
//     java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 10000);
// 
//   }

  public void test309() {}
//   public void test309() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     double var7 = var1.nextCauchy(0.15560730683937996d, 3.1780538303479458d);
//     double var11 = var1.nextUniform((-0.6740495597759653d), (-0.016482976994642014d), true);
//     int var14 = var1.nextPascal(5, 0.9864231484692195d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var17 = var1.nextPascal((-7), 15.015849047826396d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-4.5663168827520195d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.48802947969017396d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
// 
//   }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(9223372036854775807L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9223372036854775807L);

  }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(4.787491742782046d, (-0.8309074630677628d), 0.3404631721379325d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-1L), 201L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1L));

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb((-1.0f), 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.0f));

  }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(1L, 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(1L, 100L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test316() {}
//   public void test316() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-0.016482976994642014d), (java.lang.Number)0.9864231484692195d, false);
//     java.lang.String var5 = var4.toString();
// 
//   }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog((-1431655765), 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test318() {}
//   public void test318() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(-0.7853981633974483d), (java.lang.Number)1, true);
//     java.lang.String var5 = var4.toString();
// 
//   }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(1.6873352971776172d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-8.541939077859835d));

  }

  public void test320() {}
//   public void test320() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy var1 = null;
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var2 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var1);
//     double[] var5 = new double[] { 0.0d, 100.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray(var5);
//     double[] var7 = var6.getElements();
//     double[] var10 = new double[] { 0.0d, 100.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var10);
//     double var13 = var11.getElement(0);
//     double[] var14 = var11.getInternalValues();
//     double var15 = var2.mannWhitneyU(var7, var14);
// 
//   }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(18, (-1431655765));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1431655765));

  }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(0.0d, 1.3440585709080678E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.0d));

  }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.0d, 1.8328655053227587d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.8328655053227587d);

  }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(1.7453292519943295d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 8.800174227572448d);

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(10.000001f, 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10.000001f);

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(4.1972216218988037E-35d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(10.000001f, 4.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10.000001f);

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(7, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(3, (-1431655765));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(0L, 2L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(1.8328655053227587d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.2590796335125806d));

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh((-0.016482976994642014d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.016483723377414404d));

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(201L, 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }


    double var2 = org.apache.commons.math3.util.FastMath.max((-0.8390715290764524d), (-1.9868253301309484d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.8390715290764524d));

  }

  public void test335() {}
//   public void test335() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.log(4.499378297809863d, (-0.24076193928529432d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(0.730978507528758d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5486868599002128d);

  }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 13.14778027539684d);

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow((-0.6981152095798223d), 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test339() {}
//   public void test339() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     double var7 = var1.nextCauchy(0.15560730683937996d, 3.1780538303479458d);
//     var1.reSeedSecure(101L);
//     var1.reSeedSecure(10L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 4.189149606287355d);
// 
//   }

  public void test340() {}
//   public void test340() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     double var7 = var1.nextCauchy(0.15560730683937996d, 3.1780538303479458d);
//     double var11 = var1.nextUniform((-0.6740495597759653d), (-0.016482976994642014d), true);
//     int var14 = var1.nextPascal(5, 0.9864231484692195d);
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var19 = var1.nextUniform((-0.49035942660728515d), (-0.7333114255659123d), false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-9.839081230008315d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.5800717189058191d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
// 
//   }

  public void test341() {}
//   public void test341() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)3L, (java.lang.Number)0.5964546144007504d, (java.lang.Number)14);
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     org.apache.commons.math3.exception.util.Localizable var6 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var10 = new org.apache.commons.math3.exception.OutOfRangeException(var6, (java.lang.Number)10.0d, (java.lang.Number)1L, (java.lang.Number)1);
//     java.lang.Number var11 = var10.getHi();
//     org.apache.commons.math3.exception.NumberIsTooLargeException var15 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10.0d, (java.lang.Number)1.0f, true);
//     java.lang.Number var16 = var15.getMax();
//     var10.addSuppressed((java.lang.Throwable)var15);
//     java.lang.Throwable[] var18 = var10.getSuppressed();
//     org.apache.commons.math3.exception.MathIllegalStateException var19 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var5, (java.lang.Object[])var18);
// 
//   }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(0.037062153555774406d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-3.29515894983552d));

  }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(100L, 2L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 102L);

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getNumericalMean();
    double[] var9 = var3.sample(1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var11 = var3.sample((-1));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(1.561776313341697d, 0.09409951665194471d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.03791546974136306d));

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(9);

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(2.5f, 1.0000001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.5f);

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(7, 10);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(9L, 102L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9L);

  }

  public void test350() {}
//   public void test350() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(3.1780538303479458d);
//     double var5 = var1.nextExponential(19.39006869589386d);
//     double var8 = var1.nextBeta(4.499378297809863d, 1.8328655053227587d);
//     int var12 = var1.nextHypergeometric(3, 0, 2);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var16 = var1.nextUniform(3.0d, 0.5513122819358196d, true);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.3454875556425971d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 17.379929578765072d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.6386591887193759d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
// 
//   }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double[] var4 = var3.getElements();
    double[] var5 = var3.getInternalValues();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var7 = var3.getElement(10000);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Object[] var3 = new java.lang.Object[] { (short)1};
    org.apache.commons.math3.exception.MathArithmeticException var4 = new org.apache.commons.math3.exception.MathArithmeticException(var1, var3);
    org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError(var0, var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test353() {}
//   public void test353() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     var1.reSeedSecure(10L);
//     var1.reSeedSecure(100L);
//     java.util.Collection var9 = null;
//     java.lang.Object[] var11 = var1.nextSample(var9, 0);
// 
//   }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.9149287324253481d, (-0.8309074630677628d), 0.025803565724757293d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.5486868599002128d, (java.lang.Number)(-0.11387786884182144d), true);

  }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(0.4148624190190518d, (-0.6740495597759653d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.589870215356601d);

  }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(1.1519447188851685E-11d, 8.00736706798333d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 8.00736706798333d);

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(0.056967924236750636d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05690637728745587d);

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var3.setElement(3, (-0.7853981633974483d));
    int var7 = var3.getNumElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var9 = var3.getElement(15);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 4);

  }

  public void test361() {}
//   public void test361() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     double var7 = var1.nextCauchy(0.15560730683937996d, 3.1780538303479458d);
//     long var9 = var1.nextPoisson(1.5707963267948966d);
//     int var12 = var1.nextInt(0, 7);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var1.nextBinomial((-7), 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-31.484159878507718d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 4);
// 
//   }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(0, 15);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test363() {}
//   public void test363() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     var1.reSeedSecure(10L);
//     double var9 = var1.nextF(1.0d, 47.71468531505997d);
//     long var12 = var1.nextSecureLong(1L, 10L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var15 = var1.nextLong(1L, 1L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.1704541596387681d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 2L);
// 
//   }

  public void test364() {}
//   public void test364() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ((-0.01859736360708744d), 0.5573731387105724d, (-0.6312775868089657d), 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test365() {}
//   public void test365() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
//     java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 1L);
// 
//   }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var5 = var3.getElement(0);
    int var6 = var3.getNumElements();
    var3.contract();
    var3.addElement((-0.016483723458541454d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2);

  }

  public void test367() {}
//   public void test367() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextSecureInt(2, 10);
//     double var8 = var1.nextUniform(3.1780538303479458d, 4.810477380965351d, false);
//     double var11 = var1.nextF(2.4823187300238665d, 0.5573731387105724d);
//     var1.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 4.315213397797969d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.6991252484815342d);
// 
//   }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getNumericalMean();
    double[] var9 = var3.sample(15);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var12 = var3.cumulativeProbability(3.657242590218247d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(4.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.7683716E-7f);

  }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(11.28403526992695d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-3.3699820317502858d));

  }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(0.7099849575852162d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 40.67914158740765d);

  }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(0.452360517355225d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.007895180433873628d);

  }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(0L, 102L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 102L);

  }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh(0.02318656797210774d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.023190724476818098d);

  }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.5573731387105724d, 1.5707963267948966d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.5573731387105724d);

  }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(1.0000001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0000001f);

  }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(0L, (-7));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(0.0f, 1.0000001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0000001f);

  }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.3841858E-7f);

  }

  public void test380() {}
//   public void test380() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     double var7 = var1.nextCauchy(0.15560730683937996d, 3.1780538303479458d);
//     var1.reSeed(101L);
//     java.lang.String var11 = var1.nextSecureHexString(100);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var1.nextCauchy(0.452360517355225d, (-0.6981152095798223d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-0.07050558056253825d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "0704cafaee5ec84a70bf8daf62d0fdab7e6c89e5abc1659f4bbbf8ce8dd94e12a6aa4d49d7e669e8bde2ded0067bc9806200"+ "'", var11.equals("0704cafaee5ec84a70bf8daf62d0fdab7e6c89e5abc1659f4bbbf8ce8dd94e12a6aa4d49d7e669e8bde2ded0067bc9806200"));
// 
//   }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(1);
    var1.setElement(0, (-0.9880458431278127d));
    var1.setExpansionFactor(2.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.discardFrontElements(4);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(5.258584046449211d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.5803271935147514d);

  }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(8, 537824);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign((-0.4833507072637169d), 0.5964546144007504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.4833507072637169d);

  }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(2.8094479062051723d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9927689477197732d);

  }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }


    org.apache.commons.math3.exception.NullArgumentException var0 = new org.apache.commons.math3.exception.NullArgumentException();

  }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(18, 100L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(0, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test390() {}
//   public void test390() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(3.1780538303479458d);
//     double var5 = var1.nextExponential(19.39006869589386d);
//     var1.reSeedSecure(9223372036854775807L);
//     var1.reSeedSecure(2L);
//     double var12 = var1.nextWeibull(0.5403023058681398d, 0.43549250150289726d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var1.nextBeta((-0.6981152095798223d), (-0.03791546974136306d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.10026650546015396d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 21.313375811851568d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.113377973677079d);
// 
//   }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(5.081775104347323d, 32.94631867978169d, 1.8328655053227587d, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException");
    } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
      // Expected exception.
    }

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getNumericalMean();
    double[] var9 = var3.sample(1);
    double var11 = var3.density(979.3393873505228d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var14 = var3.cumulativeProbability(40.67914158740765d, 0.4833507072637169d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);

  }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(2.8094479062051723d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.049034116126541086d);

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("17f8789cc43bb2106dfbda8a540d6d9b774b8ed025f9ccf3a610e661aacb917f64a8802d7a68fd069f87939570a60c437206");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(2, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(0L, 3L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-3L));

  }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(0L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(0L, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble(10000);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 10.0f);

  }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(0.9149287324253481d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.649680406496415d);

  }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    java.lang.String var3 = var1.toString();
    java.lang.String var4 = var1.name();
    java.lang.Class var5 = var1.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var7 = java.lang.Enum.<java.lang.Enum>valueOf(var5, "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "AVERAGE"+ "'", var3.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "AVERAGE"+ "'", var4.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test404() {}
//   public void test404() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var1 = null;
//     java.math.BigInteger var3 = org.apache.commons.math3.util.ArithmeticUtils.pow(var1, 0L);
//     java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, var3);
// 
//   }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(1.9124153064037224d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.9124153064037221d);

  }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(15, 14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.70805020110221d);

  }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.NEGATIVE_INFINITY);

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(byte)100, (java.lang.Number)(-3L), false);

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Object[] var3 = new java.lang.Object[] { (short)1};
    org.apache.commons.math3.exception.MathArithmeticException var4 = new org.apache.commons.math3.exception.MathArithmeticException(var1, var3);
    java.lang.Throwable[] var5 = var4.getSuppressed();
    org.apache.commons.math3.exception.NullArgumentException var6 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(2, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2);

  }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(-3.29515894983552d));

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getNumericalMean();
    double[] var9 = var3.sample(1);
    double var11 = var3.density(979.3393873505228d);
    var3.reseedRandomGenerator(0L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var16 = var3.cumulativeProbability(31.840944456096064d, 0.08193630735653556d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(1030301L, 3L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(0.5513122819358196d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7425040618985324d);

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test416() {}
//   public void test416() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.random.RandomGenerator var1 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var1);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
//     double var9 = var6.cumulativeProbability(0.0d, 0.1690925369322372d);
//     double var10 = var6.getNumericalMean();
//     double[] var12 = var6.sample(1);
//     double var14 = var6.density(979.3393873505228d);
//     double[] var16 = var6.sample(2);
//     double[] var17 = var2.rank(var16);
// 
//   }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var5 = var3.getElement(0);
    var3.setElement(4, (-0.8309074630677628d));
    int var9 = var3.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);

  }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(10.0f, 9.536743E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.536743E-7f);

  }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test420() {}
//   public void test420() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     var1.reSeedSecure(10L);
//     double var9 = var1.nextCauchy(1.762747174039086d, 0.025803565724757293d);
//     double var11 = var1.nextExponential(6.938893903907228E-18d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var1.nextSecureInt(537824, 15);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.74360604638904d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 7.561150038529116E-19d);
// 
//   }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(49.1466895834365d, (-0.21452323545111215d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(102L, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-7227766516491148288L));

  }

  public void test424() {}
//   public void test424() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     var1.reSeedSecure((-1L));
//     var1.reSeed();
//     double var11 = var1.nextUniform(0.5513122819358196d, 3.657242590218247d, false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.705287720983563d);
// 
//   }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1920929E-7f);

  }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo((-1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var3.setElement(3, (-0.7853981633974483d));
    double[] var7 = var3.getElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var9 = var3.getElement(4);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var3.setElement(3, (-0.7853981633974483d));
    int var7 = var3.getNumElements();
    double var9 = var3.substituteMostRecentElement((-0.7853981633974483d));
    float var10 = var3.getExpansionFactor();
    double var12 = var3.getElement(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setExpansionMode(9);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-0.7853981633974483d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);

  }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.0d, (java.lang.Number)(-1.0f), (java.lang.Number)9223372036854775807L);
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var3.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test430() {}
//   public void test430() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
//     java.math.BigInteger var3 = null;
//     java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0L);
//     java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, var3);
// 
//   }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(19.39006869589386d, 0.025803565724757293d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 19.390068695893856d);

  }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)19.39006869589386d);
    boolean var2 = var1.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test433() {}
//   public void test433() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextSecureInt(2, 10);
//     var1.reSeed(3L);
//     int var9 = var1.nextInt(0, 10);
//     double var12 = var1.nextGaussian(0.0d, 47.71468531505997d);
//     java.util.Collection var13 = null;
//     java.lang.Object[] var15 = var1.nextSample(var13, 10000);
// 
//   }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(3.0d, 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.802951800684688E30d);

  }

  public void test435() {}
//   public void test435() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
//     java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0);
// 
//   }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var4 = var1.nextSecureLong(2L, 1L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test437() {}
//   public void test437() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(3.1780538303479458d);
//     double var5 = var1.nextExponential(19.39006869589386d);
//     double var8 = var1.nextBeta(4.499378297809863d, 1.8328655053227587d);
//     int var11 = var1.nextBinomial(14, 0.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var1.nextWeibull(0.0d, 1.6574543343244341d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2.2689898149970835d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 17.21469660812912d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.8643365472347966d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0);
// 
//   }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma((-0.016483723377414404d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 60.06124336900233d);

  }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    java.lang.String var3 = var1.toString();
    java.lang.String var4 = var1.toString();
    java.lang.String var5 = var1.name();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "AVERAGE"+ "'", var3.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "AVERAGE"+ "'", var4.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "AVERAGE"+ "'", var5.equals("AVERAGE"));

  }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(0.3404631721379325d, 8.00736706798333d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.042493147057781525d);

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs((-0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(0.1690925369322372d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.1690925369322372d);

  }

  public void test443() {}
//   public void test443() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(3.1780538303479458d);
//     double var5 = var1.nextExponential(19.39006869589386d);
//     double var8 = var1.nextBeta(4.499378297809863d, 1.8328655053227587d);
//     int var11 = var1.nextBinomial(14, 0.0d);
//     double var15 = var1.nextUniform(1.893344644644389d, 3.0d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("", "hi!");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 8.236772949544985d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.7083708912909041d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.4337963235456676d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2.648637481838559d);
// 
//   }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }


    double var2 = org.apache.commons.math3.util.FastMath.min((-18714.452905875783d), 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-18714.452905875783d));

  }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.4105991453937372d, 0.5964546144007504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.7241199936737109d);

  }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-1L), 18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(100);

  }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(8, 10);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test449() {}
//   public void test449() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy[] var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
//     org.apache.commons.math3.exception.MathIllegalArgumentException var2 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var1);
//     org.apache.commons.math3.exception.MathInternalError var3 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var2);
// 
//   }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(0.025185327490526228d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.025185327490526228d);

  }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }


    long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5040L);

  }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double[] var4 = var3.getElements();
    double[] var5 = var3.getInternalValues();
    int var6 = var3.start();
    float var7 = var3.getContractionCriteria();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.5f);

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(14, 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 29);

  }

  public void test454() {}
//   public void test454() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextSecureInt(2, 10);
//     var1.reSeed(3L);
//     int var9 = var1.nextInt(0, 10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("17f8789cc43bb2106dfbda8a540d6d9b774b8ed025f9ccf3a610e661aacb917f64a8802d7a68fd069f87939570a60c437206", "org.apache.commons.math3.exception.NotPositiveException: 0 is smaller than the minimum (0)");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 9);
// 
//   }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getNumericalMean();
    double[] var9 = var3.sample(1);
    double var11 = var3.density(979.3393873505228d);
    double var13 = var3.density(3921225.0d);
    double[] var15 = var3.sample(10000);
    boolean var16 = var3.isSupportUpperBoundInclusive();
    double var17 = var3.getMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1.3235780930645504d);

  }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.7425040618985324d, 0.02318656797210774d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.7425040618985324d);

  }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(1.4702361029356772d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getStandardDeviation();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)10.0d, (java.lang.Number)1L, (java.lang.Number)1);
    java.lang.Number var5 = var4.getHi();
    java.lang.Number var6 = var4.getLo();
    java.lang.Number var7 = var4.getLo();
    java.lang.Number var8 = var4.getHi();
    java.lang.Number var9 = var4.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1+ "'", var5.equals(1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 1L+ "'", var6.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 1L+ "'", var7.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 1+ "'", var8.equals(1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + 1+ "'", var9.equals(1));

  }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var5 = var3.getElement(0);
    int var6 = var3.getNumElements();
    int var7 = var3.getExpansionMode();
    float var8 = var3.getExpansionFactor();
    float var9 = var3.getContractionCriteria();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 2.5f);

  }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(2, 8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10);

  }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)10.0d, (java.lang.Number)1L, (java.lang.Number)1);
    java.lang.Number var5 = var4.getHi();
    org.apache.commons.math3.exception.NumberIsTooLargeException var9 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10.0d, (java.lang.Number)1.0f, true);
    java.lang.Number var10 = var9.getMax();
    var4.addSuppressed((java.lang.Throwable)var9);
    java.lang.Number var12 = var4.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1+ "'", var5.equals(1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + 1.0f+ "'", var10.equals(1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 10.0d+ "'", var12.equals(10.0d));

  }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getNumericalMean();
    double var8 = var3.getNumericalVariance();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var10 = var3.sample(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 6.658240041118693E-4d);

  }

  public void test464() {}
//   public void test464() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     var1.reSeedSecure(10L);
//     double var9 = var1.nextF(1.0d, 47.71468531505997d);
//     long var12 = var1.nextSecureLong(1L, 10L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var14 = var1.nextSecureHexString(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 3.7819137721192506d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 8L);
// 
//   }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(4.810477380965351d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.0d);

  }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(1);
    var1.setElement(0, (-0.9880458431278127d));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setExpansionFactor(4.7683716E-7f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test467() {}
//   public void test467() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(3.1780538303479458d);
//     double var5 = var1.nextExponential(19.39006869589386d);
//     double var8 = var1.nextBeta(4.499378297809863d, 1.8328655053227587d);
//     int var11 = var1.nextBinomial(14, 0.0d);
//     double var15 = var1.nextUniform(1.893344644644389d, 3.0d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var18 = var1.nextPermutation(1, 10);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.720597333733982d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 86.79924143031323d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.5118926780510962d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2.8783425954017394d);
// 
//   }

  public void test468() {}
//   public void test468() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(3.1780538303479458d);
//     double var5 = var1.nextExponential(19.39006869589386d);
//     var1.reSeedSecure(9223372036854775807L);
//     var1.reSeedSecure(2L);
//     var1.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var1.nextUniform(13.14778027539684d, 10.923276331316844d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2.1089228758034158d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 15.55030122530654d);
// 
//   }

  public void test469() {}
//   public void test469() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     double var7 = var1.nextCauchy(0.15560730683937996d, 3.1780538303479458d);
//     long var9 = var1.nextPoisson(1.5707963267948966d);
//     int var12 = var1.nextInt(0, 7);
//     double var15 = var1.nextF(34.62483743197144d, 4.787491742782046d);
//     java.util.Collection var16 = null;
//     java.lang.Object[] var18 = var1.nextSample(var16, 7);
// 
//   }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(0L, 5040L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(2L, 1030301L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1030301L);

  }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(70L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(1.561776313341697d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2285491878461101d);

  }

  public void test475() {}
//   public void test475() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     var1.reSeedSecure(10L);
//     double var9 = var1.nextF(1.0d, 47.71468531505997d);
//     int var12 = var1.nextZipf(18, 0.049034116126541086d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("", "");
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.03163916844664711d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 18);
// 
//   }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(100L, 1030301L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(0.0f, 10.000001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10.000001f);

  }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.3841858E-7f);

  }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6);

  }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial((-98));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test481() {}
//   public void test481() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     double var7 = var1.nextCauchy(0.15560730683937996d, 3.1780538303479458d);
//     double var11 = var1.nextUniform((-0.6740495597759653d), (-0.016482976994642014d), true);
//     int var14 = var1.nextPascal(5, 0.9864231484692195d);
//     var1.reSeedSecure();
//     int var18 = var1.nextInt(0, 7);
//     long var20 = var1.nextPoisson(71.34241022211371d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var23 = var1.nextUniform(49.1466895834365d, 1.2285491878461101d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 4.176347981130322d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.18023143482135315d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 73L);
// 
//   }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd((-1L), 100L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(0, 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.8292744355322256d, (java.lang.Number)(-0.016483723377414404d), true);

  }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getNumericalMean();
    double[] var9 = var3.sample(1);
    double var11 = var3.density(979.3393873505228d);
    double var13 = var3.density(3921225.0d);
    double[] var15 = var3.sample(10000);
    double var16 = var3.getMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1.3235780930645504d);

  }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(8.00736706798333d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9.0d);

  }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    int var4 = var1.nextZipf(100, 10.0d);
    var1.reSeedSecure((-1L));
    var1.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var10 = var1.nextZipf(8, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);

  }

  public void test488() {}
//   public void test488() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(3.1780538303479458d);
//     double var5 = var1.nextExponential(19.39006869589386d);
//     var1.reSeedSecure(9223372036854775807L);
//     var1.reSeedSecure(2L);
//     var1.reSeed();
//     int var13 = var1.nextBinomial(100, 0.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var17 = var1.nextUniform(0.9999974851203858d, 0.0d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 6.337882151158491d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 3.8197062735344454d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0);
// 
//   }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(1399408473, 537824);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1398870649);

  }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(-0.016482976994642014d));

  }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog(8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 10.60460290274525d);

  }

  public void test492() {}
//   public void test492() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     var1.reSeedSecure(10L);
//     double var9 = var1.nextF(1.0d, 47.71468531505997d);
//     long var12 = var1.nextSecureLong(1L, 10L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var1.nextHypergeometric(537824, 10000, (-1431655765));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 4.030837576330824d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 2L);
// 
//   }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var2 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MaxCountExceededException var3 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)0.007895180433873628d, (java.lang.Object[])var2);
    java.lang.Number var4 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0.007895180433873628d+ "'", var4.equals(0.007895180433873628d));

  }

  public void test494() {}
//   public void test494() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Object[] var2 = new java.lang.Object[] { (short)1};
//     org.apache.commons.math3.exception.MathArithmeticException var3 = new org.apache.commons.math3.exception.MathArithmeticException(var0, var2);
//     java.lang.String var4 = var3.toString();
// 
//   }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd((-1431655765), 7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(2.718281525573209d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.45054989843996807d));

  }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(1.762747174039086d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test498() {}
//   public void test498() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     double var7 = var1.nextCauchy(0.15560730683937996d, 3.1780538303479458d);
//     double var11 = var1.nextUniform((-0.6740495597759653d), (-0.016482976994642014d), true);
//     int var14 = var1.nextPascal(5, 0.9864231484692195d);
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var19 = var1.nextUniform(12.992787532971414d, 0.34943406609505034d, true);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-3.541250026761165d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.3894994411115627d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
// 
//   }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var5 = var3.getElement(0);
    double[] var6 = var3.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = var3.copy();
    var3.addElement(3.657242590218247d);
    org.apache.commons.math3.util.ResizableDoubleArray var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray.copy(var3, var10);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(201L, 201L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 201L);

  }

}
