
import junit.framework.*;

public class RandoopTest2 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test1"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(3.8221290494758464d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999999353024235d);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test2"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var5 = var3.getElement(0);
    var3.addElement(0.5403023058681398d);
    var3.discardFrontElements(0);
    double[] var10 = var3.getInternalValues();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setElement((-7), (-0.8390715290764524d));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test3"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test4"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test5"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(1763, 1431655772);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1431657535);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test6"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)1030301L);
    java.lang.Number var3 = var2.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test7"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(2.5842611209158894d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.6780782700309453d);

  }

  public void test8() {}
//   public void test8() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test8"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     double var7 = var1.nextCauchy(0.15560730683937996d, 3.1780538303479458d);
//     long var9 = var1.nextPoisson(1.5707963267948966d);
//     var1.reSeed(101L);
//     double var14 = var1.nextCauchy(0.0d, 108.227459172826d);
//     int var17 = var1.nextBinomial(68, 0.023190724476818098d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-1.1592768221762735d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-352.69596618548d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0);
// 
//   }

  public void test9() {}
//   public void test9() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test9"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP((-0.2386431858481304d), 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test10"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.9E-324d);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test11"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NoDataException var1 = new org.apache.commons.math3.exception.NoDataException(var0);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test12"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(1399408455, 17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 324.50328913893867d);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test13"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)1.7334893091042638d);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test14"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var5 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var4);
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var4);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var7 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var4);
    java.lang.String var8 = var4.name();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));

  }

  public void test15() {}
//   public void test15() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test15"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextSecureInt(2, 10);
//     var1.reSeed(3L);
//     java.lang.String var8 = var1.nextSecureHexString(18);
//     double var11 = var1.nextGamma(0.43549250150289726d, (-3.487382421758058d));
//     double var14 = var1.nextGamma((-0.7853981633974483d), 5.26885534061425E-4d);
//     org.apache.commons.math3.distribution.IntegerDistribution var15 = null;
//     int var16 = var1.nextInversionDeviate(var15);
// 
//   }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test16"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)8.800174227572448d, (java.lang.Number)3.474865488735192d, true);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.OutOfRangeException var9 = new org.apache.commons.math3.exception.OutOfRangeException(var5, (java.lang.Number)10.0d, (java.lang.Number)1L, (java.lang.Number)1);
    java.lang.Number var10 = var9.getHi();
    org.apache.commons.math3.exception.NumberIsTooLargeException var14 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10.0d, (java.lang.Number)1.0f, true);
    java.lang.Number var15 = var14.getMax();
    var9.addSuppressed((java.lang.Throwable)var14);
    java.lang.Number var17 = var9.getLo();
    java.lang.Number var18 = var9.getArgument();
    java.lang.Number var19 = var9.getLo();
    java.lang.Number var20 = var9.getHi();
    var4.addSuppressed((java.lang.Throwable)var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + 1+ "'", var10.equals(1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + 1.0f+ "'", var15.equals(1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + 1L+ "'", var17.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + 10.0d+ "'", var18.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + 1L+ "'", var19.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + 1+ "'", var20.equals(1));

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test17"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getNumericalMean();
    double[] var9 = var3.sample(1);
    double var11 = var3.density(15.015849047826396d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test18"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp((-9.602370808556296d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.7763568394002505E-15d);

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test19"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getNumericalMean();
    double[] var9 = var3.sample(1);
    double var11 = var3.density(979.3393873505228d);
    var3.reseedRandomGenerator(0L);
    double var14 = var3.sample();
    double var16 = var3.cumulativeProbability(0.5403023058681398d);
    double var17 = var3.getNumericalVariance();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var19 = var3.inverseCumulativeProbability((-0.13150293356331766d));
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.322456124528837d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 6.658240041118693E-4d);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test20"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.686579669341957d, (-0.7988667594075136d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.6865796693419569d);

  }

  public void test21() {}
//   public void test21() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test21"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextSecureInt(2, 10);
//     var1.reSeed(3L);
//     int var9 = var1.nextInt(0, 10);
//     double var12 = var1.nextGaussian(0.0d, 47.71468531505997d);
//     double var14 = var1.nextChiSquare(0.3109275960372989d);
//     int var17 = var1.nextZipf(14, 1.3440585709080678E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 108.227459172826d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 3.9458787581917447E-7d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
// 
//   }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test22"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getNumericalMean();
    double[] var9 = var3.sample(1);
    double var11 = var3.density(979.3393873505228d);
    double var13 = var3.density(3921225.0d);
    boolean var14 = var3.isSupportLowerBoundInclusive();
    double var15 = var3.getNumericalMean();
    boolean var16 = var3.isSupportUpperBoundInclusive();
    double var17 = var3.getSupportUpperBound();
    double var19 = var3.cumulativeProbability(3.657242590218247d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test23"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var5 = var3.cumulativeProbability(0.0d);
    double var6 = var3.getSupportUpperBound();
    double var7 = var3.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.3235780930645504d);

  }

  public void test24() {}
//   public void test24() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test24"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     double var7 = var1.nextCauchy(0.15560730683937996d, 3.1780538303479458d);
//     double var11 = var1.nextUniform((-0.6740495597759653d), (-0.016482976994642014d), true);
//     int var14 = var1.nextPascal(5, 0.9864231484692195d);
//     var1.reSeedSecure();
//     double var18 = var1.nextGamma(5.410266968958382d, (-20.34054861465728d));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var20 = var1.nextPoisson((-1.777309158100993d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.442969881689749d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.15968481504875023d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-96.43814687930849d));
// 
//   }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test25"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(0.8740383559599469d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1102230246251565E-16d);

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test26"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(1, 1491846144);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1491846145);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test27"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp((-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.99999994f));

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test28"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var5 = var3.getElement(0);
    int var6 = var3.start();
    int var7 = var3.getExpansionMode();
    float var8 = var3.getContractionCriteria();
    float var9 = var3.getContractionCriteria();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 2.5f);

  }

  public void test29() {}
//   public void test29() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test29"); }
// 
// 
//     double[] var2 = new double[] { 0.0d, 100.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
//     var3.setElement(3, (-0.7853981633974483d));
//     int var7 = var3.getNumElements();
//     double var9 = var3.substituteMostRecentElement((-0.7853981633974483d));
//     float var10 = var3.getExpansionFactor();
//     double var12 = var3.getElement(0);
//     double var14 = var3.addElementRolling(0.5573731387105724d);
//     double[] var15 = null;
//     var3.addElements(var15);
// 
//   }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test30"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)(-0.2386431858481304d), (java.lang.Number)1700, (java.lang.Number)3.69593234647658d);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test31"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var8 = var3.cumulativeProbability(10.0d);
    double var9 = var3.getNumericalVariance();
    double var10 = var3.getNumericalMean();
    double var11 = var3.getMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 6.658240041118693E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1.3235780930645504d);

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test32"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(1061208L, (-1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1061208L);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test33"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var3.setElement(3, (-0.7853981633974483d));
    int var7 = var3.getNumElements();
    int var8 = var3.getExpansionMode();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test34"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm((-5), 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5);

  }

  public void test35() {}
//   public void test35() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test35"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     double var7 = var1.nextCauchy(0.15560730683937996d, 3.1780538303479458d);
//     long var9 = var1.nextPoisson(1.5707963267948966d);
//     var1.reSeed(101L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("0078547", "org.apache.commons.math3.exception.NotPositiveException: 0 is smaller than the minimum (0)");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-0.0642698818113957d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2L);
// 
//   }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test36"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp((-0.99999994f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.9604645E-8f);

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test37"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(9, 0.0f, 2.3841858E-7f, 58347);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test38"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(9, 1399408473);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1399408482);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test39"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.7763568394002505E-15d, (java.lang.Number)2L, false);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test40"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(176.73201156338953d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7);

  }

  public void test41() {}
//   public void test41() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test41"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(3.1780538303479458d);
//     double var5 = var1.nextExponential(19.39006869589386d);
//     var1.reSeedSecure(9223372036854775807L);
//     var1.reSeedSecure(2L);
//     var1.reSeed();
//     int var13 = var1.nextBinomial(100, 0.0d);
//     int var16 = var1.nextPascal(3, 0.7241199936737109d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var19 = var1.nextPascal((-9800), 1.9124153064037221d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.858419516911983d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 37.57650987168872d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0);
// 
//   }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test42"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(0.9864231484692195d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.017216331758676744d);

  }

  public void test43() {}
//   public void test43() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test43"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     var1.reSeedSecure(10L);
//     double var9 = var1.nextF(1.0d, 47.71468531505997d);
//     long var12 = var1.nextSecureLong(1L, 10L);
//     long var15 = var1.nextSecureLong(100L, 477733L);
//     var1.reSeed(9L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var20 = var1.nextSecureLong((-3L), (-3017481761840155127L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2.064299505921709d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 2L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 357439L);
// 
//   }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test44"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(0.7641028487401796d, 0.9864231484692195d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.050807334874102675d);

  }

  public void test45() {}
//   public void test45() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test45"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     double var7 = var1.nextCauchy(0.15560730683937996d, 3.1780538303479458d);
//     long var9 = var1.nextPoisson(1.5707963267948966d);
//     var1.reSeed(101L);
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution(979.3393873505228d, 8.00736706798333d);
//     double var15 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     int var18 = var1.nextSecureInt(10000, 537824);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("d", "b7668135312ebfb291");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-1.6016587138552187d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 968.8343073325332d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 274432);
// 
//   }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test46"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var3.setElement(3, (-0.7853981633974483d));
    var3.discardMostRecentElements(0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var9 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = var11.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var13 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var10, var12);
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var9, var12);
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12);
    boolean var16 = var3.equals((java.lang.Object)var15);
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var15.getTiesStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test47() {}
//   public void test47() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test47"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.sqrt((-0.45054989843996807d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test48"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(2.5f, 19.804501413383605d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.5000002f);

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test49"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var3 = var2.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var3);
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var3);
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var5.getTiesStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test50"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getNumericalMean();
    double[] var9 = var3.sample(1);
    double var11 = var3.density(979.3393873505228d);
    double var13 = var3.density(3921225.0d);
    boolean var14 = var3.isSupportLowerBoundInclusive();
    var3.reseedRandomGenerator(0L);
    double var18 = var3.density(40.67914158740765d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test51"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    int var4 = var1.nextZipf(100, 10.0d);
    var1.reSeedSecure(1L);
    int[] var9 = var1.nextPermutation(10000, 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test52"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(8.00736706798333d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9034897375799414d);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test53"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(0.7567741732634853d, 0.5196265085690617d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.5196265085690617d);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test54"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp((-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1920929E-7f);

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test55"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(0L, 343641L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test56"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(1061208L, (-40250L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-42713622000L));

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test57"); }


    double[] var0 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    var1.addElement(Double.NaN);
    var1.discardFrontElements(1);

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test58"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(9.161381204155603d, (-75.12530904978745d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.161381204155603d);

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test59"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(0.31170684257905307d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 11.412564855387856d);

  }

  public void test60() {}
//   public void test60() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test60"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(3.1780538303479458d);
//     double var5 = var1.nextExponential(19.39006869589386d);
//     var1.reSeedSecure();
//     double var8 = var1.nextExponential(1.3261490724357603d);
//     int[] var11 = var1.nextPermutation(3, 3);
//     long var14 = var1.nextLong(9L, 10L);
//     int var17 = var1.nextSecureInt(1763, 1431657535);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var20 = var1.nextInt(1398870649, 14);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 4.82177835364067d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 15.320535684881659d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.28582729673315393d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 9L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 307136677);
// 
//   }

  public void test61() {}
//   public void test61() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test61"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log10((-15.937414129423429d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test62"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(1763, (-98));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1861);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test63"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh(0.7425040618985324d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.956037264045509d);

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test64"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(0, 4);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test65"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var2 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.NullArgumentException var3 = new org.apache.commons.math3.exception.NullArgumentException(var1, (java.lang.Object[])var2);
    org.apache.commons.math3.exception.MathArithmeticException var4 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test66"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var5 = var3.cumulativeProbability(0.0d);
    double var6 = var3.getSupportUpperBound();
    double var7 = var3.getStandardDeviation();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var9 = var3.inverseCumulativeProbability((-0.03792456006137928d));
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.025803565724757293d);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test67"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)2885.026171454364d, (java.lang.Number)0.7607318203617716d, false);
    boolean var5 = var4.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test68"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(25.19122118273868d, 0.40669696534821026d, 1.252532938915154d);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test69"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(38, 152444951);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test70"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(1763, (-196));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1567);

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test71"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)1.7453292519943295d, false);
    java.lang.Number var4 = var3.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 1.7453292519943295d+ "'", var4.equals(1.7453292519943295d));

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test72"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.7607318203617716d, 1.348220504432292d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.17839279645410733d);

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test73"); }


    double var1 = org.apache.commons.math3.special.Erf.erf((-1.194247194430087d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.9087653490514768d));

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test74"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10L, (java.lang.Number)2.0d, false);

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test75"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0.9592475867535211d);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test76"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(2L, (-1040868107005177007L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test77"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    int var4 = var1.nextZipf(100, 10.0d);
    var1.reSeedSecure(10L);
    var1.reSeedSecure(100L);
    int[] var11 = var1.nextPermutation(18, 7);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var13 = var1.nextChiSquare(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test78"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(201L, (-42713622000L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 42713622201L);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test79"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot((-0.07474017391621185d), (-38.38421194679636d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 38.38428471223844d);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test80"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0.9018588507146864d, (java.lang.Number)(-2.3306405007995967d), (java.lang.Number)0.8740383559599469d);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test81"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var1 = null;
    org.apache.commons.math3.exception.MathIllegalArgumentException var2 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var1);

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test82"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(0.8740383559599469d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6280956510347088d);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test83"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.8923313678787291d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.627598677589847d);

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test84"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var3.setElement(3, (-0.7853981633974483d));
    int var7 = var3.getNumElements();
    double var9 = var3.substituteMostRecentElement((-0.7853981633974483d));
    float var10 = var3.getExpansionFactor();
    var3.contract();
    var3.setElement(14, 6.491753541596189d);
    var3.setElement(10000, 1.252532938915154d);
    var3.addElement(0.3569670254374492d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-0.7853981633974483d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 2.0f);

  }

  public void test85() {}
//   public void test85() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test85"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(3.1780538303479458d);
//     double var5 = var1.nextExponential(19.39006869589386d);
//     double var8 = var1.nextBeta(4.499378297809863d, 1.8328655053227587d);
//     var1.reSeedSecure(355687428096000L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var1.nextGaussian(0.5091610255820427d, (-2.0832984452539125d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 5.009548831975528d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 38.579157051298075d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.711787939903987d);
// 
//   }

  public void test86() {}
//   public void test86() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test86"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test87() {}
//   public void test87() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test87"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)100.0d, (java.lang.Number)(-2.1805166473703887d), true);
//     java.lang.Number var5 = var4.getArgument();
//     java.lang.Number var6 = var4.getMax();
//     org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var4);
// 
//   }

  public void test88() {}
//   public void test88() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test88"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.0d, 0.042493147057781525d, 0.0d, 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test89"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.34943406609505034d, (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.059294183193564d);

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test90"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(0.3109275960372989d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0487286688968165d);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test91"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent((-0.43684372706947217d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-2));

  }

  public void test92() {}
//   public void test92() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test92"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextSecureInt(2, 10);
//     var1.reSeed(3L);
//     int var9 = var1.nextInt(0, 10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var12 = var1.nextLong(9L, (-7227766516491148288L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 9);
// 
//   }

  public void test93() {}
//   public void test93() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test93"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextSecureInt(2, 10);
//     double var8 = var1.nextUniform(3.1780538303479458d, 4.810477380965351d, false);
//     double var11 = var1.nextF(2.4823187300238665d, 0.5573731387105724d);
//     java.lang.String var13 = var1.nextHexString(1);
//     java.lang.String var15 = var1.nextSecureHexString(10000);
//     var1.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 3.760344905943776d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 248.820958136101d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "d"+ "'", var13.equals("d"));
// 
//   }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test94"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(9, 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 36.0d);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test95"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(0.451843130811387d, 15.996697063082339d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.451843130811387d);

  }

  public void test96() {}
//   public void test96() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test96"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     var1.reSeedSecure(1L);
//     double var9 = var1.nextGamma(1.4994259604654114d, 0.037062153555774406d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.05228453694251407d);
// 
//   }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test97"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(0.6750463740655989d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7410275570209914d);

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test98"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var3 = var2.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var3);
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var3);
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3);
    double[] var9 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(var9);
    double var12 = var10.getElement(0);
    var10.addElement(0.5403023058681398d);
    var10.discardFrontElements(0);
    double[] var17 = var10.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray(var17);
    double[] var19 = var6.rank(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test99() {}
//   public void test99() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test99"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextSecureInt(2, 10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var7 = var1.nextPascal((-2), 0.336819898262453d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 2);
// 
//   }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test100"); }


    double var1 = org.apache.commons.math3.util.FastMath.acos((-0.016483723377414404d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5872807967376275d);

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test101"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(2.0f, (-196));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test102() {}
//   public void test102() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test102"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     double var7 = var1.nextCauchy(0.15560730683937996d, 3.1780538303479458d);
//     long var9 = var1.nextPoisson(1.5707963267948966d);
//     int var12 = var1.nextSecureInt(7, 58347);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-6.382832370414748d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 6742);
// 
//   }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test103"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(2885.026171454364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.4667738496557693E-4d);

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test104"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign((-15.937414129423429d), 19.39006869589386d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 15.937414129423429d);

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test105"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var3 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var2);
    java.lang.String var4 = var2.name();
    java.lang.Class var5 = var2.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var7 = java.lang.Enum.<java.lang.Enum>valueOf(var5, "2068346a96");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "AVERAGE"+ "'", var4.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test106"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(477733L, 5040L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 482773L);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test107"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.6522307253250917d, (-3.425465364898763d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.6522307253250917d);

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test108"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9237668243211833d);

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test109"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.math.BigInteger var2 = null;
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 0L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 0L);
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var11 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10.0d, (java.lang.Number)1.0f, true);
    org.apache.commons.math3.exception.util.Localizable var12 = null;
    org.apache.commons.math3.exception.util.Localizable var13 = null;
    java.lang.Object[] var15 = new java.lang.Object[] { (short)1};
    org.apache.commons.math3.exception.MathArithmeticException var16 = new org.apache.commons.math3.exception.MathArithmeticException(var13, var15);
    org.apache.commons.math3.exception.MathIllegalStateException var17 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var11, var12, var15);
    java.lang.Throwable[] var18 = var11.getSuppressed();
    org.apache.commons.math3.exception.MathArithmeticException var19 = new org.apache.commons.math3.exception.MathArithmeticException(var7, (java.lang.Object[])var18);
    org.apache.commons.math3.exception.MaxCountExceededException var20 = new org.apache.commons.math3.exception.MaxCountExceededException(var1, (java.lang.Number)var6, (java.lang.Object[])var18);
    org.apache.commons.math3.exception.MathInternalError var21 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test110"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)10.0d, (java.lang.Number)1L, (java.lang.Number)1);
    java.lang.Number var5 = var4.getHi();
    org.apache.commons.math3.exception.NumberIsTooLargeException var9 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10.0d, (java.lang.Number)1.0f, true);
    java.lang.Number var10 = var9.getMax();
    var4.addSuppressed((java.lang.Throwable)var9);
    boolean var12 = var9.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1+ "'", var5.equals(1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + 1.0f+ "'", var10.equals(1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);

  }

  public void test111() {}
//   public void test111() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test111"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextSecureInt(2, 10);
//     double var8 = var1.nextUniform(3.1780538303479458d, 4.810477380965351d, false);
//     double var11 = var1.nextF(2.4823187300238665d, 0.5573731387105724d);
//     java.lang.String var13 = var1.nextHexString(1);
//     double var16 = var1.nextGaussian(1.605207487501684d, 0.9999999353024235d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 4.113440195218864d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.25611897857945226d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "d"+ "'", var13.equals("d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 2.4202055129036895d);
// 
//   }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test112"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(27);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test113"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-67.37989615938413d), (java.lang.Number)(-1.3173720911599616d), true);
    boolean var5 = var4.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test114() {}
//   public void test114() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test114"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh((-0.4402198698105254d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test115"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh(0.5964546144007504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6876258111900299d);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test116"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(1399408482, 29);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test117"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(13.221239069499132d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test118() {}
//   public void test118() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test118"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextWeibull(1.6815545646570225d, 0.037062153555774406d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var6 = var1.nextPoisson((-0.03791546974136306d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.056509721952365685d);
// 
//   }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test119"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(5.9604645E-8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.1054274E-15f);

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test120"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.8923313678787291d, (-75.12530904978745d), 0.7445215087468096d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test121"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1((-3.425465364898763d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.9674658627797863d));

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test122"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10.0d, (java.lang.Number)1.0f, true);
    java.lang.Number var4 = var3.getMax();
    java.lang.Number var5 = var3.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 1.0f+ "'", var4.equals(1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 10.0d+ "'", var5.equals(10.0d));

  }

  public void test123() {}
//   public void test123() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test123"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy var1 = null;
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var2 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var1);
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(6);
//     double[] var5 = var4.getInternalValues();
//     double[] var8 = new double[] { 0.0d, 100.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
//     double[] var10 = var9.getElements();
//     double[] var11 = var9.getInternalValues();
//     double var12 = var2.mannWhitneyU(var5, var11);
// 
//   }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test124"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    java.lang.String var4 = var2.toString();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var5 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var2);
    int var6 = var2.ordinal();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "AVERAGE"+ "'", var4.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 3);

  }

  public void test125() {}
//   public void test125() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test125"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos((-1.1592768221762735d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test126"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)100.00000000000001d, (java.lang.Number)(-8.541939077859835d), true);

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test127"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var4 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MaxCountExceededException var5 = new org.apache.commons.math3.exception.MaxCountExceededException(var2, (java.lang.Number)0.007895180433873628d, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.MathIllegalArgumentException var6 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test128() {}
//   public void test128() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test128"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(3.1780538303479458d);
//     double var5 = var1.nextExponential(19.39006869589386d);
//     double var7 = var1.nextChiSquare(2.1928027555236245d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var1.nextExponential((-2.3123547476369948E-4d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.1536057319707143d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 21.41859948394476d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.9728432468688706d);
// 
//   }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test129"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10L, (java.lang.Number)3921225.0d, true);
    double[] var6 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    double var9 = var7.getElement(0);
    int var10 = var7.getNumElements();
    org.apache.commons.math3.exception.MaxCountExceededException var12 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)1.8328655053227587d);
    org.apache.commons.math3.exception.util.ExceptionContext var13 = var12.getContext();
    boolean var14 = var7.equals((java.lang.Object)var12);
    var3.addSuppressed((java.lang.Throwable)var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test130"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(1567, 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1552);

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test131"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var3.discardFrontElements(2);
    int var6 = var3.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test132"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(11.332278829291482d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 11.0d);

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test133"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var5 = var3.getElement(0);
    int var6 = var3.getNumElements();
    int var7 = var3.getExpansionMode();
    int var8 = var3.getExpansionMode();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test134"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp((-75.12530904978745d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4210854715202004E-14d);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test135"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(1.4702361029356772d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1370922363587137d);

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test136"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(161);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 161);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test137"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(1.6815545646570225d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5197187016610063d);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test138"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan((-0.9812684076861612d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.775944101461304d));

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test139"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(176.73201156338953d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 10125.998367439483d);

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test140"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(18, 2.5f);
    var2.contract();
    double[] var4 = var2.getElements();
    int var5 = var2.getExpansionMode();
    var2.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test141"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.549132653311572d), 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test142"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum((-2.3123547476369948E-4d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test143() {}
//   public void test143() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test143"); }
// 
// 
//     double var1 = org.apache.commons.math3.special.Gamma.logGamma((-0.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test144() {}
//   public void test144() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test144"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
//     java.lang.String var4 = var2.toString();
//     java.lang.Class var5 = var2.getDeclaringClass();
//     java.lang.String var6 = var2.toString();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var7 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var2);
//     double[] var10 = new double[] { 0.0d, 100.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var10);
//     int var12 = var11.getNumElements();
//     org.apache.commons.math3.util.ResizableDoubleArray var13 = var11.copy();
//     var11.setExpansionFactor(1.0000001f);
//     double var17 = var11.substituteMostRecentElement((-3.889934788209016d));
//     org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray(6);
//     double[] var20 = var19.getInternalValues();
//     var11.addElements(var20);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var22 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     double[] var25 = new double[] { 0.0d, 100.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var26 = new org.apache.commons.math3.util.ResizableDoubleArray(var25);
//     double[] var27 = var26.getElements();
//     double[] var28 = var26.getInternalValues();
//     double[] var31 = new double[] { 0.0d, 100.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var32 = new org.apache.commons.math3.util.ResizableDoubleArray(var31);
//     double var34 = var32.getElement(0);
//     double[] var35 = var32.getInternalValues();
//     double var36 = var22.mannWhitneyUTest(var28, var35);
//     double var37 = var7.mannWhitneyUTest(var20, var28);
// 
//   }

  public void test145() {}
//   public void test145() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test145"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy[] var3 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
//     org.apache.commons.math3.exception.MaxCountExceededException var4 = new org.apache.commons.math3.exception.MaxCountExceededException(var1, (java.lang.Number)0.007895180433873628d, (java.lang.Object[])var3);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var5 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var3);
//     java.lang.String var6 = var5.toString();
// 
//   }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test146"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var3.setElement(3, (-0.7853981633974483d));
    int var7 = var3.getNumElements();
    double var9 = var3.substituteMostRecentElement((-0.7853981633974483d));
    float var10 = var3.getExpansionFactor();
    var3.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var12 = var3.copy();
    int var13 = var3.getExpansionMode();
    var3.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-0.7853981633974483d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test147"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(1.4E-45f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4E-45f);

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test148"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-7227766516491148288L), 27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test149"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)10.0d, (java.lang.Number)1L, (java.lang.Number)1);
    java.lang.Number var5 = var4.getHi();
    org.apache.commons.math3.exception.NumberIsTooLargeException var9 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10.0d, (java.lang.Number)1.0f, true);
    java.lang.Number var10 = var9.getMax();
    var4.addSuppressed((java.lang.Throwable)var9);
    java.lang.String var12 = var9.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1+ "'", var5.equals(1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + 1.0f+ "'", var10.equals(1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (1)"+ "'", var12.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (1)"));

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test150"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)4.787491742782046d, (java.lang.Number)0.9018588507146864d, false);

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test151"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var3.setElement(3, (-0.7853981633974483d));
    var3.contract();
    var3.contract();
    double[] var11 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var11);
    double var14 = var12.getElement(0);
    var12.addElement(0.5403023058681398d);
    var12.discardFrontElements(0);
    double[] var19 = var12.getInternalValues();
    var3.addElements(var19);
    var3.addElement(0.060647843842351036d);
    org.apache.commons.math3.util.ResizableDoubleArray var23 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.util.ResizableDoubleArray var25 = new org.apache.commons.math3.util.ResizableDoubleArray(6);
    double[] var26 = var25.getInternalValues();
    var3.addElements(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test152() {}
//   public void test152() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test152"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(2.057741374677837d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test153"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(70L, (-3L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 210L);

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test154"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(2.5000002f, 68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7.378698E20f);

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test155"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)2885.026171454364d);

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test156"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(0.336819898262453d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-3.097166451050792d));

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test157"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(1.9124153064037224d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.4585712247270832d);

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test158"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test159"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.8094479062051723d, 1.3440585709080678E43d, 3.088731025128343d);

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test160"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(1.1920929E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4210855E-14f);

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test161"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(10.000002f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test162"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(477803L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 477803L);

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test163"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(4.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.0f);

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test164"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(2885.026171454364d, 0.9152952197546206d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.19551938025798843d));

  }

  public void test165() {}
//   public void test165() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test165"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
//     double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
//     double var7 = var3.getNumericalMean();
//     double var8 = var3.getMean();
//     boolean var9 = var3.isSupportUpperBoundInclusive();
//     double var11 = var3.probability(1.7792833636531957d);
//     double var12 = var3.sample();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.3235780930645504d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.3235780930645504d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1.3212951140994438d);
// 
//   }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test166"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(201L, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-2149118271877359L));

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test167"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(343642L, 101L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test168"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(2.2250111484445025E-271d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-623.2007982752439d));

  }

  public void test169() {}
//   public void test169() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test169"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy var1 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy var2 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var5 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var4);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var4);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var7 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var4);
//     double[] var10 = new double[] { 0.0d, 100.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var10);
//     double[] var12 = var11.getElements();
//     double[] var15 = new double[] { 0.0d, 100.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray(var15);
//     double var18 = var16.getElement(0);
//     var16.addElement(0.5403023058681398d);
//     var16.discardFrontElements(0);
//     double[] var23 = var16.getInternalValues();
//     org.apache.commons.math3.util.ResizableDoubleArray var24 = new org.apache.commons.math3.util.ResizableDoubleArray(var23);
//     double var25 = var7.mannWhitneyUTest(var12, var23);
// 
//   }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test170"); }


    org.apache.commons.math3.exception.MathArithmeticException var0 = new org.apache.commons.math3.exception.MathArithmeticException();
    org.apache.commons.math3.exception.util.ExceptionContext var1 = var0.getContext();
    org.apache.commons.math3.exception.MathInternalError var2 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test171"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var5 = var3.getElement(0);
    double[] var6 = var3.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(10);
    double var10 = var8.addElementRolling((-20.34054861465728d));
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var3, var8);
    var3.discardFrontElements(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test172"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(1.1370922363587137d, (-0.3738789406485615d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.015455414413029278d);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test173"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(42713622201L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test174() {}
//   public void test174() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test174"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     double var7 = var1.nextCauchy(0.15560730683937996d, 3.1780538303479458d);
//     long var9 = var1.nextPoisson(1.5707963267948966d);
//     var1.reSeed(101L);
//     var1.reSeed(70L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var1.nextBinomial((-2), 5.081775104347323d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 9.434881784095017d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1L);
// 
//   }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test175"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(70L, 101L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test176"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(2.127929429721528d, 38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5.849207877663932E11d);

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test177"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(1.348220504432292d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8120350946443996d);

  }

  public void test178() {}
//   public void test178() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test178"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     java.lang.Object[] var4 = new java.lang.Object[] { (byte)1};
//     org.apache.commons.math3.exception.MathIllegalStateException var5 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, var4);
//     org.apache.commons.math3.exception.MathIllegalStateException var6 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, var4);
//     org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError(var0, var4);
//     org.apache.commons.math3.exception.util.ExceptionContext var8 = var7.getContext();
//     org.apache.commons.math3.exception.MathInternalError var9 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var7);
// 
//   }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test179"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(0.6225116311094179d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6635039183211455d);

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test180"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(10.000002f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3);

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test181"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    double[] var4 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    var5.setElement(3, (-0.7853981633974483d));
    int var9 = var5.getNumElements();
    java.lang.Object[] var10 = new java.lang.Object[] { var9};
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, var10);
    org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test182"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(4.0f, 2.5000002f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.5000002f);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test183"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(0, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test184"); }


    double var1 = org.apache.commons.math3.special.Gamma.logGamma(1.777309158100993d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.07735981584439577d));

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test185"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(1.9299645497621911d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.35149565402094446d));

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test186"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    java.lang.String var3 = var1.toString();
    java.lang.Class var4 = var1.getDeclaringClass();
    java.lang.String var5 = var1.toString();
    boolean var7 = var1.equals((java.lang.Object)0.05690637728745587d);
    java.lang.String var8 = var1.toString();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "AVERAGE"+ "'", var3.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "AVERAGE"+ "'", var5.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test187"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(10);
    double var3 = var1.addElementRolling((-20.34054861465728d));
    int var4 = var1.start();
    var1.setContractionCriteria(4.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test188"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var3.setElement(3, (-0.7853981633974483d));
    int var7 = var3.getNumElements();
    double var9 = var3.substituteMostRecentElement((-0.7853981633974483d));
    float var10 = var3.getExpansionFactor();
    var3.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var12 = var3.copy();
    int var13 = var3.getExpansionMode();
    int var14 = var3.getExpansionMode();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-0.7853981633974483d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);

  }

  public void test189() {}
//   public void test189() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test189"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     double var7 = var1.nextCauchy(0.15560730683937996d, 3.1780538303479458d);
//     double var11 = var1.nextUniform((-0.6740495597759653d), (-0.016482976994642014d), true);
//     int var14 = var1.nextPascal(5, 0.9864231484692195d);
//     var1.reSeedSecure();
//     int var18 = var1.nextInt(0, 7);
//     long var20 = var1.nextPoisson(71.34241022211371d);
//     double var22 = var1.nextChiSquare(0.08772462544619851d);
//     long var25 = var1.nextSecureLong((-1L), 970448963025102651L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-1.0631404596034917d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.6206008190792572d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 80L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1.118333119580686E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 528685031872420288L);
// 
//   }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test190"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var5 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var1, (java.lang.Number)13.14778027539684d, (java.lang.Number)(byte)100, false);
    java.lang.Throwable[] var6 = var5.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var7 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test191"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(1.4994259604654114d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9050444669747542d);

  }

  public void test192() {}
//   public void test192() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test192"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(3.1780538303479458d);
//     double var5 = var1.nextExponential(19.39006869589386d);
//     var1.reSeedSecure();
//     double var8 = var1.nextExponential(1.3261490724357603d);
//     int[] var11 = var1.nextPermutation(3, 3);
//     int var14 = var1.nextBinomial(29, 0.956037264045509d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var16 = var1.nextPoisson((-2.20725760697381d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.051837988140208d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 19.18371935816028d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.8845965336744268d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 28);
// 
//   }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test193"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(4.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.0000005f);

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test194"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)3.5247804145401362d);

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test195"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test196"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor((-67.37989615938413d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-68.0d));

  }

  public void test197() {}
//   public void test197() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test197"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(3.1780538303479458d);
//     double var6 = var1.nextWeibull(968.8343073325332d, 0.9149287324253481d);
//     double var9 = var1.nextGaussian(0.0d, Double.POSITIVE_INFINITY);
//     int var12 = var1.nextInt(17, 68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 6.574503424432763d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.9157064479072711d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 46);
// 
//   }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test198"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(1491846145, 1.4E-45f, 0.0f, 58347);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test199() {}
//   public void test199() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test199"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
//     java.lang.String var4 = var2.toString();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var5 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var2);
//     double[] var8 = new double[] { 0.0d, 100.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
//     var9.setElement(3, (-0.7853981633974483d));
//     int var13 = var9.getNumElements();
//     double var15 = var9.substituteMostRecentElement((-0.7853981633974483d));
//     float var16 = var9.getExpansionFactor();
//     var9.contract();
//     org.apache.commons.math3.distribution.NormalDistribution var21 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
//     double var24 = var21.cumulativeProbability(0.0d, 0.1690925369322372d);
//     double var25 = var21.getNumericalMean();
//     double[] var27 = var21.sample(1);
//     double var29 = var21.density(979.3393873505228d);
//     double var31 = var21.density(3921225.0d);
//     boolean var32 = var21.isSupportLowerBoundInclusive();
//     double var33 = var21.getMean();
//     double[] var35 = var21.sample(10000);
//     var9.addElements(var35);
//     double[] var39 = new double[] { 0.0d, 100.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var40 = new org.apache.commons.math3.util.ResizableDoubleArray(var39);
//     double var42 = var40.getElement(0);
//     var40.addElement(0.5403023058681398d);
//     var40.discardFrontElements(0);
//     double[] var47 = var40.getInternalValues();
//     double var48 = var5.mannWhitneyUTest(var35, var47);
// 
//   }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test200"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(1.7453292519943295d, 0.9034897375799414d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.06165022316555335d));

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test201"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)(-0.016483723377414404d), (java.lang.Number)10000);
    java.lang.Number var4 = var3.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 10000+ "'", var4.equals(10000));

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test202"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.OutOfRangeException var8 = new org.apache.commons.math3.exception.OutOfRangeException(var4, (java.lang.Number)10.0d, (java.lang.Number)1L, (java.lang.Number)1);
    java.lang.Number var9 = var8.getHi();
    org.apache.commons.math3.exception.NumberIsTooLargeException var13 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10.0d, (java.lang.Number)1.0f, true);
    java.lang.Number var14 = var13.getMax();
    var8.addSuppressed((java.lang.Throwable)var13);
    java.lang.Throwable[] var16 = var8.getSuppressed();
    org.apache.commons.math3.exception.MaxCountExceededException var17 = new org.apache.commons.math3.exception.MaxCountExceededException(var2, (java.lang.Number)1.762747174039086d, (java.lang.Object[])var16);
    org.apache.commons.math3.exception.MathIllegalStateException var18 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, (java.lang.Object[])var16);
    org.apache.commons.math3.exception.MathArithmeticException var19 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + 1+ "'", var9.equals(1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + 1.0f+ "'", var14.equals(1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test203"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(2.9715526190865114d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test204"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(0.6225116311094179d, 0.7445215087468096d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.6224006642648386d);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test205"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)(-0.7333114255659123d), (java.lang.Number)34.24420874191639d, (java.lang.Number)10.000002f);

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test206"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(0.05690637728745587d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.056845029433060794d);

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test207"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan((-1.1562769898876681d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.8577470431528856d));

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test208"); }


    double var1 = org.apache.commons.math3.special.Gamma.logGamma(5.649970281277403d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.201649831742769d);

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test209"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(4.0000005f, 4.7683716E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.0000005f);

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test210"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (1)");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test211() {}
//   public void test211() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test211"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     double var7 = var1.nextCauchy(0.15560730683937996d, 3.1780538303479458d);
//     double var11 = var1.nextUniform((-0.6740495597759653d), (-0.016482976994642014d), true);
//     int var14 = var1.nextPascal(5, 0.9864231484692195d);
//     var1.reSeedSecure();
//     double var18 = var1.nextGamma(5.410266968958382d, (-20.34054861465728d));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var21 = var1.nextLong(81L, (-3017481761840155127L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 174.78879154241085d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.6516906951610512d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-82.86579852829529d));
// 
//   }

  public void test212() {}
//   public void test212() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test212"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(3.1780538303479458d);
//     double var5 = var1.nextExponential(19.39006869589386d);
//     double var8 = var1.nextCauchy((-9.602370808556296d), 0.08772462544619851d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var10 = var1.nextSecureHexString((-9800));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 5.6558448124115035d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 7.811750898024476d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-9.533549830900771d));
// 
//   }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test213"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(0, 58343);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test214"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var3 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var2);
    java.lang.String var4 = var2.name();
    java.lang.Class var5 = var2.getDeclaringClass();
    java.lang.Enum var7 = java.lang.Enum.<java.lang.Enum>valueOf(var5, "AVERAGE");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var9 = java.lang.Enum.<java.lang.Enum>valueOf(var5, "d");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "AVERAGE"+ "'", var4.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test215"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var5 = var3.getElement(0);
    int var6 = var3.getNumElements();
    int var7 = var3.getExpansionMode();
    double var9 = var3.substituteMostRecentElement(1.5707963267948966d);
    java.lang.Object var10 = null;
    boolean var11 = var3.equals(var10);
    double[] var14 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    var15.setElement(3, (-0.7853981633974483d));
    float var19 = var15.getContractionCriteria();
    boolean var20 = var3.equals((java.lang.Object)var15);
    int var21 = var3.getNumElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 2);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test216"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt((-1.8769778981583525d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.2335394773537278d));

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test217"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-127));

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test218"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(528685031872420288L, 482773L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 482773L);

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test219"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)10.0d, (java.lang.Number)1L, (java.lang.Number)1);
    java.lang.Number var5 = var4.getHi();
    java.lang.Number var6 = var4.getLo();
    java.lang.Number var7 = var4.getLo();
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var12 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var8, (java.lang.Number)13.14778027539684d, (java.lang.Number)(byte)100, false);
    java.lang.Throwable[] var13 = var12.getSuppressed();
    var4.addSuppressed((java.lang.Throwable)var12);
    java.lang.Number var15 = var4.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1+ "'", var5.equals(1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 1L+ "'", var6.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 1L+ "'", var7.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + 1L+ "'", var15.equals(1L));

  }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test220"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(1.0000001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test221"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(0.9157064479072711d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7929931743433503d);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test222"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    int var4 = var3.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = var3.copy();
    var3.setExpansionFactor(1.0000001f);
    double var9 = var3.substituteMostRecentElement((-3.889934788209016d));
    org.apache.commons.math3.util.ResizableDoubleArray var10 = var3.copy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test223"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog(1861);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 12154.909104551542d);

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test224"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    int var4 = var1.nextZipf(100, 10.0d);
    var1.reSeedSecure(10L);
    var1.reSeedSecure(100L);
    var1.reSeed((-2149118271877359L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test225"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(3.477057945146137d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test226"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var3 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var4.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var6 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var3, var5);
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var5);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var8 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var5);
    org.apache.commons.math3.exception.NumberIsTooLargeException var12 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-0.11387786884182144d), (java.lang.Number)979.3393873505228d, true);
    org.apache.commons.math3.exception.MathInternalError var13 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var12);
    boolean var14 = var5.equals((java.lang.Object)var12);
    java.lang.String var15 = var5.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var16 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "AVERAGE"+ "'", var15.equals("AVERAGE"));

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test227"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(9.281695778419678d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.2280442648476493d);

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test228"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test229"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getNumericalMean();
    double[] var9 = var3.sample(1);
    double var11 = var3.density(979.3393873505228d);
    double var13 = var3.density(3921225.0d);
    boolean var14 = var3.isSupportLowerBoundInclusive();
    double var15 = var3.getNumericalMean();
    double var17 = var3.cumulativeProbability(0.5196265085690617d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var20 = var3.cumulativeProbability(9.73463740356342d, 0.5403023058681399d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);

  }

  public void test230() {}
//   public void test230() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test230"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
//     java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
//     java.math.BigInteger var5 = null;
//     java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 0L);
//     java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 0L);
//     java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 8);
//     java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, var9);
//     java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, 17);
//     java.math.BigInteger var15 = null;
//     java.math.BigInteger var16 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, var15);
// 
//   }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test231"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10.0d, (java.lang.Number)1.0f, true);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    java.lang.Object[] var6 = null;
    org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var5, var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test232() {}
//   public void test232() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test232"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(3.1780538303479458d);
//     double var5 = var1.nextExponential(19.39006869589386d);
//     double var8 = var1.nextBeta(4.499378297809863d, 1.8328655053227587d);
//     int[] var11 = var1.nextPermutation(10000, 10000);
//     double var13 = var1.nextChiSquare(10.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var16 = var1.nextBeta(10125.998367439483d, (-0.2590796335125806d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 4.62658529638666d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 31.784009125111766d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.8764719625865001d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 24.400446642372156d);
// 
//   }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test233"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)1.702737351127573d);
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var2.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test234"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(7, 6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 42);

  }

  public void test235() {}
//   public void test235() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test235"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy var1 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var3 = var2.getTiesStrategy();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var3);
//     java.lang.String var5 = var3.name();
//     java.lang.Class var6 = var3.getDeclaringClass();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var7 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var3);
//     org.apache.commons.math3.distribution.NormalDistribution var11 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
//     double var14 = var11.cumulativeProbability(0.0d, 0.1690925369322372d);
//     double var15 = var11.getNumericalMean();
//     double[] var17 = var11.sample(1);
//     double var19 = var11.density(979.3393873505228d);
//     double[] var21 = var11.sample(2);
//     double[] var24 = new double[] { 0.0d, 100.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var25 = new org.apache.commons.math3.util.ResizableDoubleArray(var24);
//     var25.setElement(3, (-0.7853981633974483d));
//     int var29 = var25.getNumElements();
//     double[] var30 = var25.getInternalValues();
//     double var32 = var25.substituteMostRecentElement(100.0d);
//     double var34 = var25.addElementRolling(3.4372222997317032d);
//     double[] var35 = var25.getInternalValues();
//     double var36 = var7.mannWhitneyU(var21, var35);
// 
//   }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test236"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var5 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var4);
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var4);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var7 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var4);
    org.apache.commons.math3.exception.NumberIsTooLargeException var11 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-0.11387786884182144d), (java.lang.Number)979.3393873505228d, true);
    org.apache.commons.math3.exception.MathInternalError var12 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var11);
    boolean var13 = var4.equals((java.lang.Object)var11);
    java.lang.String var14 = var4.name();
    java.lang.String var15 = var4.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "AVERAGE"+ "'", var14.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "AVERAGE"+ "'", var15.equals("AVERAGE"));

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test237"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(0, 1.1920929E-7f, 1.0000001f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test238"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(short)10);
    boolean var3 = var2.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test239"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var5 = var3.getElement(0);
    var3.setElement(4, (-0.8309074630677628d));
    double var10 = var3.substituteMostRecentElement(6.938893903907228E-18d);
    var3.setElement(5, 122.7902212423532d);
    org.apache.commons.math3.util.ResizableDoubleArray var14 = var3.copy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-0.8309074630677628d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test240"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-0.11387786884182144d), (java.lang.Number)979.3393873505228d, true);
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var3.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test241() {}
//   public void test241() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test241"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextSecureInt(2, 10);
//     double var7 = var1.nextCauchy(0.037062153555774406d, 3.5247804145401362d);
//     double var9 = var1.nextChiSquare(8.00736706798333d);
//     int var12 = var1.nextPascal(9, 0.686579669341957d);
//     double var14 = var1.nextExponential(2.140641475065075d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var17 = var1.nextLong(0L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 6.874722136841381d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 6.687090111296492d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 8.004601483832483d);
// 
//   }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test242"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp((-38.38421194679636d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-38.384211946796356d));

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test243"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test244"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo((-129140163L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test245"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var5 = null;
    java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 0L);
    java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 0L);
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 8);
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, var9);
    java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 1399408455);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test246"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(6627890308811632801L, 3L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6627890308811632798L);

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test247"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(11.093291396075893d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 32864.36489164638d);

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test248"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("17f8789cc43bb2106dfbda8a540d6d9b774b8ed025f9ccf3a610e661aacb917f64a8802d7a68fd069f87939570a60c437206");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test249"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(21, (-1));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test250"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0);

  }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test251"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(0.8074933757497784d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.266703980515175d);

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test252"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.9018588507146864d, 1.1384588012921568E10d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var4 = var2.sample((-127));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test253() {}
//   public void test253() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test253"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy var1 = null;
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var2 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var1);
//     double[] var5 = new double[] { 0.0d, 100.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray(var5);
//     double var8 = var6.getElement(0);
//     var6.addElement(0.5403023058681398d);
//     var6.discardFrontElements(0);
//     double[] var13 = var6.getInternalValues();
//     double[] var16 = new double[] { 0.0d, 100.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var17 = new org.apache.commons.math3.util.ResizableDoubleArray(var16);
//     double var19 = var17.getElement(0);
//     var17.addElement(0.5403023058681398d);
//     var17.discardFrontElements(0);
//     double[] var24 = var17.getInternalValues();
//     org.apache.commons.math3.util.ResizableDoubleArray var25 = new org.apache.commons.math3.util.ResizableDoubleArray(var24);
//     double var26 = var2.mannWhitneyU(var13, var24);
// 
//   }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test254"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(15.937414129423429d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.2781603508123045d);

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test255"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var5 = null;
    java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 0L);
    java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 0L);
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 8);
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, var9);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, (-20));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test256"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(8.0d, 0.7333114255659123d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.7333114255659123d);

  }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test257"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double[] var6 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    var7.setElement(3, (-0.7853981633974483d));
    var7.discardMostRecentElements(0);
    double var14 = var7.substituteMostRecentElement((-0.6981152095798223d));
    int var15 = var7.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var3, var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == (-0.7853981633974483d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 4);

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test258"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var5 = var3.getElement(0);
    int var6 = var3.getNumElements();
    int var7 = var3.getExpansionMode();
    double var9 = var3.substituteMostRecentElement(1.5707963267948966d);
    int var10 = var3.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test259"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var5 = var3.getElement(0);
    int var6 = var3.getNumElements();
    int var7 = var3.getExpansionMode();
    double var9 = var3.substituteMostRecentElement(1.5707963267948966d);
    java.lang.Object var10 = null;
    boolean var11 = var3.equals(var10);
    var3.setExpansionFactor(2.0f);
    int var14 = var3.getExpansionMode();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);

  }

  public void test260() {}
//   public void test260() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test260"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     var1.reSeedSecure(10L);
//     double var9 = var1.nextF(1.0d, 47.71468531505997d);
//     var1.reSeed(1L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var1.nextHypergeometric(100, 537824, 29);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2.0878287649974294d);
// 
//   }

  public void test261() {}
//   public void test261() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test261"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     double var7 = var1.nextCauchy(0.15560730683937996d, 3.1780538303479458d);
//     double var11 = var1.nextUniform((-0.6740495597759653d), (-0.016482976994642014d), true);
//     int var14 = var1.nextPascal(5, 0.9864231484692195d);
//     var1.reSeedSecure();
//     int var18 = var1.nextInt(0, 7);
//     long var20 = var1.nextPoisson(71.34241022211371d);
//     double var22 = var1.nextChiSquare(0.08772462544619851d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var25 = var1.nextBeta(1.5119872053626813d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 6.820974251277736d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.5681599526409591d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 75L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0.05888319765571852d);
// 
//   }

  public void test262() {}
//   public void test262() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test262"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextSecureInt(2, 10);
//     double var8 = var1.nextUniform(3.1780538303479458d, 4.810477380965351d, false);
//     double var11 = var1.nextF(2.4823187300238665d, 0.5573731387105724d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var1.nextZipf((-21), 0.049034116126541086d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 3.5754239104901835d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.23736421790467077d);
// 
//   }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test263"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var5 = var3.substituteMostRecentElement(1.3235780930645504d);
    float var6 = var3.getExpansionFactor();
    double[] var9 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(var9);
    var10.setElement(3, (-0.7853981633974483d));
    float var14 = var10.getContractionCriteria();
    int var15 = var10.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var3, var10);
    double[] var17 = var10.getElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test264"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)152444951, var2, (java.lang.Number)628.4765524686446d);

  }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test265"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor((-38.384211946796356d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-39.0d));

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test266"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(0.023190724476818098d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 31.956999090548937d);

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test267"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(3.9901174614615124E8d, 42.19646737175651d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.188963934403276d);

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test268"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.11209838020920855d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-4));

  }

  public void test269() {}
//   public void test269() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test269"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(3.1780538303479458d);
//     double var5 = var1.nextExponential(19.39006869589386d);
//     var1.reSeedSecure(9223372036854775807L);
//     var1.reSeedSecure(2L);
//     var1.reSeed();
//     int var13 = var1.nextBinomial(100, 0.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var15 = var1.nextPoisson(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.2183020837579326d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 7.779087918232684d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0);
// 
//   }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test270"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(0.451843130811387d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5712054555196198d);

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test271"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(248.820958136101d, (-3.097166451050792d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test272"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(38L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test273"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(4.810477380965351d, 0.7607318203617716d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.8104773809653505d);

  }

  public void test274() {}
//   public void test274() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test274"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(3.1780538303479458d);
//     double var5 = var1.nextExponential(19.39006869589386d);
//     var1.reSeedSecure();
//     double var8 = var1.nextExponential(1.3261490724357603d);
//     var1.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.993121186329873d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.0422659000901444d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.8644132612450952d);
// 
//   }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test275"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(3, 68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test276() {}
//   public void test276() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test276"); }
// 
// 
//     double var1 = org.apache.commons.math3.special.Gamma.logGamma((-0.20247170671153375d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test277() {}
//   public void test277() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test277"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.sqrt((-0.21452323545111215d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test278"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(1.3440585709080678E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.3440585709080678E43d);

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test279"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)10.0d, (java.lang.Number)1L, (java.lang.Number)1);
    java.lang.Number var5 = var4.getHi();
    java.lang.Number var6 = var4.getLo();
    java.lang.Number var7 = var4.getLo();
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var12 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var8, (java.lang.Number)13.14778027539684d, (java.lang.Number)(byte)100, false);
    java.lang.Throwable[] var13 = var12.getSuppressed();
    var4.addSuppressed((java.lang.Throwable)var12);
    org.apache.commons.math3.exception.util.Localizable var15 = null;
    java.lang.Object[] var17 = new java.lang.Object[] { (byte)1};
    org.apache.commons.math3.exception.MathIllegalStateException var18 = new org.apache.commons.math3.exception.MathIllegalStateException(var15, var17);
    var4.addSuppressed((java.lang.Throwable)var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1+ "'", var5.equals(1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 1L+ "'", var6.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 1L+ "'", var7.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test280"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(2.354644375697275d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.3303781644034924d);

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test281"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    java.lang.String var3 = var1.toString();
    java.lang.String var4 = var1.name();
    org.apache.commons.math3.distribution.NormalDistribution var8 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var11 = var8.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var12 = var8.getNumericalMean();
    double[] var14 = var8.sample(15);
    boolean var15 = var8.isSupportLowerBoundInclusive();
    boolean var16 = var1.equals((java.lang.Object)var8);
    java.lang.Class var17 = var1.getDeclaringClass();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "AVERAGE"+ "'", var3.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "AVERAGE"+ "'", var4.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test282"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(1.9299645497621911d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2450394442995047d);

  }

  public void test283() {}
//   public void test283() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test283"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
//     java.lang.String var4 = var2.toString();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var5 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var2);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
//     double var12 = var9.cumulativeProbability(0.0d, 0.1690925369322372d);
//     double var13 = var9.getNumericalMean();
//     double[] var15 = var9.sample(1);
//     double var17 = var9.density(979.3393873505228d);
//     double var19 = var9.density(3921225.0d);
//     boolean var20 = var9.isSupportLowerBoundInclusive();
//     double var21 = var9.getMean();
//     double[] var23 = var9.sample(10000);
//     org.apache.commons.math3.distribution.NormalDistribution var27 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
//     double var30 = var27.cumulativeProbability(0.0d, 0.1690925369322372d);
//     double var32 = var27.cumulativeProbability(10.0d);
//     double var33 = var27.getNumericalVariance();
//     double var34 = var27.getNumericalMean();
//     double[] var36 = var27.sample(7);
//     double var37 = var5.mannWhitneyU(var23, var36);
// 
//   }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test284"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var3.setElement(3, (-0.7853981633974483d));
    float var7 = var3.getContractionCriteria();
    int var8 = var3.getNumElements();
    int var9 = var3.getNumElements();
    int var10 = var3.getExpansionMode();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);

  }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test285"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)10000, (java.lang.Number)1.3440585709080678E43d, true);
    boolean var4 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test286"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(6);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setElement((-23), 0.019586458935128177d);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test287"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(1.348220504432292d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test288"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(0.056967924236750636d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 30.604942315720642d);

  }

  public void test289() {}
//   public void test289() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test289"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(3.1780538303479458d);
//     double var5 = var1.nextExponential(19.39006869589386d);
//     double var8 = var1.nextBeta(4.499378297809863d, 1.8328655053227587d);
//     int var11 = var1.nextBinomial(14, 0.0d);
//     long var13 = var1.nextPoisson(0.08193630735653556d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 5.753824499105662d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 14.080133439244888d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.707769364960512d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1L);
// 
//   }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test290"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var5 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var4);
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var4);
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var4);
    org.apache.commons.math3.stat.ranking.TiesStrategy var8 = var7.getTiesStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test291"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(7.198232315471589E-18d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5407439555097887E-33d);

  }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test292"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.08076789388642387d, 1.2967094728211648d, 0.9098704402818677d);
    double var4 = var3.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.NEGATIVE_INFINITY);

  }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test293"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(71.34241022211371d, 14.080133439244888d, 0.5486868599002128d, (-71));
      fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException");
    } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
      // Expected exception.
    }

  }

  public void test294() {}
//   public void test294() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test294"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 537824);
// 
//   }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test295"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getNumericalMean();
    double[] var9 = var3.sample(1);
    double var10 = var3.getNumericalMean();
    double var12 = var3.cumulativeProbability(0.9686944920045141d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test296"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc((-1.8769778981583525d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.992056162359819d);

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test297"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(1.8328655053227587d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test298"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(9.536744E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test299() {}
//   public void test299() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test299"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(3.1780538303479458d);
//     double var5 = var1.nextExponential(19.39006869589386d);
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var8 = var1.nextT((-0.549132653311572d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.5906256900573825d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 75.28652835290309d);
// 
//   }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test300"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(2.5164150335575357d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.721754553936818d));

  }

  public void test301() {}
//   public void test301() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test301"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     var1.reSeedSecure(10L);
//     double var9 = var1.nextF(1.0d, 47.71468531505997d);
//     long var12 = var1.nextSecureLong(1L, 10L);
//     long var15 = var1.nextSecureLong(100L, 477733L);
//     var1.reSeed(9L);
//     double var20 = var1.nextGamma((-0.03791546974136306d), (-0.9017707629176819d));
//     var1.reSeed(7L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("3aed3e95b3999aeb52", "17f8789cc43bb2106dfbda8a540d6d9b774b8ed025f9ccf3a610e661aacb917f64a8802d7a68fd069f87939570a60c437206");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.408094785570248d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 6L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 44486L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == (-1.4412304841237153d));
// 
//   }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test302"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var5 = var3.getElement(0);
    double[] var6 = var3.getElements();
    float var7 = var3.getExpansionFactor();
    double[] var10 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var10);
    var11.setElement(3, (-0.7853981633974483d));
    var11.discardMostRecentElements(0);
    double[] var19 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray(var19);
    double var22 = var20.getElement(0);
    double[] var23 = var20.getInternalValues();
    var11.addElements(var23);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var3, var11);
    double[] var28 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var29 = new org.apache.commons.math3.util.ResizableDoubleArray(var28);
    double var31 = var29.getElement(0);
    int var32 = var29.start();
    int var33 = var29.getExpansionMode();
    float var34 = var29.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var3, var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 2.5f);

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test303"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(2.5164150335575357d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9228352829279439d);

  }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test304"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(4.348284541873568d, 43.1284181946612d);

  }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test305"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(2.5842611209158894d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 148.06725538822778d);

  }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test306"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(3.6661404377193025E21d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 49.653426409720026d);

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test307"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(1);
    var1.setElement(0, (-0.9880458431278127d));
    var1.setExpansionFactor(2.0f);
    double var8 = var1.addElementRolling(100.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setContractionCriteria(1.4E-45f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-0.9880458431278127d));

  }

  public void test308() {}
//   public void test308() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test308"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     var1.reSeedSecure(10L);
//     var1.reSeedSecure(100L);
//     long var11 = var1.nextSecureLong(0L, 1061208L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 930313L);
// 
//   }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test309"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(31.840944456096064d, 8.800174227572448d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.6847603917884783E13d);

  }

  public void test310() {}
//   public void test310() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test310"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var3 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var2);
//     double[] var6 = new double[] { 0.0d, 100.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
//     var7.discardMostRecentElements(0);
//     double[] var10 = var7.getElements();
//     double[] var13 = new double[] { 0.0d, 100.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var13);
//     var14.setElement(3, (-0.7853981633974483d));
//     var14.contract();
//     var14.contract();
//     double[] var22 = new double[] { 0.0d, 100.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var23 = new org.apache.commons.math3.util.ResizableDoubleArray(var22);
//     double var25 = var23.getElement(0);
//     var23.addElement(0.5403023058681398d);
//     var23.discardFrontElements(0);
//     double[] var30 = var23.getInternalValues();
//     var14.addElements(var30);
//     double var32 = var3.mannWhitneyU(var10, var30);
// 
//   }

  public void test311() {}
//   public void test311() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test311"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     double var7 = var1.nextCauchy(0.15560730683937996d, 3.1780538303479458d);
//     double var11 = var1.nextUniform((-0.6740495597759653d), (-0.016482976994642014d), true);
//     int var14 = var1.nextPascal(2, 0.5403023058681399d);
//     double var16 = var1.nextT(0.5403023058681398d);
//     double var18 = var1.nextExponential(1.35183754101305d);
//     double var21 = var1.nextGamma((-352.69596618548d), 1.6815545646570225d);
//     long var24 = var1.nextLong(482773L, 970448963025102651L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 14.104332570968813d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.6591534326989095d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 2.8260076973785733d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 2.9500450843825274d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 112460126646364816L);
// 
//   }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test312"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(9L, 102L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 111L);

  }

  public void test313() {}
//   public void test313() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test313"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(3.1780538303479458d);
//     double var5 = var1.nextExponential(19.39006869589386d);
//     double var8 = var1.nextBeta(4.499378297809863d, 1.8328655053227587d);
//     int var11 = var1.nextBinomial(14, 0.0d);
//     long var14 = var1.nextLong(2L, 1030301L);
//     var1.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2.4796438758057278d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 6.934952184291265d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.7683350190902782d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 349189L);
// 
//   }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test314"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getNumericalMean();
    double[] var9 = var3.sample(1);
    double var11 = var3.density(979.3393873505228d);
    var3.reseedRandomGenerator(0L);
    double var14 = var3.sample();
    double var16 = var3.cumulativeProbability(0.5403023058681398d);
    double var17 = var3.getNumericalVariance();
    double var19 = var3.probability(0.0d);
    boolean var20 = var3.isSupportLowerBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.322456124528837d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 6.658240041118693E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test315"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.9254962739500686d, 41.26320996706553d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9254962739500687d);

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test316"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(709139L, 349189L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 247623538271L);

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test317"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(6742, 1552);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10463584);

  }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test318"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getNumericalMean();
    double[] var9 = var3.sample(1);
    double var11 = var3.density(979.3393873505228d);
    var3.reseedRandomGenerator(0L);
    double var14 = var3.sample();
    double var16 = var3.cumulativeProbability(0.5403023058681398d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var19 = var3.cumulativeProbability(1.8640991091503671d, (-0.2836613859603795d));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.322456124528837d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);

  }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test319"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(100.00000000000001d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.010050166663333093d);

  }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test320"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("959e7d74b527fae3cd8d1947430516e29e8a75a9b271dff39200aa1a17fa0b646148ce36723ef17f1f94a72ba258d41dc969");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test321"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1.4503293580384904d, (java.lang.Number)0.05525892401327309d, false);

  }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test322"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    java.lang.String var6 = var4.toString();
    java.lang.String var7 = var4.name();
    java.lang.Class var8 = var4.getDeclaringClass();
    java.lang.Enum var10 = java.lang.Enum.<java.lang.Enum>valueOf(var8, "AVERAGE");
    boolean var11 = var1.equals((java.lang.Object)var10);
    int var12 = var10.ordinal();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "AVERAGE"+ "'", var6.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "AVERAGE"+ "'", var7.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 3);

  }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test323"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(1552, 6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.922274497555412E16d);

  }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test324"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException(var0);

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test325"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)0);
    boolean var3 = var2.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);

  }

  public void test326() {}
//   public void test326() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test326"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(3.1780538303479458d);
//     double var5 = var1.nextExponential(19.39006869589386d);
//     var1.reSeedSecure(9223372036854775807L);
//     var1.reSeedSecure(2L);
//     var1.reSeed();
//     double var13 = var1.nextCauchy(1.7627471740390859d, 0.17839279645410733d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var16 = var1.nextPermutation(6742, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.7955044710227686d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 6.599781227213443d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.9818472665335762d);
// 
//   }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test327"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-0.016482976994642014d), (java.lang.Number)0.9864231484692195d, false);
    boolean var5 = var4.getBoundIsAllowed();
    java.lang.Number var6 = var4.getMax();
    java.lang.Number var7 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 0.9864231484692195d+ "'", var6.equals(0.9864231484692195d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 0.9864231484692195d+ "'", var7.equals(0.9864231484692195d));

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test328"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin((-1.0427625336239976d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.8637993851898413d));

  }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test329"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5607966601082315d);

  }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test330"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(80L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test331"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var5 = null;
    java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 0L);
    java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 0L);
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 8);
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, var9);
    java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, 17);
    java.math.BigInteger var16 = org.apache.commons.math3.util.ArithmeticUtils.pow(var14, 343642L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test332"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var3.setElement(3, (-0.7853981633974483d));
    int var7 = var3.getNumElements();
    double var9 = var3.substituteMostRecentElement((-0.7853981633974483d));
    var3.contract();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-0.7853981633974483d));

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test333"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)1030301L);
    boolean var3 = var2.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);

  }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test334"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.3646904086155498d, 38.38428471223844d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test335"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(38L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test336"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var3 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MathArithmeticException var4 = new org.apache.commons.math3.exception.MathArithmeticException(var2, (java.lang.Object[])var3);
    org.apache.commons.math3.exception.MaxCountExceededException var5 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)40.67914158740765d, (java.lang.Object[])var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test337"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var7 = var6.getNumericalMean();
    boolean var8 = var2.equals((java.lang.Object)var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test338"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(0.056845029433060794d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05678387960233488d);

  }

  public void test339() {}
//   public void test339() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test339"); }
// 
// 
//     double var1 = org.apache.commons.math3.special.Gamma.logGamma((-1.0427625336239976d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test340"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(42.19646737175651d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.7657587181044723d);

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test341"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var3.setElement(3, (-0.7853981633974483d));
    int var7 = var3.getNumElements();
    double var9 = var3.substituteMostRecentElement((-0.7853981633974483d));
    float var10 = var3.getExpansionFactor();
    var3.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var12 = var3.copy();
    int var13 = var3.getExpansionMode();
    var3.addElement(41.26320996706553d);
    double[] var16 = var3.getElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-0.7853981633974483d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test342() {}
//   public void test342() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test342"); }
// 
// 
//     org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-0.11387786884182144d), (java.lang.Number)979.3393873505228d, true);
//     java.lang.Number var4 = var3.getMax();
//     org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
//     java.lang.Throwable var6 = null;
//     var3.addSuppressed(var6);
// 
//   }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test343"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(18, 1431655772);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2);

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test344"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10.0d, (java.lang.Number)1.0f, true);
    java.lang.Number var4 = var3.getArgument();
    java.lang.Number var5 = var3.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 10.0d+ "'", var4.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 10.0d+ "'", var5.equals(10.0d));

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test345"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var5 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var4);
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var4);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var7 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var4);
    org.apache.commons.math3.exception.NumberIsTooLargeException var11 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-0.11387786884182144d), (java.lang.Number)979.3393873505228d, true);
    org.apache.commons.math3.exception.MathInternalError var12 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var11);
    boolean var13 = var4.equals((java.lang.Object)var11);
    java.lang.String var14 = var4.name();
    java.lang.String var15 = var4.name();
    org.apache.commons.math3.exception.NumberIsTooLargeException var19 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-0.11387786884182144d), (java.lang.Number)979.3393873505228d, true);
    java.lang.Number var20 = var19.getMax();
    org.apache.commons.math3.exception.MathInternalError var21 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var19);
    boolean var22 = var4.equals((java.lang.Object)var19);
    boolean var23 = var19.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "AVERAGE"+ "'", var14.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "AVERAGE"+ "'", var15.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + 979.3393873505228d+ "'", var20.equals(979.3393873505228d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test346"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var5 = var3.getElement(0);
    double[] var6 = var3.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(10);
    double var10 = var8.addElementRolling((-20.34054861465728d));
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var3, var8);
    float var12 = var3.getExpansionFactor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.discardMostRecentElements((-21));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 2.0f);

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test347"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)42.19646737175651d);

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test348"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(5040L, (-7227766516491148288L));
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test349() {}
//   public void test349() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test349"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy var1 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var3 = var2.getTiesStrategy();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var3);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var5 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var3);
//     double[] var8 = new double[] { 0.0d, 100.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
//     org.apache.commons.math3.distribution.NormalDistribution var13 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
//     double var14 = var13.getNumericalVariance();
//     double[] var16 = var13.sample(6);
//     double var17 = var5.mannWhitneyUTest(var8, var16);
// 
//   }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test350"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(0.4148624190190518d, 29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.2272756525328448E8d);

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test351"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var5 = var3.getElement(0);
    var3.setElement(4, (-0.8309074630677628d));
    double var10 = var3.substituteMostRecentElement(6.938893903907228E-18d);
    var3.setElement(5, 122.7902212423532d);
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(1);
    var15.setElement(0, (-0.9880458431278127d));
    var15.setNumElements(9);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var3, var15);
    int var22 = var3.getExpansionMode();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var24 = var3.getElement(1399408473);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-0.8309074630677628d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test352"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(9.161381204155603d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.11532736908667869d);

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test353"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.math.BigInteger var1 = null;
    java.math.BigInteger var3 = org.apache.commons.math3.util.ArithmeticUtils.pow(var1, 0L);
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var1, 0L);
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var10 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10.0d, (java.lang.Number)1.0f, true);
    org.apache.commons.math3.exception.util.Localizable var11 = null;
    org.apache.commons.math3.exception.util.Localizable var12 = null;
    java.lang.Object[] var14 = new java.lang.Object[] { (short)1};
    org.apache.commons.math3.exception.MathArithmeticException var15 = new org.apache.commons.math3.exception.MathArithmeticException(var12, var14);
    org.apache.commons.math3.exception.MathIllegalStateException var16 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var10, var11, var14);
    java.lang.Throwable[] var17 = var10.getSuppressed();
    org.apache.commons.math3.exception.MathArithmeticException var18 = new org.apache.commons.math3.exception.MathArithmeticException(var6, (java.lang.Object[])var17);
    org.apache.commons.math3.exception.MaxCountExceededException var19 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)var5, (java.lang.Object[])var17);
    org.apache.commons.math3.exception.util.Localizable var20 = null;
    java.math.BigInteger var21 = null;
    java.math.BigInteger var23 = org.apache.commons.math3.util.ArithmeticUtils.pow(var21, 0L);
    java.math.BigInteger var25 = org.apache.commons.math3.util.ArithmeticUtils.pow(var21, 0L);
    org.apache.commons.math3.exception.util.Localizable var26 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var30 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10.0d, (java.lang.Number)1.0f, true);
    org.apache.commons.math3.exception.util.Localizable var31 = null;
    org.apache.commons.math3.exception.util.Localizable var32 = null;
    java.lang.Object[] var34 = new java.lang.Object[] { (short)1};
    org.apache.commons.math3.exception.MathArithmeticException var35 = new org.apache.commons.math3.exception.MathArithmeticException(var32, var34);
    org.apache.commons.math3.exception.MathIllegalStateException var36 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var30, var31, var34);
    java.lang.Throwable[] var37 = var30.getSuppressed();
    org.apache.commons.math3.exception.MathArithmeticException var38 = new org.apache.commons.math3.exception.MathArithmeticException(var26, (java.lang.Object[])var37);
    org.apache.commons.math3.exception.MaxCountExceededException var39 = new org.apache.commons.math3.exception.MaxCountExceededException(var20, (java.lang.Number)var25, (java.lang.Object[])var37);
    java.math.BigInteger var40 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, var25);
    java.math.BigInteger var42 = org.apache.commons.math3.util.ArithmeticUtils.pow(var25, 477803L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test354() {}
//   public void test354() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test354"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextSecureInt(2, 10);
//     var1.reSeed(3L);
//     java.lang.String var8 = var1.nextSecureHexString(18);
//     java.util.Collection var9 = null;
//     java.lang.Object[] var11 = var1.nextSample(var9, 68);
// 
//   }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test355"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(69.74306029434739d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test356"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh((-0.15073428133995367d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.1513057313132317d));

  }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test357"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var5 = var3.getElement(0);
    int var6 = var3.start();
    int var7 = var3.getNumElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2);

  }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test358"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(34.24420874191639d, 1.7792833636531957d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 34.29040217973706d);

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test359"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm((-23), 68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1564);

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test360"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(21, 1.0000001f, 9.536743E-7f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test361() {}
//   public void test361() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test361"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
//     double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
//     double var8 = var3.cumulativeProbability(10.0d);
//     double var9 = var3.getNumericalVariance();
//     boolean var10 = var3.isSupportLowerBoundInclusive();
//     double var11 = var3.getNumericalVariance();
//     double var12 = var3.sample();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 6.658240041118693E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 6.658240041118693E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1.282916023120766d);
// 
//   }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test362"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-9.559912057076549d), 2.47859452775542d);
    boolean var3 = var2.isSupportConnected();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);

  }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test363"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.3013419654212052d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test364"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(2.0f, 1.0000001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0f);

  }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test365"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(10.000001f, 1.4210854715202004E-14d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10.0f);

  }

  public void test366() {}
//   public void test366() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test366"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy var1 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var3 = var2.getTiesStrategy();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var3);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var5 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var3);
//     double[] var8 = new double[] { 0.0d, 100.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
//     double[] var10 = var9.getElements();
//     double[] var13 = new double[] { 0.0d, 100.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var13);
//     double var16 = var14.getElement(0);
//     double[] var17 = var14.getElements();
//     org.apache.commons.math3.util.ResizableDoubleArray var18 = var14.copy();
//     double var20 = var14.addElementRolling(122.7902212423532d);
//     double var22 = var14.substituteMostRecentElement(1.3261490724357603d);
//     double[] var23 = var14.getInternalValues();
//     double var24 = var5.mannWhitneyU(var10, var23);
// 
//   }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test367"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians((-9.602370808556296d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.16759298660669747d));

  }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test368"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(1.3303781644034924d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 76.22505397668168d);

  }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test369"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(4, (-71));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test370() {}
//   public void test370() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test370"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGamma(43.1284181946612d, 0.9133226440129084d);
//     var0.reSeedSecure(83601L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 35.41583200592093d);
// 
//   }

  public void test371() {}
//   public void test371() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test371"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
//     double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
//     double var7 = var3.getNumericalMean();
//     double[] var9 = var3.sample(1);
//     double var10 = var3.getNumericalMean();
//     double var11 = var3.sample();
//     double var13 = var3.density(1.9124153064037224d);
//     double var14 = var3.getMean();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.3235780930645504d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.3235780930645504d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.3626088305537596d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.2863038544739316E-112d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.3235780930645504d);
// 
//   }

  public void test372() {}
//   public void test372() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test372"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(1.1333982703353287d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test373"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getNumericalMean();
    double[] var9 = var3.sample(1);
    double var11 = var3.density(979.3393873505228d);
    var3.reseedRandomGenerator(0L);
    double var14 = var3.sample();
    double var15 = var3.getMean();
    double var16 = var3.getMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.322456124528837d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1.3235780930645504d);

  }

  public void test374() {}
//   public void test374() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test374"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.rint(Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test375"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var5 = var3.getElement(0);
    int var6 = var3.start();
    int var7 = var3.getExpansionMode();
    float var8 = var3.getContractionCriteria();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setContractionCriteria(1.1920929E-7f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.5f);

  }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test376"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(0L, (-2149118271877359L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test377() {}
//   public void test377() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test377"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(3.1780538303479458d);
//     double var6 = var1.nextWeibull(968.8343073325332d, 0.9149287324253481d);
//     double var9 = var1.nextGaussian(0.0d, Double.POSITIVE_INFINITY);
//     var1.reSeedSecure();
//     int var14 = var1.nextHypergeometric(1399408482, 1861, 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.6506795676521677d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.9138159138435259d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
// 
//   }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test378"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var5 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var4);
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var4);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var7 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var4);
    int var8 = var4.ordinal();
    java.lang.String var9 = var4.name();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "AVERAGE"+ "'", var9.equals("AVERAGE"));

  }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test379"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(0.010050166663333093d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.009999999583352412d);

  }

  public void test380() {}
//   public void test380() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test380"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(short)1);
//     boolean var3 = var2.getBoundIsAllowed();
//     org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var2);
// 
//   }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test381"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(10000);
    var1.addElement(0.5964546144007503d);

  }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test382"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(1.1920929E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1920929E-7f);

  }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test383"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double[] var4 = var3.getElements();
    double[] var5 = var3.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray(var5);
    double var8 = var6.addElementRolling(3.4585712247270832d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);

  }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test384"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(14, 21);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test385"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getStandardDeviation();
    double var9 = var3.cumulativeProbability(4.157279707691014d);
    double var11 = var3.density(0.4105991453937372d);
    double var13 = var3.probability(2.9715526190865114d);
    double var14 = var3.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.025803565724757293d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2.2250111484445025E-271d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == Double.NEGATIVE_INFINITY);

  }

  public void test386() {}
//   public void test386() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test386"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     double var7 = var1.nextCauchy(0.15560730683937996d, 3.1780538303479458d);
//     double var10 = var1.nextBeta(8.985875073756691d, 1.7792833636531957d);
//     int var13 = var1.nextSecureInt(38, 10000);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var1.nextT((-0.29772693774983194d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 10.18093976741509d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.9127781982578973d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 7398);
// 
//   }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test387"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(0.0d, 38.38428471223844d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test388"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double[] var4 = var3.getElements();
    double[] var5 = var3.getInternalValues();
    var3.contract();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test389"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.0d, 0.9237668243211833d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.9E-324d);

  }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test390"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs((-0.13493301273117847d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.13493301273117847d);

  }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test391"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(0L, 9L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test392() {}
//   public void test392() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test392"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextSecureInt(2, 10);
//     double var7 = var1.nextCauchy(0.037062153555774406d, 3.5247804145401362d);
//     double var9 = var1.nextChiSquare(8.00736706798333d);
//     int var12 = var1.nextPascal(9, 0.686579669341957d);
//     double var14 = var1.nextExponential(2.140641475065075d);
//     double var17 = var1.nextUniform(0.0d, 43.1284181946612d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.1638480075030244d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 8.490235191674621d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 4.444579005126557d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 8.739563353200204d);
// 
//   }

  public void test393() {}
//   public void test393() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test393"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(3.1780538303479458d);
//     double var5 = var1.nextExponential(19.39006869589386d);
//     var1.reSeedSecure();
//     var1.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 5.208924279490875d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 5.013119462016452d);
// 
//   }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test394"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    java.lang.String var4 = var2.toString();
    java.lang.String var5 = var2.name();
    org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var12 = var9.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var13 = var9.getNumericalMean();
    double[] var15 = var9.sample(15);
    boolean var16 = var9.isSupportLowerBoundInclusive();
    boolean var17 = var2.equals((java.lang.Object)var9);
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var2);
    boolean var21 = var2.equals((java.lang.Object)(-0.4402198698105254d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "AVERAGE"+ "'", var4.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "AVERAGE"+ "'", var5.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test395"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var2 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var3 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)(byte)100, var2);

  }

  public void test396() {}
//   public void test396() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test396"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy[] var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
//     org.apache.commons.math3.exception.MathArithmeticException var2 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var1);
//     java.lang.String var3 = var2.toString();
// 
//   }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test397"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(58343, 1861);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 108576323);

  }

  public void test398() {}
//   public void test398() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test398"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     double var7 = var1.nextCauchy(0.15560730683937996d, 3.1780538303479458d);
//     double var11 = var1.nextUniform((-0.6740495597759653d), (-0.016482976994642014d), true);
//     int var14 = var1.nextPascal(5, 0.9864231484692195d);
//     var1.reSeedSecure();
//     int var18 = var1.nextInt(0, 7);
//     long var20 = var1.nextPoisson(71.34241022211371d);
//     double var22 = var1.nextChiSquare(0.08772462544619851d);
//     double var25 = var1.nextCauchy((-3.29515894983552d), 1.4994259604654114d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var28 = var1.nextBinomial(68, 6.283705374634298d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 8.230329148504515d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.23593069695560032d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 63L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 9.652931274665086E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == (-3.5309280191423476d));
// 
//   }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test399"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getNumericalMean();
    double[] var9 = var3.sample(1);
    double var11 = var3.density(979.3393873505228d);
    double var13 = var3.density(3921225.0d);
    double[] var15 = var3.sample(10000);
    var3.reseedRandomGenerator(201L);
    double var19 = var3.cumulativeProbability(0.09409951665194471d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);

  }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test400"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(39.61319055227623d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.666486994447429d);

  }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test401"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb((-0.7988667594075136d), (-71));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-3.3833323284221916E-22d));

  }

  public void test402() {}
//   public void test402() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test402"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     double var7 = var1.nextCauchy(0.15560730683937996d, 3.1780538303479458d);
//     double var11 = var1.nextUniform((-0.6740495597759653d), (-0.016482976994642014d), true);
//     int var14 = var1.nextPascal(5, 0.9864231484692195d);
//     var1.reSeedSecure();
//     int var18 = var1.nextInt(0, 7);
//     long var20 = var1.nextPoisson(71.34241022211371d);
//     double var22 = var1.nextChiSquare(0.08772462544619851d);
//     double var25 = var1.nextCauchy((-3.29515894983552d), 1.4994259604654114d);
//     double var28 = var1.nextUniform(0.0d, 1.0584618047656464d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-2.672797868849784d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.649279209724529d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 81L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 4.883582255643798E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == (-10.801406351075997d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0.9167348369434362d);
// 
//   }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test403"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(100.0f, (-0.99999994f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100.0f);

  }

  public void test404() {}
//   public void test404() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test404"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     var1.reSeedSecure(10L);
//     double var9 = var1.nextCauchy(1.762747174039086d, 0.025803565724757293d);
//     double var11 = var1.nextExponential(6.938893903907228E-18d);
//     int var15 = var1.nextHypergeometric(5, 0, 0);
//     long var18 = var1.nextSecureLong((-40250L), 102L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var20 = var1.nextT((-0.5109473648972219d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.7733583500313608d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.0574003003973372E-17d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-17024L));
// 
//   }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test405"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)2.718281525573209d);

  }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test406"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(1.566234879235391d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test407() {}
//   public void test407() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test407"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.sqrt((-0.7853981633974482d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test408"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(2.4796438758057278d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.7792322490867346d));

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test409"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(0);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test410"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)0.9093102466862683d);
    java.lang.Number var3 = var2.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));

  }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test411"); }


    double var1 = org.apache.commons.math3.special.Gamma.logGamma(41.26320996706553d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 111.2957193832418d);

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test412"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh((-68.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-4.912708947095866d));

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test413"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(1.12505066477235d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8441763479328743d);

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test414"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint((-1.3173720911599616d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test415"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(112460126646364816L, (-7227766516491148358L));
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test416"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(112460126646364816L, 2L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 112460126646364814L);

  }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test417"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(0.707769364960512d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.34563699406382414d));

  }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test418"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(152444951);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 152444951);

  }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test419"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.9228352829279439d, 0.025803565724757293d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9979300024779328d);

  }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test420"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(0.9034897375799414d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 14.021846690286448d);

  }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test421"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(0.9093102466862683d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9535776039139491d);

  }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test422"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, var1);

  }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test423"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(58343, 2.0f);
    double[] var3 = var2.getElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test424"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getNumericalMean();
    double[] var9 = var3.sample(1);
    double var10 = var3.getNumericalMean();
    double var12 = var3.probability((-0.6981152095798223d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);

  }

  public void test425() {}
//   public void test425() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test425"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
//     double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
//     double var7 = var3.getNumericalMean();
//     double var8 = var3.getMean();
//     double var9 = var3.sample();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.3235780930645504d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.3235780930645504d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.362796118618169d);
// 
//   }

  public void test426() {}
//   public void test426() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test426"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextSecureInt(2, 10);
//     double var8 = var1.nextUniform(3.1780538303479458d, 4.810477380965351d, false);
//     double var11 = var1.nextF(2.4823187300238665d, 0.5573731387105724d);
//     java.lang.String var13 = var1.nextHexString(1);
//     java.lang.String var15 = var1.nextSecureHexString(10000);
//     double var18 = var1.nextCauchy(0.5196265085690617d, 2.9715526190865114d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 3.8752242915617785d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 12.637985796283571d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "f"+ "'", var13.equals("f"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-7.8502096530181795d));
// 
//   }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test427"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var3.setElement(3, (-0.7853981633974483d));
    int var7 = var3.getNumElements();
    double var9 = var3.substituteMostRecentElement((-0.7853981633974483d));
    float var10 = var3.getExpansionFactor();
    var3.contract();
    var3.setElement(14, 6.491753541596189d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.discardMostRecentElements((-21));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-0.7853981633974483d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 2.0f);

  }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test428"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(58343);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test429"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(58343, (-71));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test430"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(1.3506254701664102d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9334690638538092d);

  }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test431"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan((-0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.0d));

  }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test432"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble((-5));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test433"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(1);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = var1.copy();
    double[] var3 = var1.getElements();
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.math.BigInteger var5 = null;
    java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 0L);
    java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 0L);
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var14 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10.0d, (java.lang.Number)1.0f, true);
    org.apache.commons.math3.exception.util.Localizable var15 = null;
    org.apache.commons.math3.exception.util.Localizable var16 = null;
    java.lang.Object[] var18 = new java.lang.Object[] { (short)1};
    org.apache.commons.math3.exception.MathArithmeticException var19 = new org.apache.commons.math3.exception.MathArithmeticException(var16, var18);
    org.apache.commons.math3.exception.MathIllegalStateException var20 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var14, var15, var18);
    java.lang.Throwable[] var21 = var14.getSuppressed();
    org.apache.commons.math3.exception.MathArithmeticException var22 = new org.apache.commons.math3.exception.MathArithmeticException(var10, (java.lang.Object[])var21);
    org.apache.commons.math3.exception.MaxCountExceededException var23 = new org.apache.commons.math3.exception.MaxCountExceededException(var4, (java.lang.Number)var9, (java.lang.Object[])var21);
    org.apache.commons.math3.exception.util.Localizable var24 = null;
    java.math.BigInteger var25 = null;
    java.math.BigInteger var27 = org.apache.commons.math3.util.ArithmeticUtils.pow(var25, 0L);
    java.math.BigInteger var29 = org.apache.commons.math3.util.ArithmeticUtils.pow(var25, 0L);
    org.apache.commons.math3.exception.util.Localizable var30 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var34 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10.0d, (java.lang.Number)1.0f, true);
    org.apache.commons.math3.exception.util.Localizable var35 = null;
    org.apache.commons.math3.exception.util.Localizable var36 = null;
    java.lang.Object[] var38 = new java.lang.Object[] { (short)1};
    org.apache.commons.math3.exception.MathArithmeticException var39 = new org.apache.commons.math3.exception.MathArithmeticException(var36, var38);
    org.apache.commons.math3.exception.MathIllegalStateException var40 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var34, var35, var38);
    java.lang.Throwable[] var41 = var34.getSuppressed();
    org.apache.commons.math3.exception.MathArithmeticException var42 = new org.apache.commons.math3.exception.MathArithmeticException(var30, (java.lang.Object[])var41);
    org.apache.commons.math3.exception.MaxCountExceededException var43 = new org.apache.commons.math3.exception.MaxCountExceededException(var24, (java.lang.Number)var29, (java.lang.Object[])var41);
    java.math.BigInteger var44 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, var29);
    boolean var45 = var1.equals((java.lang.Object)var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);

  }

  public void test434() {}
//   public void test434() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test434"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     var1.reSeedSecure(1L);
//     double var8 = var1.nextExponential(176.73201156338953d);
//     org.apache.commons.math3.distribution.IntegerDistribution var9 = null;
//     int var10 = var1.nextInversionDeviate(var9);
// 
//   }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test435"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)36.0d);

  }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test436"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 10);

  }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test437"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(7, (-2));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7);

  }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test438"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var5 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var4);
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var4);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var7 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var4);
    int var8 = var4.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 3);

  }

  public void test439() {}
//   public void test439() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test439"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     double var7 = var1.nextCauchy(0.15560730683937996d, 3.1780538303479458d);
//     long var9 = var1.nextPoisson(1.5707963267948966d);
//     var1.reSeed(101L);
//     var1.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-5.972894633613793d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 3L);
// 
//   }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test440"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.0f);
    java.lang.Number var2 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0+ "'", var2.equals(0));

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test441"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var3.discardFrontElements(2);
    var3.setElement(6, (-0.3738789406485615d));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.discardFrontElements(17);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test442"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test443() {}
//   public void test443() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test443"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(3.1780538303479458d);
//     double var5 = var1.nextExponential(19.39006869589386d);
//     var1.reSeedSecure(9223372036854775807L);
//     var1.reSeedSecure(2L);
//     var1.reSeed();
//     java.lang.String var12 = var1.nextHexString(7);
//     double var14 = var1.nextT(2.8627981112072765d);
//     int var17 = var1.nextBinomial(0, 0.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var19 = var1.nextChiSquare((-0.2590796335125806d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.5415982529315084d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 17.91806352574011d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "967a963"+ "'", var12.equals("967a963"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-0.5613820841253533d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0);
// 
//   }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test444"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(658.6791243661528d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 658.0d);

  }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test445"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians((-0.03791546974136306d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-6.617497844270683E-4d));

  }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test446"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("b7668135312ebfb291");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test447"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(7, 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 8);

  }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test448"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(0.336819898262453d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9.906336773220339d);

  }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test449"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-1), 27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));

  }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test450"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(4.130828839435178d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 31.12277468337147d);

  }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test451"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(9, (-0.99999994f), 0.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test452"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians((-0.7853981633974483d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.013707783890401887d));

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test453"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(108576323, 1431655772);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1540232095);

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test454"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(-0.549132653311572d), (java.lang.Number)4.9E-324d, (java.lang.Number)4.016175731375696d);

  }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test455"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var5 = var3.getElement(0);
    double[] var6 = var3.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(10);
    double var10 = var8.addElementRolling((-20.34054861465728d));
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var3, var8);
    float var12 = var3.getExpansionFactor();
    int var13 = var3.getExpansionMode();
    var3.setNumElements(58343);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);

  }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test456"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var3.setElement(3, (-0.7853981633974483d));
    var3.contract();
    var3.contract();
    double[] var11 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var11);
    double var14 = var12.getElement(0);
    var12.addElement(0.5403023058681398d);
    var12.discardFrontElements(0);
    double[] var19 = var12.getInternalValues();
    var3.addElements(var19);
    float var21 = var3.getExpansionFactor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setExpansionMode(100);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 2.0f);

  }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test457"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(46, 21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 67);

  }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test458"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(-0.6206008190792572d), (java.lang.Number)(-0.49810022948185106d), true);

  }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test459"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs((-0.21452323545111215d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.21452323545111215d);

  }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test460"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc((-9.602370808556296d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0d);

  }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test461"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)10000, (java.lang.Number)1.3440585709080678E43d, true);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var8 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MathIllegalArgumentException var9 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var7, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var5, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test462"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(7.378698E20f, 25.19122118273868d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7.3786976E20f);

  }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test463"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var2.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var2.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = var2.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var2.getNanStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test464"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var5 = var3.getElement(0);
    double[] var6 = var3.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = var3.copy();
    float var8 = var3.getExpansionFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.0f);

  }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test465"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var3.discardMostRecentElements(0);
    var3.setElement(10000, 0.9254962739500686d);
    float var9 = var3.getContractionCriteria();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setContractionCriteria(1.4210855E-14f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 2.5f);

  }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test466"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(9.536743E-7f, 67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.40737488E14f);

  }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test467"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10.0d, (java.lang.Number)1.0f, true);
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    java.lang.Object[] var7 = new java.lang.Object[] { (short)1};
    org.apache.commons.math3.exception.MathArithmeticException var8 = new org.apache.commons.math3.exception.MathArithmeticException(var5, var7);
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, var7);
    org.apache.commons.math3.exception.NumberIsTooLargeException var13 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10L, (java.lang.Number)3921225.0d, true);
    var3.addSuppressed((java.lang.Throwable)var13);
    java.lang.String var15 = var13.toString();
    boolean var16 = var13.getBoundIsAllowed();
    org.apache.commons.math3.exception.MathInternalError var17 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (3,921,225)"+ "'", var15.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (3,921,225)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);

  }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test468"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs((-0.99999994f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.99999994f);

  }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test469"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(8, 4.0f);
    var2.clear();

  }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test470"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)3.657242590218247d, (java.lang.Number)(-2.20725760697381d), true);
    java.lang.Number var4 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (-2.20725760697381d)+ "'", var4.equals((-2.20725760697381d)));

  }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test471"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.6865796693419571d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7734186671227028d);

  }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test472"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(11.0d, (-1.929622419782979d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-11.0d));

  }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test473"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var6 = var3.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var7 = var3.getStandardDeviation();
    double var9 = var3.cumulativeProbability(4.157279707691014d);
    double var11 = var3.probability((-0.549132653311572d));
    double var13 = var3.cumulativeProbability(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.025803565724757293d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);

  }

  public void test474() {}
//   public void test474() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test474"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextSecureInt(2, 10);
//     var1.reSeed(3L);
//     int var9 = var1.nextInt(0, 10);
//     var1.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var1.nextInt(100, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 9);
// 
//   }

  public void test475() {}
//   public void test475() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test475"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     double var7 = var1.nextCauchy(0.15560730683937996d, 3.1780538303479458d);
//     double var10 = var1.nextBeta(8.985875073756691d, 1.7792833636531957d);
//     int[] var13 = var1.nextPermutation(14, 6);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("c", "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (3,921,225)");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-6.570835563793132d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.94792626517016d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
// 
//   }

  public void test476() {}
//   public void test476() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test476"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextZipf(100, 10.0d);
//     var1.reSeedSecure(10L);
//     double var9 = var1.nextF(1.0d, 47.71468531505997d);
//     long var12 = var1.nextSecureLong(1L, 10L);
//     long var15 = var1.nextSecureLong(100L, 477733L);
//     var1.reSeed(9L);
//     double var20 = var1.nextGamma((-0.03791546974136306d), (-0.9017707629176819d));
//     var1.reSeed(7L);
//     double var25 = var1.nextCauchy(0.31170684257905307d, 1.7006991033646932d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.8359278159448861d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 76817L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == (-1.4412304841237153d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == (-9.93524029751647d));
// 
//   }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test477"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck((-7227766516491148358L), 930313L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test478() {}
//   public void test478() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test478"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextSecureInt(2, 10);
//     double var6 = var1.nextExponential(1.7763568394002505E-15d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var1.nextHypergeometric(9, 67, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.7959330626745692E-16d);
// 
//   }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test479"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(43.1284181946612d, (-0.3556025929135851d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 43.128418194661194d);

  }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test480"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(1700, 1399408473);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test481"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(1.8439600399218803d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.081666246819766d);

  }

  public void test482() {}
//   public void test482() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test482"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.0d, 0.0d, 0.8740383559599469d, 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test483"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double var5 = var3.getElement(0);
    int var6 = var3.getNumElements();
    var3.contract();
    double var9 = var3.substituteMostRecentElement(4.754806993644028d);
    boolean var11 = var3.equals((java.lang.Object)0.0010231502395483475d);
    int var12 = var3.getExpansionMode();
    int var13 = var3.getNumElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 2);

  }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test484"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(34.29040217973706d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.9003398768959225E14d);

  }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test485"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd((-2149118271877359L), 76817L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test486"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.random.RandomGenerator var1 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var1);
    org.apache.commons.math3.stat.ranking.TiesStrategy var3 = var2.getTiesStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test487"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint((-4.912708947095866d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-5.0d));

  }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test488"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(1.40737488E14f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.40737488E14f);

  }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test489"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(1399408455, (-2));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test490() {}
//   public void test490() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test490"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextSecureInt(2, 10);
//     var1.reSeed(3L);
//     int var9 = var1.nextInt(4, 9);
//     double var12 = var1.nextCauchy(1.1519447188851685E-11d, 6.658240041118693E-4d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var14 = var1.nextSecureHexString((-5));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.005980782441987599d);
// 
//   }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test491"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(355687428096000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 355687428096000L);

  }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test492"); }


    double[] var2 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var3.setElement(3, (-0.7853981633974483d));
    int var7 = var3.getNumElements();
    double var9 = var3.substituteMostRecentElement((-0.7853981633974483d));
    float var10 = var3.getExpansionFactor();
    var3.contract();
    org.apache.commons.math3.distribution.NormalDistribution var15 = new org.apache.commons.math3.distribution.NormalDistribution(1.3235780930645504d, 0.025803565724757293d, (-0.01859736360708744d));
    double var18 = var15.cumulativeProbability(0.0d, 0.1690925369322372d);
    double var19 = var15.getNumericalMean();
    double[] var21 = var15.sample(1);
    double var23 = var15.density(979.3393873505228d);
    double var25 = var15.density(3921225.0d);
    boolean var26 = var15.isSupportLowerBoundInclusive();
    double var27 = var15.getMean();
    double[] var29 = var15.sample(10000);
    var3.addElements(var29);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.discardFrontElements((-7));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-0.7853981633974483d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 1.3235780930645504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test493"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1.367158746897041E-7d, false);

  }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test494"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble(1552);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test495"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs((-2149118271877359L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2149118271877359L);

  }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test496"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10L, (java.lang.Number)3921225.0d, true);
    java.lang.Number var4 = var3.getArgument();
    java.lang.Number var5 = var3.getMax();
    java.lang.Number var6 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 10L+ "'", var4.equals(10L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 3921225.0d+ "'", var5.equals(3921225.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 3921225.0d+ "'", var6.equals(3921225.0d));

  }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test497"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)100.0d, (java.lang.Number)(-2.1805166473703887d), true);
    java.lang.Number var5 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-2.1805166473703887d)+ "'", var5.equals((-2.1805166473703887d)));

  }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test498"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(1307674368000L, 477733L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1307673890267L);

  }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test499"); }


    org.apache.commons.math3.exception.MathInternalError var0 = new org.apache.commons.math3.exception.MathInternalError();
    org.apache.commons.math3.exception.util.ExceptionContext var1 = var0.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test500"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.7615941542245016d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

}
