
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var4 = var1.nextInt(100, (-1));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }


    double[] var1 = new double[] { 0.0d};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkPositive(var1);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test3() {}
//   public void test3() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, (-1));
// 
//   }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(100.0d, (-1.0d), 13.226435756113098d, 0.0d, (-1.0d), 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-10101.0d));

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination((-1.682916631768903d), (-10101.0d), (-10101.0d), 2.0d, 10001.0d, 0.40877566087838346d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 885.3062819424027d);

  }

  public void test6() {}
//   public void test6() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }
// 
// 
//     double[] var2 = new double[] { 100.0d, (-1.0d)};
//     double[] var5 = new double[] { 100.0d, 1.0d};
//     boolean var6 = org.apache.commons.math3.util.MathArrays.equals(var2, var5);
//     double[] var9 = new double[] { 100.0d, (-1.0d)};
//     double[] var12 = new double[] { 100.0d, 1.0d};
//     boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var9, var12);
//     double var14 = org.apache.commons.math3.util.MathArrays.distance(var5, var9);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var15 = null;
//     boolean var17 = org.apache.commons.math3.util.MathArrays.isMonotonic(var5, var15, false);
// 
//   }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var5 = var2.nextPermutation(0, (-1));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var5 = var2.nextSecureLong(0L, 0L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var2.nextBeta((-1.682916631768903d), 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
    } catch (org.apache.commons.math3.exception.NoBracketingException e) {
      // Expected exception.
    }

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var4 = var2.nextPoisson((-1.682916631768903d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(0.0d, 0.40877566087838346d, 0.0d, 8.418185040882479d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);

  }

  public void test12() {}
//   public void test12() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1.0d, (java.lang.Number)10, true);
//     boolean var5 = var4.getBoundIsAllowed();
//     java.lang.String var6 = var4.toString();
// 
//   }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var6 = var2.nextUniform(0.0d, (-1.0d), false);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test14() {}
//   public void test14() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }
// 
// 
//     java.util.List var0 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var1 = new org.apache.commons.math3.distribution.DiscreteDistribution(var0);
// 
//   }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    var1.setSeed((-1));

  }

  public void test16() {}
//   public void test16() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }
// 
// 
//     double[] var2 = new double[] { 100.0d, (-1.0d)};
//     double[] var5 = new double[] { 100.0d, 1.0d};
//     boolean var6 = org.apache.commons.math3.util.MathArrays.equals(var2, var5);
//     double[] var9 = new double[] { 100.0d, (-1.0d)};
//     double[] var12 = new double[] { 100.0d, 1.0d};
//     boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var9, var12);
//     double var14 = org.apache.commons.math3.util.MathArrays.distance(var5, var9);
//     double[] var17 = new double[] { 100.0d, (-1.0d)};
//     double[] var20 = new double[] { 100.0d, 1.0d};
//     boolean var21 = org.apache.commons.math3.util.MathArrays.equals(var17, var20);
//     double[] var24 = new double[] { 100.0d, (-1.0d)};
//     double[] var27 = new double[] { 100.0d, 1.0d};
//     boolean var28 = org.apache.commons.math3.util.MathArrays.equals(var24, var27);
//     double var29 = org.apache.commons.math3.util.MathArrays.distance(var20, var24);
//     double var30 = org.apache.commons.math3.util.MathArrays.linearCombination(var5, var20);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var31 = null;
//     boolean var34 = org.apache.commons.math3.util.MathArrays.checkOrder(var20, var31, false, false);
// 
//   }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var5 = var2.nextBinomial((-1), 2.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(885.3062819424027d, 10001.0d, 100.0d, 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 9854048.12570597d);

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }


    org.apache.commons.math3.exception.MathIllegalStateException var0 = new org.apache.commons.math3.exception.MathIllegalStateException();

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }


    org.apache.commons.math3.exception.NotANumberException var0 = new org.apache.commons.math3.exception.NotANumberException();

  }

  public void test21() {}
//   public void test21() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextGaussian(0.0d, 2.0d);
//     var1.reSeedSecure(0L);
//     java.util.Collection var7 = null;
//     java.lang.Object[] var9 = var1.nextSample(var7, 1);
// 
//   }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }


    double[] var2 = new double[] { 100.0d, (-1.0d)};
    double[] var5 = new double[] { 100.0d, 1.0d};
    boolean var6 = org.apache.commons.math3.util.MathArrays.equals(var2, var5);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var2);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var4 = var2.nextSecureHexString(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 100, 10);
    int var4 = var3.getDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 10);

  }

  public void test25() {}
//   public void test25() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }
// 
// 
//     int[] var0 = null;
//     int[] var2 = new int[] { (-1)};
//     int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var2);
//     int[] var5 = new int[] { (-1)};
//     int[] var6 = org.apache.commons.math3.util.MathArrays.copyOf(var5);
//     int var7 = org.apache.commons.math3.util.MathArrays.distanceInf(var3, var5);
//     org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(var5);
//     double var9 = org.apache.commons.math3.util.MathArrays.distance(var0, var5);
// 
//   }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }


    double[] var3 = new double[] { 10.0d, (-1.0d), 0.0d};
    org.apache.commons.math3.util.MathArrays.OrderDirection var4 = null;
    double[] var7 = new double[] { 100.0d, (-1.0d)};
    double[] var10 = new double[] { 100.0d, 1.0d};
    boolean var11 = org.apache.commons.math3.util.MathArrays.equals(var7, var10);
    double[] var14 = new double[] { 100.0d, (-1.0d)};
    double[] var17 = new double[] { 100.0d, 1.0d};
    boolean var18 = org.apache.commons.math3.util.MathArrays.equals(var14, var17);
    double var19 = org.apache.commons.math3.util.MathArrays.distance(var10, var14);
    double[][] var20 = new double[][] { var10};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.sortInPlace(var3, var4, var20);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test27() {}
//   public void test27() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }
// 
// 
//     double[] var2 = new double[] { 100.0d, (-1.0d)};
//     double[] var5 = new double[] { 100.0d, 1.0d};
//     boolean var6 = org.apache.commons.math3.util.MathArrays.equals(var2, var5);
//     double[] var9 = new double[] { 100.0d, (-1.0d)};
//     double[] var12 = new double[] { 100.0d, 1.0d};
//     boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var9, var12);
//     double[] var16 = new double[] { 100.0d, (-1.0d)};
//     double[] var19 = new double[] { 100.0d, 1.0d};
//     boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var16, var19);
//     double[] var23 = new double[] { 100.0d, (-1.0d)};
//     double[] var26 = new double[] { 100.0d, 1.0d};
//     boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var23, var26);
//     double var28 = org.apache.commons.math3.util.MathArrays.distance(var19, var23);
//     double[] var31 = new double[] { 100.0d, (-1.0d)};
//     double[] var34 = new double[] { 100.0d, 1.0d};
//     boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var31, var34);
//     double[] var38 = new double[] { 100.0d, (-1.0d)};
//     double[] var41 = new double[] { 100.0d, 1.0d};
//     boolean var42 = org.apache.commons.math3.util.MathArrays.equals(var38, var41);
//     double var43 = org.apache.commons.math3.util.MathArrays.distance(var34, var38);
//     double var44 = org.apache.commons.math3.util.MathArrays.linearCombination(var19, var34);
//     boolean var45 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var9, var19);
//     double[] var47 = org.apache.commons.math3.util.MathArrays.normalizeArray(var19, (-1.682916631768903d));
//     double[] var48 = org.apache.commons.math3.util.MathArrays.ebeAdd(var5, var19);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var49 = null;
//     boolean var52 = org.apache.commons.math3.util.MathArrays.checkOrder(var5, var49, true, true);
// 
//   }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextZipf(100, 2.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var8 = var2.nextPermutation(30, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);

  }

  public void test29() {}
//   public void test29() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }
// 
// 
//     double[] var2 = new double[] { 100.0d, (-1.0d)};
//     double[] var5 = new double[] { 100.0d, 1.0d};
//     boolean var6 = org.apache.commons.math3.util.MathArrays.equals(var2, var5);
//     double[] var9 = new double[] { 100.0d, (-1.0d)};
//     double[] var12 = new double[] { 100.0d, 1.0d};
//     boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var9, var12);
//     double[] var16 = new double[] { 100.0d, (-1.0d)};
//     double[] var19 = new double[] { 100.0d, 1.0d};
//     boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var16, var19);
//     double var21 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
//     double[] var24 = new double[] { 100.0d, (-1.0d)};
//     double[] var27 = new double[] { 100.0d, 1.0d};
//     boolean var28 = org.apache.commons.math3.util.MathArrays.equals(var24, var27);
//     double[] var31 = new double[] { 100.0d, (-1.0d)};
//     double[] var34 = new double[] { 100.0d, 1.0d};
//     boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var31, var34);
//     double var36 = org.apache.commons.math3.util.MathArrays.distance(var27, var31);
//     double var37 = org.apache.commons.math3.util.MathArrays.linearCombination(var12, var27);
//     boolean var38 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var2, var12);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var39 = null;
//     double[] var42 = new double[] { 100.0d, (-1.0d)};
//     double[] var45 = new double[] { 100.0d, 1.0d};
//     boolean var46 = org.apache.commons.math3.util.MathArrays.equals(var42, var45);
//     double[] var49 = new double[] { 100.0d, (-1.0d)};
//     double[] var52 = new double[] { 100.0d, 1.0d};
//     boolean var53 = org.apache.commons.math3.util.MathArrays.equals(var49, var52);
//     double[] var56 = new double[] { 100.0d, (-1.0d)};
//     double[] var59 = new double[] { 100.0d, 1.0d};
//     boolean var60 = org.apache.commons.math3.util.MathArrays.equals(var56, var59);
//     double[] var63 = new double[] { 100.0d, (-1.0d)};
//     double[] var66 = new double[] { 100.0d, 1.0d};
//     boolean var67 = org.apache.commons.math3.util.MathArrays.equals(var63, var66);
//     double var68 = org.apache.commons.math3.util.MathArrays.distance(var59, var63);
//     double[] var71 = new double[] { 100.0d, (-1.0d)};
//     double[] var74 = new double[] { 100.0d, 1.0d};
//     boolean var75 = org.apache.commons.math3.util.MathArrays.equals(var71, var74);
//     double[] var78 = new double[] { 100.0d, (-1.0d)};
//     double[] var81 = new double[] { 100.0d, 1.0d};
//     boolean var82 = org.apache.commons.math3.util.MathArrays.equals(var78, var81);
//     double var83 = org.apache.commons.math3.util.MathArrays.distance(var74, var78);
//     double var84 = org.apache.commons.math3.util.MathArrays.linearCombination(var59, var74);
//     boolean var85 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var49, var59);
//     double[] var87 = org.apache.commons.math3.util.MathArrays.normalizeArray(var59, (-1.682916631768903d));
//     double[] var88 = org.apache.commons.math3.util.MathArrays.ebeAdd(var45, var59);
//     double[][] var89 = new double[][] { var45};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var2, var39, var89);
// 
//   }

  public void test30() {}
//   public void test30() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextGaussian(0.0d, 2.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var7 = var1.nextPascal((-1), 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-1.381910963229768d));
// 
//   }

  public void test31() {}
//   public void test31() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 0);
// 
//   }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var5 = var0.nextHypergeometric(30, 86, 1);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test33() {}
//   public void test33() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextGaussian(0.0d, 2.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var7 = var1.nextInt(100, (-1));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-2.40319265699144d));
// 
//   }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(byte)100, (java.lang.Number)0.0d, true);

  }

  public void test35() {}
//   public void test35() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }
// 
// 
//     long[] var0 = null;
//     long[][] var1 = new long[][] { var0};
//     org.apache.commons.math3.util.MathArrays.checkNonNegative(var1);
// 
//   }

  public void test36() {}
//   public void test36() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var5 = var2.nextSecureLong(0L, 1L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var8 = var2.nextPermutation(0, 30);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0L);
// 
//   }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(100, 1);
    java.lang.String var3 = var2.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "org.apache.commons.math3.exception.DimensionMismatchException: 100 != 1"+ "'", var3.equals("org.apache.commons.math3.exception.DimensionMismatchException: 100 != 1"));

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    int var2 = var0.nextInt(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }


    double[] var2 = new double[] { 100.0d, (-1.0d)};
    double[] var5 = new double[] { 100.0d, 1.0d};
    boolean var6 = org.apache.commons.math3.util.MathArrays.equals(var2, var5);
    double[] var9 = new double[] { 100.0d, (-1.0d)};
    double[] var12 = new double[] { 100.0d, 1.0d};
    boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var9, var12);
    double[] var16 = new double[] { 100.0d, (-1.0d)};
    double[] var19 = new double[] { 100.0d, 1.0d};
    boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var16, var19);
    double var21 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double[] var24 = new double[] { 100.0d, (-1.0d)};
    double[] var27 = new double[] { 100.0d, 1.0d};
    boolean var28 = org.apache.commons.math3.util.MathArrays.equals(var24, var27);
    double[] var31 = new double[] { 100.0d, (-1.0d)};
    double[] var34 = new double[] { 100.0d, 1.0d};
    boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var31, var34);
    double var36 = org.apache.commons.math3.util.MathArrays.distance(var27, var31);
    double var37 = org.apache.commons.math3.util.MathArrays.linearCombination(var12, var27);
    boolean var38 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var2, var12);
    double[] var40 = org.apache.commons.math3.util.MathArrays.normalizeArray(var12, (-1.682916631768903d));
    double[] var43 = new double[] { 100.0d, (-1.0d)};
    double[] var46 = new double[] { 100.0d, 1.0d};
    boolean var47 = org.apache.commons.math3.util.MathArrays.equals(var43, var46);
    double[] var50 = new double[] { 100.0d, (-1.0d)};
    double[] var53 = new double[] { 100.0d, 1.0d};
    boolean var54 = org.apache.commons.math3.util.MathArrays.equals(var50, var53);
    double var55 = org.apache.commons.math3.util.MathArrays.distance(var46, var50);
    double[] var58 = new double[] { 100.0d, (-1.0d)};
    double[] var61 = new double[] { 100.0d, 1.0d};
    boolean var62 = org.apache.commons.math3.util.MathArrays.equals(var58, var61);
    double[] var65 = new double[] { 100.0d, (-1.0d)};
    double[] var68 = new double[] { 100.0d, 1.0d};
    boolean var69 = org.apache.commons.math3.util.MathArrays.equals(var65, var68);
    double var70 = org.apache.commons.math3.util.MathArrays.distance(var61, var65);
    double var71 = org.apache.commons.math3.util.MathArrays.linearCombination(var46, var61);
    double[] var72 = org.apache.commons.math3.util.MathArrays.ebeAdd(var40, var46);
    double[] var73 = org.apache.commons.math3.util.MathArrays.copyOf(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);

  }

  public void test40() {}
//   public void test40() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }
// 
// 
//     double[] var2 = new double[] { 100.0d, (-1.0d)};
//     double[] var5 = new double[] { 100.0d, 1.0d};
//     boolean var6 = org.apache.commons.math3.util.MathArrays.equals(var2, var5);
//     double[] var9 = new double[] { 100.0d, (-1.0d)};
//     double[] var12 = new double[] { 100.0d, 1.0d};
//     boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var9, var12);
//     double[] var16 = new double[] { 100.0d, (-1.0d)};
//     double[] var19 = new double[] { 100.0d, 1.0d};
//     boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var16, var19);
//     double var21 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
//     double[] var24 = new double[] { 100.0d, (-1.0d)};
//     double[] var27 = new double[] { 100.0d, 1.0d};
//     boolean var28 = org.apache.commons.math3.util.MathArrays.equals(var24, var27);
//     double[] var31 = new double[] { 100.0d, (-1.0d)};
//     double[] var34 = new double[] { 100.0d, 1.0d};
//     boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var31, var34);
//     double var36 = org.apache.commons.math3.util.MathArrays.distance(var27, var31);
//     double var37 = org.apache.commons.math3.util.MathArrays.linearCombination(var12, var27);
//     boolean var38 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var2, var12);
//     double[] var40 = org.apache.commons.math3.util.MathArrays.normalizeArray(var12, (-1.682916631768903d));
//     org.apache.commons.math3.util.MathArrays.OrderDirection var41 = null;
//     double[] var44 = new double[] { 100.0d, (-1.0d)};
//     double[] var47 = new double[] { 100.0d, 1.0d};
//     boolean var48 = org.apache.commons.math3.util.MathArrays.equals(var44, var47);
//     double[] var51 = new double[] { 100.0d, (-1.0d)};
//     double[] var54 = new double[] { 100.0d, 1.0d};
//     boolean var55 = org.apache.commons.math3.util.MathArrays.equals(var51, var54);
//     double var56 = org.apache.commons.math3.util.MathArrays.distance(var47, var51);
//     double[] var59 = new double[] { 100.0d, (-1.0d)};
//     double[] var62 = new double[] { 100.0d, 1.0d};
//     boolean var63 = org.apache.commons.math3.util.MathArrays.equals(var59, var62);
//     double[] var66 = new double[] { 100.0d, (-1.0d)};
//     double[] var69 = new double[] { 100.0d, 1.0d};
//     boolean var70 = org.apache.commons.math3.util.MathArrays.equals(var66, var69);
//     double var71 = org.apache.commons.math3.util.MathArrays.distance(var62, var66);
//     double[] var74 = new double[] { 100.0d, (-1.0d)};
//     double[] var77 = new double[] { 100.0d, 1.0d};
//     boolean var78 = org.apache.commons.math3.util.MathArrays.equals(var74, var77);
//     double[] var81 = new double[] { 100.0d, (-1.0d)};
//     double[] var84 = new double[] { 100.0d, 1.0d};
//     boolean var85 = org.apache.commons.math3.util.MathArrays.equals(var81, var84);
//     double var86 = org.apache.commons.math3.util.MathArrays.distance(var77, var81);
//     double var87 = org.apache.commons.math3.util.MathArrays.linearCombination(var62, var77);
//     double[][] var88 = new double[][] { var62};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var51, var88);
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var12, var41, var88);
// 
//   }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(10L);

  }

  public void test42() {}
//   public void test42() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextGaussian(10.0d, 2.0d);
//     int var7 = var1.nextInt(0, 1);
//     var1.reSeed(0L);
//     org.apache.commons.math3.distribution.RealDistribution var10 = null;
//     double var11 = var1.nextInversionDeviate(var10);
// 
//   }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }


    double[] var2 = new double[] { 100.0d, (-1.0d)};
    double[] var5 = new double[] { 100.0d, 1.0d};
    boolean var6 = org.apache.commons.math3.util.MathArrays.equals(var2, var5);
    double[] var9 = new double[] { 100.0d, (-1.0d)};
    double[] var12 = new double[] { 100.0d, 1.0d};
    boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var9, var12);
    double[] var16 = new double[] { 100.0d, (-1.0d)};
    double[] var19 = new double[] { 100.0d, 1.0d};
    boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var16, var19);
    double[] var23 = new double[] { 100.0d, (-1.0d)};
    double[] var26 = new double[] { 100.0d, 1.0d};
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var23, var26);
    double var28 = org.apache.commons.math3.util.MathArrays.distance(var19, var23);
    double[] var31 = new double[] { 100.0d, (-1.0d)};
    double[] var34 = new double[] { 100.0d, 1.0d};
    boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var31, var34);
    double[] var38 = new double[] { 100.0d, (-1.0d)};
    double[] var41 = new double[] { 100.0d, 1.0d};
    boolean var42 = org.apache.commons.math3.util.MathArrays.equals(var38, var41);
    double var43 = org.apache.commons.math3.util.MathArrays.distance(var34, var38);
    double var44 = org.apache.commons.math3.util.MathArrays.linearCombination(var19, var34);
    boolean var45 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var9, var19);
    double[] var47 = org.apache.commons.math3.util.MathArrays.normalizeArray(var19, (-1.682916631768903d));
    double[] var48 = org.apache.commons.math3.util.MathArrays.ebeAdd(var5, var19);
    double[] var50 = org.apache.commons.math3.util.MathArrays.copyOf(var19, 0);
    org.apache.commons.math3.util.MathArrays.OrderDirection var51 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var53 = org.apache.commons.math3.util.MathArrays.isMonotonic(var50, var51, false);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);

  }

  public void test44() {}
//   public void test44() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextT(10001.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var6 = var1.nextBinomial(10, (-0.18999442618139734d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.06332435248741297d);
// 
//   }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }


    double[] var2 = new double[] { 100.0d, (-1.0d)};
    double[] var5 = new double[] { 100.0d, 1.0d};
    boolean var6 = org.apache.commons.math3.util.MathArrays.equals(var2, var5);
    double[] var9 = new double[] { 100.0d, (-1.0d)};
    double[] var12 = new double[] { 100.0d, 1.0d};
    boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var9, var12);
    double[] var16 = new double[] { 100.0d, (-1.0d)};
    double[] var19 = new double[] { 100.0d, 1.0d};
    boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var16, var19);
    double[] var23 = new double[] { 100.0d, (-1.0d)};
    double[] var26 = new double[] { 100.0d, 1.0d};
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var23, var26);
    double var28 = org.apache.commons.math3.util.MathArrays.distance(var19, var23);
    double[] var31 = new double[] { 100.0d, (-1.0d)};
    double[] var34 = new double[] { 100.0d, 1.0d};
    boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var31, var34);
    double[] var38 = new double[] { 100.0d, (-1.0d)};
    double[] var41 = new double[] { 100.0d, 1.0d};
    boolean var42 = org.apache.commons.math3.util.MathArrays.equals(var38, var41);
    double var43 = org.apache.commons.math3.util.MathArrays.distance(var34, var38);
    double var44 = org.apache.commons.math3.util.MathArrays.linearCombination(var19, var34);
    boolean var45 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var9, var19);
    double[] var47 = org.apache.commons.math3.util.MathArrays.normalizeArray(var19, (-1.682916631768903d));
    double[] var48 = org.apache.commons.math3.util.MathArrays.ebeAdd(var5, var19);
    double[] var50 = new double[] { 10.0d};
    double var51 = org.apache.commons.math3.util.MathArrays.safeNorm(var50);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var52 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var5, var50);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 10.0d);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextZipf(100, 2.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var2.nextUniform(1.0d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(-1.682916631768903d));

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(10, (-1));

  }

  public void test49() {}
//   public void test49() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }
// 
// 
//     double[] var2 = new double[] { 100.0d, (-1.0d)};
//     double[] var5 = new double[] { 100.0d, 1.0d};
//     boolean var6 = org.apache.commons.math3.util.MathArrays.equals(var2, var5);
//     double[] var9 = new double[] { 100.0d, (-1.0d)};
//     double[] var12 = new double[] { 100.0d, 1.0d};
//     boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var9, var12);
//     double var14 = org.apache.commons.math3.util.MathArrays.distance(var5, var9);
//     double[] var17 = new double[] { 100.0d, (-1.0d)};
//     double[] var20 = new double[] { 100.0d, 1.0d};
//     boolean var21 = org.apache.commons.math3.util.MathArrays.equals(var17, var20);
//     double[] var22 = org.apache.commons.math3.util.MathArrays.ebeDivide(var9, var17);
//     double[] var23 = null;
//     double[] var26 = new double[] { 100.0d, (-1.0d)};
//     double[] var29 = new double[] { 100.0d, 1.0d};
//     boolean var30 = org.apache.commons.math3.util.MathArrays.equals(var26, var29);
//     double[] var33 = new double[] { 100.0d, (-1.0d)};
//     double[] var36 = new double[] { 100.0d, 1.0d};
//     boolean var37 = org.apache.commons.math3.util.MathArrays.equals(var33, var36);
//     double var38 = org.apache.commons.math3.util.MathArrays.distance(var29, var33);
//     double[] var41 = new double[] { 100.0d, (-1.0d)};
//     double[] var44 = new double[] { 100.0d, 1.0d};
//     boolean var45 = org.apache.commons.math3.util.MathArrays.equals(var41, var44);
//     double[] var48 = new double[] { 100.0d, (-1.0d)};
//     double[] var51 = new double[] { 100.0d, 1.0d};
//     boolean var52 = org.apache.commons.math3.util.MathArrays.equals(var48, var51);
//     double var53 = org.apache.commons.math3.util.MathArrays.distance(var44, var48);
//     double var54 = org.apache.commons.math3.util.MathArrays.linearCombination(var29, var44);
//     boolean var55 = org.apache.commons.math3.util.MathArrays.equals(var23, var29);
//     double var56 = org.apache.commons.math3.util.MathArrays.linearCombination(var17, var23);
// 
//   }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextGaussian(0.40877566087838346d, 1.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var2.nextWeibull(8.418185040882479d, (-1.0d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.15328243612779968d);

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(4);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }


    int[] var1 = new int[] { (-1)};
    int[] var2 = org.apache.commons.math3.util.MathArrays.copyOf(var1);
    int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var3, (-1));
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(10001.0d, (-1.682916631768903d), 8.609350869964992d, (-0.18999442618139734d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-16832.484962999133d));

  }

  public void test54() {}
//   public void test54() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1.0d, (java.lang.Number)10, true);
//     java.lang.Number var5 = var4.getMax();
//     java.lang.String var6 = var4.toString();
// 
//   }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var5 = var2.nextPascal(0, 100.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    double var2 = var1.nextDouble();
    double[] var5 = new double[] { 100.0d, (-1.0d)};
    double[] var8 = new double[] { 100.0d, 1.0d};
    boolean var9 = org.apache.commons.math3.util.MathArrays.equals(var5, var8);
    double[] var12 = new double[] { 100.0d, (-1.0d)};
    double[] var15 = new double[] { 100.0d, 1.0d};
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var12, var15);
    double[] var19 = new double[] { 100.0d, (-1.0d)};
    double[] var22 = new double[] { 100.0d, 1.0d};
    boolean var23 = org.apache.commons.math3.util.MathArrays.equals(var19, var22);
    double[] var26 = new double[] { 100.0d, (-1.0d)};
    double[] var29 = new double[] { 100.0d, 1.0d};
    boolean var30 = org.apache.commons.math3.util.MathArrays.equals(var26, var29);
    double var31 = org.apache.commons.math3.util.MathArrays.distance(var22, var26);
    double[] var34 = new double[] { 100.0d, (-1.0d)};
    double[] var37 = new double[] { 100.0d, 1.0d};
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var34, var37);
    double[] var41 = new double[] { 100.0d, (-1.0d)};
    double[] var44 = new double[] { 100.0d, 1.0d};
    boolean var45 = org.apache.commons.math3.util.MathArrays.equals(var41, var44);
    double var46 = org.apache.commons.math3.util.MathArrays.distance(var37, var41);
    double var47 = org.apache.commons.math3.util.MathArrays.linearCombination(var22, var37);
    boolean var48 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var12, var22);
    double[] var50 = org.apache.commons.math3.util.MathArrays.normalizeArray(var22, (-1.682916631768903d));
    double[] var51 = org.apache.commons.math3.util.MathArrays.ebeAdd(var8, var22);
    double[] var53 = org.apache.commons.math3.util.MathArrays.copyOf(var22, 0);
    double[] var55 = new double[] { 0.0d};
    org.apache.commons.math3.util.MathArrays.OrderDirection var56 = null;
    boolean var58 = org.apache.commons.math3.util.MathArrays.isMonotonic(var55, var56, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.DiscreteRealDistribution var59 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var22, var55);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.40877566087838346d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == true);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6L);

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var4 = var1.nextBinomial(10, (-1.682916631768903d));
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }

  }

  public void test59() {}
//   public void test59() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     java.lang.String var5 = var2.nextSecureHexString(30);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var8 = var2.nextPermutation(0, 30);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + "d00ed9b576ab0ebd715e538aa9425a"+ "'", var5.equals("d00ed9b576ab0ebd715e538aa9425a"));
// 
//   }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)30, (java.lang.Number)100L, true);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }


    double[] var2 = new double[] { 100.0d, (-1.0d)};
    double[] var5 = new double[] { 100.0d, 1.0d};
    boolean var6 = org.apache.commons.math3.util.MathArrays.equals(var2, var5);
    double[] var9 = new double[] { 100.0d, (-1.0d)};
    double[] var12 = new double[] { 100.0d, 1.0d};
    boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var9, var12);
    double var14 = org.apache.commons.math3.util.MathArrays.distance(var5, var9);
    double[] var17 = new double[] { 100.0d, (-1.0d)};
    double[] var20 = new double[] { 100.0d, 1.0d};
    boolean var21 = org.apache.commons.math3.util.MathArrays.equals(var17, var20);
    double[] var22 = org.apache.commons.math3.util.MathArrays.ebeDivide(var9, var17);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var9);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextZipf(100, 2.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var2.nextWeibull((-1.0d), 13.226435756113098d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double[] var6 = new double[] { 1.0d, 100.0d, (-1.0d)};
    double[] var8 = new double[] { 10.0d};
    double var9 = org.apache.commons.math3.util.MathArrays.safeNorm(var8);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.DiscreteRealDistribution var10 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var6, var8);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 10.0d);

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var4 = var1.nextPascal(86, 13.226435756113098d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(4, 86);

  }

  public void test66() {}
//   public void test66() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextGaussian(10.0d, 2.0d);
//     int var7 = var1.nextInt(0, 1);
//     var1.reSeed(0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var12 = var1.nextLong(6L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 7.581241729592612d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
// 
//   }

  public void test67() {}
//   public void test67() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }
// 
// 
//     double[] var2 = new double[] { 100.0d, (-1.0d)};
//     double[] var5 = new double[] { 100.0d, 1.0d};
//     boolean var6 = org.apache.commons.math3.util.MathArrays.equals(var2, var5);
//     double[] var9 = new double[] { 100.0d, (-1.0d)};
//     double[] var12 = new double[] { 100.0d, 1.0d};
//     boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var9, var12);
//     double[] var16 = new double[] { 100.0d, (-1.0d)};
//     double[] var19 = new double[] { 100.0d, 1.0d};
//     boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var16, var19);
//     double var21 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
//     double[] var24 = new double[] { 100.0d, (-1.0d)};
//     double[] var27 = new double[] { 100.0d, 1.0d};
//     boolean var28 = org.apache.commons.math3.util.MathArrays.equals(var24, var27);
//     double[] var31 = new double[] { 100.0d, (-1.0d)};
//     double[] var34 = new double[] { 100.0d, 1.0d};
//     boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var31, var34);
//     double var36 = org.apache.commons.math3.util.MathArrays.distance(var27, var31);
//     double var37 = org.apache.commons.math3.util.MathArrays.linearCombination(var12, var27);
//     boolean var38 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var2, var12);
//     double[] var40 = org.apache.commons.math3.util.MathArrays.normalizeArray(var12, (-1.682916631768903d));
//     double[] var43 = new double[] { 100.0d, (-1.0d)};
//     double[] var46 = new double[] { 100.0d, 1.0d};
//     boolean var47 = org.apache.commons.math3.util.MathArrays.equals(var43, var46);
//     double[] var50 = new double[] { 100.0d, (-1.0d)};
//     double[] var53 = new double[] { 100.0d, 1.0d};
//     boolean var54 = org.apache.commons.math3.util.MathArrays.equals(var50, var53);
//     double var55 = org.apache.commons.math3.util.MathArrays.distance(var46, var50);
//     double[] var58 = new double[] { 100.0d, (-1.0d)};
//     double[] var61 = new double[] { 100.0d, 1.0d};
//     boolean var62 = org.apache.commons.math3.util.MathArrays.equals(var58, var61);
//     double[] var65 = new double[] { 100.0d, (-1.0d)};
//     double[] var68 = new double[] { 100.0d, 1.0d};
//     boolean var69 = org.apache.commons.math3.util.MathArrays.equals(var65, var68);
//     double var70 = org.apache.commons.math3.util.MathArrays.distance(var61, var65);
//     double var71 = org.apache.commons.math3.util.MathArrays.linearCombination(var46, var61);
//     double[] var72 = org.apache.commons.math3.util.MathArrays.ebeAdd(var40, var46);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var73 = null;
//     boolean var75 = org.apache.commons.math3.util.MathArrays.isMonotonic(var46, var73, true);
// 
//   }

  public void test68() {}
//   public void test68() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     java.lang.String var5 = var2.nextSecureHexString(30);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var8 = var2.nextBeta(0.0d, (-0.14642764190854016d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + "95a53425abc0acac0e488be6fd457e"+ "'", var5.equals("95a53425abc0acac0e488be6fd457e"));
// 
//   }

  public void test69() {}
//   public void test69() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     var1.setSeed(10L);
//     int var5 = var1.nextInt(10);
//     org.apache.commons.math3.random.RandomDataImpl var6 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     java.util.List var7 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var8 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var7);
// 
//   }

  public void test70() {}
//   public void test70() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextGaussian(0.0d, 2.0d);
//     var1.reSeedSecure(0L);
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var9 = var1.nextPoisson(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-0.5675707936712816d));
// 
//   }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }


    double[] var0 = null;
    double[] var3 = new double[] { 100.0d, (-1.0d)};
    double[] var6 = new double[] { 100.0d, 1.0d};
    boolean var7 = org.apache.commons.math3.util.MathArrays.equals(var3, var6);
    double[] var10 = new double[] { 100.0d, (-1.0d)};
    double[] var13 = new double[] { 100.0d, 1.0d};
    boolean var14 = org.apache.commons.math3.util.MathArrays.equals(var10, var13);
    double[] var17 = new double[] { 100.0d, (-1.0d)};
    double[] var20 = new double[] { 100.0d, 1.0d};
    boolean var21 = org.apache.commons.math3.util.MathArrays.equals(var17, var20);
    double[] var24 = new double[] { 100.0d, (-1.0d)};
    double[] var27 = new double[] { 100.0d, 1.0d};
    boolean var28 = org.apache.commons.math3.util.MathArrays.equals(var24, var27);
    double var29 = org.apache.commons.math3.util.MathArrays.distance(var20, var24);
    double[] var32 = new double[] { 100.0d, (-1.0d)};
    double[] var35 = new double[] { 100.0d, 1.0d};
    boolean var36 = org.apache.commons.math3.util.MathArrays.equals(var32, var35);
    double[] var39 = new double[] { 100.0d, (-1.0d)};
    double[] var42 = new double[] { 100.0d, 1.0d};
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var39, var42);
    double var44 = org.apache.commons.math3.util.MathArrays.distance(var35, var39);
    double var45 = org.apache.commons.math3.util.MathArrays.linearCombination(var20, var35);
    boolean var46 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var20);
    double[] var48 = org.apache.commons.math3.util.MathArrays.normalizeArray(var20, (-1.682916631768903d));
    double[] var49 = org.apache.commons.math3.util.MathArrays.ebeAdd(var6, var20);
    double[] var51 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 0);
    double[][] var52 = new double[][] { var20};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.sortInPlace(var0, var52);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);

  }

  public void test72() {}
//   public void test72() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextGaussian(10.0d, 2.0d);
//     int var7 = var1.nextInt(0, 1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var1.nextGamma(10001.0d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 11.345404320891916d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
// 
//   }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(0.0d, (-10101.0d), 13.226435756113098d, 0.15328243612779968d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.027380293984852d);

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }


    double[] var2 = new double[] { 100.0d, (-1.0d)};
    double[] var5 = new double[] { 100.0d, 1.0d};
    boolean var6 = org.apache.commons.math3.util.MathArrays.equals(var2, var5);
    double[] var9 = new double[] { 100.0d, (-1.0d)};
    double[] var12 = new double[] { 100.0d, 1.0d};
    boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var9, var12);
    double var14 = org.apache.commons.math3.util.MathArrays.distance(var5, var9);
    double[] var17 = new double[] { 100.0d, (-1.0d)};
    double[] var20 = new double[] { 100.0d, 1.0d};
    boolean var21 = org.apache.commons.math3.util.MathArrays.equals(var17, var20);
    double[] var24 = new double[] { 100.0d, (-1.0d)};
    double[] var27 = new double[] { 100.0d, 1.0d};
    boolean var28 = org.apache.commons.math3.util.MathArrays.equals(var24, var27);
    double var29 = org.apache.commons.math3.util.MathArrays.distance(var20, var24);
    double var30 = org.apache.commons.math3.util.MathArrays.linearCombination(var5, var20);
    double[] var33 = new double[] { 100.0d, (-1.0d)};
    double[] var36 = new double[] { 100.0d, 1.0d};
    boolean var37 = org.apache.commons.math3.util.MathArrays.equals(var33, var36);
    double[] var40 = new double[] { 100.0d, (-1.0d)};
    double[] var43 = new double[] { 100.0d, 1.0d};
    boolean var44 = org.apache.commons.math3.util.MathArrays.equals(var40, var43);
    double var45 = org.apache.commons.math3.util.MathArrays.distance(var36, var40);
    double var46 = org.apache.commons.math3.util.MathArrays.distanceInf(var5, var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0.0d);

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)86, (java.lang.Number)1L, true);
    boolean var4 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var5 = var2.nextSecureInt(100, 1);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test77() {}
//   public void test77() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextGaussian(10.0d, 2.0d);
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var7 = var1.nextSecureHexString(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 10.435959879187052d);
// 
//   }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var3 = var1.nextSecureHexString(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test79() {}
//   public void test79() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextGaussian(0.0d, 2.0d);
//     var1.reSeed(0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var1.nextUniform(0.0d, (-0.14642764190854016d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 3.1739685209368345d);
// 
//   }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }


    double[] var2 = new double[] { 100.0d, (-1.0d)};
    double[] var5 = new double[] { 100.0d, 1.0d};
    boolean var6 = org.apache.commons.math3.util.MathArrays.equals(var2, var5);
    double[] var9 = new double[] { 100.0d, (-1.0d)};
    double[] var12 = new double[] { 100.0d, 1.0d};
    boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var9, var12);
    double[] var16 = new double[] { 100.0d, (-1.0d)};
    double[] var19 = new double[] { 100.0d, 1.0d};
    boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var16, var19);
    double var21 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double[] var24 = new double[] { 100.0d, (-1.0d)};
    double[] var27 = new double[] { 100.0d, 1.0d};
    boolean var28 = org.apache.commons.math3.util.MathArrays.equals(var24, var27);
    double[] var31 = new double[] { 100.0d, (-1.0d)};
    double[] var34 = new double[] { 100.0d, 1.0d};
    boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var31, var34);
    double var36 = org.apache.commons.math3.util.MathArrays.distance(var27, var31);
    double var37 = org.apache.commons.math3.util.MathArrays.linearCombination(var12, var27);
    boolean var38 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var2, var12);
    double[] var40 = org.apache.commons.math3.util.MathArrays.normalizeArray(var12, (-1.682916631768903d));
    double[] var43 = new double[] { 100.0d, (-1.0d)};
    double[] var46 = new double[] { 100.0d, 1.0d};
    boolean var47 = org.apache.commons.math3.util.MathArrays.equals(var43, var46);
    double[] var50 = new double[] { 100.0d, (-1.0d)};
    double[] var53 = new double[] { 100.0d, 1.0d};
    boolean var54 = org.apache.commons.math3.util.MathArrays.equals(var50, var53);
    double var55 = org.apache.commons.math3.util.MathArrays.distance(var46, var50);
    double[] var58 = new double[] { 100.0d, (-1.0d)};
    double[] var61 = new double[] { 100.0d, 1.0d};
    boolean var62 = org.apache.commons.math3.util.MathArrays.equals(var58, var61);
    double[] var65 = new double[] { 100.0d, (-1.0d)};
    double[] var68 = new double[] { 100.0d, 1.0d};
    boolean var69 = org.apache.commons.math3.util.MathArrays.equals(var65, var68);
    double var70 = org.apache.commons.math3.util.MathArrays.distance(var61, var65);
    double var71 = org.apache.commons.math3.util.MathArrays.linearCombination(var46, var61);
    double[] var72 = org.apache.commons.math3.util.MathArrays.ebeAdd(var40, var46);
    double[] var74 = new double[] { 10.0d};
    double var75 = org.apache.commons.math3.util.MathArrays.safeNorm(var74);
    org.apache.commons.math3.util.MathArrays.OrderDirection var76 = null;
    boolean var78 = org.apache.commons.math3.util.MathArrays.isMonotonic(var74, var76, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var79 = org.apache.commons.math3.util.MathArrays.linearCombination(var46, var74);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == true);

  }

  public void test81() {}
//   public void test81() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var3 = var1.nextDouble();
//     var1.setSeed(10L);
//     java.util.List var6 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var7 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var6);
// 
//   }

  public void test82() {}
//   public void test82() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextGaussian(10.0d, 2.0d);
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var8 = var1.nextLong((-1L), (-1L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 12.772591413882637d);
// 
//   }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    var1.setSeed(10);
    int var5 = var1.nextInt(86);
    var1.setSeed(30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 30);

  }

  public void test84() {}
//   public void test84() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }
// 
// 
//     double[] var0 = null;
//     double[] var1 = null;
//     double[] var4 = new double[] { 100.0d, (-1.0d)};
//     double[] var7 = new double[] { 100.0d, 1.0d};
//     boolean var8 = org.apache.commons.math3.util.MathArrays.equals(var4, var7);
//     double[] var11 = new double[] { 100.0d, (-1.0d)};
//     double[] var14 = new double[] { 100.0d, 1.0d};
//     boolean var15 = org.apache.commons.math3.util.MathArrays.equals(var11, var14);
//     double var16 = org.apache.commons.math3.util.MathArrays.distance(var7, var11);
//     double[] var19 = new double[] { 100.0d, (-1.0d)};
//     double[] var22 = new double[] { 100.0d, 1.0d};
//     boolean var23 = org.apache.commons.math3.util.MathArrays.equals(var19, var22);
//     double[] var26 = new double[] { 100.0d, (-1.0d)};
//     double[] var29 = new double[] { 100.0d, 1.0d};
//     boolean var30 = org.apache.commons.math3.util.MathArrays.equals(var26, var29);
//     double var31 = org.apache.commons.math3.util.MathArrays.distance(var22, var26);
//     double var32 = org.apache.commons.math3.util.MathArrays.linearCombination(var7, var22);
//     boolean var33 = org.apache.commons.math3.util.MathArrays.equals(var1, var7);
//     double var34 = org.apache.commons.math3.util.MathArrays.linearCombination(var0, var7);
// 
//   }

  public void test85() {}
//   public void test85() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var5 = var2.nextSecureLong(0L, 1L);
//     var2.reSeed(6L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var2.nextHypergeometric(0, 30, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0L);
// 
//   }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(-1L));

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);

  }

  public void test88() {}
//   public void test88() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var5 = var2.nextSecureLong(0L, 1L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var8 = var2.nextBinomial(52, 100.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0L);
// 
//   }

  public void test89() {}
//   public void test89() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)86, (java.lang.Number)1L, true);
//     java.lang.Throwable[] var5 = var4.getSuppressed();
//     org.apache.commons.math3.exception.NullArgumentException var6 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var5);
//     org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var6);
// 
//   }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)2.027380293984852d, (java.lang.Number)1, false);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }


    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)2.3590437156692077d, (java.lang.Number)2.6669397224844205d, 1, var3, false);

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var6 = var2.nextUniform(2.0d, (-1.0d), true);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.lang.Object[] var4 = new java.lang.Object[] { 10.0d};
    org.apache.commons.math3.exception.NullArgumentException var5 = new org.apache.commons.math3.exception.NullArgumentException(var2, var4);
    org.apache.commons.math3.exception.NotFiniteNumberException var6 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)100.0d, var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test94() {}
//   public void test94() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextGaussian(0.0d, 2.0d);
//     var1.reSeedSecure(0L);
//     var1.reSeedSecure();
//     double var10 = var1.nextGaussian(2.0d, 2.0d);
//     var1.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("org.apache.commons.math3.exception.NonMonotonicSequenceException: points 0 and 1 are not decreasing (-1 < 1)", "hi!");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 2.1883123364147243d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.895950642832488d);
// 
//   }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var4 = var1.nextSecureInt(52, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test96() {}
//   public void test96() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     java.util.Collection var3 = null;
//     java.lang.Object[] var5 = var2.nextSample(var3, 10);
// 
//   }

  public void test97() {}
//   public void test97() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     long var6 = var2.nextLong((-1L), 10L);
//     var2.reSeedSecure(6L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var2.nextPascal(10, 10001.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 5L);
// 
//   }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }


    long[] var3 = new long[] { 1L, (-1L), 0L};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkNonNegative(var3);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test99() {}
//   public void test99() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     java.lang.String var5 = var2.nextSecureHexString(30);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var8 = var2.nextInt(52, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + "35ecee285700e2ad177118ff6a6ddc"+ "'", var5.equals("35ecee285700e2ad177118ff6a6ddc"));
// 
//   }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var4 = var1.nextSecureInt(100, 1);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1.0d, (java.lang.Number)10, true);
    java.lang.Number var5 = var4.getMax();
    java.lang.Number var6 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 10+ "'", var5.equals(10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 10+ "'", var6.equals(10));

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var4 = var1.nextPascal(30, 2.6669397224844205d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }

  }

  public void test103() {}
//   public void test103() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextGaussian(0.0d, 2.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var7 = var1.nextBinomial(1, (-1.056554310492439d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.35434649603081647d);
// 
//   }

  public void test104() {}
//   public void test104() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextGaussian(0.0d, 2.0d);
//     double var6 = var1.nextT(1.5399696003263283d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-2.1148810308778625d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.6115651382182169d);
// 
//   }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(13.90833488952869d, 9854048.12570597d, 8.418185040882479d, (-0.7314779623383547d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.3705339519213432E8d);

  }

  public void test106() {}
//   public void test106() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextGaussian(0.0d, 2.0d);
//     var1.reSeedSecure(0L);
//     double var9 = var1.nextWeibull(2.0d, 9854048.12570597d);
//     org.apache.commons.math3.distribution.IntegerDistribution var10 = null;
//     int var11 = var1.nextInversionDeviate(var10);
// 
//   }

  public void test107() {}
//   public void test107() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     java.lang.Object[] var4 = new java.lang.Object[] { 10.0d};
//     org.apache.commons.math3.exception.NullArgumentException var5 = new org.apache.commons.math3.exception.NullArgumentException(var2, var4);
//     org.apache.commons.math3.exception.MathIllegalStateException var6 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, var4);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var7 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var4);
//     java.lang.String var8 = var7.toString();
// 
//   }

  public void test108() {}
//   public void test108() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }
// 
// 
//     int[] var0 = null;
//     int[] var2 = new int[] { (-1)};
//     int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var2);
//     int[] var5 = new int[] { (-1)};
//     int[] var6 = org.apache.commons.math3.util.MathArrays.copyOf(var5);
//     int var7 = org.apache.commons.math3.util.MathArrays.distanceInf(var3, var5);
//     double var8 = org.apache.commons.math3.util.MathArrays.distance(var0, var3);
// 
//   }

  public void test109() {}
//   public void test109() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextGaussian(10.0d, 2.0d);
//     int var7 = var1.nextInt(0, 1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var10 = var1.nextLong(0L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 10.758085422921512d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
// 
//   }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(byte)10, (java.lang.Number)10L, (java.lang.Number)1.5399696003263283d);
    java.lang.Number var4 = var3.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 1.5399696003263283d+ "'", var4.equals(1.5399696003263283d));

  }

  public void test111() {}
//   public void test111() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextGaussian(10.0d, 2.0d);
//     int var7 = var1.nextInt(0, 1);
//     var1.reSeed(0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var1.nextGamma(0.0d, 2.3590437156692077d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 9.093775409611284d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
// 
//   }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }


    int[] var1 = new int[] { (-1)};
    int[] var2 = org.apache.commons.math3.util.MathArrays.copyOf(var1);
    int[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var6 = org.apache.commons.math3.util.MathArrays.copyOf(var4, (-1));
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.8761829645236354d, var1, false);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    var1.setSeed(10L);
    int var5 = var1.nextInt(10);
    double var6 = var1.nextDouble();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2323975705328034d);

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }


    double[] var2 = new double[] { 100.0d, (-1.0d)};
    double[] var5 = new double[] { 100.0d, 1.0d};
    boolean var6 = org.apache.commons.math3.util.MathArrays.equals(var2, var5);
    double[] var9 = new double[] { 100.0d, (-1.0d)};
    double[] var12 = new double[] { 100.0d, 1.0d};
    boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var9, var12);
    double var14 = org.apache.commons.math3.util.MathArrays.distance(var5, var9);
    double[] var17 = new double[] { 100.0d, (-1.0d)};
    double[] var20 = new double[] { 100.0d, 1.0d};
    boolean var21 = org.apache.commons.math3.util.MathArrays.equals(var17, var20);
    double[] var24 = new double[] { 100.0d, (-1.0d)};
    double[] var27 = new double[] { 100.0d, 1.0d};
    boolean var28 = org.apache.commons.math3.util.MathArrays.equals(var24, var27);
    double var29 = org.apache.commons.math3.util.MathArrays.distance(var20, var24);
    double var30 = org.apache.commons.math3.util.MathArrays.linearCombination(var5, var20);
    double[] var33 = new double[] { 100.0d, (-1.0d)};
    double[] var36 = new double[] { 100.0d, 1.0d};
    boolean var37 = org.apache.commons.math3.util.MathArrays.equals(var33, var36);
    double[] var40 = new double[] { 100.0d, (-1.0d)};
    double[] var43 = new double[] { 100.0d, 1.0d};
    boolean var44 = org.apache.commons.math3.util.MathArrays.equals(var40, var43);
    double var45 = org.apache.commons.math3.util.MathArrays.distance(var36, var40);
    double[] var48 = new double[] { 100.0d, (-1.0d)};
    double[] var51 = new double[] { 100.0d, 1.0d};
    boolean var52 = org.apache.commons.math3.util.MathArrays.equals(var48, var51);
    double[] var55 = new double[] { 100.0d, (-1.0d)};
    double[] var58 = new double[] { 100.0d, 1.0d};
    boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var55, var58);
    double var60 = org.apache.commons.math3.util.MathArrays.distance(var51, var55);
    double[] var63 = new double[] { 100.0d, (-1.0d)};
    double[] var66 = new double[] { 100.0d, 1.0d};
    boolean var67 = org.apache.commons.math3.util.MathArrays.equals(var63, var66);
    double[] var70 = new double[] { 100.0d, (-1.0d)};
    double[] var73 = new double[] { 100.0d, 1.0d};
    boolean var74 = org.apache.commons.math3.util.MathArrays.equals(var70, var73);
    double var75 = org.apache.commons.math3.util.MathArrays.distance(var66, var70);
    double var76 = org.apache.commons.math3.util.MathArrays.linearCombination(var51, var66);
    double[][] var77 = new double[][] { var51};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var40, var77);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.DiscreteRealDistribution var79 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var5, var40);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);

  }

  public void test116() {}
//   public void test116() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     java.util.Collection var4 = null;
//     java.lang.Object[] var6 = var2.nextSample(var4, 2147483647);
// 
//   }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination((-0.14642764190854016d), 0.0d, 3068624.4438274824d, 2.3590437156692077d, (-0.7314779623383547d), 8.418185040882479d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 7239013.0522433d);

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }


    double[] var1 = new double[] { 10.0d};
    double var2 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    boolean var5 = org.apache.commons.math3.util.MathArrays.isMonotonic(var1, var3, false);
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
    boolean var9 = org.apache.commons.math3.util.MathArrays.checkOrder(var1, var6, false, true);
    double[] var12 = new double[] { 100.0d, (-1.0d)};
    double[] var15 = new double[] { 100.0d, 1.0d};
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var12, var15);
    double[] var19 = new double[] { 100.0d, (-1.0d)};
    double[] var22 = new double[] { 100.0d, 1.0d};
    boolean var23 = org.apache.commons.math3.util.MathArrays.equals(var19, var22);
    double[] var26 = new double[] { 100.0d, (-1.0d)};
    double[] var29 = new double[] { 100.0d, 1.0d};
    boolean var30 = org.apache.commons.math3.util.MathArrays.equals(var26, var29);
    double var31 = org.apache.commons.math3.util.MathArrays.distance(var22, var26);
    double[] var34 = new double[] { 100.0d, (-1.0d)};
    double[] var37 = new double[] { 100.0d, 1.0d};
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var34, var37);
    double[] var41 = new double[] { 100.0d, (-1.0d)};
    double[] var44 = new double[] { 100.0d, 1.0d};
    boolean var45 = org.apache.commons.math3.util.MathArrays.equals(var41, var44);
    double var46 = org.apache.commons.math3.util.MathArrays.distance(var37, var41);
    double var47 = org.apache.commons.math3.util.MathArrays.linearCombination(var22, var37);
    boolean var48 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var12, var22);
    double[] var50 = org.apache.commons.math3.util.MathArrays.normalizeArray(var22, (-1.682916631768903d));
    double[] var53 = new double[] { 100.0d, (-1.0d)};
    double[] var56 = new double[] { 100.0d, 1.0d};
    boolean var57 = org.apache.commons.math3.util.MathArrays.equals(var53, var56);
    double[] var60 = new double[] { 100.0d, (-1.0d)};
    double[] var63 = new double[] { 100.0d, 1.0d};
    boolean var64 = org.apache.commons.math3.util.MathArrays.equals(var60, var63);
    double var65 = org.apache.commons.math3.util.MathArrays.distance(var56, var60);
    double[] var68 = new double[] { 100.0d, (-1.0d)};
    double[] var71 = new double[] { 100.0d, 1.0d};
    boolean var72 = org.apache.commons.math3.util.MathArrays.equals(var68, var71);
    double[] var73 = org.apache.commons.math3.util.MathArrays.ebeDivide(var60, var68);
    double[] var74 = org.apache.commons.math3.util.MathArrays.ebeDivide(var22, var68);
    boolean var75 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var1, var68);
    double var76 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == 10.0d);

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    var1.setSeed(10);
    int[] var4 = null;
    var1.setSeed(var4);
    int[] var6 = null;
    var1.setSeed(var6);

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeedSecure(10L);
    double var7 = var2.nextUniform(11.684643263460426d, 7506849.916132723d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var2.nextGaussian(1.5399696003263283d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 3068624.4438274824d);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }


    int[] var0 = null;
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var2.nextWeibull((-1.212080947441934d), 2.027380293984852d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(byte)(-1), var2, false);

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }


    double[] var2 = new double[] { 100.0d, (-1.0d)};
    double[] var5 = new double[] { 100.0d, 1.0d};
    boolean var6 = org.apache.commons.math3.util.MathArrays.equals(var2, var5);
    double[] var9 = new double[] { 100.0d, (-1.0d)};
    double[] var12 = new double[] { 100.0d, 1.0d};
    boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var9, var12);
    double[] var16 = new double[] { 100.0d, (-1.0d)};
    double[] var19 = new double[] { 100.0d, 1.0d};
    boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var16, var19);
    double var21 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double[] var24 = new double[] { 100.0d, (-1.0d)};
    double[] var27 = new double[] { 100.0d, 1.0d};
    boolean var28 = org.apache.commons.math3.util.MathArrays.equals(var24, var27);
    double[] var31 = new double[] { 100.0d, (-1.0d)};
    double[] var34 = new double[] { 100.0d, 1.0d};
    boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var31, var34);
    double var36 = org.apache.commons.math3.util.MathArrays.distance(var27, var31);
    double var37 = org.apache.commons.math3.util.MathArrays.linearCombination(var12, var27);
    boolean var38 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var2, var12);
    double[] var40 = org.apache.commons.math3.util.MathArrays.normalizeArray(var12, (-1.682916631768903d));
    double[] var43 = new double[] { 100.0d, (-1.0d)};
    double[] var46 = new double[] { 100.0d, 1.0d};
    boolean var47 = org.apache.commons.math3.util.MathArrays.equals(var43, var46);
    double[] var50 = new double[] { 100.0d, (-1.0d)};
    double[] var53 = new double[] { 100.0d, 1.0d};
    boolean var54 = org.apache.commons.math3.util.MathArrays.equals(var50, var53);
    double var55 = org.apache.commons.math3.util.MathArrays.distance(var46, var50);
    double[] var58 = new double[] { 100.0d, (-1.0d)};
    double[] var61 = new double[] { 100.0d, 1.0d};
    boolean var62 = org.apache.commons.math3.util.MathArrays.equals(var58, var61);
    double[] var63 = org.apache.commons.math3.util.MathArrays.ebeDivide(var50, var58);
    double[] var64 = org.apache.commons.math3.util.MathArrays.ebeDivide(var12, var58);
    double[] var65 = new double[] { };
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var66 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var64, var65);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-16832.484962999133d), (java.lang.Number)(byte)1, true);

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }


    long[] var3 = new long[] { (-1L), 100L, 10L};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkNonNegative(var3);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }


    double[] var1 = new double[] { 0.0d};
    double[] var4 = new double[] { 100.0d, (-1.0d)};
    double[] var7 = new double[] { 100.0d, 1.0d};
    boolean var8 = org.apache.commons.math3.util.MathArrays.equals(var4, var7);
    double[] var11 = new double[] { 100.0d, (-1.0d)};
    double[] var14 = new double[] { 100.0d, 1.0d};
    boolean var15 = org.apache.commons.math3.util.MathArrays.equals(var11, var14);
    double var16 = org.apache.commons.math3.util.MathArrays.distance(var7, var11);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var17 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var1, var11);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 2.0d);

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination((-1.682916631768903d), (-1.056554310492439d), 13.226435756113098d, (-1.6270847051012245d), 1.3705339519213432E8d, (-0.7844030186481109d), 13.90833488952869d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-1.0750511664712115E8d));

  }

  public void test128() {}
//   public void test128() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     int[] var5 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c(var5);
//     double[] var9 = new double[] { 100.0d, (-1.0d)};
//     double[] var12 = new double[] { 100.0d, 1.0d};
//     boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var9, var12);
//     double[] var16 = new double[] { 100.0d, (-1.0d)};
//     double[] var19 = new double[] { 100.0d, 1.0d};
//     boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var16, var19);
//     double[] var23 = new double[] { 100.0d, (-1.0d)};
//     double[] var26 = new double[] { 100.0d, 1.0d};
//     boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var23, var26);
//     double var28 = org.apache.commons.math3.util.MathArrays.distance(var19, var23);
//     double[] var31 = new double[] { 100.0d, (-1.0d)};
//     double[] var34 = new double[] { 100.0d, 1.0d};
//     boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var31, var34);
//     double[] var38 = new double[] { 100.0d, (-1.0d)};
//     double[] var41 = new double[] { 100.0d, 1.0d};
//     boolean var42 = org.apache.commons.math3.util.MathArrays.equals(var38, var41);
//     double var43 = org.apache.commons.math3.util.MathArrays.distance(var34, var38);
//     double var44 = org.apache.commons.math3.util.MathArrays.linearCombination(var19, var34);
//     boolean var45 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var9, var19);
//     double[] var47 = org.apache.commons.math3.util.MathArrays.normalizeArray(var19, (-1.682916631768903d));
//     double[] var50 = new double[] { 100.0d, (-1.0d)};
//     double[] var53 = new double[] { 100.0d, 1.0d};
//     boolean var54 = org.apache.commons.math3.util.MathArrays.equals(var50, var53);
//     double[] var57 = new double[] { 100.0d, (-1.0d)};
//     double[] var60 = new double[] { 100.0d, 1.0d};
//     boolean var61 = org.apache.commons.math3.util.MathArrays.equals(var57, var60);
//     double var62 = org.apache.commons.math3.util.MathArrays.distance(var53, var57);
//     double[] var65 = new double[] { 100.0d, (-1.0d)};
//     double[] var68 = new double[] { 100.0d, 1.0d};
//     boolean var69 = org.apache.commons.math3.util.MathArrays.equals(var65, var68);
//     double[] var72 = new double[] { 100.0d, (-1.0d)};
//     double[] var75 = new double[] { 100.0d, 1.0d};
//     boolean var76 = org.apache.commons.math3.util.MathArrays.equals(var72, var75);
//     double var77 = org.apache.commons.math3.util.MathArrays.distance(var68, var72);
//     double var78 = org.apache.commons.math3.util.MathArrays.linearCombination(var53, var68);
//     double[] var79 = org.apache.commons.math3.util.MathArrays.ebeAdd(var47, var53);
//     double[] var82 = new double[] { 100.0d, (-1.0d)};
//     double[] var85 = new double[] { 100.0d, 1.0d};
//     boolean var86 = org.apache.commons.math3.util.MathArrays.equals(var82, var85);
//     double[] var89 = new double[] { 100.0d, (-1.0d)};
//     double[] var92 = new double[] { 100.0d, 1.0d};
//     boolean var93 = org.apache.commons.math3.util.MathArrays.equals(var89, var92);
//     double var94 = org.apache.commons.math3.util.MathArrays.distance(var85, var89);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var95 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var6, var53, var85);
//     boolean var96 = var95.isSupportConnected();
//     var95.reseedRandomGenerator(10L);
//     double var99 = var2.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var95);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 2.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 2.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == 10001.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var62 == 2.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var69 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var72);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var75);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var76 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var77 == 2.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var78 == 10001.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var79);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var82);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var85);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var86 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var89);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var92);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var93 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var94 == 2.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var96 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var99 == 99.9999988872748d);
// 
//   }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Object[] var3 = new java.lang.Object[] { 10.0d};
    org.apache.commons.math3.exception.NullArgumentException var4 = new org.apache.commons.math3.exception.NullArgumentException(var1, var3);
    org.apache.commons.math3.exception.MathIllegalStateException var5 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var3);
    org.apache.commons.math3.exception.util.ExceptionContext var6 = var5.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test130() {}
//   public void test130() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextGaussian(0.0d, 2.0d);
//     var1.reSeed(0L);
//     java.util.Collection var7 = null;
//     java.lang.Object[] var9 = var1.nextSample(var7, 30);
// 
//   }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed((-1L));
    double var6 = var0.nextUniform(0.0d, 2.3590437156692077d, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var9 = var0.nextSecureLong(10L, 0L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.5650828929145241d);

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
    var1.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var5 = var1.nextLong((-1L), (-1L));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(1);
    int[] var3 = new int[] { (-1)};
    int[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
    int[] var6 = new int[] { (-1)};
    int[] var7 = org.apache.commons.math3.util.MathArrays.copyOf(var6);
    int[] var9 = new int[] { (-1)};
    int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var9);
    int var11 = org.apache.commons.math3.util.MathArrays.distanceInf(var7, var9);
    int var12 = org.apache.commons.math3.util.MathArrays.distanceInf(var4, var9);
    var1.setSeed(var9);
    double[] var16 = new double[] { 100.0d, (-1.0d)};
    double[] var19 = new double[] { 100.0d, 1.0d};
    boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var16, var19);
    double[] var23 = new double[] { 100.0d, (-1.0d)};
    double[] var26 = new double[] { 100.0d, 1.0d};
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var23, var26);
    double[] var30 = new double[] { 100.0d, (-1.0d)};
    double[] var33 = new double[] { 100.0d, 1.0d};
    boolean var34 = org.apache.commons.math3.util.MathArrays.equals(var30, var33);
    double var35 = org.apache.commons.math3.util.MathArrays.distance(var26, var30);
    double[] var38 = new double[] { 100.0d, (-1.0d)};
    double[] var41 = new double[] { 100.0d, 1.0d};
    boolean var42 = org.apache.commons.math3.util.MathArrays.equals(var38, var41);
    double[] var45 = new double[] { 100.0d, (-1.0d)};
    double[] var48 = new double[] { 100.0d, 1.0d};
    boolean var49 = org.apache.commons.math3.util.MathArrays.equals(var45, var48);
    double var50 = org.apache.commons.math3.util.MathArrays.distance(var41, var45);
    double var51 = org.apache.commons.math3.util.MathArrays.linearCombination(var26, var41);
    boolean var52 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var16, var26);
    double[] var54 = org.apache.commons.math3.util.MathArrays.normalizeArray(var26, (-1.682916631768903d));
    double[] var57 = new double[] { 100.0d, (-1.0d)};
    double[] var60 = new double[] { 100.0d, 1.0d};
    boolean var61 = org.apache.commons.math3.util.MathArrays.equals(var57, var60);
    double[] var64 = new double[] { 100.0d, (-1.0d)};
    double[] var67 = new double[] { 100.0d, 1.0d};
    boolean var68 = org.apache.commons.math3.util.MathArrays.equals(var64, var67);
    double var69 = org.apache.commons.math3.util.MathArrays.distance(var60, var64);
    double[] var72 = new double[] { 100.0d, (-1.0d)};
    double[] var75 = new double[] { 100.0d, 1.0d};
    boolean var76 = org.apache.commons.math3.util.MathArrays.equals(var72, var75);
    double[] var77 = org.apache.commons.math3.util.MathArrays.ebeDivide(var64, var72);
    double[] var78 = org.apache.commons.math3.util.MathArrays.ebeDivide(var26, var72);
    org.apache.commons.math3.util.Pair var79 = new org.apache.commons.math3.util.Pair((java.lang.Object)var9, (java.lang.Object)var72);
    java.lang.Object var80 = var79.getFirst();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextZipf(100, 2.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSecureAlgorithm("", "5704f866d4cba2903ba4655f9e0f11");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);

  }

  public void test135() {}
//   public void test135() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     java.lang.Object[] var3 = new java.lang.Object[] { 10.0d};
//     org.apache.commons.math3.exception.NullArgumentException var4 = new org.apache.commons.math3.exception.NullArgumentException(var1, var3);
//     org.apache.commons.math3.exception.MathIllegalStateException var5 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var3);
//     java.lang.String var6 = var5.toString();
// 
//   }

  public void test136() {}
//   public void test136() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextGaussian(10.0d, 2.0d);
//     java.util.Collection var5 = null;
//     java.lang.Object[] var7 = var1.nextSample(var5, 0);
// 
//   }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    var1.setSeed(10L);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var7 = var4.nextPermutation(1, 10);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }


    int[] var0 = null;
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var5 = var2.nextInt(1, (-1));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeedSecure(10L);
    double var7 = var2.nextUniform(11.684643263460426d, 7506849.916132723d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var2.nextF(10001.0d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 3068624.4438274824d);

  }

  public void test140() {}
//   public void test140() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     var1.setSeed(10);
//     int var5 = var1.nextInt(100);
//     java.util.List var6 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var7 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var6);
// 
//   }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination((-0.18999442618139734d), (-1.212080947441934d), 0.0d, 0.2323975705328034d, 0.40877566087838346d, (-0.6858698665320467d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-0.050078283873571376d));

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    var1.setSeed(10L);
    int var5 = var1.nextInt(10);
    org.apache.commons.math3.random.RandomDataImpl var6 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var9 = var6.nextWeibull(0.0d, 2.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 4);

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextGaussian(0.40877566087838346d, 1.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var8 = var2.nextZipf(100, (-0.7314779623383547d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.15328243612779968d);

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    double[] var5 = new double[] { 100.0d, (-1.0d)};
    double[] var8 = new double[] { 100.0d, 1.0d};
    boolean var9 = org.apache.commons.math3.util.MathArrays.equals(var5, var8);
    double[] var12 = new double[] { 100.0d, (-1.0d)};
    double[] var15 = new double[] { 100.0d, 1.0d};
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var12, var15);
    double[] var19 = new double[] { 100.0d, (-1.0d)};
    double[] var22 = new double[] { 100.0d, 1.0d};
    boolean var23 = org.apache.commons.math3.util.MathArrays.equals(var19, var22);
    double var24 = org.apache.commons.math3.util.MathArrays.distance(var15, var19);
    double[] var27 = new double[] { 100.0d, (-1.0d)};
    double[] var30 = new double[] { 100.0d, 1.0d};
    boolean var31 = org.apache.commons.math3.util.MathArrays.equals(var27, var30);
    double[] var34 = new double[] { 100.0d, (-1.0d)};
    double[] var37 = new double[] { 100.0d, 1.0d};
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var34, var37);
    double var39 = org.apache.commons.math3.util.MathArrays.distance(var30, var34);
    double var40 = org.apache.commons.math3.util.MathArrays.linearCombination(var15, var30);
    boolean var41 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var5, var15);
    double[] var43 = org.apache.commons.math3.util.MathArrays.normalizeArray(var15, (-1.682916631768903d));
    double[] var46 = new double[] { 100.0d, (-1.0d)};
    double[] var49 = new double[] { 100.0d, 1.0d};
    boolean var50 = org.apache.commons.math3.util.MathArrays.equals(var46, var49);
    double[] var53 = new double[] { 100.0d, (-1.0d)};
    double[] var56 = new double[] { 100.0d, 1.0d};
    boolean var57 = org.apache.commons.math3.util.MathArrays.equals(var53, var56);
    double var58 = org.apache.commons.math3.util.MathArrays.distance(var49, var53);
    double[] var61 = new double[] { 100.0d, (-1.0d)};
    double[] var64 = new double[] { 100.0d, 1.0d};
    boolean var65 = org.apache.commons.math3.util.MathArrays.equals(var61, var64);
    double[] var68 = new double[] { 100.0d, (-1.0d)};
    double[] var71 = new double[] { 100.0d, 1.0d};
    boolean var72 = org.apache.commons.math3.util.MathArrays.equals(var68, var71);
    double var73 = org.apache.commons.math3.util.MathArrays.distance(var64, var68);
    double var74 = org.apache.commons.math3.util.MathArrays.linearCombination(var49, var64);
    double[] var75 = org.apache.commons.math3.util.MathArrays.ebeAdd(var43, var49);
    double[] var78 = new double[] { 100.0d, (-1.0d)};
    double[] var81 = new double[] { 100.0d, 1.0d};
    boolean var82 = org.apache.commons.math3.util.MathArrays.equals(var78, var81);
    double[] var85 = new double[] { 100.0d, (-1.0d)};
    double[] var88 = new double[] { 100.0d, 1.0d};
    boolean var89 = org.apache.commons.math3.util.MathArrays.equals(var85, var88);
    double var90 = org.apache.commons.math3.util.MathArrays.distance(var81, var85);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var91 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var2, var49, var81);
    var91.reseedRandomGenerator((-1L));
    double var96 = var91.probability(0.6115651382182169d, 99.01980198019803d);
    double var98 = var91.probability(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var96 == 0.009900990099009901d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var98 == 0.0d);

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }


    int[] var0 = null;
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var2.nextUniform(2.0d, (-16832.484962999133d));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test146() {}
//   public void test146() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     java.util.List var2 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var3 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var2);
// 
//   }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var3 = var0.nextF((-0.6858698665320467d), 1.2694665049707192d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test148() {}
//   public void test148() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextGaussian(10.0d, 2.0d);
//     int var7 = var1.nextInt(0, 1);
//     org.apache.commons.math3.distribution.IntegerDistribution var8 = null;
//     int var9 = var1.nextInversionDeviate(var8);
// 
//   }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }


    double[] var1 = new double[] { 10.0d};
    double var2 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    boolean var5 = org.apache.commons.math3.util.MathArrays.isMonotonic(var1, var3, false);
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
    boolean var9 = org.apache.commons.math3.util.MathArrays.checkOrder(var1, var6, true, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    double[] var5 = new double[] { 100.0d, (-1.0d)};
    double[] var8 = new double[] { 100.0d, 1.0d};
    boolean var9 = org.apache.commons.math3.util.MathArrays.equals(var5, var8);
    double[] var12 = new double[] { 100.0d, (-1.0d)};
    double[] var15 = new double[] { 100.0d, 1.0d};
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var12, var15);
    double[] var19 = new double[] { 100.0d, (-1.0d)};
    double[] var22 = new double[] { 100.0d, 1.0d};
    boolean var23 = org.apache.commons.math3.util.MathArrays.equals(var19, var22);
    double var24 = org.apache.commons.math3.util.MathArrays.distance(var15, var19);
    double[] var27 = new double[] { 100.0d, (-1.0d)};
    double[] var30 = new double[] { 100.0d, 1.0d};
    boolean var31 = org.apache.commons.math3.util.MathArrays.equals(var27, var30);
    double[] var34 = new double[] { 100.0d, (-1.0d)};
    double[] var37 = new double[] { 100.0d, 1.0d};
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var34, var37);
    double var39 = org.apache.commons.math3.util.MathArrays.distance(var30, var34);
    double var40 = org.apache.commons.math3.util.MathArrays.linearCombination(var15, var30);
    boolean var41 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var5, var15);
    double[] var43 = org.apache.commons.math3.util.MathArrays.normalizeArray(var15, (-1.682916631768903d));
    double[] var46 = new double[] { 100.0d, (-1.0d)};
    double[] var49 = new double[] { 100.0d, 1.0d};
    boolean var50 = org.apache.commons.math3.util.MathArrays.equals(var46, var49);
    double[] var53 = new double[] { 100.0d, (-1.0d)};
    double[] var56 = new double[] { 100.0d, 1.0d};
    boolean var57 = org.apache.commons.math3.util.MathArrays.equals(var53, var56);
    double var58 = org.apache.commons.math3.util.MathArrays.distance(var49, var53);
    double[] var61 = new double[] { 100.0d, (-1.0d)};
    double[] var64 = new double[] { 100.0d, 1.0d};
    boolean var65 = org.apache.commons.math3.util.MathArrays.equals(var61, var64);
    double[] var68 = new double[] { 100.0d, (-1.0d)};
    double[] var71 = new double[] { 100.0d, 1.0d};
    boolean var72 = org.apache.commons.math3.util.MathArrays.equals(var68, var71);
    double var73 = org.apache.commons.math3.util.MathArrays.distance(var64, var68);
    double var74 = org.apache.commons.math3.util.MathArrays.linearCombination(var49, var64);
    double[] var75 = org.apache.commons.math3.util.MathArrays.ebeAdd(var43, var49);
    double[] var78 = new double[] { 100.0d, (-1.0d)};
    double[] var81 = new double[] { 100.0d, 1.0d};
    boolean var82 = org.apache.commons.math3.util.MathArrays.equals(var78, var81);
    double[] var85 = new double[] { 100.0d, (-1.0d)};
    double[] var88 = new double[] { 100.0d, 1.0d};
    boolean var89 = org.apache.commons.math3.util.MathArrays.equals(var85, var88);
    double var90 = org.apache.commons.math3.util.MathArrays.distance(var81, var85);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var91 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var2, var49, var81);
    double var93 = var91.cumulativeProbability(7239013.0522433d);
    double var95 = var91.cumulativeProbability(3068624.4438274824d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var95 == 1.0d);

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(0.0d, (-0.6858698665320467d), 0.0d, (-1.0d), 0.8761829645236354d, 2.0d, 0.0d, 7239013.0522433d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.7523659290472708d);

  }

  public void test152() {}
//   public void test152() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     float var3 = var1.nextFloat();
//     var1.clear();
//     double[] var5 = null;
//     double[] var8 = new double[] { 100.0d, (-1.0d)};
//     double[] var11 = new double[] { 100.0d, 1.0d};
//     boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var8, var11);
//     double[] var15 = new double[] { 100.0d, (-1.0d)};
//     double[] var18 = new double[] { 100.0d, 1.0d};
//     boolean var19 = org.apache.commons.math3.util.MathArrays.equals(var15, var18);
//     double[] var22 = new double[] { 100.0d, (-1.0d)};
//     double[] var25 = new double[] { 100.0d, 1.0d};
//     boolean var26 = org.apache.commons.math3.util.MathArrays.equals(var22, var25);
//     double var27 = org.apache.commons.math3.util.MathArrays.distance(var18, var22);
//     double[] var30 = new double[] { 100.0d, (-1.0d)};
//     double[] var33 = new double[] { 100.0d, 1.0d};
//     boolean var34 = org.apache.commons.math3.util.MathArrays.equals(var30, var33);
//     double[] var37 = new double[] { 100.0d, (-1.0d)};
//     double[] var40 = new double[] { 100.0d, 1.0d};
//     boolean var41 = org.apache.commons.math3.util.MathArrays.equals(var37, var40);
//     double var42 = org.apache.commons.math3.util.MathArrays.distance(var33, var37);
//     double var43 = org.apache.commons.math3.util.MathArrays.linearCombination(var18, var33);
//     boolean var44 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var8, var18);
//     double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var18, (-1.682916631768903d));
//     double[] var49 = new double[] { 100.0d, (-1.0d)};
//     double[] var52 = new double[] { 100.0d, 1.0d};
//     boolean var53 = org.apache.commons.math3.util.MathArrays.equals(var49, var52);
//     double[] var56 = new double[] { 100.0d, (-1.0d)};
//     double[] var59 = new double[] { 100.0d, 1.0d};
//     boolean var60 = org.apache.commons.math3.util.MathArrays.equals(var56, var59);
//     double var61 = org.apache.commons.math3.util.MathArrays.distance(var52, var56);
//     double[] var64 = new double[] { 100.0d, (-1.0d)};
//     double[] var67 = new double[] { 100.0d, 1.0d};
//     boolean var68 = org.apache.commons.math3.util.MathArrays.equals(var64, var67);
//     double[] var69 = org.apache.commons.math3.util.MathArrays.ebeDivide(var56, var64);
//     double[] var72 = new double[] { 100.0d, (-1.0d)};
//     double[] var75 = new double[] { 100.0d, 1.0d};
//     boolean var76 = org.apache.commons.math3.util.MathArrays.equals(var72, var75);
//     double[] var79 = new double[] { 100.0d, (-1.0d)};
//     double[] var82 = new double[] { 100.0d, 1.0d};
//     boolean var83 = org.apache.commons.math3.util.MathArrays.equals(var79, var82);
//     double var84 = org.apache.commons.math3.util.MathArrays.distance(var75, var79);
//     double[] var87 = new double[] { 100.0d, (-1.0d)};
//     double[] var90 = new double[] { 100.0d, 1.0d};
//     boolean var91 = org.apache.commons.math3.util.MathArrays.equals(var87, var90);
//     double[] var92 = org.apache.commons.math3.util.MathArrays.ebeDivide(var79, var87);
//     double[] var93 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var64, var92);
//     double var94 = org.apache.commons.math3.util.MathArrays.distance1(var46, var92);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var95 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var5, var92);
// 
//   }

  public void test153() {}
//   public void test153() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var5 = var2.nextSecureLong(0L, 1L);
//     var2.reSeed(6L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var2.nextGamma((-2.350538798101527d), (-2.350538798101527d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0L);
// 
//   }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    double[] var5 = new double[] { 100.0d, (-1.0d)};
    double[] var8 = new double[] { 100.0d, 1.0d};
    boolean var9 = org.apache.commons.math3.util.MathArrays.equals(var5, var8);
    double[] var12 = new double[] { 100.0d, (-1.0d)};
    double[] var15 = new double[] { 100.0d, 1.0d};
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var12, var15);
    double[] var19 = new double[] { 100.0d, (-1.0d)};
    double[] var22 = new double[] { 100.0d, 1.0d};
    boolean var23 = org.apache.commons.math3.util.MathArrays.equals(var19, var22);
    double var24 = org.apache.commons.math3.util.MathArrays.distance(var15, var19);
    double[] var27 = new double[] { 100.0d, (-1.0d)};
    double[] var30 = new double[] { 100.0d, 1.0d};
    boolean var31 = org.apache.commons.math3.util.MathArrays.equals(var27, var30);
    double[] var34 = new double[] { 100.0d, (-1.0d)};
    double[] var37 = new double[] { 100.0d, 1.0d};
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var34, var37);
    double var39 = org.apache.commons.math3.util.MathArrays.distance(var30, var34);
    double var40 = org.apache.commons.math3.util.MathArrays.linearCombination(var15, var30);
    boolean var41 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var5, var15);
    double[] var43 = org.apache.commons.math3.util.MathArrays.normalizeArray(var15, (-1.682916631768903d));
    double[] var46 = new double[] { 100.0d, (-1.0d)};
    double[] var49 = new double[] { 100.0d, 1.0d};
    boolean var50 = org.apache.commons.math3.util.MathArrays.equals(var46, var49);
    double[] var53 = new double[] { 100.0d, (-1.0d)};
    double[] var56 = new double[] { 100.0d, 1.0d};
    boolean var57 = org.apache.commons.math3.util.MathArrays.equals(var53, var56);
    double var58 = org.apache.commons.math3.util.MathArrays.distance(var49, var53);
    double[] var61 = new double[] { 100.0d, (-1.0d)};
    double[] var64 = new double[] { 100.0d, 1.0d};
    boolean var65 = org.apache.commons.math3.util.MathArrays.equals(var61, var64);
    double[] var68 = new double[] { 100.0d, (-1.0d)};
    double[] var71 = new double[] { 100.0d, 1.0d};
    boolean var72 = org.apache.commons.math3.util.MathArrays.equals(var68, var71);
    double var73 = org.apache.commons.math3.util.MathArrays.distance(var64, var68);
    double var74 = org.apache.commons.math3.util.MathArrays.linearCombination(var49, var64);
    double[] var75 = org.apache.commons.math3.util.MathArrays.ebeAdd(var43, var49);
    double[] var78 = new double[] { 100.0d, (-1.0d)};
    double[] var81 = new double[] { 100.0d, 1.0d};
    boolean var82 = org.apache.commons.math3.util.MathArrays.equals(var78, var81);
    double[] var85 = new double[] { 100.0d, (-1.0d)};
    double[] var88 = new double[] { 100.0d, 1.0d};
    boolean var89 = org.apache.commons.math3.util.MathArrays.equals(var85, var88);
    double var90 = org.apache.commons.math3.util.MathArrays.distance(var81, var85);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var91 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var2, var49, var81);
    boolean var92 = var91.isSupportConnected();
    double var94 = var91.density(0.40877566087838346d);
    var91.reseedRandomGenerator(3L);
    double var98 = var91.density((-0.18999442618139734d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var94 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var98 == 0.0d);

  }

  public void test155() {}
//   public void test155() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextGaussian(0.0d, 2.0d);
//     var1.reSeedSecure(0L);
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var1.nextSecureInt(30, 1);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.9430015265203553d);
// 
//   }

  public void test156() {}
//   public void test156() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     long var6 = var2.nextLong((-1L), 10L);
//     var2.reSeedSecure(6L);
//     java.lang.String var10 = var2.nextHexString(1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var2.nextWeibull(13.226435756113098d, (-0.7314779623383547d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 9L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "5"+ "'", var10.equals("5"));
// 
//   }

  public void test157() {}
//   public void test157() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)885.3062819424027d);
//     org.apache.commons.math3.exception.MathInternalError var3 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var2);
// 
//   }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }


    int[] var1 = new int[] { (-1)};
    int[] var2 = org.apache.commons.math3.util.MathArrays.copyOf(var1);
    int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var2);
    int[] var4 = new int[] { };
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = org.apache.commons.math3.util.MathArrays.distance(var3, var4);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, (-1), 1);

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    double[] var5 = new double[] { 100.0d, (-1.0d)};
    double[] var8 = new double[] { 100.0d, 1.0d};
    boolean var9 = org.apache.commons.math3.util.MathArrays.equals(var5, var8);
    double[] var12 = new double[] { 100.0d, (-1.0d)};
    double[] var15 = new double[] { 100.0d, 1.0d};
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var12, var15);
    double[] var19 = new double[] { 100.0d, (-1.0d)};
    double[] var22 = new double[] { 100.0d, 1.0d};
    boolean var23 = org.apache.commons.math3.util.MathArrays.equals(var19, var22);
    double var24 = org.apache.commons.math3.util.MathArrays.distance(var15, var19);
    double[] var27 = new double[] { 100.0d, (-1.0d)};
    double[] var30 = new double[] { 100.0d, 1.0d};
    boolean var31 = org.apache.commons.math3.util.MathArrays.equals(var27, var30);
    double[] var34 = new double[] { 100.0d, (-1.0d)};
    double[] var37 = new double[] { 100.0d, 1.0d};
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var34, var37);
    double var39 = org.apache.commons.math3.util.MathArrays.distance(var30, var34);
    double var40 = org.apache.commons.math3.util.MathArrays.linearCombination(var15, var30);
    boolean var41 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var5, var15);
    double[] var43 = org.apache.commons.math3.util.MathArrays.normalizeArray(var15, (-1.682916631768903d));
    double[] var46 = new double[] { 100.0d, (-1.0d)};
    double[] var49 = new double[] { 100.0d, 1.0d};
    boolean var50 = org.apache.commons.math3.util.MathArrays.equals(var46, var49);
    double[] var53 = new double[] { 100.0d, (-1.0d)};
    double[] var56 = new double[] { 100.0d, 1.0d};
    boolean var57 = org.apache.commons.math3.util.MathArrays.equals(var53, var56);
    double var58 = org.apache.commons.math3.util.MathArrays.distance(var49, var53);
    double[] var61 = new double[] { 100.0d, (-1.0d)};
    double[] var64 = new double[] { 100.0d, 1.0d};
    boolean var65 = org.apache.commons.math3.util.MathArrays.equals(var61, var64);
    double[] var68 = new double[] { 100.0d, (-1.0d)};
    double[] var71 = new double[] { 100.0d, 1.0d};
    boolean var72 = org.apache.commons.math3.util.MathArrays.equals(var68, var71);
    double var73 = org.apache.commons.math3.util.MathArrays.distance(var64, var68);
    double var74 = org.apache.commons.math3.util.MathArrays.linearCombination(var49, var64);
    double[] var75 = org.apache.commons.math3.util.MathArrays.ebeAdd(var43, var49);
    double[] var78 = new double[] { 100.0d, (-1.0d)};
    double[] var81 = new double[] { 100.0d, 1.0d};
    boolean var82 = org.apache.commons.math3.util.MathArrays.equals(var78, var81);
    double[] var85 = new double[] { 100.0d, (-1.0d)};
    double[] var88 = new double[] { 100.0d, 1.0d};
    boolean var89 = org.apache.commons.math3.util.MathArrays.equals(var85, var88);
    double var90 = org.apache.commons.math3.util.MathArrays.distance(var81, var85);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var91 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var2, var49, var81);
    double var93 = var91.cumulativeProbability(7239013.0522433d);
    double var94 = var91.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var94 == 96.07881580237154d);

  }

  public void test161() {}
//   public void test161() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextT(10001.0d);
//     long var6 = var1.nextLong((-1L), 3L);
//     var1.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var1.nextSecureInt(10, 1);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-0.4455745174001674d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0L);
// 
//   }

  public void test162() {}
//   public void test162() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1.0d, (java.lang.Number)10, true);
//     java.lang.Number var5 = var4.getMax();
//     org.apache.commons.math3.exception.MathInternalError var6 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var4);
// 
//   }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeedSecure(10L);
    double var6 = var2.nextExponential(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 132.82498240734793d);

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var3 = var1.nextDouble();
    var1.setSeed(10L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var7 = var1.nextInt(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.40877566087838346d);

  }

  public void test165() {}
//   public void test165() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextGaussian(0.0d, 2.0d);
//     var1.reSeedSecure(0L);
//     var1.reSeedSecure();
//     double var10 = var1.nextGaussian(2.0d, 2.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var12 = var1.nextSecureHexString(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.5820602432064517d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.7219199240262002d);
// 
//   }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }


    double[] var0 = null;
    double[] var3 = new double[] { 100.0d, (-1.0d)};
    double[] var6 = new double[] { 100.0d, 1.0d};
    boolean var7 = org.apache.commons.math3.util.MathArrays.equals(var3, var6);
    double[] var10 = new double[] { 100.0d, (-1.0d)};
    double[] var13 = new double[] { 100.0d, 1.0d};
    boolean var14 = org.apache.commons.math3.util.MathArrays.equals(var10, var13);
    double[] var17 = new double[] { 100.0d, (-1.0d)};
    double[] var20 = new double[] { 100.0d, 1.0d};
    boolean var21 = org.apache.commons.math3.util.MathArrays.equals(var17, var20);
    double var22 = org.apache.commons.math3.util.MathArrays.distance(var13, var17);
    double[] var25 = new double[] { 100.0d, (-1.0d)};
    double[] var28 = new double[] { 100.0d, 1.0d};
    boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var25, var28);
    double[] var32 = new double[] { 100.0d, (-1.0d)};
    double[] var35 = new double[] { 100.0d, 1.0d};
    boolean var36 = org.apache.commons.math3.util.MathArrays.equals(var32, var35);
    double var37 = org.apache.commons.math3.util.MathArrays.distance(var28, var32);
    double var38 = org.apache.commons.math3.util.MathArrays.linearCombination(var13, var28);
    boolean var39 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var13);
    double[] var41 = org.apache.commons.math3.util.MathArrays.normalizeArray(var13, (-1.682916631768903d));
    double[] var44 = new double[] { 100.0d, (-1.0d)};
    double[] var47 = new double[] { 100.0d, 1.0d};
    boolean var48 = org.apache.commons.math3.util.MathArrays.equals(var44, var47);
    double[] var51 = new double[] { 100.0d, (-1.0d)};
    double[] var54 = new double[] { 100.0d, 1.0d};
    boolean var55 = org.apache.commons.math3.util.MathArrays.equals(var51, var54);
    double var56 = org.apache.commons.math3.util.MathArrays.distance(var47, var51);
    double[] var59 = new double[] { 100.0d, (-1.0d)};
    double[] var62 = new double[] { 100.0d, 1.0d};
    boolean var63 = org.apache.commons.math3.util.MathArrays.equals(var59, var62);
    double[] var64 = org.apache.commons.math3.util.MathArrays.ebeDivide(var51, var59);
    double[] var65 = org.apache.commons.math3.util.MathArrays.ebeDivide(var13, var59);
    double[][] var66 = new double[][] { var65};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.sortInPlace(var0, var66);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }


    double[] var2 = new double[] { 100.0d, (-1.0d)};
    double[] var5 = new double[] { 100.0d, 1.0d};
    boolean var6 = org.apache.commons.math3.util.MathArrays.equals(var2, var5);
    double[] var9 = new double[] { 100.0d, (-1.0d)};
    double[] var12 = new double[] { 100.0d, 1.0d};
    boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var9, var12);
    double[] var16 = new double[] { 100.0d, (-1.0d)};
    double[] var19 = new double[] { 100.0d, 1.0d};
    boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var16, var19);
    double var21 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double[] var24 = new double[] { 100.0d, (-1.0d)};
    double[] var27 = new double[] { 100.0d, 1.0d};
    boolean var28 = org.apache.commons.math3.util.MathArrays.equals(var24, var27);
    double[] var31 = new double[] { 100.0d, (-1.0d)};
    double[] var34 = new double[] { 100.0d, 1.0d};
    boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var31, var34);
    double var36 = org.apache.commons.math3.util.MathArrays.distance(var27, var31);
    double var37 = org.apache.commons.math3.util.MathArrays.linearCombination(var12, var27);
    boolean var38 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var2, var12);
    double[] var40 = org.apache.commons.math3.util.MathArrays.normalizeArray(var12, (-1.682916631768903d));
    double[] var43 = new double[] { 100.0d, (-1.0d)};
    double[] var46 = new double[] { 100.0d, 1.0d};
    boolean var47 = org.apache.commons.math3.util.MathArrays.equals(var43, var46);
    double[] var50 = new double[] { 100.0d, (-1.0d)};
    double[] var53 = new double[] { 100.0d, 1.0d};
    boolean var54 = org.apache.commons.math3.util.MathArrays.equals(var50, var53);
    double var55 = org.apache.commons.math3.util.MathArrays.distance(var46, var50);
    double[] var58 = new double[] { 100.0d, (-1.0d)};
    double[] var61 = new double[] { 100.0d, 1.0d};
    boolean var62 = org.apache.commons.math3.util.MathArrays.equals(var58, var61);
    double[] var63 = org.apache.commons.math3.util.MathArrays.ebeDivide(var50, var58);
    double[] var66 = new double[] { 100.0d, (-1.0d)};
    double[] var69 = new double[] { 100.0d, 1.0d};
    boolean var70 = org.apache.commons.math3.util.MathArrays.equals(var66, var69);
    double[] var73 = new double[] { 100.0d, (-1.0d)};
    double[] var76 = new double[] { 100.0d, 1.0d};
    boolean var77 = org.apache.commons.math3.util.MathArrays.equals(var73, var76);
    double var78 = org.apache.commons.math3.util.MathArrays.distance(var69, var73);
    double[] var81 = new double[] { 100.0d, (-1.0d)};
    double[] var84 = new double[] { 100.0d, 1.0d};
    boolean var85 = org.apache.commons.math3.util.MathArrays.equals(var81, var84);
    double[] var86 = org.apache.commons.math3.util.MathArrays.ebeDivide(var73, var81);
    double[] var87 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var58, var86);
    double var88 = org.apache.commons.math3.util.MathArrays.distance1(var40, var86);
    double[] var89 = new double[] { };
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var90 = org.apache.commons.math3.util.MathArrays.distance1(var40, var89);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == 3.682916631768903d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    double[] var5 = new double[] { 100.0d, (-1.0d)};
    double[] var8 = new double[] { 100.0d, 1.0d};
    boolean var9 = org.apache.commons.math3.util.MathArrays.equals(var5, var8);
    double[] var12 = new double[] { 100.0d, (-1.0d)};
    double[] var15 = new double[] { 100.0d, 1.0d};
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var12, var15);
    double[] var19 = new double[] { 100.0d, (-1.0d)};
    double[] var22 = new double[] { 100.0d, 1.0d};
    boolean var23 = org.apache.commons.math3.util.MathArrays.equals(var19, var22);
    double var24 = org.apache.commons.math3.util.MathArrays.distance(var15, var19);
    double[] var27 = new double[] { 100.0d, (-1.0d)};
    double[] var30 = new double[] { 100.0d, 1.0d};
    boolean var31 = org.apache.commons.math3.util.MathArrays.equals(var27, var30);
    double[] var34 = new double[] { 100.0d, (-1.0d)};
    double[] var37 = new double[] { 100.0d, 1.0d};
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var34, var37);
    double var39 = org.apache.commons.math3.util.MathArrays.distance(var30, var34);
    double var40 = org.apache.commons.math3.util.MathArrays.linearCombination(var15, var30);
    boolean var41 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var5, var15);
    double[] var43 = org.apache.commons.math3.util.MathArrays.normalizeArray(var15, (-1.682916631768903d));
    double[] var46 = new double[] { 100.0d, (-1.0d)};
    double[] var49 = new double[] { 100.0d, 1.0d};
    boolean var50 = org.apache.commons.math3.util.MathArrays.equals(var46, var49);
    double[] var53 = new double[] { 100.0d, (-1.0d)};
    double[] var56 = new double[] { 100.0d, 1.0d};
    boolean var57 = org.apache.commons.math3.util.MathArrays.equals(var53, var56);
    double var58 = org.apache.commons.math3.util.MathArrays.distance(var49, var53);
    double[] var61 = new double[] { 100.0d, (-1.0d)};
    double[] var64 = new double[] { 100.0d, 1.0d};
    boolean var65 = org.apache.commons.math3.util.MathArrays.equals(var61, var64);
    double[] var68 = new double[] { 100.0d, (-1.0d)};
    double[] var71 = new double[] { 100.0d, 1.0d};
    boolean var72 = org.apache.commons.math3.util.MathArrays.equals(var68, var71);
    double var73 = org.apache.commons.math3.util.MathArrays.distance(var64, var68);
    double var74 = org.apache.commons.math3.util.MathArrays.linearCombination(var49, var64);
    double[] var75 = org.apache.commons.math3.util.MathArrays.ebeAdd(var43, var49);
    double[] var78 = new double[] { 100.0d, (-1.0d)};
    double[] var81 = new double[] { 100.0d, 1.0d};
    boolean var82 = org.apache.commons.math3.util.MathArrays.equals(var78, var81);
    double[] var85 = new double[] { 100.0d, (-1.0d)};
    double[] var88 = new double[] { 100.0d, 1.0d};
    boolean var89 = org.apache.commons.math3.util.MathArrays.equals(var85, var88);
    double var90 = org.apache.commons.math3.util.MathArrays.distance(var81, var85);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var91 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var2, var49, var81);
    boolean var92 = var91.isSupportConnected();
    double var94 = var91.density(0.40877566087838346d);
    var91.reseedRandomGenerator(3L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var99 = var91.probability(99.01980198019803d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var94 == 0.0d);

  }

  public void test169() {}
//   public void test169() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 52, 52);
// 
//   }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = var1.nextUniform(96.07881580237154d, 11.684643263460426d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)3L);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(-1.0d));

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }


    long[] var3 = new long[] { 0L, 0L, 1L};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeedSecure(10L);
    double var7 = var2.nextUniform(11.684643263460426d, 7506849.916132723d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var9 = var2.nextPoisson((-1.212080947441934d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 3068624.4438274824d);

  }

  public void test175() {}
//   public void test175() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextGaussian(0.0d, 2.0d);
//     var1.reSeedSecure(0L);
//     double var9 = var1.nextWeibull(2.0d, 9854048.12570597d);
//     double var11 = var1.nextT(0.5650828929145241d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var1.nextInt(10, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.4847647051340191d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.851131555253769E7d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-1.7311222195000082d));
// 
//   }

  public void test176() {}
//   public void test176() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(1);
//     int[] var3 = new int[] { (-1)};
//     int[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
//     int[] var6 = new int[] { (-1)};
//     int[] var7 = org.apache.commons.math3.util.MathArrays.copyOf(var6);
//     int[] var9 = new int[] { (-1)};
//     int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var9);
//     int var11 = org.apache.commons.math3.util.MathArrays.distanceInf(var7, var9);
//     int var12 = org.apache.commons.math3.util.MathArrays.distanceInf(var4, var9);
//     var1.setSeed(var9);
//     double[] var16 = new double[] { 100.0d, (-1.0d)};
//     double[] var19 = new double[] { 100.0d, 1.0d};
//     boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var16, var19);
//     double[] var23 = new double[] { 100.0d, (-1.0d)};
//     double[] var26 = new double[] { 100.0d, 1.0d};
//     boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var23, var26);
//     double[] var30 = new double[] { 100.0d, (-1.0d)};
//     double[] var33 = new double[] { 100.0d, 1.0d};
//     boolean var34 = org.apache.commons.math3.util.MathArrays.equals(var30, var33);
//     double var35 = org.apache.commons.math3.util.MathArrays.distance(var26, var30);
//     double[] var38 = new double[] { 100.0d, (-1.0d)};
//     double[] var41 = new double[] { 100.0d, 1.0d};
//     boolean var42 = org.apache.commons.math3.util.MathArrays.equals(var38, var41);
//     double[] var45 = new double[] { 100.0d, (-1.0d)};
//     double[] var48 = new double[] { 100.0d, 1.0d};
//     boolean var49 = org.apache.commons.math3.util.MathArrays.equals(var45, var48);
//     double var50 = org.apache.commons.math3.util.MathArrays.distance(var41, var45);
//     double var51 = org.apache.commons.math3.util.MathArrays.linearCombination(var26, var41);
//     boolean var52 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var16, var26);
//     double[] var54 = org.apache.commons.math3.util.MathArrays.normalizeArray(var26, (-1.682916631768903d));
//     double[] var57 = new double[] { 100.0d, (-1.0d)};
//     double[] var60 = new double[] { 100.0d, 1.0d};
//     boolean var61 = org.apache.commons.math3.util.MathArrays.equals(var57, var60);
//     double[] var64 = new double[] { 100.0d, (-1.0d)};
//     double[] var67 = new double[] { 100.0d, 1.0d};
//     boolean var68 = org.apache.commons.math3.util.MathArrays.equals(var64, var67);
//     double var69 = org.apache.commons.math3.util.MathArrays.distance(var60, var64);
//     double[] var72 = new double[] { 100.0d, (-1.0d)};
//     double[] var75 = new double[] { 100.0d, 1.0d};
//     boolean var76 = org.apache.commons.math3.util.MathArrays.equals(var72, var75);
//     double[] var77 = org.apache.commons.math3.util.MathArrays.ebeDivide(var64, var72);
//     double[] var78 = org.apache.commons.math3.util.MathArrays.ebeDivide(var26, var72);
//     org.apache.commons.math3.util.Pair var79 = new org.apache.commons.math3.util.Pair((java.lang.Object)var9, (java.lang.Object)var72);
//     int[] var80 = null;
//     int var81 = org.apache.commons.math3.util.MathArrays.distance1(var9, var80);
// 
//   }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    var1.setSeed(10);
    int var5 = var1.nextInt(86);
    int[] var7 = new int[] { (-1)};
    int[] var8 = org.apache.commons.math3.util.MathArrays.copyOf(var7);
    int[] var10 = new int[] { (-1)};
    int[] var11 = org.apache.commons.math3.util.MathArrays.copyOf(var10);
    int var12 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var10);
    org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(var10);
    var1.setSeed(var10);
    int[] var16 = new int[] { (-1)};
    int[] var17 = org.apache.commons.math3.util.MathArrays.copyOf(var16);
    int[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var17);
    int[] var19 = org.apache.commons.math3.util.MathArrays.copyOf(var17);
    var1.setSeed(var17);
    int var21 = var1.nextInt();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 2035706397);

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    float var3 = var1.nextFloat();
    var1.clear();
    int var5 = var1.nextInt();
    long var6 = var1.nextLong();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.40877557f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 998139946);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-833491931516635789L));

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }


    double[] var2 = new double[] { 100.0d, (-1.0d)};
    double[] var5 = new double[] { 100.0d, 1.0d};
    boolean var6 = org.apache.commons.math3.util.MathArrays.equals(var2, var5);
    double[] var9 = new double[] { 100.0d, (-1.0d)};
    double[] var12 = new double[] { 100.0d, 1.0d};
    boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var9, var12);
    double[] var16 = new double[] { 100.0d, (-1.0d)};
    double[] var19 = new double[] { 100.0d, 1.0d};
    boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var16, var19);
    double[] var23 = new double[] { 100.0d, (-1.0d)};
    double[] var26 = new double[] { 100.0d, 1.0d};
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var23, var26);
    double var28 = org.apache.commons.math3.util.MathArrays.distance(var19, var23);
    double[] var31 = new double[] { 100.0d, (-1.0d)};
    double[] var34 = new double[] { 100.0d, 1.0d};
    boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var31, var34);
    double[] var38 = new double[] { 100.0d, (-1.0d)};
    double[] var41 = new double[] { 100.0d, 1.0d};
    boolean var42 = org.apache.commons.math3.util.MathArrays.equals(var38, var41);
    double var43 = org.apache.commons.math3.util.MathArrays.distance(var34, var38);
    double var44 = org.apache.commons.math3.util.MathArrays.linearCombination(var19, var34);
    boolean var45 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var9, var19);
    double[] var47 = org.apache.commons.math3.util.MathArrays.normalizeArray(var19, (-1.682916631768903d));
    double[] var48 = org.apache.commons.math3.util.MathArrays.ebeAdd(var5, var19);
    double[] var51 = new double[] { 100.0d, (-1.0d)};
    double[] var54 = new double[] { 100.0d, 1.0d};
    boolean var55 = org.apache.commons.math3.util.MathArrays.equals(var51, var54);
    double[] var58 = new double[] { 100.0d, (-1.0d)};
    double[] var61 = new double[] { 100.0d, 1.0d};
    boolean var62 = org.apache.commons.math3.util.MathArrays.equals(var58, var61);
    double[] var65 = new double[] { 100.0d, (-1.0d)};
    double[] var68 = new double[] { 100.0d, 1.0d};
    boolean var69 = org.apache.commons.math3.util.MathArrays.equals(var65, var68);
    double var70 = org.apache.commons.math3.util.MathArrays.distance(var61, var65);
    double[] var73 = new double[] { 100.0d, (-1.0d)};
    double[] var76 = new double[] { 100.0d, 1.0d};
    boolean var77 = org.apache.commons.math3.util.MathArrays.equals(var73, var76);
    double[] var80 = new double[] { 100.0d, (-1.0d)};
    double[] var83 = new double[] { 100.0d, 1.0d};
    boolean var84 = org.apache.commons.math3.util.MathArrays.equals(var80, var83);
    double var85 = org.apache.commons.math3.util.MathArrays.distance(var76, var80);
    double var86 = org.apache.commons.math3.util.MathArrays.linearCombination(var61, var76);
    boolean var87 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var51, var61);
    double var88 = org.apache.commons.math3.util.MathArrays.distanceInf(var5, var61);
    double[] var89 = org.apache.commons.math3.util.MathArrays.copyOf(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);

  }

  public void test180() {}
//   public void test180() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextGaussian(10.0d, 2.0d);
//     int var7 = var1.nextInt(0, 1);
//     var1.reSeed(0L);
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var1.nextF((-0.050078283873571376d), 0.009900990099009901d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 12.209515016951123d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
// 
//   }

  public void test181() {}
//   public void test181() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }
// 
// 
//     double[] var2 = new double[] { 100.0d, (-1.0d)};
//     double[] var5 = new double[] { 100.0d, 1.0d};
//     boolean var6 = org.apache.commons.math3.util.MathArrays.equals(var2, var5);
//     double[] var9 = new double[] { 100.0d, (-1.0d)};
//     double[] var12 = new double[] { 100.0d, 1.0d};
//     boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var9, var12);
//     double var14 = org.apache.commons.math3.util.MathArrays.distance(var5, var9);
//     double[] var17 = new double[] { 100.0d, (-1.0d)};
//     double[] var20 = new double[] { 100.0d, 1.0d};
//     boolean var21 = org.apache.commons.math3.util.MathArrays.equals(var17, var20);
//     double[] var22 = org.apache.commons.math3.util.MathArrays.ebeDivide(var9, var17);
//     double[] var23 = null;
//     double var24 = org.apache.commons.math3.util.MathArrays.linearCombination(var9, var23);
// 
//   }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }


    double[] var2 = new double[] { 100.0d, (-1.0d)};
    double[] var5 = new double[] { 100.0d, 1.0d};
    boolean var6 = org.apache.commons.math3.util.MathArrays.equals(var2, var5);
    double[] var9 = new double[] { 100.0d, (-1.0d)};
    double[] var12 = new double[] { 100.0d, 1.0d};
    boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var9, var12);
    double var14 = org.apache.commons.math3.util.MathArrays.distance(var5, var9);
    double[] var17 = new double[] { 100.0d, (-1.0d)};
    double[] var20 = new double[] { 100.0d, 1.0d};
    boolean var21 = org.apache.commons.math3.util.MathArrays.equals(var17, var20);
    double[] var24 = new double[] { 100.0d, (-1.0d)};
    double[] var27 = new double[] { 100.0d, 1.0d};
    boolean var28 = org.apache.commons.math3.util.MathArrays.equals(var24, var27);
    double[] var31 = new double[] { 100.0d, (-1.0d)};
    double[] var34 = new double[] { 100.0d, 1.0d};
    boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var31, var34);
    double var36 = org.apache.commons.math3.util.MathArrays.distance(var27, var31);
    double[] var39 = new double[] { 100.0d, (-1.0d)};
    double[] var42 = new double[] { 100.0d, 1.0d};
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var39, var42);
    double[] var46 = new double[] { 100.0d, (-1.0d)};
    double[] var49 = new double[] { 100.0d, 1.0d};
    boolean var50 = org.apache.commons.math3.util.MathArrays.equals(var46, var49);
    double var51 = org.apache.commons.math3.util.MathArrays.distance(var42, var46);
    double var52 = org.apache.commons.math3.util.MathArrays.linearCombination(var27, var42);
    boolean var53 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var17, var27);
    double[] var55 = org.apache.commons.math3.util.MathArrays.normalizeArray(var27, (-1.682916631768903d));
    org.apache.commons.math3.distribution.DiscreteRealDistribution var56 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var9, var27);
    var56.reseedRandomGenerator(1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }


    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)2.0d, (java.lang.Object)(byte)(-1));
    java.lang.Object var3 = var2.getSecond();
    java.lang.Object var4 = var2.getKey();
    boolean var6 = var2.equals((java.lang.Object)"0627178f9a");
    java.lang.Object var7 = var2.getValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + (byte)(-1)+ "'", var3.equals((byte)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 2.0d+ "'", var4.equals(2.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (byte)(-1)+ "'", var7.equals((byte)(-1)));

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }


    int[] var1 = new int[] { (-1)};
    int[] var2 = org.apache.commons.math3.util.MathArrays.copyOf(var1);
    int[] var4 = new int[] { (-1)};
    int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
    int[] var7 = new int[] { (-1)};
    int[] var8 = org.apache.commons.math3.util.MathArrays.copyOf(var7);
    int var9 = org.apache.commons.math3.util.MathArrays.distanceInf(var5, var7);
    int var10 = org.apache.commons.math3.util.MathArrays.distanceInf(var2, var7);
    int[] var14 = new int[] { (-1), 10, 100};
    double var15 = org.apache.commons.math3.util.MathArrays.distance(var7, var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);

  }

  public void test185() {}
//   public void test185() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var5 = var2.nextSecureInt(0, 86);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var8 = var2.nextPascal(10, (-2555.7647705813442d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 84);
// 
//   }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)998139946, (java.lang.Number)(-1.0d), (java.lang.Number)1.0d);

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)47.60131471069713d, true);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    double[] var5 = new double[] { 100.0d, (-1.0d)};
    double[] var8 = new double[] { 100.0d, 1.0d};
    boolean var9 = org.apache.commons.math3.util.MathArrays.equals(var5, var8);
    double[] var12 = new double[] { 100.0d, (-1.0d)};
    double[] var15 = new double[] { 100.0d, 1.0d};
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var12, var15);
    double[] var19 = new double[] { 100.0d, (-1.0d)};
    double[] var22 = new double[] { 100.0d, 1.0d};
    boolean var23 = org.apache.commons.math3.util.MathArrays.equals(var19, var22);
    double var24 = org.apache.commons.math3.util.MathArrays.distance(var15, var19);
    double[] var27 = new double[] { 100.0d, (-1.0d)};
    double[] var30 = new double[] { 100.0d, 1.0d};
    boolean var31 = org.apache.commons.math3.util.MathArrays.equals(var27, var30);
    double[] var34 = new double[] { 100.0d, (-1.0d)};
    double[] var37 = new double[] { 100.0d, 1.0d};
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var34, var37);
    double var39 = org.apache.commons.math3.util.MathArrays.distance(var30, var34);
    double var40 = org.apache.commons.math3.util.MathArrays.linearCombination(var15, var30);
    boolean var41 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var5, var15);
    double[] var43 = org.apache.commons.math3.util.MathArrays.normalizeArray(var15, (-1.682916631768903d));
    double[] var46 = new double[] { 100.0d, (-1.0d)};
    double[] var49 = new double[] { 100.0d, 1.0d};
    boolean var50 = org.apache.commons.math3.util.MathArrays.equals(var46, var49);
    double[] var53 = new double[] { 100.0d, (-1.0d)};
    double[] var56 = new double[] { 100.0d, 1.0d};
    boolean var57 = org.apache.commons.math3.util.MathArrays.equals(var53, var56);
    double var58 = org.apache.commons.math3.util.MathArrays.distance(var49, var53);
    double[] var61 = new double[] { 100.0d, (-1.0d)};
    double[] var64 = new double[] { 100.0d, 1.0d};
    boolean var65 = org.apache.commons.math3.util.MathArrays.equals(var61, var64);
    double[] var68 = new double[] { 100.0d, (-1.0d)};
    double[] var71 = new double[] { 100.0d, 1.0d};
    boolean var72 = org.apache.commons.math3.util.MathArrays.equals(var68, var71);
    double var73 = org.apache.commons.math3.util.MathArrays.distance(var64, var68);
    double var74 = org.apache.commons.math3.util.MathArrays.linearCombination(var49, var64);
    double[] var75 = org.apache.commons.math3.util.MathArrays.ebeAdd(var43, var49);
    double[] var78 = new double[] { 100.0d, (-1.0d)};
    double[] var81 = new double[] { 100.0d, 1.0d};
    boolean var82 = org.apache.commons.math3.util.MathArrays.equals(var78, var81);
    double[] var85 = new double[] { 100.0d, (-1.0d)};
    double[] var88 = new double[] { 100.0d, 1.0d};
    boolean var89 = org.apache.commons.math3.util.MathArrays.equals(var85, var88);
    double var90 = org.apache.commons.math3.util.MathArrays.distance(var81, var85);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var91 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var2, var49, var81);
    double var93 = var91.density(0.0d);
    double var96 = var91.probability(1.3705339519213432E8d, 1.3705339519213432E8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var96 == 0.0d);

  }

  public void test189() {}
//   public void test189() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 30);
// 
//   }

  public void test190() {}
//   public void test190() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextT(10001.0d);
//     long var6 = var1.nextLong((-1L), 3L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("5704f866d4cba2903ba4655f9e0f11", "046dac4c25");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.2771607019350125d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1L));
// 
//   }

  public void test191() {}
//   public void test191() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextGaussian(10.0d, 2.0d);
//     java.util.Collection var5 = null;
//     java.lang.Object[] var7 = var1.nextSample(var5, 100);
// 
//   }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, var1, (java.lang.Number)(byte)0, true);
    java.lang.Number var5 = var4.getMin();
    java.lang.Number var6 = var4.getMin();
    java.lang.Number var7 = var4.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (byte)0+ "'", var5.equals((byte)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (byte)0+ "'", var6.equals((byte)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (byte)0+ "'", var7.equals((byte)0));

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    double var2 = var1.nextDouble();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var6 = var3.nextCauchy(132.82498240734793d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.40877566087838346d);

  }

  public void test194() {}
//   public void test194() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }
// 
// 
//     double[] var0 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var0);
// 
//   }

  public void test195() {}
//   public void test195() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }
// 
// 
//     double[] var0 = null;
//     double[] var3 = new double[] { 100.0d, (-1.0d)};
//     double[] var6 = new double[] { 100.0d, 1.0d};
//     boolean var7 = org.apache.commons.math3.util.MathArrays.equals(var3, var6);
//     double[] var10 = new double[] { 100.0d, (-1.0d)};
//     double[] var13 = new double[] { 100.0d, 1.0d};
//     boolean var14 = org.apache.commons.math3.util.MathArrays.equals(var10, var13);
//     double var15 = org.apache.commons.math3.util.MathArrays.distance(var6, var10);
//     double[] var16 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var0, var6);
// 
//   }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(-1.0f));

  }

  public void test197() {}
//   public void test197() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }
// 
// 
//     double[] var2 = new double[] { 100.0d, (-1.0d)};
//     double[] var5 = new double[] { 100.0d, 1.0d};
//     boolean var6 = org.apache.commons.math3.util.MathArrays.equals(var2, var5);
//     double[] var9 = new double[] { 100.0d, (-1.0d)};
//     double[] var12 = new double[] { 100.0d, 1.0d};
//     boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var9, var12);
//     double var14 = org.apache.commons.math3.util.MathArrays.distance(var5, var9);
//     double[] var17 = new double[] { 100.0d, (-1.0d)};
//     double[] var20 = new double[] { 100.0d, 1.0d};
//     boolean var21 = org.apache.commons.math3.util.MathArrays.equals(var17, var20);
//     double[] var22 = org.apache.commons.math3.util.MathArrays.ebeDivide(var9, var17);
//     double[] var25 = new double[] { 100.0d, (-1.0d)};
//     double[] var28 = new double[] { 100.0d, 1.0d};
//     boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var25, var28);
//     double[] var32 = new double[] { 100.0d, (-1.0d)};
//     double[] var35 = new double[] { 100.0d, 1.0d};
//     boolean var36 = org.apache.commons.math3.util.MathArrays.equals(var32, var35);
//     double var37 = org.apache.commons.math3.util.MathArrays.distance(var28, var32);
//     double[] var40 = new double[] { 100.0d, (-1.0d)};
//     double[] var43 = new double[] { 100.0d, 1.0d};
//     boolean var44 = org.apache.commons.math3.util.MathArrays.equals(var40, var43);
//     double[] var45 = org.apache.commons.math3.util.MathArrays.ebeDivide(var32, var40);
//     double[] var46 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var17, var45);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var47 = null;
//     boolean var49 = org.apache.commons.math3.util.MathArrays.isMonotonic(var45, var47, false);
// 
//   }

  public void test198() {}
//   public void test198() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextGaussian(0.0d, 2.0d);
//     var1.reSeedSecure(0L);
//     var1.reSeedSecure();
//     double var10 = var1.nextGaussian(2.0d, 2.0d);
//     var1.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var1.nextPascal(0, 2.3590437156692077d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-3.112007538126816d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.5007290958917561d));
// 
//   }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed((-1L));
    double var6 = var0.nextUniform(0.0d, 2.3590437156692077d, false);
    double var9 = var0.nextGamma(885.3062819424027d, 96.07881580237154d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var13 = var0.nextUniform(0.0d, (-0.7844030186481109d), true);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.5650828929145241d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 80739.49636849186d);

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)1.2694665049707192d, (java.lang.Number)(-0.050078283873571376d), true);

  }

  public void test201() {}
//   public void test201() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }
// 
// 
//     double[] var0 = null;
//     double[] var3 = new double[] { 100.0d, (-1.0d)};
//     double[] var6 = new double[] { 100.0d, 1.0d};
//     boolean var7 = org.apache.commons.math3.util.MathArrays.equals(var3, var6);
//     double[] var10 = new double[] { 100.0d, (-1.0d)};
//     double[] var13 = new double[] { 100.0d, 1.0d};
//     boolean var14 = org.apache.commons.math3.util.MathArrays.equals(var10, var13);
//     double[] var17 = new double[] { 100.0d, (-1.0d)};
//     double[] var20 = new double[] { 100.0d, 1.0d};
//     boolean var21 = org.apache.commons.math3.util.MathArrays.equals(var17, var20);
//     double var22 = org.apache.commons.math3.util.MathArrays.distance(var13, var17);
//     double[] var25 = new double[] { 100.0d, (-1.0d)};
//     double[] var28 = new double[] { 100.0d, 1.0d};
//     boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var25, var28);
//     double[] var32 = new double[] { 100.0d, (-1.0d)};
//     double[] var35 = new double[] { 100.0d, 1.0d};
//     boolean var36 = org.apache.commons.math3.util.MathArrays.equals(var32, var35);
//     double var37 = org.apache.commons.math3.util.MathArrays.distance(var28, var32);
//     double var38 = org.apache.commons.math3.util.MathArrays.linearCombination(var13, var28);
//     boolean var39 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var13);
//     double[] var41 = org.apache.commons.math3.util.MathArrays.normalizeArray(var13, (-1.682916631768903d));
//     double[] var44 = new double[] { 100.0d, (-1.0d)};
//     double[] var47 = new double[] { 100.0d, 1.0d};
//     boolean var48 = org.apache.commons.math3.util.MathArrays.equals(var44, var47);
//     double[] var51 = new double[] { 100.0d, (-1.0d)};
//     double[] var54 = new double[] { 100.0d, 1.0d};
//     boolean var55 = org.apache.commons.math3.util.MathArrays.equals(var51, var54);
//     double var56 = org.apache.commons.math3.util.MathArrays.distance(var47, var51);
//     double[] var59 = new double[] { 100.0d, (-1.0d)};
//     double[] var62 = new double[] { 100.0d, 1.0d};
//     boolean var63 = org.apache.commons.math3.util.MathArrays.equals(var59, var62);
//     double[] var64 = org.apache.commons.math3.util.MathArrays.ebeDivide(var51, var59);
//     double[] var67 = new double[] { 100.0d, (-1.0d)};
//     double[] var70 = new double[] { 100.0d, 1.0d};
//     boolean var71 = org.apache.commons.math3.util.MathArrays.equals(var67, var70);
//     double[] var74 = new double[] { 100.0d, (-1.0d)};
//     double[] var77 = new double[] { 100.0d, 1.0d};
//     boolean var78 = org.apache.commons.math3.util.MathArrays.equals(var74, var77);
//     double var79 = org.apache.commons.math3.util.MathArrays.distance(var70, var74);
//     double[] var82 = new double[] { 100.0d, (-1.0d)};
//     double[] var85 = new double[] { 100.0d, 1.0d};
//     boolean var86 = org.apache.commons.math3.util.MathArrays.equals(var82, var85);
//     double[] var87 = org.apache.commons.math3.util.MathArrays.ebeDivide(var74, var82);
//     double[] var88 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var59, var87);
//     double var89 = org.apache.commons.math3.util.MathArrays.distance1(var41, var87);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var90 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var0, var87);
// 
//   }

  public void test202() {}
//   public void test202() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 86);
// 
//   }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)(-0.7314779623383547d), (java.lang.Number)1, (java.lang.Number)8.609350869964992d);

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)86, (java.lang.Number)1L, true);
    java.lang.Throwable[] var5 = var4.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var6 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)5L);

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var6 = var2.nextWeibull(0.15328243612779968d, (-1.6270847051012245d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double[] var5 = new double[] { 100.0d, (-1.0d)};
    double[] var8 = new double[] { 100.0d, 1.0d};
    boolean var9 = org.apache.commons.math3.util.MathArrays.equals(var5, var8);
    double[] var12 = new double[] { 100.0d, (-1.0d)};
    double[] var15 = new double[] { 100.0d, 1.0d};
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var12, var15);
    double[] var19 = new double[] { 100.0d, (-1.0d)};
    double[] var22 = new double[] { 100.0d, 1.0d};
    boolean var23 = org.apache.commons.math3.util.MathArrays.equals(var19, var22);
    double[] var26 = new double[] { 100.0d, (-1.0d)};
    double[] var29 = new double[] { 100.0d, 1.0d};
    boolean var30 = org.apache.commons.math3.util.MathArrays.equals(var26, var29);
    double var31 = org.apache.commons.math3.util.MathArrays.distance(var22, var26);
    double[] var34 = new double[] { 100.0d, (-1.0d)};
    double[] var37 = new double[] { 100.0d, 1.0d};
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var34, var37);
    double[] var41 = new double[] { 100.0d, (-1.0d)};
    double[] var44 = new double[] { 100.0d, 1.0d};
    boolean var45 = org.apache.commons.math3.util.MathArrays.equals(var41, var44);
    double var46 = org.apache.commons.math3.util.MathArrays.distance(var37, var41);
    double var47 = org.apache.commons.math3.util.MathArrays.linearCombination(var22, var37);
    boolean var48 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var12, var22);
    double[] var50 = org.apache.commons.math3.util.MathArrays.normalizeArray(var22, (-1.682916631768903d));
    double[] var51 = org.apache.commons.math3.util.MathArrays.ebeAdd(var8, var22);
    double[] var53 = org.apache.commons.math3.util.MathArrays.copyOf(var22, 0);
    double[] var55 = new double[] { 10.0d};
    double var56 = org.apache.commons.math3.util.MathArrays.safeNorm(var55);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.DiscreteRealDistribution var57 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var53, var55);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 10.0d);

  }

  public void test208() {}
//   public void test208() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }
// 
// 
//     double[] var2 = new double[] { 100.0d, (-1.0d)};
//     double[] var5 = new double[] { 100.0d, 1.0d};
//     boolean var6 = org.apache.commons.math3.util.MathArrays.equals(var2, var5);
//     double[] var9 = new double[] { 100.0d, (-1.0d)};
//     double[] var12 = new double[] { 100.0d, 1.0d};
//     boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var9, var12);
//     double var14 = org.apache.commons.math3.util.MathArrays.distance(var5, var9);
//     double[] var15 = null;
//     double[] var16 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var5, var15);
// 
//   }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }


    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)2.0d, (java.lang.Object)(byte)(-1));
    java.lang.Object var3 = var2.getSecond();
    java.lang.Object var4 = var2.getSecond();
    java.lang.Object var5 = var2.getSecond();
    java.lang.Object var6 = var2.getValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + (byte)(-1)+ "'", var3.equals((byte)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (byte)(-1)+ "'", var4.equals((byte)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (byte)(-1)+ "'", var5.equals((byte)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (byte)(-1)+ "'", var6.equals((byte)(-1)));

  }

  public void test210() {}
//   public void test210() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextT(10001.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var5 = var1.nextExponential((-1.212080947441934d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.1124382691327872d);
// 
//   }

  public void test211() {}
//   public void test211() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     java.util.Collection var4 = null;
//     java.lang.Object[] var6 = var2.nextSample(var4, (-1));
// 
//   }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }


    int[] var1 = new int[] { (-1)};
    int[] var2 = org.apache.commons.math3.util.MathArrays.copyOf(var1);
    int[] var4 = new int[] { (-1)};
    int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
    int var6 = org.apache.commons.math3.util.MathArrays.distanceInf(var2, var4);
    org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(var4);
    org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(var4);
    org.apache.commons.math3.random.Well19937c var10 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var11 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var10);
    double var12 = var10.nextDouble();
    byte[] var13 = new byte[] { };
    var10.nextBytes(var13);
    var8.nextBytes(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.40877566087838346d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(0.2884362901949524d, 1.0d, (-0.4700655222907494d), (-1.212080947441934d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.8581937538129115d);

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(short)100, var1, false);
    boolean var4 = var3.getBoundIsAllowed();
    java.lang.Number var5 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    double[] var2 = new double[] { 10.0d};
    double var3 = org.apache.commons.math3.util.MathArrays.safeNorm(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.safeNorm(var2);
    double[] var7 = new double[] { 100.0d, (-1.0d)};
    double[] var10 = new double[] { 100.0d, 1.0d};
    boolean var11 = org.apache.commons.math3.util.MathArrays.equals(var7, var10);
    double[] var14 = new double[] { 100.0d, (-1.0d)};
    double[] var17 = new double[] { 100.0d, 1.0d};
    boolean var18 = org.apache.commons.math3.util.MathArrays.equals(var14, var17);
    double[] var21 = new double[] { 100.0d, (-1.0d)};
    double[] var24 = new double[] { 100.0d, 1.0d};
    boolean var25 = org.apache.commons.math3.util.MathArrays.equals(var21, var24);
    double var26 = org.apache.commons.math3.util.MathArrays.distance(var17, var21);
    double[] var29 = new double[] { 100.0d, (-1.0d)};
    double[] var32 = new double[] { 100.0d, 1.0d};
    boolean var33 = org.apache.commons.math3.util.MathArrays.equals(var29, var32);
    double[] var36 = new double[] { 100.0d, (-1.0d)};
    double[] var39 = new double[] { 100.0d, 1.0d};
    boolean var40 = org.apache.commons.math3.util.MathArrays.equals(var36, var39);
    double var41 = org.apache.commons.math3.util.MathArrays.distance(var32, var36);
    double var42 = org.apache.commons.math3.util.MathArrays.linearCombination(var17, var32);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var17);
    double[] var45 = org.apache.commons.math3.util.MathArrays.normalizeArray(var17, (-1.682916631768903d));
    double[] var48 = new double[] { 100.0d, (-1.0d)};
    double[] var51 = new double[] { 100.0d, 1.0d};
    boolean var52 = org.apache.commons.math3.util.MathArrays.equals(var48, var51);
    double[] var55 = new double[] { 100.0d, (-1.0d)};
    double[] var58 = new double[] { 100.0d, 1.0d};
    boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var55, var58);
    double var60 = org.apache.commons.math3.util.MathArrays.distance(var51, var55);
    double[] var63 = new double[] { 100.0d, (-1.0d)};
    double[] var66 = new double[] { 100.0d, 1.0d};
    boolean var67 = org.apache.commons.math3.util.MathArrays.equals(var63, var66);
    double[] var70 = new double[] { 100.0d, (-1.0d)};
    double[] var73 = new double[] { 100.0d, 1.0d};
    boolean var74 = org.apache.commons.math3.util.MathArrays.equals(var70, var73);
    double var75 = org.apache.commons.math3.util.MathArrays.distance(var66, var70);
    double var76 = org.apache.commons.math3.util.MathArrays.linearCombination(var51, var66);
    double[] var77 = org.apache.commons.math3.util.MathArrays.ebeAdd(var45, var51);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.DiscreteRealDistribution var78 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var0, var2, var51);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)86, (java.lang.Number)1L, true);
    java.lang.Throwable[] var5 = var4.getSuppressed();
    org.apache.commons.math3.exception.MathInternalError var6 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = var0.nextUniform((-0.6858698665320467d), (-1.682916631768903d), false);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0.6115651382182169d);

  }

  public void test219() {}
//   public void test219() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     java.lang.String var5 = var2.nextSecureHexString(30);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var8 = var2.nextUniform(2.6669397224844205d, (-1.0d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + "e09f8dea3c875c3e80f8c1ebcd320d"+ "'", var5.equals("e09f8dea3c875c3e80f8c1ebcd320d"));
// 
//   }

  public void test220() {}
//   public void test220() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }
// 
// 
//     double[] var2 = new double[] { 100.0d, (-1.0d)};
//     double[] var5 = new double[] { 100.0d, 1.0d};
//     boolean var6 = org.apache.commons.math3.util.MathArrays.equals(var2, var5);
//     double[] var9 = new double[] { 100.0d, (-1.0d)};
//     double[] var12 = new double[] { 100.0d, 1.0d};
//     boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var9, var12);
//     double[] var16 = new double[] { 100.0d, (-1.0d)};
//     double[] var19 = new double[] { 100.0d, 1.0d};
//     boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var16, var19);
//     double[] var23 = new double[] { 100.0d, (-1.0d)};
//     double[] var26 = new double[] { 100.0d, 1.0d};
//     boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var23, var26);
//     double var28 = org.apache.commons.math3.util.MathArrays.distance(var19, var23);
//     double[] var31 = new double[] { 100.0d, (-1.0d)};
//     double[] var34 = new double[] { 100.0d, 1.0d};
//     boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var31, var34);
//     double[] var38 = new double[] { 100.0d, (-1.0d)};
//     double[] var41 = new double[] { 100.0d, 1.0d};
//     boolean var42 = org.apache.commons.math3.util.MathArrays.equals(var38, var41);
//     double var43 = org.apache.commons.math3.util.MathArrays.distance(var34, var38);
//     double var44 = org.apache.commons.math3.util.MathArrays.linearCombination(var19, var34);
//     boolean var45 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var9, var19);
//     double[] var47 = org.apache.commons.math3.util.MathArrays.normalizeArray(var19, (-1.682916631768903d));
//     double[] var48 = org.apache.commons.math3.util.MathArrays.ebeAdd(var5, var19);
//     double[] var51 = new double[] { 100.0d, (-1.0d)};
//     double[] var54 = new double[] { 100.0d, 1.0d};
//     boolean var55 = org.apache.commons.math3.util.MathArrays.equals(var51, var54);
//     double[] var58 = new double[] { 100.0d, (-1.0d)};
//     double[] var61 = new double[] { 100.0d, 1.0d};
//     boolean var62 = org.apache.commons.math3.util.MathArrays.equals(var58, var61);
//     double[] var65 = new double[] { 100.0d, (-1.0d)};
//     double[] var68 = new double[] { 100.0d, 1.0d};
//     boolean var69 = org.apache.commons.math3.util.MathArrays.equals(var65, var68);
//     double var70 = org.apache.commons.math3.util.MathArrays.distance(var61, var65);
//     double[] var73 = new double[] { 100.0d, (-1.0d)};
//     double[] var76 = new double[] { 100.0d, 1.0d};
//     boolean var77 = org.apache.commons.math3.util.MathArrays.equals(var73, var76);
//     double[] var80 = new double[] { 100.0d, (-1.0d)};
//     double[] var83 = new double[] { 100.0d, 1.0d};
//     boolean var84 = org.apache.commons.math3.util.MathArrays.equals(var80, var83);
//     double var85 = org.apache.commons.math3.util.MathArrays.distance(var76, var80);
//     double var86 = org.apache.commons.math3.util.MathArrays.linearCombination(var61, var76);
//     boolean var87 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var51, var61);
//     double var88 = org.apache.commons.math3.util.MathArrays.distanceInf(var5, var61);
//     double[] var89 = null;
//     double var90 = org.apache.commons.math3.util.MathArrays.distance1(var61, var89);
// 
//   }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var1);
    int[] var5 = new int[] { (-1)};
    int[] var6 = org.apache.commons.math3.util.MathArrays.copyOf(var5);
    int[] var8 = new int[] { (-1)};
    int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var8);
    int var10 = org.apache.commons.math3.util.MathArrays.distanceInf(var6, var8);
    int var11 = org.apache.commons.math3.util.MathArrays.distance1(var3, var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);

  }

  public void test222() {}
//   public void test222() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     var1.setSeed(10);
//     int var5 = var1.nextInt(86);
//     byte[] var6 = null;
//     var1.nextBytes(var6);
// 
//   }

  public void test223() {}
//   public void test223() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextT(10001.0d);
//     long var6 = var1.nextLong((-1L), 3L);
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var1.nextSecureInt(2035706397, 30);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-0.7870186994499074d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2L);
// 
//   }

  public void test224() {}
//   public void test224() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextGaussian((-0.5770298507560749d), 10001.0d);
//     long var8 = var2.nextSecureLong((-1L), 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-2555.7647705813442d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-1L));
// 
//   }

  public void test225() {}
//   public void test225() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextGaussian(0.0d, 2.0d);
//     java.lang.String var6 = var1.nextHexString(10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var9 = var1.nextPermutation(10, 2035706397);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-0.23826074746540202d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "352f143b29"+ "'", var6.equals("352f143b29"));
// 
//   }

  public void test226() {}
//   public void test226() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var5 = var2.nextSecureLong(0L, 1L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var8 = var2.nextGamma(0.0d, 11.684643263460426d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1L);
// 
//   }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.util.MathArrays.OrderDirection var4 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var6 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1L, (java.lang.Number)(-1), 1, var4, false);
    java.lang.String var7 = var6.toString();
    java.lang.Throwable[] var8 = var6.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var9 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "org.apache.commons.math3.exception.NonMonotonicSequenceException: points 0 and 1 are not decreasing (-1 < 1)"+ "'", var7.equals("org.apache.commons.math3.exception.NonMonotonicSequenceException: points 0 and 1 are not decreasing (-1 < 1)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    double[] var5 = new double[] { 100.0d, (-1.0d)};
    double[] var8 = new double[] { 100.0d, 1.0d};
    boolean var9 = org.apache.commons.math3.util.MathArrays.equals(var5, var8);
    double[] var12 = new double[] { 100.0d, (-1.0d)};
    double[] var15 = new double[] { 100.0d, 1.0d};
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var12, var15);
    double[] var19 = new double[] { 100.0d, (-1.0d)};
    double[] var22 = new double[] { 100.0d, 1.0d};
    boolean var23 = org.apache.commons.math3.util.MathArrays.equals(var19, var22);
    double var24 = org.apache.commons.math3.util.MathArrays.distance(var15, var19);
    double[] var27 = new double[] { 100.0d, (-1.0d)};
    double[] var30 = new double[] { 100.0d, 1.0d};
    boolean var31 = org.apache.commons.math3.util.MathArrays.equals(var27, var30);
    double[] var34 = new double[] { 100.0d, (-1.0d)};
    double[] var37 = new double[] { 100.0d, 1.0d};
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var34, var37);
    double var39 = org.apache.commons.math3.util.MathArrays.distance(var30, var34);
    double var40 = org.apache.commons.math3.util.MathArrays.linearCombination(var15, var30);
    boolean var41 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var5, var15);
    double[] var43 = org.apache.commons.math3.util.MathArrays.normalizeArray(var15, (-1.682916631768903d));
    double[] var46 = new double[] { 100.0d, (-1.0d)};
    double[] var49 = new double[] { 100.0d, 1.0d};
    boolean var50 = org.apache.commons.math3.util.MathArrays.equals(var46, var49);
    double[] var53 = new double[] { 100.0d, (-1.0d)};
    double[] var56 = new double[] { 100.0d, 1.0d};
    boolean var57 = org.apache.commons.math3.util.MathArrays.equals(var53, var56);
    double var58 = org.apache.commons.math3.util.MathArrays.distance(var49, var53);
    double[] var61 = new double[] { 100.0d, (-1.0d)};
    double[] var64 = new double[] { 100.0d, 1.0d};
    boolean var65 = org.apache.commons.math3.util.MathArrays.equals(var61, var64);
    double[] var68 = new double[] { 100.0d, (-1.0d)};
    double[] var71 = new double[] { 100.0d, 1.0d};
    boolean var72 = org.apache.commons.math3.util.MathArrays.equals(var68, var71);
    double var73 = org.apache.commons.math3.util.MathArrays.distance(var64, var68);
    double var74 = org.apache.commons.math3.util.MathArrays.linearCombination(var49, var64);
    double[] var75 = org.apache.commons.math3.util.MathArrays.ebeAdd(var43, var49);
    double[] var78 = new double[] { 100.0d, (-1.0d)};
    double[] var81 = new double[] { 100.0d, 1.0d};
    boolean var82 = org.apache.commons.math3.util.MathArrays.equals(var78, var81);
    double[] var85 = new double[] { 100.0d, (-1.0d)};
    double[] var88 = new double[] { 100.0d, 1.0d};
    boolean var89 = org.apache.commons.math3.util.MathArrays.equals(var85, var88);
    double var90 = org.apache.commons.math3.util.MathArrays.distance(var81, var85);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var91 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var2, var49, var81);
    var91.reseedRandomGenerator((-1L));
    double var96 = var91.probability(0.6115651382182169d, 99.01980198019803d);
    double var97 = var91.sample();
    var91.reseedRandomGenerator(0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var96 == 0.009900990099009901d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var97 == 100.0d);

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    float var3 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var7 = var4.nextWeibull(0.0d, 0.19743013148352145d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.40877557f);

  }

  public void test230() {}
//   public void test230() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
//     float var2 = var0.nextFloat();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.83821094f);
// 
//   }

  public void test231() {}
//   public void test231() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextT(10001.0d);
//     long var6 = var1.nextLong((-1L), 3L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var1.nextGamma(100.0d, (-1.6478376658157248d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.0464425306547607d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1L));
// 
//   }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)100L);
    java.lang.Number var3 = var2.getMin();
    java.lang.Number var4 = var2.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0+ "'", var4.equals(0));

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }


    java.lang.Number var1 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.19743013148352145d, var1, var2);

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.40877566087838346d, (java.lang.Number)(-10101.0d), true);

  }

  public void test235() {}
//   public void test235() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextInt(86, 998139946);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 561247916);
// 
//   }

  public void test236() {}
//   public void test236() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextGaussian(10.0d, 2.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var7 = var1.nextCauchy(0.009900990099009901d, (-1.212080947441934d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 8.706134239284637d);
// 
//   }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextGaussian(0.40877566087838346d, 1.0d);
    double var8 = var2.nextBeta(3.682916631768903d, 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.15328243612779968d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 3.252729169280298E-4d);

  }

  public void test238() {}
//   public void test238() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure();
//     long var4 = var0.nextSecureLong((-1L), 7L);
//     double var6 = var0.nextChiSquare(0.009900990099009901d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 6L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.451238645107864E-9d);
// 
//   }

  public void test239() {}
//   public void test239() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }
// 
// 
//     java.lang.Comparable[] var0 = null;
//     org.apache.commons.math3.util.MathArrays.OrderDirection var1 = null;
//     boolean var3 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var0, var1, false);
// 
//   }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination((-0.6858698665320467d), 1.3705339519213432E8d, 0.8761829645236354d, (-1.6478376658157248d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-9.400079531200032E7d));

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1.0d, (java.lang.Number)10, true);
    boolean var5 = var4.getBoundIsAllowed();
    org.apache.commons.math3.exception.util.ExceptionContext var6 = var4.getContext();
    java.lang.Number var7 = var4.getMax();
    org.apache.commons.math3.exception.NullArgumentException var8 = new org.apache.commons.math3.exception.NullArgumentException();
    var4.addSuppressed((java.lang.Throwable)var8);
    org.apache.commons.math3.util.MathArrays.OrderDirection var13 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var15 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1L, (java.lang.Number)(-1), 1, var13, false);
    java.lang.Number var16 = var15.getPrevious();
    int var17 = var15.getIndex();
    var8.addSuppressed((java.lang.Throwable)var15);
    int var19 = var15.getIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 10+ "'", var7.equals(10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + (-1)+ "'", var16.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1);

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextGaussian(0.40877566087838346d, 1.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var7 = var2.nextSecureHexString((-1));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.15328243612779968d);

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    double[] var5 = new double[] { 100.0d, (-1.0d)};
    double[] var8 = new double[] { 100.0d, 1.0d};
    boolean var9 = org.apache.commons.math3.util.MathArrays.equals(var5, var8);
    double[] var12 = new double[] { 100.0d, (-1.0d)};
    double[] var15 = new double[] { 100.0d, 1.0d};
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var12, var15);
    double[] var19 = new double[] { 100.0d, (-1.0d)};
    double[] var22 = new double[] { 100.0d, 1.0d};
    boolean var23 = org.apache.commons.math3.util.MathArrays.equals(var19, var22);
    double var24 = org.apache.commons.math3.util.MathArrays.distance(var15, var19);
    double[] var27 = new double[] { 100.0d, (-1.0d)};
    double[] var30 = new double[] { 100.0d, 1.0d};
    boolean var31 = org.apache.commons.math3.util.MathArrays.equals(var27, var30);
    double[] var34 = new double[] { 100.0d, (-1.0d)};
    double[] var37 = new double[] { 100.0d, 1.0d};
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var34, var37);
    double var39 = org.apache.commons.math3.util.MathArrays.distance(var30, var34);
    double var40 = org.apache.commons.math3.util.MathArrays.linearCombination(var15, var30);
    boolean var41 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var5, var15);
    double[] var43 = org.apache.commons.math3.util.MathArrays.normalizeArray(var15, (-1.682916631768903d));
    double[] var46 = new double[] { 100.0d, (-1.0d)};
    double[] var49 = new double[] { 100.0d, 1.0d};
    boolean var50 = org.apache.commons.math3.util.MathArrays.equals(var46, var49);
    double[] var53 = new double[] { 100.0d, (-1.0d)};
    double[] var56 = new double[] { 100.0d, 1.0d};
    boolean var57 = org.apache.commons.math3.util.MathArrays.equals(var53, var56);
    double var58 = org.apache.commons.math3.util.MathArrays.distance(var49, var53);
    double[] var61 = new double[] { 100.0d, (-1.0d)};
    double[] var64 = new double[] { 100.0d, 1.0d};
    boolean var65 = org.apache.commons.math3.util.MathArrays.equals(var61, var64);
    double[] var68 = new double[] { 100.0d, (-1.0d)};
    double[] var71 = new double[] { 100.0d, 1.0d};
    boolean var72 = org.apache.commons.math3.util.MathArrays.equals(var68, var71);
    double var73 = org.apache.commons.math3.util.MathArrays.distance(var64, var68);
    double var74 = org.apache.commons.math3.util.MathArrays.linearCombination(var49, var64);
    double[] var75 = org.apache.commons.math3.util.MathArrays.ebeAdd(var43, var49);
    double[] var78 = new double[] { 100.0d, (-1.0d)};
    double[] var81 = new double[] { 100.0d, 1.0d};
    boolean var82 = org.apache.commons.math3.util.MathArrays.equals(var78, var81);
    double[] var85 = new double[] { 100.0d, (-1.0d)};
    double[] var88 = new double[] { 100.0d, 1.0d};
    boolean var89 = org.apache.commons.math3.util.MathArrays.equals(var85, var88);
    double var90 = org.apache.commons.math3.util.MathArrays.distance(var81, var85);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var91 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var2, var49, var81);
    boolean var92 = var91.isSupportConnected();
    boolean var93 = var91.isSupportConnected();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var95 = var91.inverseCumulativeProbability(2.027380293984852d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == true);

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }


    java.lang.Object[] var1 = null;
    org.apache.commons.math3.exception.NotFiniteNumberException var2 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(byte)0, var1);

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }


    int[] var0 = null;
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var6 = var2.nextHypergeometric(561247916, 2147483647, 4);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeedSecure(10L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var6 = var2.nextExponential((-2555.7647705813442d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test247() {}
//   public void test247() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextGaussian(0.0d, 2.0d);
//     var1.reSeedSecure(0L);
//     var1.reSeedSecure();
//     double var10 = var1.nextGaussian(2.0d, 2.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var1.nextBinomial(0, 9854048.12570597d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-4.499923109228074d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 3.7276474532802277d);
// 
//   }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)1687.9702609361561d);

  }

  public void test249() {}
//   public void test249() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextT(10001.0d);
//     double var6 = var1.nextCauchy(0.2323975705328034d, 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.32973134850766805d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.15135115843769842d);
// 
//   }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var5 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)86, (java.lang.Number)1L, true);
    java.lang.Throwable[] var6 = var5.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var7 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)1.0f, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.util.ExceptionContext var8 = var7.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test251() {}
//   public void test251() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed((-1L));
//     var0.reSeed();
//     long var6 = var0.nextSecureLong((-1L), 10L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 9L);
// 
//   }

  public void test252() {}
//   public void test252() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextGaussian(10.0d, 2.0d);
//     int var7 = var1.nextInt(0, 1);
//     var1.reSeed(0L);
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var1.nextBinomial(0, 3.31077097012213d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 9.981135530774745d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
// 
//   }

  public void test253() {}
//   public void test253() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextGaussian(0.0d, 2.0d);
//     var1.reSeedSecure(0L);
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var10 = var1.nextLong(9L, (-414028722650554365L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.4027338379762944d);
// 
//   }

  public void test254() {}
//   public void test254() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }
// 
// 
//     double[] var2 = new double[] { 100.0d, (-1.0d)};
//     double[] var5 = new double[] { 100.0d, 1.0d};
//     boolean var6 = org.apache.commons.math3.util.MathArrays.equals(var2, var5);
//     double[] var9 = new double[] { 100.0d, (-1.0d)};
//     double[] var12 = new double[] { 100.0d, 1.0d};
//     boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var9, var12);
//     double[] var16 = new double[] { 100.0d, (-1.0d)};
//     double[] var19 = new double[] { 100.0d, 1.0d};
//     boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var16, var19);
//     double[] var23 = new double[] { 100.0d, (-1.0d)};
//     double[] var26 = new double[] { 100.0d, 1.0d};
//     boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var23, var26);
//     double var28 = org.apache.commons.math3.util.MathArrays.distance(var19, var23);
//     double[] var31 = new double[] { 100.0d, (-1.0d)};
//     double[] var34 = new double[] { 100.0d, 1.0d};
//     boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var31, var34);
//     double[] var38 = new double[] { 100.0d, (-1.0d)};
//     double[] var41 = new double[] { 100.0d, 1.0d};
//     boolean var42 = org.apache.commons.math3.util.MathArrays.equals(var38, var41);
//     double var43 = org.apache.commons.math3.util.MathArrays.distance(var34, var38);
//     double var44 = org.apache.commons.math3.util.MathArrays.linearCombination(var19, var34);
//     boolean var45 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var9, var19);
//     double[] var47 = org.apache.commons.math3.util.MathArrays.normalizeArray(var19, (-1.682916631768903d));
//     double[] var48 = org.apache.commons.math3.util.MathArrays.ebeAdd(var5, var19);
//     double[] var51 = new double[] { 100.0d, (-1.0d)};
//     double[] var54 = new double[] { 100.0d, 1.0d};
//     boolean var55 = org.apache.commons.math3.util.MathArrays.equals(var51, var54);
//     double[] var58 = new double[] { 100.0d, (-1.0d)};
//     double[] var61 = new double[] { 100.0d, 1.0d};
//     boolean var62 = org.apache.commons.math3.util.MathArrays.equals(var58, var61);
//     double[] var65 = new double[] { 100.0d, (-1.0d)};
//     double[] var68 = new double[] { 100.0d, 1.0d};
//     boolean var69 = org.apache.commons.math3.util.MathArrays.equals(var65, var68);
//     double var70 = org.apache.commons.math3.util.MathArrays.distance(var61, var65);
//     double[] var73 = new double[] { 100.0d, (-1.0d)};
//     double[] var76 = new double[] { 100.0d, 1.0d};
//     boolean var77 = org.apache.commons.math3.util.MathArrays.equals(var73, var76);
//     double[] var80 = new double[] { 100.0d, (-1.0d)};
//     double[] var83 = new double[] { 100.0d, 1.0d};
//     boolean var84 = org.apache.commons.math3.util.MathArrays.equals(var80, var83);
//     double var85 = org.apache.commons.math3.util.MathArrays.distance(var76, var80);
//     double var86 = org.apache.commons.math3.util.MathArrays.linearCombination(var61, var76);
//     boolean var87 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var51, var61);
//     double var88 = org.apache.commons.math3.util.MathArrays.distanceInf(var5, var61);
//     double[] var90 = org.apache.commons.math3.util.MathArrays.copyOf(var61, 86);
//     double[] var91 = null;
//     double var92 = org.apache.commons.math3.util.MathArrays.distance(var90, var91);
// 
//   }

  public void test255() {}
//   public void test255() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     long var6 = var2.nextLong((-1L), 10L);
//     double var8 = var2.nextChiSquare(99.01980198019803d);
//     java.util.Collection var9 = null;
//     java.lang.Object[] var11 = var2.nextSample(var9, 100);
// 
//   }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(100, 28);

  }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }


    double[] var1 = new double[] { 10.0d};
    double var2 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    boolean var5 = org.apache.commons.math3.util.MathArrays.isMonotonic(var1, var3, false);
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
    boolean var9 = org.apache.commons.math3.util.MathArrays.checkOrder(var1, var6, false, true);
    double[] var12 = new double[] { 100.0d, (-1.0d)};
    double[] var15 = new double[] { 100.0d, 1.0d};
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var12, var15);
    double[] var19 = new double[] { 100.0d, (-1.0d)};
    double[] var22 = new double[] { 100.0d, 1.0d};
    boolean var23 = org.apache.commons.math3.util.MathArrays.equals(var19, var22);
    double[] var26 = new double[] { 100.0d, (-1.0d)};
    double[] var29 = new double[] { 100.0d, 1.0d};
    boolean var30 = org.apache.commons.math3.util.MathArrays.equals(var26, var29);
    double var31 = org.apache.commons.math3.util.MathArrays.distance(var22, var26);
    double[] var34 = new double[] { 100.0d, (-1.0d)};
    double[] var37 = new double[] { 100.0d, 1.0d};
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var34, var37);
    double[] var41 = new double[] { 100.0d, (-1.0d)};
    double[] var44 = new double[] { 100.0d, 1.0d};
    boolean var45 = org.apache.commons.math3.util.MathArrays.equals(var41, var44);
    double var46 = org.apache.commons.math3.util.MathArrays.distance(var37, var41);
    double var47 = org.apache.commons.math3.util.MathArrays.linearCombination(var22, var37);
    boolean var48 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var12, var22);
    double[] var50 = org.apache.commons.math3.util.MathArrays.normalizeArray(var22, (-1.682916631768903d));
    double[] var53 = new double[] { 100.0d, (-1.0d)};
    double[] var56 = new double[] { 100.0d, 1.0d};
    boolean var57 = org.apache.commons.math3.util.MathArrays.equals(var53, var56);
    double[] var60 = new double[] { 100.0d, (-1.0d)};
    double[] var63 = new double[] { 100.0d, 1.0d};
    boolean var64 = org.apache.commons.math3.util.MathArrays.equals(var60, var63);
    double var65 = org.apache.commons.math3.util.MathArrays.distance(var56, var60);
    double[] var68 = new double[] { 100.0d, (-1.0d)};
    double[] var71 = new double[] { 100.0d, 1.0d};
    boolean var72 = org.apache.commons.math3.util.MathArrays.equals(var68, var71);
    double[] var73 = org.apache.commons.math3.util.MathArrays.ebeDivide(var60, var68);
    double[] var74 = org.apache.commons.math3.util.MathArrays.ebeDivide(var22, var68);
    boolean var75 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var1, var68);
    double[] var78 = new double[] { 100.0d, (-1.0d)};
    double[] var81 = new double[] { 100.0d, 1.0d};
    boolean var82 = org.apache.commons.math3.util.MathArrays.equals(var78, var81);
    double[] var85 = new double[] { 100.0d, (-1.0d)};
    double[] var88 = new double[] { 100.0d, 1.0d};
    boolean var89 = org.apache.commons.math3.util.MathArrays.equals(var85, var88);
    double var90 = org.apache.commons.math3.util.MathArrays.distance(var81, var85);
    double[] var93 = new double[] { 100.0d, (-1.0d)};
    double[] var96 = new double[] { 100.0d, 1.0d};
    boolean var97 = org.apache.commons.math3.util.MathArrays.equals(var93, var96);
    double[] var98 = org.apache.commons.math3.util.MathArrays.ebeDivide(var85, var93);
    boolean var99 = org.apache.commons.math3.util.MathArrays.equals(var68, var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var93);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var96);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var97 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var98);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var99 == true);

  }

  public void test258() {}
//   public void test258() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }
// 
// 
//     double[] var2 = new double[] { 100.0d, (-1.0d)};
//     double[] var5 = new double[] { 100.0d, 1.0d};
//     boolean var6 = org.apache.commons.math3.util.MathArrays.equals(var2, var5);
//     double[] var9 = new double[] { 100.0d, (-1.0d)};
//     double[] var12 = new double[] { 100.0d, 1.0d};
//     boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var9, var12);
//     double[] var16 = new double[] { 100.0d, (-1.0d)};
//     double[] var19 = new double[] { 100.0d, 1.0d};
//     boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var16, var19);
//     double var21 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
//     double[] var24 = new double[] { 100.0d, (-1.0d)};
//     double[] var27 = new double[] { 100.0d, 1.0d};
//     boolean var28 = org.apache.commons.math3.util.MathArrays.equals(var24, var27);
//     double[] var31 = new double[] { 100.0d, (-1.0d)};
//     double[] var34 = new double[] { 100.0d, 1.0d};
//     boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var31, var34);
//     double var36 = org.apache.commons.math3.util.MathArrays.distance(var27, var31);
//     double var37 = org.apache.commons.math3.util.MathArrays.linearCombination(var12, var27);
//     boolean var38 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var2, var12);
//     double[] var40 = org.apache.commons.math3.util.MathArrays.normalizeArray(var12, (-1.682916631768903d));
//     double[] var43 = new double[] { 100.0d, (-1.0d)};
//     double[] var46 = new double[] { 100.0d, 1.0d};
//     boolean var47 = org.apache.commons.math3.util.MathArrays.equals(var43, var46);
//     double[] var50 = new double[] { 100.0d, (-1.0d)};
//     double[] var53 = new double[] { 100.0d, 1.0d};
//     boolean var54 = org.apache.commons.math3.util.MathArrays.equals(var50, var53);
//     double var55 = org.apache.commons.math3.util.MathArrays.distance(var46, var50);
//     double[] var58 = new double[] { 100.0d, (-1.0d)};
//     double[] var61 = new double[] { 100.0d, 1.0d};
//     boolean var62 = org.apache.commons.math3.util.MathArrays.equals(var58, var61);
//     double[] var63 = org.apache.commons.math3.util.MathArrays.ebeDivide(var50, var58);
//     double[] var64 = org.apache.commons.math3.util.MathArrays.ebeDivide(var12, var58);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var65 = null;
//     double[][] var66 = null;
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var12, var65, var66);
// 
//   }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(224787129);

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)86, (java.lang.Number)1L, true);
    java.lang.Throwable[] var5 = var4.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var6 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    var1.setSeed(10L);
    int var5 = var1.nextInt(10);
    org.apache.commons.math3.random.RandomDataImpl var6 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    java.lang.String var8 = var6.nextHexString(224787129);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var11 = var6.nextUniform(9854048.12570597d, 13.90833488952869d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 4);

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var3 = var1.nextDouble();
    var1.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.40877566087838346d);

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)11.684643263460426d);

  }

  public void test264() {}
//   public void test264() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }
// 
// 
//     double[] var0 = null;
//     double[] var3 = new double[] { 100.0d, (-1.0d)};
//     double[] var6 = new double[] { 100.0d, 1.0d};
//     boolean var7 = org.apache.commons.math3.util.MathArrays.equals(var3, var6);
//     double[] var10 = new double[] { 100.0d, (-1.0d)};
//     double[] var13 = new double[] { 100.0d, 1.0d};
//     boolean var14 = org.apache.commons.math3.util.MathArrays.equals(var10, var13);
//     double[] var17 = new double[] { 100.0d, (-1.0d)};
//     double[] var20 = new double[] { 100.0d, 1.0d};
//     boolean var21 = org.apache.commons.math3.util.MathArrays.equals(var17, var20);
//     double var22 = org.apache.commons.math3.util.MathArrays.distance(var13, var17);
//     double[] var25 = new double[] { 100.0d, (-1.0d)};
//     double[] var28 = new double[] { 100.0d, 1.0d};
//     boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var25, var28);
//     double[] var32 = new double[] { 100.0d, (-1.0d)};
//     double[] var35 = new double[] { 100.0d, 1.0d};
//     boolean var36 = org.apache.commons.math3.util.MathArrays.equals(var32, var35);
//     double var37 = org.apache.commons.math3.util.MathArrays.distance(var28, var32);
//     double var38 = org.apache.commons.math3.util.MathArrays.linearCombination(var13, var28);
//     boolean var39 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var13);
//     double[] var41 = org.apache.commons.math3.util.MathArrays.normalizeArray(var13, (-1.682916631768903d));
//     double[] var44 = new double[] { 100.0d, (-1.0d)};
//     double[] var47 = new double[] { 100.0d, 1.0d};
//     boolean var48 = org.apache.commons.math3.util.MathArrays.equals(var44, var47);
//     double[] var51 = new double[] { 100.0d, (-1.0d)};
//     double[] var54 = new double[] { 100.0d, 1.0d};
//     boolean var55 = org.apache.commons.math3.util.MathArrays.equals(var51, var54);
//     double var56 = org.apache.commons.math3.util.MathArrays.distance(var47, var51);
//     double[] var59 = new double[] { 100.0d, (-1.0d)};
//     double[] var62 = new double[] { 100.0d, 1.0d};
//     boolean var63 = org.apache.commons.math3.util.MathArrays.equals(var59, var62);
//     double[] var66 = new double[] { 100.0d, (-1.0d)};
//     double[] var69 = new double[] { 100.0d, 1.0d};
//     boolean var70 = org.apache.commons.math3.util.MathArrays.equals(var66, var69);
//     double var71 = org.apache.commons.math3.util.MathArrays.distance(var62, var66);
//     double var72 = org.apache.commons.math3.util.MathArrays.linearCombination(var47, var62);
//     double[] var73 = org.apache.commons.math3.util.MathArrays.ebeAdd(var41, var47);
//     double[] var74 = null;
//     boolean var75 = org.apache.commons.math3.util.MathArrays.equals(var47, var74);
//     double[] var76 = org.apache.commons.math3.util.MathArrays.ebeDivide(var0, var74);
// 
//   }

  public void test265() {}
//   public void test265() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextGaussian(10.0d, 2.0d);
//     int[] var6 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(var6);
//     double[] var10 = new double[] { 100.0d, (-1.0d)};
//     double[] var13 = new double[] { 100.0d, 1.0d};
//     boolean var14 = org.apache.commons.math3.util.MathArrays.equals(var10, var13);
//     double[] var17 = new double[] { 100.0d, (-1.0d)};
//     double[] var20 = new double[] { 100.0d, 1.0d};
//     boolean var21 = org.apache.commons.math3.util.MathArrays.equals(var17, var20);
//     double[] var24 = new double[] { 100.0d, (-1.0d)};
//     double[] var27 = new double[] { 100.0d, 1.0d};
//     boolean var28 = org.apache.commons.math3.util.MathArrays.equals(var24, var27);
//     double var29 = org.apache.commons.math3.util.MathArrays.distance(var20, var24);
//     double[] var32 = new double[] { 100.0d, (-1.0d)};
//     double[] var35 = new double[] { 100.0d, 1.0d};
//     boolean var36 = org.apache.commons.math3.util.MathArrays.equals(var32, var35);
//     double[] var39 = new double[] { 100.0d, (-1.0d)};
//     double[] var42 = new double[] { 100.0d, 1.0d};
//     boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var39, var42);
//     double var44 = org.apache.commons.math3.util.MathArrays.distance(var35, var39);
//     double var45 = org.apache.commons.math3.util.MathArrays.linearCombination(var20, var35);
//     boolean var46 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var20);
//     double[] var48 = org.apache.commons.math3.util.MathArrays.normalizeArray(var20, (-1.682916631768903d));
//     double[] var51 = new double[] { 100.0d, (-1.0d)};
//     double[] var54 = new double[] { 100.0d, 1.0d};
//     boolean var55 = org.apache.commons.math3.util.MathArrays.equals(var51, var54);
//     double[] var58 = new double[] { 100.0d, (-1.0d)};
//     double[] var61 = new double[] { 100.0d, 1.0d};
//     boolean var62 = org.apache.commons.math3.util.MathArrays.equals(var58, var61);
//     double var63 = org.apache.commons.math3.util.MathArrays.distance(var54, var58);
//     double[] var66 = new double[] { 100.0d, (-1.0d)};
//     double[] var69 = new double[] { 100.0d, 1.0d};
//     boolean var70 = org.apache.commons.math3.util.MathArrays.equals(var66, var69);
//     double[] var73 = new double[] { 100.0d, (-1.0d)};
//     double[] var76 = new double[] { 100.0d, 1.0d};
//     boolean var77 = org.apache.commons.math3.util.MathArrays.equals(var73, var76);
//     double var78 = org.apache.commons.math3.util.MathArrays.distance(var69, var73);
//     double var79 = org.apache.commons.math3.util.MathArrays.linearCombination(var54, var69);
//     double[] var80 = org.apache.commons.math3.util.MathArrays.ebeAdd(var48, var54);
//     double[] var83 = new double[] { 100.0d, (-1.0d)};
//     double[] var86 = new double[] { 100.0d, 1.0d};
//     boolean var87 = org.apache.commons.math3.util.MathArrays.equals(var83, var86);
//     double[] var90 = new double[] { 100.0d, (-1.0d)};
//     double[] var93 = new double[] { 100.0d, 1.0d};
//     boolean var94 = org.apache.commons.math3.util.MathArrays.equals(var90, var93);
//     double var95 = org.apache.commons.math3.util.MathArrays.distance(var86, var90);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var96 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var7, var54, var86);
//     double var98 = var96.cumulativeProbability(7239013.0522433d);
//     double var99 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var96);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 8.492012401520995d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 2.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == 2.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 10001.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var62 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == 2.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var70 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var77 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var78 == 2.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var79 == 10001.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var83);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var86);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var87 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var90);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var93);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var94 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var95 == 2.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var98 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var99 == 99.99999882208091d);
// 
//   }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1.0d, (java.lang.Number)10, true);
    org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var7 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var6);
    org.apache.commons.math3.util.Pair var8 = new org.apache.commons.math3.util.Pair((java.lang.Object)true, (java.lang.Object)var6);
    java.lang.Object var9 = var8.getSecond();
    double[] var12 = new double[] { 100.0d, (-1.0d)};
    double[] var15 = new double[] { 100.0d, 1.0d};
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var12, var15);
    double[] var19 = new double[] { 100.0d, (-1.0d)};
    double[] var22 = new double[] { 100.0d, 1.0d};
    boolean var23 = org.apache.commons.math3.util.MathArrays.equals(var19, var22);
    double var24 = org.apache.commons.math3.util.MathArrays.distance(var15, var19);
    double[] var27 = new double[] { 100.0d, (-1.0d)};
    double[] var30 = new double[] { 100.0d, 1.0d};
    boolean var31 = org.apache.commons.math3.util.MathArrays.equals(var27, var30);
    double[] var32 = org.apache.commons.math3.util.MathArrays.ebeDivide(var19, var27);
    boolean var33 = var8.equals((java.lang.Object)var32);
    double[] var35 = org.apache.commons.math3.util.MathArrays.copyOf(var32, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed((-1L));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var0.nextUniform(76.67195653183816d, 1.2694665049707192d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test268() {}
//   public void test268() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }
// 
// 
//     double[] var2 = new double[] { 100.0d, (-1.0d)};
//     double[] var5 = new double[] { 100.0d, 1.0d};
//     boolean var6 = org.apache.commons.math3.util.MathArrays.equals(var2, var5);
//     double[] var9 = new double[] { 100.0d, (-1.0d)};
//     double[] var12 = new double[] { 100.0d, 1.0d};
//     boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var9, var12);
//     double[] var16 = new double[] { 100.0d, (-1.0d)};
//     double[] var19 = new double[] { 100.0d, 1.0d};
//     boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var16, var19);
//     double[] var23 = new double[] { 100.0d, (-1.0d)};
//     double[] var26 = new double[] { 100.0d, 1.0d};
//     boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var23, var26);
//     double var28 = org.apache.commons.math3.util.MathArrays.distance(var19, var23);
//     double[] var31 = new double[] { 100.0d, (-1.0d)};
//     double[] var34 = new double[] { 100.0d, 1.0d};
//     boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var31, var34);
//     double[] var38 = new double[] { 100.0d, (-1.0d)};
//     double[] var41 = new double[] { 100.0d, 1.0d};
//     boolean var42 = org.apache.commons.math3.util.MathArrays.equals(var38, var41);
//     double var43 = org.apache.commons.math3.util.MathArrays.distance(var34, var38);
//     double var44 = org.apache.commons.math3.util.MathArrays.linearCombination(var19, var34);
//     boolean var45 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var9, var19);
//     double[] var47 = org.apache.commons.math3.util.MathArrays.normalizeArray(var19, (-1.682916631768903d));
//     double[] var48 = org.apache.commons.math3.util.MathArrays.ebeAdd(var5, var19);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var49 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var19, var49, false);
// 
//   }

  public void test269() {}
//   public void test269() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }
// 
// 
//     int[] var1 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(10L);
//     var4.setSeed(10);
//     int var8 = var4.nextInt(100);
//     int[] var10 = new int[] { (-1)};
//     int[] var11 = org.apache.commons.math3.util.MathArrays.copyOf(var10);
//     int[] var12 = org.apache.commons.math3.util.MathArrays.copyOf(var11);
//     var4.setSeed(var12);
//     int var14 = org.apache.commons.math3.util.MathArrays.distance1(var1, var12);
//     int[] var16 = new int[] { (-1)};
//     int[] var17 = org.apache.commons.math3.util.MathArrays.copyOf(var16);
//     int[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var17);
//     int var19 = org.apache.commons.math3.util.MathArrays.distance1(var12, var17);
//     int[] var20 = null;
//     int var21 = org.apache.commons.math3.util.MathArrays.distance1(var12, var20);
// 
//   }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    double[] var5 = new double[] { 100.0d, (-1.0d)};
    double[] var8 = new double[] { 100.0d, 1.0d};
    boolean var9 = org.apache.commons.math3.util.MathArrays.equals(var5, var8);
    double[] var12 = new double[] { 100.0d, (-1.0d)};
    double[] var15 = new double[] { 100.0d, 1.0d};
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var12, var15);
    double[] var19 = new double[] { 100.0d, (-1.0d)};
    double[] var22 = new double[] { 100.0d, 1.0d};
    boolean var23 = org.apache.commons.math3.util.MathArrays.equals(var19, var22);
    double var24 = org.apache.commons.math3.util.MathArrays.distance(var15, var19);
    double[] var27 = new double[] { 100.0d, (-1.0d)};
    double[] var30 = new double[] { 100.0d, 1.0d};
    boolean var31 = org.apache.commons.math3.util.MathArrays.equals(var27, var30);
    double[] var34 = new double[] { 100.0d, (-1.0d)};
    double[] var37 = new double[] { 100.0d, 1.0d};
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var34, var37);
    double var39 = org.apache.commons.math3.util.MathArrays.distance(var30, var34);
    double var40 = org.apache.commons.math3.util.MathArrays.linearCombination(var15, var30);
    boolean var41 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var5, var15);
    double[] var43 = org.apache.commons.math3.util.MathArrays.normalizeArray(var15, (-1.682916631768903d));
    double[] var46 = new double[] { 100.0d, (-1.0d)};
    double[] var49 = new double[] { 100.0d, 1.0d};
    boolean var50 = org.apache.commons.math3.util.MathArrays.equals(var46, var49);
    double[] var53 = new double[] { 100.0d, (-1.0d)};
    double[] var56 = new double[] { 100.0d, 1.0d};
    boolean var57 = org.apache.commons.math3.util.MathArrays.equals(var53, var56);
    double var58 = org.apache.commons.math3.util.MathArrays.distance(var49, var53);
    double[] var61 = new double[] { 100.0d, (-1.0d)};
    double[] var64 = new double[] { 100.0d, 1.0d};
    boolean var65 = org.apache.commons.math3.util.MathArrays.equals(var61, var64);
    double[] var68 = new double[] { 100.0d, (-1.0d)};
    double[] var71 = new double[] { 100.0d, 1.0d};
    boolean var72 = org.apache.commons.math3.util.MathArrays.equals(var68, var71);
    double var73 = org.apache.commons.math3.util.MathArrays.distance(var64, var68);
    double var74 = org.apache.commons.math3.util.MathArrays.linearCombination(var49, var64);
    double[] var75 = org.apache.commons.math3.util.MathArrays.ebeAdd(var43, var49);
    double[] var78 = new double[] { 100.0d, (-1.0d)};
    double[] var81 = new double[] { 100.0d, 1.0d};
    boolean var82 = org.apache.commons.math3.util.MathArrays.equals(var78, var81);
    double[] var85 = new double[] { 100.0d, (-1.0d)};
    double[] var88 = new double[] { 100.0d, 1.0d};
    boolean var89 = org.apache.commons.math3.util.MathArrays.equals(var85, var88);
    double var90 = org.apache.commons.math3.util.MathArrays.distance(var81, var85);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var91 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var2, var49, var81);
    double var93 = var91.density(111.37224047421323d);
    double var96 = var91.probability(0.0d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var96 == 0.0d);

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    var1.setSeed(10L);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var7 = var4.nextGamma(1.451238645107864E-9d, 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }


    long[] var1 = new long[] { 1L};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(-1.682916631768903d), (java.lang.Number)998139946, (java.lang.Number)(-1L));

  }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSecureAlgorithm("d", "046dac4c25");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }

  }

  public void test275() {}
//   public void test275() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     var1.setSeed(10);
//     boolean var4 = var1.nextBoolean();
//     java.util.List var5 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var6 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var5);
// 
//   }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-2.350538798101527d), (java.lang.Number)(-0.6858698665320467d), false);

  }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)10001.0d, (java.lang.Number)99.01980198019803d, true);

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    double[] var5 = new double[] { 100.0d, (-1.0d)};
    double[] var8 = new double[] { 100.0d, 1.0d};
    boolean var9 = org.apache.commons.math3.util.MathArrays.equals(var5, var8);
    double[] var12 = new double[] { 100.0d, (-1.0d)};
    double[] var15 = new double[] { 100.0d, 1.0d};
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var12, var15);
    double[] var19 = new double[] { 100.0d, (-1.0d)};
    double[] var22 = new double[] { 100.0d, 1.0d};
    boolean var23 = org.apache.commons.math3.util.MathArrays.equals(var19, var22);
    double var24 = org.apache.commons.math3.util.MathArrays.distance(var15, var19);
    double[] var27 = new double[] { 100.0d, (-1.0d)};
    double[] var30 = new double[] { 100.0d, 1.0d};
    boolean var31 = org.apache.commons.math3.util.MathArrays.equals(var27, var30);
    double[] var34 = new double[] { 100.0d, (-1.0d)};
    double[] var37 = new double[] { 100.0d, 1.0d};
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var34, var37);
    double var39 = org.apache.commons.math3.util.MathArrays.distance(var30, var34);
    double var40 = org.apache.commons.math3.util.MathArrays.linearCombination(var15, var30);
    boolean var41 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var5, var15);
    double[] var43 = org.apache.commons.math3.util.MathArrays.normalizeArray(var15, (-1.682916631768903d));
    double[] var46 = new double[] { 100.0d, (-1.0d)};
    double[] var49 = new double[] { 100.0d, 1.0d};
    boolean var50 = org.apache.commons.math3.util.MathArrays.equals(var46, var49);
    double[] var53 = new double[] { 100.0d, (-1.0d)};
    double[] var56 = new double[] { 100.0d, 1.0d};
    boolean var57 = org.apache.commons.math3.util.MathArrays.equals(var53, var56);
    double var58 = org.apache.commons.math3.util.MathArrays.distance(var49, var53);
    double[] var61 = new double[] { 100.0d, (-1.0d)};
    double[] var64 = new double[] { 100.0d, 1.0d};
    boolean var65 = org.apache.commons.math3.util.MathArrays.equals(var61, var64);
    double[] var68 = new double[] { 100.0d, (-1.0d)};
    double[] var71 = new double[] { 100.0d, 1.0d};
    boolean var72 = org.apache.commons.math3.util.MathArrays.equals(var68, var71);
    double var73 = org.apache.commons.math3.util.MathArrays.distance(var64, var68);
    double var74 = org.apache.commons.math3.util.MathArrays.linearCombination(var49, var64);
    double[] var75 = org.apache.commons.math3.util.MathArrays.ebeAdd(var43, var49);
    double[] var78 = new double[] { 100.0d, (-1.0d)};
    double[] var81 = new double[] { 100.0d, 1.0d};
    boolean var82 = org.apache.commons.math3.util.MathArrays.equals(var78, var81);
    double[] var85 = new double[] { 100.0d, (-1.0d)};
    double[] var88 = new double[] { 100.0d, 1.0d};
    boolean var89 = org.apache.commons.math3.util.MathArrays.equals(var85, var88);
    double var90 = org.apache.commons.math3.util.MathArrays.distance(var81, var85);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var91 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var2, var49, var81);
    double[] var92 = org.apache.commons.math3.util.MathArrays.copyOf(var49);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var92);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(1);
    double var2 = var1.nextDouble();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.2787313252014696d);

  }

  public void test280() {}
//   public void test280() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var5 = var2.nextSecureLong(0L, 1L);
//     var2.reSeed(6L);
//     double var10 = var2.nextGaussian(1.7523659290472708d, 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 2.581121805739166d);
// 
//   }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1.0d, (java.lang.Number)10, true);
    boolean var5 = var4.getBoundIsAllowed();
    org.apache.commons.math3.exception.util.ExceptionContext var6 = var4.getContext();
    java.lang.Number var7 = var4.getArgument();
    java.lang.Throwable[] var8 = var4.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 1.0d+ "'", var7.equals(1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var1 = null;
    org.apache.commons.math3.exception.MathArithmeticException var2 = new org.apache.commons.math3.exception.MathArithmeticException(var0, var1);
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var2.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var2.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }


    double[] var1 = new double[] { 10.0d};
    double var2 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    boolean var5 = org.apache.commons.math3.util.MathArrays.isMonotonic(var1, var3, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)6L, (java.lang.Number)3L, false);

  }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var5 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var1, (java.lang.Number)1.0d, (java.lang.Number)10, true);
    java.lang.Number var6 = var5.getMax();
    java.lang.Throwable[] var7 = var5.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var8 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.util.ExceptionContext var9 = var8.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 10+ "'", var6.equals(10));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test286() {}
//   public void test286() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextGaussian(0.0d, 2.0d);
//     var1.reSeedSecure(0L);
//     var1.reSeedSecure();
//     double var10 = var1.nextGaussian(2.0d, 2.0d);
//     double var12 = var1.nextExponential(99.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-2.8790720904868783d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 3.5880681118638957d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 3.52646337620062d);
// 
//   }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    var1.setSeed(10L);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var7 = var4.nextLong(6L, 0L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }


    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1L, (java.lang.Number)(-1), 1, var3, false);
    java.lang.Number var6 = var5.getPrevious();
    boolean var7 = var5.getStrict();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (-1)+ "'", var6.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    double[] var5 = new double[] { 100.0d, (-1.0d)};
    double[] var8 = new double[] { 100.0d, 1.0d};
    boolean var9 = org.apache.commons.math3.util.MathArrays.equals(var5, var8);
    double[] var12 = new double[] { 100.0d, (-1.0d)};
    double[] var15 = new double[] { 100.0d, 1.0d};
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var12, var15);
    double[] var19 = new double[] { 100.0d, (-1.0d)};
    double[] var22 = new double[] { 100.0d, 1.0d};
    boolean var23 = org.apache.commons.math3.util.MathArrays.equals(var19, var22);
    double var24 = org.apache.commons.math3.util.MathArrays.distance(var15, var19);
    double[] var27 = new double[] { 100.0d, (-1.0d)};
    double[] var30 = new double[] { 100.0d, 1.0d};
    boolean var31 = org.apache.commons.math3.util.MathArrays.equals(var27, var30);
    double[] var34 = new double[] { 100.0d, (-1.0d)};
    double[] var37 = new double[] { 100.0d, 1.0d};
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var34, var37);
    double var39 = org.apache.commons.math3.util.MathArrays.distance(var30, var34);
    double var40 = org.apache.commons.math3.util.MathArrays.linearCombination(var15, var30);
    boolean var41 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var5, var15);
    double[] var43 = org.apache.commons.math3.util.MathArrays.normalizeArray(var15, (-1.682916631768903d));
    double[] var46 = new double[] { 100.0d, (-1.0d)};
    double[] var49 = new double[] { 100.0d, 1.0d};
    boolean var50 = org.apache.commons.math3.util.MathArrays.equals(var46, var49);
    double[] var53 = new double[] { 100.0d, (-1.0d)};
    double[] var56 = new double[] { 100.0d, 1.0d};
    boolean var57 = org.apache.commons.math3.util.MathArrays.equals(var53, var56);
    double var58 = org.apache.commons.math3.util.MathArrays.distance(var49, var53);
    double[] var61 = new double[] { 100.0d, (-1.0d)};
    double[] var64 = new double[] { 100.0d, 1.0d};
    boolean var65 = org.apache.commons.math3.util.MathArrays.equals(var61, var64);
    double[] var68 = new double[] { 100.0d, (-1.0d)};
    double[] var71 = new double[] { 100.0d, 1.0d};
    boolean var72 = org.apache.commons.math3.util.MathArrays.equals(var68, var71);
    double var73 = org.apache.commons.math3.util.MathArrays.distance(var64, var68);
    double var74 = org.apache.commons.math3.util.MathArrays.linearCombination(var49, var64);
    double[] var75 = org.apache.commons.math3.util.MathArrays.ebeAdd(var43, var49);
    double[] var78 = new double[] { 100.0d, (-1.0d)};
    double[] var81 = new double[] { 100.0d, 1.0d};
    boolean var82 = org.apache.commons.math3.util.MathArrays.equals(var78, var81);
    double[] var85 = new double[] { 100.0d, (-1.0d)};
    double[] var88 = new double[] { 100.0d, 1.0d};
    boolean var89 = org.apache.commons.math3.util.MathArrays.equals(var85, var88);
    double var90 = org.apache.commons.math3.util.MathArrays.distance(var81, var85);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var91 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var2, var49, var81);
    double var93 = var91.density(111.37224047421323d);
    boolean var94 = var91.isSupportUpperBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var94 == true);

  }

  public void test290() {}
//   public void test290() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextT(10001.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var6 = var1.nextZipf(10, (-0.055195337499989006d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1.5203775038614646d));
// 
//   }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }


    long[][] var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkRectangular(var0);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }

  }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }


    double[] var2 = new double[] { 100.0d, (-1.0d)};
    double[] var5 = new double[] { 100.0d, 1.0d};
    boolean var6 = org.apache.commons.math3.util.MathArrays.equals(var2, var5);
    double[] var9 = new double[] { 100.0d, (-1.0d)};
    double[] var12 = new double[] { 100.0d, 1.0d};
    boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var9, var12);
    double[] var16 = new double[] { 100.0d, (-1.0d)};
    double[] var19 = new double[] { 100.0d, 1.0d};
    boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var16, var19);
    double[] var23 = new double[] { 100.0d, (-1.0d)};
    double[] var26 = new double[] { 100.0d, 1.0d};
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var23, var26);
    double var28 = org.apache.commons.math3.util.MathArrays.distance(var19, var23);
    double[] var31 = new double[] { 100.0d, (-1.0d)};
    double[] var34 = new double[] { 100.0d, 1.0d};
    boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var31, var34);
    double[] var38 = new double[] { 100.0d, (-1.0d)};
    double[] var41 = new double[] { 100.0d, 1.0d};
    boolean var42 = org.apache.commons.math3.util.MathArrays.equals(var38, var41);
    double var43 = org.apache.commons.math3.util.MathArrays.distance(var34, var38);
    double var44 = org.apache.commons.math3.util.MathArrays.linearCombination(var19, var34);
    boolean var45 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var9, var19);
    double[] var47 = org.apache.commons.math3.util.MathArrays.normalizeArray(var19, (-1.682916631768903d));
    double[] var48 = org.apache.commons.math3.util.MathArrays.ebeAdd(var5, var19);
    double[] var50 = org.apache.commons.math3.util.MathArrays.copyOf(var19, 0);
    double[] var53 = new double[] { 100.0d, (-1.0d)};
    double[] var56 = new double[] { 100.0d, 1.0d};
    boolean var57 = org.apache.commons.math3.util.MathArrays.equals(var53, var56);
    double[] var60 = new double[] { 100.0d, (-1.0d)};
    double[] var63 = new double[] { 100.0d, 1.0d};
    boolean var64 = org.apache.commons.math3.util.MathArrays.equals(var60, var63);
    double[] var67 = new double[] { 100.0d, (-1.0d)};
    double[] var70 = new double[] { 100.0d, 1.0d};
    boolean var71 = org.apache.commons.math3.util.MathArrays.equals(var67, var70);
    double var72 = org.apache.commons.math3.util.MathArrays.distance(var63, var67);
    double[] var75 = new double[] { 100.0d, (-1.0d)};
    double[] var78 = new double[] { 100.0d, 1.0d};
    boolean var79 = org.apache.commons.math3.util.MathArrays.equals(var75, var78);
    double[] var82 = new double[] { 100.0d, (-1.0d)};
    double[] var85 = new double[] { 100.0d, 1.0d};
    boolean var86 = org.apache.commons.math3.util.MathArrays.equals(var82, var85);
    double var87 = org.apache.commons.math3.util.MathArrays.distance(var78, var82);
    double var88 = org.apache.commons.math3.util.MathArrays.linearCombination(var63, var78);
    boolean var89 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var53, var63);
    double[] var91 = org.apache.commons.math3.util.MathArrays.normalizeArray(var63, (-1.682916631768903d));
    boolean var92 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var50, var91);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var94 = org.apache.commons.math3.util.MathArrays.normalizeArray(var50, (-16832.484962999133d));
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == false);

  }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }


    double[] var2 = new double[] { 100.0d, (-1.0d)};
    double[] var5 = new double[] { 100.0d, 1.0d};
    boolean var6 = org.apache.commons.math3.util.MathArrays.equals(var2, var5);
    double[] var9 = new double[] { 100.0d, (-1.0d)};
    double[] var12 = new double[] { 100.0d, 1.0d};
    boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var9, var12);
    double var14 = org.apache.commons.math3.util.MathArrays.distance(var5, var9);
    double[] var17 = new double[] { 100.0d, (-1.0d)};
    double[] var20 = new double[] { 100.0d, 1.0d};
    boolean var21 = org.apache.commons.math3.util.MathArrays.equals(var17, var20);
    double[] var24 = new double[] { 100.0d, (-1.0d)};
    double[] var27 = new double[] { 100.0d, 1.0d};
    boolean var28 = org.apache.commons.math3.util.MathArrays.equals(var24, var27);
    double[] var31 = new double[] { 100.0d, (-1.0d)};
    double[] var34 = new double[] { 100.0d, 1.0d};
    boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var31, var34);
    double var36 = org.apache.commons.math3.util.MathArrays.distance(var27, var31);
    double[] var39 = new double[] { 100.0d, (-1.0d)};
    double[] var42 = new double[] { 100.0d, 1.0d};
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var39, var42);
    double[] var46 = new double[] { 100.0d, (-1.0d)};
    double[] var49 = new double[] { 100.0d, 1.0d};
    boolean var50 = org.apache.commons.math3.util.MathArrays.equals(var46, var49);
    double var51 = org.apache.commons.math3.util.MathArrays.distance(var42, var46);
    double var52 = org.apache.commons.math3.util.MathArrays.linearCombination(var27, var42);
    boolean var53 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var17, var27);
    double[] var55 = org.apache.commons.math3.util.MathArrays.normalizeArray(var27, (-1.682916631768903d));
    org.apache.commons.math3.distribution.DiscreteRealDistribution var56 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var9, var27);
    boolean var57 = var56.isSupportConnected();
    double var58 = var56.sample();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 100.0d);

  }

  public void test294() {}
//   public void test294() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextGaussian(10.0d, 2.0d);
//     int var7 = var1.nextInt(0, 1);
//     var1.reSeed(0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var1.nextBeta((-0.7314779623383547d), 96.07881580237154d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 8.97623861959745d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
// 
//   }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setSecureAlgorithm("046dac4c25", "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test296() {}
//   public void test296() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var5 = var1.nextUniform((-0.03786377777366967d), 0.5650828929145241d, true);
//     double var8 = var1.nextUniform((-0.7844030186481109d), 96.07881580237154d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var1.nextZipf((-1), 0.8761829645236354d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.04595480653468004d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 95.89661429451364d);
// 
//   }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(864L);

  }

  public void test298() {}
//   public void test298() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }
// 
// 
//     double[] var2 = new double[] { 100.0d, (-1.0d)};
//     double[] var5 = new double[] { 100.0d, 1.0d};
//     boolean var6 = org.apache.commons.math3.util.MathArrays.equals(var2, var5);
//     double[] var9 = new double[] { 100.0d, (-1.0d)};
//     double[] var12 = new double[] { 100.0d, 1.0d};
//     boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var9, var12);
//     double[] var16 = new double[] { 100.0d, (-1.0d)};
//     double[] var19 = new double[] { 100.0d, 1.0d};
//     boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var16, var19);
//     double var21 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
//     double[] var24 = new double[] { 100.0d, (-1.0d)};
//     double[] var27 = new double[] { 100.0d, 1.0d};
//     boolean var28 = org.apache.commons.math3.util.MathArrays.equals(var24, var27);
//     double[] var31 = new double[] { 100.0d, (-1.0d)};
//     double[] var34 = new double[] { 100.0d, 1.0d};
//     boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var31, var34);
//     double var36 = org.apache.commons.math3.util.MathArrays.distance(var27, var31);
//     double var37 = org.apache.commons.math3.util.MathArrays.linearCombination(var12, var27);
//     boolean var38 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var2, var12);
//     double[] var41 = new double[] { 100.0d, (-1.0d)};
//     double[] var44 = new double[] { 100.0d, 1.0d};
//     boolean var45 = org.apache.commons.math3.util.MathArrays.equals(var41, var44);
//     double[] var48 = new double[] { 100.0d, (-1.0d)};
//     double[] var51 = new double[] { 100.0d, 1.0d};
//     boolean var52 = org.apache.commons.math3.util.MathArrays.equals(var48, var51);
//     double var53 = org.apache.commons.math3.util.MathArrays.distance(var44, var48);
//     double[] var56 = new double[] { 100.0d, (-1.0d)};
//     double[] var59 = new double[] { 100.0d, 1.0d};
//     boolean var60 = org.apache.commons.math3.util.MathArrays.equals(var56, var59);
//     double[] var61 = org.apache.commons.math3.util.MathArrays.ebeDivide(var48, var56);
//     double[] var64 = new double[] { 100.0d, (-1.0d)};
//     double[] var67 = new double[] { 100.0d, 1.0d};
//     boolean var68 = org.apache.commons.math3.util.MathArrays.equals(var64, var67);
//     double[] var71 = new double[] { 100.0d, (-1.0d)};
//     double[] var74 = new double[] { 100.0d, 1.0d};
//     boolean var75 = org.apache.commons.math3.util.MathArrays.equals(var71, var74);
//     double var76 = org.apache.commons.math3.util.MathArrays.distance(var67, var71);
//     double[] var79 = new double[] { 100.0d, (-1.0d)};
//     double[] var82 = new double[] { 100.0d, 1.0d};
//     boolean var83 = org.apache.commons.math3.util.MathArrays.equals(var79, var82);
//     double[] var84 = org.apache.commons.math3.util.MathArrays.ebeDivide(var71, var79);
//     double[] var85 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var56, var84);
//     double[] var86 = org.apache.commons.math3.util.MathArrays.ebeAdd(var12, var84);
//     double[] var87 = null;
//     double var88 = org.apache.commons.math3.util.MathArrays.distance(var86, var87);
// 
//   }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed((-1L));
    var0.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var6 = var0.nextBinomial(2147483647, 10.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }

  }

  public void test300() {}
//   public void test300() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed((-1L));
//     var0.reSeed();
//     var0.reSeedSecure(6L);
//     long var8 = var0.nextLong(1L, 9L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 6L);
// 
//   }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var3 = var1.nextDouble();
    var1.setSeed(10L);
    int var6 = var1.nextInt();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.40877566087838346d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1755678109);

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    double[] var5 = new double[] { 100.0d, (-1.0d)};
    double[] var8 = new double[] { 100.0d, 1.0d};
    boolean var9 = org.apache.commons.math3.util.MathArrays.equals(var5, var8);
    double[] var12 = new double[] { 100.0d, (-1.0d)};
    double[] var15 = new double[] { 100.0d, 1.0d};
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var12, var15);
    double[] var19 = new double[] { 100.0d, (-1.0d)};
    double[] var22 = new double[] { 100.0d, 1.0d};
    boolean var23 = org.apache.commons.math3.util.MathArrays.equals(var19, var22);
    double var24 = org.apache.commons.math3.util.MathArrays.distance(var15, var19);
    double[] var27 = new double[] { 100.0d, (-1.0d)};
    double[] var30 = new double[] { 100.0d, 1.0d};
    boolean var31 = org.apache.commons.math3.util.MathArrays.equals(var27, var30);
    double[] var34 = new double[] { 100.0d, (-1.0d)};
    double[] var37 = new double[] { 100.0d, 1.0d};
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var34, var37);
    double var39 = org.apache.commons.math3.util.MathArrays.distance(var30, var34);
    double var40 = org.apache.commons.math3.util.MathArrays.linearCombination(var15, var30);
    boolean var41 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var5, var15);
    double[] var43 = org.apache.commons.math3.util.MathArrays.normalizeArray(var15, (-1.682916631768903d));
    double[] var46 = new double[] { 100.0d, (-1.0d)};
    double[] var49 = new double[] { 100.0d, 1.0d};
    boolean var50 = org.apache.commons.math3.util.MathArrays.equals(var46, var49);
    double[] var53 = new double[] { 100.0d, (-1.0d)};
    double[] var56 = new double[] { 100.0d, 1.0d};
    boolean var57 = org.apache.commons.math3.util.MathArrays.equals(var53, var56);
    double var58 = org.apache.commons.math3.util.MathArrays.distance(var49, var53);
    double[] var61 = new double[] { 100.0d, (-1.0d)};
    double[] var64 = new double[] { 100.0d, 1.0d};
    boolean var65 = org.apache.commons.math3.util.MathArrays.equals(var61, var64);
    double[] var68 = new double[] { 100.0d, (-1.0d)};
    double[] var71 = new double[] { 100.0d, 1.0d};
    boolean var72 = org.apache.commons.math3.util.MathArrays.equals(var68, var71);
    double var73 = org.apache.commons.math3.util.MathArrays.distance(var64, var68);
    double var74 = org.apache.commons.math3.util.MathArrays.linearCombination(var49, var64);
    double[] var75 = org.apache.commons.math3.util.MathArrays.ebeAdd(var43, var49);
    double[] var78 = new double[] { 100.0d, (-1.0d)};
    double[] var81 = new double[] { 100.0d, 1.0d};
    boolean var82 = org.apache.commons.math3.util.MathArrays.equals(var78, var81);
    double[] var85 = new double[] { 100.0d, (-1.0d)};
    double[] var88 = new double[] { 100.0d, 1.0d};
    boolean var89 = org.apache.commons.math3.util.MathArrays.equals(var85, var88);
    double var90 = org.apache.commons.math3.util.MathArrays.distance(var81, var85);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var91 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var2, var49, var81);
    boolean var92 = var91.isSupportConnected();
    double var93 = var91.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == 96.07881580237154d);

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed((-1L));
    int[] var5 = var0.nextPermutation(100, 30);
    double var8 = var0.nextCauchy(0.19389798955545332d, 0.19743013148352145d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var11 = var0.nextWeibull(80739.49636849186d, (-16832.484962999133d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-0.055195337499989006d));

  }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }


    double[] var2 = new double[] { 100.0d, (-1.0d)};
    double[] var5 = new double[] { 100.0d, 1.0d};
    boolean var6 = org.apache.commons.math3.util.MathArrays.equals(var2, var5);
    double[] var8 = new double[] { 10.0d};
    double var9 = org.apache.commons.math3.util.MathArrays.safeNorm(var8);
    org.apache.commons.math3.util.MathArrays.OrderDirection var10 = null;
    boolean var12 = org.apache.commons.math3.util.MathArrays.isMonotonic(var8, var10, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var13 = org.apache.commons.math3.util.MathArrays.distanceInf(var5, var8);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);

  }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }


    double[] var2 = new double[] { 100.0d, (-1.0d)};
    double[] var5 = new double[] { 100.0d, 1.0d};
    boolean var6 = org.apache.commons.math3.util.MathArrays.equals(var2, var5);
    double[] var9 = new double[] { 100.0d, (-1.0d)};
    double[] var12 = new double[] { 100.0d, 1.0d};
    boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var9, var12);
    double[] var16 = new double[] { 100.0d, (-1.0d)};
    double[] var19 = new double[] { 100.0d, 1.0d};
    boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var16, var19);
    double var21 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double[] var24 = new double[] { 100.0d, (-1.0d)};
    double[] var27 = new double[] { 100.0d, 1.0d};
    boolean var28 = org.apache.commons.math3.util.MathArrays.equals(var24, var27);
    double[] var31 = new double[] { 100.0d, (-1.0d)};
    double[] var34 = new double[] { 100.0d, 1.0d};
    boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var31, var34);
    double var36 = org.apache.commons.math3.util.MathArrays.distance(var27, var31);
    double var37 = org.apache.commons.math3.util.MathArrays.linearCombination(var12, var27);
    boolean var38 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var2, var12);
    double[] var40 = org.apache.commons.math3.util.MathArrays.normalizeArray(var12, (-1.682916631768903d));
    double[] var43 = new double[] { 100.0d, (-1.0d)};
    double[] var46 = new double[] { 100.0d, 1.0d};
    boolean var47 = org.apache.commons.math3.util.MathArrays.equals(var43, var46);
    double[] var50 = new double[] { 100.0d, (-1.0d)};
    double[] var53 = new double[] { 100.0d, 1.0d};
    boolean var54 = org.apache.commons.math3.util.MathArrays.equals(var50, var53);
    double var55 = org.apache.commons.math3.util.MathArrays.distance(var46, var50);
    double[] var58 = new double[] { 100.0d, (-1.0d)};
    double[] var61 = new double[] { 100.0d, 1.0d};
    boolean var62 = org.apache.commons.math3.util.MathArrays.equals(var58, var61);
    double[] var65 = new double[] { 100.0d, (-1.0d)};
    double[] var68 = new double[] { 100.0d, 1.0d};
    boolean var69 = org.apache.commons.math3.util.MathArrays.equals(var65, var68);
    double var70 = org.apache.commons.math3.util.MathArrays.distance(var61, var65);
    double var71 = org.apache.commons.math3.util.MathArrays.linearCombination(var46, var61);
    double[] var72 = org.apache.commons.math3.util.MathArrays.ebeAdd(var40, var46);
    org.apache.commons.math3.util.MathArrays.checkOrder(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);

  }

  public void test306() {}
//   public void test306() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     long var6 = var2.nextLong((-1L), 10L);
//     var2.reSeedSecure(6L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var2.nextInt(0, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 4L);
// 
//   }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)0.0f);
    java.lang.Number var3 = var2.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
    var1.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var5 = var1.nextZipf(0, (-2.1148810308778625d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextPascal(86, 0.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var8 = var2.nextPermutation(28, 998139946);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2147483647);

  }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed((-1L));
    var0.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var7 = var0.nextUniform(0.6115651382182169d, 0.15328243612779968d, true);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }


    double[] var2 = new double[] { 100.0d, (-1.0d)};
    double[] var5 = new double[] { 100.0d, 1.0d};
    boolean var6 = org.apache.commons.math3.util.MathArrays.equals(var2, var5);
    double[] var9 = new double[] { 100.0d, (-1.0d)};
    double[] var12 = new double[] { 100.0d, 1.0d};
    boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var9, var12);
    double var14 = org.apache.commons.math3.util.MathArrays.distance(var5, var9);
    double[] var17 = new double[] { 100.0d, (-1.0d)};
    double[] var20 = new double[] { 100.0d, 1.0d};
    boolean var21 = org.apache.commons.math3.util.MathArrays.equals(var17, var20);
    double[] var24 = new double[] { 100.0d, (-1.0d)};
    double[] var27 = new double[] { 100.0d, 1.0d};
    boolean var28 = org.apache.commons.math3.util.MathArrays.equals(var24, var27);
    double[] var31 = new double[] { 100.0d, (-1.0d)};
    double[] var34 = new double[] { 100.0d, 1.0d};
    boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var31, var34);
    double var36 = org.apache.commons.math3.util.MathArrays.distance(var27, var31);
    double[] var39 = new double[] { 100.0d, (-1.0d)};
    double[] var42 = new double[] { 100.0d, 1.0d};
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var39, var42);
    double[] var46 = new double[] { 100.0d, (-1.0d)};
    double[] var49 = new double[] { 100.0d, 1.0d};
    boolean var50 = org.apache.commons.math3.util.MathArrays.equals(var46, var49);
    double var51 = org.apache.commons.math3.util.MathArrays.distance(var42, var46);
    double var52 = org.apache.commons.math3.util.MathArrays.linearCombination(var27, var42);
    boolean var53 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var17, var27);
    double[] var55 = org.apache.commons.math3.util.MathArrays.normalizeArray(var27, (-1.682916631768903d));
    org.apache.commons.math3.distribution.DiscreteRealDistribution var56 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var9, var27);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var9);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);

  }

  public void test312() {}
//   public void test312() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextGaussian(0.0d, 2.0d);
//     var1.reSeedSecure(0L);
//     double var9 = var1.nextWeibull(2.0d, 9854048.12570597d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var1.nextGamma(0.2323975705328034d, (-0.03786377777366967d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-1.1356519015823674d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 7511123.900235617d);
// 
//   }

  public void test313() {}
//   public void test313() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }
// 
// 
//     double[] var2 = new double[] { 100.0d, (-1.0d)};
//     double[] var5 = new double[] { 100.0d, 1.0d};
//     boolean var6 = org.apache.commons.math3.util.MathArrays.equals(var2, var5);
//     double[] var9 = new double[] { 100.0d, (-1.0d)};
//     double[] var12 = new double[] { 100.0d, 1.0d};
//     boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var9, var12);
//     double var14 = org.apache.commons.math3.util.MathArrays.distance(var5, var9);
//     double[] var17 = new double[] { 100.0d, (-1.0d)};
//     double[] var20 = new double[] { 100.0d, 1.0d};
//     boolean var21 = org.apache.commons.math3.util.MathArrays.equals(var17, var20);
//     double[] var22 = org.apache.commons.math3.util.MathArrays.ebeDivide(var9, var17);
//     double[] var25 = new double[] { 100.0d, (-1.0d)};
//     double[] var28 = new double[] { 100.0d, 1.0d};
//     boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var25, var28);
//     double[] var32 = new double[] { 100.0d, (-1.0d)};
//     double[] var35 = new double[] { 100.0d, 1.0d};
//     boolean var36 = org.apache.commons.math3.util.MathArrays.equals(var32, var35);
//     double var37 = org.apache.commons.math3.util.MathArrays.distance(var28, var32);
//     double[] var40 = new double[] { 100.0d, (-1.0d)};
//     double[] var43 = new double[] { 100.0d, 1.0d};
//     boolean var44 = org.apache.commons.math3.util.MathArrays.equals(var40, var43);
//     double[] var45 = org.apache.commons.math3.util.MathArrays.ebeDivide(var32, var40);
//     double[] var46 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var17, var45);
//     double[] var47 = null;
//     double var48 = org.apache.commons.math3.util.MathArrays.distance1(var46, var47);
// 
//   }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    double[] var5 = new double[] { 100.0d, (-1.0d)};
    double[] var8 = new double[] { 100.0d, 1.0d};
    boolean var9 = org.apache.commons.math3.util.MathArrays.equals(var5, var8);
    double[] var12 = new double[] { 100.0d, (-1.0d)};
    double[] var15 = new double[] { 100.0d, 1.0d};
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var12, var15);
    double[] var19 = new double[] { 100.0d, (-1.0d)};
    double[] var22 = new double[] { 100.0d, 1.0d};
    boolean var23 = org.apache.commons.math3.util.MathArrays.equals(var19, var22);
    double var24 = org.apache.commons.math3.util.MathArrays.distance(var15, var19);
    double[] var27 = new double[] { 100.0d, (-1.0d)};
    double[] var30 = new double[] { 100.0d, 1.0d};
    boolean var31 = org.apache.commons.math3.util.MathArrays.equals(var27, var30);
    double[] var34 = new double[] { 100.0d, (-1.0d)};
    double[] var37 = new double[] { 100.0d, 1.0d};
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var34, var37);
    double var39 = org.apache.commons.math3.util.MathArrays.distance(var30, var34);
    double var40 = org.apache.commons.math3.util.MathArrays.linearCombination(var15, var30);
    boolean var41 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var5, var15);
    double[] var43 = org.apache.commons.math3.util.MathArrays.normalizeArray(var15, (-1.682916631768903d));
    double[] var46 = new double[] { 100.0d, (-1.0d)};
    double[] var49 = new double[] { 100.0d, 1.0d};
    boolean var50 = org.apache.commons.math3.util.MathArrays.equals(var46, var49);
    double[] var53 = new double[] { 100.0d, (-1.0d)};
    double[] var56 = new double[] { 100.0d, 1.0d};
    boolean var57 = org.apache.commons.math3.util.MathArrays.equals(var53, var56);
    double var58 = org.apache.commons.math3.util.MathArrays.distance(var49, var53);
    double[] var61 = new double[] { 100.0d, (-1.0d)};
    double[] var64 = new double[] { 100.0d, 1.0d};
    boolean var65 = org.apache.commons.math3.util.MathArrays.equals(var61, var64);
    double[] var68 = new double[] { 100.0d, (-1.0d)};
    double[] var71 = new double[] { 100.0d, 1.0d};
    boolean var72 = org.apache.commons.math3.util.MathArrays.equals(var68, var71);
    double var73 = org.apache.commons.math3.util.MathArrays.distance(var64, var68);
    double var74 = org.apache.commons.math3.util.MathArrays.linearCombination(var49, var64);
    double[] var75 = org.apache.commons.math3.util.MathArrays.ebeAdd(var43, var49);
    double[] var78 = new double[] { 100.0d, (-1.0d)};
    double[] var81 = new double[] { 100.0d, 1.0d};
    boolean var82 = org.apache.commons.math3.util.MathArrays.equals(var78, var81);
    double[] var85 = new double[] { 100.0d, (-1.0d)};
    double[] var88 = new double[] { 100.0d, 1.0d};
    boolean var89 = org.apache.commons.math3.util.MathArrays.equals(var85, var88);
    double var90 = org.apache.commons.math3.util.MathArrays.distance(var81, var85);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var91 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var2, var49, var81);
    double var93 = var91.cumulativeProbability(3.31077097012213d);
    boolean var94 = var91.isSupportUpperBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == 0.009900990099009901d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var94 == true);

  }

  public void test315() {}
//   public void test315() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextGaussian(0.0d, 2.0d);
//     var1.reSeedSecure(0L);
//     var1.reSeedSecure();
//     double var10 = var1.nextGaussian(2.0d, 2.0d);
//     var1.reSeed();
//     long var14 = var1.nextLong(1L, 10L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var16 = var1.nextT((-0.7314779623383547d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-1.231787851892023d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5.779113531293843d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 4L);
// 
//   }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Object[] var6 = new java.lang.Object[] { 10.0d};
    org.apache.commons.math3.exception.NullArgumentException var7 = new org.apache.commons.math3.exception.NullArgumentException(var4, var6);
    org.apache.commons.math3.exception.MathIllegalArgumentException var8 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, var6);
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var2, var6);
    org.apache.commons.math3.exception.MathArithmeticException var10 = new org.apache.commons.math3.exception.MathArithmeticException(var1, var6);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var0, var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.util.MathArrays.OrderDirection var4 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var6 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1L, (java.lang.Number)(-1), 1, var4, false);
    java.lang.String var7 = var6.toString();
    java.lang.Throwable[] var8 = var6.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "org.apache.commons.math3.exception.NonMonotonicSequenceException: points 0 and 1 are not decreasing (-1 < 1)"+ "'", var7.equals("org.apache.commons.math3.exception.NonMonotonicSequenceException: points 0 and 1 are not decreasing (-1 < 1)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    long[] var1 = new long[] { };
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var1);
    long[][] var3 = new long[][] { var1};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var3);
    org.apache.commons.math3.exception.MathIllegalArgumentException var5 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var3);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(-2.350538798101527d), (java.lang.Number)86, true);
    java.lang.Number var5 = var4.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 86+ "'", var5.equals(86));

  }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    long[] var4 = new long[] { };
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var4);
    long[][] var6 = new long[][] { var4};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var6);
    org.apache.commons.math3.exception.MathIllegalArgumentException var8 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var2, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.NotFiniteNumberException var10 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)99, (java.lang.Object[])var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test321() {}
//   public void test321() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)7506849.916132723d, (java.lang.Number)1.0f, (java.lang.Number)86);
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     java.lang.Object[] var7 = new java.lang.Object[] { 10.0d};
//     org.apache.commons.math3.exception.NullArgumentException var8 = new org.apache.commons.math3.exception.NullArgumentException(var5, var7);
//     var4.addSuppressed((java.lang.Throwable)var8);
//     java.lang.Number var10 = var4.getLo();
//     java.lang.Number var11 = var4.getArgument();
//     org.apache.commons.math3.exception.MathInternalError var12 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var4);
// 
//   }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed((-1L));
    var0.reSeed();
    var0.reSeed(100L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var0.nextF(1687.9702609361561d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }


    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)2.0d, (java.lang.Object)(byte)(-1));
    java.lang.Object var3 = var2.getSecond();
    java.lang.Object var4 = var2.getSecond();
    org.apache.commons.math3.util.Pair var5 = new org.apache.commons.math3.util.Pair(var2);
    java.lang.Object var6 = var2.getKey();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + (byte)(-1)+ "'", var3.equals((byte)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (byte)(-1)+ "'", var4.equals((byte)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 2.0d+ "'", var6.equals(2.0d));

  }

  public void test324() {}
//   public void test324() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextGaussian(0.0d, 2.0d);
//     var1.reSeedSecure(0L);
//     var1.reSeedSecure();
//     double var10 = var1.nextGaussian(2.0d, 2.0d);
//     java.util.Collection var11 = null;
//     java.lang.Object[] var13 = var1.nextSample(var11, 224787129);
// 
//   }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }


    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)2.0d, (java.lang.Object)(byte)(-1));
    java.lang.Object var3 = var2.getSecond();
    java.lang.Object var4 = var2.getKey();
    java.lang.Object var5 = var2.getFirst();
    org.apache.commons.math3.util.Pair var6 = new org.apache.commons.math3.util.Pair(var2);
    java.lang.Object var7 = var2.getSecond();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + (byte)(-1)+ "'", var3.equals((byte)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 2.0d+ "'", var4.equals(2.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 2.0d+ "'", var5.equals(2.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (byte)(-1)+ "'", var7.equals((byte)(-1)));

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    double[] var5 = new double[] { 100.0d, (-1.0d)};
    double[] var8 = new double[] { 100.0d, 1.0d};
    boolean var9 = org.apache.commons.math3.util.MathArrays.equals(var5, var8);
    double[] var12 = new double[] { 100.0d, (-1.0d)};
    double[] var15 = new double[] { 100.0d, 1.0d};
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var12, var15);
    double[] var19 = new double[] { 100.0d, (-1.0d)};
    double[] var22 = new double[] { 100.0d, 1.0d};
    boolean var23 = org.apache.commons.math3.util.MathArrays.equals(var19, var22);
    double var24 = org.apache.commons.math3.util.MathArrays.distance(var15, var19);
    double[] var27 = new double[] { 100.0d, (-1.0d)};
    double[] var30 = new double[] { 100.0d, 1.0d};
    boolean var31 = org.apache.commons.math3.util.MathArrays.equals(var27, var30);
    double[] var34 = new double[] { 100.0d, (-1.0d)};
    double[] var37 = new double[] { 100.0d, 1.0d};
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var34, var37);
    double var39 = org.apache.commons.math3.util.MathArrays.distance(var30, var34);
    double var40 = org.apache.commons.math3.util.MathArrays.linearCombination(var15, var30);
    boolean var41 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var5, var15);
    double[] var43 = org.apache.commons.math3.util.MathArrays.normalizeArray(var15, (-1.682916631768903d));
    double[] var46 = new double[] { 100.0d, (-1.0d)};
    double[] var49 = new double[] { 100.0d, 1.0d};
    boolean var50 = org.apache.commons.math3.util.MathArrays.equals(var46, var49);
    double[] var53 = new double[] { 100.0d, (-1.0d)};
    double[] var56 = new double[] { 100.0d, 1.0d};
    boolean var57 = org.apache.commons.math3.util.MathArrays.equals(var53, var56);
    double var58 = org.apache.commons.math3.util.MathArrays.distance(var49, var53);
    double[] var61 = new double[] { 100.0d, (-1.0d)};
    double[] var64 = new double[] { 100.0d, 1.0d};
    boolean var65 = org.apache.commons.math3.util.MathArrays.equals(var61, var64);
    double[] var68 = new double[] { 100.0d, (-1.0d)};
    double[] var71 = new double[] { 100.0d, 1.0d};
    boolean var72 = org.apache.commons.math3.util.MathArrays.equals(var68, var71);
    double var73 = org.apache.commons.math3.util.MathArrays.distance(var64, var68);
    double var74 = org.apache.commons.math3.util.MathArrays.linearCombination(var49, var64);
    double[] var75 = org.apache.commons.math3.util.MathArrays.ebeAdd(var43, var49);
    double[] var78 = new double[] { 100.0d, (-1.0d)};
    double[] var81 = new double[] { 100.0d, 1.0d};
    boolean var82 = org.apache.commons.math3.util.MathArrays.equals(var78, var81);
    double[] var85 = new double[] { 100.0d, (-1.0d)};
    double[] var88 = new double[] { 100.0d, 1.0d};
    boolean var89 = org.apache.commons.math3.util.MathArrays.equals(var85, var88);
    double var90 = org.apache.commons.math3.util.MathArrays.distance(var81, var85);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var91 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var2, var49, var81);
    double var93 = var91.density(0.0d);
    double var94 = var91.getSupportUpperBound();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var97 = var91.cumulativeProbability(11.4447253818428d, 0.5650828929145241d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var94 == 100.0d);

  }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    var1.setSeed(10L);
    int var5 = var1.nextInt(10);
    org.apache.commons.math3.random.RandomDataImpl var6 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var7 = var1.nextDouble();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.2323975705328034d);

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeedSecure(10L);
    double var7 = var2.nextBeta(11.4447253818428d, 99.9999988872748d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var2.nextGaussian(0.15328243612779968d, (-1.682916631768903d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.09387795525619293d);

  }

  public void test329() {}
//   public void test329() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextT(10001.0d);
//     long var6 = var1.nextLong((-1L), 3L);
//     org.apache.commons.math3.distribution.IntegerDistribution var7 = null;
//     int var8 = var1.nextInversionDeviate(var7);
// 
//   }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }


    double[] var2 = new double[] { 100.0d, (-1.0d)};
    double[] var5 = new double[] { 100.0d, 1.0d};
    boolean var6 = org.apache.commons.math3.util.MathArrays.equals(var2, var5);
    double[] var9 = new double[] { 100.0d, (-1.0d)};
    double[] var12 = new double[] { 100.0d, 1.0d};
    boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var9, var12);
    double var14 = org.apache.commons.math3.util.MathArrays.distance(var5, var9);
    double[] var17 = new double[] { 100.0d, (-1.0d)};
    double[] var20 = new double[] { 100.0d, 1.0d};
    boolean var21 = org.apache.commons.math3.util.MathArrays.equals(var17, var20);
    double[] var24 = new double[] { 100.0d, (-1.0d)};
    double[] var27 = new double[] { 100.0d, 1.0d};
    boolean var28 = org.apache.commons.math3.util.MathArrays.equals(var24, var27);
    double var29 = org.apache.commons.math3.util.MathArrays.distance(var20, var24);
    double[] var32 = new double[] { 100.0d, (-1.0d)};
    double[] var35 = new double[] { 100.0d, 1.0d};
    boolean var36 = org.apache.commons.math3.util.MathArrays.equals(var32, var35);
    double[] var37 = org.apache.commons.math3.util.MathArrays.ebeDivide(var24, var32);
    double[] var40 = new double[] { 100.0d, (-1.0d)};
    double[] var43 = new double[] { 100.0d, 1.0d};
    boolean var44 = org.apache.commons.math3.util.MathArrays.equals(var40, var43);
    double[] var47 = new double[] { 100.0d, (-1.0d)};
    double[] var50 = new double[] { 100.0d, 1.0d};
    boolean var51 = org.apache.commons.math3.util.MathArrays.equals(var47, var50);
    double var52 = org.apache.commons.math3.util.MathArrays.distance(var43, var47);
    double[] var55 = new double[] { 100.0d, (-1.0d)};
    double[] var58 = new double[] { 100.0d, 1.0d};
    boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var55, var58);
    double[] var60 = org.apache.commons.math3.util.MathArrays.ebeDivide(var47, var55);
    double[] var61 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var32, var60);
    double var62 = org.apache.commons.math3.util.MathArrays.distanceInf(var9, var60);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var60);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 99.0d);

  }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }


    double[] var2 = new double[] { 100.0d, (-1.0d)};
    double[] var5 = new double[] { 100.0d, 1.0d};
    boolean var6 = org.apache.commons.math3.util.MathArrays.equals(var2, var5);
    double[] var9 = new double[] { 100.0d, (-1.0d)};
    double[] var12 = new double[] { 100.0d, 1.0d};
    boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var9, var12);
    double var14 = org.apache.commons.math3.util.MathArrays.distance(var5, var9);
    double[] var17 = new double[] { 100.0d, (-1.0d)};
    double[] var20 = new double[] { 100.0d, 1.0d};
    boolean var21 = org.apache.commons.math3.util.MathArrays.equals(var17, var20);
    double[] var24 = new double[] { 100.0d, (-1.0d)};
    double[] var27 = new double[] { 100.0d, 1.0d};
    boolean var28 = org.apache.commons.math3.util.MathArrays.equals(var24, var27);
    double var29 = org.apache.commons.math3.util.MathArrays.distance(var20, var24);
    double var30 = org.apache.commons.math3.util.MathArrays.linearCombination(var5, var20);
    double[] var32 = org.apache.commons.math3.util.MathArrays.normalizeArray(var5, 0.0d);
    double var33 = org.apache.commons.math3.util.MathArrays.safeNorm(var32);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var32);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    double var2 = var1.nextDouble();
    org.apache.commons.math3.random.RandomDataImpl var3 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.40877566087838346d);

  }

  public void test333() {}
//   public void test333() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure();
//     long var4 = var0.nextSecureLong((-1L), 7L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var7 = var0.nextWeibull(0.32973134850766805d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1L);
// 
//   }

  public void test334() {}
//   public void test334() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var5 = var2.nextSecureLong(0L, 1L);
//     var2.reSeed(6L);
//     double var9 = var2.nextT(2.027380293984852d);
//     var2.reSeedSecure(3L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.123200103709113d);
// 
//   }

  public void test335() {}
//   public void test335() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextGaussian(10.0d, 2.0d);
//     int var7 = var1.nextInt(0, 1);
//     double var10 = var1.nextGamma(13.226435756113098d, 99.01980198019803d);
//     java.util.Collection var11 = null;
//     java.lang.Object[] var13 = var1.nextSample(var11, 0);
// 
//   }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-10101.0d), (java.lang.Number)0.09387795525619293d, false);
    boolean var4 = var3.getBoundIsAllowed();
    boolean var5 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var5 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var1, (java.lang.Number)1.0d, (java.lang.Number)10, true);
    java.lang.Number var6 = var5.getMax();
    java.lang.Throwable[] var7 = var5.getSuppressed();
    org.apache.commons.math3.exception.MathInternalError var8 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 10+ "'", var6.equals(10));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test338() {}
//   public void test338() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }
// 
// 
//     double[] var0 = null;
//     org.apache.commons.math3.util.MathArrays.OrderDirection var1 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var0, var1, false);
// 
//   }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }


    double[] var2 = new double[] { 100.0d, (-1.0d)};
    double[] var5 = new double[] { 100.0d, 1.0d};
    boolean var6 = org.apache.commons.math3.util.MathArrays.equals(var2, var5);
    double[] var9 = new double[] { 100.0d, (-1.0d)};
    double[] var12 = new double[] { 100.0d, 1.0d};
    boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var9, var12);
    double[] var16 = new double[] { 100.0d, (-1.0d)};
    double[] var19 = new double[] { 100.0d, 1.0d};
    boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var16, var19);
    double[] var23 = new double[] { 100.0d, (-1.0d)};
    double[] var26 = new double[] { 100.0d, 1.0d};
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var23, var26);
    double var28 = org.apache.commons.math3.util.MathArrays.distance(var19, var23);
    double[] var31 = new double[] { 100.0d, (-1.0d)};
    double[] var34 = new double[] { 100.0d, 1.0d};
    boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var31, var34);
    double[] var38 = new double[] { 100.0d, (-1.0d)};
    double[] var41 = new double[] { 100.0d, 1.0d};
    boolean var42 = org.apache.commons.math3.util.MathArrays.equals(var38, var41);
    double var43 = org.apache.commons.math3.util.MathArrays.distance(var34, var38);
    double var44 = org.apache.commons.math3.util.MathArrays.linearCombination(var19, var34);
    boolean var45 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var9, var19);
    double[] var47 = org.apache.commons.math3.util.MathArrays.normalizeArray(var19, (-1.682916631768903d));
    double[] var48 = org.apache.commons.math3.util.MathArrays.ebeAdd(var5, var19);
    double[] var51 = new double[] { 100.0d, (-1.0d)};
    double[] var54 = new double[] { 100.0d, 1.0d};
    boolean var55 = org.apache.commons.math3.util.MathArrays.equals(var51, var54);
    double[] var58 = new double[] { 100.0d, (-1.0d)};
    double[] var61 = new double[] { 100.0d, 1.0d};
    boolean var62 = org.apache.commons.math3.util.MathArrays.equals(var58, var61);
    double var63 = org.apache.commons.math3.util.MathArrays.distance(var54, var58);
    double[] var66 = new double[] { 100.0d, (-1.0d)};
    double[] var69 = new double[] { 100.0d, 1.0d};
    boolean var70 = org.apache.commons.math3.util.MathArrays.equals(var66, var69);
    double[] var71 = org.apache.commons.math3.util.MathArrays.ebeDivide(var58, var66);
    double[] var74 = new double[] { 100.0d, (-1.0d)};
    double[] var77 = new double[] { 100.0d, 1.0d};
    boolean var78 = org.apache.commons.math3.util.MathArrays.equals(var74, var77);
    double[] var81 = new double[] { 100.0d, (-1.0d)};
    double[] var84 = new double[] { 100.0d, 1.0d};
    boolean var85 = org.apache.commons.math3.util.MathArrays.equals(var81, var84);
    double var86 = org.apache.commons.math3.util.MathArrays.distance(var77, var81);
    double[] var89 = new double[] { 100.0d, (-1.0d)};
    double[] var92 = new double[] { 100.0d, 1.0d};
    boolean var93 = org.apache.commons.math3.util.MathArrays.equals(var89, var92);
    double[] var94 = org.apache.commons.math3.util.MathArrays.ebeDivide(var81, var89);
    double[] var95 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var66, var94);
    double var96 = org.apache.commons.math3.util.MathArrays.linearCombination(var5, var95);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var95);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var96 == 9898.0d);

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(short)1);

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }


    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.NotPositiveException var3 = new org.apache.commons.math3.exception.NotPositiveException(var1, (java.lang.Number)(-1.0d));
    org.apache.commons.math3.util.Pair var4 = new org.apache.commons.math3.util.Pair((java.lang.Object)4L, (java.lang.Object)var1);

  }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }


    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)2.0d, (java.lang.Object)(byte)(-1));
    java.lang.Object var3 = var2.getSecond();
    java.lang.Object var4 = var2.getKey();
    java.lang.Object var5 = var2.getFirst();
    java.lang.Object var6 = var2.getValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + (byte)(-1)+ "'", var3.equals((byte)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 2.0d+ "'", var4.equals(2.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 2.0d+ "'", var5.equals(2.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (byte)(-1)+ "'", var6.equals((byte)(-1)));

  }

  public void test343() {}
//   public void test343() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextGaussian(0.0d, 2.0d);
//     java.lang.String var6 = var1.nextHexString(10);
//     long var8 = var1.nextPoisson(0.40877566087838346d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var1.nextF(111.37224047421323d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-0.830718695633615d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "bedbe59d22"+ "'", var6.equals("bedbe59d22"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0L);
// 
//   }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }


    double[] var1 = new double[] { 1.0d};
    double[] var4 = new double[] { 100.0d, (-1.0d)};
    double[] var7 = new double[] { 100.0d, 1.0d};
    boolean var8 = org.apache.commons.math3.util.MathArrays.equals(var4, var7);
    double[] var11 = new double[] { 100.0d, (-1.0d)};
    double[] var14 = new double[] { 100.0d, 1.0d};
    boolean var15 = org.apache.commons.math3.util.MathArrays.equals(var11, var14);
    double[] var18 = new double[] { 100.0d, (-1.0d)};
    double[] var21 = new double[] { 100.0d, 1.0d};
    boolean var22 = org.apache.commons.math3.util.MathArrays.equals(var18, var21);
    double var23 = org.apache.commons.math3.util.MathArrays.distance(var14, var18);
    double[] var26 = new double[] { 100.0d, (-1.0d)};
    double[] var29 = new double[] { 100.0d, 1.0d};
    boolean var30 = org.apache.commons.math3.util.MathArrays.equals(var26, var29);
    double[] var33 = new double[] { 100.0d, (-1.0d)};
    double[] var36 = new double[] { 100.0d, 1.0d};
    boolean var37 = org.apache.commons.math3.util.MathArrays.equals(var33, var36);
    double var38 = org.apache.commons.math3.util.MathArrays.distance(var29, var33);
    double var39 = org.apache.commons.math3.util.MathArrays.linearCombination(var14, var29);
    boolean var40 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var4, var14);
    double[] var43 = new double[] { 100.0d, (-1.0d)};
    double[] var46 = new double[] { 100.0d, 1.0d};
    boolean var47 = org.apache.commons.math3.util.MathArrays.equals(var43, var46);
    double[] var50 = new double[] { 100.0d, (-1.0d)};
    double[] var53 = new double[] { 100.0d, 1.0d};
    boolean var54 = org.apache.commons.math3.util.MathArrays.equals(var50, var53);
    double var55 = org.apache.commons.math3.util.MathArrays.distance(var46, var50);
    double[] var58 = new double[] { 100.0d, (-1.0d)};
    double[] var61 = new double[] { 100.0d, 1.0d};
    boolean var62 = org.apache.commons.math3.util.MathArrays.equals(var58, var61);
    double[] var63 = org.apache.commons.math3.util.MathArrays.ebeDivide(var50, var58);
    double[] var66 = new double[] { 100.0d, (-1.0d)};
    double[] var69 = new double[] { 100.0d, 1.0d};
    boolean var70 = org.apache.commons.math3.util.MathArrays.equals(var66, var69);
    double[] var73 = new double[] { 100.0d, (-1.0d)};
    double[] var76 = new double[] { 100.0d, 1.0d};
    boolean var77 = org.apache.commons.math3.util.MathArrays.equals(var73, var76);
    double var78 = org.apache.commons.math3.util.MathArrays.distance(var69, var73);
    double[] var81 = new double[] { 100.0d, (-1.0d)};
    double[] var84 = new double[] { 100.0d, 1.0d};
    boolean var85 = org.apache.commons.math3.util.MathArrays.equals(var81, var84);
    double[] var86 = org.apache.commons.math3.util.MathArrays.ebeDivide(var73, var81);
    double[] var87 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var58, var86);
    double[] var88 = org.apache.commons.math3.util.MathArrays.ebeAdd(var14, var86);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var89 = org.apache.commons.math3.util.MathArrays.linearCombination(var1, var14);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var6 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)86, (java.lang.Number)1L, true);
    java.lang.Throwable[] var7 = var6.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var8 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Number)1.0f, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var7);
    java.lang.Throwable[] var10 = var9.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test346() {}
//   public void test346() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }
// 
// 
//     double[] var0 = null;
//     double[] var3 = new double[] { 100.0d, (-1.0d)};
//     double[] var6 = new double[] { 100.0d, 1.0d};
//     boolean var7 = org.apache.commons.math3.util.MathArrays.equals(var3, var6);
//     double[] var10 = new double[] { 100.0d, (-1.0d)};
//     double[] var13 = new double[] { 100.0d, 1.0d};
//     boolean var14 = org.apache.commons.math3.util.MathArrays.equals(var10, var13);
//     double[] var17 = new double[] { 100.0d, (-1.0d)};
//     double[] var20 = new double[] { 100.0d, 1.0d};
//     boolean var21 = org.apache.commons.math3.util.MathArrays.equals(var17, var20);
//     double var22 = org.apache.commons.math3.util.MathArrays.distance(var13, var17);
//     double[] var25 = new double[] { 100.0d, (-1.0d)};
//     double[] var28 = new double[] { 100.0d, 1.0d};
//     boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var25, var28);
//     double[] var32 = new double[] { 100.0d, (-1.0d)};
//     double[] var35 = new double[] { 100.0d, 1.0d};
//     boolean var36 = org.apache.commons.math3.util.MathArrays.equals(var32, var35);
//     double var37 = org.apache.commons.math3.util.MathArrays.distance(var28, var32);
//     double var38 = org.apache.commons.math3.util.MathArrays.linearCombination(var13, var28);
//     boolean var39 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var13);
//     double[] var41 = org.apache.commons.math3.util.MathArrays.normalizeArray(var13, (-1.682916631768903d));
//     double[] var44 = new double[] { 100.0d, (-1.0d)};
//     double[] var47 = new double[] { 100.0d, 1.0d};
//     boolean var48 = org.apache.commons.math3.util.MathArrays.equals(var44, var47);
//     double[] var51 = new double[] { 100.0d, (-1.0d)};
//     double[] var54 = new double[] { 100.0d, 1.0d};
//     boolean var55 = org.apache.commons.math3.util.MathArrays.equals(var51, var54);
//     double var56 = org.apache.commons.math3.util.MathArrays.distance(var47, var51);
//     double[] var59 = new double[] { 100.0d, (-1.0d)};
//     double[] var62 = new double[] { 100.0d, 1.0d};
//     boolean var63 = org.apache.commons.math3.util.MathArrays.equals(var59, var62);
//     double[] var64 = org.apache.commons.math3.util.MathArrays.ebeDivide(var51, var59);
//     double[] var65 = org.apache.commons.math3.util.MathArrays.ebeDivide(var13, var59);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var66 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var0, var13);
// 
//   }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }


    int[] var1 = new int[] { (-1)};
    int[] var2 = org.apache.commons.math3.util.MathArrays.copyOf(var1);
    int[] var4 = new int[] { (-1)};
    int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
    int var6 = org.apache.commons.math3.util.MathArrays.distanceInf(var2, var4);
    org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(var4);
    org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(var4);
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(var4);
    boolean var10 = var9.nextBoolean();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    var1.setSeed(10L);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var4.nextChiSquare(1.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var4.nextT((-0.7314779623383547d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2884362901949524d);

  }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)7506849.916132723d, (java.lang.Number)1.0f, (java.lang.Number)86);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    java.lang.Object[] var7 = new java.lang.Object[] { 10.0d};
    org.apache.commons.math3.exception.NullArgumentException var8 = new org.apache.commons.math3.exception.NullArgumentException(var5, var7);
    var4.addSuppressed((java.lang.Throwable)var8);
    java.lang.Number var10 = var4.getLo();
    java.lang.Number var11 = var4.getHi();
    org.apache.commons.math3.exception.NumberIsTooSmallException var15 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)86, (java.lang.Number)1L, true);
    java.lang.Throwable[] var16 = var15.getSuppressed();
    var4.addSuppressed((java.lang.Throwable)var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + 1.0f+ "'", var10.equals(1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + 86+ "'", var11.equals(86));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test350() {}
//   public void test350() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var3 = var1.nextDouble();
//     int var5 = var1.nextInt(998139946);
//     org.apache.commons.math3.random.RandomDataImpl var6 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var9 = var6.nextSecureInt(1, 28);
//     java.lang.String var11 = var6.nextSecureHexString(16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.40877566087838346d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 224787129);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "975a1ce676c0954a"+ "'", var11.equals("975a1ce676c0954a"));
// 
//   }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)10, (java.lang.Number)3L, (java.lang.Number)1.0f);
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var3.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var3 = var1.nextDouble();
    int var5 = var1.nextInt(998139946);
    org.apache.commons.math3.random.RandomDataImpl var6 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var9 = var6.nextWeibull(13.90833488952869d, (-2555.7647705813442d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.40877566087838346d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 224787129);

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, var1, (java.lang.Number)3.5880681118638957d, (java.lang.Number)(-1.6478376658157248d));

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)8.492012401520995d, (java.lang.Number)(-10101.0d));

  }

  public void test355() {}
//   public void test355() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextT(10001.0d);
//     long var6 = var1.nextLong((-1L), 3L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var9 = var1.nextInt(4, (-1));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.5415137097072861d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0L);
// 
//   }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    double[] var5 = new double[] { 100.0d, (-1.0d)};
    double[] var8 = new double[] { 100.0d, 1.0d};
    boolean var9 = org.apache.commons.math3.util.MathArrays.equals(var5, var8);
    double[] var12 = new double[] { 100.0d, (-1.0d)};
    double[] var15 = new double[] { 100.0d, 1.0d};
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var12, var15);
    double[] var19 = new double[] { 100.0d, (-1.0d)};
    double[] var22 = new double[] { 100.0d, 1.0d};
    boolean var23 = org.apache.commons.math3.util.MathArrays.equals(var19, var22);
    double var24 = org.apache.commons.math3.util.MathArrays.distance(var15, var19);
    double[] var27 = new double[] { 100.0d, (-1.0d)};
    double[] var30 = new double[] { 100.0d, 1.0d};
    boolean var31 = org.apache.commons.math3.util.MathArrays.equals(var27, var30);
    double[] var34 = new double[] { 100.0d, (-1.0d)};
    double[] var37 = new double[] { 100.0d, 1.0d};
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var34, var37);
    double var39 = org.apache.commons.math3.util.MathArrays.distance(var30, var34);
    double var40 = org.apache.commons.math3.util.MathArrays.linearCombination(var15, var30);
    boolean var41 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var5, var15);
    double[] var43 = org.apache.commons.math3.util.MathArrays.normalizeArray(var15, (-1.682916631768903d));
    double[] var46 = new double[] { 100.0d, (-1.0d)};
    double[] var49 = new double[] { 100.0d, 1.0d};
    boolean var50 = org.apache.commons.math3.util.MathArrays.equals(var46, var49);
    double[] var53 = new double[] { 100.0d, (-1.0d)};
    double[] var56 = new double[] { 100.0d, 1.0d};
    boolean var57 = org.apache.commons.math3.util.MathArrays.equals(var53, var56);
    double var58 = org.apache.commons.math3.util.MathArrays.distance(var49, var53);
    double[] var61 = new double[] { 100.0d, (-1.0d)};
    double[] var64 = new double[] { 100.0d, 1.0d};
    boolean var65 = org.apache.commons.math3.util.MathArrays.equals(var61, var64);
    double[] var68 = new double[] { 100.0d, (-1.0d)};
    double[] var71 = new double[] { 100.0d, 1.0d};
    boolean var72 = org.apache.commons.math3.util.MathArrays.equals(var68, var71);
    double var73 = org.apache.commons.math3.util.MathArrays.distance(var64, var68);
    double var74 = org.apache.commons.math3.util.MathArrays.linearCombination(var49, var64);
    double[] var75 = org.apache.commons.math3.util.MathArrays.ebeAdd(var43, var49);
    double[] var78 = new double[] { 100.0d, (-1.0d)};
    double[] var81 = new double[] { 100.0d, 1.0d};
    boolean var82 = org.apache.commons.math3.util.MathArrays.equals(var78, var81);
    double[] var85 = new double[] { 100.0d, (-1.0d)};
    double[] var88 = new double[] { 100.0d, 1.0d};
    boolean var89 = org.apache.commons.math3.util.MathArrays.equals(var85, var88);
    double var90 = org.apache.commons.math3.util.MathArrays.distance(var81, var85);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var91 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var2, var49, var81);
    boolean var92 = var91.isSupportConnected();
    boolean var93 = var91.isSupportConnected();
    double var96 = var91.probability(2.6669397224844205d, 3.31077097012213d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var96 == 0.0d);

  }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, var1);
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.NotPositiveException var5 = new org.apache.commons.math3.exception.NotPositiveException(var3, (java.lang.Number)100L);
    java.lang.Number var6 = var5.getMin();
    var2.addSuppressed((java.lang.Throwable)var5);
    org.apache.commons.math3.exception.util.ExceptionContext var8 = var5.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 0+ "'", var6.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test358() {}
//   public void test358() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 669834927, 2147483647);
// 
//   }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(1);
    int[] var3 = new int[] { (-1)};
    int[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
    int[] var6 = new int[] { (-1)};
    int[] var7 = org.apache.commons.math3.util.MathArrays.copyOf(var6);
    int[] var9 = new int[] { (-1)};
    int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var9);
    int var11 = org.apache.commons.math3.util.MathArrays.distanceInf(var7, var9);
    int var12 = org.apache.commons.math3.util.MathArrays.distanceInf(var4, var9);
    var1.setSeed(var9);
    int[] var15 = new int[] { (-1)};
    int[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var15);
    int[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var16, 86);
    int var19 = org.apache.commons.math3.util.MathArrays.distanceInf(var9, var18);
    org.apache.commons.math3.random.Well19937c var21 = new org.apache.commons.math3.random.Well19937c(1);
    int[] var23 = new int[] { (-1)};
    int[] var24 = org.apache.commons.math3.util.MathArrays.copyOf(var23);
    int[] var26 = new int[] { (-1)};
    int[] var27 = org.apache.commons.math3.util.MathArrays.copyOf(var26);
    int[] var29 = new int[] { (-1)};
    int[] var30 = org.apache.commons.math3.util.MathArrays.copyOf(var29);
    int var31 = org.apache.commons.math3.util.MathArrays.distanceInf(var27, var29);
    int var32 = org.apache.commons.math3.util.MathArrays.distanceInf(var24, var29);
    var21.setSeed(var29);
    int[] var35 = new int[] { (-1)};
    int[] var36 = org.apache.commons.math3.util.MathArrays.copyOf(var35);
    int[] var38 = org.apache.commons.math3.util.MathArrays.copyOf(var36, 86);
    int var39 = org.apache.commons.math3.util.MathArrays.distanceInf(var29, var38);
    int var40 = org.apache.commons.math3.util.MathArrays.distanceInf(var9, var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0);

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }


    double[] var1 = new double[] { 10.0d};
    double var2 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    boolean var5 = org.apache.commons.math3.util.MathArrays.isMonotonic(var1, var3, false);
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
    boolean var9 = org.apache.commons.math3.util.MathArrays.checkOrder(var1, var6, false, true);
    double[] var12 = new double[] { 100.0d, (-1.0d)};
    double[] var15 = new double[] { 100.0d, 1.0d};
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var12, var15);
    double[] var19 = new double[] { 100.0d, (-1.0d)};
    double[] var22 = new double[] { 100.0d, 1.0d};
    boolean var23 = org.apache.commons.math3.util.MathArrays.equals(var19, var22);
    double[] var26 = new double[] { 100.0d, (-1.0d)};
    double[] var29 = new double[] { 100.0d, 1.0d};
    boolean var30 = org.apache.commons.math3.util.MathArrays.equals(var26, var29);
    double var31 = org.apache.commons.math3.util.MathArrays.distance(var22, var26);
    double[] var34 = new double[] { 100.0d, (-1.0d)};
    double[] var37 = new double[] { 100.0d, 1.0d};
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var34, var37);
    double[] var41 = new double[] { 100.0d, (-1.0d)};
    double[] var44 = new double[] { 100.0d, 1.0d};
    boolean var45 = org.apache.commons.math3.util.MathArrays.equals(var41, var44);
    double var46 = org.apache.commons.math3.util.MathArrays.distance(var37, var41);
    double var47 = org.apache.commons.math3.util.MathArrays.linearCombination(var22, var37);
    boolean var48 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var12, var22);
    double[] var50 = org.apache.commons.math3.util.MathArrays.normalizeArray(var22, (-1.682916631768903d));
    double[] var53 = new double[] { 100.0d, (-1.0d)};
    double[] var56 = new double[] { 100.0d, 1.0d};
    boolean var57 = org.apache.commons.math3.util.MathArrays.equals(var53, var56);
    double[] var60 = new double[] { 100.0d, (-1.0d)};
    double[] var63 = new double[] { 100.0d, 1.0d};
    boolean var64 = org.apache.commons.math3.util.MathArrays.equals(var60, var63);
    double var65 = org.apache.commons.math3.util.MathArrays.distance(var56, var60);
    double[] var68 = new double[] { 100.0d, (-1.0d)};
    double[] var71 = new double[] { 100.0d, 1.0d};
    boolean var72 = org.apache.commons.math3.util.MathArrays.equals(var68, var71);
    double[] var73 = org.apache.commons.math3.util.MathArrays.ebeDivide(var60, var68);
    double[] var74 = org.apache.commons.math3.util.MathArrays.ebeDivide(var22, var68);
    boolean var75 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var1, var68);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkPositive(var68);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == false);

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)1.451238645107864E-9d);

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }


    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1L, (java.lang.Number)(-1), 1, var3, false);
    java.lang.Number var6 = var5.getPrevious();
    int var7 = var5.getIndex();
    int var8 = var5.getIndex();
    int var9 = var5.getIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (-1)+ "'", var6.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);

  }

  public void test363() {}
//   public void test363() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }
// 
// 
//     double[] var0 = null;
//     double[] var3 = new double[] { 100.0d, (-1.0d)};
//     double[] var6 = new double[] { 100.0d, 1.0d};
//     boolean var7 = org.apache.commons.math3.util.MathArrays.equals(var3, var6);
//     double[] var10 = new double[] { 100.0d, (-1.0d)};
//     double[] var13 = new double[] { 100.0d, 1.0d};
//     boolean var14 = org.apache.commons.math3.util.MathArrays.equals(var10, var13);
//     double var15 = org.apache.commons.math3.util.MathArrays.distance(var6, var10);
//     double[] var18 = new double[] { 100.0d, (-1.0d)};
//     double[] var21 = new double[] { 100.0d, 1.0d};
//     boolean var22 = org.apache.commons.math3.util.MathArrays.equals(var18, var21);
//     double[] var25 = new double[] { 100.0d, (-1.0d)};
//     double[] var28 = new double[] { 100.0d, 1.0d};
//     boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var25, var28);
//     double var30 = org.apache.commons.math3.util.MathArrays.distance(var21, var25);
//     double var31 = org.apache.commons.math3.util.MathArrays.linearCombination(var6, var21);
//     boolean var32 = org.apache.commons.math3.util.MathArrays.equals(var0, var6);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var33 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var0, var33, false);
// 
//   }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    var1.setSeed(10);
    int var5 = var1.nextInt(100);
    double var6 = var1.nextGaussian();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 86);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.041888119963332d);

  }

  public void test365() {}
//   public void test365() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 10, 669834927);
// 
//   }

  public void test366() {}
//   public void test366() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(3.31077097012213d);
//     double var5 = var1.nextExponential(92.26337525222011d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.9684160642989688d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 118.34791728453098d);
// 
//   }

  public void test367() {}
//   public void test367() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextGaussian(0.0d, 2.0d);
//     java.lang.String var6 = var1.nextHexString(10);
//     java.util.Collection var7 = null;
//     java.lang.Object[] var9 = var1.nextSample(var7, 0);
// 
//   }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, var1, (java.lang.Number)(byte)0, true);
    java.lang.Number var5 = var4.getMin();
    org.apache.commons.math3.exception.util.ExceptionContext var6 = var4.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (byte)0+ "'", var5.equals((byte)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }


    int[] var1 = new int[] { (-1)};
    int[] var2 = org.apache.commons.math3.util.MathArrays.copyOf(var1);
    int[] var4 = new int[] { (-1)};
    int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
    int var6 = org.apache.commons.math3.util.MathArrays.distanceInf(var2, var4);
    int[] var7 = org.apache.commons.math3.util.MathArrays.copyOf(var2);
    int[] var9 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var10 = new org.apache.commons.math3.random.Well19937c(var9);
    org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(10L);
    var12.setSeed(10);
    int var16 = var12.nextInt(100);
    int[] var18 = new int[] { (-1)};
    int[] var19 = org.apache.commons.math3.util.MathArrays.copyOf(var18);
    int[] var20 = org.apache.commons.math3.util.MathArrays.copyOf(var19);
    var12.setSeed(var20);
    int var22 = org.apache.commons.math3.util.MathArrays.distance1(var9, var20);
    int var23 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1);

  }

  public void test370() {}
//   public void test370() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextT(10001.0d);
//     double var6 = var1.nextF(0.09387795525619293d, 0.009900990099009901d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.4178627725837282d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.4991537467049955E15d);
// 
//   }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(1.2694665049707192d, 8.418185040882479d, 3.5880681118638957d, (-0.6858698665320467d), (-0.5770298507560749d), 7506849.916132723d, 99.9999988872748d, (-0.5770298507560749d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-4331725.964082607d));

  }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)2035706397, (java.lang.Number)669834927, (java.lang.Number)(-1.1440322521572115d));

  }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }


    float[] var0 = new float[] { };
    float[] var3 = new float[] { 100.0f, 100.0f};
    boolean var4 = org.apache.commons.math3.util.MathArrays.equals(var0, var3);
    float[] var7 = new float[] { 10.0f, (-1.0f)};
    boolean var8 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var7);
    float[] var9 = new float[] { };
    float[] var12 = new float[] { 100.0f, 100.0f};
    boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var9, var12);
    float[] var16 = new float[] { 10.0f, (-1.0f)};
    boolean var17 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var12, var16);
    boolean var18 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);

  }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }


    double[] var1 = new double[] { 10.0d};
    double var2 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    boolean var5 = org.apache.commons.math3.util.MathArrays.isMonotonic(var1, var3, false);
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
    boolean var9 = org.apache.commons.math3.util.MathArrays.checkOrder(var1, var6, false, true);
    double[] var12 = new double[] { 100.0d, (-1.0d)};
    double[] var15 = new double[] { 100.0d, 1.0d};
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var12, var15);
    double[] var19 = new double[] { 100.0d, (-1.0d)};
    double[] var22 = new double[] { 100.0d, 1.0d};
    boolean var23 = org.apache.commons.math3.util.MathArrays.equals(var19, var22);
    double[] var26 = new double[] { 100.0d, (-1.0d)};
    double[] var29 = new double[] { 100.0d, 1.0d};
    boolean var30 = org.apache.commons.math3.util.MathArrays.equals(var26, var29);
    double var31 = org.apache.commons.math3.util.MathArrays.distance(var22, var26);
    double[] var34 = new double[] { 100.0d, (-1.0d)};
    double[] var37 = new double[] { 100.0d, 1.0d};
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var34, var37);
    double[] var41 = new double[] { 100.0d, (-1.0d)};
    double[] var44 = new double[] { 100.0d, 1.0d};
    boolean var45 = org.apache.commons.math3.util.MathArrays.equals(var41, var44);
    double var46 = org.apache.commons.math3.util.MathArrays.distance(var37, var41);
    double var47 = org.apache.commons.math3.util.MathArrays.linearCombination(var22, var37);
    boolean var48 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var12, var22);
    double[] var50 = org.apache.commons.math3.util.MathArrays.normalizeArray(var22, (-1.682916631768903d));
    double[] var53 = new double[] { 100.0d, (-1.0d)};
    double[] var56 = new double[] { 100.0d, 1.0d};
    boolean var57 = org.apache.commons.math3.util.MathArrays.equals(var53, var56);
    double[] var60 = new double[] { 100.0d, (-1.0d)};
    double[] var63 = new double[] { 100.0d, 1.0d};
    boolean var64 = org.apache.commons.math3.util.MathArrays.equals(var60, var63);
    double var65 = org.apache.commons.math3.util.MathArrays.distance(var56, var60);
    double[] var68 = new double[] { 100.0d, (-1.0d)};
    double[] var71 = new double[] { 100.0d, 1.0d};
    boolean var72 = org.apache.commons.math3.util.MathArrays.equals(var68, var71);
    double[] var73 = org.apache.commons.math3.util.MathArrays.ebeDivide(var60, var68);
    double[] var74 = org.apache.commons.math3.util.MathArrays.ebeDivide(var22, var68);
    boolean var75 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var1, var68);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var68);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == false);

  }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }


    double[] var2 = new double[] { 100.0d, (-1.0d)};
    double[] var5 = new double[] { 100.0d, 1.0d};
    boolean var6 = org.apache.commons.math3.util.MathArrays.equals(var2, var5);
    double[] var9 = new double[] { 100.0d, (-1.0d)};
    double[] var12 = new double[] { 100.0d, 1.0d};
    boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var9, var12);
    double var14 = org.apache.commons.math3.util.MathArrays.distance(var5, var9);
    double[] var17 = new double[] { 100.0d, (-1.0d)};
    double[] var20 = new double[] { 100.0d, 1.0d};
    boolean var21 = org.apache.commons.math3.util.MathArrays.equals(var17, var20);
    double[] var24 = new double[] { 100.0d, (-1.0d)};
    double[] var27 = new double[] { 100.0d, 1.0d};
    boolean var28 = org.apache.commons.math3.util.MathArrays.equals(var24, var27);
    double[] var31 = new double[] { 100.0d, (-1.0d)};
    double[] var34 = new double[] { 100.0d, 1.0d};
    boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var31, var34);
    double var36 = org.apache.commons.math3.util.MathArrays.distance(var27, var31);
    double[] var39 = new double[] { 100.0d, (-1.0d)};
    double[] var42 = new double[] { 100.0d, 1.0d};
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var39, var42);
    double[] var46 = new double[] { 100.0d, (-1.0d)};
    double[] var49 = new double[] { 100.0d, 1.0d};
    boolean var50 = org.apache.commons.math3.util.MathArrays.equals(var46, var49);
    double var51 = org.apache.commons.math3.util.MathArrays.distance(var42, var46);
    double var52 = org.apache.commons.math3.util.MathArrays.linearCombination(var27, var42);
    boolean var53 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var17, var27);
    double var54 = org.apache.commons.math3.util.MathArrays.distanceInf(var5, var17);
    double[] var57 = new double[] { 100.0d, (-1.0d)};
    double[] var60 = new double[] { 100.0d, 1.0d};
    boolean var61 = org.apache.commons.math3.util.MathArrays.equals(var57, var60);
    double[] var62 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var5, var57);
    double[] var64 = org.apache.commons.math3.util.MathArrays.normalizeArray(var62, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);

  }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }


    org.apache.commons.math3.exception.MathInternalError var0 = new org.apache.commons.math3.exception.MathInternalError();
    org.apache.commons.math3.exception.util.ExceptionContext var1 = var0.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }


    double[] var2 = new double[] { 100.0d, (-1.0d)};
    double[] var5 = new double[] { 100.0d, 1.0d};
    boolean var6 = org.apache.commons.math3.util.MathArrays.equals(var2, var5);
    double[] var9 = new double[] { 100.0d, (-1.0d)};
    double[] var12 = new double[] { 100.0d, 1.0d};
    boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var9, var12);
    double[] var16 = new double[] { 100.0d, (-1.0d)};
    double[] var19 = new double[] { 100.0d, 1.0d};
    boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var16, var19);
    double var21 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double[] var24 = new double[] { 100.0d, (-1.0d)};
    double[] var27 = new double[] { 100.0d, 1.0d};
    boolean var28 = org.apache.commons.math3.util.MathArrays.equals(var24, var27);
    double[] var31 = new double[] { 100.0d, (-1.0d)};
    double[] var34 = new double[] { 100.0d, 1.0d};
    boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var31, var34);
    double var36 = org.apache.commons.math3.util.MathArrays.distance(var27, var31);
    double var37 = org.apache.commons.math3.util.MathArrays.linearCombination(var12, var27);
    boolean var38 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var2, var12);
    double[] var40 = org.apache.commons.math3.util.MathArrays.normalizeArray(var12, (-1.682916631768903d));
    double[] var43 = new double[] { 100.0d, (-1.0d)};
    double[] var46 = new double[] { 100.0d, 1.0d};
    boolean var47 = org.apache.commons.math3.util.MathArrays.equals(var43, var46);
    double[] var50 = new double[] { 100.0d, (-1.0d)};
    double[] var53 = new double[] { 100.0d, 1.0d};
    boolean var54 = org.apache.commons.math3.util.MathArrays.equals(var50, var53);
    double var55 = org.apache.commons.math3.util.MathArrays.distance(var46, var50);
    double[] var58 = new double[] { 100.0d, (-1.0d)};
    double[] var61 = new double[] { 100.0d, 1.0d};
    boolean var62 = org.apache.commons.math3.util.MathArrays.equals(var58, var61);
    double[] var65 = new double[] { 100.0d, (-1.0d)};
    double[] var68 = new double[] { 100.0d, 1.0d};
    boolean var69 = org.apache.commons.math3.util.MathArrays.equals(var65, var68);
    double var70 = org.apache.commons.math3.util.MathArrays.distance(var61, var65);
    double var71 = org.apache.commons.math3.util.MathArrays.linearCombination(var46, var61);
    double[] var72 = org.apache.commons.math3.util.MathArrays.ebeAdd(var40, var46);
    double var73 = org.apache.commons.math3.util.MathArrays.safeNorm(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 100.00499987500625d);

  }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)100L);
    java.lang.Number var3 = var2.getMin();
    boolean var4 = var2.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    double[] var5 = new double[] { 100.0d, (-1.0d)};
    double[] var8 = new double[] { 100.0d, 1.0d};
    boolean var9 = org.apache.commons.math3.util.MathArrays.equals(var5, var8);
    double[] var12 = new double[] { 100.0d, (-1.0d)};
    double[] var15 = new double[] { 100.0d, 1.0d};
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var12, var15);
    double[] var19 = new double[] { 100.0d, (-1.0d)};
    double[] var22 = new double[] { 100.0d, 1.0d};
    boolean var23 = org.apache.commons.math3.util.MathArrays.equals(var19, var22);
    double var24 = org.apache.commons.math3.util.MathArrays.distance(var15, var19);
    double[] var27 = new double[] { 100.0d, (-1.0d)};
    double[] var30 = new double[] { 100.0d, 1.0d};
    boolean var31 = org.apache.commons.math3.util.MathArrays.equals(var27, var30);
    double[] var34 = new double[] { 100.0d, (-1.0d)};
    double[] var37 = new double[] { 100.0d, 1.0d};
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var34, var37);
    double var39 = org.apache.commons.math3.util.MathArrays.distance(var30, var34);
    double var40 = org.apache.commons.math3.util.MathArrays.linearCombination(var15, var30);
    boolean var41 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var5, var15);
    double[] var43 = org.apache.commons.math3.util.MathArrays.normalizeArray(var15, (-1.682916631768903d));
    double[] var46 = new double[] { 100.0d, (-1.0d)};
    double[] var49 = new double[] { 100.0d, 1.0d};
    boolean var50 = org.apache.commons.math3.util.MathArrays.equals(var46, var49);
    double[] var53 = new double[] { 100.0d, (-1.0d)};
    double[] var56 = new double[] { 100.0d, 1.0d};
    boolean var57 = org.apache.commons.math3.util.MathArrays.equals(var53, var56);
    double var58 = org.apache.commons.math3.util.MathArrays.distance(var49, var53);
    double[] var61 = new double[] { 100.0d, (-1.0d)};
    double[] var64 = new double[] { 100.0d, 1.0d};
    boolean var65 = org.apache.commons.math3.util.MathArrays.equals(var61, var64);
    double[] var68 = new double[] { 100.0d, (-1.0d)};
    double[] var71 = new double[] { 100.0d, 1.0d};
    boolean var72 = org.apache.commons.math3.util.MathArrays.equals(var68, var71);
    double var73 = org.apache.commons.math3.util.MathArrays.distance(var64, var68);
    double var74 = org.apache.commons.math3.util.MathArrays.linearCombination(var49, var64);
    double[] var75 = org.apache.commons.math3.util.MathArrays.ebeAdd(var43, var49);
    double[] var78 = new double[] { 100.0d, (-1.0d)};
    double[] var81 = new double[] { 100.0d, 1.0d};
    boolean var82 = org.apache.commons.math3.util.MathArrays.equals(var78, var81);
    double[] var85 = new double[] { 100.0d, (-1.0d)};
    double[] var88 = new double[] { 100.0d, 1.0d};
    boolean var89 = org.apache.commons.math3.util.MathArrays.equals(var85, var88);
    double var90 = org.apache.commons.math3.util.MathArrays.distance(var81, var85);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var91 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var2, var49, var81);
    double var93 = var91.cumulativeProbability(3.31077097012213d);
    double var94 = var91.sample();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == 0.009900990099009901d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var94 == 100.0d);

  }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }


    int[] var1 = new int[] { (-1)};
    int[] var2 = org.apache.commons.math3.util.MathArrays.copyOf(var1);
    int[] var4 = new int[] { (-1)};
    int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
    int var6 = org.apache.commons.math3.util.MathArrays.distanceInf(var2, var4);
    org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(var4);
    org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(var4);
    var8.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);

  }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    double[] var5 = new double[] { 100.0d, (-1.0d)};
    double[] var8 = new double[] { 100.0d, 1.0d};
    boolean var9 = org.apache.commons.math3.util.MathArrays.equals(var5, var8);
    double[] var12 = new double[] { 100.0d, (-1.0d)};
    double[] var15 = new double[] { 100.0d, 1.0d};
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var12, var15);
    double[] var19 = new double[] { 100.0d, (-1.0d)};
    double[] var22 = new double[] { 100.0d, 1.0d};
    boolean var23 = org.apache.commons.math3.util.MathArrays.equals(var19, var22);
    double var24 = org.apache.commons.math3.util.MathArrays.distance(var15, var19);
    double[] var27 = new double[] { 100.0d, (-1.0d)};
    double[] var30 = new double[] { 100.0d, 1.0d};
    boolean var31 = org.apache.commons.math3.util.MathArrays.equals(var27, var30);
    double[] var34 = new double[] { 100.0d, (-1.0d)};
    double[] var37 = new double[] { 100.0d, 1.0d};
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var34, var37);
    double var39 = org.apache.commons.math3.util.MathArrays.distance(var30, var34);
    double var40 = org.apache.commons.math3.util.MathArrays.linearCombination(var15, var30);
    boolean var41 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var5, var15);
    double[] var43 = org.apache.commons.math3.util.MathArrays.normalizeArray(var15, (-1.682916631768903d));
    double[] var46 = new double[] { 100.0d, (-1.0d)};
    double[] var49 = new double[] { 100.0d, 1.0d};
    boolean var50 = org.apache.commons.math3.util.MathArrays.equals(var46, var49);
    double[] var53 = new double[] { 100.0d, (-1.0d)};
    double[] var56 = new double[] { 100.0d, 1.0d};
    boolean var57 = org.apache.commons.math3.util.MathArrays.equals(var53, var56);
    double var58 = org.apache.commons.math3.util.MathArrays.distance(var49, var53);
    double[] var61 = new double[] { 100.0d, (-1.0d)};
    double[] var64 = new double[] { 100.0d, 1.0d};
    boolean var65 = org.apache.commons.math3.util.MathArrays.equals(var61, var64);
    double[] var68 = new double[] { 100.0d, (-1.0d)};
    double[] var71 = new double[] { 100.0d, 1.0d};
    boolean var72 = org.apache.commons.math3.util.MathArrays.equals(var68, var71);
    double var73 = org.apache.commons.math3.util.MathArrays.distance(var64, var68);
    double var74 = org.apache.commons.math3.util.MathArrays.linearCombination(var49, var64);
    double[] var75 = org.apache.commons.math3.util.MathArrays.ebeAdd(var43, var49);
    double[] var78 = new double[] { 100.0d, (-1.0d)};
    double[] var81 = new double[] { 100.0d, 1.0d};
    boolean var82 = org.apache.commons.math3.util.MathArrays.equals(var78, var81);
    double[] var85 = new double[] { 100.0d, (-1.0d)};
    double[] var88 = new double[] { 100.0d, 1.0d};
    boolean var89 = org.apache.commons.math3.util.MathArrays.equals(var85, var88);
    double var90 = org.apache.commons.math3.util.MathArrays.distance(var81, var85);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var91 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var2, var49, var81);
    double var93 = var91.density(0.0d);
    boolean var94 = var91.isSupportConnected();
    var91.reseedRandomGenerator(100L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var94 == true);

  }

  public void test382() {}
//   public void test382() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextGaussian(0.0d, 2.0d);
//     var1.reSeedSecure(0L);
//     var1.reSeedSecure();
//     var1.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 2.177799292832918d);
// 
//   }

  public void test383() {}
//   public void test383() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextGaussian(10.0d, 2.0d);
//     long var7 = var1.nextSecureLong(1L, 7L);
//     double var10 = var1.nextCauchy(8.609350869964992d, 101.91063826044444d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 10.883385168453582d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 7L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-101.82161958573565d));
// 
//   }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }


    org.apache.commons.math3.exception.MathArithmeticException var0 = new org.apache.commons.math3.exception.MathArithmeticException();

  }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var4 = var2.nextChiSquare(96.07881580237154d);
    double var7 = var2.nextCauchy(0.0d, 8.323092904832185d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 92.26337525222011d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 58.24014955836018d);

  }

  public void test386() {}
//   public void test386() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextGaussian(10.0d, 2.0d);
//     long var7 = var1.nextSecureLong(1L, 7L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var1.nextHypergeometric(1, 0, 224787129);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 9.49141421181552d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 3L);
// 
//   }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }


    int[] var1 = new int[] { (-1)};
    int[] var2 = org.apache.commons.math3.util.MathArrays.copyOf(var1);
    int[] var4 = new int[] { (-1)};
    int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
    int var6 = org.apache.commons.math3.util.MathArrays.distanceInf(var2, var4);
    org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(var4);
    int[] var9 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var10 = new org.apache.commons.math3.random.Well19937c(var9);
    org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(10L);
    var12.setSeed(10);
    int var16 = var12.nextInt(100);
    int[] var18 = new int[] { (-1)};
    int[] var19 = org.apache.commons.math3.util.MathArrays.copyOf(var18);
    int[] var20 = org.apache.commons.math3.util.MathArrays.copyOf(var19);
    var12.setSeed(var20);
    int var22 = org.apache.commons.math3.util.MathArrays.distance1(var9, var20);
    double var23 = org.apache.commons.math3.util.MathArrays.distance(var4, var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);

  }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1.0d, (java.lang.Number)10, true);
    boolean var5 = var4.getBoundIsAllowed();
    org.apache.commons.math3.exception.util.ExceptionContext var6 = var4.getContext();
    java.lang.Number var7 = var4.getMax();
    org.apache.commons.math3.exception.NullArgumentException var8 = new org.apache.commons.math3.exception.NullArgumentException();
    var4.addSuppressed((java.lang.Throwable)var8);
    org.apache.commons.math3.util.MathArrays.OrderDirection var13 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var15 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1L, (java.lang.Number)(-1), 1, var13, false);
    java.lang.Number var16 = var15.getPrevious();
    int var17 = var15.getIndex();
    var8.addSuppressed((java.lang.Throwable)var15);
    org.apache.commons.math3.exception.util.ExceptionContext var19 = var8.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 10+ "'", var7.equals(10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + (-1)+ "'", var16.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed((-1L));
    var0.reSeed();
    var0.reSeed(100L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var8 = var0.nextLong(100L, 6L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test390() {}
//   public void test390() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }
// 
// 
//     double[] var0 = null;
//     org.apache.commons.math3.util.MathArrays.OrderDirection var1 = null;
//     boolean var3 = org.apache.commons.math3.util.MathArrays.isMonotonic(var0, var1, true);
// 
//   }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    var1.reSeed();

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    double var2 = var1.nextDouble();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setSecureAlgorithm("", "org.apache.commons.math3.exception.NumberIsTooSmallException: -1 is smaller than the minimum (10)");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.40877566087838346d);

  }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }


    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1L, (java.lang.Number)(-1), 1, var3, false);
    java.lang.String var6 = var5.toString();
    java.lang.Throwable[] var7 = var5.getSuppressed();
    boolean var8 = var5.getStrict();
    boolean var9 = var5.getStrict();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "org.apache.commons.math3.exception.NonMonotonicSequenceException: points 0 and 1 are not decreasing (-1 < 1)"+ "'", var6.equals("org.apache.commons.math3.exception.NonMonotonicSequenceException: points 0 and 1 are not decreasing (-1 < 1)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)13.226435756113098d);

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    var1.setSeed(10);
    int var5 = var1.nextInt(100);
    var1.setSeed(100L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 86);

  }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    long[] var3 = new long[] { };
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var3);
    long[][] var5 = new long[][] { var3};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var5);
    org.apache.commons.math3.exception.MathIllegalArgumentException var7 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.NullArgumentException var8 = new org.apache.commons.math3.exception.NullArgumentException(var1, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(2.027380293984852d, (-0.4700655222907494d), 8.609350869964992d, 0.0d, 0.8287558766918952d, (-1.6478376658157248d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-2.318656726153d));

  }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(10.883385168453582d, (-0.9455744221955024d), 63.69489379047444d, 1.4672819741620675d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 83.16731886273895d);

  }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextPascal(86, 0.0d);
    double var8 = var2.nextF(1.3705339519213432E8d, 0.15328243612779968d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSecureAlgorithm("d", "625f874598");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.6430091429172536E7d);

  }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Object[] var6 = new java.lang.Object[] { 10.0d};
    org.apache.commons.math3.exception.NullArgumentException var7 = new org.apache.commons.math3.exception.NullArgumentException(var4, var6);
    org.apache.commons.math3.exception.MathIllegalArgumentException var8 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, var6);
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var2, var6);
    org.apache.commons.math3.exception.MathArithmeticException var10 = new org.apache.commons.math3.exception.MathArithmeticException(var1, var6);
    org.apache.commons.math3.exception.NotFiniteNumberException var11 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var3 = var1.nextDouble();
    int var5 = var1.nextInt(998139946);
    org.apache.commons.math3.random.RandomDataImpl var6 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var8 = var6.nextT(1.2694665049707192d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var11 = var6.nextCauchy(0.009900990099009901d, (-2.350538798101527d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.40877566087838346d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 224787129);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-0.06785102457656743d));

  }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }


    long[] var0 = new long[] { };
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var0);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }


    double[] var2 = new double[] { 100.0d, (-1.0d)};
    double[] var5 = new double[] { 100.0d, 1.0d};
    boolean var6 = org.apache.commons.math3.util.MathArrays.equals(var2, var5);
    double[] var9 = new double[] { 100.0d, (-1.0d)};
    double[] var12 = new double[] { 100.0d, 1.0d};
    boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var9, var12);
    double var14 = org.apache.commons.math3.util.MathArrays.distance(var5, var9);
    double[] var17 = new double[] { 100.0d, (-1.0d)};
    double[] var20 = new double[] { 100.0d, 1.0d};
    boolean var21 = org.apache.commons.math3.util.MathArrays.equals(var17, var20);
    double[] var24 = new double[] { 100.0d, (-1.0d)};
    double[] var27 = new double[] { 100.0d, 1.0d};
    boolean var28 = org.apache.commons.math3.util.MathArrays.equals(var24, var27);
    double[] var31 = new double[] { 100.0d, (-1.0d)};
    double[] var34 = new double[] { 100.0d, 1.0d};
    boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var31, var34);
    double var36 = org.apache.commons.math3.util.MathArrays.distance(var27, var31);
    double[] var39 = new double[] { 100.0d, (-1.0d)};
    double[] var42 = new double[] { 100.0d, 1.0d};
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var39, var42);
    double[] var46 = new double[] { 100.0d, (-1.0d)};
    double[] var49 = new double[] { 100.0d, 1.0d};
    boolean var50 = org.apache.commons.math3.util.MathArrays.equals(var46, var49);
    double var51 = org.apache.commons.math3.util.MathArrays.distance(var42, var46);
    double var52 = org.apache.commons.math3.util.MathArrays.linearCombination(var27, var42);
    boolean var53 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var17, var27);
    double[] var55 = org.apache.commons.math3.util.MathArrays.normalizeArray(var27, (-1.682916631768903d));
    org.apache.commons.math3.distribution.DiscreteRealDistribution var56 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var9, var27);
    boolean var57 = var56.isSupportConnected();
    double var59 = var56.density(8.323092904832185d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0.0d);

  }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }


    double[] var2 = new double[] { 100.0d, (-1.0d)};
    double[] var5 = new double[] { 100.0d, 1.0d};
    boolean var6 = org.apache.commons.math3.util.MathArrays.equals(var2, var5);
    double[] var9 = new double[] { 100.0d, (-1.0d)};
    double[] var12 = new double[] { 100.0d, 1.0d};
    boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var9, var12);
    double[] var16 = new double[] { 100.0d, (-1.0d)};
    double[] var19 = new double[] { 100.0d, 1.0d};
    boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var16, var19);
    double[] var23 = new double[] { 100.0d, (-1.0d)};
    double[] var26 = new double[] { 100.0d, 1.0d};
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var23, var26);
    double var28 = org.apache.commons.math3.util.MathArrays.distance(var19, var23);
    double[] var31 = new double[] { 100.0d, (-1.0d)};
    double[] var34 = new double[] { 100.0d, 1.0d};
    boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var31, var34);
    double[] var38 = new double[] { 100.0d, (-1.0d)};
    double[] var41 = new double[] { 100.0d, 1.0d};
    boolean var42 = org.apache.commons.math3.util.MathArrays.equals(var38, var41);
    double var43 = org.apache.commons.math3.util.MathArrays.distance(var34, var38);
    double var44 = org.apache.commons.math3.util.MathArrays.linearCombination(var19, var34);
    boolean var45 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var9, var19);
    double[] var47 = org.apache.commons.math3.util.MathArrays.normalizeArray(var19, (-1.682916631768903d));
    double[] var48 = org.apache.commons.math3.util.MathArrays.ebeAdd(var5, var19);
    double[] var51 = new double[] { 100.0d, (-1.0d)};
    double[] var54 = new double[] { 100.0d, 1.0d};
    boolean var55 = org.apache.commons.math3.util.MathArrays.equals(var51, var54);
    double[] var58 = new double[] { 100.0d, (-1.0d)};
    double[] var61 = new double[] { 100.0d, 1.0d};
    boolean var62 = org.apache.commons.math3.util.MathArrays.equals(var58, var61);
    double[] var65 = new double[] { 100.0d, (-1.0d)};
    double[] var68 = new double[] { 100.0d, 1.0d};
    boolean var69 = org.apache.commons.math3.util.MathArrays.equals(var65, var68);
    double var70 = org.apache.commons.math3.util.MathArrays.distance(var61, var65);
    double[] var73 = new double[] { 100.0d, (-1.0d)};
    double[] var76 = new double[] { 100.0d, 1.0d};
    boolean var77 = org.apache.commons.math3.util.MathArrays.equals(var73, var76);
    double[] var80 = new double[] { 100.0d, (-1.0d)};
    double[] var83 = new double[] { 100.0d, 1.0d};
    boolean var84 = org.apache.commons.math3.util.MathArrays.equals(var80, var83);
    double var85 = org.apache.commons.math3.util.MathArrays.distance(var76, var80);
    double var86 = org.apache.commons.math3.util.MathArrays.linearCombination(var61, var76);
    boolean var87 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var51, var61);
    double var88 = org.apache.commons.math3.util.MathArrays.distanceInf(var5, var61);
    double[] var90 = org.apache.commons.math3.util.MathArrays.normalizeArray(var5, (-1.0750511664712115E8d));
    org.apache.commons.math3.util.MathArrays.checkPositive(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);

  }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(1, (-1));
    int var3 = var2.getDimension();
    int var4 = var2.getDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));

  }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    var1.setSeed(10L);
    int var5 = var1.nextInt(10);
    org.apache.commons.math3.random.RandomDataImpl var6 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var9 = var6.nextGaussian(1.6430091429172536E7d, 0.2323975705328034d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.6430091483669123E7d);

  }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 0, 10);

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }


    double[] var2 = new double[] { 100.0d, (-1.0d)};
    double[] var5 = new double[] { 100.0d, 1.0d};
    boolean var6 = org.apache.commons.math3.util.MathArrays.equals(var2, var5);
    double[] var9 = new double[] { 100.0d, (-1.0d)};
    double[] var12 = new double[] { 100.0d, 1.0d};
    boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var9, var12);
    double[] var16 = new double[] { 100.0d, (-1.0d)};
    double[] var19 = new double[] { 100.0d, 1.0d};
    boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var16, var19);
    double[] var23 = new double[] { 100.0d, (-1.0d)};
    double[] var26 = new double[] { 100.0d, 1.0d};
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var23, var26);
    double var28 = org.apache.commons.math3.util.MathArrays.distance(var19, var23);
    double[] var31 = new double[] { 100.0d, (-1.0d)};
    double[] var34 = new double[] { 100.0d, 1.0d};
    boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var31, var34);
    double[] var38 = new double[] { 100.0d, (-1.0d)};
    double[] var41 = new double[] { 100.0d, 1.0d};
    boolean var42 = org.apache.commons.math3.util.MathArrays.equals(var38, var41);
    double var43 = org.apache.commons.math3.util.MathArrays.distance(var34, var38);
    double var44 = org.apache.commons.math3.util.MathArrays.linearCombination(var19, var34);
    boolean var45 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var9, var19);
    double[] var47 = org.apache.commons.math3.util.MathArrays.normalizeArray(var19, (-1.682916631768903d));
    double[] var48 = org.apache.commons.math3.util.MathArrays.ebeAdd(var5, var19);
    double[] var50 = org.apache.commons.math3.util.MathArrays.copyOf(var19, 0);
    double var51 = org.apache.commons.math3.util.MathArrays.safeNorm(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 100.00499987500625d);

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    float var3 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var7 = var4.nextLong(5L, (-833491931516635789L));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.40877557f);

  }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(-2.350538798101527d));

  }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    var1.setSeed(10);
    int var5 = var1.nextInt(86);
    int[] var7 = new int[] { (-1)};
    int[] var8 = org.apache.commons.math3.util.MathArrays.copyOf(var7);
    int[] var10 = new int[] { (-1)};
    int[] var11 = org.apache.commons.math3.util.MathArrays.copyOf(var10);
    int var12 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var10);
    org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(var10);
    var1.setSeed(var10);
    int[] var16 = new int[] { (-1)};
    int[] var17 = org.apache.commons.math3.util.MathArrays.copyOf(var16);
    var1.setSeed(var17);
    var1.setSeed(2147483647);
    var1.setSeed((-1));
    double var23 = var1.nextDouble();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.473974825082335d);

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var3 = var1.nextDouble();
    var1.setSeed(10L);
    int var7 = var1.nextInt(1);
    double var8 = var1.nextDouble();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.40877566087838346d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.2323975705328034d);

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }


    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)8.323092904832185d, (java.lang.Number)10, 89447278, var3, false);

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)5L, var1, false);

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(byte)10, (java.lang.Number)9854048.12570597d, (java.lang.Number)10001.0d);
    java.lang.Number var4 = var3.getArgument();
    java.lang.String var5 = var3.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (byte)10+ "'", var4.equals((byte)10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: 10 out of [9,854,048.126, 10,001] range"+ "'", var5.equals("org.apache.commons.math3.exception.OutOfRangeException: 10 out of [9,854,048.126, 10,001] range"));

  }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    double var2 = var1.nextDouble();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    boolean var4 = var1.nextBoolean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.40877566087838346d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test417() {}
//   public void test417() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     long var6 = var2.nextLong((-1L), 10L);
//     double var8 = var2.nextChiSquare(99.01980198019803d);
//     long var10 = var2.nextPoisson(0.473974825082335d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 94.5705477312919d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0L);
// 
//   }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    double[] var5 = new double[] { 100.0d, (-1.0d)};
    double[] var8 = new double[] { 100.0d, 1.0d};
    boolean var9 = org.apache.commons.math3.util.MathArrays.equals(var5, var8);
    double[] var12 = new double[] { 100.0d, (-1.0d)};
    double[] var15 = new double[] { 100.0d, 1.0d};
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var12, var15);
    double[] var19 = new double[] { 100.0d, (-1.0d)};
    double[] var22 = new double[] { 100.0d, 1.0d};
    boolean var23 = org.apache.commons.math3.util.MathArrays.equals(var19, var22);
    double var24 = org.apache.commons.math3.util.MathArrays.distance(var15, var19);
    double[] var27 = new double[] { 100.0d, (-1.0d)};
    double[] var30 = new double[] { 100.0d, 1.0d};
    boolean var31 = org.apache.commons.math3.util.MathArrays.equals(var27, var30);
    double[] var34 = new double[] { 100.0d, (-1.0d)};
    double[] var37 = new double[] { 100.0d, 1.0d};
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var34, var37);
    double var39 = org.apache.commons.math3.util.MathArrays.distance(var30, var34);
    double var40 = org.apache.commons.math3.util.MathArrays.linearCombination(var15, var30);
    boolean var41 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var5, var15);
    double[] var43 = org.apache.commons.math3.util.MathArrays.normalizeArray(var15, (-1.682916631768903d));
    double[] var46 = new double[] { 100.0d, (-1.0d)};
    double[] var49 = new double[] { 100.0d, 1.0d};
    boolean var50 = org.apache.commons.math3.util.MathArrays.equals(var46, var49);
    double[] var53 = new double[] { 100.0d, (-1.0d)};
    double[] var56 = new double[] { 100.0d, 1.0d};
    boolean var57 = org.apache.commons.math3.util.MathArrays.equals(var53, var56);
    double var58 = org.apache.commons.math3.util.MathArrays.distance(var49, var53);
    double[] var61 = new double[] { 100.0d, (-1.0d)};
    double[] var64 = new double[] { 100.0d, 1.0d};
    boolean var65 = org.apache.commons.math3.util.MathArrays.equals(var61, var64);
    double[] var68 = new double[] { 100.0d, (-1.0d)};
    double[] var71 = new double[] { 100.0d, 1.0d};
    boolean var72 = org.apache.commons.math3.util.MathArrays.equals(var68, var71);
    double var73 = org.apache.commons.math3.util.MathArrays.distance(var64, var68);
    double var74 = org.apache.commons.math3.util.MathArrays.linearCombination(var49, var64);
    double[] var75 = org.apache.commons.math3.util.MathArrays.ebeAdd(var43, var49);
    double[] var78 = new double[] { 100.0d, (-1.0d)};
    double[] var81 = new double[] { 100.0d, 1.0d};
    boolean var82 = org.apache.commons.math3.util.MathArrays.equals(var78, var81);
    double[] var85 = new double[] { 100.0d, (-1.0d)};
    double[] var88 = new double[] { 100.0d, 1.0d};
    boolean var89 = org.apache.commons.math3.util.MathArrays.equals(var85, var88);
    double var90 = org.apache.commons.math3.util.MathArrays.distance(var81, var85);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var91 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var2, var49, var81);
    double var93 = var91.density(0.0d);
    boolean var94 = var91.isSupportConnected();
    double var95 = var91.getSupportUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var94 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var95 == 100.0d);

  }

  public void test419() {}
//   public void test419() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     double var5 = var2.nextExponential(1.4672819741620675d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 9.501148456806142E-4d);
// 
//   }

  public void test420() {}
//   public void test420() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     java.util.Collection var3 = null;
//     java.lang.Object[] var5 = var2.nextSample(var3, 1);
// 
//   }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)1.2694665049707192d);
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var1.getContext();
    java.lang.Number var3 = var1.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 1.2694665049707192d+ "'", var3.equals(1.2694665049707192d));

  }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)2.0d);

  }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, var1, (java.lang.Number)30, (java.lang.Number)2.3590437156692077d);

  }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeedSecure(10L);
    var2.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var8 = var2.nextSecureInt(28, 4);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test425() {}
//   public void test425() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextGaussian(0.0d, 2.0d);
//     var1.reSeedSecure(0L);
//     var1.reSeedSecure();
//     double var10 = var1.nextGaussian(2.0d, 2.0d);
//     long var13 = var1.nextLong(3L, 6L);
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var17 = var1.nextBeta(0.0d, 58.24014955836018d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0006227563497203d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 2.1822274014447944d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 3L);
// 
//   }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 2147483647, 0);
    int var4 = var3.getDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);

  }

  public void test427() {}
//   public void test427() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var5 = var2.nextSecureLong(0L, 1L);
//     var2.reSeed(6L);
//     var2.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0L);
// 
//   }

  public void test428() {}
//   public void test428() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var5 = var1.nextUniform((-0.03786377777366967d), 0.5650828929145241d, true);
//     double var8 = var1.nextUniform((-0.7844030186481109d), 96.07881580237154d);
//     var1.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.173731774113822d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 69.98119896658409d);
// 
//   }

  public void test429() {}
//   public void test429() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var5 = var2.nextSecureLong(0L, 1L);
//     var2.reSeed(6L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var2.nextPascal(1755678109, 10.883385168453582d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0L);
// 
//   }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }


    double[] var2 = new double[] { 100.0d, (-1.0d)};
    double[] var5 = new double[] { 100.0d, 1.0d};
    boolean var6 = org.apache.commons.math3.util.MathArrays.equals(var2, var5);
    double[] var9 = new double[] { 100.0d, (-1.0d)};
    double[] var12 = new double[] { 100.0d, 1.0d};
    boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var9, var12);
    double[] var16 = new double[] { 100.0d, (-1.0d)};
    double[] var19 = new double[] { 100.0d, 1.0d};
    boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var16, var19);
    double var21 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double[] var24 = new double[] { 100.0d, (-1.0d)};
    double[] var27 = new double[] { 100.0d, 1.0d};
    boolean var28 = org.apache.commons.math3.util.MathArrays.equals(var24, var27);
    double[] var31 = new double[] { 100.0d, (-1.0d)};
    double[] var34 = new double[] { 100.0d, 1.0d};
    boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var31, var34);
    double var36 = org.apache.commons.math3.util.MathArrays.distance(var27, var31);
    double var37 = org.apache.commons.math3.util.MathArrays.linearCombination(var12, var27);
    boolean var38 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var2, var12);
    double[] var40 = org.apache.commons.math3.util.MathArrays.normalizeArray(var12, (-1.682916631768903d));
    double[] var43 = new double[] { 100.0d, (-1.0d)};
    double[] var46 = new double[] { 100.0d, 1.0d};
    boolean var47 = org.apache.commons.math3.util.MathArrays.equals(var43, var46);
    double[] var50 = new double[] { 100.0d, (-1.0d)};
    double[] var53 = new double[] { 100.0d, 1.0d};
    boolean var54 = org.apache.commons.math3.util.MathArrays.equals(var50, var53);
    double var55 = org.apache.commons.math3.util.MathArrays.distance(var46, var50);
    double[] var58 = new double[] { 100.0d, (-1.0d)};
    double[] var61 = new double[] { 100.0d, 1.0d};
    boolean var62 = org.apache.commons.math3.util.MathArrays.equals(var58, var61);
    double[] var63 = org.apache.commons.math3.util.MathArrays.ebeDivide(var50, var58);
    double[] var64 = org.apache.commons.math3.util.MathArrays.ebeDivide(var12, var58);
    double[] var65 = org.apache.commons.math3.util.MathArrays.copyOf(var64);
    double var66 = org.apache.commons.math3.util.MathArrays.safeNorm(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 1.4142135623730951d);

  }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    var1.setSeed(10);
    int var5 = var1.nextInt(86);
    int[] var7 = new int[] { (-1)};
    int[] var8 = org.apache.commons.math3.util.MathArrays.copyOf(var7);
    int[] var10 = new int[] { (-1)};
    int[] var11 = org.apache.commons.math3.util.MathArrays.copyOf(var10);
    int var12 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var10);
    org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(var10);
    var1.setSeed(var10);
    int[] var16 = new int[] { (-1)};
    int[] var17 = org.apache.commons.math3.util.MathArrays.copyOf(var16);
    int[] var19 = org.apache.commons.math3.util.MathArrays.copyOf(var17, 86);
    int var20 = org.apache.commons.math3.util.MathArrays.distanceInf(var10, var17);
    int[] var21 = org.apache.commons.math3.util.MathArrays.copyOf(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)4L, (java.lang.Number)(-0.06785102457656743d), false);

  }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }


    double[] var1 = new double[] { 0.0d};
    org.apache.commons.math3.util.MathArrays.OrderDirection var2 = null;
    boolean var4 = org.apache.commons.math3.util.MathArrays.isMonotonic(var1, var2, false);
    int[] var6 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(var6);
    double[] var10 = new double[] { 100.0d, (-1.0d)};
    double[] var13 = new double[] { 100.0d, 1.0d};
    boolean var14 = org.apache.commons.math3.util.MathArrays.equals(var10, var13);
    double[] var17 = new double[] { 100.0d, (-1.0d)};
    double[] var20 = new double[] { 100.0d, 1.0d};
    boolean var21 = org.apache.commons.math3.util.MathArrays.equals(var17, var20);
    double[] var24 = new double[] { 100.0d, (-1.0d)};
    double[] var27 = new double[] { 100.0d, 1.0d};
    boolean var28 = org.apache.commons.math3.util.MathArrays.equals(var24, var27);
    double var29 = org.apache.commons.math3.util.MathArrays.distance(var20, var24);
    double[] var32 = new double[] { 100.0d, (-1.0d)};
    double[] var35 = new double[] { 100.0d, 1.0d};
    boolean var36 = org.apache.commons.math3.util.MathArrays.equals(var32, var35);
    double[] var39 = new double[] { 100.0d, (-1.0d)};
    double[] var42 = new double[] { 100.0d, 1.0d};
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var39, var42);
    double var44 = org.apache.commons.math3.util.MathArrays.distance(var35, var39);
    double var45 = org.apache.commons.math3.util.MathArrays.linearCombination(var20, var35);
    boolean var46 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var20);
    double[] var48 = org.apache.commons.math3.util.MathArrays.normalizeArray(var20, (-1.682916631768903d));
    double[] var51 = new double[] { 100.0d, (-1.0d)};
    double[] var54 = new double[] { 100.0d, 1.0d};
    boolean var55 = org.apache.commons.math3.util.MathArrays.equals(var51, var54);
    double[] var58 = new double[] { 100.0d, (-1.0d)};
    double[] var61 = new double[] { 100.0d, 1.0d};
    boolean var62 = org.apache.commons.math3.util.MathArrays.equals(var58, var61);
    double var63 = org.apache.commons.math3.util.MathArrays.distance(var54, var58);
    double[] var66 = new double[] { 100.0d, (-1.0d)};
    double[] var69 = new double[] { 100.0d, 1.0d};
    boolean var70 = org.apache.commons.math3.util.MathArrays.equals(var66, var69);
    double[] var73 = new double[] { 100.0d, (-1.0d)};
    double[] var76 = new double[] { 100.0d, 1.0d};
    boolean var77 = org.apache.commons.math3.util.MathArrays.equals(var73, var76);
    double var78 = org.apache.commons.math3.util.MathArrays.distance(var69, var73);
    double var79 = org.apache.commons.math3.util.MathArrays.linearCombination(var54, var69);
    double[] var80 = org.apache.commons.math3.util.MathArrays.ebeAdd(var48, var54);
    double[] var83 = new double[] { 100.0d, (-1.0d)};
    double[] var86 = new double[] { 100.0d, 1.0d};
    boolean var87 = org.apache.commons.math3.util.MathArrays.equals(var83, var86);
    double[] var90 = new double[] { 100.0d, (-1.0d)};
    double[] var93 = new double[] { 100.0d, 1.0d};
    boolean var94 = org.apache.commons.math3.util.MathArrays.equals(var90, var93);
    double var95 = org.apache.commons.math3.util.MathArrays.distance(var86, var90);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var96 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var7, var54, var86);
    double[] var97 = org.apache.commons.math3.util.MathArrays.copyOf(var54);
    double[][] var98 = new double[][] { var97};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.sortInPlace(var1, var98);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var93);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var94 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var95 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var97);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var98);

  }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeedSecure();
    var0.reSeedSecure();

  }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var3 = var0.nextSecureLong(100L, 1L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test436() {}
//   public void test436() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var5 = var2.nextSecureLong(0L, 1L);
//     var2.reSeed(6L);
//     double var9 = var2.nextT(2.027380293984852d);
//     var2.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var2.nextPascal((-1), 8509402.437162092d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.123200103709113d);
// 
//   }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var3 = var1.nextDouble();
    int var5 = var1.nextInt(998139946);
    org.apache.commons.math3.random.RandomDataImpl var6 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var9 = var6.nextUniform(0.519605336917354d, 132.82498240734793d);
    double var12 = var6.nextGaussian(2.6669397224844205d, 13.90833488952869d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.40877566087838346d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 224787129);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 63.69489379047444d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 11.227769774268392d);

  }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var1 = null;
    org.apache.commons.math3.exception.MathIllegalArgumentException var2 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var1);

  }

  public void test439() {}
//   public void test439() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     long var6 = var2.nextLong((-1L), 10L);
//     double var8 = var2.nextChiSquare(99.01980198019803d);
//     int var11 = var2.nextSecureInt(16, 561247916);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var2.nextBinomial(2035706397, (-9.400079531200032E7d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 93.88436307746014d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 75302244);
// 
//   }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }


    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)2.0d, (java.lang.Object)(byte)(-1));
    java.lang.Object var3 = var2.getSecond();
    java.lang.Object var4 = var2.getKey();
    boolean var6 = var2.equals((java.lang.Object)"0627178f9a");
    java.lang.Object var7 = var2.getSecond();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + (byte)(-1)+ "'", var3.equals((byte)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 2.0d+ "'", var4.equals(2.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (byte)(-1)+ "'", var7.equals((byte)(-1)));

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }


    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)2.0d, (java.lang.Object)(byte)(-1));
    java.lang.Object var3 = var2.getSecond();
    java.lang.Object var4 = var2.getSecond();
    java.lang.Object var5 = var2.getFirst();
    java.lang.Object var6 = var2.getSecond();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + (byte)(-1)+ "'", var3.equals((byte)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (byte)(-1)+ "'", var4.equals((byte)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 2.0d+ "'", var5.equals(2.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (byte)(-1)+ "'", var6.equals((byte)(-1)));

  }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }


    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1L, (java.lang.Number)(-1), 1, var3, false);
    java.lang.Number var6 = var5.getPrevious();
    int var7 = var5.getIndex();
    int var8 = var5.getIndex();
    org.apache.commons.math3.util.MathArrays.OrderDirection var9 = var5.getDirection();
    java.lang.Number var10 = var5.getPrevious();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (-1)+ "'", var6.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + (-1)+ "'", var10.equals((-1)));

  }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(1);
    int[] var3 = new int[] { (-1)};
    int[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
    int[] var6 = new int[] { (-1)};
    int[] var7 = org.apache.commons.math3.util.MathArrays.copyOf(var6);
    int[] var9 = new int[] { (-1)};
    int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var9);
    int var11 = org.apache.commons.math3.util.MathArrays.distanceInf(var7, var9);
    int var12 = org.apache.commons.math3.util.MathArrays.distanceInf(var4, var9);
    var1.setSeed(var9);
    int[] var15 = new int[] { (-1)};
    int[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var15);
    int[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var16, 86);
    int var19 = org.apache.commons.math3.util.MathArrays.distanceInf(var9, var18);
    org.apache.commons.math3.random.Well19937c var20 = new org.apache.commons.math3.random.Well19937c(var9);
    org.apache.commons.math3.random.Well19937c var21 = new org.apache.commons.math3.random.Well19937c(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);

  }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    var1.setSeed(10);
    int var5 = var1.nextInt(86);
    int[] var7 = new int[] { (-1)};
    int[] var8 = org.apache.commons.math3.util.MathArrays.copyOf(var7);
    int[] var10 = new int[] { (-1)};
    int[] var11 = org.apache.commons.math3.util.MathArrays.copyOf(var10);
    int var12 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var10);
    org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(var10);
    var1.setSeed(var10);
    int[] var16 = new int[] { (-1)};
    int[] var17 = org.apache.commons.math3.util.MathArrays.copyOf(var16);
    var1.setSeed(var17);
    int[] var20 = org.apache.commons.math3.util.MathArrays.copyOf(var17, 16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(1);
    int[] var3 = new int[] { (-1)};
    int[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
    int[] var6 = new int[] { (-1)};
    int[] var7 = org.apache.commons.math3.util.MathArrays.copyOf(var6);
    int[] var9 = new int[] { (-1)};
    int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var9);
    int var11 = org.apache.commons.math3.util.MathArrays.distanceInf(var7, var9);
    int var12 = org.apache.commons.math3.util.MathArrays.distanceInf(var4, var9);
    var1.setSeed(var9);
    org.apache.commons.math3.random.RandomDataImpl var14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);

  }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var4 = var1.nextSecureLong(0L, (-833491931516635789L));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    var1.setSeed(10);
    boolean var4 = var1.nextBoolean();
    double var5 = var1.nextDouble();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.9158810627712619d);

  }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }


    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1L, (java.lang.Number)(-1), 1, var3, false);
    java.lang.String var6 = var5.toString();
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = var5.getDirection();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "org.apache.commons.math3.exception.NonMonotonicSequenceException: points 0 and 1 are not decreasing (-1 < 1)"+ "'", var6.equals("org.apache.commons.math3.exception.NonMonotonicSequenceException: points 0 and 1 are not decreasing (-1 < 1)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }


    double[] var2 = new double[] { 100.0d, (-1.0d)};
    double[] var5 = new double[] { 100.0d, 1.0d};
    boolean var6 = org.apache.commons.math3.util.MathArrays.equals(var2, var5);
    double[] var9 = new double[] { 100.0d, (-1.0d)};
    double[] var12 = new double[] { 100.0d, 1.0d};
    boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var9, var12);
    double[] var16 = new double[] { 100.0d, (-1.0d)};
    double[] var19 = new double[] { 100.0d, 1.0d};
    boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var16, var19);
    double[] var23 = new double[] { 100.0d, (-1.0d)};
    double[] var26 = new double[] { 100.0d, 1.0d};
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var23, var26);
    double var28 = org.apache.commons.math3.util.MathArrays.distance(var19, var23);
    double[] var31 = new double[] { 100.0d, (-1.0d)};
    double[] var34 = new double[] { 100.0d, 1.0d};
    boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var31, var34);
    double[] var38 = new double[] { 100.0d, (-1.0d)};
    double[] var41 = new double[] { 100.0d, 1.0d};
    boolean var42 = org.apache.commons.math3.util.MathArrays.equals(var38, var41);
    double var43 = org.apache.commons.math3.util.MathArrays.distance(var34, var38);
    double var44 = org.apache.commons.math3.util.MathArrays.linearCombination(var19, var34);
    boolean var45 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var9, var19);
    double[] var47 = org.apache.commons.math3.util.MathArrays.normalizeArray(var19, (-1.682916631768903d));
    double[] var48 = org.apache.commons.math3.util.MathArrays.ebeAdd(var5, var19);
    double[] var50 = org.apache.commons.math3.util.MathArrays.copyOf(var19, 0);
    double[] var51 = org.apache.commons.math3.util.MathArrays.copyOf(var50);
    double[] var52 = null;
    double[] var55 = new double[] { 100.0d, (-1.0d)};
    double[] var58 = new double[] { 100.0d, 1.0d};
    boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var55, var58);
    double[] var62 = new double[] { 100.0d, (-1.0d)};
    double[] var65 = new double[] { 100.0d, 1.0d};
    boolean var66 = org.apache.commons.math3.util.MathArrays.equals(var62, var65);
    double var67 = org.apache.commons.math3.util.MathArrays.distance(var58, var62);
    double[] var70 = new double[] { 100.0d, (-1.0d)};
    double[] var73 = new double[] { 100.0d, 1.0d};
    boolean var74 = org.apache.commons.math3.util.MathArrays.equals(var70, var73);
    double[] var77 = new double[] { 100.0d, (-1.0d)};
    double[] var80 = new double[] { 100.0d, 1.0d};
    boolean var81 = org.apache.commons.math3.util.MathArrays.equals(var77, var80);
    double var82 = org.apache.commons.math3.util.MathArrays.distance(var73, var77);
    double var83 = org.apache.commons.math3.util.MathArrays.linearCombination(var58, var73);
    boolean var84 = org.apache.commons.math3.util.MathArrays.equals(var52, var58);
    org.apache.commons.math3.util.MathArrays.checkPositive(var58);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var86 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var51, var58);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == false);

  }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }


    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1L, (java.lang.Number)(-1), 1, var3, false);
    java.lang.Number var6 = var5.getPrevious();
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = var5.getDirection();
    org.apache.commons.math3.util.MathArrays.OrderDirection var8 = var5.getDirection();
    java.lang.Number var9 = var5.getPrevious();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (-1)+ "'", var6.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + (-1)+ "'", var9.equals((-1)));

  }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed((-1L));
    var0.reSeed();
    var0.reSeedSecure(6L);
    var0.reSeedSecure(864L);
    var0.reSeed(7L);

  }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    double[] var5 = new double[] { 100.0d, (-1.0d)};
    double[] var8 = new double[] { 100.0d, 1.0d};
    boolean var9 = org.apache.commons.math3.util.MathArrays.equals(var5, var8);
    double[] var12 = new double[] { 100.0d, (-1.0d)};
    double[] var15 = new double[] { 100.0d, 1.0d};
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var12, var15);
    double[] var19 = new double[] { 100.0d, (-1.0d)};
    double[] var22 = new double[] { 100.0d, 1.0d};
    boolean var23 = org.apache.commons.math3.util.MathArrays.equals(var19, var22);
    double var24 = org.apache.commons.math3.util.MathArrays.distance(var15, var19);
    double[] var27 = new double[] { 100.0d, (-1.0d)};
    double[] var30 = new double[] { 100.0d, 1.0d};
    boolean var31 = org.apache.commons.math3.util.MathArrays.equals(var27, var30);
    double[] var34 = new double[] { 100.0d, (-1.0d)};
    double[] var37 = new double[] { 100.0d, 1.0d};
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var34, var37);
    double var39 = org.apache.commons.math3.util.MathArrays.distance(var30, var34);
    double var40 = org.apache.commons.math3.util.MathArrays.linearCombination(var15, var30);
    boolean var41 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var5, var15);
    double[] var43 = org.apache.commons.math3.util.MathArrays.normalizeArray(var15, (-1.682916631768903d));
    double[] var46 = new double[] { 100.0d, (-1.0d)};
    double[] var49 = new double[] { 100.0d, 1.0d};
    boolean var50 = org.apache.commons.math3.util.MathArrays.equals(var46, var49);
    double[] var53 = new double[] { 100.0d, (-1.0d)};
    double[] var56 = new double[] { 100.0d, 1.0d};
    boolean var57 = org.apache.commons.math3.util.MathArrays.equals(var53, var56);
    double var58 = org.apache.commons.math3.util.MathArrays.distance(var49, var53);
    double[] var61 = new double[] { 100.0d, (-1.0d)};
    double[] var64 = new double[] { 100.0d, 1.0d};
    boolean var65 = org.apache.commons.math3.util.MathArrays.equals(var61, var64);
    double[] var68 = new double[] { 100.0d, (-1.0d)};
    double[] var71 = new double[] { 100.0d, 1.0d};
    boolean var72 = org.apache.commons.math3.util.MathArrays.equals(var68, var71);
    double var73 = org.apache.commons.math3.util.MathArrays.distance(var64, var68);
    double var74 = org.apache.commons.math3.util.MathArrays.linearCombination(var49, var64);
    double[] var75 = org.apache.commons.math3.util.MathArrays.ebeAdd(var43, var49);
    double[] var78 = new double[] { 100.0d, (-1.0d)};
    double[] var81 = new double[] { 100.0d, 1.0d};
    boolean var82 = org.apache.commons.math3.util.MathArrays.equals(var78, var81);
    double[] var85 = new double[] { 100.0d, (-1.0d)};
    double[] var88 = new double[] { 100.0d, 1.0d};
    boolean var89 = org.apache.commons.math3.util.MathArrays.equals(var85, var88);
    double var90 = org.apache.commons.math3.util.MathArrays.distance(var81, var85);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var91 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var2, var49, var81);
    var91.reseedRandomGenerator((-1L));
    double var96 = var91.probability(0.6115651382182169d, 99.01980198019803d);
    double var97 = var91.sample();
    double var99 = var91.density(1.5399696003263283d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var96 == 0.009900990099009901d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var97 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var99 == 0.0d);

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var1.setSeed(6L);
    double var5 = var1.nextGaussian();
    org.apache.commons.math3.random.RandomDataImpl var6 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.8287558766918952d);

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }


    int[] var1 = new int[] { (-1)};
    int[] var2 = org.apache.commons.math3.util.MathArrays.copyOf(var1);
    int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var2);
    int[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var2);
    org.apache.commons.math3.random.Well19937c var5 = new org.apache.commons.math3.random.Well19937c(var2);
    double var6 = var5.nextDouble();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.473974825082335d);

  }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    double var2 = var1.nextDouble();
    long var3 = var1.nextLong();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.40877566087838346d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-833491931516635789L));

  }

  public void test456() {}
//   public void test456() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed((-1L));
//     var0.reSeed();
//     var0.reSeedSecure(6L);
//     var0.reSeedSecure(864L);
//     java.util.Collection var8 = null;
//     java.lang.Object[] var10 = var0.nextSample(var8, 669834927);
// 
//   }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination((-2.318656726153d), 10.883385168453582d, (-2.8790720904868783d), 0.40877566087838346d, 0.519605336917354d, 99.99999882208091d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 25.548804259028376d);

  }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)10, (java.lang.Number)0L, true);
    java.lang.Number var4 = var3.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0L+ "'", var4.equals(0L));

  }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    double[] var5 = new double[] { 100.0d, (-1.0d)};
    double[] var8 = new double[] { 100.0d, 1.0d};
    boolean var9 = org.apache.commons.math3.util.MathArrays.equals(var5, var8);
    double[] var12 = new double[] { 100.0d, (-1.0d)};
    double[] var15 = new double[] { 100.0d, 1.0d};
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var12, var15);
    double[] var19 = new double[] { 100.0d, (-1.0d)};
    double[] var22 = new double[] { 100.0d, 1.0d};
    boolean var23 = org.apache.commons.math3.util.MathArrays.equals(var19, var22);
    double var24 = org.apache.commons.math3.util.MathArrays.distance(var15, var19);
    double[] var27 = new double[] { 100.0d, (-1.0d)};
    double[] var30 = new double[] { 100.0d, 1.0d};
    boolean var31 = org.apache.commons.math3.util.MathArrays.equals(var27, var30);
    double[] var34 = new double[] { 100.0d, (-1.0d)};
    double[] var37 = new double[] { 100.0d, 1.0d};
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var34, var37);
    double var39 = org.apache.commons.math3.util.MathArrays.distance(var30, var34);
    double var40 = org.apache.commons.math3.util.MathArrays.linearCombination(var15, var30);
    boolean var41 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var5, var15);
    double[] var43 = org.apache.commons.math3.util.MathArrays.normalizeArray(var15, (-1.682916631768903d));
    double[] var46 = new double[] { 100.0d, (-1.0d)};
    double[] var49 = new double[] { 100.0d, 1.0d};
    boolean var50 = org.apache.commons.math3.util.MathArrays.equals(var46, var49);
    double[] var53 = new double[] { 100.0d, (-1.0d)};
    double[] var56 = new double[] { 100.0d, 1.0d};
    boolean var57 = org.apache.commons.math3.util.MathArrays.equals(var53, var56);
    double var58 = org.apache.commons.math3.util.MathArrays.distance(var49, var53);
    double[] var61 = new double[] { 100.0d, (-1.0d)};
    double[] var64 = new double[] { 100.0d, 1.0d};
    boolean var65 = org.apache.commons.math3.util.MathArrays.equals(var61, var64);
    double[] var68 = new double[] { 100.0d, (-1.0d)};
    double[] var71 = new double[] { 100.0d, 1.0d};
    boolean var72 = org.apache.commons.math3.util.MathArrays.equals(var68, var71);
    double var73 = org.apache.commons.math3.util.MathArrays.distance(var64, var68);
    double var74 = org.apache.commons.math3.util.MathArrays.linearCombination(var49, var64);
    double[] var75 = org.apache.commons.math3.util.MathArrays.ebeAdd(var43, var49);
    double[] var78 = new double[] { 100.0d, (-1.0d)};
    double[] var81 = new double[] { 100.0d, 1.0d};
    boolean var82 = org.apache.commons.math3.util.MathArrays.equals(var78, var81);
    double[] var85 = new double[] { 100.0d, (-1.0d)};
    double[] var88 = new double[] { 100.0d, 1.0d};
    boolean var89 = org.apache.commons.math3.util.MathArrays.equals(var85, var88);
    double var90 = org.apache.commons.math3.util.MathArrays.distance(var81, var85);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var91 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var2, var49, var81);
    boolean var92 = var91.isSupportConnected();
    double var94 = var91.density(0.40877566087838346d);
    var91.reseedRandomGenerator((-1L));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var99 = var91.cumulativeProbability(99.99999882208091d, 10.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var94 == 0.0d);

  }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    double[] var5 = new double[] { 100.0d, (-1.0d)};
    double[] var8 = new double[] { 100.0d, 1.0d};
    boolean var9 = org.apache.commons.math3.util.MathArrays.equals(var5, var8);
    double[] var12 = new double[] { 100.0d, (-1.0d)};
    double[] var15 = new double[] { 100.0d, 1.0d};
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var12, var15);
    double[] var19 = new double[] { 100.0d, (-1.0d)};
    double[] var22 = new double[] { 100.0d, 1.0d};
    boolean var23 = org.apache.commons.math3.util.MathArrays.equals(var19, var22);
    double var24 = org.apache.commons.math3.util.MathArrays.distance(var15, var19);
    double[] var27 = new double[] { 100.0d, (-1.0d)};
    double[] var30 = new double[] { 100.0d, 1.0d};
    boolean var31 = org.apache.commons.math3.util.MathArrays.equals(var27, var30);
    double[] var34 = new double[] { 100.0d, (-1.0d)};
    double[] var37 = new double[] { 100.0d, 1.0d};
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var34, var37);
    double var39 = org.apache.commons.math3.util.MathArrays.distance(var30, var34);
    double var40 = org.apache.commons.math3.util.MathArrays.linearCombination(var15, var30);
    boolean var41 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var5, var15);
    double[] var43 = org.apache.commons.math3.util.MathArrays.normalizeArray(var15, (-1.682916631768903d));
    double[] var46 = new double[] { 100.0d, (-1.0d)};
    double[] var49 = new double[] { 100.0d, 1.0d};
    boolean var50 = org.apache.commons.math3.util.MathArrays.equals(var46, var49);
    double[] var53 = new double[] { 100.0d, (-1.0d)};
    double[] var56 = new double[] { 100.0d, 1.0d};
    boolean var57 = org.apache.commons.math3.util.MathArrays.equals(var53, var56);
    double var58 = org.apache.commons.math3.util.MathArrays.distance(var49, var53);
    double[] var61 = new double[] { 100.0d, (-1.0d)};
    double[] var64 = new double[] { 100.0d, 1.0d};
    boolean var65 = org.apache.commons.math3.util.MathArrays.equals(var61, var64);
    double[] var68 = new double[] { 100.0d, (-1.0d)};
    double[] var71 = new double[] { 100.0d, 1.0d};
    boolean var72 = org.apache.commons.math3.util.MathArrays.equals(var68, var71);
    double var73 = org.apache.commons.math3.util.MathArrays.distance(var64, var68);
    double var74 = org.apache.commons.math3.util.MathArrays.linearCombination(var49, var64);
    double[] var75 = org.apache.commons.math3.util.MathArrays.ebeAdd(var43, var49);
    double[] var78 = new double[] { 100.0d, (-1.0d)};
    double[] var81 = new double[] { 100.0d, 1.0d};
    boolean var82 = org.apache.commons.math3.util.MathArrays.equals(var78, var81);
    double[] var85 = new double[] { 100.0d, (-1.0d)};
    double[] var88 = new double[] { 100.0d, 1.0d};
    boolean var89 = org.apache.commons.math3.util.MathArrays.equals(var85, var88);
    double var90 = org.apache.commons.math3.util.MathArrays.distance(var81, var85);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var91 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var2, var49, var81);
    var91.reseedRandomGenerator((-1L));
    double var96 = var91.probability(0.6115651382182169d, 99.01980198019803d);
    double var99 = var91.probability(58.24014955836018d, 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var96 == 0.009900990099009901d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var99 == 0.9900990099009901d);

  }

  public void test461() {}
//   public void test461() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }
// 
// 
//     int[] var1 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     double[] var5 = new double[] { 100.0d, (-1.0d)};
//     double[] var8 = new double[] { 100.0d, 1.0d};
//     boolean var9 = org.apache.commons.math3.util.MathArrays.equals(var5, var8);
//     double[] var12 = new double[] { 100.0d, (-1.0d)};
//     double[] var15 = new double[] { 100.0d, 1.0d};
//     boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var12, var15);
//     double[] var19 = new double[] { 100.0d, (-1.0d)};
//     double[] var22 = new double[] { 100.0d, 1.0d};
//     boolean var23 = org.apache.commons.math3.util.MathArrays.equals(var19, var22);
//     double var24 = org.apache.commons.math3.util.MathArrays.distance(var15, var19);
//     double[] var27 = new double[] { 100.0d, (-1.0d)};
//     double[] var30 = new double[] { 100.0d, 1.0d};
//     boolean var31 = org.apache.commons.math3.util.MathArrays.equals(var27, var30);
//     double[] var34 = new double[] { 100.0d, (-1.0d)};
//     double[] var37 = new double[] { 100.0d, 1.0d};
//     boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var34, var37);
//     double var39 = org.apache.commons.math3.util.MathArrays.distance(var30, var34);
//     double var40 = org.apache.commons.math3.util.MathArrays.linearCombination(var15, var30);
//     boolean var41 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var5, var15);
//     double[] var43 = org.apache.commons.math3.util.MathArrays.normalizeArray(var15, (-1.682916631768903d));
//     double[] var46 = new double[] { 100.0d, (-1.0d)};
//     double[] var49 = new double[] { 100.0d, 1.0d};
//     boolean var50 = org.apache.commons.math3.util.MathArrays.equals(var46, var49);
//     double[] var53 = new double[] { 100.0d, (-1.0d)};
//     double[] var56 = new double[] { 100.0d, 1.0d};
//     boolean var57 = org.apache.commons.math3.util.MathArrays.equals(var53, var56);
//     double var58 = org.apache.commons.math3.util.MathArrays.distance(var49, var53);
//     double[] var61 = new double[] { 100.0d, (-1.0d)};
//     double[] var64 = new double[] { 100.0d, 1.0d};
//     boolean var65 = org.apache.commons.math3.util.MathArrays.equals(var61, var64);
//     double[] var68 = new double[] { 100.0d, (-1.0d)};
//     double[] var71 = new double[] { 100.0d, 1.0d};
//     boolean var72 = org.apache.commons.math3.util.MathArrays.equals(var68, var71);
//     double var73 = org.apache.commons.math3.util.MathArrays.distance(var64, var68);
//     double var74 = org.apache.commons.math3.util.MathArrays.linearCombination(var49, var64);
//     double[] var75 = org.apache.commons.math3.util.MathArrays.ebeAdd(var43, var49);
//     double[] var78 = new double[] { 100.0d, (-1.0d)};
//     double[] var81 = new double[] { 100.0d, 1.0d};
//     boolean var82 = org.apache.commons.math3.util.MathArrays.equals(var78, var81);
//     double[] var85 = new double[] { 100.0d, (-1.0d)};
//     double[] var88 = new double[] { 100.0d, 1.0d};
//     boolean var89 = org.apache.commons.math3.util.MathArrays.equals(var85, var88);
//     double var90 = org.apache.commons.math3.util.MathArrays.distance(var81, var85);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var91 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var2, var49, var81);
//     double[] var94 = new double[] { 100.0d, 1.0d};
//     double[] var95 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var81, var94);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var96 = null;
//     boolean var98 = org.apache.commons.math3.util.MathArrays.isMonotonic(var94, var96, true);
// 
//   }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(-0.022398407861035873d), var2, false);

  }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeedSecure(10L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var6 = var2.nextHexString(2147483647);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }

  }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var3 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)83.16731886273895d, (java.lang.Number)(-2.318656726153d), var3);

  }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }


    double[] var1 = new double[] { 0.0d};
    org.apache.commons.math3.util.MathArrays.OrderDirection var2 = null;
    boolean var4 = org.apache.commons.math3.util.MathArrays.isMonotonic(var1, var2, false);
    double[] var7 = new double[] { 100.0d, (-1.0d)};
    double[] var10 = new double[] { 100.0d, 1.0d};
    boolean var11 = org.apache.commons.math3.util.MathArrays.equals(var7, var10);
    double[] var14 = new double[] { 100.0d, (-1.0d)};
    double[] var17 = new double[] { 100.0d, 1.0d};
    boolean var18 = org.apache.commons.math3.util.MathArrays.equals(var14, var17);
    double var19 = org.apache.commons.math3.util.MathArrays.distance(var10, var14);
    double[] var22 = new double[] { 100.0d, (-1.0d)};
    double[] var25 = new double[] { 100.0d, 1.0d};
    boolean var26 = org.apache.commons.math3.util.MathArrays.equals(var22, var25);
    double[] var27 = org.apache.commons.math3.util.MathArrays.ebeDivide(var14, var22);
    double[] var30 = new double[] { 100.0d, (-1.0d)};
    double[] var33 = new double[] { 100.0d, 1.0d};
    boolean var34 = org.apache.commons.math3.util.MathArrays.equals(var30, var33);
    double[] var37 = new double[] { 100.0d, (-1.0d)};
    double[] var40 = new double[] { 100.0d, 1.0d};
    boolean var41 = org.apache.commons.math3.util.MathArrays.equals(var37, var40);
    double var42 = org.apache.commons.math3.util.MathArrays.distance(var33, var37);
    double[] var45 = new double[] { 100.0d, (-1.0d)};
    double[] var48 = new double[] { 100.0d, 1.0d};
    boolean var49 = org.apache.commons.math3.util.MathArrays.equals(var45, var48);
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeDivide(var37, var45);
    double[] var51 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var22, var50);
    org.apache.commons.math3.util.MathArrays.checkPositive(var50);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var53 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var50);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);

  }

  public void test466() {}
//   public void test466() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     long var6 = var2.nextLong((-1L), 10L);
//     double var8 = var2.nextChiSquare(99.01980198019803d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var2.nextInt(2035706397, 22);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 4L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 109.55549463575866d);
// 
//   }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(short)0, (java.lang.Number)83.16731886273895d, false);

  }

  public void test468() {}
//   public void test468() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextGaussian(10.0d, 2.0d);
//     int var7 = var1.nextInt(0, 1);
//     var1.reSeed(0L);
//     double var13 = var1.nextUniform(0.4363208126344491d, 94.5705477312919d, true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 12.463056599367073d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 70.40080058104351d);
// 
//   }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(-1.0750511664712115E8d));

  }

  public void test470() {}
//   public void test470() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var5 = var1.nextUniform((-0.03786377777366967d), 0.5650828929145241d, true);
//     var1.reSeed(100L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var1.nextGamma(0.0d, 2.027380293984852d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.1315720877890414d);
// 
//   }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)86, (java.lang.Number)1L, true);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    java.lang.Number var5 = var3.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1L+ "'", var5.equals(1L));

  }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    double[] var5 = new double[] { 100.0d, (-1.0d)};
    double[] var8 = new double[] { 100.0d, 1.0d};
    boolean var9 = org.apache.commons.math3.util.MathArrays.equals(var5, var8);
    double[] var12 = new double[] { 100.0d, (-1.0d)};
    double[] var15 = new double[] { 100.0d, 1.0d};
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var12, var15);
    double[] var19 = new double[] { 100.0d, (-1.0d)};
    double[] var22 = new double[] { 100.0d, 1.0d};
    boolean var23 = org.apache.commons.math3.util.MathArrays.equals(var19, var22);
    double var24 = org.apache.commons.math3.util.MathArrays.distance(var15, var19);
    double[] var27 = new double[] { 100.0d, (-1.0d)};
    double[] var30 = new double[] { 100.0d, 1.0d};
    boolean var31 = org.apache.commons.math3.util.MathArrays.equals(var27, var30);
    double[] var34 = new double[] { 100.0d, (-1.0d)};
    double[] var37 = new double[] { 100.0d, 1.0d};
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var34, var37);
    double var39 = org.apache.commons.math3.util.MathArrays.distance(var30, var34);
    double var40 = org.apache.commons.math3.util.MathArrays.linearCombination(var15, var30);
    boolean var41 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var5, var15);
    double[] var43 = org.apache.commons.math3.util.MathArrays.normalizeArray(var15, (-1.682916631768903d));
    double[] var46 = new double[] { 100.0d, (-1.0d)};
    double[] var49 = new double[] { 100.0d, 1.0d};
    boolean var50 = org.apache.commons.math3.util.MathArrays.equals(var46, var49);
    double[] var53 = new double[] { 100.0d, (-1.0d)};
    double[] var56 = new double[] { 100.0d, 1.0d};
    boolean var57 = org.apache.commons.math3.util.MathArrays.equals(var53, var56);
    double var58 = org.apache.commons.math3.util.MathArrays.distance(var49, var53);
    double[] var61 = new double[] { 100.0d, (-1.0d)};
    double[] var64 = new double[] { 100.0d, 1.0d};
    boolean var65 = org.apache.commons.math3.util.MathArrays.equals(var61, var64);
    double[] var68 = new double[] { 100.0d, (-1.0d)};
    double[] var71 = new double[] { 100.0d, 1.0d};
    boolean var72 = org.apache.commons.math3.util.MathArrays.equals(var68, var71);
    double var73 = org.apache.commons.math3.util.MathArrays.distance(var64, var68);
    double var74 = org.apache.commons.math3.util.MathArrays.linearCombination(var49, var64);
    double[] var75 = org.apache.commons.math3.util.MathArrays.ebeAdd(var43, var49);
    double[] var78 = new double[] { 100.0d, (-1.0d)};
    double[] var81 = new double[] { 100.0d, 1.0d};
    boolean var82 = org.apache.commons.math3.util.MathArrays.equals(var78, var81);
    double[] var85 = new double[] { 100.0d, (-1.0d)};
    double[] var88 = new double[] { 100.0d, 1.0d};
    boolean var89 = org.apache.commons.math3.util.MathArrays.equals(var85, var88);
    double var90 = org.apache.commons.math3.util.MathArrays.distance(var81, var85);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var91 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var2, var49, var81);
    double var93 = var91.density(111.37224047421323d);
    double var96 = var91.cumulativeProbability(0.0d, 69.98119896658409d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var96 == 0.009900990099009901d);

  }

  public void test473() {}
//   public void test473() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var5 = var2.nextSecureLong(0L, 1L);
//     var2.reSeed(6L);
//     java.lang.String var9 = var2.nextSecureHexString(10);
//     java.util.Collection var10 = null;
//     java.lang.Object[] var12 = var2.nextSample(var10, 12);
// 
//   }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.lang.Object[] var4 = new java.lang.Object[] { 10.0d};
    org.apache.commons.math3.exception.NullArgumentException var5 = new org.apache.commons.math3.exception.NullArgumentException(var2, var4);
    org.apache.commons.math3.exception.MathIllegalStateException var6 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, var4);
    org.apache.commons.math3.exception.NullArgumentException var7 = new org.apache.commons.math3.exception.NullArgumentException(var0, var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, var1);
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.NotPositiveException var5 = new org.apache.commons.math3.exception.NotPositiveException(var3, (java.lang.Number)100L);
    java.lang.Number var6 = var5.getMin();
    var2.addSuppressed((java.lang.Throwable)var5);
    boolean var8 = var5.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 0+ "'", var6.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);

  }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(10L);
    var4.setSeed(10);
    int var8 = var4.nextInt(100);
    int[] var10 = new int[] { (-1)};
    int[] var11 = org.apache.commons.math3.util.MathArrays.copyOf(var10);
    int[] var12 = org.apache.commons.math3.util.MathArrays.copyOf(var11);
    var4.setSeed(var12);
    int var14 = org.apache.commons.math3.util.MathArrays.distance1(var1, var12);
    org.apache.commons.math3.exception.util.Localizable var15 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var19 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var15, (java.lang.Number)1.0d, (java.lang.Number)10, true);
    org.apache.commons.math3.random.Well19937c var21 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var22 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var21);
    org.apache.commons.math3.util.Pair var23 = new org.apache.commons.math3.util.Pair((java.lang.Object)true, (java.lang.Object)var21);
    int[] var25 = new int[] { (-1)};
    int[] var26 = org.apache.commons.math3.util.MathArrays.copyOf(var25);
    int[] var27 = org.apache.commons.math3.util.MathArrays.copyOf(var26);
    int[] var28 = org.apache.commons.math3.util.MathArrays.copyOf(var26);
    org.apache.commons.math3.random.Well19937c var29 = new org.apache.commons.math3.random.Well19937c(var26);
    var21.setSeed(var26);
    double var31 = org.apache.commons.math3.util.MathArrays.distance(var1, var26);
    org.apache.commons.math3.random.Well19937c var32 = new org.apache.commons.math3.random.Well19937c(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 1.0d);

  }

  public void test477() {}
//   public void test477() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     long var6 = var2.nextLong((-1L), 10L);
//     var2.reSeedSecure(6L);
//     java.lang.String var10 = var2.nextHexString(1);
//     var2.reSeedSecure(3L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "8"+ "'", var10.equals("8"));
// 
//   }

  public void test478() {}
//   public void test478() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     long var6 = var2.nextLong((-1L), 10L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var2.nextHypergeometric(0, 10, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2L);
// 
//   }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    double[] var5 = new double[] { 100.0d, (-1.0d)};
    double[] var8 = new double[] { 100.0d, 1.0d};
    boolean var9 = org.apache.commons.math3.util.MathArrays.equals(var5, var8);
    double[] var12 = new double[] { 100.0d, (-1.0d)};
    double[] var15 = new double[] { 100.0d, 1.0d};
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var12, var15);
    double[] var19 = new double[] { 100.0d, (-1.0d)};
    double[] var22 = new double[] { 100.0d, 1.0d};
    boolean var23 = org.apache.commons.math3.util.MathArrays.equals(var19, var22);
    double var24 = org.apache.commons.math3.util.MathArrays.distance(var15, var19);
    double[] var27 = new double[] { 100.0d, (-1.0d)};
    double[] var30 = new double[] { 100.0d, 1.0d};
    boolean var31 = org.apache.commons.math3.util.MathArrays.equals(var27, var30);
    double[] var34 = new double[] { 100.0d, (-1.0d)};
    double[] var37 = new double[] { 100.0d, 1.0d};
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var34, var37);
    double var39 = org.apache.commons.math3.util.MathArrays.distance(var30, var34);
    double var40 = org.apache.commons.math3.util.MathArrays.linearCombination(var15, var30);
    boolean var41 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var5, var15);
    double[] var43 = org.apache.commons.math3.util.MathArrays.normalizeArray(var15, (-1.682916631768903d));
    double[] var46 = new double[] { 100.0d, (-1.0d)};
    double[] var49 = new double[] { 100.0d, 1.0d};
    boolean var50 = org.apache.commons.math3.util.MathArrays.equals(var46, var49);
    double[] var53 = new double[] { 100.0d, (-1.0d)};
    double[] var56 = new double[] { 100.0d, 1.0d};
    boolean var57 = org.apache.commons.math3.util.MathArrays.equals(var53, var56);
    double var58 = org.apache.commons.math3.util.MathArrays.distance(var49, var53);
    double[] var61 = new double[] { 100.0d, (-1.0d)};
    double[] var64 = new double[] { 100.0d, 1.0d};
    boolean var65 = org.apache.commons.math3.util.MathArrays.equals(var61, var64);
    double[] var68 = new double[] { 100.0d, (-1.0d)};
    double[] var71 = new double[] { 100.0d, 1.0d};
    boolean var72 = org.apache.commons.math3.util.MathArrays.equals(var68, var71);
    double var73 = org.apache.commons.math3.util.MathArrays.distance(var64, var68);
    double var74 = org.apache.commons.math3.util.MathArrays.linearCombination(var49, var64);
    double[] var75 = org.apache.commons.math3.util.MathArrays.ebeAdd(var43, var49);
    double[] var78 = new double[] { 100.0d, (-1.0d)};
    double[] var81 = new double[] { 100.0d, 1.0d};
    boolean var82 = org.apache.commons.math3.util.MathArrays.equals(var78, var81);
    double[] var85 = new double[] { 100.0d, (-1.0d)};
    double[] var88 = new double[] { 100.0d, 1.0d};
    boolean var89 = org.apache.commons.math3.util.MathArrays.equals(var85, var88);
    double var90 = org.apache.commons.math3.util.MathArrays.distance(var81, var85);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var91 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var2, var49, var81);
    double var93 = var91.cumulativeProbability(3.31077097012213d);
    double var95 = var91.density(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == 0.009900990099009901d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var95 == 0.0d);

  }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.lang.Object[] var4 = new java.lang.Object[] { 10.0d};
    org.apache.commons.math3.exception.NullArgumentException var5 = new org.apache.commons.math3.exception.NullArgumentException(var2, var4);
    org.apache.commons.math3.exception.MathIllegalArgumentException var6 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, var4);
    org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test481() {}
//   public void test481() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextGaussian(0.0d, 2.0d);
//     java.lang.String var6 = var1.nextHexString(10);
//     long var8 = var1.nextPoisson(0.40877566087838346d);
//     double var10 = var1.nextT(0.2323975705328034d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var1.nextUniform(0.0d, (-1.0d), true);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-0.19522969799069248d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "a8763f54d6"+ "'", var6.equals("a8763f54d6"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.27577880179937825d);
// 
//   }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }


    double[] var2 = new double[] { 100.0d, (-1.0d)};
    double[] var5 = new double[] { 100.0d, 1.0d};
    boolean var6 = org.apache.commons.math3.util.MathArrays.equals(var2, var5);
    double[] var9 = new double[] { 100.0d, (-1.0d)};
    double[] var12 = new double[] { 100.0d, 1.0d};
    boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var9, var12);
    double var14 = org.apache.commons.math3.util.MathArrays.distance(var5, var9);
    double[] var17 = new double[] { 100.0d, (-1.0d)};
    double[] var20 = new double[] { 100.0d, 1.0d};
    boolean var21 = org.apache.commons.math3.util.MathArrays.equals(var17, var20);
    double[] var24 = new double[] { 100.0d, (-1.0d)};
    double[] var27 = new double[] { 100.0d, 1.0d};
    boolean var28 = org.apache.commons.math3.util.MathArrays.equals(var24, var27);
    double[] var31 = new double[] { 100.0d, (-1.0d)};
    double[] var34 = new double[] { 100.0d, 1.0d};
    boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var31, var34);
    double var36 = org.apache.commons.math3.util.MathArrays.distance(var27, var31);
    double[] var39 = new double[] { 100.0d, (-1.0d)};
    double[] var42 = new double[] { 100.0d, 1.0d};
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var39, var42);
    double[] var46 = new double[] { 100.0d, (-1.0d)};
    double[] var49 = new double[] { 100.0d, 1.0d};
    boolean var50 = org.apache.commons.math3.util.MathArrays.equals(var46, var49);
    double var51 = org.apache.commons.math3.util.MathArrays.distance(var42, var46);
    double var52 = org.apache.commons.math3.util.MathArrays.linearCombination(var27, var42);
    boolean var53 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var17, var27);
    double var54 = org.apache.commons.math3.util.MathArrays.distanceInf(var5, var17);
    double[] var57 = new double[] { 100.0d, (-1.0d)};
    double[] var60 = new double[] { 100.0d, 1.0d};
    boolean var61 = org.apache.commons.math3.util.MathArrays.equals(var57, var60);
    double[] var62 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var5, var57);
    double[] var65 = new double[] { 100.0d, (-1.0d)};
    double[] var68 = new double[] { 100.0d, 1.0d};
    boolean var69 = org.apache.commons.math3.util.MathArrays.equals(var65, var68);
    boolean var70 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var5, var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);

  }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var7 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)86, (java.lang.Number)1L, true);
    java.lang.Throwable[] var8 = var7.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var9 = new org.apache.commons.math3.exception.NotFiniteNumberException(var2, (java.lang.Number)1.0f, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathIllegalArgumentException var11 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    var1.setSeed(10);
    int var5 = var1.nextInt(86);
    int[] var7 = new int[] { (-1)};
    int[] var8 = org.apache.commons.math3.util.MathArrays.copyOf(var7);
    int[] var10 = new int[] { (-1)};
    int[] var11 = org.apache.commons.math3.util.MathArrays.copyOf(var10);
    int var12 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var10);
    org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(var10);
    var1.setSeed(var10);
    int[] var16 = new int[] { (-1)};
    int[] var17 = org.apache.commons.math3.util.MathArrays.copyOf(var16);
    var1.setSeed(var17);
    int[] var20 = new int[] { (-1)};
    int[] var21 = org.apache.commons.math3.util.MathArrays.copyOf(var20);
    int[] var22 = org.apache.commons.math3.util.MathArrays.copyOf(var21);
    int var23 = org.apache.commons.math3.util.MathArrays.distance1(var17, var21);
    int[] var25 = org.apache.commons.math3.util.MathArrays.copyOf(var21, 99);
    int[] var26 = org.apache.commons.math3.util.MathArrays.copyOf(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test485() {}
//   public void test485() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }
// 
// 
//     double[] var2 = new double[] { 100.0d, (-1.0d)};
//     double[] var5 = new double[] { 100.0d, 1.0d};
//     boolean var6 = org.apache.commons.math3.util.MathArrays.equals(var2, var5);
//     double[] var9 = new double[] { 100.0d, (-1.0d)};
//     double[] var12 = new double[] { 100.0d, 1.0d};
//     boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var9, var12);
//     double var14 = org.apache.commons.math3.util.MathArrays.distance(var5, var9);
//     double[] var17 = new double[] { 100.0d, (-1.0d)};
//     double[] var20 = new double[] { 100.0d, 1.0d};
//     boolean var21 = org.apache.commons.math3.util.MathArrays.equals(var17, var20);
//     double[] var24 = new double[] { 100.0d, (-1.0d)};
//     double[] var27 = new double[] { 100.0d, 1.0d};
//     boolean var28 = org.apache.commons.math3.util.MathArrays.equals(var24, var27);
//     double[] var31 = new double[] { 100.0d, (-1.0d)};
//     double[] var34 = new double[] { 100.0d, 1.0d};
//     boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var31, var34);
//     double var36 = org.apache.commons.math3.util.MathArrays.distance(var27, var31);
//     double[] var39 = new double[] { 100.0d, (-1.0d)};
//     double[] var42 = new double[] { 100.0d, 1.0d};
//     boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var39, var42);
//     double[] var46 = new double[] { 100.0d, (-1.0d)};
//     double[] var49 = new double[] { 100.0d, 1.0d};
//     boolean var50 = org.apache.commons.math3.util.MathArrays.equals(var46, var49);
//     double var51 = org.apache.commons.math3.util.MathArrays.distance(var42, var46);
//     double var52 = org.apache.commons.math3.util.MathArrays.linearCombination(var27, var42);
//     boolean var53 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var17, var27);
//     double[] var55 = org.apache.commons.math3.util.MathArrays.normalizeArray(var27, (-1.682916631768903d));
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var56 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var9, var27);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var57 = null;
//     boolean var60 = org.apache.commons.math3.util.MathArrays.checkOrder(var27, var57, false, true);
// 
//   }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed((-1L));
    double var6 = var0.nextUniform(0.0d, 2.3590437156692077d, false);
    double var9 = var0.nextGamma(885.3062819424027d, 96.07881580237154d);
    double var13 = var0.nextUniform((-0.022398407861035873d), 10.883385168453582d, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.5650828929145241d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 80739.49636849186d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 2.398467417074526d);

  }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextPascal(86, 0.0d);
    var2.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var9 = var2.nextUniform(9898.0d, (-0.9455744221955024d));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2147483647);

  }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }


    double[] var2 = new double[] { 100.0d, (-1.0d)};
    double[] var5 = new double[] { 100.0d, 1.0d};
    boolean var6 = org.apache.commons.math3.util.MathArrays.equals(var2, var5);
    double[] var9 = new double[] { 100.0d, (-1.0d)};
    double[] var12 = new double[] { 100.0d, 1.0d};
    boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var9, var12);
    double[] var16 = new double[] { 100.0d, (-1.0d)};
    double[] var19 = new double[] { 100.0d, 1.0d};
    boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var16, var19);
    double var21 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double[] var24 = new double[] { 100.0d, (-1.0d)};
    double[] var27 = new double[] { 100.0d, 1.0d};
    boolean var28 = org.apache.commons.math3.util.MathArrays.equals(var24, var27);
    double[] var31 = new double[] { 100.0d, (-1.0d)};
    double[] var34 = new double[] { 100.0d, 1.0d};
    boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var31, var34);
    double var36 = org.apache.commons.math3.util.MathArrays.distance(var27, var31);
    double var37 = org.apache.commons.math3.util.MathArrays.linearCombination(var12, var27);
    boolean var38 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var2, var12);
    double[] var40 = org.apache.commons.math3.util.MathArrays.normalizeArray(var12, (-1.682916631768903d));
    double[] var43 = new double[] { 100.0d, (-1.0d)};
    double[] var46 = new double[] { 100.0d, 1.0d};
    boolean var47 = org.apache.commons.math3.util.MathArrays.equals(var43, var46);
    double[] var50 = new double[] { 100.0d, (-1.0d)};
    double[] var53 = new double[] { 100.0d, 1.0d};
    boolean var54 = org.apache.commons.math3.util.MathArrays.equals(var50, var53);
    double var55 = org.apache.commons.math3.util.MathArrays.distance(var46, var50);
    double[] var58 = new double[] { 100.0d, (-1.0d)};
    double[] var61 = new double[] { 100.0d, 1.0d};
    boolean var62 = org.apache.commons.math3.util.MathArrays.equals(var58, var61);
    double[] var63 = org.apache.commons.math3.util.MathArrays.ebeDivide(var50, var58);
    double[] var64 = org.apache.commons.math3.util.MathArrays.ebeDivide(var12, var58);
    double[] var65 = org.apache.commons.math3.util.MathArrays.copyOf(var64);
    double[] var66 = org.apache.commons.math3.util.MathArrays.copyOf(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);

  }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeedSecure(10L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var7 = var2.nextInt(52, 22);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }


    double[] var2 = new double[] { 100.0d, (-1.0d)};
    double[] var5 = new double[] { 100.0d, 1.0d};
    boolean var6 = org.apache.commons.math3.util.MathArrays.equals(var2, var5);
    double[] var9 = new double[] { 100.0d, (-1.0d)};
    double[] var12 = new double[] { 100.0d, 1.0d};
    boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var9, var12);
    double var14 = org.apache.commons.math3.util.MathArrays.distance(var5, var9);
    double[] var17 = new double[] { 100.0d, (-1.0d)};
    double[] var20 = new double[] { 100.0d, 1.0d};
    boolean var21 = org.apache.commons.math3.util.MathArrays.equals(var17, var20);
    double[] var22 = org.apache.commons.math3.util.MathArrays.ebeDivide(var9, var17);
    double[] var25 = new double[] { 100.0d, (-1.0d)};
    double[] var28 = new double[] { 100.0d, 1.0d};
    boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var25, var28);
    double[] var32 = new double[] { 100.0d, (-1.0d)};
    double[] var35 = new double[] { 100.0d, 1.0d};
    boolean var36 = org.apache.commons.math3.util.MathArrays.equals(var32, var35);
    double var37 = org.apache.commons.math3.util.MathArrays.distance(var28, var32);
    double[] var40 = new double[] { 100.0d, (-1.0d)};
    double[] var43 = new double[] { 100.0d, 1.0d};
    boolean var44 = org.apache.commons.math3.util.MathArrays.equals(var40, var43);
    double[] var45 = org.apache.commons.math3.util.MathArrays.ebeDivide(var32, var40);
    double[] var46 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var17, var45);
    double[] var48 = new double[] { 10.0d};
    double var49 = org.apache.commons.math3.util.MathArrays.safeNorm(var48);
    org.apache.commons.math3.util.MathArrays.OrderDirection var50 = null;
    boolean var52 = org.apache.commons.math3.util.MathArrays.isMonotonic(var48, var50, false);
    org.apache.commons.math3.util.MathArrays.OrderDirection var53 = null;
    boolean var56 = org.apache.commons.math3.util.MathArrays.checkOrder(var48, var53, false, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var57 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var45, var48);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == true);

  }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.0f, (java.lang.Number)2147483647, true);

  }

  public void test492() {}
//   public void test492() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextGaussian(0.0d, 2.0d);
//     var1.reSeedSecure(0L);
//     double var9 = var1.nextWeibull(2.0d, 9854048.12570597d);
//     long var11 = var1.nextPoisson(885.3062819424027d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var1.nextPascal(99, 58.24014955836018d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.554829358159634d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 8678227.074855005d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 874L);
// 
//   }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var3 = var0.nextBeta((-1.6478376658157248d), 2.398467417074526d);
      fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
    } catch (org.apache.commons.math3.exception.NoBracketingException e) {
      // Expected exception.
    }

  }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)7L);

  }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }


    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Object[] var5 = new java.lang.Object[] { 864L};
    org.apache.commons.math3.exception.MathInternalError var6 = new org.apache.commons.math3.exception.MathInternalError(var3, var5);
    org.apache.commons.math3.exception.NotFiniteNumberException var7 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Number)(-2.1148810308778625d), var5);
    org.apache.commons.math3.exception.NotFiniteNumberException var8 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-9.400079531200032E7d), var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }


    double[] var0 = null;
    double[] var3 = new double[] { 100.0d, (-1.0d)};
    double[] var6 = new double[] { 100.0d, 1.0d};
    boolean var7 = org.apache.commons.math3.util.MathArrays.equals(var3, var6);
    double[] var10 = new double[] { 100.0d, (-1.0d)};
    double[] var13 = new double[] { 100.0d, 1.0d};
    boolean var14 = org.apache.commons.math3.util.MathArrays.equals(var10, var13);
    double var15 = org.apache.commons.math3.util.MathArrays.distance(var6, var10);
    double[] var18 = new double[] { 100.0d, (-1.0d)};
    double[] var21 = new double[] { 100.0d, 1.0d};
    boolean var22 = org.apache.commons.math3.util.MathArrays.equals(var18, var21);
    double[] var25 = new double[] { 100.0d, (-1.0d)};
    double[] var28 = new double[] { 100.0d, 1.0d};
    boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var25, var28);
    double var30 = org.apache.commons.math3.util.MathArrays.distance(var21, var25);
    double var31 = org.apache.commons.math3.util.MathArrays.linearCombination(var6, var21);
    boolean var32 = org.apache.commons.math3.util.MathArrays.equals(var0, var6);
    org.apache.commons.math3.util.MathArrays.checkPositive(var6);
    double[] var35 = org.apache.commons.math3.util.MathArrays.copyOf(var6, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test497() {}
//   public void test497() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed((-1L));
//     long var5 = var0.nextSecureLong(0L, 5L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1L);
// 
//   }

  public void test498() {}
//   public void test498() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }
// 
// 
//     double[] var0 = null;
//     double[] var3 = new double[] { 100.0d, (-1.0d)};
//     double[] var6 = new double[] { 100.0d, 1.0d};
//     boolean var7 = org.apache.commons.math3.util.MathArrays.equals(var3, var6);
//     double[] var10 = new double[] { 100.0d, (-1.0d)};
//     double[] var13 = new double[] { 100.0d, 1.0d};
//     boolean var14 = org.apache.commons.math3.util.MathArrays.equals(var10, var13);
//     double var15 = org.apache.commons.math3.util.MathArrays.distance(var6, var10);
//     double[] var18 = new double[] { 100.0d, (-1.0d)};
//     double[] var21 = new double[] { 100.0d, 1.0d};
//     boolean var22 = org.apache.commons.math3.util.MathArrays.equals(var18, var21);
//     double[] var25 = new double[] { 100.0d, (-1.0d)};
//     double[] var28 = new double[] { 100.0d, 1.0d};
//     boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var25, var28);
//     double var30 = org.apache.commons.math3.util.MathArrays.distance(var21, var25);
//     double var31 = org.apache.commons.math3.util.MathArrays.linearCombination(var6, var21);
//     double[] var33 = org.apache.commons.math3.util.MathArrays.normalizeArray(var6, 0.0d);
//     double var34 = org.apache.commons.math3.util.MathArrays.distance(var0, var33);
// 
//   }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }


    double[] var2 = new double[] { 100.0d, (-1.0d)};
    double[] var5 = new double[] { 100.0d, 1.0d};
    boolean var6 = org.apache.commons.math3.util.MathArrays.equals(var2, var5);
    double[] var9 = new double[] { 100.0d, (-1.0d)};
    double[] var12 = new double[] { 100.0d, 1.0d};
    boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var9, var12);
    double[] var16 = new double[] { 100.0d, (-1.0d)};
    double[] var19 = new double[] { 100.0d, 1.0d};
    boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var16, var19);
    double var21 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double[] var24 = new double[] { 100.0d, (-1.0d)};
    double[] var27 = new double[] { 100.0d, 1.0d};
    boolean var28 = org.apache.commons.math3.util.MathArrays.equals(var24, var27);
    double[] var31 = new double[] { 100.0d, (-1.0d)};
    double[] var34 = new double[] { 100.0d, 1.0d};
    boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var31, var34);
    double var36 = org.apache.commons.math3.util.MathArrays.distance(var27, var31);
    double var37 = org.apache.commons.math3.util.MathArrays.linearCombination(var12, var27);
    boolean var38 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var2, var12);
    double[] var40 = org.apache.commons.math3.util.MathArrays.normalizeArray(var12, (-1.682916631768903d));
    double[] var43 = new double[] { 100.0d, (-1.0d)};
    double[] var46 = new double[] { 100.0d, 1.0d};
    boolean var47 = org.apache.commons.math3.util.MathArrays.equals(var43, var46);
    double[] var50 = new double[] { 100.0d, (-1.0d)};
    double[] var53 = new double[] { 100.0d, 1.0d};
    boolean var54 = org.apache.commons.math3.util.MathArrays.equals(var50, var53);
    double var55 = org.apache.commons.math3.util.MathArrays.distance(var46, var50);
    double[] var58 = new double[] { 100.0d, (-1.0d)};
    double[] var61 = new double[] { 100.0d, 1.0d};
    boolean var62 = org.apache.commons.math3.util.MathArrays.equals(var58, var61);
    double[] var65 = new double[] { 100.0d, (-1.0d)};
    double[] var68 = new double[] { 100.0d, 1.0d};
    boolean var69 = org.apache.commons.math3.util.MathArrays.equals(var65, var68);
    double var70 = org.apache.commons.math3.util.MathArrays.distance(var61, var65);
    double var71 = org.apache.commons.math3.util.MathArrays.linearCombination(var46, var61);
    double[] var72 = org.apache.commons.math3.util.MathArrays.ebeAdd(var40, var46);
    double[] var74 = new double[] { 10.0d};
    double var75 = org.apache.commons.math3.util.MathArrays.safeNorm(var74);
    org.apache.commons.math3.util.MathArrays.OrderDirection var76 = null;
    boolean var78 = org.apache.commons.math3.util.MathArrays.isMonotonic(var74, var76, false);
    boolean var79 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var72, var74);
    org.apache.commons.math3.util.MathArrays.checkPositive(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == false);

  }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var2.nextF(0.0d, (-1.1440322521572115d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

}
