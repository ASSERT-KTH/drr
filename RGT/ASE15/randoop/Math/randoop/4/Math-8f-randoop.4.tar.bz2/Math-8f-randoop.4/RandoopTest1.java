
import junit.framework.*;

public class RandoopTest1 extends TestCase {

  public static boolean debug = false;

  public void test1() {}
//   public void test1() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test1"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var5 = var2.nextSecureLong(0L, 1L);
//     var2.reSeed(6L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var10 = var2.nextSecureLong(10L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0L);
// 
//   }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test2"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var7 = var2.nextUniform(2.027380293984852d, (-10101.0d), true);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test3"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)100L);
    java.lang.Number var3 = var2.getMin();
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var2.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test4"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    double[] var5 = new double[] { 100.0d, (-1.0d)};
    double[] var8 = new double[] { 100.0d, 1.0d};
    boolean var9 = org.apache.commons.math3.util.MathArrays.equals(var5, var8);
    double[] var12 = new double[] { 100.0d, (-1.0d)};
    double[] var15 = new double[] { 100.0d, 1.0d};
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var12, var15);
    double[] var19 = new double[] { 100.0d, (-1.0d)};
    double[] var22 = new double[] { 100.0d, 1.0d};
    boolean var23 = org.apache.commons.math3.util.MathArrays.equals(var19, var22);
    double var24 = org.apache.commons.math3.util.MathArrays.distance(var15, var19);
    double[] var27 = new double[] { 100.0d, (-1.0d)};
    double[] var30 = new double[] { 100.0d, 1.0d};
    boolean var31 = org.apache.commons.math3.util.MathArrays.equals(var27, var30);
    double[] var34 = new double[] { 100.0d, (-1.0d)};
    double[] var37 = new double[] { 100.0d, 1.0d};
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var34, var37);
    double var39 = org.apache.commons.math3.util.MathArrays.distance(var30, var34);
    double var40 = org.apache.commons.math3.util.MathArrays.linearCombination(var15, var30);
    boolean var41 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var5, var15);
    double[] var43 = org.apache.commons.math3.util.MathArrays.normalizeArray(var15, (-1.682916631768903d));
    double[] var46 = new double[] { 100.0d, (-1.0d)};
    double[] var49 = new double[] { 100.0d, 1.0d};
    boolean var50 = org.apache.commons.math3.util.MathArrays.equals(var46, var49);
    double[] var53 = new double[] { 100.0d, (-1.0d)};
    double[] var56 = new double[] { 100.0d, 1.0d};
    boolean var57 = org.apache.commons.math3.util.MathArrays.equals(var53, var56);
    double var58 = org.apache.commons.math3.util.MathArrays.distance(var49, var53);
    double[] var61 = new double[] { 100.0d, (-1.0d)};
    double[] var64 = new double[] { 100.0d, 1.0d};
    boolean var65 = org.apache.commons.math3.util.MathArrays.equals(var61, var64);
    double[] var68 = new double[] { 100.0d, (-1.0d)};
    double[] var71 = new double[] { 100.0d, 1.0d};
    boolean var72 = org.apache.commons.math3.util.MathArrays.equals(var68, var71);
    double var73 = org.apache.commons.math3.util.MathArrays.distance(var64, var68);
    double var74 = org.apache.commons.math3.util.MathArrays.linearCombination(var49, var64);
    double[] var75 = org.apache.commons.math3.util.MathArrays.ebeAdd(var43, var49);
    double[] var78 = new double[] { 100.0d, (-1.0d)};
    double[] var81 = new double[] { 100.0d, 1.0d};
    boolean var82 = org.apache.commons.math3.util.MathArrays.equals(var78, var81);
    double[] var85 = new double[] { 100.0d, (-1.0d)};
    double[] var88 = new double[] { 100.0d, 1.0d};
    boolean var89 = org.apache.commons.math3.util.MathArrays.equals(var85, var88);
    double var90 = org.apache.commons.math3.util.MathArrays.distance(var81, var85);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var91 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var2, var49, var81);
    double var93 = var91.density(111.37224047421323d);
    var91.reseedRandomGenerator((-1L));
    double var96 = var91.sample();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var96 == 100.0d);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test5"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    var1.setSeed(10);
    int var5 = var1.nextInt(100);
    int[] var7 = new int[] { (-1)};
    int[] var8 = org.apache.commons.math3.util.MathArrays.copyOf(var7);
    int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var8);
    var1.setSeed(var9);
    int[] var12 = new int[] { (-1)};
    int[] var13 = org.apache.commons.math3.util.MathArrays.copyOf(var12);
    int[] var15 = new int[] { (-1)};
    int[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var15);
    int var17 = org.apache.commons.math3.util.MathArrays.distanceInf(var13, var15);
    org.apache.commons.math3.random.Well19937c var19 = new org.apache.commons.math3.random.Well19937c(10L);
    var19.setSeed(10);
    int var23 = var19.nextInt(86);
    int[] var25 = new int[] { (-1)};
    int[] var26 = org.apache.commons.math3.util.MathArrays.copyOf(var25);
    int[] var28 = new int[] { (-1)};
    int[] var29 = org.apache.commons.math3.util.MathArrays.copyOf(var28);
    int var30 = org.apache.commons.math3.util.MathArrays.distanceInf(var26, var28);
    org.apache.commons.math3.random.Well19937c var31 = new org.apache.commons.math3.random.Well19937c(var28);
    var19.setSeed(var28);
    int[] var34 = new int[] { (-1)};
    int[] var35 = org.apache.commons.math3.util.MathArrays.copyOf(var34);
    var19.setSeed(var35);
    int var37 = org.apache.commons.math3.util.MathArrays.distanceInf(var15, var35);
    int[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var15, 16);
    int var40 = org.apache.commons.math3.util.MathArrays.distanceInf(var9, var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test6"); }


    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)2.0d, (java.lang.Object)(byte)(-1));
    java.lang.Object var3 = var2.getSecond();
    java.lang.Object var4 = var2.getKey();
    java.lang.Object var5 = var2.getFirst();
    java.lang.Object var6 = var2.getSecond();
    java.lang.Object var7 = var2.getValue();
    org.apache.commons.math3.exception.NotPositiveException var9 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(-1.056554310492439d));
    boolean var10 = var2.equals((java.lang.Object)var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + (byte)(-1)+ "'", var3.equals((byte)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 2.0d+ "'", var4.equals(2.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 2.0d+ "'", var5.equals(2.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (byte)(-1)+ "'", var6.equals((byte)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (byte)(-1)+ "'", var7.equals((byte)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test7() {}
//   public void test7() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test7"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(10L);
//     var2.setSeed(10);
//     int var6 = var2.nextInt(86);
//     int[] var8 = new int[] { (-1)};
//     int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var8);
//     int[] var11 = new int[] { (-1)};
//     int[] var12 = org.apache.commons.math3.util.MathArrays.copyOf(var11);
//     int var13 = org.apache.commons.math3.util.MathArrays.distanceInf(var9, var11);
//     org.apache.commons.math3.random.Well19937c var14 = new org.apache.commons.math3.random.Well19937c(var11);
//     var2.setSeed(var11);
//     int[] var17 = new int[] { (-1)};
//     int[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var17);
//     var2.setSeed(var18);
//     int[] var21 = new int[] { (-1)};
//     int[] var22 = org.apache.commons.math3.util.MathArrays.copyOf(var21);
//     int[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var22);
//     int var24 = org.apache.commons.math3.util.MathArrays.distance1(var18, var22);
//     int var25 = org.apache.commons.math3.util.MathArrays.distanceInf(var0, var18);
// 
//   }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test8"); }


    int[] var1 = new int[] { (-1)};
    int[] var2 = org.apache.commons.math3.util.MathArrays.copyOf(var1);
    int[] var4 = new int[] { (-1)};
    int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
    int var6 = org.apache.commons.math3.util.MathArrays.distanceInf(var2, var4);
    org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(var4);
    int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var4, 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test9"); }


    int[] var2 = new int[] { 0, 0};
    org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(10L);
    var4.setSeed(10);
    int var8 = var4.nextInt(86);
    int[] var10 = new int[] { (-1)};
    int[] var11 = org.apache.commons.math3.util.MathArrays.copyOf(var10);
    int[] var13 = new int[] { (-1)};
    int[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var13);
    int var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var11, var13);
    org.apache.commons.math3.random.Well19937c var16 = new org.apache.commons.math3.random.Well19937c(var13);
    var4.setSeed(var13);
    int[] var19 = new int[] { (-1)};
    int[] var20 = org.apache.commons.math3.util.MathArrays.copyOf(var19);
    int[] var21 = org.apache.commons.math3.util.MathArrays.copyOf(var20);
    int[] var22 = org.apache.commons.math3.util.MathArrays.copyOf(var20);
    var4.setSeed(var20);
    org.apache.commons.math3.random.Well19937c var24 = new org.apache.commons.math3.random.Well19937c(var20);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var25 = org.apache.commons.math3.util.MathArrays.distanceInf(var2, var20);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test10"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    double[] var5 = new double[] { 100.0d, (-1.0d)};
    double[] var8 = new double[] { 100.0d, 1.0d};
    boolean var9 = org.apache.commons.math3.util.MathArrays.equals(var5, var8);
    double[] var12 = new double[] { 100.0d, (-1.0d)};
    double[] var15 = new double[] { 100.0d, 1.0d};
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var12, var15);
    double[] var19 = new double[] { 100.0d, (-1.0d)};
    double[] var22 = new double[] { 100.0d, 1.0d};
    boolean var23 = org.apache.commons.math3.util.MathArrays.equals(var19, var22);
    double var24 = org.apache.commons.math3.util.MathArrays.distance(var15, var19);
    double[] var27 = new double[] { 100.0d, (-1.0d)};
    double[] var30 = new double[] { 100.0d, 1.0d};
    boolean var31 = org.apache.commons.math3.util.MathArrays.equals(var27, var30);
    double[] var34 = new double[] { 100.0d, (-1.0d)};
    double[] var37 = new double[] { 100.0d, 1.0d};
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var34, var37);
    double var39 = org.apache.commons.math3.util.MathArrays.distance(var30, var34);
    double var40 = org.apache.commons.math3.util.MathArrays.linearCombination(var15, var30);
    boolean var41 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var5, var15);
    double[] var43 = org.apache.commons.math3.util.MathArrays.normalizeArray(var15, (-1.682916631768903d));
    double[] var46 = new double[] { 100.0d, (-1.0d)};
    double[] var49 = new double[] { 100.0d, 1.0d};
    boolean var50 = org.apache.commons.math3.util.MathArrays.equals(var46, var49);
    double[] var53 = new double[] { 100.0d, (-1.0d)};
    double[] var56 = new double[] { 100.0d, 1.0d};
    boolean var57 = org.apache.commons.math3.util.MathArrays.equals(var53, var56);
    double var58 = org.apache.commons.math3.util.MathArrays.distance(var49, var53);
    double[] var61 = new double[] { 100.0d, (-1.0d)};
    double[] var64 = new double[] { 100.0d, 1.0d};
    boolean var65 = org.apache.commons.math3.util.MathArrays.equals(var61, var64);
    double[] var68 = new double[] { 100.0d, (-1.0d)};
    double[] var71 = new double[] { 100.0d, 1.0d};
    boolean var72 = org.apache.commons.math3.util.MathArrays.equals(var68, var71);
    double var73 = org.apache.commons.math3.util.MathArrays.distance(var64, var68);
    double var74 = org.apache.commons.math3.util.MathArrays.linearCombination(var49, var64);
    double[] var75 = org.apache.commons.math3.util.MathArrays.ebeAdd(var43, var49);
    double[] var78 = new double[] { 100.0d, (-1.0d)};
    double[] var81 = new double[] { 100.0d, 1.0d};
    boolean var82 = org.apache.commons.math3.util.MathArrays.equals(var78, var81);
    double[] var85 = new double[] { 100.0d, (-1.0d)};
    double[] var88 = new double[] { 100.0d, 1.0d};
    boolean var89 = org.apache.commons.math3.util.MathArrays.equals(var85, var88);
    double var90 = org.apache.commons.math3.util.MathArrays.distance(var81, var85);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var91 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var2, var49, var81);
    var91.reseedRandomGenerator((-1L));
    double var96 = var91.probability(0.6115651382182169d, 99.01980198019803d);
    boolean var97 = var91.isSupportLowerBoundInclusive();
    double var99 = var91.density(2.6669397224844205d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var96 == 0.009900990099009901d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var97 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var99 == 0.0d);

  }

  public void test11() {}
//   public void test11() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test11"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Number var1 = null;
//     org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, var1);
//     org.apache.commons.math3.exception.util.Localizable var3 = null;
//     org.apache.commons.math3.exception.NotPositiveException var5 = new org.apache.commons.math3.exception.NotPositiveException(var3, (java.lang.Number)100L);
//     java.lang.Number var6 = var5.getMin();
//     var2.addSuppressed((java.lang.Throwable)var5);
//     java.lang.String var8 = var5.toString();
// 
//   }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test12"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    double[] var5 = new double[] { 100.0d, (-1.0d)};
    double[] var8 = new double[] { 100.0d, 1.0d};
    boolean var9 = org.apache.commons.math3.util.MathArrays.equals(var5, var8);
    double[] var12 = new double[] { 100.0d, (-1.0d)};
    double[] var15 = new double[] { 100.0d, 1.0d};
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var12, var15);
    double[] var19 = new double[] { 100.0d, (-1.0d)};
    double[] var22 = new double[] { 100.0d, 1.0d};
    boolean var23 = org.apache.commons.math3.util.MathArrays.equals(var19, var22);
    double var24 = org.apache.commons.math3.util.MathArrays.distance(var15, var19);
    double[] var27 = new double[] { 100.0d, (-1.0d)};
    double[] var30 = new double[] { 100.0d, 1.0d};
    boolean var31 = org.apache.commons.math3.util.MathArrays.equals(var27, var30);
    double[] var34 = new double[] { 100.0d, (-1.0d)};
    double[] var37 = new double[] { 100.0d, 1.0d};
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var34, var37);
    double var39 = org.apache.commons.math3.util.MathArrays.distance(var30, var34);
    double var40 = org.apache.commons.math3.util.MathArrays.linearCombination(var15, var30);
    boolean var41 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var5, var15);
    double[] var43 = org.apache.commons.math3.util.MathArrays.normalizeArray(var15, (-1.682916631768903d));
    double[] var46 = new double[] { 100.0d, (-1.0d)};
    double[] var49 = new double[] { 100.0d, 1.0d};
    boolean var50 = org.apache.commons.math3.util.MathArrays.equals(var46, var49);
    double[] var53 = new double[] { 100.0d, (-1.0d)};
    double[] var56 = new double[] { 100.0d, 1.0d};
    boolean var57 = org.apache.commons.math3.util.MathArrays.equals(var53, var56);
    double var58 = org.apache.commons.math3.util.MathArrays.distance(var49, var53);
    double[] var61 = new double[] { 100.0d, (-1.0d)};
    double[] var64 = new double[] { 100.0d, 1.0d};
    boolean var65 = org.apache.commons.math3.util.MathArrays.equals(var61, var64);
    double[] var68 = new double[] { 100.0d, (-1.0d)};
    double[] var71 = new double[] { 100.0d, 1.0d};
    boolean var72 = org.apache.commons.math3.util.MathArrays.equals(var68, var71);
    double var73 = org.apache.commons.math3.util.MathArrays.distance(var64, var68);
    double var74 = org.apache.commons.math3.util.MathArrays.linearCombination(var49, var64);
    double[] var75 = org.apache.commons.math3.util.MathArrays.ebeAdd(var43, var49);
    double[] var78 = new double[] { 100.0d, (-1.0d)};
    double[] var81 = new double[] { 100.0d, 1.0d};
    boolean var82 = org.apache.commons.math3.util.MathArrays.equals(var78, var81);
    double[] var85 = new double[] { 100.0d, (-1.0d)};
    double[] var88 = new double[] { 100.0d, 1.0d};
    boolean var89 = org.apache.commons.math3.util.MathArrays.equals(var85, var88);
    double var90 = org.apache.commons.math3.util.MathArrays.distance(var81, var85);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var91 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var2, var49, var81);
    var2.setSeed(4L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 2.0d);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test13"); }


    double[] var0 = null;
    double[] var3 = new double[] { 100.0d, (-1.0d)};
    double[] var6 = new double[] { 100.0d, 1.0d};
    boolean var7 = org.apache.commons.math3.util.MathArrays.equals(var3, var6);
    double[] var10 = new double[] { 100.0d, (-1.0d)};
    double[] var13 = new double[] { 100.0d, 1.0d};
    boolean var14 = org.apache.commons.math3.util.MathArrays.equals(var10, var13);
    double var15 = org.apache.commons.math3.util.MathArrays.distance(var6, var10);
    double[] var18 = new double[] { 100.0d, (-1.0d)};
    double[] var21 = new double[] { 100.0d, 1.0d};
    boolean var22 = org.apache.commons.math3.util.MathArrays.equals(var18, var21);
    double[] var25 = new double[] { 100.0d, (-1.0d)};
    double[] var28 = new double[] { 100.0d, 1.0d};
    boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var25, var28);
    double[] var32 = new double[] { 100.0d, (-1.0d)};
    double[] var35 = new double[] { 100.0d, 1.0d};
    boolean var36 = org.apache.commons.math3.util.MathArrays.equals(var32, var35);
    double var37 = org.apache.commons.math3.util.MathArrays.distance(var28, var32);
    double[] var40 = new double[] { 100.0d, (-1.0d)};
    double[] var43 = new double[] { 100.0d, 1.0d};
    boolean var44 = org.apache.commons.math3.util.MathArrays.equals(var40, var43);
    double[] var47 = new double[] { 100.0d, (-1.0d)};
    double[] var50 = new double[] { 100.0d, 1.0d};
    boolean var51 = org.apache.commons.math3.util.MathArrays.equals(var47, var50);
    double var52 = org.apache.commons.math3.util.MathArrays.distance(var43, var47);
    double var53 = org.apache.commons.math3.util.MathArrays.linearCombination(var28, var43);
    boolean var54 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var18, var28);
    double var55 = org.apache.commons.math3.util.MathArrays.distanceInf(var6, var18);
    double[] var58 = new double[] { 100.0d, (-1.0d)};
    double[] var61 = new double[] { 100.0d, 1.0d};
    boolean var62 = org.apache.commons.math3.util.MathArrays.equals(var58, var61);
    double[] var63 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var6, var58);
    boolean var64 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var0, var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test14"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)12.463056599367073d, (java.lang.Number)83.16731886273895d, (java.lang.Number)1.2694665049707192d);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test15"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    double[] var5 = new double[] { 100.0d, (-1.0d)};
    double[] var8 = new double[] { 100.0d, 1.0d};
    boolean var9 = org.apache.commons.math3.util.MathArrays.equals(var5, var8);
    double[] var12 = new double[] { 100.0d, (-1.0d)};
    double[] var15 = new double[] { 100.0d, 1.0d};
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var12, var15);
    double[] var19 = new double[] { 100.0d, (-1.0d)};
    double[] var22 = new double[] { 100.0d, 1.0d};
    boolean var23 = org.apache.commons.math3.util.MathArrays.equals(var19, var22);
    double var24 = org.apache.commons.math3.util.MathArrays.distance(var15, var19);
    double[] var27 = new double[] { 100.0d, (-1.0d)};
    double[] var30 = new double[] { 100.0d, 1.0d};
    boolean var31 = org.apache.commons.math3.util.MathArrays.equals(var27, var30);
    double[] var34 = new double[] { 100.0d, (-1.0d)};
    double[] var37 = new double[] { 100.0d, 1.0d};
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var34, var37);
    double var39 = org.apache.commons.math3.util.MathArrays.distance(var30, var34);
    double var40 = org.apache.commons.math3.util.MathArrays.linearCombination(var15, var30);
    boolean var41 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var5, var15);
    double[] var43 = org.apache.commons.math3.util.MathArrays.normalizeArray(var15, (-1.682916631768903d));
    double[] var46 = new double[] { 100.0d, (-1.0d)};
    double[] var49 = new double[] { 100.0d, 1.0d};
    boolean var50 = org.apache.commons.math3.util.MathArrays.equals(var46, var49);
    double[] var53 = new double[] { 100.0d, (-1.0d)};
    double[] var56 = new double[] { 100.0d, 1.0d};
    boolean var57 = org.apache.commons.math3.util.MathArrays.equals(var53, var56);
    double var58 = org.apache.commons.math3.util.MathArrays.distance(var49, var53);
    double[] var61 = new double[] { 100.0d, (-1.0d)};
    double[] var64 = new double[] { 100.0d, 1.0d};
    boolean var65 = org.apache.commons.math3.util.MathArrays.equals(var61, var64);
    double[] var68 = new double[] { 100.0d, (-1.0d)};
    double[] var71 = new double[] { 100.0d, 1.0d};
    boolean var72 = org.apache.commons.math3.util.MathArrays.equals(var68, var71);
    double var73 = org.apache.commons.math3.util.MathArrays.distance(var64, var68);
    double var74 = org.apache.commons.math3.util.MathArrays.linearCombination(var49, var64);
    double[] var75 = org.apache.commons.math3.util.MathArrays.ebeAdd(var43, var49);
    double[] var78 = new double[] { 100.0d, (-1.0d)};
    double[] var81 = new double[] { 100.0d, 1.0d};
    boolean var82 = org.apache.commons.math3.util.MathArrays.equals(var78, var81);
    double[] var85 = new double[] { 100.0d, (-1.0d)};
    double[] var88 = new double[] { 100.0d, 1.0d};
    boolean var89 = org.apache.commons.math3.util.MathArrays.equals(var85, var88);
    double var90 = org.apache.commons.math3.util.MathArrays.distance(var81, var85);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var91 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var2, var49, var81);
    var91.reseedRandomGenerator(6L);
    double var95 = var91.probability(111.37224047421323d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var95 == 0.0d);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test16"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSecureAlgorithm("", "975a1ce676c0954a");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test17"); }


    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)2.0d, (java.lang.Object)(byte)(-1));
    java.lang.Object var3 = var2.getSecond();
    java.lang.Object var4 = var2.getKey();
    java.lang.Object var5 = var2.getFirst();
    org.apache.commons.math3.util.Pair var6 = new org.apache.commons.math3.util.Pair(var2);
    java.lang.Object var7 = var6.getSecond();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + (byte)(-1)+ "'", var3.equals((byte)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 2.0d+ "'", var4.equals(2.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 2.0d+ "'", var5.equals(2.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (byte)(-1)+ "'", var7.equals((byte)(-1)));

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test18"); }


    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    java.lang.Object[] var7 = new java.lang.Object[] { 10.0d};
    org.apache.commons.math3.exception.NullArgumentException var8 = new org.apache.commons.math3.exception.NullArgumentException(var5, var7);
    org.apache.commons.math3.exception.MathIllegalArgumentException var9 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var4, var7);
    org.apache.commons.math3.exception.NullArgumentException var10 = new org.apache.commons.math3.exception.NullArgumentException(var3, var7);
    org.apache.commons.math3.exception.MathArithmeticException var11 = new org.apache.commons.math3.exception.MathArithmeticException(var2, var7);
    org.apache.commons.math3.exception.NotFiniteNumberException var12 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)561247916, var7);
    org.apache.commons.math3.exception.NotFiniteNumberException var13 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1687.9702609361561d, var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test19() {}
//   public void test19() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test19"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)7506849.916132723d, (java.lang.Number)1.0f, (java.lang.Number)86);
//     org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var4);
// 
//   }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test20"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    double[] var5 = new double[] { 100.0d, (-1.0d)};
    double[] var8 = new double[] { 100.0d, 1.0d};
    boolean var9 = org.apache.commons.math3.util.MathArrays.equals(var5, var8);
    double[] var12 = new double[] { 100.0d, (-1.0d)};
    double[] var15 = new double[] { 100.0d, 1.0d};
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var12, var15);
    double[] var19 = new double[] { 100.0d, (-1.0d)};
    double[] var22 = new double[] { 100.0d, 1.0d};
    boolean var23 = org.apache.commons.math3.util.MathArrays.equals(var19, var22);
    double var24 = org.apache.commons.math3.util.MathArrays.distance(var15, var19);
    double[] var27 = new double[] { 100.0d, (-1.0d)};
    double[] var30 = new double[] { 100.0d, 1.0d};
    boolean var31 = org.apache.commons.math3.util.MathArrays.equals(var27, var30);
    double[] var34 = new double[] { 100.0d, (-1.0d)};
    double[] var37 = new double[] { 100.0d, 1.0d};
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var34, var37);
    double var39 = org.apache.commons.math3.util.MathArrays.distance(var30, var34);
    double var40 = org.apache.commons.math3.util.MathArrays.linearCombination(var15, var30);
    boolean var41 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var5, var15);
    double[] var43 = org.apache.commons.math3.util.MathArrays.normalizeArray(var15, (-1.682916631768903d));
    double[] var46 = new double[] { 100.0d, (-1.0d)};
    double[] var49 = new double[] { 100.0d, 1.0d};
    boolean var50 = org.apache.commons.math3.util.MathArrays.equals(var46, var49);
    double[] var53 = new double[] { 100.0d, (-1.0d)};
    double[] var56 = new double[] { 100.0d, 1.0d};
    boolean var57 = org.apache.commons.math3.util.MathArrays.equals(var53, var56);
    double var58 = org.apache.commons.math3.util.MathArrays.distance(var49, var53);
    double[] var61 = new double[] { 100.0d, (-1.0d)};
    double[] var64 = new double[] { 100.0d, 1.0d};
    boolean var65 = org.apache.commons.math3.util.MathArrays.equals(var61, var64);
    double[] var68 = new double[] { 100.0d, (-1.0d)};
    double[] var71 = new double[] { 100.0d, 1.0d};
    boolean var72 = org.apache.commons.math3.util.MathArrays.equals(var68, var71);
    double var73 = org.apache.commons.math3.util.MathArrays.distance(var64, var68);
    double var74 = org.apache.commons.math3.util.MathArrays.linearCombination(var49, var64);
    double[] var75 = org.apache.commons.math3.util.MathArrays.ebeAdd(var43, var49);
    double[] var78 = new double[] { 100.0d, (-1.0d)};
    double[] var81 = new double[] { 100.0d, 1.0d};
    boolean var82 = org.apache.commons.math3.util.MathArrays.equals(var78, var81);
    double[] var85 = new double[] { 100.0d, (-1.0d)};
    double[] var88 = new double[] { 100.0d, 1.0d};
    boolean var89 = org.apache.commons.math3.util.MathArrays.equals(var85, var88);
    double var90 = org.apache.commons.math3.util.MathArrays.distance(var81, var85);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var91 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var2, var49, var81);
    double var93 = var91.density(111.37224047421323d);
    boolean var94 = var91.isSupportLowerBoundInclusive();
    double var95 = var91.sample();
    double[] var97 = var91.sample(22);
    boolean var98 = var91.isSupportUpperBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var94 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var95 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var97);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var98 == true);

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test21"); }


    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)2.0d, (java.lang.Object)(byte)(-1));
    java.lang.Object var3 = var2.getSecond();
    java.lang.Object var4 = var2.getKey();
    java.lang.Object var5 = var2.getFirst();
    java.lang.Object var6 = var2.getSecond();
    java.lang.Object var7 = var2.getValue();
    java.lang.Object var8 = var2.getFirst();
    java.lang.Object var9 = var2.getValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + (byte)(-1)+ "'", var3.equals((byte)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 2.0d+ "'", var4.equals(2.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 2.0d+ "'", var5.equals(2.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (byte)(-1)+ "'", var6.equals((byte)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (byte)(-1)+ "'", var7.equals((byte)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 2.0d+ "'", var8.equals(2.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + (byte)(-1)+ "'", var9.equals((byte)(-1)));

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test22"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)1.2694665049707192d);
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var1.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var1.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test23() {}
//   public void test23() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test23"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextGaussian(10.0d, 2.0d);
//     long var7 = var1.nextSecureLong(1L, 7L);
//     double var9 = var1.nextChiSquare(3.1703807935259682d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 9.497731394084708d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 3L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.8946071500339745d);
// 
//   }

  public void test24() {}
//   public void test24() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test24"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextCauchy(0.15328243612779968d, 1.2640264838134555E7d);
//     int var7 = var1.nextInt(100, 1755678109);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.147682018143803E7d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1290819565);
// 
//   }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test25"); }


    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1L, (java.lang.Number)(-1), 1, var3, false);
    java.lang.Number var6 = var5.getPrevious();
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = var5.getDirection();
    int var8 = var5.getIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (-1)+ "'", var6.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test26"); }


    int[] var1 = new int[] { (-1)};
    int[] var2 = org.apache.commons.math3.util.MathArrays.copyOf(var1);
    int[] var4 = new int[] { (-1)};
    int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
    int var6 = org.apache.commons.math3.util.MathArrays.distanceInf(var2, var4);
    org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(var4);
    org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(var4);
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(var4);
    int var11 = var9.nextInt(30);
    double var12 = var9.nextDouble();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.07587422179227632d);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test27"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextZipf(100, 2.0d);
    var2.reSeedSecure();
    double var9 = var2.nextUniform((-0.7314779623383547d), 2.581121805739166d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 2.431446335184138d);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test28"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.83821094f);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test29"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Object[] var5 = new java.lang.Object[] { 10.0d};
    org.apache.commons.math3.exception.NullArgumentException var6 = new org.apache.commons.math3.exception.NullArgumentException(var3, var5);
    org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, var5);
    org.apache.commons.math3.exception.MathIllegalArgumentException var8 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, var5);
    org.apache.commons.math3.exception.MathIllegalArgumentException var9 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test30"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeed();
    var2.reSeed();

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test31"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    var1.setSeed(10L);
    boolean var4 = var1.nextBoolean();
    int[] var5 = null;
    var1.setSeed(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test32() {}
//   public void test32() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test32"); }
// 
// 
//     double[] var2 = new double[] { 100.0d, (-1.0d)};
//     double[] var5 = new double[] { 100.0d, 1.0d};
//     boolean var6 = org.apache.commons.math3.util.MathArrays.equals(var2, var5);
//     double[] var9 = new double[] { 100.0d, (-1.0d)};
//     double[] var12 = new double[] { 100.0d, 1.0d};
//     boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var9, var12);
//     double[] var16 = new double[] { 100.0d, (-1.0d)};
//     double[] var19 = new double[] { 100.0d, 1.0d};
//     boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var16, var19);
//     double var21 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
//     double[] var24 = new double[] { 100.0d, (-1.0d)};
//     double[] var27 = new double[] { 100.0d, 1.0d};
//     boolean var28 = org.apache.commons.math3.util.MathArrays.equals(var24, var27);
//     double[] var31 = new double[] { 100.0d, (-1.0d)};
//     double[] var34 = new double[] { 100.0d, 1.0d};
//     boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var31, var34);
//     double var36 = org.apache.commons.math3.util.MathArrays.distance(var27, var31);
//     double var37 = org.apache.commons.math3.util.MathArrays.linearCombination(var12, var27);
//     boolean var38 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var2, var12);
//     double[] var39 = null;
//     double var40 = org.apache.commons.math3.util.MathArrays.distance(var12, var39);
// 
//   }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test33"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)12, (java.lang.Number)864L, false);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test34"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var2);
    long var4 = var2.nextLong();
    int var5 = var2.nextInt();
    double var6 = var2.nextDouble();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-414028722650554365L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 669834927);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.8769524240060045d);

  }

  public void test35() {}
//   public void test35() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test35"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeedSecure(10L);
//     double var7 = var2.nextUniform(11.684643263460426d, 7506849.916132723d);
//     java.lang.String var9 = var2.nextSecureHexString(99);
//     double var12 = var2.nextCauchy(0.2884362901949524d, 111.37224047421323d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 3068624.4438274824d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "30f40d133373814195a4e59389e362796fb868d97f43710cfec8811cbbba6af36616dd8e905a94737f585a6da26997dac9b"+ "'", var9.equals("30f40d133373814195a4e59389e362796fb868d97f43710cfec8811cbbba6af36616dd8e905a94737f585a6da26997dac9b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 779.6064153196041d);
// 
//   }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test36"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.19389798955545332d, (java.lang.Number)8509402.437162092d, true);
    boolean var4 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test37"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    double[] var5 = new double[] { 100.0d, (-1.0d)};
    double[] var8 = new double[] { 100.0d, 1.0d};
    boolean var9 = org.apache.commons.math3.util.MathArrays.equals(var5, var8);
    double[] var12 = new double[] { 100.0d, (-1.0d)};
    double[] var15 = new double[] { 100.0d, 1.0d};
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var12, var15);
    double[] var19 = new double[] { 100.0d, (-1.0d)};
    double[] var22 = new double[] { 100.0d, 1.0d};
    boolean var23 = org.apache.commons.math3.util.MathArrays.equals(var19, var22);
    double var24 = org.apache.commons.math3.util.MathArrays.distance(var15, var19);
    double[] var27 = new double[] { 100.0d, (-1.0d)};
    double[] var30 = new double[] { 100.0d, 1.0d};
    boolean var31 = org.apache.commons.math3.util.MathArrays.equals(var27, var30);
    double[] var34 = new double[] { 100.0d, (-1.0d)};
    double[] var37 = new double[] { 100.0d, 1.0d};
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var34, var37);
    double var39 = org.apache.commons.math3.util.MathArrays.distance(var30, var34);
    double var40 = org.apache.commons.math3.util.MathArrays.linearCombination(var15, var30);
    boolean var41 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var5, var15);
    double[] var43 = org.apache.commons.math3.util.MathArrays.normalizeArray(var15, (-1.682916631768903d));
    double[] var46 = new double[] { 100.0d, (-1.0d)};
    double[] var49 = new double[] { 100.0d, 1.0d};
    boolean var50 = org.apache.commons.math3.util.MathArrays.equals(var46, var49);
    double[] var53 = new double[] { 100.0d, (-1.0d)};
    double[] var56 = new double[] { 100.0d, 1.0d};
    boolean var57 = org.apache.commons.math3.util.MathArrays.equals(var53, var56);
    double var58 = org.apache.commons.math3.util.MathArrays.distance(var49, var53);
    double[] var61 = new double[] { 100.0d, (-1.0d)};
    double[] var64 = new double[] { 100.0d, 1.0d};
    boolean var65 = org.apache.commons.math3.util.MathArrays.equals(var61, var64);
    double[] var68 = new double[] { 100.0d, (-1.0d)};
    double[] var71 = new double[] { 100.0d, 1.0d};
    boolean var72 = org.apache.commons.math3.util.MathArrays.equals(var68, var71);
    double var73 = org.apache.commons.math3.util.MathArrays.distance(var64, var68);
    double var74 = org.apache.commons.math3.util.MathArrays.linearCombination(var49, var64);
    double[] var75 = org.apache.commons.math3.util.MathArrays.ebeAdd(var43, var49);
    double[] var78 = new double[] { 100.0d, (-1.0d)};
    double[] var81 = new double[] { 100.0d, 1.0d};
    boolean var82 = org.apache.commons.math3.util.MathArrays.equals(var78, var81);
    double[] var85 = new double[] { 100.0d, (-1.0d)};
    double[] var88 = new double[] { 100.0d, 1.0d};
    boolean var89 = org.apache.commons.math3.util.MathArrays.equals(var85, var88);
    double var90 = org.apache.commons.math3.util.MathArrays.distance(var81, var85);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var91 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var2, var49, var81);
    boolean var92 = var91.isSupportConnected();
    double var93 = var91.getNumericalMean();
    double var94 = var91.getNumericalMean();
    double var95 = var91.getSupportUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == 99.01980198019803d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var94 == 99.01980198019803d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var95 == 100.0d);

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test38"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeed();
    var2.reSeedSecure(1L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var7 = var2.nextChiSquare(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test39"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextGaussian(0.40877566087838346d, 1.0d);
    var2.reSeedSecure();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.15328243612779968d);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test40"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var1.setSeed(6L);
    double var5 = var1.nextGaussian();
    long var6 = var1.nextLong();
    int var7 = var1.nextInt();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.8287558766918952d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1410210306176149564L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-420911021));

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test41"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    var1.setSeed(10L);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var7 = var4.nextGamma((-0.7314779623383547d), 70.40080058104351d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test42"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    double[] var5 = new double[] { 100.0d, (-1.0d)};
    double[] var8 = new double[] { 100.0d, 1.0d};
    boolean var9 = org.apache.commons.math3.util.MathArrays.equals(var5, var8);
    double[] var12 = new double[] { 100.0d, (-1.0d)};
    double[] var15 = new double[] { 100.0d, 1.0d};
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var12, var15);
    double[] var19 = new double[] { 100.0d, (-1.0d)};
    double[] var22 = new double[] { 100.0d, 1.0d};
    boolean var23 = org.apache.commons.math3.util.MathArrays.equals(var19, var22);
    double var24 = org.apache.commons.math3.util.MathArrays.distance(var15, var19);
    double[] var27 = new double[] { 100.0d, (-1.0d)};
    double[] var30 = new double[] { 100.0d, 1.0d};
    boolean var31 = org.apache.commons.math3.util.MathArrays.equals(var27, var30);
    double[] var34 = new double[] { 100.0d, (-1.0d)};
    double[] var37 = new double[] { 100.0d, 1.0d};
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var34, var37);
    double var39 = org.apache.commons.math3.util.MathArrays.distance(var30, var34);
    double var40 = org.apache.commons.math3.util.MathArrays.linearCombination(var15, var30);
    boolean var41 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var5, var15);
    double[] var43 = org.apache.commons.math3.util.MathArrays.normalizeArray(var15, (-1.682916631768903d));
    double[] var46 = new double[] { 100.0d, (-1.0d)};
    double[] var49 = new double[] { 100.0d, 1.0d};
    boolean var50 = org.apache.commons.math3.util.MathArrays.equals(var46, var49);
    double[] var53 = new double[] { 100.0d, (-1.0d)};
    double[] var56 = new double[] { 100.0d, 1.0d};
    boolean var57 = org.apache.commons.math3.util.MathArrays.equals(var53, var56);
    double var58 = org.apache.commons.math3.util.MathArrays.distance(var49, var53);
    double[] var61 = new double[] { 100.0d, (-1.0d)};
    double[] var64 = new double[] { 100.0d, 1.0d};
    boolean var65 = org.apache.commons.math3.util.MathArrays.equals(var61, var64);
    double[] var68 = new double[] { 100.0d, (-1.0d)};
    double[] var71 = new double[] { 100.0d, 1.0d};
    boolean var72 = org.apache.commons.math3.util.MathArrays.equals(var68, var71);
    double var73 = org.apache.commons.math3.util.MathArrays.distance(var64, var68);
    double var74 = org.apache.commons.math3.util.MathArrays.linearCombination(var49, var64);
    double[] var75 = org.apache.commons.math3.util.MathArrays.ebeAdd(var43, var49);
    double[] var78 = new double[] { 100.0d, (-1.0d)};
    double[] var81 = new double[] { 100.0d, 1.0d};
    boolean var82 = org.apache.commons.math3.util.MathArrays.equals(var78, var81);
    double[] var85 = new double[] { 100.0d, (-1.0d)};
    double[] var88 = new double[] { 100.0d, 1.0d};
    boolean var89 = org.apache.commons.math3.util.MathArrays.equals(var85, var88);
    double var90 = org.apache.commons.math3.util.MathArrays.distance(var81, var85);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var91 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var2, var49, var81);
    boolean var92 = var91.isSupportConnected();
    double var94 = var91.density(0.40877566087838346d);
    var91.reseedRandomGenerator(3L);
    double var97 = var91.getNumericalMean();
    double var98 = var91.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var94 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var97 == 99.01980198019803d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var98 == 1.0d);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test43"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)0.009900990099009901d, (java.lang.Number)(-0.18999442618139734d), false);

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test44"); }


    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)2.0d, (java.lang.Object)(byte)(-1));
    java.lang.Object var3 = var2.getSecond();
    java.lang.Object var4 = var2.getKey();
    java.lang.Object var5 = var2.getValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + (byte)(-1)+ "'", var3.equals((byte)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 2.0d+ "'", var4.equals(2.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (byte)(-1)+ "'", var5.equals((byte)(-1)));

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test45"); }


    int[] var1 = new int[] { (-1)};
    int[] var2 = org.apache.commons.math3.util.MathArrays.copyOf(var1);
    int[] var4 = new int[] { (-1)};
    int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
    int var6 = org.apache.commons.math3.util.MathArrays.distanceInf(var2, var4);
    org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(var4);
    int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var4, 28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test46() {}
//   public void test46() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test46"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed((-1L));
//     double var6 = var0.nextUniform(0.0d, 2.3590437156692077d, false);
//     double var9 = var0.nextGamma(885.3062819424027d, 96.07881580237154d);
//     double var13 = var0.nextUniform((-16832.484962999133d), 132.82498240734793d, true);
//     java.lang.String var15 = var0.nextSecureHexString(4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.5650828929145241d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 80739.49636849186d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-13066.525482061685d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "8dbf"+ "'", var15.equals("8dbf"));
// 
//   }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test47"); }


    double[] var1 = new double[] { 10.0d};
    double var2 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    boolean var5 = org.apache.commons.math3.util.MathArrays.isMonotonic(var1, var3, false);
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
    boolean var9 = org.apache.commons.math3.util.MathArrays.checkOrder(var1, var6, false, true);
    double[] var12 = new double[] { 100.0d, (-1.0d)};
    double[] var15 = new double[] { 100.0d, 1.0d};
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var12, var15);
    double[] var19 = new double[] { 100.0d, (-1.0d)};
    double[] var22 = new double[] { 100.0d, 1.0d};
    boolean var23 = org.apache.commons.math3.util.MathArrays.equals(var19, var22);
    double[] var26 = new double[] { 100.0d, (-1.0d)};
    double[] var29 = new double[] { 100.0d, 1.0d};
    boolean var30 = org.apache.commons.math3.util.MathArrays.equals(var26, var29);
    double var31 = org.apache.commons.math3.util.MathArrays.distance(var22, var26);
    double[] var34 = new double[] { 100.0d, (-1.0d)};
    double[] var37 = new double[] { 100.0d, 1.0d};
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var34, var37);
    double[] var41 = new double[] { 100.0d, (-1.0d)};
    double[] var44 = new double[] { 100.0d, 1.0d};
    boolean var45 = org.apache.commons.math3.util.MathArrays.equals(var41, var44);
    double var46 = org.apache.commons.math3.util.MathArrays.distance(var37, var41);
    double var47 = org.apache.commons.math3.util.MathArrays.linearCombination(var22, var37);
    boolean var48 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var12, var22);
    double[] var50 = org.apache.commons.math3.util.MathArrays.normalizeArray(var22, (-1.682916631768903d));
    double[] var53 = new double[] { 100.0d, (-1.0d)};
    double[] var56 = new double[] { 100.0d, 1.0d};
    boolean var57 = org.apache.commons.math3.util.MathArrays.equals(var53, var56);
    double[] var60 = new double[] { 100.0d, (-1.0d)};
    double[] var63 = new double[] { 100.0d, 1.0d};
    boolean var64 = org.apache.commons.math3.util.MathArrays.equals(var60, var63);
    double var65 = org.apache.commons.math3.util.MathArrays.distance(var56, var60);
    double[] var68 = new double[] { 100.0d, (-1.0d)};
    double[] var71 = new double[] { 100.0d, 1.0d};
    boolean var72 = org.apache.commons.math3.util.MathArrays.equals(var68, var71);
    double[] var73 = org.apache.commons.math3.util.MathArrays.ebeDivide(var60, var68);
    double[] var74 = org.apache.commons.math3.util.MathArrays.ebeDivide(var22, var68);
    boolean var75 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var1, var68);
    double[] var76 = org.apache.commons.math3.util.MathArrays.copyOf(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test48"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(short)(-1), (java.lang.Number)0L, false);
    java.lang.Number var5 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0L+ "'", var5.equals(0L));

  }

  public void test49() {}
//   public void test49() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test49"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 998139946, 10);
// 
//   }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test50"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextPascal(86, 0.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var9 = var2.nextHypergeometric(30, 12, 224787129);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2147483647);

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test51"); }


    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1L, (java.lang.Number)(-1), 1, var3, false);
    java.lang.Number var6 = var5.getPrevious();
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = var5.getDirection();
    org.apache.commons.math3.util.MathArrays.OrderDirection var8 = var5.getDirection();
    org.apache.commons.math3.util.MathArrays.OrderDirection var9 = var5.getDirection();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (-1)+ "'", var6.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test52"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1.0d, (java.lang.Number)10, true);
    org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var7 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var6);
    org.apache.commons.math3.util.Pair var8 = new org.apache.commons.math3.util.Pair((java.lang.Object)true, (java.lang.Object)var6);
    java.lang.Object var9 = var8.getSecond();
    java.lang.Object var10 = var8.getFirst();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + true+ "'", var10.equals(true));

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test53"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(86, 669834927);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test54"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed((-1L));
    int[] var5 = var0.nextPermutation(100, 30);
    int[] var7 = new int[] { (-1)};
    int[] var8 = org.apache.commons.math3.util.MathArrays.copyOf(var7);
    int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var8, 86);
    int var11 = org.apache.commons.math3.util.MathArrays.distanceInf(var5, var10);
    org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 99);

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test55"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)1.4142135623730951d);
    java.lang.Number var3 = var2.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test56"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    double[] var5 = new double[] { 100.0d, (-1.0d)};
    double[] var8 = new double[] { 100.0d, 1.0d};
    boolean var9 = org.apache.commons.math3.util.MathArrays.equals(var5, var8);
    double[] var12 = new double[] { 100.0d, (-1.0d)};
    double[] var15 = new double[] { 100.0d, 1.0d};
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var12, var15);
    double[] var19 = new double[] { 100.0d, (-1.0d)};
    double[] var22 = new double[] { 100.0d, 1.0d};
    boolean var23 = org.apache.commons.math3.util.MathArrays.equals(var19, var22);
    double var24 = org.apache.commons.math3.util.MathArrays.distance(var15, var19);
    double[] var27 = new double[] { 100.0d, (-1.0d)};
    double[] var30 = new double[] { 100.0d, 1.0d};
    boolean var31 = org.apache.commons.math3.util.MathArrays.equals(var27, var30);
    double[] var34 = new double[] { 100.0d, (-1.0d)};
    double[] var37 = new double[] { 100.0d, 1.0d};
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var34, var37);
    double var39 = org.apache.commons.math3.util.MathArrays.distance(var30, var34);
    double var40 = org.apache.commons.math3.util.MathArrays.linearCombination(var15, var30);
    boolean var41 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var5, var15);
    double[] var43 = org.apache.commons.math3.util.MathArrays.normalizeArray(var15, (-1.682916631768903d));
    double[] var46 = new double[] { 100.0d, (-1.0d)};
    double[] var49 = new double[] { 100.0d, 1.0d};
    boolean var50 = org.apache.commons.math3.util.MathArrays.equals(var46, var49);
    double[] var53 = new double[] { 100.0d, (-1.0d)};
    double[] var56 = new double[] { 100.0d, 1.0d};
    boolean var57 = org.apache.commons.math3.util.MathArrays.equals(var53, var56);
    double var58 = org.apache.commons.math3.util.MathArrays.distance(var49, var53);
    double[] var61 = new double[] { 100.0d, (-1.0d)};
    double[] var64 = new double[] { 100.0d, 1.0d};
    boolean var65 = org.apache.commons.math3.util.MathArrays.equals(var61, var64);
    double[] var68 = new double[] { 100.0d, (-1.0d)};
    double[] var71 = new double[] { 100.0d, 1.0d};
    boolean var72 = org.apache.commons.math3.util.MathArrays.equals(var68, var71);
    double var73 = org.apache.commons.math3.util.MathArrays.distance(var64, var68);
    double var74 = org.apache.commons.math3.util.MathArrays.linearCombination(var49, var64);
    double[] var75 = org.apache.commons.math3.util.MathArrays.ebeAdd(var43, var49);
    double[] var78 = new double[] { 100.0d, (-1.0d)};
    double[] var81 = new double[] { 100.0d, 1.0d};
    boolean var82 = org.apache.commons.math3.util.MathArrays.equals(var78, var81);
    double[] var85 = new double[] { 100.0d, (-1.0d)};
    double[] var88 = new double[] { 100.0d, 1.0d};
    boolean var89 = org.apache.commons.math3.util.MathArrays.equals(var85, var88);
    double var90 = org.apache.commons.math3.util.MathArrays.distance(var81, var85);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var91 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var2, var49, var81);
    boolean var92 = var91.isSupportConnected();
    var91.reseedRandomGenerator(10L);
    double var95 = var91.getNumericalMean();
    boolean var96 = var91.isSupportConnected();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var98 = var91.inverseCumulativeProbability(63.69489379047444d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var95 == 99.01980198019803d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var96 == true);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test57"); }


    double[] var2 = new double[] { 100.0d, (-1.0d)};
    double[] var5 = new double[] { 100.0d, 1.0d};
    boolean var6 = org.apache.commons.math3.util.MathArrays.equals(var2, var5);
    double[] var9 = new double[] { 100.0d, (-1.0d)};
    double[] var12 = new double[] { 100.0d, 1.0d};
    boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var9, var12);
    double[] var16 = new double[] { 100.0d, (-1.0d)};
    double[] var19 = new double[] { 100.0d, 1.0d};
    boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var16, var19);
    double[] var23 = new double[] { 100.0d, (-1.0d)};
    double[] var26 = new double[] { 100.0d, 1.0d};
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var23, var26);
    double var28 = org.apache.commons.math3.util.MathArrays.distance(var19, var23);
    double[] var31 = new double[] { 100.0d, (-1.0d)};
    double[] var34 = new double[] { 100.0d, 1.0d};
    boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var31, var34);
    double[] var38 = new double[] { 100.0d, (-1.0d)};
    double[] var41 = new double[] { 100.0d, 1.0d};
    boolean var42 = org.apache.commons.math3.util.MathArrays.equals(var38, var41);
    double var43 = org.apache.commons.math3.util.MathArrays.distance(var34, var38);
    double var44 = org.apache.commons.math3.util.MathArrays.linearCombination(var19, var34);
    boolean var45 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var9, var19);
    double[] var47 = org.apache.commons.math3.util.MathArrays.normalizeArray(var19, (-1.682916631768903d));
    double[] var48 = org.apache.commons.math3.util.MathArrays.ebeAdd(var5, var19);
    double[] var50 = org.apache.commons.math3.util.MathArrays.copyOf(var19, 0);
    double[] var51 = org.apache.commons.math3.util.MathArrays.copyOf(var50);
    java.lang.Number var52 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var55 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var52, (java.lang.Number)(byte)100, 0);
    org.apache.commons.math3.exception.util.ExceptionContext var56 = var55.getContext();
    boolean var57 = var55.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var58 = var55.getDirection();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var60 = org.apache.commons.math3.util.MathArrays.isMonotonic(var50, var58, false);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test58"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextZipf(100, 2.0d);
    var2.reSeedSecure((-833491931516635789L));
    long var9 = var2.nextPoisson(8.418185040882479d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 9L);

  }

  public void test59() {}
//   public void test59() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test59"); }
// 
// 
//     double[] var1 = new double[] { 10.0d};
//     double var2 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
//     boolean var5 = org.apache.commons.math3.util.MathArrays.isMonotonic(var1, var3, false);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
//     boolean var9 = org.apache.commons.math3.util.MathArrays.checkOrder(var1, var6, false, true);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var10 = null;
//     boolean var13 = org.apache.commons.math3.util.MathArrays.checkOrder(var1, var10, false, false);
//     double[] var16 = new double[] { 100.0d, (-1.0d)};
//     double[] var19 = new double[] { 100.0d, 1.0d};
//     boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var16, var19);
//     double[] var23 = new double[] { 100.0d, (-1.0d)};
//     double[] var26 = new double[] { 100.0d, 1.0d};
//     boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var23, var26);
//     double[] var30 = new double[] { 100.0d, (-1.0d)};
//     double[] var33 = new double[] { 100.0d, 1.0d};
//     boolean var34 = org.apache.commons.math3.util.MathArrays.equals(var30, var33);
//     double var35 = org.apache.commons.math3.util.MathArrays.distance(var26, var30);
//     double[] var38 = new double[] { 100.0d, (-1.0d)};
//     double[] var41 = new double[] { 100.0d, 1.0d};
//     boolean var42 = org.apache.commons.math3.util.MathArrays.equals(var38, var41);
//     double[] var45 = new double[] { 100.0d, (-1.0d)};
//     double[] var48 = new double[] { 100.0d, 1.0d};
//     boolean var49 = org.apache.commons.math3.util.MathArrays.equals(var45, var48);
//     double var50 = org.apache.commons.math3.util.MathArrays.distance(var41, var45);
//     double var51 = org.apache.commons.math3.util.MathArrays.linearCombination(var26, var41);
//     boolean var52 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var16, var26);
//     double[] var54 = org.apache.commons.math3.util.MathArrays.normalizeArray(var26, (-1.682916631768903d));
//     double[] var57 = new double[] { 100.0d, (-1.0d)};
//     double[] var60 = new double[] { 100.0d, 1.0d};
//     boolean var61 = org.apache.commons.math3.util.MathArrays.equals(var57, var60);
//     double[] var64 = new double[] { 100.0d, (-1.0d)};
//     double[] var67 = new double[] { 100.0d, 1.0d};
//     boolean var68 = org.apache.commons.math3.util.MathArrays.equals(var64, var67);
//     double var69 = org.apache.commons.math3.util.MathArrays.distance(var60, var64);
//     double[] var72 = new double[] { 100.0d, (-1.0d)};
//     double[] var75 = new double[] { 100.0d, 1.0d};
//     boolean var76 = org.apache.commons.math3.util.MathArrays.equals(var72, var75);
//     double[] var79 = new double[] { 100.0d, (-1.0d)};
//     double[] var82 = new double[] { 100.0d, 1.0d};
//     boolean var83 = org.apache.commons.math3.util.MathArrays.equals(var79, var82);
//     double var84 = org.apache.commons.math3.util.MathArrays.distance(var75, var79);
//     double var85 = org.apache.commons.math3.util.MathArrays.linearCombination(var60, var75);
//     double[] var86 = org.apache.commons.math3.util.MathArrays.ebeAdd(var54, var60);
//     double[] var87 = null;
//     boolean var88 = org.apache.commons.math3.util.MathArrays.equals(var60, var87);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var89 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var1, var87);
// 
//   }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test60"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    float var3 = var1.nextFloat();
    var1.clear();
    double var5 = var1.nextDouble();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.40877557f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.2323975705328034d);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test61"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(-1410210306176149564L), (java.lang.Number)(-1.0f), true);

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test62"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    boolean var3 = var1.nextBoolean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test63() {}
//   public void test63() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test63"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextGaussian(0.0d, 2.0d);
//     var1.reSeedSecure(0L);
//     var1.reSeedSecure();
//     double var10 = var1.nextGaussian(2.0d, 2.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var1.nextPascal((-420911021), 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-2.6050751095341997d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.8205297040204593d);
// 
//   }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test64"); }


    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Object[] var3 = new java.lang.Object[] { 864L};
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError(var1, var3);
    org.apache.commons.math3.exception.NotFiniteNumberException var5 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)0.519605336917354d, var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test65() {}
//   public void test65() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test65"); }
// 
// 
//     int[] var1 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var2);
//     long var4 = var2.nextLong();
//     int var5 = var2.nextInt();
//     org.apache.commons.math3.random.RandomDataImpl var6 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var2);
//     java.util.Collection var7 = null;
//     java.lang.Object[] var9 = var6.nextSample(var7, 99);
// 
//   }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test66"); }


    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)2.0d, (java.lang.Object)(byte)(-1));
    java.lang.Object var3 = var2.getSecond();
    java.lang.Object var4 = var2.getSecond();
    java.lang.Object var5 = var2.getSecond();
    java.lang.Object var6 = var2.getKey();
    boolean var8 = var2.equals((java.lang.Object)2.177799292832918d);
    java.lang.Object var9 = var2.getKey();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + (byte)(-1)+ "'", var3.equals((byte)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (byte)(-1)+ "'", var4.equals((byte)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (byte)(-1)+ "'", var5.equals((byte)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 2.0d+ "'", var6.equals(2.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + 2.0d+ "'", var9.equals(2.0d));

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test67"); }


    double[] var2 = new double[] { 100.0d, (-1.0d)};
    double[] var5 = new double[] { 100.0d, 1.0d};
    boolean var6 = org.apache.commons.math3.util.MathArrays.equals(var2, var5);
    double[] var9 = new double[] { 100.0d, (-1.0d)};
    double[] var12 = new double[] { 100.0d, 1.0d};
    boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var9, var12);
    double[] var16 = new double[] { 100.0d, (-1.0d)};
    double[] var19 = new double[] { 100.0d, 1.0d};
    boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var16, var19);
    double var21 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double[] var24 = new double[] { 100.0d, (-1.0d)};
    double[] var27 = new double[] { 100.0d, 1.0d};
    boolean var28 = org.apache.commons.math3.util.MathArrays.equals(var24, var27);
    double[] var31 = new double[] { 100.0d, (-1.0d)};
    double[] var34 = new double[] { 100.0d, 1.0d};
    boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var31, var34);
    double var36 = org.apache.commons.math3.util.MathArrays.distance(var27, var31);
    double var37 = org.apache.commons.math3.util.MathArrays.linearCombination(var12, var27);
    boolean var38 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var2, var12);
    double[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test68"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextGaussian((-0.5770298507560749d), 10001.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var8 = var2.nextPermutation(1755678109, 1);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-2555.7647705813442d));

  }

  public void test69() {}
//   public void test69() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test69"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var3 = var1.nextDouble();
//     int var5 = var1.nextInt(998139946);
//     org.apache.commons.math3.random.RandomDataImpl var6 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var9 = var6.nextSecureInt(1, 28);
//     var6.reSeedSecure(1L);
//     double var13 = var6.nextExponential(1.7523659290472708d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.40877566087838346d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 224787129);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.2470814806545836d);
// 
//   }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test70"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(1);
    float var2 = var1.nextFloat();
    int var4 = var1.nextInt(86);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.27873123f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 18);

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test71"); }


    double[] var2 = new double[] { 100.0d, (-1.0d)};
    double[] var5 = new double[] { 100.0d, 1.0d};
    boolean var6 = org.apache.commons.math3.util.MathArrays.equals(var2, var5);
    double[] var9 = new double[] { 100.0d, (-1.0d)};
    double[] var12 = new double[] { 100.0d, 1.0d};
    boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var9, var12);
    double var14 = org.apache.commons.math3.util.MathArrays.distance(var5, var9);
    double[] var17 = new double[] { 100.0d, (-1.0d)};
    double[] var20 = new double[] { 100.0d, 1.0d};
    boolean var21 = org.apache.commons.math3.util.MathArrays.equals(var17, var20);
    double[] var22 = org.apache.commons.math3.util.MathArrays.ebeDivide(var9, var17);
    double[] var25 = new double[] { 100.0d, (-1.0d)};
    double[] var28 = new double[] { 100.0d, 1.0d};
    boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var25, var28);
    double[] var32 = new double[] { 100.0d, (-1.0d)};
    double[] var35 = new double[] { 100.0d, 1.0d};
    boolean var36 = org.apache.commons.math3.util.MathArrays.equals(var32, var35);
    double[] var39 = new double[] { 100.0d, (-1.0d)};
    double[] var42 = new double[] { 100.0d, 1.0d};
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var39, var42);
    double[] var46 = new double[] { 100.0d, (-1.0d)};
    double[] var49 = new double[] { 100.0d, 1.0d};
    boolean var50 = org.apache.commons.math3.util.MathArrays.equals(var46, var49);
    double var51 = org.apache.commons.math3.util.MathArrays.distance(var42, var46);
    double[] var54 = new double[] { 100.0d, (-1.0d)};
    double[] var57 = new double[] { 100.0d, 1.0d};
    boolean var58 = org.apache.commons.math3.util.MathArrays.equals(var54, var57);
    double[] var61 = new double[] { 100.0d, (-1.0d)};
    double[] var64 = new double[] { 100.0d, 1.0d};
    boolean var65 = org.apache.commons.math3.util.MathArrays.equals(var61, var64);
    double var66 = org.apache.commons.math3.util.MathArrays.distance(var57, var61);
    double var67 = org.apache.commons.math3.util.MathArrays.linearCombination(var42, var57);
    boolean var68 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var32, var42);
    double[] var70 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, (-1.682916631768903d));
    double[] var71 = org.apache.commons.math3.util.MathArrays.ebeAdd(var28, var42);
    double var72 = org.apache.commons.math3.util.MathArrays.distance(var9, var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 100.04498987955368d);

  }

  public void test72() {}
//   public void test72() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test72"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed((-1L));
//     var0.reSeed();
//     double var6 = var0.nextCauchy(0.6115651382182169d, 96.07881580237154d);
//     double var8 = var0.nextT(0.519605336917354d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 22.74104627622211d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 28781.122908250312d);
// 
//   }

  public void test73() {}
//   public void test73() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test73"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextGaussian(0.0d, 2.0d);
//     var1.reSeedSecure(0L);
//     double var9 = var1.nextWeibull(2.0d, 9854048.12570597d);
//     long var11 = var1.nextPoisson(885.3062819424027d);
//     long var14 = var1.nextLong((-833491931516635789L), 2L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 2.8564880029424904d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 7173885.144901177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 849L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-347250533274553600L));
// 
//   }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test74"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    double[] var5 = new double[] { 100.0d, (-1.0d)};
    double[] var8 = new double[] { 100.0d, 1.0d};
    boolean var9 = org.apache.commons.math3.util.MathArrays.equals(var5, var8);
    double[] var12 = new double[] { 100.0d, (-1.0d)};
    double[] var15 = new double[] { 100.0d, 1.0d};
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var12, var15);
    double[] var19 = new double[] { 100.0d, (-1.0d)};
    double[] var22 = new double[] { 100.0d, 1.0d};
    boolean var23 = org.apache.commons.math3.util.MathArrays.equals(var19, var22);
    double var24 = org.apache.commons.math3.util.MathArrays.distance(var15, var19);
    double[] var27 = new double[] { 100.0d, (-1.0d)};
    double[] var30 = new double[] { 100.0d, 1.0d};
    boolean var31 = org.apache.commons.math3.util.MathArrays.equals(var27, var30);
    double[] var34 = new double[] { 100.0d, (-1.0d)};
    double[] var37 = new double[] { 100.0d, 1.0d};
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var34, var37);
    double var39 = org.apache.commons.math3.util.MathArrays.distance(var30, var34);
    double var40 = org.apache.commons.math3.util.MathArrays.linearCombination(var15, var30);
    boolean var41 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var5, var15);
    double[] var43 = org.apache.commons.math3.util.MathArrays.normalizeArray(var15, (-1.682916631768903d));
    double[] var46 = new double[] { 100.0d, (-1.0d)};
    double[] var49 = new double[] { 100.0d, 1.0d};
    boolean var50 = org.apache.commons.math3.util.MathArrays.equals(var46, var49);
    double[] var53 = new double[] { 100.0d, (-1.0d)};
    double[] var56 = new double[] { 100.0d, 1.0d};
    boolean var57 = org.apache.commons.math3.util.MathArrays.equals(var53, var56);
    double var58 = org.apache.commons.math3.util.MathArrays.distance(var49, var53);
    double[] var61 = new double[] { 100.0d, (-1.0d)};
    double[] var64 = new double[] { 100.0d, 1.0d};
    boolean var65 = org.apache.commons.math3.util.MathArrays.equals(var61, var64);
    double[] var68 = new double[] { 100.0d, (-1.0d)};
    double[] var71 = new double[] { 100.0d, 1.0d};
    boolean var72 = org.apache.commons.math3.util.MathArrays.equals(var68, var71);
    double var73 = org.apache.commons.math3.util.MathArrays.distance(var64, var68);
    double var74 = org.apache.commons.math3.util.MathArrays.linearCombination(var49, var64);
    double[] var75 = org.apache.commons.math3.util.MathArrays.ebeAdd(var43, var49);
    double[] var78 = new double[] { 100.0d, (-1.0d)};
    double[] var81 = new double[] { 100.0d, 1.0d};
    boolean var82 = org.apache.commons.math3.util.MathArrays.equals(var78, var81);
    double[] var85 = new double[] { 100.0d, (-1.0d)};
    double[] var88 = new double[] { 100.0d, 1.0d};
    boolean var89 = org.apache.commons.math3.util.MathArrays.equals(var85, var88);
    double var90 = org.apache.commons.math3.util.MathArrays.distance(var81, var85);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var91 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var2, var49, var81);
    boolean var92 = var91.isSupportConnected();
    double var93 = var91.getNumericalMean();
    double var94 = var91.getNumericalMean();
    double var95 = var91.getNumericalMean();
    double var96 = var91.getSupportLowerBound();
    double var97 = var91.sample();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == 99.01980198019803d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var94 == 99.01980198019803d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var95 == 99.01980198019803d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var96 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var97 == 100.0d);

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test75"); }


    int[] var1 = new int[] { (-1)};
    int[] var2 = org.apache.commons.math3.util.MathArrays.copyOf(var1);
    int[] var4 = new int[] { (-1)};
    int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
    int var6 = org.apache.commons.math3.util.MathArrays.distanceInf(var2, var4);
    int[] var7 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test76() {}
//   public void test76() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test76"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var3 = var1.nextDouble();
//     int var5 = var1.nextInt(998139946);
//     org.apache.commons.math3.random.RandomDataImpl var6 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var9 = var6.nextSecureInt(1, 28);
//     double var13 = var6.nextUniform(0.0d, 1.6430091483669123E7d, true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.40877566087838346d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 224787129);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 7845302.978476674d);
// 
//   }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test77"); }


    float[] var3 = new float[] { 1.0f, 1.0f, 1.0f};
    float[] var4 = new float[] { };
    float[] var7 = new float[] { 100.0f, 100.0f};
    boolean var8 = org.apache.commons.math3.util.MathArrays.equals(var4, var7);
    float[] var11 = new float[] { 10.0f, (-1.0f)};
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var11);
    float[] var13 = new float[] { };
    float[] var16 = new float[] { 100.0f, 100.0f};
    boolean var17 = org.apache.commons.math3.util.MathArrays.equals(var13, var16);
    boolean var18 = org.apache.commons.math3.util.MathArrays.equals(var7, var16);
    boolean var19 = org.apache.commons.math3.util.MathArrays.equals(var3, var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test78"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)7506849.916132723d, (java.lang.Number)1.0f, (java.lang.Number)86);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    java.lang.Object[] var7 = new java.lang.Object[] { 10.0d};
    org.apache.commons.math3.exception.NullArgumentException var8 = new org.apache.commons.math3.exception.NullArgumentException(var5, var7);
    var4.addSuppressed((java.lang.Throwable)var8);
    org.apache.commons.math3.exception.util.ExceptionContext var10 = var4.getContext();
    java.lang.Number var11 = var4.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + 1.0f+ "'", var11.equals(1.0f));

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test79"); }


    int[] var1 = new int[] { (-1)};
    int[] var2 = org.apache.commons.math3.util.MathArrays.copyOf(var1);
    int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var2);
    org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(var2);
    org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test80"); }


    double[] var2 = new double[] { 100.0d, (-1.0d)};
    double[] var5 = new double[] { 100.0d, 1.0d};
    boolean var6 = org.apache.commons.math3.util.MathArrays.equals(var2, var5);
    double[] var9 = new double[] { 100.0d, (-1.0d)};
    double[] var12 = new double[] { 100.0d, 1.0d};
    boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var9, var12);
    double var14 = org.apache.commons.math3.util.MathArrays.distance(var5, var9);
    double[] var17 = new double[] { 100.0d, (-1.0d)};
    double[] var20 = new double[] { 100.0d, 1.0d};
    boolean var21 = org.apache.commons.math3.util.MathArrays.equals(var17, var20);
    double[] var24 = new double[] { 100.0d, (-1.0d)};
    double[] var27 = new double[] { 100.0d, 1.0d};
    boolean var28 = org.apache.commons.math3.util.MathArrays.equals(var24, var27);
    double[] var31 = new double[] { 100.0d, (-1.0d)};
    double[] var34 = new double[] { 100.0d, 1.0d};
    boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var31, var34);
    double var36 = org.apache.commons.math3.util.MathArrays.distance(var27, var31);
    double[] var39 = new double[] { 100.0d, (-1.0d)};
    double[] var42 = new double[] { 100.0d, 1.0d};
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var39, var42);
    double[] var46 = new double[] { 100.0d, (-1.0d)};
    double[] var49 = new double[] { 100.0d, 1.0d};
    boolean var50 = org.apache.commons.math3.util.MathArrays.equals(var46, var49);
    double var51 = org.apache.commons.math3.util.MathArrays.distance(var42, var46);
    double var52 = org.apache.commons.math3.util.MathArrays.linearCombination(var27, var42);
    boolean var53 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var17, var27);
    double var54 = org.apache.commons.math3.util.MathArrays.distanceInf(var5, var17);
    double[] var57 = new double[] { 100.0d, (-1.0d)};
    double[] var60 = new double[] { 100.0d, 1.0d};
    boolean var61 = org.apache.commons.math3.util.MathArrays.equals(var57, var60);
    double[] var62 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var5, var57);
    java.lang.Number var63 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var66 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var63, (java.lang.Number)(byte)100, 0);
    org.apache.commons.math3.exception.util.ExceptionContext var67 = var66.getContext();
    boolean var68 = var66.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var69 = var66.getDirection();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var57, var69, false);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);

  }

  public void test81() {}
//   public void test81() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test81"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextGaussian(0.0d, 2.0d);
//     var1.reSeedSecure(0L);
//     var1.reSeedSecure();
//     double var10 = var1.nextGaussian(2.0d, 2.0d);
//     long var13 = var1.nextLong(3L, 6L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var17 = var1.nextUniform(0.8581937538129115d, (-13066.525482061685d), false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-1.3592363945960575d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.6347008410484671d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 6L);
// 
//   }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test82"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed((-1L));
    int[] var5 = var0.nextPermutation(100, 30);
    double var8 = var0.nextCauchy(0.19389798955545332d, 0.19743013148352145d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var11 = var0.nextCauchy(0.2787313252014696d, (-4331725.964082607d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-0.055195337499989006d));

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test83"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextZipf(100, 2.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var8 = var2.nextPascal(22, 2.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test84"); }


    int[] var1 = new int[] { (-1)};
    int[] var2 = org.apache.commons.math3.util.MathArrays.copyOf(var1);
    int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var2);
    int[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var2);
    int[] var6 = new int[] { (-1)};
    int[] var7 = org.apache.commons.math3.util.MathArrays.copyOf(var6);
    int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var6, 1);
    int[] var11 = new int[] { (-1)};
    int[] var12 = org.apache.commons.math3.util.MathArrays.copyOf(var11);
    int var13 = org.apache.commons.math3.util.MathArrays.distanceInf(var6, var12);
    int var14 = org.apache.commons.math3.util.MathArrays.distance1(var4, var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test85"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(10L);
    var4.setSeed(10);
    int var8 = var4.nextInt(100);
    int[] var10 = new int[] { (-1)};
    int[] var11 = org.apache.commons.math3.util.MathArrays.copyOf(var10);
    int[] var12 = org.apache.commons.math3.util.MathArrays.copyOf(var11);
    var4.setSeed(var12);
    int var14 = org.apache.commons.math3.util.MathArrays.distance1(var1, var12);
    int[] var16 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var17 = new org.apache.commons.math3.random.Well19937c(var16);
    int[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var16);
    int var19 = org.apache.commons.math3.util.MathArrays.distanceInf(var1, var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);

  }

  public void test86() {}
//   public void test86() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test86"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextGaussian(10.0d, 2.0d);
//     int var7 = var1.nextInt(0, 1);
//     double var10 = var1.nextGamma(13.226435756113098d, 99.01980198019803d);
//     long var12 = var1.nextPoisson(0.8769524240060045d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 4.730225990077176d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 2107.3842601178153d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1L);
// 
//   }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test87"); }


    double[] var0 = null;
    java.lang.Comparable[] var2 = new java.lang.Comparable[] { 3068624.4438274824d};
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    boolean var5 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var3, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
    boolean var8 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var6, false);
    java.lang.Number var9 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var12 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var9, (java.lang.Number)(byte)100, 0);
    org.apache.commons.math3.exception.util.ExceptionContext var13 = var12.getContext();
    boolean var14 = var12.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var15 = var12.getDirection();
    boolean var17 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var15, false);
    double[] var20 = new double[] { 100.0d, (-1.0d)};
    double[] var23 = new double[] { 100.0d, 1.0d};
    boolean var24 = org.apache.commons.math3.util.MathArrays.equals(var20, var23);
    double[] var27 = new double[] { 100.0d, (-1.0d)};
    double[] var30 = new double[] { 100.0d, 1.0d};
    boolean var31 = org.apache.commons.math3.util.MathArrays.equals(var27, var30);
    double var32 = org.apache.commons.math3.util.MathArrays.distance(var23, var27);
    double[] var35 = new double[] { 100.0d, (-1.0d)};
    double[] var38 = new double[] { 100.0d, 1.0d};
    boolean var39 = org.apache.commons.math3.util.MathArrays.equals(var35, var38);
    double[] var42 = new double[] { 100.0d, (-1.0d)};
    double[] var45 = new double[] { 100.0d, 1.0d};
    boolean var46 = org.apache.commons.math3.util.MathArrays.equals(var42, var45);
    double var47 = org.apache.commons.math3.util.MathArrays.distance(var38, var42);
    double[] var50 = new double[] { 100.0d, (-1.0d)};
    double[] var53 = new double[] { 100.0d, 1.0d};
    boolean var54 = org.apache.commons.math3.util.MathArrays.equals(var50, var53);
    double[] var57 = new double[] { 100.0d, (-1.0d)};
    double[] var60 = new double[] { 100.0d, 1.0d};
    boolean var61 = org.apache.commons.math3.util.MathArrays.equals(var57, var60);
    double var62 = org.apache.commons.math3.util.MathArrays.distance(var53, var57);
    double var63 = org.apache.commons.math3.util.MathArrays.linearCombination(var38, var53);
    double[][] var64 = new double[][] { var38};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var27, var64);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.sortInPlace(var0, var15, var64);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);

  }

  public void test88() {}
//   public void test88() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test88"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var5 = var2.nextSecureLong(0L, 1L);
//     var2.reSeed(6L);
//     java.lang.String var9 = var2.nextSecureHexString(10);
//     double var12 = var2.nextCauchy(0.2787313252014696d, 11.227769774268392d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "1d01980c7e"+ "'", var9.equals("1d01980c7e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 16.984168499937674d);
// 
//   }

  public void test89() {}
//   public void test89() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test89"); }
// 
// 
//     org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1L), (java.lang.Number)10, true);
//     java.lang.String var4 = var3.toString();
//     java.lang.Number var5 = var3.getArgument();
//     org.apache.commons.math3.exception.util.Localizable var6 = null;
//     org.apache.commons.math3.exception.NotPositiveException var8 = new org.apache.commons.math3.exception.NotPositiveException(var6, (java.lang.Number)100L);
//     java.lang.Number var9 = var8.getMin();
//     var3.addSuppressed((java.lang.Throwable)var8);
//     java.lang.String var11 = var8.toString();
// 
//   }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test90"); }


    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1L, (java.lang.Number)(-1), 1, var3, false);
    int var6 = var5.getIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test91"); }


    java.lang.Number var0 = null;
    java.lang.Comparable[] var2 = new java.lang.Comparable[] { 3068624.4438274824d};
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    boolean var5 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var3, true);
    org.apache.commons.math3.exception.NotFiniteNumberException var6 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Object[])var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test92() {}
//   public void test92() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test92"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextT(10001.0d);
//     long var6 = var1.nextLong((-1L), 3L);
//     var1.reSeedSecure();
//     java.lang.String var9 = var1.nextHexString(12);
//     double var11 = var1.nextT(0.473974825082335d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var1.nextInt(10, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-0.57387101862265d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "1e67b556ad2f"+ "'", var9.equals("1e67b556ad2f"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.029935078823738824d);
// 
//   }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test93"); }


    double[] var2 = new double[] { 100.0d, (-1.0d)};
    double[] var5 = new double[] { 100.0d, 1.0d};
    boolean var6 = org.apache.commons.math3.util.MathArrays.equals(var2, var5);
    double[] var9 = new double[] { 100.0d, (-1.0d)};
    double[] var12 = new double[] { 100.0d, 1.0d};
    boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var9, var12);
    double var14 = org.apache.commons.math3.util.MathArrays.distance(var5, var9);
    double[] var17 = new double[] { 100.0d, (-1.0d)};
    double[] var20 = new double[] { 100.0d, 1.0d};
    boolean var21 = org.apache.commons.math3.util.MathArrays.equals(var17, var20);
    double[] var24 = new double[] { 100.0d, (-1.0d)};
    double[] var27 = new double[] { 100.0d, 1.0d};
    boolean var28 = org.apache.commons.math3.util.MathArrays.equals(var24, var27);
    double[] var31 = new double[] { 100.0d, (-1.0d)};
    double[] var34 = new double[] { 100.0d, 1.0d};
    boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var31, var34);
    double var36 = org.apache.commons.math3.util.MathArrays.distance(var27, var31);
    double[] var39 = new double[] { 100.0d, (-1.0d)};
    double[] var42 = new double[] { 100.0d, 1.0d};
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var39, var42);
    double[] var46 = new double[] { 100.0d, (-1.0d)};
    double[] var49 = new double[] { 100.0d, 1.0d};
    boolean var50 = org.apache.commons.math3.util.MathArrays.equals(var46, var49);
    double var51 = org.apache.commons.math3.util.MathArrays.distance(var42, var46);
    double var52 = org.apache.commons.math3.util.MathArrays.linearCombination(var27, var42);
    boolean var53 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var17, var27);
    double[] var55 = org.apache.commons.math3.util.MathArrays.normalizeArray(var27, (-1.682916631768903d));
    double[] var58 = new double[] { 100.0d, (-1.0d)};
    double[] var61 = new double[] { 100.0d, 1.0d};
    boolean var62 = org.apache.commons.math3.util.MathArrays.equals(var58, var61);
    double[] var65 = new double[] { 100.0d, (-1.0d)};
    double[] var68 = new double[] { 100.0d, 1.0d};
    boolean var69 = org.apache.commons.math3.util.MathArrays.equals(var65, var68);
    double var70 = org.apache.commons.math3.util.MathArrays.distance(var61, var65);
    double[] var73 = new double[] { 100.0d, (-1.0d)};
    double[] var76 = new double[] { 100.0d, 1.0d};
    boolean var77 = org.apache.commons.math3.util.MathArrays.equals(var73, var76);
    double[] var80 = new double[] { 100.0d, (-1.0d)};
    double[] var83 = new double[] { 100.0d, 1.0d};
    boolean var84 = org.apache.commons.math3.util.MathArrays.equals(var80, var83);
    double var85 = org.apache.commons.math3.util.MathArrays.distance(var76, var80);
    double var86 = org.apache.commons.math3.util.MathArrays.linearCombination(var61, var76);
    double[] var87 = org.apache.commons.math3.util.MathArrays.ebeAdd(var55, var61);
    double[] var89 = new double[] { 10.0d};
    double var90 = org.apache.commons.math3.util.MathArrays.safeNorm(var89);
    org.apache.commons.math3.util.MathArrays.OrderDirection var91 = null;
    boolean var93 = org.apache.commons.math3.util.MathArrays.isMonotonic(var89, var91, false);
    boolean var94 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var87, var89);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var95 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var9, var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 10001.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var94 == false);

  }

}
