
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(1, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.3440585709080678E43d);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }


    float var2 = org.apache.commons.math3.util.FastMath.min((-1.0f), 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.0f));

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999999958776927d);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow((-1.0d), 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(1.3440585709080678E43d, (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7.440151952041671E-44d);

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(0.9999999958776927d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999999958776928d);

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.9999999958776928d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.7182818172534526d);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var5 = var0.nextPermutation(1, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSecureAlgorithm("hi!", "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test13() {}
//   public void test13() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     java.util.Collection var2 = null;
//     java.lang.Object[] var4 = var1.nextSample(var2, 10);
// 
//   }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = var0.nextSecureHexString((-1));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test15() {}
//   public void test15() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Object[] var2 = new java.lang.Object[] { (short)0};
//     org.apache.commons.math3.exception.MathIllegalArgumentException var3 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var2);
//     org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
// 
//   }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.0d, 2.7182818172534526d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = var0.nextUniform(100.0d, 0.9999999960115731d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    byte[] var2 = new byte[] { };
    var0.nextBytes(var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var7 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var0, (-1), 0, 100);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var3 = var1.nextChiSquare(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.9999999960115731d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.7182818176173766d);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(0.0f, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.NEGATIVE_INFINITY);

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(7.440151952041671E-44d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2985514841181041E-45d);

  }

  public void test27() {}
//   public void test27() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextWeibull(1.3440585709080678E43d, 1.0d);
//     var1.reSeed();
//     java.util.Collection var6 = null;
//     java.lang.Object[] var8 = var1.nextSample(var6, 100);
// 
//   }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4E-45f);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var3 = var0.nextLong((-1L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    double var4 = var1.nextWeibull(1.3440585709080678E43d, 1.0d);
    var1.reSeed();
    org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.distribution.HypergeometricDistribution var10 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var6, 1, 0, 0);
    int var11 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var14 = var1.nextBeta(0.9999999960115731d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
    } catch (org.apache.commons.math3.exception.NoBracketingException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(1.3440585709080678E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 99.30685281944005d);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5707963267948966d);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(0L, 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var3 = var1.nextInt(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var0.nextUniform(1.0d, 7.440151952041671E-44d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(1.3440585709080678E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 43.1284181946612d);

  }

  public void test38() {}
//   public void test38() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextWeibull(1.3440585709080678E43d, 1.0d);
//     var1.reSeed();
//     org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.distribution.HypergeometricDistribution var10 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var6, 1, 0, 0);
//     int var11 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var10);
//     org.apache.commons.math3.distribution.IntegerDistribution var12 = null;
//     int var13 = var1.nextInversionDeviate(var12);
// 
//   }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed();
    int var4 = var0.nextZipf(10, 10.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var6 = var0.nextSecureHexString(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(1.0f, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.99999994f);

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(0.9999999984135708d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8414709839507452d);

  }

  public void test42() {}
//   public void test42() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextUniform(0.9999999960115731d, 2.7182818176173766d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var7 = var1.nextWeibull(Double.NEGATIVE_INFINITY, 1.2985514841181041E-45d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.064262263185927d);
// 
//   }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 10);

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.220446049250313E-16d);

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(7.440151952041671E-44d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-43.1284181946612d));

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = var0.nextT((-43.1284181946612d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Object[] var3 = new java.lang.Object[] { (short)0};
    org.apache.commons.math3.exception.MathIllegalArgumentException var4 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, var3);
    org.apache.commons.math3.exception.MathIllegalStateException var5 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var3);
    org.apache.commons.math3.exception.util.ExceptionContext var6 = var5.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var7 = var5.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }


    double var1 = org.apache.commons.math3.util.FastMath.acos(0.9999999958776927d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9.079985986933498E-5d);

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(7.440151952041671E-44d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test50() {}
//   public void test50() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     double var3 = var0.nextExponential(10.0d);
//     java.util.Collection var4 = null;
//     java.lang.Object[] var6 = var0.nextSample(var4, 1);
// 
//   }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(10.0d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed();
    int var4 = var0.nextZipf(10, 10.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var7 = var0.nextGaussian(7.440151952041671E-44d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(9.079985986933498E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9.079986011887159E-5d);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(0.8756646f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.87566465f);

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed();
    int var4 = var0.nextZipf(10, 10.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var7 = var0.nextPermutation((-1), 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(1.3440585709080678E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.718281828459045d);

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(1.4E-45f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var5 = var0.nextZipf(100, Double.NEGATIVE_INFINITY);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(1.4E-45f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4E-45f);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow((-0.8608123678316708d), 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.0963483532390896E-7d);

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }


    org.apache.commons.math3.exception.MathInternalError var0 = new org.apache.commons.math3.exception.MathInternalError();

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(0.9999999958776927d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 57.295779276891516d);

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.19888476295580476d, 0.9999999958776927d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.1988847629558048d);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow((-43.1284181946612d), 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6931471805599453d);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(0.8756646f, 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0f);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(43.1284181946612d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.105427357601002E-15d);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.9999999985607362d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5403023070792384d);

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(4L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4L);

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.9999999985607362d, 2.220446049250313E-16d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    byte[] var2 = new byte[] { };
    var0.nextBytes(var2);
    org.apache.commons.math3.distribution.HypergeometricDistribution var7 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var0, 1, 0, 1);
    int var8 = var7.getSupportUpperBound();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var11 = var7.cumulativeProbability(100, (-1751072663));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);

  }

  public void test74() {}
//   public void test74() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var0, 100, (-1), (-1));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(0.99999994f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.9604645E-8f);

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(1.4E-45f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(0.9999999981579031d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999999981579032d);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(2.7182818172534526d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.45054954755007814d));

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(0.8756646f, 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.8756646f);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(0.6931471805599453d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8849970445005177d);

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var5 = var0.nextHypergeometric((-1751072663), 10, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(0.8756646f, 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.8756646f);

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs((-1751072663));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1751072663);

  }

  public void test85() {}
//   public void test85() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextWeibull(1.3440585709080678E43d, 1.0d);
//     double var7 = var1.nextBeta(100.0d, 0.9999999981579031d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var1.nextHypergeometric(100, 100, (-1));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.9946759351478884d);
// 
//   }

  public void test86() {}
//   public void test86() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextGaussian(9.079986011887159E-5d, 2.7182818172534526d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var6 = var0.nextGaussian(2.7182818176173766d, Double.NEGATIVE_INFINITY);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 4.332520574818658d);
// 
//   }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(43.1284181946612d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 43.0d);

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSecureAlgorithm("", "org.apache.commons.math3.exception.NotANumberException: NaN is not allowed");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var1 = null;
    org.apache.commons.math3.exception.MathIllegalStateException var2 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var1);

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(0.99999994f, (-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.99999994f));

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }


    int[] var2 = new int[] { 0, 100};
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var5 = var3.nextLong(0L);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(2.062677441918783d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.NEGATIVE_INFINITY);

  }

  public void test93() {}
//   public void test93() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextGaussian(9.079986011887159E-5d, 2.7182818172534526d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var5 = var0.nextPoisson(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.143837280674261d);
// 
//   }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }


    int var2 = org.apache.commons.math3.util.FastMath.max((-1), (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var4 = var0.nextHypergeometric((-1751072663), 0, 100);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    byte[] var2 = new byte[] { };
    var0.nextBytes(var2);
    org.apache.commons.math3.distribution.HypergeometricDistribution var7 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var0, 1, 0, 1);
    var0.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var10 = var0.nextInt((-1));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(0.87566465f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.9604645E-8f);

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = var0.nextExponential(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(0.87566465f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.87566465f);

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(5.9604645E-8f, 0.8414709839507452d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5.960465E-8f);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    double var4 = var1.nextWeibull(1.3440585709080678E43d, 1.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var7 = var1.nextCauchy(0.0d, (-0.5996555078851037d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(1.0f, 0.99999994f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0f);

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(2.039860471086022d, 1751072663);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.POSITIVE_INFINITY);

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var3 = var1.nextT(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.6913269815529459d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution((-1), (-898785569), (-1303859983));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test108() {}
//   public void test108() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var9 = var1.nextHypergeometric(0, (-898785569), (-1303859983));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.9999999985889878d);
// 
//   }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(1.4E-45f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4E-45f);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.997364744862623d, 0.997364744862623d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.4104867488175032d);

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint((-0.8608123678316708d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs((-898785569));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 898785569);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(0.0d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test114() {}
//   public void test114() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     double var5 = var0.nextUniform(0.9999999958776928d, 1.0d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var8 = var0.nextF(43.0d, Double.NaN);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.999999999870355d);
// 
//   }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(86L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 86L);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(0.5403023070792384d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test117() {}
//   public void test117() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextF(0.9999999958776927d, 0.9999999960115731d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var6 = var0.nextF(Double.POSITIVE_INFINITY, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2.7418823840930986d);
// 
//   }

  public void test118() {}
//   public void test118() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh(0.9999999958776928d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test119() {}
//   public void test119() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextF(0.8849970445005177d, 100.0d);
//     double var6 = var0.nextWeibull(0.9999999985607362d, 7.105427357601002E-15d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var0.nextF(0.6913269815529459d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.7818333109736607d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 9.715280435310436E-15d);
// 
//   }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0f);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(Double.NEGATIVE_INFINITY, 0.796031726960919d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.5707963267948966d));

  }

  public void test122() {}
//   public void test122() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextWeibull(1.3440585709080678E43d, 1.0d);
//     double var7 = var1.nextBeta(100.0d, 0.9999999981579031d);
//     var1.reSeedSecure(0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var1.nextCauchy(0.9832066969973898d, (-0.45054954755007814d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.9902568779172275d);
// 
//   }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(0.9999999958776928d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.7902952569832583E-9d));

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(0.0f, (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(5.9604645E-8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-24));

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var3 = var0.nextUniform(0.796031726960919d, 0.09600083985689681d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeedSecure(1L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var5 = var0.nextInt((-1751072663), (-1751072663));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var4 = var0.nextPascal((-1751072663), 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test129() {}
//   public void test129() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextGaussian(9.079986011887159E-5d, 2.7182818172534526d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var5 = var0.nextT((-0.31967323691980976d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1.2604596566926318d));
// 
//   }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed();
    int var4 = var0.nextZipf(10, 10.0d);
    org.apache.commons.math3.random.RandomGenerator var5 = var0.getRandomGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var7 = var0.nextHexString((-898785569));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(5.9604645E-8f, (-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-5.9604645E-8f));

  }

  public void test132() {}
//   public void test132() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     int var4 = var0.nextZipf(10, 10.0d);
//     double var7 = var0.nextGamma(0.9999999981579032d, 99.30685281944005d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var0.nextGaussian(0.9999999981579031d, (-0.45054954755007814d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 82.81898997284262d);
// 
//   }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(5.9604645E-8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.960465E-8f);

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(898785569, (-1751072663), (-898785569));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    byte[] var2 = new byte[] { };
    var0.nextBytes(var2);
    org.apache.commons.math3.distribution.HypergeometricDistribution var7 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var0, 1, 0, 1);
    int var8 = var7.getSupportUpperBound();
    double var10 = var7.probability(356963565);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var13 = var7.cumulativeProbability(898785569, (-898785569));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(0.9999999985607362d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5707426748831026d);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.9999999984135708d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(1.3440585709080678E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9223372036854775807L);

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0f);

  }

//  public void test140() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }
//
//
//    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//    org.apache.commons.math3.distribution.HypergeometricDistribution var4 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var0, 1, 0, 0);
//    int var5 = var4.getPopulationSize();
//    // The following exception was thrown during execution.
//    // This behavior will recorded for regression testing.
//    try {
//      int[] var7 = var4.sample(898785569);
//      fail("Expected exception of type java.lang.OutOfMemoryError");
//    } catch (java.lang.OutOfMemoryError e) {
//      // Expected exception.
//    }
//    
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var5 == 1);
//
//  }
//
  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(2.718281828459045d, 0.8849970445005177d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.12217097352722141d));

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(9.34417912153031d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.99999998469691d);

  }

  public void test143() {}
//   public void test143() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var7 = var1.nextUniform(0.49364015980407d, (-0.8608123678316708d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
// 
//   }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(1751072663, 898785569);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 898785569);

  }

  public void test145() {}
//   public void test145() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     double var3 = var0.nextExponential(10.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var6 = var0.nextSecureInt(0, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 9.832458029034912d);
// 
//   }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1L);

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(1.4E-45f, 0.9999999984135708d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.8E-45f);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(0.9832066969973898d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9832066969973899d);

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(0L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(0.997364744862623d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.002638733534516324d));

  }

  public void test152() {}
//   public void test152() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin((-1.5707963267948966d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test153() {}
//   public void test153() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     long var6 = var1.nextPoisson(1.5707963267948966d);
//     int var9 = var1.nextBinomial(100, 0.0d);
//     double var12 = var1.nextWeibull(0.9999999984135708d, 0.9999999981579031d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var1.nextChiSquare((-0.8608123678316708d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.9999999988854988d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.49853375753766d);
// 
//   }

  public void test154() {}
//   public void test154() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     double var5 = var0.nextUniform(0.9999999958776928d, 1.0d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var0.nextUniform((-1.5707963267948966d), Double.NaN, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotANumberException");
//     } catch (org.apache.commons.math3.exception.NotANumberException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.9999999983887448d);
// 
//   }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(86L, 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0L);

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    org.apache.commons.math3.random.RandomGenerator var3 = var0.getRandomGenerator();
    org.apache.commons.math3.random.RandomGenerator var4 = var0.getRandomGenerator();
    double var7 = var0.nextCauchy(0.09600083985689681d, 1.4104867488175032d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var10 = var0.nextSecureInt(1751072663, 356963565);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-0.31967323691980976d));

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp((-0.99999994f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.9999999f));

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test160() {}
//   public void test160() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var6 = var1.nextPoisson((-1.5707963267948966d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
// 
//   }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.5403023070792384d, 0.14822362710183382d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.5602649611267612d);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(1.3440585709080678E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.3440585709080678E43d);

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(0.6576685413083545d, 99.30685281944005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-10.972839449353398d));

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(1, 898785569, 1);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(100, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.5602649611267612d, 0.9999999983533883d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.4397350372266271d));

  }

  public void test167() {}
//   public void test167() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextWeibull(1.3440585709080678E43d, 1.0d);
//     double var7 = var1.nextBeta(100.0d, 0.9999999981579031d);
//     var1.reSeedSecure(0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var11 = var1.nextSecureHexString(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.9898856527667649d);
// 
//   }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)1.5707426748831026d);

  }

  public void test169() {}
//   public void test169() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextWeibull(1.3440585709080678E43d, 1.0d);
//     double var7 = var1.nextGamma(2.062677441918783d, 0.796031726960919d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var10 = var1.nextSecureLong(86L, 1L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2.2270477232607813d);
// 
//   }

  public void test170() {}
//   public void test170() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     long var6 = var1.nextPoisson(1.5707963267948966d);
//     int var9 = var1.nextBinomial(100, 0.0d);
//     long var12 = var1.nextSecureLong(0L, 2L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var15 = var1.nextPermutation(100, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1L);
// 
//   }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    org.apache.commons.math3.random.RandomGenerator var3 = var0.getRandomGenerator();
    org.apache.commons.math3.random.RandomGenerator var4 = var0.getRandomGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var7 = var0.nextPermutation(898785569, (-24));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(0.04206742590911261d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.47801733f, 0.09600083985689681d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.4780173f);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.0d, 0.1988847629558048d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    double var4 = var1.nextWeibull(1.3440585709080678E43d, 1.0d);
    var1.reSeed();
    org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.distribution.HypergeometricDistribution var10 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var6, 1, 0, 0);
    int var11 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var10);
    int var12 = var10.getSampleSize();
    int var13 = var10.getSupportUpperBound();
    int var14 = var10.getSupportUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh((-0.45054954755007814d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.43655076153977196d));

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5729.5779513082325d);

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(57.295779276891516d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.048226960918503d);

  }

  public void test179() {}
//   public void test179() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     var1.reSeedSecure();
//     int var8 = var1.nextPascal(10, 1.0d);
//     double var12 = var1.nextUniform(0.0d, 9.079986011887159E-5d, true);
//     java.util.Collection var13 = null;
//     java.lang.Object[] var15 = var1.nextSample(var13, (-381930297));
// 
//   }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(0.9999999960115731d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.175201187489337d);

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs((-1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1L);

  }

  public void test182() {}
//   public void test182() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     double var3 = var0.nextExponential(0.9999999983533883d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var6 = var0.nextLong(4L, 4L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.9668716736215022d);
// 
//   }

  public void test183() {}
//   public void test183() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextGaussian(9.079986011887159E-5d, 2.7182818172534526d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var6 = var0.nextZipf(356963565, (-1.0556578976664823d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2.5628840555988073d);
// 
//   }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(86L);
    var1.setSeed((-1303859983));

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(2L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2L);

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp((-0.002638733534516324d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.0026387335345163234d));

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(1L, 3L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3L);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var5 = var0.nextUniform(1.5707963267948966d, 2.718281828459045d);
    int var8 = var0.nextBinomial(100, 9.079985986933498E-5d);
    double var10 = var0.nextExponential(0.9999999958776928d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var13 = var0.nextZipf(100, Double.POSITIVE_INFINITY);
      fail("Expected exception of type org.apache.commons.math3.exception.MathInternalError");
    } catch (org.apache.commons.math3.exception.MathInternalError e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2.039860471086022d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.7116558561440108d);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.8414709839507452d, (java.lang.Number)1.0d, (java.lang.Number)100);
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var3.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    double var4 = var1.nextWeibull(1.3440585709080678E43d, 1.0d);
    var1.reSeed();
    org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.distribution.HypergeometricDistribution var10 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var6, 1, 0, 0);
    int var11 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var14 = var1.nextInt(0, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.9999999988073947d, 1631590754);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.14286661306191545d);

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var5 = var0.nextUniform(1.5707963267948966d, 2.718281828459045d);
    long var7 = var0.nextPoisson(0.8849970445005177d);
    var0.reSeedSecure((-1L));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var13 = var0.nextUniform(99.30685281944005d, 2.2284072655256315d, false);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2.039860471086022d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2L);

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(3L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3L);

  }

  public void test194() {}
//   public void test194() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(0L, 86L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 44L);
// 
//   }

  public void test195() {}
//   public void test195() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     int var4 = var0.nextZipf(10, 10.0d);
//     org.apache.commons.math3.random.RandomGenerator var5 = var0.getRandomGenerator();
//     java.util.Collection var6 = null;
//     java.lang.Object[] var8 = var0.nextSample(var6, 0);
// 
//   }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(0.0f, (-5.9604645E-8f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-5.9604645E-8f));

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var0.nextF((-0.8051174925228636d), 2.2284072655256315d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    org.apache.commons.math3.random.RandomGenerator var3 = var0.getRandomGenerator();
    var0.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var7 = var0.nextLong(100L, 2L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test199() {}
//   public void test199() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     long var6 = var1.nextPoisson(1.5707963267948966d);
//     int var9 = var1.nextBinomial(100, 0.0d);
//     double var12 = var1.nextWeibull(0.9999999984135708d, 0.9999999981579031d);
//     double var15 = var1.nextGaussian((-0.8608123678316708d), 0.1988847629558048d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("hi!", "org.apache.commons.math3.exception.NotANumberException: NaN is not allowed");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.07061630720929575d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-0.9103914877617173d));
// 
//   }

  public void test200() {}
//   public void test200() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     var1.reSeedSecure();
//     int var8 = var1.nextPascal(10, 1.0d);
//     var1.reSeed();
//     double var11 = var1.nextExponential(2.718281828459045d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var14 = var1.nextPermutation(0, (-898785569));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.8619874000458232d);
// 
//   }

  public void test201() {}
//   public void test201() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     byte[] var2 = new byte[] { };
//     var0.nextBytes(var2);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var7 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var0, 1, 0, 1);
//     double var8 = var0.nextGaussian();
//     int var9 = var0.nextInt();
//     org.apache.commons.math3.random.RandomDataGenerator var10 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
//     var10.reSeed(100L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var15 = var10.nextLong(9223372036854775807L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-1.2437075690409407d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-471871539));
// 
//   }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0, (java.lang.Number)10L, (java.lang.Number)0.0f);
    java.lang.Number var4 = var3.getLo();
    java.lang.Throwable[] var5 = var3.getSuppressed();
    java.lang.Number var6 = var3.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 10L+ "'", var4.equals(10L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 10L+ "'", var6.equals(10L));

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var3 = var0.nextLong(0L, 0L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution((-381930297), (-24), 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    org.apache.commons.math3.random.RandomGenerator var3 = var0.getRandomGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var6 = var0.nextZipf((-1), (-1.0556578976664823d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test206() {}
//   public void test206() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     int var4 = var0.nextZipf(10, 10.0d);
//     long var6 = var0.nextPoisson(9.079986011887159E-5d);
//     java.util.Collection var7 = null;
//     java.lang.Object[] var9 = var0.nextSample(var7, 10);
// 
//   }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(1.5707963267948966d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0038848218538872d);

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(3.0963483532390896E-7d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-22));

  }

  public void test209() {}
//   public void test209() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     byte[] var2 = new byte[] { };
//     var0.nextBytes(var2);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var7 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var0, 1, 0, 1);
//     double var8 = var0.nextGaussian();
//     int var9 = var0.nextInt();
//     org.apache.commons.math3.random.RandomDataGenerator var10 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
//     var10.reSeed(100L);
//     double var14 = var10.nextT(2.7182818172534526d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var16 = var10.nextExponential((-0.05962020220104047d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.5168287917770061d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 461074528);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-1.0423136260211314d));
// 
//   }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    double var4 = var1.nextWeibull(1.3440585709080678E43d, 1.0d);
    var1.reSeed();
    org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.distribution.HypergeometricDistribution var10 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var6, 1, 0, 0);
    int var11 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var15 = var1.nextHypergeometric(10, 356963565, 1403217883);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }


    double var1 = org.apache.commons.math3.util.FastMath.acos(0.9999999987463872d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.007220325508991E-5d);

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var5 = var0.nextUniform(1.5707963267948966d, 2.718281828459045d);
    long var7 = var0.nextPoisson(0.8849970445005177d);
    var0.reSeedSecure((-1L));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var11 = var0.nextSecureHexString((-22));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2.039860471086022d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2L);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(0.5403023070792384d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8144772173080679d);

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(0L, 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test215() {}
//   public void test215() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     long var6 = var1.nextPoisson(1.5707963267948966d);
//     int var9 = var1.nextBinomial(100, 0.0d);
//     long var12 = var1.nextSecureLong(0L, 2L);
//     double var14 = var1.nextChiSquare(0.6576685413083545d);
//     var1.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.0033187103187824712d);
// 
//   }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)4L, (java.lang.Number)0.9999999985607362d, true);

  }

  public void test217() {}
//   public void test217() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     double var3 = var0.nextExponential(10.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var6 = var0.nextInt(904660695, (-898785569));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.5493695211985026d);
// 
//   }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(0.9999999988073947d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5707474881759962d);

  }

  public void test219() {}
//   public void test219() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.distribution.HypergeometricDistribution var4 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var0, 1, 0, 0);
//     boolean var5 = var0.nextBoolean();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == false);
// 
//   }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.distribution.HypergeometricDistribution var4 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var0, 1, 0, 0);
    int var5 = var4.getPopulationSize();
    int var6 = var4.getNumberOfSuccesses();
    int var7 = var4.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);

  }

  public void test221() {}
//   public void test221() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     double var3 = var0.nextExponential(0.9999999983533883d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var6 = var0.nextBinomial(1, (-0.45054954755007814d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.14567266985802058d);
// 
//   }

  public void test222() {}
//   public void test222() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextWeibull(1.3440585709080678E43d, 1.0d);
//     double var7 = var1.nextBeta(100.0d, 0.9999999981579031d);
//     java.util.Collection var8 = null;
//     java.lang.Object[] var10 = var1.nextSample(var8, (-22));
// 
//   }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed();
    int var4 = var0.nextZipf(10, 10.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var7 = var0.nextCauchy(1.5707474881759962d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.47801733f, 0.45442853273944145d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.4780173f);

  }

  public void test225() {}
//   public void test225() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextWeibull(1.3440585709080678E43d, 1.0d);
//     var1.reSeed();
//     org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.distribution.HypergeometricDistribution var10 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var6, 1, 0, 0);
//     int var11 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var10);
//     int var12 = var10.getSampleSize();
//     double var13 = var10.getNumericalVariance();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var16 = var10.cumulativeProbability(100, (-22));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == Double.NaN);
// 
//   }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(0.5602649611267612d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, (-381930297), (-381930297), 356963565);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(0.5602649611267612d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.009778468255220022d);

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 100.0f);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos((-0.43655076153977196d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9062154450702296d);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(0.8561856667531293d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.15526802594735428d));

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4210854715202004E-14d);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var5 = var0.nextUniform(1.5707963267948966d, 2.718281828459045d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var7 = var0.nextT(Double.POSITIVE_INFINITY);
      fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
    } catch (org.apache.commons.math3.exception.NoBracketingException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2.039860471086022d);

  }

  public void test234() {}
//   public void test234() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     var1.reSeedSecure();
//     int var8 = var1.nextPascal(10, 1.0d);
//     var1.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var11 = var1.nextSecureHexString((-22));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.9999999981478263d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
// 
//   }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh((-0.8608123678316708d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.2964727668339666d));

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs((-0.9999999f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999999f);

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(0.9832066969973899d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9915677974790176d);

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(0.796031726960919d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.0990696225016985d));

  }

  public void test239() {}
//   public void test239() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     long var6 = var1.nextPoisson(1.5707963267948966d);
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var1.nextF(0.0d, 1.465042107535607E-5d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 4L);
// 
//   }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var5 = var0.nextUniform(1.5707963267948966d, 2.718281828459045d);
    int var8 = var0.nextBinomial(100, 9.079985986933498E-5d);
    double var10 = var0.nextExponential(0.9999999958776928d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var13 = var0.nextZipf(0, 1.0038848218538872d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2.039860471086022d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.7116558561440108d);

  }

  public void test241() {}
//   public void test241() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     double var3 = var0.nextExponential(0.9999999983533883d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var6 = var0.nextSecureLong(100L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.9361108219754978d);
// 
//   }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }


    int var2 = org.apache.commons.math3.util.FastMath.min((-24), (-1751072663));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1751072663));

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(5.960465E-8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.960465E-8f);

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0);
    boolean var2 = var1.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    double var4 = var1.nextWeibull(1.3440585709080678E43d, 1.0d);
    var1.reSeed();
    org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.distribution.HypergeometricDistribution var10 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var6, 1, 0, 0);
    int var11 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var10);
    int[] var13 = var10.sample(1);
    double var16 = var10.cumulativeProbability(1, 10);
    double var18 = var10.cumulativeProbability(1751072663);
    double var20 = var10.upperCumulativeProbability(1751072663);
    double var22 = var10.upperCumulativeProbability((-1303859983));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1.0d);

  }

  public void test246() {}
//   public void test246() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     long var6 = var1.nextPoisson(1.5707963267948966d);
//     int var9 = var1.nextBinomial(100, 0.0d);
//     double var12 = var1.nextWeibull(0.9999999984135708d, 0.9999999981579031d);
//     double var15 = var1.nextGaussian((-0.8608123678316708d), 0.1988847629558048d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var18 = var1.nextGamma(0.9999999981579032d, (-0.8608123678316708d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.9999999984935639d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.35384798481012764d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-1.2327759088461194d));
// 
//   }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(1.2985514841181041E-45d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.266399890451977E-47d);

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(1.1406515950416476d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0680129189488523d);

  }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(2.266399890451977E-47d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.2663998904519776E-47d);

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(2.7182818172534526d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.5707963267948966d);

  }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed();
    int var4 = var0.nextZipf(10, 10.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSecureAlgorithm("hi!", "org.apache.commons.math3.exception.NotANumberException: NaN is not allowed");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    org.apache.commons.math3.random.RandomGenerator var3 = var0.getRandomGenerator();
    org.apache.commons.math3.random.RandomGenerator var4 = var0.getRandomGenerator();
    double var7 = var0.nextCauchy(0.09600083985689681d, 1.4104867488175032d);
    var0.reSeedSecure(2L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var11 = var0.nextSecureHexString((-1303859983));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-0.31967323691980976d));

  }

  public void test253() {}
//   public void test253() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     org.apache.commons.math3.random.Well19937c var5 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.distribution.HypergeometricDistribution var9 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var5, 1, 0, 0);
//     int var10 = var9.getPopulationSize();
//     int var11 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var9);
//     double var13 = var9.probability(100);
//     int var15 = var9.inverseCumulativeProbability(0.9999999981579031d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var17 = var9.sample((-1751072663));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.9999999983470635d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0);
// 
//   }

  public void test254() {}
//   public void test254() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     java.lang.String var6 = var1.nextSecureHexString(100);
//     double var8 = var1.nextT(1.4104867488175032d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var1.nextBinomial(100, 2.2284072655256315d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "df0cf2d2a6dffea32a78ecdc33e04c14cafd998bc27728fee4e0b71e47274906cc15f58fb0c108f8cf447252918ea9b9f40c"+ "'", var6.equals("df0cf2d2a6dffea32a78ecdc33e04c14cafd998bc27728fee4e0b71e47274906cc15f58fb0c108f8cf447252918ea9b9f40c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.7469833099113289d);
// 
//   }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1));
    double var2 = var1.nextGaussian();
    boolean var3 = var1.nextBoolean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.5996555078851037d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);

  }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(156.29984373774747d, (-0.31967323691980976d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.5728415802227789d);

  }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    byte[] var2 = new byte[] { };
    var0.nextBytes(var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var5 = var0.nextInt((-1751072663));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test258() {}
//   public void test258() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     long var6 = var1.nextPoisson(1.5707963267948966d);
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var1.nextSecureInt(0, (-341994742));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2L);
// 
//   }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(0.8008915432040549d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.22202974282417431d));

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(2.718281828459045d, Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    double var4 = var1.nextWeibull(1.3440585709080678E43d, 1.0d);
    var1.reSeed();
    org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.distribution.HypergeometricDistribution var10 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var6, 1, 0, 0);
    int var11 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var10);
    int[] var13 = var10.sample(1);
    double var16 = var10.cumulativeProbability(1, 10);
    double var18 = var10.cumulativeProbability(1751072663);
    double var20 = var10.upperCumulativeProbability(1751072663);
    int var22 = var10.inverseCumulativeProbability(0.9999999958776928d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var24 = var10.sample((-341994742));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }


    double var1 = org.apache.commons.math3.util.FastMath.acos(2.340547218914322E-6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5707939862476776d);

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.9999999958776927d);

  }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.3967883861837536d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-2));

  }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.13834817027406507d, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test266() {}
//   public void test266() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     var1.reSeedSecure();
//     int var8 = var1.nextPascal(10, 1.0d);
//     var1.reSeed();
//     double var11 = var1.nextExponential(2.718281828459045d);
//     var1.reSeedSecure(0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var16 = var1.nextUniform(0.19888476295580476d, 0.13834817027406507d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.6121272669068892d);
// 
//   }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp((-1.0423136260211314d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.3526378652778325d);

  }

  public void test268() {}
//   public void test268() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.atan2(Double.NaN, 0.45442853273944145d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }


    org.apache.commons.math3.exception.MathIllegalStateException var0 = new org.apache.commons.math3.exception.MathIllegalStateException();
    org.apache.commons.math3.exception.util.ExceptionContext var1 = var0.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test270() {}
//   public void test270() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     double var4 = var0.nextWeibull(1.5707474881759962d, 1.465042107535607E-5d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var8 = var0.nextUniform((-0.43655076153977196d), (-1.0423136260211314d), false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0649771495146079E-5d);
// 
//   }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }


    int var2 = org.apache.commons.math3.util.FastMath.max((-2), (-24));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-2));

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    byte[] var2 = new byte[] { };
    var0.nextBytes(var2);
    var0.setSeed(0L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var7 = var0.nextInt((-2));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test273() {}
//   public void test273() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.pow((-43.1284181946612d), 1.5707426748831026d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test274() {}
//   public void test274() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     var1.reSeedSecure();
//     int var8 = var1.nextPascal(10, 1.0d);
//     var1.reSeed();
//     double var11 = var1.nextExponential(2.718281828459045d);
//     var1.reSeedSecure(0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var1.nextInt(0, (-1406140309));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.9968745780719799d);
// 
//   }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.9999999983761798d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test276() {}
//   public void test276() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var7 = var1.nextSecureLong(9223372036854775807L, 86L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
// 
//   }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(0.8849970445005177d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7244640698111079d);

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(7.105427357601002E-15d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.105427357601027E-15d);

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(0.9915677974790176d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.017306122822757185d);

  }

  public void test281() {}
//   public void test281() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     java.util.Collection var1 = null;
//     java.lang.Object[] var3 = var0.nextSample(var1, (-1303859983));
// 
//   }

  public void test282() {}
//   public void test282() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(1.4376971476050446d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(2.2663998904519776E-47d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2985514841181043E-45d);

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(0.14822362710183382d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.909033151689426d));

  }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh((-0.15526802594735428d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.15589264946400347d));

  }

  public void test286() {}
//   public void test286() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextF(0.8849970445005177d, 100.0d);
//     var0.reSeed(3L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("02f7bc4360a8525bd4987a9d998124e802a7f265bc27fff7e441f950d132dffddc73174650b1923710568194444738263d1d", "hi!");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.02382895476238166d);
// 
//   }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    double var4 = var1.nextWeibull(1.3440585709080678E43d, 1.0d);
    var1.reSeed();
    org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.distribution.HypergeometricDistribution var10 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var6, 1, 0, 0);
    int var11 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var10);
    int[] var13 = var10.sample(1);
    double var16 = var10.cumulativeProbability(1, 10);
    double var18 = var10.cumulativeProbability(1751072663);
    boolean var19 = var10.isSupportConnected();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);

  }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(0.19888476295580476d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.20154923380017717d);

  }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(1.6700035326960307E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(0.87566465f, 0.9999999f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.87566465f);

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign((-1.2964727668339666d), 0.796031726960919d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.2964727668339666d);

  }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.6576685413083545d, (java.lang.Number)0.6931471805599453d, false);
    boolean var4 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(0.99999994f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test294() {}
//   public void test294() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextWeibull(1.3440585709080678E43d, 1.0d);
//     var1.reSeed();
//     org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.distribution.HypergeometricDistribution var10 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var6, 1, 0, 0);
//     int var11 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var10);
//     int[] var13 = var10.sample(1);
//     double var16 = var10.cumulativeProbability(1, 10);
//     double var18 = var10.probability(0);
//     var10.reseedRandomGenerator(44L);
//     int var22 = var10.inverseCumulativeProbability(0.04206742590911261d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0);
// 
//   }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed();
    int var4 = var0.nextZipf(10, 10.0d);
    long var6 = var0.nextPoisson(9.079986011887159E-5d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var0.nextChiSquare((-1.5108247410718927d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0L);

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(0, 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100);

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign((-0.9999999f), 0.87566465f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9999999f);

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb((-0.0026387335345163234d), 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.0026387335345163234d));

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3);

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(0.9999999958776928d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(4.048226960918503d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.3286227060069709d);

  }

  public void test302() {}
//   public void test302() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     long var6 = var1.nextPoisson(1.5707963267948966d);
//     int var9 = var1.nextBinomial(100, 0.0d);
//     long var12 = var1.nextSecureLong(0L, 2L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("289bbda1dac2da7e66b565ebd4035d94c25b04fdbe21f0ef618db786cf385395db56ecb5d9fc29497e94cb3cda1435af0c52", "");
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.9999999987845877d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0L);
// 
//   }

  public void test303() {}
//   public void test303() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }
// 
// 
//     double var0 = org.apache.commons.math3.util.FastMath.random();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var0 == 0.29670596978174246d);
// 
//   }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-4523942956662907304L));

  }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test306() {}
//   public void test306() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     double var5 = var0.nextUniform(0.0d, 0.8414709839507452d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var7 = var0.nextHexString((-1));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.1716224627828515d);
// 
//   }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(0.8849970445005177d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9407428152797754d);

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(0.19051909067436468d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.7200614999929482d));

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(10.0d, 1.2985514841181043E-45d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test310() {}
//   public void test310() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     double var5 = var0.nextUniform(0.0d, 0.8414709839507452d, false);
//     var0.reSeedSecure();
//     var0.reSeedSecure(0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var11 = var0.nextLong(9223372036854775807L, 4L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.6740459835019736d);
// 
//   }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.9999999988073947d, 2.7182818172534526d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.7182818172534526d);

  }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    var0.setSeed(100);
    var0.clear();
    int var5 = var0.nextInt();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var9 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var0, 10, 904660695, 10);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1347491339));

  }

  public void test313() {}
//   public void test313() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(10L);
//     org.apache.commons.math3.random.RandomGenerator var3 = var0.getRandomGenerator();
//     var0.reSeedSecure();
//     int var7 = var0.nextSecureInt((-898785569), 1751072663);
//     java.util.Collection var8 = null;
//     java.lang.Object[] var10 = var0.nextSample(var8, 10);
// 
//   }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var2 = new java.lang.Object[] { (short)0};
    org.apache.commons.math3.exception.MathIllegalArgumentException var3 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var2);
    org.apache.commons.math3.exception.OutOfRangeException var7 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0, (java.lang.Number)10L, (java.lang.Number)0.0f);
    java.lang.Number var8 = var7.getLo();
    java.lang.Throwable[] var9 = var7.getSuppressed();
    var3.addSuppressed((java.lang.Throwable)var7);
    java.lang.Number var11 = var7.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 10L+ "'", var8.equals(10L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + 10L+ "'", var11.equals(10L));

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    long var3 = var1.nextLong(100L);
    var1.setSeed(0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 86L);

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.9856706438725751d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.679608344878513d);

  }

  public void test317() {}
//   public void test317() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     int var4 = var0.nextZipf(10, 10.0d);
//     long var6 = var0.nextPoisson(9.079986011887159E-5d);
//     var0.reSeedSecure();
//     double var11 = var0.nextUniform(0.2932229761817242d, 0.9999999989374517d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("02f7bc4360a8525bd4987a9d998124e802a7f265bc27fff7e441f950d132dffddc73174650b1923710568194444738263d1d", "");
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.32122971428658176d);
// 
//   }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.9999999960115731d, (java.lang.Number)(-0.2938234861534898d), (java.lang.Number)0.3526378652778325d);
    java.lang.String var4 = var3.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: 1 out of [-0.294, 0.353] range"+ "'", var4.equals("org.apache.commons.math3.exception.OutOfRangeException: 1 out of [-0.294, 0.353] range"));

  }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(0.9999999986927417d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 57.29577943818194d);

  }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(100, 671331466);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 671331466);

  }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(10.0d, 1338524259);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.POSITIVE_INFINITY);

  }

  public void test322() {}
//   public void test322() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextF(0.8849970445005177d, 100.0d);
//     int var6 = var0.nextPascal(10, 0.9999999984135708d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var0.nextUniform((-43.1284181946612d), Double.NaN);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotANumberException");
//     } catch (org.apache.commons.math3.exception.NotANumberException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.2548962947237182d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0);
// 
//   }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }


    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(-0.31967323691980976d), (java.lang.Number)1.4104867488175032d, var2);

  }

  public void test324() {}
//   public void test324() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextF(0.8849970445005177d, 100.0d);
//     var0.reSeed(3L);
//     double var8 = var0.nextGamma(6.012810737016811E-15d, 0.796031726960919d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var0.nextCauchy(1.5707474881759962d, (-0.43655076153977196d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.44221881485206377d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.0d);
// 
//   }

  public void test325() {}
//   public void test325() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     double var4 = var0.nextWeibull(1.5707474881759962d, 1.465042107535607E-5d);
//     double var7 = var0.nextCauchy(0.796031726960919d, 1.0038848218538872d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var0.nextExponential(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 2.2618522548172524E-5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2.6354517043715733d);
// 
//   }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed();
    int var4 = var0.nextZipf(10, 10.0d);
    org.apache.commons.math3.random.RandomGenerator var5 = var0.getRandomGenerator();
    var0.reSeedSecure(100L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var10 = var0.nextSecureLong(3L, 0L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test327() {}
//   public void test327() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextWeibull(1.3440585709080678E43d, 1.0d);
//     var1.reSeed();
//     org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.distribution.HypergeometricDistribution var10 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var6, 1, 0, 0);
//     int var11 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var10);
//     double var13 = var10.probability(0);
//     int var14 = var10.getSupportLowerBound();
//     double var15 = var10.getNumericalVariance();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == Double.NaN);
// 
//   }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution((-801113088), 0, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test329() {}
//   public void test329() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh((-43.1284181946612d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1));
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.5996555078851037d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.09893969565884042d);

  }

  public void test331() {}
//   public void test331() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     org.apache.commons.math3.random.Well19937c var5 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.distribution.HypergeometricDistribution var9 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var5, 1, 0, 0);
//     int var10 = var9.getPopulationSize();
//     int var11 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var9);
//     double var13 = var9.probability(100);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var15 = var9.sample(1043738272);
//       fail("Expected exception of type java.lang.OutOfMemoryError");
//     } catch (java.lang.OutOfMemoryError e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.0d);
// 
//   }

  public void test332() {}
//   public void test332() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     var1.reSeedSecure();
//     int var8 = var1.nextPascal(10, 1.0d);
//     var1.reSeed();
//     double var11 = var1.nextExponential(2.718281828459045d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var1.nextHypergeometric(356963565, 0, (-1406140309));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 4.145066075691088d);
// 
//   }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    double var4 = var1.nextWeibull(1.3440585709080678E43d, 1.0d);
    var1.reSeed();
    org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.distribution.HypergeometricDistribution var10 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var6, 1, 0, 0);
    int var11 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var10);
    int var12 = var10.getSampleSize();
    double var14 = var10.cumulativeProbability(1403217883);
    int var15 = var10.getPopulationSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1);

  }

  public void test334() {}
//   public void test334() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(1.2964727668339666d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var5 = var0.nextUniform(1.5707963267948966d, 2.718281828459045d);
    int var8 = var0.nextBinomial(100, 9.079985986933498E-5d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var11 = var0.nextInt((-1303859983), (-1303859983));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2.039860471086022d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);

  }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.9821617566081232d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9821617566081231d);

  }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(0.9999999988073947d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 57.29577944475107d);

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }


    int var2 = org.apache.commons.math3.util.FastMath.max((-1347491339), 1403217883);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1403217883);

  }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.distribution.HypergeometricDistribution var4 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var0, 1, 0, 0);
    int var5 = var4.getSupportUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(0.9999999958776927d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999999986258976d);

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = var0.nextChiSquare(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test342() {}
//   public void test342() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     double var4 = var0.nextWeibull(1.5707474881759962d, 1.465042107535607E-5d);
//     double var7 = var0.nextCauchy(0.796031726960919d, 1.0038848218538872d);
//     var0.reSeedSecure(1L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var0.nextUniform(1.3286227060069709d, 0.9832066969973899d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 6.8138948295212445E-6d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.47705074586547214d);
// 
//   }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(0.6913269815529459d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.827569446980059d);

  }

  public void test344() {}
//   public void test344() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(0.9999999982562285d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999999991281142d);

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    byte[] var2 = new byte[] { };
    var0.nextBytes(var2);
    org.apache.commons.math3.distribution.HypergeometricDistribution var7 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var0, 1, 0, 1);
    int var8 = var7.getSupportUpperBound();
    double var10 = var7.probability(356963565);
    int var12 = var7.inverseCumulativeProbability(0.1988847629558048d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.8008915432040549d, 0.9999999988073941d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.8008915434161261d);

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSecureAlgorithm("", "org.apache.commons.math3.exception.NotANumberException: NaN is not allowed");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }

  }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin((-0.7200614999929482d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.6594309067715061d));

  }

  public void test350() {}
//   public void test350() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log10((-1.5707963267948966d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(1.0680129189488523d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(0.436170481055685d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.4234057674389688d);

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test354() {}
//   public void test354() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh(6.012810737016811E-15d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)100, (java.lang.Number)0.9999999f, (java.lang.Number)0.8008915434161261d);

  }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp((-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.99999994f));

  }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(1.465042107535607E-5d, 1.5707474881759962d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.4650421075356071E-5d);

  }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder((-1.909033151689426d), 1.5707426748831026d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.3382904768063235d));

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs((-91603220));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 91603220);

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh((-1.7902952569832583E-9d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.7902952569832583E-9d));

  }

  public void test361() {}
//   public void test361() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextWeibull(1.3440585709080678E43d, 1.0d);
//     double var7 = var1.nextGamma(2.062677441918783d, 0.796031726960919d);
//     double var9 = var1.nextT(0.1904834217843172d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2.3625960167107d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-16.67872785720866d));
// 
//   }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var4 = var1.nextPascal((-24), (-0.7200614999929482d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test363() {}
//   public void test363() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextF(0.8849970445005177d, 100.0d);
//     var0.reSeed(3L);
//     double var8 = var0.nextGamma(6.012810737016811E-15d, 0.796031726960919d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var0.nextHypergeometric(1403217883, (-1), (-560611733));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.6020115698661984d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.0d);
// 
//   }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var5 = var0.nextUniform(1.5707963267948966d, 2.718281828459045d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var0.nextGaussian(0.5872236411115884d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2.039860471086022d);

  }

  public void test365() {}
//   public void test365() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     java.lang.String var6 = var1.nextSecureHexString(100);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var8 = var1.nextSecureHexString((-2));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.9999999986780761d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "9751bafaa54ee0228de1b20d25f914230f1acd0b1a0f23477c72c759c60e5f65eac79c878a72020b347c2c1d2f26fb77192e"+ "'", var6.equals("9751bafaa54ee0228de1b20d25f914230f1acd0b1a0f23477c72c759c60e5f65eac79c878a72020b347c2c1d2f26fb77192e"));
// 
//   }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians((-1.909033151689426d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.03331891402670484d));

  }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(2.1246841133521155d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0d);

  }

  public void test368() {}
//   public void test368() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     var1.reSeedSecure();
//     int var8 = var1.nextPascal(10, 1.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var10 = var1.nextSecureHexString((-24));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.999999998799211d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
// 
//   }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(1.4E-45f, 0.13834817027406507d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.8E-45f);

  }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(0.9999999989582015d, (-1.5965235428572633d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.9999999989582015d));

  }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    double var4 = var1.nextWeibull(1.3440585709080678E43d, 1.0d);
    var1.reSeed();
    org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.distribution.HypergeometricDistribution var10 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var6, 1, 0, 0);
    int var11 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var10);
    int[] var13 = var10.sample(1);
    double var16 = var10.cumulativeProbability(1, 10);
    double var18 = var10.probability(2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);

  }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }


    int var2 = org.apache.commons.math3.util.FastMath.min((-91603220), (-79669777));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-91603220));

  }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(0.9885362382515357d, 0.9999999986258976d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.1917650521719954E-7d);

  }

  public void test374() {}
//   public void test374() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     double var4 = var0.nextWeibull(1.5707474881759962d, 1.465042107535607E-5d);
//     java.util.Collection var5 = null;
//     java.lang.Object[] var7 = var0.nextSample(var5, (-898785569));
// 
//   }

  public void test375() {}
//   public void test375() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextWeibull(1.3440585709080678E43d, 1.0d);
//     var1.reSeed();
//     org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.distribution.HypergeometricDistribution var10 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var6, 1, 0, 0);
//     int var11 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var10);
//     int[] var13 = var10.sample(1);
//     double var16 = var10.cumulativeProbability(1, 10);
//     double var18 = var10.cumulativeProbability(1751072663);
//     double var20 = var10.upperCumulativeProbability(1751072663);
//     double var21 = var10.getNumericalVariance();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == Double.NaN);
// 
//   }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(0.19051909067436468d, 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.POSITIVE_INFINITY);

  }

  public void test378() {}
//   public void test378() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(2.3130252983208304d, 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(6.012810737016811E-15d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(356963565);
    int var2 = var1.nextInt();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 545144851);

  }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.9915677974790176d, var2, false);

  }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);

  }

  public void test385() {}
//   public void test385() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextF(0.8849970445005177d, 100.0d);
//     var0.reSeed(3L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("org.apache.commons.math3.exception.NotANumberException: NaN is not allowed", "");
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 6.8389243989400486d);
// 
//   }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.distribution.HypergeometricDistribution var4 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var0, 1, 0, 0);
    int var5 = var4.getPopulationSize();
    double var7 = var4.probability((-1303859983));
    int var8 = var4.getSupportUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);

  }

  public void test387() {}
//   public void test387() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     java.lang.String var6 = var1.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.RealDistribution var7 = null;
//     double var8 = var1.nextInversionDeviate(var7);
// 
//   }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(1.8769923069620795d, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.8769923069620795d);

  }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }


    double var1 = org.apache.commons.math3.util.FastMath.acos(0.9999999991281142d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.175849101483783E-5d);

  }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(0.9856706438725751d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.01443301276440699d));

  }

  public void test391() {}
//   public void test391() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     byte[] var2 = new byte[] { };
//     var0.nextBytes(var2);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var7 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var0, 1, 0, 1);
//     double var8 = var0.nextGaussian();
//     int var9 = var0.nextInt();
//     int[] var12 = new int[] { 0, 100};
//     org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(var12);
//     var0.setSeed(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.5855692499311639d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-534376165));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
// 
//   }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var2 = new java.lang.Object[] { (short)0};
    org.apache.commons.math3.exception.MathIllegalArgumentException var3 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var2);
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    java.lang.Object[] var10 = new java.lang.Object[] { (short)0};
    org.apache.commons.math3.exception.MathIllegalArgumentException var11 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var8, var10);
    org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException(var7, var10);
    org.apache.commons.math3.exception.MathInternalError var13 = new org.apache.commons.math3.exception.MathInternalError(var6, var10);
    org.apache.commons.math3.exception.NotFiniteNumberException var14 = new org.apache.commons.math3.exception.NotFiniteNumberException(var4, (java.lang.Number)(-1406140309), var10);
    var3.addSuppressed((java.lang.Throwable)var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb((-0.9999999f), (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.49999994f));

  }

  public void test394() {}
//   public void test394() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     var1.reSeedSecure();
//     int var8 = var1.nextPascal(10, 1.0d);
//     double var12 = var1.nextUniform(0.0d, 9.079986011887159E-5d, true);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var1.nextBeta(0.0d, 0.999999998809201d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.9999999987371946d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 3.830409393112305E-5d);
// 
//   }

  public void test395() {}
//   public void test395() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(1.0466614727344177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(0.8414709839507452d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6995216438466961d);

  }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }


    double var2 = org.apache.commons.math3.util.FastMath.max((-0.15589264946400347d), 0.6576685413083545d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.6576685413083545d);

  }

  public void test398() {}
//   public void test398() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     byte[] var2 = new byte[] { };
//     var0.nextBytes(var2);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var7 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var0, 1, 0, 1);
//     int var8 = var0.nextInt();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2050544884);
// 
//   }

  public void test399() {}
//   public void test399() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     long var6 = var1.nextPoisson(1.5707963267948966d);
//     int var9 = var1.nextBinomial(100, 0.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var1.nextSecureInt(10, (-341994742));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
// 
//   }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var3 = var1.nextInt((-801113088));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test401() {}
//   public void test401() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     byte[] var2 = new byte[] { };
//     var0.nextBytes(var2);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var7 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var0, 1, 0, 1);
//     double var8 = var0.nextGaussian();
//     int var9 = var0.nextInt();
//     org.apache.commons.math3.random.RandomDataImpl var10 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     java.util.Collection var11 = null;
//     java.lang.Object[] var13 = var10.nextSample(var11, 1);
// 
//   }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }


    int[] var2 = new int[] { 0, 100};
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var2);
    org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(var2);
    double var5 = var4.nextDouble();
    var4.setSeed(10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.1904834217843172d);

  }

  public void test403() {}
//   public void test403() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextF(0.8849970445005177d, 100.0d);
//     int var6 = var0.nextPascal(10, 0.9999999984135708d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var8 = var0.nextT((-0.0026387335345163234d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.026755553599122933d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0);
// 
//   }

  public void test404() {}
//   public void test404() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextWeibull(1.3440585709080678E43d, 1.0d);
//     var1.reSeed();
//     org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.distribution.HypergeometricDistribution var10 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var6, 1, 0, 0);
//     int var11 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var10);
//     double var13 = var10.probability(0);
//     int[] var15 = var10.sample(100);
//     org.apache.commons.math3.random.Well19937c var16 = new org.apache.commons.math3.random.Well19937c(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
// 
//   }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.0d, (-10.972839449353398d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1));
    double var2 = var1.nextGaussian();
    var1.clear();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.5996555078851037d));

  }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(0.4780173f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(57.29577944475107d, 1.2985514841181041E-45d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.3360154842351714E-46d);

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(0.47801733f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(0.37271443404257165d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.006505094043750115d);

  }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var5 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var2, (java.lang.Number)1.4210854715202004E-14d, false);
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.OutOfRangeException var11 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0, (java.lang.Number)10L, (java.lang.Number)0.0f);
    java.lang.Number var12 = var11.getLo();
    java.lang.Throwable[] var13 = var11.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var14 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)7.105427357601002E-15d, (java.lang.Object[])var13);
    org.apache.commons.math3.exception.MathIllegalStateException var15 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var5, var6, (java.lang.Object[])var13);
    org.apache.commons.math3.exception.NotFiniteNumberException var16 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)0.0d, (java.lang.Object[])var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 10L+ "'", var12.equals(10L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }


    int[] var2 = new int[] { 0, 100};
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var2);
    org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(var2);
    double var5 = var4.nextGaussian();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var9 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var4, 545144851, (-341994742), (-1283341984));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.4705756905309871d);

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(0.1904834217843172d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.6581901129564953d));

  }

  public void test414() {}
//   public void test414() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     int var4 = var0.nextZipf(10, 10.0d);
//     org.apache.commons.math3.random.RandomGenerator var5 = var0.getRandomGenerator();
//     double var8 = var0.nextWeibull(1.5707963267948966d, 0.2932229761817242d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var0.nextPascal(904660695, Double.NEGATIVE_INFINITY);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.4276148377125348d);
// 
//   }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4E-45f);

  }

  public void test416() {}
//   public void test416() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextF(0.8849970445005177d, 100.0d);
//     var0.reSeed(3L);
//     org.apache.commons.math3.random.RandomGenerator var6 = var0.getRandomGenerator();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.904396966604755d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
// 
//   }

  public void test417() {}
//   public void test417() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     long var6 = var1.nextPoisson(1.5707963267948966d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var9 = var1.nextZipf(91603220, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.9999999984579779d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3L);
// 
//   }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(0.9999999960115731d, 4.175849101483783E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9999999960115731d);

  }

  public void test419() {}
//   public void test419() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.sqrt((-0.43655076153977196d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0, (java.lang.Number)10L, (java.lang.Number)0.0f);
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.MathIllegalStateException var5 = new org.apache.commons.math3.exception.MathIllegalStateException();
    java.lang.Throwable[] var6 = var5.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.util.ExceptionContext var8 = var7.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan((-6.60702273463716E-6d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-6.6070227347332986E-6d));

  }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(5.626980147788368d, 2.062677441918783d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5.626980147788367d);

  }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.distribution.HypergeometricDistribution var4 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var0, 1, 0, 0);
    int var5 = var4.getPopulationSize();
    int var6 = var4.getNumberOfSuccesses();
    int var7 = var4.getSupportUpperBound();
    int var8 = var4.sample();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var10 = var4.sample((-1406140309));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);

  }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(1751072663, 671331466, (-22));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(1L);
    var1.clear();
    double var3 = var1.nextDouble();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.07277703352123166d);

  }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    var1.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var1.nextWeibull(2.3478644801478817E-5d, (-10.972839449353398d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.3320822313065658d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.3938674633426786d);

  }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    double var4 = var1.nextWeibull(1.3440585709080678E43d, 1.0d);
    var1.reSeed();
    org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.distribution.HypergeometricDistribution var10 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var6, 1, 0, 0);
    int var11 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var10);
    int[] var13 = var10.sample(1);
    double var16 = var10.cumulativeProbability(1, 10);
    int var17 = var10.getSampleSize();
    int var18 = var10.sample();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var20 = var10.sample(1631590754);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);

  }

  public void test429() {}
//   public void test429() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(10L);
//     org.apache.commons.math3.random.RandomGenerator var3 = var0.getRandomGenerator();
//     var0.reSeedSecure();
//     int var7 = var0.nextSecureInt((-898785569), 1751072663);
//     int var10 = var0.nextSecureInt((-1751072663), 0);
//     var0.reSeedSecure();
//     var0.reSeed(0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-853405806));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-989803513));
// 
//   }

  public void test430() {}
//   public void test430() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     long var6 = var1.nextPoisson(1.5707963267948966d);
//     int var9 = var1.nextBinomial(100, 0.0d);
//     long var12 = var1.nextSecureLong(0L, 2L);
//     var1.reSeed(3L);
//     java.util.Collection var15 = null;
//     java.lang.Object[] var17 = var1.nextSample(var15, 91603220);
// 
//   }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder((-0.31967323691980976d), 1.5707939862476776d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.31967323691980976d));

  }

  public void test432() {}
//   public void test432() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextF(0.9999999958776927d, 0.9999999960115731d);
//     int var7 = var0.nextHypergeometric(671331466, 0, 10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var10 = var0.nextSecureLong(52L, 52L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.020990726435064676d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
// 
//   }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(2.340547218914322E-6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.340547218916459E-6d);

  }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(10.0f, 0.9832066969973898d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.999999f);

  }

  public void test435() {}
//   public void test435() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     byte[] var2 = new byte[] { };
//     var0.nextBytes(var2);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var7 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var0, 1, 0, 1);
//     double var8 = var0.nextGaussian();
//     int var9 = var0.nextInt();
//     org.apache.commons.math3.random.RandomDataImpl var10 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var10.nextZipf((-560611733), 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-1.482962019497124d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 212895266);
// 
//   }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0, (java.lang.Number)10L, (java.lang.Number)0.0f);
    java.lang.Number var4 = var3.getLo();
    org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    java.lang.Number var6 = var3.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 10L+ "'", var4.equals(10L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 0.0f+ "'", var6.equals(0.0f));

  }

  public void test437() {}
//   public void test437() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextF(0.8849970445005177d, 100.0d);
//     var0.reSeed(3L);
//     var0.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.03213628727820503d);
// 
//   }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(1631590754, (-801113088));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1631590754);

  }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-0.7417982053570744d), (java.lang.Number)0.0f, true);

  }

  public void test440() {}
//   public void test440() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextWeibull(1.3440585709080678E43d, 1.0d);
//     double var7 = var1.nextBeta(100.0d, 0.9999999981579031d);
//     var1.reSeedSecure(0L);
//     double var11 = var1.nextExponential(0.8144772173080679d);
//     int var14 = var1.nextPascal(1751072663, 0.0d);
//     var1.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.9916667871985944d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 4.092710028155628d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 2147483647);
// 
//   }

  public void test441() {}
//   public void test441() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.pow(0.0d, (-853405806));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)1.4210854715202004E-14d, false);
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.OutOfRangeException var9 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0, (java.lang.Number)10L, (java.lang.Number)0.0f);
    java.lang.Number var10 = var9.getLo();
    java.lang.Throwable[] var11 = var9.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var12 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)4.048226960918503d, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, (java.lang.Object[])var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + 10L+ "'", var10.equals(10L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(377317007, (-1406140309), 307240327);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed();
    int var4 = var0.nextZipf(10, 10.0d);
    org.apache.commons.math3.random.RandomGenerator var5 = var0.getRandomGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var9 = var0.nextHypergeometric(0, 898785569, 2147483647);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(2.266399890451977E-47d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.266399890451977E-47d);

  }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    byte[] var2 = new byte[] { };
    var0.nextBytes(var2);
    org.apache.commons.math3.distribution.HypergeometricDistribution var7 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var0, 1, 0, 1);
    int var8 = var7.getSupportUpperBound();
    int var9 = var7.getNumberOfSuccesses();
    int var10 = var7.getSupportLowerBound();
    double var11 = var7.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);

  }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(0.4780173f, 5.960465E-8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.4780173f);

  }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow((-1.0423136260211314d), 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test449() {}
//   public void test449() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.exception.util.Localizable var4 = null;
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     java.lang.Object[] var7 = new java.lang.Object[] { (short)0};
//     org.apache.commons.math3.exception.MathIllegalArgumentException var8 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var5, var7);
//     org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException(var4, var7);
//     org.apache.commons.math3.exception.NotFiniteNumberException var10 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)10L, var7);
//     org.apache.commons.math3.exception.NotFiniteNumberException var11 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Number)0.2932229761817242d, var7);
//     org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var7);
//     java.lang.String var13 = var12.toString();
// 
//   }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }


    int var2 = org.apache.commons.math3.util.FastMath.min((-1073422946), (-1283341984));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1283341984));

  }

  public void test451() {}
//   public void test451() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextF(0.8849970445005177d, 100.0d);
//     var0.reSeed(3L);
//     double var8 = var0.nextGamma(6.012810737016811E-15d, 0.796031726960919d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var0.nextT((-0.2938234861534898d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.21471835644204576d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.0d);
// 
//   }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.08760316753657016d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.996165295854039d);

  }

  public void test453() {}
//   public void test453() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     double var5 = var0.nextUniform(0.0d, 0.8414709839507452d, false);
//     var0.reSeedSecure();
//     var0.reSeedSecure(0L);
//     org.apache.commons.math3.random.RandomGenerator var9 = var0.getRandomGenerator();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.7501337807872253d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
// 
//   }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution((-381930297), (-1073422946), 307240327);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test455() {}
//   public void test455() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextWeibull(1.3440585709080678E43d, 1.0d);
//     var1.reSeed();
//     org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.distribution.HypergeometricDistribution var10 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var6, 1, 0, 0);
//     int var11 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var10);
//     int var12 = var10.getSampleSize();
//     double var14 = var10.cumulativeProbability(1403217883);
//     double var15 = var10.getNumericalVariance();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == Double.NaN);
// 
//   }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    double var4 = var1.nextWeibull(1.3440585709080678E43d, 1.0d);
    var1.reSeed();
    org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.distribution.HypergeometricDistribution var10 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var6, 1, 0, 0);
    int var11 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var10);
    int var12 = var10.getSampleSize();
    double var14 = var10.upperCumulativeProbability((-898785569));
    int var15 = var10.getSampleSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);

  }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.45442853273944145d, 0.09893969565884042d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.46507456901531996d);

  }

  public void test458() {}
//   public void test458() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test459() {}
//   public void test459() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     long var6 = var1.nextPoisson(1.5707963267948966d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var9 = var1.nextInt(1211316230, 671331466);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1L);
// 
//   }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(1631590754);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeedSecure(3L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var2.nextUniform(0.6913269815529459d, 1.4210854715202004E-14d, true);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test461() {}
//   public void test461() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextWeibull(1.3440585709080678E43d, 1.0d);
//     double var7 = var1.nextBeta(100.0d, 0.9999999981579031d);
//     var1.reSeedSecure(0L);
//     var1.reSeedSecure();
//     double var13 = var1.nextUniform((-0.03331891402670484d), 1.5468551477579688d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.9712844823142752d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.1044641716017267d);
// 
//   }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(1.0f, 2.8E-45f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0f);

  }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(100L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 100L);

  }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(0.9999999f, 2.8E-45f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9999999f);

  }

  public void test465() {}
//   public void test465() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     java.lang.String var6 = var1.nextSecureHexString(100);
//     double var8 = var1.nextT(1.4104867488175032d);
//     java.util.Collection var9 = null;
//     java.lang.Object[] var11 = var1.nextSample(var9, 1631590754);
// 
//   }

  public void test466() {}
//   public void test466() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextWeibull(1.3440585709080678E43d, 1.0d);
//     int var7 = var1.nextZipf(33, 0.9915677974790176d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
// 
//   }

  public void test467() {}
//   public void test467() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextF(0.9999999958776927d, 0.9999999960115731d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var5 = var0.nextHexString((-341994742));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.8053528230970811d);
// 
//   }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(0.0d, 0.796031726960919d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.8561856667531293d, 0.19888476295580476d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0606466149299103d);

  }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(9.093286722815058d, 0.723033992730824d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.4914503190196489d);

  }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0.9407428152797754d);

  }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp((-0.8743406346512441d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.874340634651244d));

  }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    var1.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var1.nextGaussian(2.1246841133521155d, (-0.3382904768063235d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test474() {}
//   public void test474() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     byte[] var2 = new byte[] { };
//     var0.nextBytes(var2);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var7 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var0, 1, 0, 1);
//     double var8 = var0.nextGaussian();
//     int var9 = var0.nextInt();
//     org.apache.commons.math3.random.RandomDataGenerator var10 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
//     var10.reSeed(100L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var10.nextSecureInt(377317007, 10);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.001776079028603d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1171960311));
// 
//   }

  public void test475() {}
//   public void test475() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh(0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test476() {}
//   public void test476() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextWeibull(1.3440585709080678E43d, 1.0d);
//     double var7 = var1.nextBeta(100.0d, 0.9999999981579031d);
//     var1.reSeedSecure(0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var12 = var1.nextLong(10L, (-4523942956662907304L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.9932117564170156d);
// 
//   }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin((-0.12217097352722141d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.12247694862585845d));

  }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt((-0.08219903947746836d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.43479937809557295d));

  }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }


    int[] var2 = new int[] { 0, 100};
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var2);
    org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(var2);
    double var5 = var4.nextGaussian();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var9 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var4, 904660695, (-1406140309), (-1283341984));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.4705756905309871d);

  }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(1.0680129189488523d, (-1.5108247410718927d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9053695994376896d);

  }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum((-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0f));

  }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)2.0d);

  }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(0.87566465f, (-898785569));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(1.8002070710500197E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.80020707105002E-5d);

  }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(1.2039859390820599E-4d, 1.1044641716017267d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0901086384421757E-4d);

  }

  public void test488() {}
//   public void test488() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     int var4 = var0.nextZipf(10, 10.0d);
//     org.apache.commons.math3.random.RandomGenerator var5 = var0.getRandomGenerator();
//     var0.reSeedSecure(100L);
//     var0.reSeed(100L);
//     long var12 = var0.nextSecureLong(0L, 2L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1L);
// 
//   }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(898785569, (-1406140309));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 898785569);

  }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0, (java.lang.Number)10L, (java.lang.Number)0.0f);
    java.lang.Number var5 = var4.getLo();
    java.lang.Throwable[] var6 = var4.getSuppressed();
    org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.util.ExceptionContext var8 = var7.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var9 = var7.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 10L+ "'", var5.equals(10L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test491() {}
//   public void test491() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.9999999958776928d, (java.lang.Number)7.185312789079109d, false);
//     org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var4);
// 
//   }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)1.2039859390820599E-4d, (java.lang.Number)Double.NEGATIVE_INFINITY, (java.lang.Number)(-5.9250729133356295d));

  }

  public void test493() {}
//   public void test493() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.log((-0.08219903947746836d), 0.7116558561440108d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    double var4 = var1.nextWeibull(1.3440585709080678E43d, 1.0d);
    var1.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var1.nextF((-10.972839449353398d), 0.9999999983761798d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);

  }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    double var4 = var1.nextWeibull(1.3440585709080678E43d, 1.0d);
    var1.reSeed();
    org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.distribution.HypergeometricDistribution var10 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var6, 1, 0, 0);
    int var11 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var10);
    int[] var13 = var10.sample(1);
    double var16 = var10.cumulativeProbability(1, 10);
    int var17 = var10.getSampleSize();
    double var19 = var10.cumulativeProbability(545144851);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);

  }

  public void test496() {}
//   public void test496() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(1.5707939862476776d, 2.7182818172534526d);
//     java.util.Collection var6 = null;
//     java.lang.Object[] var8 = var1.nextSample(var6, (-2));
// 
//   }

  public void test497() {}
//   public void test497() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     double var5 = var0.nextUniform(0.0d, 0.8414709839507452d, false);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var0.nextUniform((-0.12217097352722141d), (-0.8287175427643352d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.22948509707121895d);
// 
//   }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }


    int var2 = org.apache.commons.math3.util.FastMath.min((-685508479), (-1295158278));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1295158278));

  }

  public void test499() {}
//   public void test499() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextWeibull(1.3440585709080678E43d, 1.0d);
//     double var7 = var1.nextBeta(100.0d, 0.9999999981579031d);
//     long var9 = var1.nextPoisson(2.340547218914322E-6d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var1.nextF(0.13834817027406507d, (-43.1284181946612d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.985125060470744d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0L);
// 
//   }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(-1295158278), (java.lang.Number)1.5468551477579688d, (java.lang.Number)(-1.5108247410718927d));

  }

}
