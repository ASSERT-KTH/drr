
import junit.framework.*;

public class RandoopTest2 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test1"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan((-30.58486541292743d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.5381120604411769d));

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test2"); }


    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)1.4264141427071622E-5d, (java.lang.Number)2.292658765776463d, var2);
    java.lang.Number var4 = var3.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 2.292658765776463d+ "'", var4.equals(2.292658765776463d));

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test3"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(2.2096435425874593E-28d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.8565555113582706E-30d);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test4"); }


    int[] var2 = new int[] { (-1), (-1)};
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var2);
    org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.random.RandomDataImpl var5 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var4);
    byte[] var6 = new byte[] { };
    var4.nextBytes(var6);
    var3.nextBytes(var6);
    org.apache.commons.math3.random.RandomDataGenerator var9 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var3);
    double var12 = var9.nextBeta(1.1996222517255549E-5d, 0.5855692499311639d);
    double var15 = var9.nextGaussian(0.6196668376344506d, 2.7182818172534526d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1.6887516602762443E-9d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == (-1.603102588302534d));

  }

  public void test5() {}
//   public void test5() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test5"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     boolean var1 = var0.nextBoolean();
//     var0.setSeed((-769587589));
//     double var4 = var0.nextGaussian();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.1738418540313411d);
// 
//   }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test6"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(0.0f, 0.43617046f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.43617046f);

  }

  public void test7() {}
//   public void test7() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test7"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.pow((-0.8051174925228636d), 0.4085624567274803d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test8"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0, (java.lang.Number)10L, (java.lang.Number)0.0f);
    java.lang.Number var4 = var3.getLo();
    java.lang.Throwable[] var5 = var3.getSuppressed();
    java.lang.Number var6 = var3.getHi();
    org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    java.lang.Object[] var9 = null;
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var8, var9);
    java.lang.Throwable[] var11 = var10.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 10L+ "'", var4.equals(10L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 0.0f+ "'", var6.equals(0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test9"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(0.9999999985607362d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1L);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test10"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)2.303458119613107d, (java.lang.Number)(byte)(-1), (java.lang.Number)0.9999999958776928d);
    java.lang.Number var4 = var3.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 2.303458119613107d+ "'", var4.equals(2.303458119613107d));

  }

  public void test11() {}
//   public void test11() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test11"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextF(0.8849970445005177d, 100.0d);
//     var0.reSeed(3L);
//     double var8 = var0.nextGamma(6.012810737016811E-15d, 0.796031726960919d);
//     double var10 = var0.nextT(100.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var0.nextUniform(0.9999999980892902d, Double.NaN);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotANumberException");
//     } catch (org.apache.commons.math3.exception.NotANumberException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.005724616432395839d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-1.5108247410718927d));
// 
//   }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test12"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(5.842999498835825E-5d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test13() {}
//   public void test13() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test13"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(2.2927265271769707E139d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test14"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(0.62119067f, 1631590754);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.POSITIVE_INFINITY);

  }

  public void test15() {}
//   public void test15() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test15"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     byte[] var2 = new byte[] { };
//     var0.nextBytes(var2);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var7 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var0, 1, 0, 1);
//     var7.reseedRandomGenerator(100L);
//     double var10 = var7.getNumericalVariance();
//     double var13 = var7.cumulativeProbability(100, 91603220);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.0d);
// 
//   }

  public void test16() {}
//   public void test16() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test16"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     long var6 = var1.nextPoisson(1.5707963267948966d);
//     int var9 = var1.nextBinomial(100, 0.0d);
//     long var12 = var1.nextSecureLong(0L, 2L);
//     int var15 = var1.nextSecureInt((-79669777), 10);
//     double var18 = var1.nextUniform(0.0d, 0.3320822313065658d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 2L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-67836054));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.057572048944108015d);
// 
//   }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test17"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos((-0.4589855811533775d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8965023857355163d);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test18"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign((-1.909033151689426d), 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.909033151689426d);

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test19"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(0.9999999981579032d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6931471796388969d);

  }

  public void test20() {}
//   public void test20() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test20"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextWeibull(1.3440585709080678E43d, 1.0d);
//     double var7 = var1.nextGamma(2.062677441918783d, 0.796031726960919d);
//     double var11 = var1.nextUniform((-1.0556578976664823d), 0.0d, true);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var1.nextHypergeometric((-1023), 307240327, (-1283341984));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.45358119127355506d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.263895188999869d));
// 
//   }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test21"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1406140309));
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var6 = var2.nextHypergeometric(605135783, 1403217883, 1295158278);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test22"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.9194974954056635d, 0.25373002333651473d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9194974954056635d);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test23"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.distribution.HypergeometricDistribution var4 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var0, 1, 0, 0);
    int var5 = var4.getPopulationSize();
    double var7 = var4.probability((-1303859983));
    int var8 = var4.getPopulationSize();
    double var9 = var4.getNumericalMean();
    int var10 = var4.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);

  }

  public void test24() {}
//   public void test24() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test24"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure(1L);
//     double var6 = var0.nextUniform((-1.5707963267948966d), 7.185312789079109d, false);
//     int var9 = var0.nextInt((-1347491339), (-1073422946));
//     var0.reSeedSecure(44L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 5.5850163452105575d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1247282530));
// 
//   }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test25"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)0.8849970445005177d, (java.lang.Number)4L, true);
    boolean var5 = var4.getBoundIsAllowed();
    boolean var6 = var4.getBoundIsAllowed();
    org.apache.commons.math3.exception.util.ExceptionContext var7 = var4.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test26"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(0.62119067f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test27"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)1.052068872575641d);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test28"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(9.079985986933498E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.04494641520883384d);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test29"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(2.220446049250313E-16d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6.0554544523933395E-6d);

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test30"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(0.99999998469691d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test31"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(2.3478644801478817E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test32"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, var1, (java.lang.Number)0.6913269815529459d, true);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test33"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(4.092710028155628d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.8140649547585508d));

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test34"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    double var4 = var1.nextWeibull(1.3440585709080678E43d, 1.0d);
    var1.reSeed();
    org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.distribution.HypergeometricDistribution var10 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var6, 1, 0, 0);
    int var11 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var10);
    int[] var13 = var10.sample(1);
    double var16 = var10.cumulativeProbability(1, 10);
    double var18 = var10.cumulativeProbability(1751072663);
    double var20 = var10.upperCumulativeProbability(1751072663);
    int var21 = var10.sample();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test35"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    byte[] var2 = new byte[] { };
    var0.nextBytes(var2);
    var0.setSeed(0L);
    org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
    double var9 = var6.nextCauchy(0.9999999958776927d, 0.9915677974790176d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var13 = var6.nextUniform(0.3320822313065658d, 0.0d, true);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.9503313336725001d);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test36"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.08760316753657016d, 0.8447319740526457d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.08760316753657017d);

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test37"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    var1.reSeed();
    var1.reSeedSecure((-763690238135674660L));

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test38"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(1.175201187489337d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7771211602578841d);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test39"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(byte)10);

  }

  public void test40() {}
//   public void test40() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test40"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.distribution.HypergeometricDistribution var4 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var0, 1, 0, 0);
//     int var5 = var4.getPopulationSize();
//     int var6 = var4.getNumberOfSuccesses();
//     int var7 = var4.getSupportUpperBound();
//     double var9 = var4.cumulativeProbability(0);
//     double var10 = var4.getNumericalVariance();
//     int var11 = var4.getSupportLowerBound();
//     double var13 = var4.upperCumulativeProbability(898785569);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.0d);
// 
//   }

  public void test41() {}
//   public void test41() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test41"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextWeibull(1.3440585709080678E43d, 1.0d);
//     double var7 = var1.nextBeta(100.0d, 0.9999999981579031d);
//     var1.reSeedSecure(0L);
//     double var11 = var1.nextExponential(0.8144772173080679d);
//     int var14 = var1.nextPascal(1751072663, 0.0d);
//     double var16 = var1.nextExponential(2.7182818172534526d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.9999864077917604d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.097166648439941d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 7.734074965267404d);
// 
//   }

  public void test42() {}
//   public void test42() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test42"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     var1.reSeedSecure();
//     int var8 = var1.nextPascal(10, 1.0d);
//     double var12 = var1.nextUniform(0.0d, 9.079986011887159E-5d, true);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var1.nextHypergeometric((-50691549), (-989803513), (-1247282530));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 3.700461323575864E-5d);
// 
//   }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test43"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)3.2528957538806926d, (java.lang.Number)0.99999994f, false);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.MathIllegalStateException var6 = new org.apache.commons.math3.exception.MathIllegalStateException();
    java.lang.Throwable[] var7 = var6.getSuppressed();
    org.apache.commons.math3.exception.util.ExceptionContext var8 = var6.getContext();
    java.lang.Throwable[] var9 = var6.getSuppressed();
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var5, (java.lang.Object[])var9);
    var4.addSuppressed((java.lang.Throwable)var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test44"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(7.105427357601027E-15d, 2.5775895463862826d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7.105427357601027E-15d);

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test45"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(0.4115570042965047d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.007183024784618457d);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test46"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)49L);

  }

  public void test47() {}
//   public void test47() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test47"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     long var6 = var1.nextPoisson(1.5707963267948966d);
//     int var9 = var1.nextSecureInt((-24), 898785569);
//     double var12 = var1.nextGaussian(0.37271443404257165d, 5.340988197617562E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 318035548);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.3730590522152938d);
// 
//   }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test48"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(0.8660577872728119d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1758879064437948d);

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test49"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(0.6913269815529459d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6913269815529459d);

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test50"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(6.0554544523933395E-6d, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6.62929611322474E-53d);

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test51"); }


    java.lang.Throwable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Object[] var2 = null;
    org.apache.commons.math3.exception.MathIllegalStateException var3 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var1, var2);

  }

  public void test52() {}
//   public void test52() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test52"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c((-1));
//     double var4 = var3.nextGaussian();
//     byte[] var5 = new byte[] { };
//     var3.nextBytes(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var3);
//     byte[] var10 = new byte[] { (byte)(-1), (byte)1};
//     var3.nextBytes(var10);
//     var1.nextBytes(var10);
//     org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var13);
//     double var17 = var14.nextWeibull(1.3440585709080678E43d, 1.0d);
//     var14.reSeed();
//     org.apache.commons.math3.random.Well19937c var19 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.distribution.HypergeometricDistribution var23 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var19, 1, 0, 0);
//     int var24 = var14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var23);
//     double var26 = var23.probability(0);
//     int[] var28 = var23.sample(100);
//     var1.setSeed(var28);
//     org.apache.commons.math3.random.Well19937c var30 = new org.apache.commons.math3.random.Well19937c(var28);
//     double var31 = var30.nextDouble();
//     var30.setSeed(7L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-0.5996555078851037d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 0.8660577872728119d);
// 
//   }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test53"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(9223372036854775807L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var3 = var1.nextLong((-1698941240313716601L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test54() {}
//   public void test54() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test54"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextF(0.8849970445005177d, 100.0d);
//     var0.reSeed(3L);
//     double var8 = var0.nextGamma(6.012810737016811E-15d, 0.796031726960919d);
//     var0.reSeed();
//     double var12 = var0.nextWeibull(0.9999999984961787d, 0.8900985606462235d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var15 = var0.nextLong(4418479070395385219L, 6L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.21524283963407723d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.4348537342654801d);
// 
//   }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test55"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(100.0f, 0.8537519891965641d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 99.99999f);

  }

  public void test56() {}
//   public void test56() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test56"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     long var6 = var1.nextPoisson(1.5707963267948966d);
//     int var9 = var1.nextBinomial(100, 0.0d);
//     double var12 = var1.nextWeibull(0.9999999984135708d, 0.9999999981579031d);
//     double var15 = var1.nextGaussian((-0.8608123678316708d), 0.1988847629558048d);
//     double var17 = var1.nextChiSquare(2.039860471086022d);
//     int var20 = var1.nextSecureInt((-1025814147), 33);
//     long var23 = var1.nextLong((-5290993314367314646L), 4L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.8794513578582717d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-1.285906978072985d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 2.8382704884193126d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == (-398862196));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == (-4484042485519284623L));
// 
//   }

  public void test57() {}
//   public void test57() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test57"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.distribution.HypergeometricDistribution var4 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var0, 1, 0, 0);
//     int var5 = var4.getPopulationSize();
//     int var6 = var4.getNumberOfSuccesses();
//     int var7 = var4.getSupportUpperBound();
//     double var9 = var4.cumulativeProbability(0);
//     double var10 = var4.getNumericalVariance();
//     double var12 = var4.cumulativeProbability((-22));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.0d);
// 
//   }

  public void test58() {}
//   public void test58() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test58"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(1.4376971476050446d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test59() {}
//   public void test59() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test59"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     long var4 = var1.nextSecureLong(2L, 52L);
//     org.apache.commons.math3.random.Well19937c var5 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.distribution.HypergeometricDistribution var9 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var5, 1, 0, 0);
//     int var10 = var9.getNumberOfSuccesses();
//     int var11 = var9.getSampleSize();
//     int var12 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 18L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
// 
//   }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test60"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.0d, 0.20154923380017717d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test61"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(1.4E-45f, (-5.9604645E-8f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-5.9604645E-8f));

  }

  public void test62() {}
//   public void test62() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test62"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.pow(0.0d, (-560611733));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test63"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.9E-324d);

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test64"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(1L);
    var1.clear();
    long var4 = var1.nextLong(3513799009476651814L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 671249688581541202L);

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test65"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(0.9916667871985944d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.003634231868860884d));

  }

  public void test66() {}
//   public void test66() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test66"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     int var4 = var0.nextZipf(10, 10.0d);
//     org.apache.commons.math3.random.RandomGenerator var5 = var0.getRandomGenerator();
//     long var7 = var0.nextPoisson(0.38949689393933223d);
//     var0.reSeed();
//     double var10 = var0.nextExponential(0.8414709842450103d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.5154424625902132d);
// 
//   }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test67"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var5 = var0.nextUniform(1.5707963267948966d, 2.718281828459045d);
    long var7 = var0.nextPoisson(0.8849970445005177d);
    var0.reSeedSecure((-1L));
    long var12 = var0.nextLong(4L, 10L);
    double var15 = var0.nextCauchy(0.048652408275159854d, 2.220446049250313E-16d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var17 = var0.nextHexString((-534376165));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2.039860471086022d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 7L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.04865240827515966d);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test68"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs((-67836054));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 67836054);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test69"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(0.9999999982562284d, 0.8414709839507452d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.871274682089143d);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test70"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0L);
    float var2 = var1.nextFloat();
    var1.clear();
    int var4 = var1.nextInt();
    float var5 = var1.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.74324155f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-118603794));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.5918164f);

  }

  public void test71() {}
//   public void test71() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test71"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(10L);
//     org.apache.commons.math3.random.RandomGenerator var3 = var0.getRandomGenerator();
//     var0.reSeedSecure();
//     java.util.Collection var5 = null;
//     java.lang.Object[] var7 = var0.nextSample(var5, (-1151128773));
// 
//   }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test72"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(-0.874340634651244d), (java.lang.Number)0.29389079350642466d, (java.lang.Number)0.9999999983533883d);
    java.lang.Number var4 = var3.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0.29389079350642466d+ "'", var4.equals(0.29389079350642466d));

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test73"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(6.4062789865185135d, 2.039860471086022d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.28669757326044687d);

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test74"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution((-788080321), (-1347491339), 1211316230);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test75() {}
//   public void test75() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test75"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     long var6 = var1.nextPoisson(1.5707963267948966d);
//     double var9 = var1.nextWeibull(0.672863877987592d, 0.0035657051620800614d);
//     long var12 = var1.nextSecureLong((-509399413869688601L), 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.9999999987555547d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.008195032123627492d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-206642078767006300L));
// 
//   }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test76"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeedSecure();
    var2.reSeedSecure(0L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var7 = var2.nextSecureHexString((-1));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test77() {}
//   public void test77() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test77"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextWeibull(1.3440585709080678E43d, 1.0d);
//     var1.reSeed();
//     org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.distribution.HypergeometricDistribution var10 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var6, 1, 0, 0);
//     int var11 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var10);
//     double var13 = var1.nextChiSquare(0.9999999983761798d);
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var17 = var1.nextSecureLong(44L, 18L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 6.352594687375102E-4d);
// 
//   }

  public void test78() {}
//   public void test78() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test78"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextWeibull(1.3440585709080678E43d, 1.0d);
//     var1.reSeed();
//     org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.distribution.HypergeometricDistribution var10 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var6, 1, 0, 0);
//     int var11 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var10);
//     int[] var13 = var10.sample(1);
//     double var16 = var10.cumulativeProbability(1, 10);
//     double var18 = var10.probability(0);
//     var10.reseedRandomGenerator(44L);
//     double var22 = var10.probability((-1151128773));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0.0d);
// 
//   }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test79"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(7.105429E-15f, 0.3227009648454902d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7.10543E-15f);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test80"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1));
    double var2 = var1.nextGaussian();
    byte[] var3 = new byte[] { };
    var1.nextBytes(var3);
    org.apache.commons.math3.random.RandomDataImpl var5 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    byte[] var8 = new byte[] { (byte)(-1), (byte)1};
    var1.nextBytes(var8);
    float var10 = var1.nextFloat();
    boolean var11 = var1.nextBoolean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.5996555078851037d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.48337555f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test81"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(732236354, 1631590754);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 732236354);

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test82"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0, (java.lang.Number)10L, (java.lang.Number)0.0f);
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.MathIllegalStateException var5 = new org.apache.commons.math3.exception.MathIllegalStateException();
    java.lang.Throwable[] var6 = var5.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, (java.lang.Object[])var6);
    java.lang.Number var8 = var3.getArgument();
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var13 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var9, (java.lang.Number)57.29577943818194d, (java.lang.Number)(-821915238), true);
    var3.addSuppressed((java.lang.Throwable)var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 0+ "'", var8.equals(0));

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test83"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(0, (-1023));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test84"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var5 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0, (java.lang.Number)10L, (java.lang.Number)0.0f);
    java.lang.Number var6 = var5.getLo();
    java.lang.Throwable[] var7 = var5.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var8 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)4.048226960918503d, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathIllegalArgumentException var9 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 10L+ "'", var6.equals(10L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test85"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    byte[] var2 = new byte[] { };
    var0.nextBytes(var2);
    org.apache.commons.math3.distribution.HypergeometricDistribution var7 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var0, 1, 0, 1);
    org.apache.commons.math3.random.RandomDataGenerator var8 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var11 = var8.nextZipf((-1295158278), 5.007220325508991E-5d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test86() {}
//   public void test86() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test86"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     int var4 = var0.nextZipf(10, 10.0d);
//     long var6 = var0.nextPoisson(9.079986011887159E-5d);
//     var0.reSeedSecure();
//     double var9 = var0.nextT(9.079986011887159E-5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.3407807929942171E154d);
// 
//   }

  public void test87() {}
//   public void test87() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test87"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var8 = var1.nextBinomial(0, 100.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.9999999987209941d);
// 
//   }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test88"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var3 = var0.nextZipf((-1907692685), 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test89"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(0.9831744835581396d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.007369401270603746d));

  }

  public void test90() {}
//   public void test90() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test90"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     long var4 = var1.nextSecureLong(50L, 4418479070395385219L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1424471569370799730L);
// 
//   }

  public void test91() {}
//   public void test91() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test91"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     int var4 = var0.nextZipf(10, 10.0d);
//     org.apache.commons.math3.random.RandomGenerator var5 = var0.getRandomGenerator();
//     var0.reSeedSecure(100L);
//     double var9 = var0.nextExponential(7.440151952041671E-44d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var0.nextSecureInt(288573454, (-880641009));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2.9915639312511122E-43d);
// 
//   }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test92"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(9223372036854775807L);
    var1.setSeed(1631590754);

  }

  public void test93() {}
//   public void test93() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test93"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(10L);
//     double var5 = var0.nextUniform(1.5707963267948966d, 2.718281828459045d);
//     double var8 = var0.nextCauchy(0.9999999960115731d, 1.8002070710500197E-5d);
//     var0.reSeed();
//     double var12 = var0.nextUniform(0.2883240816320676d, 0.8008915432040549d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("e1ef46863aee29532680eb50de7e13121033ff14b63da9df31c53f1609adaf601fb6a15fa05c8bb9f18d01b591a11788891f", "org.apache.commons.math3.exception.OutOfRangeException: 1 out of [-0.294, 0.353] range");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2.039860471086022d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.0001259640023823d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.6949538528364038d);
// 
//   }

  public void test94() {}
//   public void test94() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test94"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure(1L);
//     double var6 = var0.nextUniform((-1.5707963267948966d), 7.185312789079109d, false);
//     var0.reSeedSecure();
//     double var10 = var0.nextGaussian(1.5707963267948966d, 1.4737344297585606d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var12 = var0.nextHexString((-1247282530));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3.831826229139286d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.3007564603838562d);
// 
//   }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test95"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.lang.Object[] var4 = new java.lang.Object[] { (short)0};
    org.apache.commons.math3.exception.MathIllegalArgumentException var5 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, var4);
    org.apache.commons.math3.exception.MathIllegalStateException var6 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, var4);
    org.apache.commons.math3.exception.MathIllegalArgumentException var7 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test96() {}
//   public void test96() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test96"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     int var4 = var0.nextZipf(10, 10.0d);
//     org.apache.commons.math3.random.RandomGenerator var5 = var0.getRandomGenerator();
//     int var8 = var0.nextInt(3, 100);
//     long var11 = var0.nextLong((-419708803539342658L), 100L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var0.nextGamma((-0.4397350372266271d), 2.7182818172534526d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-46382945913239886L));
// 
//   }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test97"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(0.99999994f, 0.90662575f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.90662575f);

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test98"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    org.apache.commons.math3.random.RandomGenerator var3 = var2.getRandomGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test99() {}
//   public void test99() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test99"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     var1.reSeedSecure();
//     int var8 = var1.nextPascal(10, 1.0d);
//     double var12 = var1.nextUniform(0.0d, 9.079986011887159E-5d, true);
//     double var15 = var1.nextCauchy(0.0d, 9.079985986933498E-5d);
//     double var18 = var1.nextUniform(6.213663748637817d, 69.77567655475545d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 7.840298292407006E-5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 4.278618754219691E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 53.51919753236771d);
// 
//   }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test100"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.distribution.HypergeometricDistribution var4 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var0, 1, 0, 0);
    int var5 = var4.sample();
    int var6 = var4.getSampleSize();
    var4.reseedRandomGenerator(9223372036854775807L);
    var4.reseedRandomGenerator(0L);
    var4.reseedRandomGenerator(100L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test101"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.9999999958776928d, (java.lang.Number)0.49364015980407d, true);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test102"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(-0.49999994f), (java.lang.Number)2.0d, (java.lang.Number)(-177416670));

  }

  public void test103() {}
//   public void test103() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test103"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.distribution.HypergeometricDistribution var4 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var0, 1, 0, 0);
//     int var5 = var4.getPopulationSize();
//     int var6 = var4.getNumberOfSuccesses();
//     int var7 = var4.getSupportUpperBound();
//     double var9 = var4.cumulativeProbability(0);
//     double var10 = var4.getNumericalVariance();
//     var4.reseedRandomGenerator(49L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == Double.NaN);
// 
//   }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test104"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(0.43617046f, 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100.0f);

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test105"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeedSecure();
    org.apache.commons.math3.random.RandomGenerator var4 = var2.getRandomGenerator();
    double var7 = var2.nextWeibull(2.3478644801478817E-5d, 1.5468551477579688d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var10 = var2.nextBinomial((-67836054), 3.0475727868016896E-6d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test106"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(9.079986011887159E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9.07998602436399E-5d);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test107"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.12692642f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-3));

  }

  public void test108() {}
//   public void test108() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test108"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextF(0.8849970445005177d, 100.0d);
//     double var6 = var0.nextWeibull(0.9999999985607362d, 7.105427357601002E-15d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var0.nextGamma(0.827569446980059d, (-0.5996555078851037d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.2497593153078892d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.0528881669471588E-15d);
// 
//   }

  public void test109() {}
//   public void test109() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test109"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     byte[] var2 = new byte[] { };
//     var0.nextBytes(var2);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var7 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var0, 1, 0, 1);
//     double var8 = var0.nextGaussian();
//     int var9 = var0.nextInt();
//     org.apache.commons.math3.random.RandomDataGenerator var10 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
//     var10.reSeed(100L);
//     var10.reSeedSecure();
//     double var15 = var10.nextExponential(69.77567655475545d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.5653101806776353d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 680360965);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 133.282827416152d);
// 
//   }

  public void test110() {}
//   public void test110() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test110"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.distribution.HypergeometricDistribution var4 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var0, 1, 0, 0);
//     int var5 = var4.sample();
//     int var6 = var4.getSampleSize();
//     double var7 = var4.getNumericalVariance();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == Double.NaN);
// 
//   }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test111"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(1.0038848218538872d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8435636080687686d);

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test112"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(2.5309948459080432E-15d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.3627946509120594E-5d);

  }

  public void test113() {}
//   public void test113() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test113"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     boolean var1 = var0.nextBoolean();
//     var0.setSeed(0L);
//     int[] var6 = new int[] { 10, 100};
//     var0.setSeed(var6);
//     org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(var6);
//     org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(var6);
//     org.apache.commons.math3.random.Well19937c var10 = new org.apache.commons.math3.random.Well19937c(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
// 
//   }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test114"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians((-0.003634231868860884d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-6.342931189252921E-5d));

  }

  public void test115() {}
//   public void test115() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test115"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(10L);
//     double var5 = var0.nextUniform(1.5707963267948966d, 2.718281828459045d);
//     int var8 = var0.nextBinomial(100, 9.079985986933498E-5d);
//     int var11 = var0.nextSecureInt(27821159, 1817549287);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2.039860471086022d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 169393618);
// 
//   }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test116"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.distribution.HypergeometricDistribution var4 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var0, 1, 0, 0);
    int var5 = var4.getPopulationSize();
    int var6 = var4.getNumberOfSuccesses();
    int var7 = var4.getSupportUpperBound();
    int var8 = var4.sample();
    double var10 = var4.upperCumulativeProbability(34378987);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);

  }

  public void test117() {}
//   public void test117() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test117"); }
// 
// 
//     int[] var2 = new int[] { 0, 100};
//     org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var2);
//     org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(var2);
//     double var5 = var4.nextGaussian();
//     long var6 = var4.nextLong();
//     org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var7);
//     double var11 = var8.nextWeibull(1.3440585709080678E43d, 1.0d);
//     var8.reSeed();
//     org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.distribution.HypergeometricDistribution var17 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var13, 1, 0, 0);
//     int var18 = var8.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var17);
//     double var20 = var17.probability(0);
//     int[] var22 = var17.sample(100);
//     var4.setSeed(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.4705756905309871d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-4523942956662907304L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
// 
//   }

  public void test118() {}
//   public void test118() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test118"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1));
//     double var2 = var1.nextGaussian();
//     byte[] var3 = new byte[] { };
//     var1.nextBytes(var3);
//     org.apache.commons.math3.random.RandomDataImpl var5 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var5.reSeed((-1L));
//     var5.reSeed(0L);
//     double var12 = var5.nextF(1.0789421797795569d, 0.9999999983761798d);
//     java.util.Collection var13 = null;
//     java.lang.Object[] var15 = var5.nextSample(var13, (-560611733));
// 
//   }

  public void test119() {}
//   public void test119() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test119"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     int var4 = var0.nextZipf(10, 10.0d);
//     long var6 = var0.nextPoisson(9.079986011887159E-5d);
//     double var9 = var0.nextCauchy(1.175201187489337d, 0.7244640698111079d);
//     var0.reSeedSecure(7L);
//     double var14 = var0.nextUniform(0.0d, 0.9971376756813538d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-6.4852778786930765d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.9116423718590687d);
// 
//   }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test120"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-0.5996555078851037d), (java.lang.Number)2.220446049250313E-16d, false);
    boolean var4 = var3.getBoundIsAllowed();
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var3.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test121"); }


    org.apache.commons.math3.exception.NotANumberException var0 = new org.apache.commons.math3.exception.NotANumberException();
    java.lang.String var1 = var0.toString();
    org.apache.commons.math3.exception.NumberIsTooSmallException var5 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.9997453213737743d, (java.lang.Number)(short)0, true);
    var0.addSuppressed((java.lang.Throwable)var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "org.apache.commons.math3.exception.NotANumberException: NaN is not allowed"+ "'", var1.equals("org.apache.commons.math3.exception.NotANumberException: NaN is not allowed"));

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test122"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos((-1.7902952569832583E-9d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test123"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(0.87888706f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test124"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(57.29577940753794d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 57.29577940753794d);

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test125"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)5.960465E-8f, (java.lang.Number)0.49364015980407d, false);
    java.lang.Number var4 = var3.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0.49364015980407d+ "'", var4.equals(0.49364015980407d));

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test126"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.9999999991281142d, (java.lang.Number)14.078970893373334d, true);

  }

  public void test127() {}
//   public void test127() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test127"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextWeibull(1.3440585709080678E43d, 1.0d);
//     double var7 = var1.nextGamma(2.062677441918783d, 0.796031726960919d);
//     double var11 = var1.nextUniform((-1.0556578976664823d), 0.0d, true);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var13 = var1.nextHexString(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2.6256990601635386d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.2809732876009951d));
// 
//   }

  public void test128() {}
//   public void test128() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test128"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     var1.reSeedSecure();
//     var1.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
// 
//   }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test129"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0.6576685413083545d);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test130"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.distribution.HypergeometricDistribution var4 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var0, 1, 0, 0);
    int var5 = var4.getPopulationSize();
    double var7 = var4.probability((-1303859983));
    int var8 = var4.getPopulationSize();
    int var9 = var4.getPopulationSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);

  }

  public void test131() {}
//   public void test131() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test131"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextWeibull(1.3440585709080678E43d, 1.0d);
//     var1.reSeed();
//     org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.distribution.HypergeometricDistribution var10 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var6, 1, 0, 0);
//     int var11 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var10);
//     double var13 = var10.probability(0);
//     int var14 = var10.getSupportLowerBound();
//     var10.reseedRandomGenerator(0L);
//     int var17 = var10.getNumberOfSuccesses();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0);
// 
//   }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test132"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(7.10543E-15f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.105431E-15f);

  }

  public void test133() {}
//   public void test133() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test133"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     var1.reSeedSecure();
//     double var8 = var1.nextWeibull(0.827569446980059d, 3.95443798992998d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var1.nextPascal(0, (-1.7902952569832583E-9d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.9999999983598096d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 6.135646004281124d);
// 
//   }

  public void test134() {}
//   public void test134() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test134"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     byte[] var2 = new byte[] { };
//     var0.nextBytes(var2);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var7 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var0, 1, 0, 1);
//     double var8 = var0.nextGaussian();
//     int var9 = var0.nextInt();
//     org.apache.commons.math3.random.RandomDataGenerator var10 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
//     var10.reSeed(100L);
//     var10.reSeedSecure();
//     double var16 = var10.nextF(0.9999999989345962d, 0.8849970445005177d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var18 = var10.nextPoisson((-0.03331891402670484d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.17937623865178806d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 53124176);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.10067723915807407d);
// 
//   }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test135"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var3 = var0.nextGamma(3.0475727868016896E-6d, (-43.1284181946612d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test136() {}
//   public void test136() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test136"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     byte[] var2 = new byte[] { };
//     var0.nextBytes(var2);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var7 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var0, 1, 0, 1);
//     double var8 = var0.nextGaussian();
//     int var9 = var0.nextInt();
//     org.apache.commons.math3.random.RandomDataGenerator var10 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
//     var10.reSeed(100L);
//     double var14 = var10.nextT(2.7182818172534526d);
//     java.util.Collection var15 = null;
//     java.lang.Object[] var17 = var10.nextSample(var15, (-853405806));
// 
//   }

  public void test137() {}
//   public void test137() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test137"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     var1.reSeedSecure();
//     int var8 = var1.nextPascal(10, 1.0d);
//     double var12 = var1.nextUniform(0.0d, 9.079986011887159E-5d, true);
//     int var15 = var1.nextPascal(732236354, 0.9999999983416217d);
//     java.util.Collection var16 = null;
//     java.lang.Object[] var18 = var1.nextSample(var16, 904660695);
// 
//   }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test138"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs((-118603794));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 118603794);

  }

//  public void test139() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest2.test139"); }
//
//
//    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//    byte[] var2 = new byte[] { };
//    var0.nextBytes(var2);
//    org.apache.commons.math3.distribution.HypergeometricDistribution var7 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var0, 1, 0, 1);
//    int var8 = var7.getSupportUpperBound();
//    // The following exception was thrown during execution.
//    // This behavior will recorded for regression testing.
//    try {
//      int[] var10 = var7.sample(743997922);
//      fail("Expected exception of type java.lang.OutOfMemoryError");
//    } catch (java.lang.OutOfMemoryError e) {
//      // Expected exception.
//    }
//    
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var2);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var8 == 0);
//
//  }
//
  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test140"); }


    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.OutOfRangeException var6 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0, (java.lang.Number)10L, (java.lang.Number)0.0f);
    java.lang.Number var7 = var6.getLo();
    java.lang.Throwable[] var8 = var6.getSuppressed();
    org.apache.commons.math3.exception.MathInternalError var9 = new org.apache.commons.math3.exception.MathInternalError(var2, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NotFiniteNumberException var10 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-0.7200614999929482d), (java.lang.Object[])var8);
    org.apache.commons.math3.exception.util.Localizable var11 = null;
    org.apache.commons.math3.exception.util.Localizable var12 = null;
    org.apache.commons.math3.exception.util.Localizable var13 = null;
    org.apache.commons.math3.exception.util.Localizable var14 = null;
    java.lang.Object[] var16 = new java.lang.Object[] { (short)0};
    org.apache.commons.math3.exception.MathIllegalArgumentException var17 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var14, var16);
    org.apache.commons.math3.exception.MathIllegalStateException var18 = new org.apache.commons.math3.exception.MathIllegalStateException(var13, var16);
    org.apache.commons.math3.exception.MathInternalError var19 = new org.apache.commons.math3.exception.MathInternalError(var12, var16);
    org.apache.commons.math3.exception.MathIllegalStateException var20 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var10, var11, var16);
    org.apache.commons.math3.exception.NotFiniteNumberException var21 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)0.5448925059405476d, var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 10L+ "'", var7.equals(10L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test141() {}
//   public void test141() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test141"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     byte[] var2 = new byte[] { };
//     var0.nextBytes(var2);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var7 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var0, 1, 0, 1);
//     org.apache.commons.math3.random.RandomDataGenerator var8 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var11 = var8.nextF(0.8743406346512441d, 0.9821617566081232d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.27916007706505663d);
// 
//   }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test142"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(0.999999998714612d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 57.295779439435016d);

  }

  public void test143() {}
//   public void test143() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test143"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     int var4 = var0.nextZipf(10, 10.0d);
//     long var6 = var0.nextPoisson(9.079986011887159E-5d);
//     var0.reSeedSecure();
//     int var10 = var0.nextInt((-685508479), 2147483647);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var0.nextSecureInt(545144851, (-769587589));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-386510979));
// 
//   }

  public void test144() {}
//   public void test144() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test144"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     boolean var1 = var0.nextBoolean();
//     var0.setSeed(0L);
//     boolean var4 = var0.nextBoolean();
//     org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
//     org.apache.commons.math3.random.RandomDataImpl var6 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var9 = var6.nextBeta(0.9999999986927417d, 3.3655074191291803d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var6.nextGaussian(0.9821617566081232d, (-2.188538528552972d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.6557987711581932d);
// 
//   }

  public void test145() {}
//   public void test145() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test145"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextWeibull(1.3440585709080678E43d, 1.0d);
//     double var7 = var1.nextGamma(2.062677441918783d, 0.796031726960919d);
//     double var9 = var1.nextT(0.7316667507618113d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var1.nextZipf((-24), 0.9999999989920091d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 3.4272820172777934d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-0.9854545017574631d));
// 
//   }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test146"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(0.08760316753657016d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-2.434938122600249d));

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test147"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(0.7349819390826269d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2824792232443951d);

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test148"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(0.5897460277281191d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5328456964830538d);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test149"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(-0.5338066027349188d));
    java.lang.String var2 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "org.apache.commons.math3.exception.NotStrictlyPositiveException: -0.534 is smaller than, or equal to, the minimum (0)"+ "'", var2.equals("org.apache.commons.math3.exception.NotStrictlyPositiveException: -0.534 is smaller than, or equal to, the minimum (0)"));

  }

  public void test150() {}
//   public void test150() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test150"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextWeibull(1.3440585709080678E43d, 1.0d);
//     var1.reSeed();
//     org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.distribution.HypergeometricDistribution var10 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var6, 1, 0, 0);
//     int var11 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var10);
//     int[] var13 = var10.sample(1);
//     double var16 = var10.cumulativeProbability(1, 10);
//     double var18 = var10.probability(0);
//     double var19 = var10.getNumericalVariance();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == Double.NaN);
// 
//   }

  public void test151() {}
//   public void test151() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test151"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     byte[] var2 = new byte[] { };
//     var0.nextBytes(var2);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var7 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var0, 1, 0, 1);
//     double var8 = var0.nextGaussian();
//     int var9 = var0.nextInt();
//     org.apache.commons.math3.random.RandomDataImpl var10 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var10.nextZipf((-167697954), 0.5602649611267612d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.150796572543027d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 674053588);
// 
//   }

  public void test152() {}
//   public void test152() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test152"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     long var6 = var1.nextPoisson(1.5707963267948966d);
//     int var9 = var1.nextBinomial(100, 0.0d);
//     long var12 = var1.nextSecureLong(0L, 2L);
//     double var14 = var1.nextChiSquare(0.6576685413083545d);
//     double var17 = var1.nextWeibull(0.9999999987463872d, 1.6700035326960307E-4d);
//     double var20 = var1.nextGaussian(0.9999999985607362d, 0.4300078514249014d);
//     org.apache.commons.math3.random.Well19937c var21 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.distribution.HypergeometricDistribution var25 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var21, 1, 0, 0);
//     int var26 = var25.getPopulationSize();
//     int var27 = var25.getNumberOfSuccesses();
//     int var28 = var25.sample();
//     double var29 = var25.getNumericalMean();
//     int var30 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.3004463438044578d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 6.77299545788871E-5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1.9161943747359536d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 0);
// 
//   }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test153"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(6.012810737016811E-15d, 0.8537519891965641d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6.012810737016811E-15d);

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test154"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException(var0);
    java.lang.Number var2 = var1.getMin();
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var1.getContext();
    boolean var4 = var1.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0+ "'", var2.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test155() {}
//   public void test155() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test155"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     org.apache.commons.math3.random.RandomGenerator var2 = var1.getRandomGenerator();
//     java.util.Collection var3 = null;
//     java.lang.Object[] var5 = var1.nextSample(var3, (-177416670));
// 
//   }

  public void test156() {}
//   public void test156() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test156"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextWeibull(1.3440585709080678E43d, 1.0d);
//     double var7 = var1.nextBeta(100.0d, 0.9999999981579031d);
//     var1.reSeedSecure(0L);
//     var1.reSeedSecure();
//     double var12 = var1.nextChiSquare(0.1904834217843172d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var1.nextBinomial(898785569, 1.1044641716017267d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.9371719973704553d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 5.463691634562549E-8d);
// 
//   }

  public void test157() {}
//   public void test157() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test157"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure(1L);
//     double var5 = var0.nextF(4.117647632342092E-5d, 0.9915677974790176d);
//     double var9 = var0.nextUniform(0.1904834217843172d, 3.8513924447510477d, true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.9041920532061513E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.9602540472414514d);
// 
//   }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test158"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    double var4 = var1.nextWeibull(1.3440585709080678E43d, 1.0d);
    var1.reSeed();
    org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.distribution.HypergeometricDistribution var10 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var6, 1, 0, 0);
    int var11 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var10);
    int var12 = var10.getSampleSize();
    int var13 = var10.sample();
    int var15 = var10.inverseCumulativeProbability(0.9832066969973899d);
    int var16 = var10.sample();
    int var17 = var10.getSupportUpperBound();
    int var18 = var10.getNumberOfSuccesses();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);

  }

  public void test159() {}
//   public void test159() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test159"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     double var8 = var1.nextUniform(0.8561856667531293d, 0.9831744835581396d, false);
//     int var11 = var1.nextBinomial(100, 1.8002070710500197E-5d);
//     double var13 = var1.nextT(99.30685281944005d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.9011385256216409d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-0.09804043723700066d));
// 
//   }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test160"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(0.7501337807872253d, 0.9999999986780632d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.597981587282191E-9d);

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test161"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    byte[] var2 = new byte[] { };
    var0.nextBytes(var2);
    org.apache.commons.math3.distribution.HypergeometricDistribution var7 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var0, 1, 0, 1);
    int var8 = var7.getSupportUpperBound();
    int var9 = var7.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);

  }

  public void test162() {}
//   public void test162() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test162"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextWeibull(1.3440585709080678E43d, 1.0d);
//     var1.reSeed();
//     org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.distribution.HypergeometricDistribution var10 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var6, 1, 0, 0);
//     int var11 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var10);
//     int var12 = var10.getSampleSize();
//     double var13 = var10.getNumericalMean();
//     double var14 = var10.getNumericalMean();
//     double var17 = var10.cumulativeProbability(22, 671331466);
//     double var18 = var10.getNumericalVariance();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == Double.NaN);
// 
//   }

  public void test163() {}
//   public void test163() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test163"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh((-0.9875111568541143d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test164"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(0.02125483753856919d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0L);

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test165"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(0.87888706f, 9.999999f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.87888706f);

  }

  public void test166() {}
//   public void test166() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test166"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     java.lang.String var6 = var1.nextSecureHexString(100);
//     double var9 = var1.nextCauchy(0.1988847629558048d, 0.9999999981579032d);
//     long var12 = var1.nextLong(0L, 3L);
//     double var14 = var1.nextT(0.9999999984135708d);
//     int var17 = var1.nextInt(0, 118603794);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "fce241a73524aa6c9a7c8b4c42fe33eecbcff99a30d23adb9ef8ce8a01ce5d85a323fc24b9cb7f8e3d6ef7284272aa3183cc"+ "'", var6.equals("fce241a73524aa6c9a7c8b4c42fe33eecbcff99a30d23adb9ef8ce8a01ce5d85a323fc24b9cb7f8e3d6ef7284272aa3183cc"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 11.574019520309887d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-0.9136768129075086d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 101743994);
// 
//   }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test167"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(0.1836117523004867d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.6949317924930873d));

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test168"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(-40.76427490590991d));

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test169"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(7L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7L);

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test170"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    byte[] var2 = new byte[] { };
    var0.nextBytes(var2);
    var0.setSeed(0L);
    org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
    double var9 = var6.nextGamma(0.6198309595431225d, 3.4443949340539812d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.9140778930795641d);

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test171"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(86L);
    boolean var2 = var1.nextBoolean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test172() {}
//   public void test172() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test172"); }
// 
// 
//     int[] var2 = new int[] { 0, 100};
//     org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var2);
//     long var4 = var3.nextLong();
//     float var5 = var3.nextFloat();
//     org.apache.commons.math3.random.RandomDataImpl var6 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var3);
//     int var9 = var6.nextSecureInt(0, 34378987);
//     double var12 = var6.nextGaussian(0.996165295854039d, 0.9999999988073941d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 3513799009476651814L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.43617046f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 7543009);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-0.10186565969945094d));
// 
//   }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test173"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(0.90662575f, 545144851);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.POSITIVE_INFINITY);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test174"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(6.77299545788871E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test175"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(5.960465E-8f, 0.8414709842450103d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5.960466E-8f);

  }

  public void test176() {}
//   public void test176() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test176"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     long var6 = var1.nextPoisson(1.5707963267948966d);
//     int var9 = var1.nextBinomial(100, 0.0d);
//     double var12 = var1.nextWeibull(0.9999999984135708d, 0.9999999981579031d);
//     double var15 = var1.nextGaussian((-0.8608123678316708d), 0.1988847629558048d);
//     double var17 = var1.nextChiSquare(2.039860471086022d);
//     long var19 = var1.nextPoisson(1.4210854715202004E-14d);
//     double var21 = var1.nextT(0.8414709839507452d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.29190564092801613d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-0.6833849213534039d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.5305198106112067d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == (-0.8995907474892845d));
// 
//   }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test177"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs((-1347491339));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1347491339);

  }

  public void test178() {}
//   public void test178() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test178"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     byte[] var2 = new byte[] { };
//     var0.nextBytes(var2);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var7 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var0, 1, 0, 1);
//     double var8 = var0.nextGaussian();
//     int var9 = var0.nextInt();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var11 = var0.nextLong(0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-0.9654165604650801d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 462744578);
// 
//   }

  public void test179() {}
//   public void test179() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test179"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextF(0.8849970445005177d, 100.0d);
//     int var6 = var0.nextPascal(10, 0.9999999984135708d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var9 = var0.nextSecureLong(9223372036854775807L, 6L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.018536386329080275d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0);
// 
//   }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test180"); }


    int var2 = org.apache.commons.math3.util.FastMath.min((-1347491339), (-821915238));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1347491339));

  }

  public void test181() {}
//   public void test181() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test181"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     int var4 = var0.nextZipf(10, 10.0d);
//     long var6 = var0.nextPoisson(9.079986011887159E-5d);
//     var0.reSeedSecure();
//     double var11 = var0.nextUniform(0.2932229761817242d, 0.9999999989374517d, false);
//     var0.reSeed();
//     int var15 = var0.nextInt((-1303859983), (-685508479));
//     double var18 = var0.nextUniform((-0.9875111568541143d), 1.1996222517255549E-5d);
//     double var20 = var0.nextExponential(7.105427357601002E-15d);
//     long var23 = var0.nextLong((-2698994567720459831L), 671249688581541202L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.39931472745656715d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-890894017));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-0.6587999668540366d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 2.5292974858079915E-15d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 248426082839369258L);
// 
//   }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test182"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.OutOfRangeException var6 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0, (java.lang.Number)10L, (java.lang.Number)0.0f);
    java.lang.Number var7 = var6.getLo();
    java.lang.Throwable[] var8 = var6.getSuppressed();
    org.apache.commons.math3.exception.MathInternalError var9 = new org.apache.commons.math3.exception.MathInternalError(var2, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NotFiniteNumberException var10 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-0.7200614999929482d), (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var11 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 10L+ "'", var7.equals(10L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test183() {}
//   public void test183() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test183"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     java.lang.String var6 = var1.nextSecureHexString(100);
//     double var9 = var1.nextCauchy(0.1988847629558048d, 0.9999999981579032d);
//     org.apache.commons.math3.random.Well19937c var10 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var11 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var10);
//     byte[] var12 = new byte[] { };
//     var10.nextBytes(var12);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var17 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var10, 1, 0, 1);
//     int var18 = var17.getSupportUpperBound();
//     int var19 = var17.getNumberOfSuccesses();
//     int var20 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "045b09ff4a4c19064a86614648df2a98afffee368918d5ae9c892cc3c7b50ae317b240cf61246da96ac70bb765b5145a926d"+ "'", var6.equals("045b09ff4a4c19064a86614648df2a98afffee368918d5ae9c892cc3c7b50ae317b240cf61246da96ac70bb765b5145a926d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1.222250248371973d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0);
// 
//   }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test184"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var3 = var1.nextSecureHexString((-1449204054));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test185"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeedSecure();
    org.apache.commons.math3.random.RandomGenerator var4 = var2.getRandomGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var7 = var2.nextCauchy(0.02125483753856919d, (-1.222250248371973d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test186"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(7.10543E-15f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test187"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed();
    int var4 = var0.nextZipf(10, 10.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var7 = var0.nextUniform(0.9999999987555547d, 2.2663998904519776E-47d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test188"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.8414709839507452d, (java.lang.Number)1.0d, (java.lang.Number)100);
    java.lang.Number var4 = var3.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 100+ "'", var4.equals(100));

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test189"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(7.255724013837027d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.1109067796238987d);

  }

  public void test190() {}
//   public void test190() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test190"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c((-1));
//     double var4 = var3.nextGaussian();
//     byte[] var5 = new byte[] { };
//     var3.nextBytes(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var3);
//     byte[] var10 = new byte[] { (byte)(-1), (byte)1};
//     var3.nextBytes(var10);
//     var1.nextBytes(var10);
//     org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var13);
//     double var17 = var14.nextWeibull(1.3440585709080678E43d, 1.0d);
//     var14.reSeed();
//     org.apache.commons.math3.random.Well19937c var19 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.distribution.HypergeometricDistribution var23 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var19, 1, 0, 0);
//     int var24 = var14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var23);
//     double var26 = var23.probability(0);
//     int[] var28 = var23.sample(100);
//     var1.setSeed(var28);
//     org.apache.commons.math3.random.Well19937c var30 = new org.apache.commons.math3.random.Well19937c(var28);
//     org.apache.commons.math3.random.Well19937c var31 = new org.apache.commons.math3.random.Well19937c(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-0.5996555078851037d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
// 
//   }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test191"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    byte[] var2 = new byte[] { };
    var0.nextBytes(var2);
    org.apache.commons.math3.distribution.HypergeometricDistribution var7 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var0, 1, 0, 1);
    int var8 = var7.sample();
    int var9 = var7.getSupportUpperBound();
    double var11 = var7.cumulativeProbability((-769587589));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test192"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(0.8756646f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);

  }

  public void test193() {}
//   public void test193() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test193"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     boolean var1 = var0.nextBoolean();
//     var0.setSeed(0L);
//     boolean var4 = var0.nextBoolean();
//     org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
//     org.apache.commons.math3.random.RandomDataImpl var6 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var8 = var6.nextHexString((-560611733));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == true);
// 
//   }

  public void test194() {}
//   public void test194() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test194"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.pow(0.9194974954056635d, (-821915238));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test195"); }


    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    java.lang.Object[] var9 = new java.lang.Object[] { (short)0};
    org.apache.commons.math3.exception.MathIllegalArgumentException var10 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var7, var9);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException(var6, var9);
    org.apache.commons.math3.exception.NotFiniteNumberException var12 = new org.apache.commons.math3.exception.NotFiniteNumberException(var4, (java.lang.Number)(-43.1284181946612d), var9);
    org.apache.commons.math3.exception.NotFiniteNumberException var13 = new org.apache.commons.math3.exception.NotFiniteNumberException(var2, (java.lang.Number)2.1246841133521155d, var9);
    org.apache.commons.math3.exception.MathIllegalStateException var14 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, var9);
    org.apache.commons.math3.exception.NotFiniteNumberException var15 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-0.9124802270098076d), var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test196() {}
//   public void test196() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test196"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     int var4 = var0.nextZipf(10, 10.0d);
//     long var6 = var0.nextPoisson(9.079986011887159E-5d);
//     var0.reSeedSecure();
//     double var11 = var0.nextUniform(0.2932229761817242d, 0.9999999989374517d, false);
//     var0.reSeedSecure(52L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.9720433438628594d);
// 
//   }

  public void test197() {}
//   public void test197() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test197"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextF(0.9999999958776927d, 0.9999999960115731d);
//     double var5 = var0.nextChiSquare(0.9832066969973898d);
//     double var8 = var0.nextF(0.057572048944108015d, 0.3540943443210691d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var0.nextInt(1610766970, (-177416670));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 5.716448479989039d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.4261813095342731d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2.135928025786086E-9d);
// 
//   }

  public void test198() {}
//   public void test198() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test198"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     var1.reSeedSecure();
//     int var8 = var1.nextPascal(10, 1.0d);
//     var1.reSeed();
//     double var11 = var1.nextExponential(2.718281828459045d);
//     var1.reSeedSecure(0L);
//     double var15 = var1.nextChiSquare(3.4735920489312525E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.9999999982771463d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 4.464828729776398d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.9882111146929657E-9d);
// 
//   }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test199"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.14286661306191545d, 2.5292974858079915E-15d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9999999999999951d);

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test200"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(0.8374249820314493d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.371616790741472d);

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test201"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-9.345165350689458d), (java.lang.Number)0.9066258578518134d, true);

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test202"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.997364744862623d, var1, false);
    boolean var4 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test203"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(0.9999999983761798d, 1.2964727668339666d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9999999983761798d);

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test204"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1));
    byte[] var4 = new byte[] { (byte)1, (byte)10};
    var1.nextBytes(var4);
    double var6 = var1.nextDouble();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.07587422179227632d);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test205"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0L);
    float var2 = var1.nextFloat();
    var1.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var5 = var1.nextLong((-4523942956662907304L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.74324155f);

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test206"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(7L, 4007079952561314190L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7L);

  }

  public void test207() {}
//   public void test207() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test207"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     long var6 = var1.nextPoisson(1.5707963267948966d);
//     int var9 = var1.nextSecureInt((-24), 898785569);
//     long var11 = var1.nextPoisson(0.5149328744477741d);
//     org.apache.commons.math3.distribution.RealDistribution var12 = null;
//     double var13 = var1.nextInversionDeviate(var12);
// 
//   }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test208"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(1751072663, 2043750045);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2043750045);

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test209"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(5729.5779513082325d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.8203867151263053d));

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test210"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(3.4443949340539812d, (-1.6949317924930873d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-3.4443949340539812d));

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test211"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    java.lang.Object[] var7 = new java.lang.Object[] { (short)0};
    org.apache.commons.math3.exception.MathIllegalArgumentException var8 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var5, var7);
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException(var4, var7);
    org.apache.commons.math3.exception.NotFiniteNumberException var10 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)10L, var7);
    org.apache.commons.math3.exception.NotFiniteNumberException var11 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Number)0.2932229761817242d, var7);
    org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var7);
    org.apache.commons.math3.exception.util.ExceptionContext var13 = var12.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var14 = var12.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test212"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(2.7182818172534526d, 0.048652408275159854d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.7182818172534526d);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test213"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh((-0.16425008622791915d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.16575151689981996d));

  }

  public void test214() {}
//   public void test214() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test214"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextF(0.8849970445005177d, 100.0d);
//     var0.reSeed(3L);
//     double var8 = var0.nextGamma(6.012810737016811E-15d, 0.796031726960919d);
//     double var10 = var0.nextT(100.0d);
//     double var12 = var0.nextExponential(0.3967883861837536d);
//     double var16 = var0.nextUniform((-0.15589264946400347d), 0.14822362710183382d, false);
//     int var19 = var0.nextSecureInt((-381930297), 545144851);
//     double var21 = var0.nextChiSquare(0.8813735861775209d);
//     var0.reSeed((-2698994567720459831L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.129074006676293d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-1.5108247410718927d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1.0466614727344177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == (-0.08219903947746836d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 222283404);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.15492433788557564d);
// 
//   }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test215"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.9821617566081232d, (java.lang.Number)(-0.99999994f), false);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test216"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(0.9999999989993d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.841470984267216d);

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test217"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(1.0466614727344177d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test218() {}
//   public void test218() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test218"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.distribution.HypergeometricDistribution var4 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var0, 1, 0, 0);
//     int var5 = var4.getPopulationSize();
//     int var6 = var4.getNumberOfSuccesses();
//     double var7 = var4.getNumericalVariance();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == Double.NaN);
// 
//   }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test219"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(0.13834817027406507d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.1392376521428738d);

  }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test220"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(52L, 4418479070395385219L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 52L);

  }

  public void test221() {}
//   public void test221() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test221"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextF(0.9999999958776927d, 0.9999999960115731d);
//     double var5 = var0.nextChiSquare(0.9832066969973898d);
//     double var8 = var0.nextF(0.057572048944108015d, 0.3540943443210691d);
//     long var11 = var0.nextLong(10L, 13L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.43113198314052664d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.6455265031186466d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.01239866642544102d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 13L);
// 
//   }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test222"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(4.117647632342092E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0L);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test223"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var5 = var0.nextUniform(1.5707963267948966d, 2.718281828459045d);
    double var8 = var0.nextCauchy(0.9999999960115731d, 1.8002070710500197E-5d);
    var0.reSeed();
    var0.reSeedSecure();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2.039860471086022d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0001259640023823d);

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test224"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(6.213663748637817d, 0.5602649611267612d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.050749176243444216d);

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test225"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-0.002638733534516324d), var2, true);

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test226"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(356963565);
    float var2 = var1.nextFloat();
    double var3 = var1.nextGaussian();
    int var4 = var1.nextInt();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.12692642f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.7415817319349819d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1599392786));

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test227"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    var0.setSeed(100);
    var0.clear();
    int var5 = var0.nextInt();
    int var6 = var0.nextInt();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1347491339));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-749437760));

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test228"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor((-0.003634231868860884d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test229"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(0.9972958442280366d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.7109411006717328d);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test230"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(57.29577944485456d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 57.29577944485457d);

  }

  public void test231() {}
//   public void test231() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test231"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextWeibull(1.3440585709080678E43d, 1.0d);
//     double var7 = var1.nextBeta(100.0d, 0.9999999981579031d);
//     var1.reSeedSecure(0L);
//     double var11 = var1.nextExponential(0.8144772173080679d);
//     int var14 = var1.nextPascal(1751072663, 0.0d);
//     double var17 = var1.nextBeta(0.6576685413083545d, 0.9971376756813538d);
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var21 = var1.nextPermutation((-801113088), (-2));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.9968536156061855d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.6498623214019632d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.6821109832415712d);
// 
//   }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test232"); }


    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(-0.6594309067715061d), (java.lang.Number)(-1.7008680768487319d), var2);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test233"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(0.097166648439941d, 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.097166648439941d);

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test234"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees((-1.6581901129564953d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-95.00729510272842d));

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test235"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(356963565);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var3 = var1.nextLong((-2698994567720459831L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test236"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(2L);
    long var2 = var1.nextLong();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1538236582175553973L));

  }

  public void test237() {}
//   public void test237() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test237"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     double var4 = var0.nextWeibull(1.5707474881759962d, 1.465042107535607E-5d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var6 = var0.nextPoisson((-3.189942242201521d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 3.942371741452806E-6d);
// 
//   }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test238"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.9128649983517316d, 7.105427357601002E-15d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9128649983517316d);

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test239"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(-43.1284181946612d), (java.lang.Number)0.4705756905309871d, (java.lang.Number)2.7182818172534526d);
    java.lang.Number var4 = var3.getArgument();
    java.lang.Number var5 = var3.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (-43.1284181946612d)+ "'", var4.equals((-43.1284181946612d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 2.7182818172534526d+ "'", var5.equals(2.7182818172534526d));

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test240"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(57.295779439435016d, 0.3320822313065658d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.3320822313065658d);

  }

  public void test241() {}
//   public void test241() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test241"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     long var6 = var1.nextPoisson(1.5707963267948966d);
//     org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var7);
//     double var11 = var8.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.distribution.HypergeometricDistribution var16 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var12, 1, 0, 0);
//     int var17 = var16.getPopulationSize();
//     int var18 = var8.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var16);
//     int var19 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var16);
//     var1.reSeedSecure();
//     long var23 = var1.nextSecureLong(0L, 3513799009476651814L);
//     org.apache.commons.math3.random.Well19937c var24 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var25 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var24);
//     double var28 = var25.nextWeibull(1.3440585709080678E43d, 1.0d);
//     var25.reSeed();
//     org.apache.commons.math3.random.Well19937c var30 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.distribution.HypergeometricDistribution var34 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var30, 1, 0, 0);
//     int var35 = var25.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var34);
//     int var36 = var34.getSampleSize();
//     int var37 = var34.sample();
//     int var39 = var34.inverseCumulativeProbability(0.9832066969973899d);
//     int var40 = var34.sample();
//     int var41 = var34.sample();
//     int var42 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.9999999985444242d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 2488512171383906588L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 0);
// 
//   }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test242"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(1631590754);
    long var2 = var1.nextLong();
    int var3 = var1.nextInt();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-2698994567720459831L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1961706183);

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test243"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    org.apache.commons.math3.random.RandomGenerator var3 = var0.getRandomGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var6 = var0.nextBeta(0.1937576370046115d, (-0.8743406346512441d));
      fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
    } catch (org.apache.commons.math3.exception.NoBracketingException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test244"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0L);
    float var2 = var1.nextFloat();
    var1.setSeed(2L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.74324155f);

  }

  public void test245() {}
//   public void test245() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test245"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     long var6 = var1.nextPoisson(1.5707963267948966d);
//     var1.reSeedSecure();
//     double var10 = var1.nextUniform((-10.972839449353398d), 0.5403023070792384d);
//     double var13 = var1.nextCauchy(1.0318841600686934d, 7.105427357601027E-15d);
//     var1.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-9.291436070730358d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.0318841600686977d);
// 
//   }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test246"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    org.apache.commons.math3.random.RandomGenerator var3 = var0.getRandomGenerator();
    org.apache.commons.math3.random.RandomGenerator var4 = var0.getRandomGenerator();
    long var7 = var0.nextLong((-509399413869688601L), (-1L));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var10 = var0.nextInt(732236354, 288573454);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-419708803539342658L));

  }

  public void test247() {}
//   public void test247() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test247"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextWeibull(1.3440585709080678E43d, 1.0d);
//     var1.reSeed();
//     org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.distribution.HypergeometricDistribution var10 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var6, 1, 0, 0);
//     int var11 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var10);
//     int var12 = var10.getSampleSize();
//     double var13 = var10.getNumericalVariance();
//     int var14 = var10.getNumberOfSuccesses();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
// 
//   }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test248"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.9832066969973899d, (java.lang.Number)Double.NaN, false);
    boolean var5 = var4.getBoundIsAllowed();
    boolean var6 = var4.getBoundIsAllowed();
    boolean var7 = var4.getBoundIsAllowed();
    boolean var8 = var4.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test249"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)1424471569370799730L);

  }

  public void test250() {}
//   public void test250() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test250"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     var1.reSeedSecure();
//     int var8 = var1.nextPascal(10, 1.0d);
//     var1.reSeed();
//     var1.reSeed();
//     java.util.Collection var11 = null;
//     java.lang.Object[] var13 = var1.nextSample(var11, 0);
// 
//   }

  public void test251() {}
//   public void test251() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test251"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     double var4 = var0.nextWeibull(1.5707474881759962d, 1.465042107535607E-5d);
//     double var7 = var0.nextCauchy(0.796031726960919d, 1.0038848218538872d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var0.nextZipf((-749437760), 0.9971376756813538d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 6.805557667361937E-6d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 3.2217721793975675d);
// 
//   }

  public void test252() {}
//   public void test252() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test252"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)57.29577943818194d, (java.lang.Number)(-821915238), true);
//     java.lang.String var5 = var4.toString();
// 
//   }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test253"); }


    double var2 = org.apache.commons.math3.util.FastMath.min((-0.3382904768063235d), 1.3627946509120594E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.3382904768063235d));

  }

  public void test254() {}
//   public void test254() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test254"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     long var6 = var1.nextPoisson(1.5707963267948966d);
//     org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var7);
//     double var11 = var8.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.distribution.HypergeometricDistribution var16 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var12, 1, 0, 0);
//     int var17 = var16.getPopulationSize();
//     int var18 = var8.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var16);
//     int var19 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var16);
//     boolean var20 = var16.isSupportConnected();
//     double var22 = var16.upperCumulativeProbability((-1406140309));
//     double var24 = var16.probability(1043738272);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0.0d);
// 
//   }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test255"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(4.087815954995088d, 0.6755073021273506d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.6755073021273506d);

  }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test256"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(9.999999f, (-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-9.999999f));

  }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test257"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(9223372036854775807L);
    double var2 = var1.nextDouble();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.1081900069793682d);

  }

  public void test258() {}
//   public void test258() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test258"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     java.lang.String var6 = var1.nextSecureHexString(100);
//     double var9 = var1.nextCauchy(0.1988847629558048d, 0.9999999981579032d);
//     double var12 = var1.nextF(3.95443798992998d, 0.9856706438725751d);
//     var1.reSeed(86L);
//     org.apache.commons.math3.distribution.RealDistribution var15 = null;
//     double var16 = var1.nextInversionDeviate(var15);
// 
//   }

  public void test259() {}
//   public void test259() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test259"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     int var4 = var0.nextZipf(10, 10.0d);
//     long var6 = var0.nextPoisson(9.079986011887159E-5d);
//     var0.reSeedSecure();
//     int var10 = var0.nextInt((-685508479), 2147483647);
//     var0.reSeedSecure();
//     int var14 = var0.nextSecureInt((-1283341984), 904660695);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var16 = var0.nextPoisson(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1379907598);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 693356231);
// 
//   }

  public void test260() {}
//   public void test260() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test260"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     var1.reSeedSecure();
//     int var8 = var1.nextPascal(10, 1.0d);
//     var1.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("201b55a3979b58d28955f98e500f42c9e85c0253a098e78270d13d690201e0799e3adaaa82d089e629799017cbea418a5c7c", "org.apache.commons.math3.exception.OutOfRangeException: 0 out of [10, 0] range");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.9999999984180618d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
// 
//   }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test261"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(0.5448925059405476d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1L);

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test262"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0, (java.lang.Number)10L, (java.lang.Number)0.0f);
    java.lang.Number var4 = var3.getLo();
    java.lang.Throwable[] var5 = var3.getSuppressed();
    java.lang.Number var6 = var3.getHi();
    org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    java.lang.Object[] var9 = null;
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var8, var9);
    java.lang.Number var11 = var3.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 10L+ "'", var4.equals(10L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 0.0f+ "'", var6.equals(0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + 10L+ "'", var11.equals(10L));

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test263"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(545144851);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 545144851);

  }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test264"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1((-0.6833849213534039d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.49509496725094293d));

  }

  public void test265() {}
//   public void test265() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test265"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     var1.reSeedSecure();
//     int var8 = var1.nextPascal(10, 1.0d);
//     var1.reSeed();
//     double var12 = var1.nextGaussian((-0.0026387335345163234d), 0.30391978507586603d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-0.13405018287357692d));
// 
//   }

  public void test266() {}
//   public void test266() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test266"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     int var4 = var0.nextZipf(10, 10.0d);
//     java.util.Collection var5 = null;
//     java.lang.Object[] var7 = var0.nextSample(var5, (-1247282530));
// 
//   }

  public void test267() {}
//   public void test267() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test267"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     byte[] var2 = new byte[] { };
//     var0.nextBytes(var2);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var7 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var0, 1, 0, 1);
//     double var8 = var0.nextGaussian();
//     int var9 = var0.nextInt();
//     org.apache.commons.math3.random.RandomDataImpl var10 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     org.apache.commons.math3.random.RandomDataImpl var11 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     var11.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-0.8111640143836467d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1013344440);
// 
//   }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test268"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.10067723915807407d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test269"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(1.4914503190196489d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4914503190196489d);

  }

  public void test270() {}
//   public void test270() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test270"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1406140309));
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var5 = var2.nextSecureInt(0, 118603794);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 75123425);
// 
//   }

  public void test271() {}
//   public void test271() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test271"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     int var4 = var0.nextZipf(10, 10.0d);
//     org.apache.commons.math3.random.RandomGenerator var5 = var0.getRandomGenerator();
//     int var8 = var0.nextInt(3, 100);
//     long var11 = var0.nextLong((-419708803539342658L), 100L);
//     double var14 = var0.nextCauchy(0.6576685413083545d, 1.2964727668339666d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-68267839203543167L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.615686678197821d);
// 
//   }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test272"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(896015843);

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test273"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.9194974954056635d, 0.389036998381009d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.14142349864364545d);

  }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test274"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.9602540472414514d, (java.lang.Number)0.9999999983416217d, false);

  }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test275"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(0.9407428152797754d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9407428152797755d);

  }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test276"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(-1.5108247410718927d));
    org.apache.commons.math3.exception.OutOfRangeException var5 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0, (java.lang.Number)10L, (java.lang.Number)0.0f);
    java.lang.Number var6 = var5.getLo();
    java.lang.Throwable[] var7 = var5.getSuppressed();
    java.lang.Number var8 = var5.getHi();
    var1.addSuppressed((java.lang.Throwable)var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 10L+ "'", var6.equals(10L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 0.0f+ "'", var8.equals(0.0f));

  }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test277"); }


    int[] var2 = new int[] { (-1), (-1)};
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var2);
    org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.random.RandomDataImpl var5 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var4);
    byte[] var6 = new byte[] { };
    var4.nextBytes(var6);
    var3.nextBytes(var6);
    org.apache.commons.math3.random.RandomDataGenerator var9 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var3);
    double var12 = var9.nextBeta(1.1996222517255549E-5d, 0.5855692499311639d);
    double var14 = var9.nextT(2.2284072655256315d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var17 = var9.nextCauchy((-0.1687358924107422d), (-1.0444823775572407d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1.6887516602762443E-9d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == (-0.5338066027349188d));

  }

  public void test278() {}
//   public void test278() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test278"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextWeibull(1.3440585709080678E43d, 1.0d);
//     var1.reSeed();
//     var1.reSeedSecure();
//     long var9 = var1.nextSecureLong((-5290993314367314646L), 44L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-5087448622803391531L));
// 
//   }

  public void test279() {}
//   public void test279() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test279"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.distribution.HypergeometricDistribution var4 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var0, 1, 0, 0);
//     int var5 = var4.sample();
//     int var6 = var4.getNumberOfSuccesses();
//     double var7 = var4.getNumericalVariance();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == Double.NaN);
// 
//   }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test280"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution((-377950801), 1043738272, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test281"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var5 = var0.nextUniform(1.5707963267948966d, 2.718281828459045d);
    long var7 = var0.nextPoisson(0.8849970445005177d);
    var0.reSeedSecure((-1L));
    long var12 = var0.nextLong(4L, 10L);
    double var15 = var0.nextCauchy(0.048652408275159854d, 2.220446049250313E-16d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var18 = var0.nextZipf((-398862196), 0.14822362710183382d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2.039860471086022d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 7L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.04865240827515966d);

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test282"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed();
    int var4 = var0.nextZipf(10, 10.0d);
    org.apache.commons.math3.random.RandomGenerator var5 = var0.getRandomGenerator();
    var0.reSeedSecure(100L);
    var0.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var11 = var0.nextUniform(2.1246841133521155d, (-0.002638733534516324d));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test283() {}
//   public void test283() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test283"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(1.5707939862476776d, 2.7182818172534526d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var8 = var1.nextGamma(3.2528957538806926d, (-9.345165350689458d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.8141834144709754d);
// 
//   }

  public void test284() {}
//   public void test284() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test284"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextF(0.8849970445005177d, 100.0d);
//     double var6 = var0.nextWeibull(0.9999999985607362d, 7.105427357601002E-15d);
//     double var8 = var0.nextT(1.2985514841181041E-45d);
//     var0.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.08230836732743194d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 6.394270465074144E-16d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2.2927265271769966E139d);
// 
//   }

  public void test285() {}
//   public void test285() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test285"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     byte[] var2 = new byte[] { };
//     var0.nextBytes(var2);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var7 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var0, 1, 0, 1);
//     double var8 = var0.nextGaussian();
//     int var9 = var0.nextInt();
//     org.apache.commons.math3.random.RandomDataGenerator var10 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
//     int var11 = var0.nextInt();
//     var0.clear();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.1410852497519727d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1298535816));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-861659744));
// 
//   }

  public void test286() {}
//   public void test286() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test286"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     long var6 = var1.nextPoisson(1.5707963267948966d);
//     int var9 = var1.nextBinomial(100, 0.0d);
//     long var12 = var1.nextSecureLong(0L, 2L);
//     double var14 = var1.nextChiSquare(0.6576685413083545d);
//     double var17 = var1.nextF(0.9062154450702296d, 221.80908805818223d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 2L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 8.136203647204195E-5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.00825003005254576d);
// 
//   }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test287"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)1.4210854715202004E-14d, false);
    java.lang.String var4 = var3.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: null is smaller than, or equal to, the minimum (0)"+ "'", var4.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: null is smaller than, or equal to, the minimum (0)"));

  }

  public void test288() {}
//   public void test288() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test288"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure(1L);
//     double var6 = var0.nextUniform((-1.5707963267948966d), 7.185312789079109d, false);
//     var0.reSeedSecure();
//     double var10 = var0.nextGaussian(1.5707963267948966d, 1.4737344297585606d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("hi!", "hi!");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.254515113261555d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.056504261147173d);
// 
//   }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test289"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(0.62119067f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);

  }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test290"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(2.292658765776463d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.1358880972502168d));

  }

  public void test291() {}
//   public void test291() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test291"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     java.lang.String var6 = var1.nextSecureHexString(100);
//     double var9 = var1.nextCauchy(0.1988847629558048d, 0.9999999981579032d);
//     long var12 = var1.nextLong(0L, 3L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var14 = var1.nextHexString(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "0b3c9150f32199b866c6bc1bd42d603ab9d8bb98c861bdae4c394f1fe1ddb4cd3c0b4a8bb8de0d74c5736fdde0d41a078c05"+ "'", var6.equals("0b3c9150f32199b866c6bc1bd42d603ab9d8bb98c861bdae4c394f1fe1ddb4cd3c0b4a8bb8de0d74c5736fdde0d41a078c05"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-0.5969617650085524d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 3L);
// 
//   }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test292"); }


    double var1 = org.apache.commons.math3.util.FastMath.acos(7.105427357601027E-15d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5707963267948895d);

  }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test293"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var5 = var0.nextUniform(1.5707963267948966d, 2.718281828459045d);
    var0.reSeed();
    var0.reSeedSecure();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2.039860471086022d);

  }

  public void test294() {}
//   public void test294() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test294"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     long var6 = var1.nextPoisson(1.5707963267948966d);
//     double var9 = var1.nextF(2.7526098571399982E-6d, 57.29577940753794d);
//     var1.reSeedSecure((-68267839203543167L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.9999999983616868d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.4369701115806796E-9d);
// 
//   }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test295"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)5.007220325508991E-5d, (java.lang.Number)2.828379142292715d, true);
    boolean var5 = var4.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test296"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(2.7182818176173766d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.218282903724919d);

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test297"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan((-0.703572788552714d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.6131197864658187d));

  }

  public void test298() {}
//   public void test298() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test298"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(10L);
//     org.apache.commons.math3.random.RandomGenerator var3 = var0.getRandomGenerator();
//     var0.reSeedSecure();
//     int var7 = var0.nextSecureInt((-898785569), 1751072663);
//     int var10 = var0.nextSecureInt((-1751072663), 0);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var0.nextBinomial((-1303859983), 0.009036285118124106d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 213042080);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-1005482336));
// 
//   }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test299"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(0.6101403405599028d, 2.1109067796238987d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.6101403405599028d);

  }

  public void test300() {}
//   public void test300() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test300"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     int var4 = var0.nextZipf(10, 10.0d);
//     long var6 = var0.nextPoisson(9.079986011887159E-5d);
//     double var9 = var0.nextCauchy(1.175201187489337d, 0.7244640698111079d);
//     long var12 = var0.nextLong((-4484042485519284623L), 1424471569370799730L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.7353239281435382d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-506882068182701169L));
// 
//   }

  public void test301() {}
//   public void test301() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test301"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     long var6 = var1.nextPoisson(1.5707963267948966d);
//     double var8 = var1.nextT(2.062677441918783d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.9999999989200603d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-4.592293384857122d));
// 
//   }

  public void test302() {}
//   public void test302() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test302"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     long var6 = var1.nextPoisson(1.5707963267948966d);
//     int var9 = var1.nextBinomial(100, 0.0d);
//     double var11 = var1.nextExponential(0.7501337807872253d);
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var1.nextPascal(169393618, (-1.7008680768487319d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 4L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.03258587260595691d);
// 
//   }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test303"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(44L);
    long var3 = var1.nextLong(4L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1L);

  }

  public void test304() {}
//   public void test304() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test304"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextWeibull(1.3440585709080678E43d, 1.0d);
//     double var7 = var1.nextGamma(2.062677441918783d, 0.796031726960919d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("org.apache.commons.math3.exception.NotStrictlyPositiveException: -0.534 is smaller than, or equal to, the minimum (0)", "5ccf861b74a0084635168f2c65d888398476b44fa3ef284cff9176591ab3a4a794de87460339aef76bb1a3ab7baf01c6c881");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.8620103594078588d);
// 
//   }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test305"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)2.718281828459045d, var1, true);
    java.lang.Number var4 = var3.getMax();
    boolean var5 = var3.getBoundIsAllowed();
    boolean var6 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test306() {}
//   public void test306() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test306"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextWeibull(1.3440585709080678E43d, 1.0d);
//     var1.reSeed();
//     org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.distribution.HypergeometricDistribution var10 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var6, 1, 0, 0);
//     int var11 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var10);
//     double var13 = var10.probability(0);
//     int[] var15 = var10.sample(100);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var17 = var10.sample(2050544884);
//       fail("Expected exception of type java.lang.OutOfMemoryError");
//     } catch (java.lang.OutOfMemoryError e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
// 
//   }

  public void test307() {}
//   public void test307() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test307"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextWeibull(1.3440585709080678E43d, 1.0d);
//     var1.reSeed();
//     org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.distribution.HypergeometricDistribution var10 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var6, 1, 0, 0);
//     int var11 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var10);
//     double var13 = var10.probability(0);
//     int var14 = var10.sample();
//     boolean var15 = var10.isSupportConnected();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
// 
//   }

  public void test308() {}
//   public void test308() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test308"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextWeibull(1.3440585709080678E43d, 1.0d);
//     var1.reSeed();
//     org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.distribution.HypergeometricDistribution var10 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var6, 1, 0, 0);
//     int var11 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var10);
//     int[] var13 = var10.sample(1);
//     double var16 = var10.cumulativeProbability(1, 10);
//     double var18 = var10.probability(0);
//     var10.reseedRandomGenerator(44L);
//     int var21 = var10.getSampleSize();
//     boolean var22 = var10.isSupportConnected();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == true);
// 
//   }

  public void test309() {}
//   public void test309() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test309"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     java.lang.String var6 = var1.nextSecureHexString(100);
//     double var9 = var1.nextCauchy(0.1988847629558048d, 0.9999999981579032d);
//     var1.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.9999999982061611d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "6ec3ea6169909d14e37a3a6765eea8a54393dc36dcbde6779f37ba44934318bf894fc314ab7f35d17fa4cc7faa74818db75b"+ "'", var6.equals("6ec3ea6169909d14e37a3a6765eea8a54393dc36dcbde6779f37ba44934318bf894fc314ab7f35d17fa4cc7faa74818db75b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-0.9984669418116945d));
// 
//   }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test310"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-0.5996555078851037d), (java.lang.Number)2.220446049250313E-16d, false);
    boolean var4 = var3.getBoundIsAllowed();
    java.lang.String var5 = var3.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: -0.6 is larger than, or equal to, the maximum (0)"+ "'", var5.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: -0.6 is larger than, or equal to, the maximum (0)"));

  }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test311"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(1295158278);

  }

  public void test312() {}
//   public void test312() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test312"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh((-1.013910152495272d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test313"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    boolean var2 = var1.nextBoolean();
    var1.clear();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    int var7 = var4.nextZipf(10, 1.9503313336725001d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);

  }

  public void test314() {}
//   public void test314() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test314"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextBeta(1.3440585709080678E43d, 2.7182818176173766d);
//     long var6 = var1.nextPoisson(1.5707963267948966d);
//     var1.reSeedSecure();
//     double var10 = var1.nextUniform((-10.972839449353398d), 0.5403023070792384d);
//     double var13 = var1.nextCauchy(1.0318841600686934d, 7.105427357601027E-15d);
//     double var16 = var1.nextGaussian(0.0d, 0.9999999989993d);
//     double var19 = var1.nextGaussian(0.9999999989920091d, 0.5329332910170664d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 4L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-10.914047604432712d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.0318841600687003d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.5568960043042961d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.6892752973922996d);
// 
//   }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test315"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0, (java.lang.Number)10L, (java.lang.Number)0.0f);
    java.lang.Number var4 = var3.getLo();
    java.lang.Throwable[] var5 = var3.getSuppressed();
    java.lang.Number var6 = var3.getArgument();
    java.lang.Number var7 = var3.getArgument();
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    java.lang.Object[] var12 = new java.lang.Object[] { (short)0};
    org.apache.commons.math3.exception.MathIllegalArgumentException var13 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var10, var12);
    java.lang.Throwable[] var14 = var13.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var15 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var9, (java.lang.Object[])var14);
    org.apache.commons.math3.exception.MathIllegalStateException var16 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var8, (java.lang.Object[])var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 10L+ "'", var4.equals(10L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 0+ "'", var6.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 0+ "'", var7.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test316"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var5 = var0.nextUniform(1.5707963267948966d, 2.718281828459045d);
    int var8 = var0.nextBinomial(100, 9.079985986933498E-5d);
    java.lang.String var10 = var0.nextHexString(222283404);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2.039860471086022d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);

  }

}
