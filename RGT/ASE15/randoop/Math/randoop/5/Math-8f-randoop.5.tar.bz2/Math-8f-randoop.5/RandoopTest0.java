
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }


    double[] var1 = new double[] { 100.0d};
    double[] var5 = new double[] { 100.0d, (-1.0d), 100.0d};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var6 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var1, var5);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }


    double[] var3 = new double[] { 100.0d, 1.0d, (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var4 = null;
    double[] var6 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var6);
    double[][] var8 = new double[][] { var6};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.sortInPlace(var3, var4, var8);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(0.0d, 0.0d, 1.0d, 100.0d, 0.0d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 100.0d);

  }

  public void test4() {}
//   public void test4() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 10);
// 
//   }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    double[] var1 = new double[] { };
    double[] var3 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.DiscreteRealDistribution var5 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var0, var1, var3);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test6() {}
//   public void test6() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }
// 
// 
//     double[] var1 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var1);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
//     double[] var6 = null;
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var7 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var1, var6);
// 
//   }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    double[] var4 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var4);
    double[] var7 = org.apache.commons.math3.util.MathArrays.copyOf(var4, 10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var8 = org.apache.commons.math3.util.MathArrays.ebeAdd(var1, var7);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }


    double[] var1 = new double[] { 0.0d};
    org.apache.commons.math3.util.MathArrays.OrderDirection var2 = null;
    double[] var4 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var4);
    double[] var7 = org.apache.commons.math3.util.MathArrays.copyOf(var4, 10);
    double[][] var8 = new double[][] { var7};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.sortInPlace(var1, var2, var8);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test9() {}
//   public void test9() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 10, 10);
// 
//   }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(0L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var5 = var0.nextLong(1L, (-1L));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test11() {}
//   public void test11() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }
// 
// 
//     java.util.List var0 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var1 = new org.apache.commons.math3.distribution.DiscreteDistribution(var0);
// 
//   }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var3 = var0.nextSecureLong(0L, 0L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test13() {}
//   public void test13() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }
// 
// 
//     org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10.0d, (java.lang.Number)(-1), true);
//     java.lang.Throwable var4 = null;
//     var3.addSuppressed(var4);
// 
//   }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(0L);
    double var4 = var0.nextExponential(0.7432416673360078d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var7 = var0.nextInt(100, 1);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.36157468479281d);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var3 = var0.nextInt(100, 1);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(0L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var5 = var0.nextSecureLong(100L, 100L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(1.0d, 100.0d, 1.0d, 10.0d, 100.0d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 110.0d);

  }

  public void test18() {}
//   public void test18() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }
// 
// 
//     double[] var0 = null;
//     double[] var2 = org.apache.commons.math3.util.MathArrays.normalizeArray(var0, 0.0d);
// 
//   }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(0L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var0.nextBeta(0.0d, 100.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
    } catch (org.apache.commons.math3.exception.NoBracketingException e) {
      // Expected exception.
    }

  }

  public void test20() {}
//   public void test20() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.exception.util.Localizable var3 = null;
//     java.lang.Object[] var6 = new java.lang.Object[] { 'a'};
//     org.apache.commons.math3.exception.NotFiniteNumberException var7 = new org.apache.commons.math3.exception.NotFiniteNumberException(var3, (java.lang.Number)(short)0, var6);
//     org.apache.commons.math3.exception.NotFiniteNumberException var8 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Number)10L, var6);
//     org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var0, var6);
//     org.apache.commons.math3.exception.util.Localizable var10 = null;
//     org.apache.commons.math3.exception.util.Localizable var11 = null;
//     org.apache.commons.math3.exception.util.Localizable var12 = null;
//     org.apache.commons.math3.exception.util.Localizable var14 = null;
//     java.lang.Object[] var17 = new java.lang.Object[] { 'a'};
//     org.apache.commons.math3.exception.NotFiniteNumberException var18 = new org.apache.commons.math3.exception.NotFiniteNumberException(var14, (java.lang.Number)(short)0, var17);
//     org.apache.commons.math3.exception.NotFiniteNumberException var19 = new org.apache.commons.math3.exception.NotFiniteNumberException(var12, (java.lang.Number)10L, var17);
//     org.apache.commons.math3.exception.NullArgumentException var20 = new org.apache.commons.math3.exception.NullArgumentException(var11, var17);
//     org.apache.commons.math3.exception.MathIllegalStateException var21 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var9, var10, var17);
// 
//   }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(0L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var5 = var0.nextBinomial(1, (-1.2016184922621251d));
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double[] var9 = new double[] { 1.0d, 10.0d, 1.0d};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var10 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var1, var9);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.MathArrays.OrderDirection var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var3 = org.apache.commons.math3.util.MathArrays.isMonotonic(var0, var1, true);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(0L);
    java.lang.String var4 = var0.nextHexString(100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var7 = var0.nextZipf(10, (-1.0d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"+ "'", var4.equals("7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"));

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)100.0d);
    java.lang.Number var3 = var2.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(0L);
    java.lang.String var4 = var0.nextHexString(100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var7 = var0.nextUniform(100.0d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"+ "'", var4.equals("7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"));

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    double[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 10);
    double[] var6 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var6);
    boolean var8 = org.apache.commons.math3.util.MathArrays.equals(var1, var6);
    double[] var10 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var10);
    double[] var13 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var13);
    double[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var13, 10);
    double var17 = org.apache.commons.math3.util.MathArrays.distanceInf(var10, var16);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.DiscreteRealDistribution var18 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var16);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);

  }

  public void test28() {}
//   public void test28() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }
// 
// 
//     double[] var0 = null;
//     double[] var2 = org.apache.commons.math3.util.MathArrays.normalizeArray(var0, 0.7432416673360078d);
// 
//   }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var3 = var0.nextBinomial((-1), 0.7432416673360078d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var3 = var0.nextSecureHexString(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(0L);
    double var3 = var0.nextDouble();
    double var4 = var0.nextGaussian();
    var0.setSeed(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var8 = var0.nextInt((-1));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.7432416673360078d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1.2016184922621251d));

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = var0.nextSecureHexString(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var3 = var0.nextSecureLong(10L, (-1L));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(0L);
    double var4 = var0.nextExponential(0.7432416673360078d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var6 = var0.nextSecureHexString((-1));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.36157468479281d);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var3 = var0.nextF((-1.2016184922621251d), (-1.0d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test36() {}
//   public void test36() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }
// 
// 
//     double[] var0 = null;
//     double[] var1 = org.apache.commons.math3.util.MathArrays.copyOf(var0);
// 
//   }

  public void test37() {}
//   public void test37() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }
// 
// 
//     double[] var1 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var1);
//     double[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 10);
//     double[] var6 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var6);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var8 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var6, var8, false);
//     boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var4, var6);
//     double[] var12 = null;
//     double var13 = org.apache.commons.math3.util.MathArrays.distance(var6, var12);
// 
//   }

  public void test38() {}
//   public void test38() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }
// 
// 
//     double[] var0 = null;
//     double[] var2 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var2);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var4 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var2, var4, false);
//     double var7 = org.apache.commons.math3.util.MathArrays.safeNorm(var2);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var8 = null;
//     boolean var10 = org.apache.commons.math3.util.MathArrays.isMonotonic(var2, var8, false);
//     double var11 = org.apache.commons.math3.util.MathArrays.distance(var0, var2);
// 
//   }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var4 = var0.nextHypergeometric(0, 0, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var3 = var0.nextSecureLong(10L, 0L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test41() {}
//   public void test41() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     org.apache.commons.math3.distribution.IntegerDistribution var1 = null;
//     int var2 = var0.nextInversionDeviate(var1);
// 
//   }

  public void test42() {}
//   public void test42() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.util.Collection var1 = null;
//     java.lang.Object[] var3 = var0.nextSample(var1, (-1));
// 
//   }

  public void test43() {}
//   public void test43() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var5 = var0.nextF(110.0d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "942039379648d5183b6c7c050013016cbe5b722cbfdd42360a5b2cfe842d7334e704303a58c3a22b6ce1a212120a8928d144"+ "'", var2.equals("942039379648d5183b6c7c050013016cbe5b722cbfdd42360a5b2cfe842d7334e704303a58c3a22b6ce1a212120a8928d144"));
// 
//   }

  public void test44() {}
//   public void test44() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("18b750b5aede8c5cb77a6d4310c7df1b25788d4f32b713b654134b3d7cbbcffd421462f89aeaa230ac23621fd38af23d96c8", "7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "4067350ce5d5b2ac2db6e1021c3a617900267a9a9706f1982ff5db0b8b5869f2c83d90321bccdf26bf11270ca54329c2c7aa"+ "'", var2.equals("4067350ce5d5b2ac2db6e1021c3a617900267a9a9706f1982ff5db0b8b5869f2c83d90321bccdf26bf11270ca54329c2c7aa"));
// 
//   }

  public void test45() {}
//   public void test45() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)100.0d);
//     java.lang.String var3 = var2.toString();
// 
//   }

  public void test46() {}
//   public void test46() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var4 = var0.nextSecureHexString((-1));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.9230508526704067d));
// 
//   }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }


    org.apache.commons.math3.exception.NullArgumentException var0 = new org.apache.commons.math3.exception.NullArgumentException();

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double[] var7 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var7);
    double[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 10);
    double[] var12 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var12);
    boolean var14 = org.apache.commons.math3.util.MathArrays.equals(var7, var12);
    double[] var16 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var16);
    double[] var19 = org.apache.commons.math3.util.MathArrays.copyOf(var16, 10);
    double var20 = org.apache.commons.math3.util.MathArrays.distanceInf(var12, var19);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var21 = org.apache.commons.math3.util.MathArrays.linearCombination(var1, var12);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException((-1), (-1));
    int var3 = var2.getDimension();
    int var4 = var2.getDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(1.0d, (-1.2016184922621251d), 0.36157468479281d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1.2016184922621251d));

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0d, (java.lang.Number)(byte)(-1), 1);
    boolean var4 = var3.getStrict();
    int var5 = var3.getIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);

  }

  public void test52() {}
//   public void test52() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     var0.setSeed(0L);
//     double var3 = var0.nextDouble();
//     int[] var7 = new int[] { 1, 10, 100};
//     var0.setSeed(var7);
//     java.util.List var9 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var10 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var0, var9);
// 
//   }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(10, 0);

  }

  public void test54() {}
//   public void test54() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 100);
// 
//   }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(0L);
    double var3 = var0.nextDouble();
    var0.clear();
    double var5 = var0.nextGaussian();
    boolean var6 = var0.nextBoolean();
    var0.setSeed(1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.7432416673360078d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1.2016184922621251d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(0L);
    double var4 = var0.nextExponential(0.7432416673360078d);
    var0.reSeed(0L);
    var0.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var10 = var0.nextLong(100L, 0L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.36157468479281d);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    double[] var3 = new double[] { };
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = org.apache.commons.math3.util.MathArrays.distance(var1, var3);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test58() {}
//   public void test58() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var8 = var0.nextUniform(0.3874438233115065d, 1.0d, true);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var0.nextWeibull(0.0d, 22.579321102366254d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.7042337292253328d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 118.13507617042553d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.7519142764036426d);
// 
//   }

  public void test59() {}
//   public void test59() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("18b750b5aede8c5cb77a6d4310c7df1b25788d4f32b713b654134b3d7cbbcffd421462f89aeaa230ac23621fd38af23d96c8", "18b750b5aede8c5cb77a6d4310c7df1b25788d4f32b713b654134b3d7cbbcffd421462f89aeaa230ac23621fd38af23d96c8");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.677188837011972d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 126.33222855914589d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.26692637238302475d);
// 
//   }

  public void test60() {}
//   public void test60() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var10 = var0.nextHexString((-1));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.8346356605849216d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 117.34611227478331d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.5686219204377613d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "6"+ "'", var8.equals("6"));
// 
//   }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(0L);
    double var4 = var0.nextExponential(0.7432416673360078d);
    var0.reSeed(0L);
    var0.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var0.nextBeta(0.0d, 2.1070663248503236d);
      fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
    } catch (org.apache.commons.math3.exception.NoBracketingException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.36157468479281d);

  }

  public void test62() {}
//   public void test62() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var8 = var0.nextUniform(0.3874438233115065d, 1.0d, true);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var10 = var0.nextSecureHexString((-1));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.215175325462935d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 147.06182520683018d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.9146650936912589d);
// 
//   }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(0L);
    double var4 = var0.nextExponential(0.7432416673360078d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var7 = var0.nextBinomial(10, 10.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.36157468479281d);

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Object[] var7 = new java.lang.Object[] { 'a'};
    org.apache.commons.math3.exception.NotFiniteNumberException var8 = new org.apache.commons.math3.exception.NotFiniteNumberException(var4, (java.lang.Number)(short)0, var7);
    org.apache.commons.math3.exception.NotFiniteNumberException var9 = new org.apache.commons.math3.exception.NotFiniteNumberException(var2, (java.lang.Number)10L, var7);
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, var7);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var7);
    org.apache.commons.math3.exception.util.ExceptionContext var12 = var11.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var13 = var11.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test65() {}
//   public void test65() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }
// 
// 
//     double[] var1 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var1);
//     double[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 10);
//     double[] var6 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var6);
//     boolean var8 = org.apache.commons.math3.util.MathArrays.equals(var1, var6);
//     double[] var10 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var10);
//     double[] var13 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 10);
//     double var14 = org.apache.commons.math3.util.MathArrays.distanceInf(var6, var13);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var15 = null;
//     boolean var18 = org.apache.commons.math3.util.MathArrays.checkOrder(var13, var15, false, true);
// 
//   }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }


    org.apache.commons.math3.exception.NotANumberException var0 = new org.apache.commons.math3.exception.NotANumberException();
    org.apache.commons.math3.exception.util.ExceptionContext var1 = var0.getContext();
    org.apache.commons.math3.exception.MathInternalError var2 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10.0d, (java.lang.Number)(-1), true);
    java.lang.Number var4 = var3.getMax();
    boolean var5 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (-1)+ "'", var4.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test68() {}
//   public void test68() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var8 = var0.nextUniform(0.3874438233115065d, 1.0d, true);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var10 = var0.nextPoisson((-1.2016184922621251d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.8828467681784395d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 116.37228391098378d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.7209556680615489d);
// 
//   }

  public void test69() {}
//   public void test69() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(0L);
//     java.lang.String var4 = var0.nextHexString(100);
//     java.lang.String var6 = var0.nextSecureHexString(1);
//     var0.reSeed((-1L));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var0.nextBeta(107.15931048659918d, (-1.0d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"+ "'", var4.equals("7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "a"+ "'", var6.equals("a"));
// 
//   }

  public void test70() {}
//   public void test70() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var11 = var0.nextPermutation((-1), 48);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.01776945464883862d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 103.09383696501872d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.37839782914041237d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "a"+ "'", var8.equals("a"));
// 
//   }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)100.0d, (java.lang.Number)(-1), true);

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }


    long[] var1 = new long[] { (-1L)};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkNonNegative(var1);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test73() {}
//   public void test73() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(0L);
//     double var4 = var0.nextExponential(0.7432416673360078d);
//     java.lang.String var6 = var0.nextSecureHexString(10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var9 = var0.nextBinomial(100, 101.79109515357918d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.36157468479281d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "b6e4ef0d6a"+ "'", var6.equals("b6e4ef0d6a"));
// 
//   }

  public void test74() {}
//   public void test74() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var5 = var0.nextPascal((-1), 82.45368975667407d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.6984241047827207d);
// 
//   }

  public void test75() {}
//   public void test75() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     double var11 = var0.nextGamma(0.36157468479281d, 0.8376757571801716d);
//     org.apache.commons.math3.distribution.IntegerDistribution var12 = null;
//     int var13 = var0.nextInversionDeviate(var12);
// 
//   }

  public void test76() {}
//   public void test76() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }
// 
// 
//     double[] var0 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var0);
// 
//   }

  public void test77() {}
//   public void test77() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(0L);
//     double var4 = var0.nextExponential(0.7432416673360078d);
//     int var7 = var0.nextSecureInt(1, 100);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var10 = var0.nextPermutation((-1), 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.36157468479281d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 27);
// 
//   }

  public void test78() {}
//   public void test78() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     org.apache.commons.math3.distribution.IntegerDistribution var5 = null;
//     int var6 = var0.nextInversionDeviate(var5);
// 
//   }

  public void test79() {}
//   public void test79() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }
// 
// 
//     java.lang.Comparable[] var0 = null;
//     org.apache.commons.math3.util.MathArrays.OrderDirection var1 = null;
//     boolean var3 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var0, var1, false);
// 
//   }

  public void test80() {}
//   public void test80() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }
// 
// 
//     double[] var1 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var1);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
//     double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
//     double[] var8 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var8);
//     double[] var11 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var11);
//     double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
//     double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
//     double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
//     double[] var17 = null;
//     double[] var18 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var16, var17);
// 
//   }

  public void test81() {}
//   public void test81() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     int var5 = var0.nextBinomial(0, 0.0d);
//     double var8 = var0.nextGaussian(108.97593914807048d, 101.79109515357918d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("c", "org.apache.commons.math3.exception.NonMonotonicSequenceException: points 0 and 1 are not strictly increasing (-1 >= 1)");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "77fba249a3dc241617bb01b002fc01e030c4f34b31dcd32efce195067da2e71da8b5a318d33fdc6b89e197933db2247bbcc5"+ "'", var2.equals("77fba249a3dc241617bb01b002fc01e030c4f34b31dcd32efce195067da2e71da8b5a318d33fdc6b89e197933db2247bbcc5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 119.99040434777042d);
// 
//   }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)1, (java.lang.Number)1L, (java.lang.Number)(short)(-1));
    java.lang.Number var5 = var4.getHi();
    java.lang.Number var6 = var4.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (short)(-1)+ "'", var5.equals((short)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (short)(-1)+ "'", var6.equals((short)(-1)));

  }

  public void test83() {}
//   public void test83() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }
// 
// 
//     int[] var3 = new int[] { 1, 1, (-1)};
//     int[] var4 = new int[] { };
//     int[] var5 = null;
//     int var6 = org.apache.commons.math3.util.MathArrays.distance1(var4, var5);
//     int var7 = org.apache.commons.math3.util.MathArrays.distance1(var3, var5);
// 
//   }

  public void test84() {}
//   public void test84() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     double var5 = var0.nextWeibull(110.0d, 0.3874438233115065d);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var0.nextGamma(10.0d, (-1.0790847054779544d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "abca34620f12931c8ea2e0018ebeef457c058b6bdbabca1d910e44b4f03496e929b0064585f8639e2447c51519fda63c5c55"+ "'", var2.equals("abca34620f12931c8ea2e0018ebeef457c058b6bdbabca1d910e44b4f03496e929b0064585f8639e2447c51519fda63c5c55"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.3910377540791953d);
// 
//   }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var3 = var0.nextUniform(0.8376757571801716d, 0.3821299365949273d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test86() {}
//   public void test86() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     org.apache.commons.math3.distribution.RealDistribution var3 = null;
//     double var4 = var0.nextInversionDeviate(var3);
// 
//   }

  public void test87() {}
//   public void test87() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     double var5 = var0.nextWeibull(110.0d, 0.3874438233115065d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var8 = var0.nextSecureInt(1, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "2b1e126f27395414f38e54d6ea03a70b62e3d900af6bd6d152a096498232418984d0fd726261636bec896513f678a2f601c9"+ "'", var2.equals("2b1e126f27395414f38e54d6ea03a70b62e3d900af6bd6d152a096498232418984d0fd726261636bec896513f678a2f601c9"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.3818003461058393d);
// 
//   }

  public void test88() {}
//   public void test88() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     var0.setSeed(0L);
//     double var3 = var0.nextDouble();
//     var0.clear();
//     double var5 = var0.nextGaussian();
//     var0.clear();
//     int var8 = var0.nextInt(48);
//     java.util.List var9 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var10 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var0, var9);
// 
//   }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)0L);
    java.lang.Throwable[] var3 = var2.getSuppressed();
    boolean var4 = var2.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }


    double[] var2 = new double[] { 1.0d, 0.0d};
    double[] var4 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var4);
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var4, var6, false);
    double var9 = org.apache.commons.math3.util.MathArrays.safeNorm(var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = org.apache.commons.math3.util.MathArrays.linearCombination(var2, var4);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }


    long[] var2 = new long[] { 100L, 100L};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test92() {}
//   public void test92() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var9 = var0.nextBinomial(10, (-0.33420519785105623d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-1.5154166137674914d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 104.83487793292598d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.13256612285647507d);
// 
//   }

  public void test93() {}
//   public void test93() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var0.nextCauchy(0.6529927310149576d, (-0.33420519785105623d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.16222002235019015d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 110.4212062625808d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.5464754657332704d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "f"+ "'", var8.equals("f"));
// 
//   }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(100.38955484251419d, 4.149496931236865d, 98.7281415762265d, 115.17225623214854d, 0.0d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 11787.308968688245d);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    double[] var4 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var4);
    double[] var7 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var7);
    double[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 10);
    double var11 = org.apache.commons.math3.util.MathArrays.distanceInf(var4, var10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.DiscreteRealDistribution var12 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var1, var4);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);

  }

  public void test96() {}
//   public void test96() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     java.lang.String var10 = var0.nextSecureHexString(10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var0.nextUniform(22.579321102366254d, (-1.2016184922621251d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.45799433555402125d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 97.50292097994249d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 6.820639547276532E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "9"+ "'", var8.equals("9"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "d6aba6a57b"+ "'", var10.equals("d6aba6a57b"));
// 
//   }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination((-0.7309917490679942d), 107.15931048659918d, 0.6529927310149576d, 0.0d, (-0.4076885612903701d), 0.00940319128424221d, 89.20864929079774d, 0.36157468479281d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-46.08081612693308d));

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10.0d, (java.lang.Number)(-1), true);
    boolean var4 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test99() {}
//   public void test99() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     long var10 = var0.nextPoisson(98.7281415762265d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var0.nextPascal(0, 0.0032241185303045258d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-1.8242388484262302d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 104.7779352046661d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.06908434006720464d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "7"+ "'", var8.equals("7"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 99L);
// 
//   }

  public void test100() {}
//   public void test100() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     java.lang.String var10 = var0.nextSecureHexString(10);
//     org.apache.commons.math3.distribution.IntegerDistribution var11 = null;
//     int var12 = var0.nextInversionDeviate(var11);
// 
//   }

  public void test101() {}
//   public void test101() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     int var5 = var0.nextBinomial(0, 0.0d);
//     double var8 = var0.nextGaussian(108.97593914807048d, 101.79109515357918d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var0.nextF(0.6556684902257256d, (-0.4076885612903701d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "4fab5075b3aa603b690b560b9916c35fad3bebd859b0574358ad8507cf61ae00c8481f6fb1f6fa6735efb145f5f360484f01"+ "'", var2.equals("4fab5075b3aa603b690b560b9916c35fad3bebd859b0574358ad8507cf61ae00c8481f6fb1f6fa6735efb145f5f360484f01"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 41.28017644357722d);
// 
//   }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    double[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 10);
    double[] var6 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var6);
    boolean var8 = org.apache.commons.math3.util.MathArrays.equals(var1, var6);
    double[] var10 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var10);
    double[] var13 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 10);
    double var14 = org.apache.commons.math3.util.MathArrays.distanceInf(var6, var13);
    org.apache.commons.math3.util.MathArrays.OrderDirection var15 = null;
    boolean var17 = org.apache.commons.math3.util.MathArrays.isMonotonic(var6, var15, true);
    double[] var19 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var19);
    double var21 = org.apache.commons.math3.util.MathArrays.distance1(var6, var19);
    double[] var23 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var23);
    org.apache.commons.math3.util.MathArrays.OrderDirection var25 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var23, var25, false);
    double var28 = org.apache.commons.math3.util.MathArrays.safeNorm(var23);
    double[] var30 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var30);
    double[] var33 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var33);
    double[] var36 = org.apache.commons.math3.util.MathArrays.copyOf(var33, 10);
    double var37 = org.apache.commons.math3.util.MathArrays.distanceInf(var30, var36);
    double[] var38 = org.apache.commons.math3.util.MathArrays.ebeDivide(var23, var30);
    double[] var40 = org.apache.commons.math3.util.MathArrays.normalizeArray(var23, 10.0d);
    double[] var42 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var42);
    double[] var45 = org.apache.commons.math3.util.MathArrays.copyOf(var42, 10);
    double[] var47 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var47);
    boolean var49 = org.apache.commons.math3.util.MathArrays.equals(var42, var47);
    double[] var51 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var51);
    double[] var54 = org.apache.commons.math3.util.MathArrays.copyOf(var51, 10);
    double var55 = org.apache.commons.math3.util.MathArrays.distanceInf(var47, var54);
    double var56 = org.apache.commons.math3.util.MathArrays.distanceInf(var40, var47);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var57 = org.apache.commons.math3.util.MathArrays.linearCombination(var6, var40);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 11.0d);

  }

  public void test103() {}
//   public void test103() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     java.lang.Object[] var5 = new java.lang.Object[] { 'a'};
//     org.apache.commons.math3.exception.NotFiniteNumberException var6 = new org.apache.commons.math3.exception.NotFiniteNumberException(var2, (java.lang.Number)(short)0, var5);
//     org.apache.commons.math3.exception.NotFiniteNumberException var7 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)10L, var5);
//     java.lang.String var8 = var7.toString();
// 
//   }

  public void test104() {}
//   public void test104() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }
// 
// 
//     org.apache.commons.math3.util.Pair var0 = null;
//     org.apache.commons.math3.util.Pair var1 = new org.apache.commons.math3.util.Pair(var0);
// 
//   }

  public void test105() {}
//   public void test105() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var0.nextUniform(0.0d, (-463.4955697271597d), false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.5399186590033553d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 120.65502477324435d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.692773712667691E-5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "f"+ "'", var8.equals("f"));
// 
//   }

  public void test106() {}
//   public void test106() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var7 = var0.nextSecureLong(75L, (-1L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.1275627131231058d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 78.17527721629308d);
// 
//   }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(0L);
    double var3 = var0.nextDouble();
    int[] var7 = new int[] { 1, 10, 100};
    var0.setSeed(var7);
    int[] var9 = new int[] { };
    org.apache.commons.math3.random.Well19937c var10 = new org.apache.commons.math3.random.Well19937c(var9);
    int[] var12 = org.apache.commons.math3.util.MathArrays.copyOf(var9, 100);
    int[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var9, 10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var15 = org.apache.commons.math3.util.MathArrays.distance(var7, var9);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.7432416673360078d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test108() {}
//   public void test108() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var9 = var0.nextZipf(7, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-1.4390756889651775d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 150.89010192196815d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.04192736428083931d);
// 
//   }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeedSecure();
    var0.reSeed(100L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSecureAlgorithm("6", "f4cba46ce3");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(0L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var6 = var0.nextUniform(110.0d, 0.0d, true);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test111() {}
//   public void test111() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(0L);
//     java.lang.String var4 = var0.nextHexString(100);
//     java.lang.String var6 = var0.nextSecureHexString(1);
//     double var9 = var0.nextGamma(0.7432416673360078d, 100.0d);
//     long var12 = var0.nextSecureLong(10L, 85L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var0.nextGaussian(0.6556684902257256d, (-0.33420519785105623d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"+ "'", var4.equals("7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "4"+ "'", var6.equals("4"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 22.579321102366254d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 81L);
// 
//   }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(0L);
    double var3 = var0.nextDouble();
    var0.clear();
    double var5 = var0.nextGaussian();
    boolean var6 = var0.nextBoolean();
    double var7 = var0.nextDouble();
    var0.setSeed(100);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double[] var16 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var16);
    boolean var18 = org.apache.commons.math3.util.MathArrays.equals(var11, var16);
    double[] var20 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var20);
    double[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 10);
    double var24 = org.apache.commons.math3.util.MathArrays.distanceInf(var16, var23);
    org.apache.commons.math3.util.MathArrays.OrderDirection var25 = null;
    boolean var27 = org.apache.commons.math3.util.MathArrays.isMonotonic(var16, var25, true);
    double[] var29 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var29);
    double var31 = org.apache.commons.math3.util.MathArrays.distance1(var16, var29);
    double[] var33 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var33);
    double[] var36 = org.apache.commons.math3.util.MathArrays.copyOf(var33, 10);
    double[] var38 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var38);
    boolean var40 = org.apache.commons.math3.util.MathArrays.equals(var33, var38);
    double[] var42 = org.apache.commons.math3.util.MathArrays.copyOf(var33, 0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.DiscreteRealDistribution var43 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var0, var16, var33);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.7432416673360078d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1.2016184922621251d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.3874438233115065d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var3 = var0.nextPoisson((-0.33420519785105623d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 48, 0);

  }

  public void test115() {}
//   public void test115() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var0.nextWeibull(112.79893611497971d, (-0.7983970751347875d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-1.3214249128930065d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 120.9849304901913d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.3951211400664656E-7d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "e"+ "'", var8.equals("e"));
// 
//   }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var0, 100);
    int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var0, 10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var7 = org.apache.commons.math3.util.MathArrays.copyOf(var0, (-1));
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test117() {}
//   public void test117() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     double var11 = var0.nextGamma(0.36157468479281d, 0.8376757571801716d);
//     var0.reSeed();
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var16 = var0.nextLong((-1L), (-1L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.6198991520989245d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 115.87025423204707d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 4.4920215447630096E-6d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "0"+ "'", var8.equals("0"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.04463304186869765d);
// 
//   }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    double[] var4 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var4);
    double[] var7 = org.apache.commons.math3.util.MathArrays.copyOf(var4, 10);
    double var8 = org.apache.commons.math3.util.MathArrays.distanceInf(var1, var7);
    double[] var10 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var10);
    double[] var13 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 10);
    double[] var15 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var15);
    org.apache.commons.math3.util.MathArrays.OrderDirection var17 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var15, var17, false);
    double var20 = org.apache.commons.math3.util.MathArrays.safeNorm(var15);
    double[] var22 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var22);
    double[] var25 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    double[] var28 = org.apache.commons.math3.util.MathArrays.copyOf(var25, 10);
    double var29 = org.apache.commons.math3.util.MathArrays.distanceInf(var22, var28);
    double[] var30 = org.apache.commons.math3.util.MathArrays.ebeDivide(var15, var22);
    double[] var32 = org.apache.commons.math3.util.MathArrays.normalizeArray(var15, 10.0d);
    double var33 = org.apache.commons.math3.util.MathArrays.distance(var10, var15);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var34 = org.apache.commons.math3.util.MathArrays.ebeAdd(var7, var10);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var0, 100);
    int[] var4 = new int[] { };
    org.apache.commons.math3.random.Well19937c var5 = new org.apache.commons.math3.random.Well19937c(var4);
    int[] var6 = new int[] { };
    org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(var6);
    int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var6, 100);
    int var10 = org.apache.commons.math3.util.MathArrays.distance1(var4, var6);
    int[] var11 = new int[] { };
    org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(var11);
    int var13 = org.apache.commons.math3.util.MathArrays.distanceInf(var6, var11);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var14 = org.apache.commons.math3.util.MathArrays.distance1(var3, var6);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }


    float[] var1 = new float[] { 100.0f};
    float[] var2 = null;
    float[] var5 = new float[] { 100.0f, 10.0f};
    boolean var6 = org.apache.commons.math3.util.MathArrays.equals(var2, var5);
    float[] var10 = new float[] { 0.0f, (-1.0f), 0.0f};
    boolean var11 = org.apache.commons.math3.util.MathArrays.equals(var5, var10);
    float[] var12 = null;
    float[] var15 = new float[] { 100.0f, 10.0f};
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var12, var15);
    float[] var20 = new float[] { 0.0f, (-1.0f), 0.0f};
    boolean var21 = org.apache.commons.math3.util.MathArrays.equals(var15, var20);
    float[] var22 = null;
    float[] var25 = new float[] { 100.0f, 10.0f};
    boolean var26 = org.apache.commons.math3.util.MathArrays.equals(var22, var25);
    float[] var30 = new float[] { 0.0f, (-1.0f), 0.0f};
    boolean var31 = org.apache.commons.math3.util.MathArrays.equals(var25, var30);
    boolean var32 = org.apache.commons.math3.util.MathArrays.equals(var15, var25);
    boolean var33 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var15);
    boolean var34 = org.apache.commons.math3.util.MathArrays.equals(var1, var15);
    float[] var37 = new float[] { (-1.0f), 10.0f};
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var15, var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)75L, (java.lang.Number)1.0d, false);

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(0.4517190132114119d, 3.3900817738101328d, 0.23842384721562462d, 0.0d, 112.79893611497971d, 9.160555011685411E-6d, 1.4924399031740692E10d, 0.6529927310149576d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 9.745524084025742E9d);

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(98.7281415762265d, 0.4243146458091146d, 0.6529927310149576d, 9.745524084025742E9d, 0.0d, 0.5230125715149944d, 9.160555011685411E-6d, (-0.4076885612903701d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 6.363756428691805E9d);

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)114.23712557956448d, (java.lang.Number)0.4243146458091146d, true);

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }


    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Object[] var6 = new java.lang.Object[] { 'a'};
    org.apache.commons.math3.exception.NotFiniteNumberException var7 = new org.apache.commons.math3.exception.NotFiniteNumberException(var3, (java.lang.Number)(short)0, var6);
    org.apache.commons.math3.exception.NotFiniteNumberException var8 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Number)10L, var6);
    org.apache.commons.math3.exception.NotFiniteNumberException var9 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-0.019977037496912195d), var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test126() {}
//   public void test126() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     double var5 = var0.nextWeibull(110.0d, 0.3874438233115065d);
//     var0.reSeedSecure();
//     var0.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "db73bad9dc69f6cc695ea2112cf9dff922940f5513fb99f33de4a0b1ed0c2d6ebe9f19399c7a1b99bf0e3b67dfc20c551cca"+ "'", var2.equals("db73bad9dc69f6cc695ea2112cf9dff922940f5513fb99f33de4a0b1ed0c2d6ebe9f19399c7a1b99bf0e3b67dfc20c551cca"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.3895561528043651d);
// 
//   }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }


    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.17846182358222898d, (java.lang.Number)(-0.14067868274055728d), var2);

  }

  public void test128() {}
//   public void test128() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var5 = var0.nextSecureInt(48, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2.3445184902672316d);
// 
//   }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0.03863055888020799d, (java.lang.Number)(-1.3407807929942597E154d), (java.lang.Number)0.00322408197305579d);

  }

  public void test130() {}
//   public void test130() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     double var5 = var0.nextWeibull(110.0d, 0.3874438233115065d);
//     java.lang.String var7 = var0.nextHexString(1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var0.nextGamma(0.0d, 11.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "8638b41838cda21cb9b6f28d6c537f8b7a05f7731f360d20e5ee9f3ccc0cd3c2e260555bd189887e69a15cfae6e910bfc2e3"+ "'", var2.equals("8638b41838cda21cb9b6f28d6c537f8b7a05f7731f360d20e5ee9f3ccc0cd3c2e260555bd189887e69a15cfae6e910bfc2e3"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.3844811679394907d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + "4"+ "'", var7.equals("4"));
// 
//   }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(byte)1, (java.lang.Number)(short)(-1), false);
    java.lang.String var4 = var3.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: 1 is smaller than, or equal to, the minimum (-1)"+ "'", var4.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: 1 is smaller than, or equal to, the minimum (-1)"));

  }

  public void test132() {}
//   public void test132() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)0L);
//     java.lang.Number var3 = var2.getMin();
//     org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var2);
// 
//   }

  public void test133() {}
//   public void test133() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(0L);
//     double var4 = var0.nextExponential(0.7432416673360078d);
//     java.lang.String var6 = var0.nextSecureHexString(10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var9 = var0.nextInt(0, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.36157468479281d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "f6b45c1a79"+ "'", var6.equals("f6b45c1a79"));
// 
//   }

  public void test134() {}
//   public void test134() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     var0.reSeedSecure();
//     org.apache.commons.math3.distribution.RealDistribution var6 = null;
//     double var7 = var0.nextInversionDeviate(var6);
// 
//   }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0f, var1, 10, var3, true);
    org.apache.commons.math3.exception.util.ExceptionContext var6 = var5.getContext();
    int var7 = var5.getIndex();
    boolean var8 = var5.getStrict();
    boolean var9 = var5.getStrict();
    boolean var10 = var5.getStrict();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);

  }

  public void test136() {}
//   public void test136() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)1, (java.lang.Number)1L, (java.lang.Number)(short)(-1));
//     java.lang.Number var5 = var4.getLo();
//     java.lang.Number var6 = var4.getHi();
//     java.lang.Number var7 = var4.getLo();
//     java.lang.String var8 = var4.toString();
// 
//   }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var1 = null;
    org.apache.commons.math3.exception.MathArithmeticException var2 = new org.apache.commons.math3.exception.MathArithmeticException(var0, var1);
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var2.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var2.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var2.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test138() {}
//   public void test138() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     double var11 = var0.nextGamma(0.36157468479281d, 0.8376757571801716d);
//     int var14 = var0.nextBinomial(1, 0.7432416673360078d);
//     double var17 = var0.nextBeta(3.3900817738101328d, 11787.308968688245d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var20 = var0.nextCauchy(0.7140368591421311d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-1.6296005630065122d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 82.37040725053161d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.0034782423453467324d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "5"+ "'", var8.equals("5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0010426051863991685d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 2.468752205818235E-4d);
// 
//   }

  public void test139() {}
//   public void test139() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(0L);
//     java.lang.String var4 = var0.nextHexString(100);
//     java.lang.String var6 = var0.nextSecureHexString(1);
//     var0.reSeed((-1L));
//     double var10 = var0.nextExponential(0.915778680097192d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var0.nextUniform(6.363756428691805E9d, 7.277800330956172E-5d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"+ "'", var4.equals("7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "d"+ "'", var6.equals("d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.3650947445123496d);
// 
//   }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)1.305475194865426d, (java.lang.Number)1024457413273955602L, false);
    boolean var5 = var4.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test141() {}
//   public void test141() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)0L);
//     java.lang.Number var3 = var2.getArgument();
//     org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var2);
// 
//   }

  public void test142() {}
//   public void test142() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     double var11 = var0.nextGamma(0.36157468479281d, 0.8376757571801716d);
//     int var14 = var0.nextBinomial(1, 0.7432416673360078d);
//     double var17 = var0.nextBeta(3.3900817738101328d, 11787.308968688245d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var20 = var0.nextBinomial(0, (-2.1031364139386386d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.5120168748562809d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 102.30979747622827d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 9.137649014606028E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "9"+ "'", var8.equals("9"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.27779274719838404d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 3.0103607105887506E-4d);
// 
//   }

  public void test143() {}
//   public void test143() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }
// 
// 
//     double[] var1 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var1);
//     double[] var4 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var4);
//     double[] var7 = org.apache.commons.math3.util.MathArrays.copyOf(var4, 10);
//     double var8 = org.apache.commons.math3.util.MathArrays.distanceInf(var1, var7);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var9 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var7, var9, false);
// 
//   }

  public void test144() {}
//   public void test144() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(0L);
//     java.lang.String var4 = var0.nextHexString(100);
//     java.lang.String var6 = var0.nextSecureHexString(1);
//     double var9 = var0.nextGamma(0.7432416673360078d, 100.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var0.nextChiSquare((-2.2726334418422858d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"+ "'", var4.equals("7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "f"+ "'", var6.equals("f"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 22.579321102366254d);
// 
//   }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.06453083525684095d, (java.lang.Number)0.19576879474708697d, 10);

  }

  public void test146() {}
//   public void test146() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(0L);
//     java.lang.String var4 = var0.nextHexString(100);
//     java.lang.String var6 = var0.nextSecureHexString(1);
//     double var9 = var0.nextGamma(0.7432416673360078d, 100.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var12 = var0.nextSecureLong(75L, (-1L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"+ "'", var4.equals("7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "d"+ "'", var6.equals("d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 22.579321102366254d);
// 
//   }

  public void test147() {}
//   public void test147() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     long var10 = var0.nextPoisson(98.7281415762265d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var12 = var0.nextHexString((-1));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.4121688796886973d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 131.95543029166677d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 5.142122019680586E-6d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "2"+ "'", var8.equals("2"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 88L);
// 
//   }

  public void test148() {}
//   public void test148() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     var0.setSeed(0L);
//     double var3 = var0.nextDouble();
//     var0.clear();
//     double var5 = var0.nextGaussian();
//     boolean var6 = var0.nextBoolean();
//     double var7 = var0.nextDouble();
//     var0.setSeed(100);
//     var0.setSeed(0);
//     boolean var12 = var0.nextBoolean();
//     java.util.List var13 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var14 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var0, var13);
// 
//   }

  public void test149() {}
//   public void test149() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     double var11 = var0.nextGamma(0.36157468479281d, 0.8376757571801716d);
//     int var14 = var0.nextBinomial(1, 0.7432416673360078d);
//     double var17 = var0.nextBeta(3.3900817738101328d, 11787.308968688245d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var20 = var0.nextBinomial(33787721, 378.32817290051395d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-1.0300056388462107d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 95.02038184523553d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.388390250724656d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "b"+ "'", var8.equals("b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.0762351263510632d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 5.961537099590307E-4d);
// 
//   }

  public void test150() {}
//   public void test150() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var0.nextBeta((-46.08081612693308d), 0.06453083525684095d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.0798342082904075d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 86.52202900402075d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.2190416110126366d);
// 
//   }

  public void test151() {}
//   public void test151() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     int var5 = var0.nextBinomial(0, 0.0d);
//     var0.reSeed(0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var9 = var0.nextPoisson((-0.7309917490679942d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "601a69ab51bc4f502eb30eec5b08cdea2ff063f009f8745f36e33f311729520b775498f7214bc4705fb3d663b10bbe096bff"+ "'", var2.equals("601a69ab51bc4f502eb30eec5b08cdea2ff063f009f8745f36e33f311729520b775498f7214bc4705fb3d663b10bbe096bff"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
// 
//   }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
    var1.reSeed();
    var1.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var6 = var1.nextSecureInt(52084938, 39);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Object[] var7 = new java.lang.Object[] { 'a'};
    org.apache.commons.math3.exception.NotFiniteNumberException var8 = new org.apache.commons.math3.exception.NotFiniteNumberException(var4, (java.lang.Number)(short)0, var7);
    org.apache.commons.math3.exception.NotFiniteNumberException var9 = new org.apache.commons.math3.exception.NotFiniteNumberException(var2, (java.lang.Number)10L, var7);
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, var7);
    org.apache.commons.math3.exception.MathArithmeticException var11 = new org.apache.commons.math3.exception.MathArithmeticException(var0, var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }


    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)75L, (java.lang.Number)100.38955484251419d, 0, var3, false);

  }

  public void test155() {}
//   public void test155() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     var0.reSeedSecure();
//     var0.reSeed();
//     double var9 = var0.nextUniform(0.0015326576218039215d, 114.81244598869324d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var0.nextBeta((-0.33420519785105623d), 0.6466912681842636d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.778687487462697d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 121.85358203198544d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 89.67828672475147d);
// 
//   }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    double[] var3 = new double[] { };
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var4 = org.apache.commons.math3.util.MathArrays.ebeAdd(var1, var3);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)103.25934629914218d, (java.lang.Number)7.277800330956172E-5d, (java.lang.Number)0.3842834232631038d);

  }

  public void test158() {}
//   public void test158() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(0L);
//     double var4 = var0.nextExponential(0.7432416673360078d);
//     int var7 = var0.nextSecureInt(1, 100);
//     java.lang.String var9 = var0.nextHexString(7);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var0.nextPascal(0, (-1.2016184922621251d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.36157468479281d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "67c8011"+ "'", var9.equals("67c8011"));
// 
//   }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(7, 99);

  }

  public void test160() {}
//   public void test160() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var8 = var0.nextUniform(0.3874438233115065d, 1.0d, true);
//     long var10 = var0.nextPoisson(0.5230125715149944d);
//     var0.reSeed();
//     org.apache.commons.math3.distribution.RealDistribution var12 = null;
//     double var13 = var0.nextInversionDeviate(var12);
// 
//   }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }


    org.apache.commons.math3.exception.NotANumberException var0 = new org.apache.commons.math3.exception.NotANumberException();
    org.apache.commons.math3.exception.util.ExceptionContext var1 = var0.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var0.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var0.getContext();
    java.lang.Number var4 = var0.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + Double.NaN+ "'", var4.equals(Double.NaN));

  }

  public void test162() {}
//   public void test162() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }
// 
// 
//     int[] var0 = new int[] { };
//     int[] var1 = null;
//     int var2 = org.apache.commons.math3.util.MathArrays.distance1(var0, var1);
//     int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var1);
// 
//   }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    var1.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var0, 100);
    int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var0, 10);
    int[] var7 = org.apache.commons.math3.util.MathArrays.copyOf(var0, 99);
    org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test165() {}
//   public void test165() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     int var5 = var0.nextBinomial(10, 0.03863055888020799d);
//     int var8 = var0.nextSecureInt(7, 48);
//     org.apache.commons.math3.distribution.IntegerDistribution var9 = null;
//     int var10 = var0.nextInversionDeviate(var9);
// 
//   }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0f, var1, 10, var3, true);
    org.apache.commons.math3.exception.util.ExceptionContext var6 = var5.getContext();
    int var7 = var5.getIndex();
    org.apache.commons.math3.util.MathArrays.OrderDirection var8 = var5.getDirection();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double[] var18 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 10.0d);
    double[] var20 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var20);
    double[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 10);
    double[] var25 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var20, var25);
    double[] var29 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var29);
    double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 10);
    double var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var32);
    double var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var25);
    double[] var36 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var36);
    double[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var36, 10);
    double[] var41 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var41);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var36, var41);
    double[] var45 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var45);
    double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var45, 10);
    double var49 = org.apache.commons.math3.util.MathArrays.distanceInf(var41, var48);
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeAdd(var18, var41);
    double[] var52 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var52);
    double[] var55 = org.apache.commons.math3.util.MathArrays.copyOf(var52, 10);
    double[] var57 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var57);
    boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var52, var57);
    double[] var61 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var61);
    double[] var64 = org.apache.commons.math3.util.MathArrays.copyOf(var61, 10);
    double var65 = org.apache.commons.math3.util.MathArrays.distanceInf(var57, var64);
    org.apache.commons.math3.util.MathArrays.OrderDirection var66 = null;
    boolean var68 = org.apache.commons.math3.util.MathArrays.isMonotonic(var57, var66, true);
    double[] var70 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var70);
    double var72 = org.apache.commons.math3.util.MathArrays.distance1(var57, var70);
    double[] var74 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var74);
    double[] var77 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var77);
    double[] var80 = org.apache.commons.math3.util.MathArrays.copyOf(var77, 10);
    double var81 = org.apache.commons.math3.util.MathArrays.distanceInf(var74, var80);
    double[] var82 = org.apache.commons.math3.util.MathArrays.ebeDivide(var70, var74);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.DiscreteRealDistribution var83 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var41, var74);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 11.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);

  }

  public void test168() {}
//   public void test168() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(0L);
//     java.lang.String var4 = var0.nextHexString(100);
//     java.lang.String var6 = var0.nextSecureHexString(1);
//     var0.reSeed((-1L));
//     var0.reSeed(0L);
//     double var13 = var0.nextWeibull(128.35556077963213d, 0.3874438233115065d);
//     java.util.Collection var14 = null;
//     java.lang.Object[] var16 = var0.nextSample(var14, 1);
// 
//   }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-1.3407807929942597E154d), (java.lang.Number)0.7767857089724116d, true);

  }

  public void test170() {}
//   public void test170() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     double var5 = var0.nextGaussian(0.0032241185303045258d, 128.35556077963213d);
//     long var8 = var0.nextSecureLong(1L, 10L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var0.nextUniform(0.38580107253710577d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "a8c58b58b2894fa0c2cb3c4fcdc83c15b23627b02dc71eddab4773f6e6525a59e2c2aac91202c42ff5cbd7dbe5115b0affb2"+ "'", var2.equals("a8c58b58b2894fa0c2cb3c4fcdc83c15b23627b02dc71eddab4773f6e6525a59e2c2aac91202c42ff5cbd7dbe5115b0affb2"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-30.842155699651446d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 9L);
// 
//   }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(0L);
    double var3 = var0.nextDouble();
    var0.clear();
    double var5 = var0.nextGaussian();
    var0.setSeed(0);
    double var8 = var0.nextDouble();
    var0.clear();
    byte[] var10 = new byte[] { };
    var0.nextBytes(var10);
    int var13 = var0.nextInt(312574995);
    float var14 = var0.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.7432416673360078d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1.2016184922621251d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.9775554539871507d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 52084938);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.54627895f);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(0L);
    boolean var3 = var0.nextBoolean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    double[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkPositive(var4);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0f, var1, 10, var3, true);
    java.lang.Number var6 = var5.getArgument();
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = var5.getDirection();
    java.lang.String var8 = var5.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 0.0f+ "'", var6.equals(0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "org.apache.commons.math3.exception.NonMonotonicSequenceException: points 9 and 10 are not strictly decreasing (null <= 0)"+ "'", var8.equals("org.apache.commons.math3.exception.NonMonotonicSequenceException: points 9 and 10 are not strictly decreasing (null <= 0)"));

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)0, true);
    java.lang.Number var4 = var3.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0+ "'", var4.equals(0));

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(0L);
    java.lang.String var4 = var0.nextHexString(100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var7 = var0.nextPascal(48, 111.37835237422031d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"+ "'", var4.equals("7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"));

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c();
    var1.setSeed(0L);
    double var4 = var1.nextDouble();
    var1.clear();
    byte[] var9 = new byte[] { (byte)0, (byte)(-1), (byte)10};
    var1.nextBytes(var9);
    var0.nextBytes(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.7432416673360078d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test178() {}
//   public void test178() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)1, (java.lang.Number)1L, (java.lang.Number)(short)(-1));
//     java.lang.Number var5 = var4.getHi();
//     java.lang.Number var6 = var4.getLo();
//     org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var4);
// 
//   }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var2 = null;
    org.apache.commons.math3.exception.NotFiniteNumberException var3 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)1.0d, var2);

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
    var1.reSeed();
    var1.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var6 = var1.nextInt(36, 1);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test181() {}
//   public void test181() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     double var11 = var0.nextGamma(0.36157468479281d, 0.8376757571801716d);
//     var0.reSeed();
//     var0.reSeedSecure();
//     double var16 = var0.nextCauchy(99.15680865820634d, 54.76711054963606d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var19 = var0.nextPascal(99, (-2.1031364139386386d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2.2755258288996956d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 102.4050315539949d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 4.6961359860803414E-5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "4"+ "'", var8.equals("4"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.08337609141715706d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 104.17602808196126d);
// 
//   }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var0, 100);
    int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var0, 10);
    int[] var6 = new int[] { };
    org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(var6);
    int[] var8 = new int[] { };
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(var8);
    int[] var11 = org.apache.commons.math3.util.MathArrays.copyOf(var8, 100);
    int var12 = org.apache.commons.math3.util.MathArrays.distance1(var6, var8);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var13 = org.apache.commons.math3.util.MathArrays.distance1(var5, var6);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);

  }

  public void test183() {}
//   public void test183() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(0L);
//     double var4 = var0.nextExponential(0.7432416673360078d);
//     int var7 = var0.nextSecureInt(1, 100);
//     java.lang.String var9 = var0.nextHexString(7);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var0.nextChiSquare((-1.214586682339185d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.36157468479281d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "67c8011"+ "'", var9.equals("67c8011"));
// 
//   }

  public void test184() {}
//   public void test184() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }
// 
// 
//     double[] var1 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var1);
//     double[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 10);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var5 = null;
//     boolean var7 = org.apache.commons.math3.util.MathArrays.isMonotonic(var4, var5, true);
// 
//   }

  public void test185() {}
//   public void test185() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var8 = var0.nextInt(19, 19);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.8297481909047211d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 128.23708465430565d);
// 
//   }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }


    double[] var0 = null;
    double[] var2 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var2);
    org.apache.commons.math3.util.MathArrays.OrderDirection var4 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var2, var4, false);
    double var7 = org.apache.commons.math3.util.MathArrays.safeNorm(var2);
    double[] var9 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    double[] var12 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var12);
    double[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var12, 10);
    double var16 = org.apache.commons.math3.util.MathArrays.distanceInf(var9, var15);
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeDivide(var2, var9);
    double[] var19 = org.apache.commons.math3.util.MathArrays.normalizeArray(var2, 10.0d);
    double[] var21 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var21);
    double[] var24 = org.apache.commons.math3.util.MathArrays.copyOf(var21, 10);
    double[] var26 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var26);
    boolean var28 = org.apache.commons.math3.util.MathArrays.equals(var21, var26);
    double[] var30 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var30);
    double[] var33 = org.apache.commons.math3.util.MathArrays.copyOf(var30, 10);
    double var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var26, var33);
    double var35 = org.apache.commons.math3.util.MathArrays.distanceInf(var19, var26);
    double[] var37 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var37);
    org.apache.commons.math3.util.MathArrays.OrderDirection var39 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var37, var39, false);
    double var42 = org.apache.commons.math3.util.MathArrays.distanceInf(var26, var37);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var0, var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 11.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);

  }

  public void test187() {}
//   public void test187() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     java.util.Collection var3 = null;
//     java.lang.Object[] var5 = var0.nextSample(var3, 52084938);
// 
//   }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.lang.Object[] var4 = new java.lang.Object[] { (short)10};
    org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError(var2, var4);
    org.apache.commons.math3.exception.MathIllegalStateException var6 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, var4);
    org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError(var0, var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, var1);

  }

  public void test190() {}
//   public void test190() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(0L);
//     double var4 = var0.nextExponential(0.7432416673360078d);
//     java.util.Collection var5 = null;
//     java.lang.Object[] var7 = var0.nextSample(var5, 44);
// 
//   }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.3901018313315268d, (java.lang.Number)0.05609443507672968d, 44);

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var3 = new java.lang.Object[] { 'a'};
    org.apache.commons.math3.exception.NotFiniteNumberException var4 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)(short)0, var3);
    double[] var6 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var6);
    org.apache.commons.math3.util.MathArrays.OrderDirection var8 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var6, var8, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var6);
    org.apache.commons.math3.util.Pair var12 = new org.apache.commons.math3.util.Pair((java.lang.Object)(short)0, (java.lang.Object)var6);
    java.lang.Object var13 = var12.getValue();
    org.apache.commons.math3.util.Pair var14 = new org.apache.commons.math3.util.Pair(var12);
    java.lang.Object var15 = var14.getFirst();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + (short)0+ "'", var15.equals((short)0));

  }

  public void test193() {}
//   public void test193() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(7, 312574995);
//     long var6 = var0.nextLong(75L, 477836925424025280L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 274497138);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 434277157163744896L);
// 
//   }

  public void test194() {}
//   public void test194() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var5 = var0.nextF(0.044259860704679646d, 0.19576879474708697d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var8 = var0.nextGamma((-1.7185138799120012d), 0.17846182358222898d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.3962879349033403d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.8171319616392182E-9d);
// 
//   }

  public void test195() {}
//   public void test195() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 0);
// 
//   }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)0L);
    boolean var3 = var2.getBoundIsAllowed();
    java.lang.Number var4 = var2.getArgument();
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var2.getContext();
    boolean var6 = var2.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0L+ "'", var4.equals(0L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(0L);
    double var3 = var0.nextDouble();
    var0.setSeed(48);
    double var6 = var0.nextDouble();
    var0.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.7432416673360078d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.6062775910181382d);

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = null;
    boolean var10 = org.apache.commons.math3.util.MathArrays.checkOrder(var1, var7, true, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);

  }

  public void test199() {}
//   public void test199() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(7, 312574995);
//     java.util.Collection var4 = null;
//     java.lang.Object[] var6 = var0.nextSample(var4, (-1));
// 
//   }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.0181388340431587d, (java.lang.Number)39, false);

  }

  public void test201() {}
//   public void test201() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     var0.reSeedSecure();
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var8 = var0.nextSecureHexString(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.7228139354268504d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 99.38255569315768d);
// 
//   }

  public void test202() {}
//   public void test202() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     double var11 = var0.nextGamma(0.36157468479281d, 0.8376757571801716d);
//     var0.reSeed();
//     var0.reSeedSecure();
//     long var16 = var0.nextLong((-1L), 10L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var19 = var0.nextPascal(99, 89.20864929079774d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.9212868970895929d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 119.40559052208738d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.004424375007207592d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "5"+ "'", var8.equals("5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.06910063654769477d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 2L);
// 
//   }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(0L);
    double var3 = var0.nextDouble();
    var0.clear();
    double var5 = var0.nextGaussian();
    var0.setSeed(0);
    var0.setSeed(0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.7432416673360078d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1.2016184922621251d));

  }

  public void test204() {}
//   public void test204() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     var0.reSeedSecure();
//     var0.reSeed();
//     int var9 = var0.nextZipf(21, 0.044259860704679646d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var0.nextWeibull(114.23712557956448d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.5660055267157714d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 103.85392050228103d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 11);
// 
//   }

  public void test205() {}
//   public void test205() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var8 = var0.nextUniform(0.3874438233115065d, 1.0d, true);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var0.nextGaussian(0.1919548516136001d, (-0.06187681393378908d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.2373187180057922d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 118.1016726482923d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.8468795198154837d);
// 
//   }

  public void test206() {}
//   public void test206() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c();
//     var1.setSeed(0L);
//     double var4 = var1.nextDouble();
//     var1.clear();
//     double var6 = var1.nextGaussian();
//     boolean var7 = var1.nextBoolean();
//     int[] var8 = new int[] { };
//     int[] var9 = null;
//     int var10 = org.apache.commons.math3.util.MathArrays.distance1(var8, var9);
//     org.apache.commons.math3.random.Well19937c var11 = new org.apache.commons.math3.random.Well19937c(var8);
//     int[] var12 = org.apache.commons.math3.util.MathArrays.copyOf(var8);
//     var1.setSeed(var12);
//     int var14 = org.apache.commons.math3.util.MathArrays.distance1(var0, var12);
// 
//   }

  public void test207() {}
//   public void test207() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     java.lang.String var10 = var0.nextSecureHexString(10);
//     double var12 = var0.nextT(9.160555011685411E-6d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var15 = var0.nextSecureLong(100L, 85L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.8842419417085474d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 105.58442977145707d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.054201734076825284d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "0"+ "'", var8.equals("0"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "274ad9a7d5"+ "'", var10.equals("274ad9a7d5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-1.3407807929942597E154d));
// 
//   }

  public void test208() {}
//   public void test208() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     var0.reSeedSecure();
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var9 = var0.nextInt(99, 10);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.19070761002894107d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 103.0850294443974d);
// 
//   }

  public void test209() {}
//   public void test209() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     var0.reSeedSecure();
//     var0.reSeed();
//     double var9 = var0.nextUniform(0.0015326576218039215d, 114.81244598869324d);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var0.nextHypergeometric(114470686, 7, 118517391);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.11142324741153166d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 122.84795738964556d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 62.48830306485994d);
// 
//   }

  public void test210() {}
//   public void test210() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var3 = var1.nextChiSquare(1.3650947445123496d);
//     double var6 = var1.nextWeibull(1.0d, 0.3874438233115065d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var1.nextWeibull(6.005006333616257d, (-0.33420519785105623d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.39540728312527196d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.3066727225025025d);
// 
//   }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(1024457413273955602L);

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var4 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var2, (java.lang.Number)0L);
    org.apache.commons.math3.exception.OutOfRangeException var8 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(-1.0f), (java.lang.Number)100.0f, (java.lang.Number)(short)0);
    java.lang.Number var9 = var8.getLo();
    var4.addSuppressed((java.lang.Throwable)var8);
    java.lang.Throwable[] var11 = var4.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var12 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)10.0d, (java.lang.Object[])var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + 100.0f+ "'", var9.equals(100.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }


    float[] var0 = null;
    float[] var1 = null;
    float[] var4 = new float[] { 100.0f, 10.0f};
    boolean var5 = org.apache.commons.math3.util.MathArrays.equals(var1, var4);
    float[] var9 = new float[] { 0.0f, (-1.0f), 0.0f};
    boolean var10 = org.apache.commons.math3.util.MathArrays.equals(var4, var9);
    float[] var11 = null;
    float[] var14 = new float[] { 100.0f, 10.0f};
    boolean var15 = org.apache.commons.math3.util.MathArrays.equals(var11, var14);
    float[] var19 = new float[] { 0.0f, (-1.0f), 0.0f};
    boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var14, var19);
    boolean var21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var9, var19);
    boolean var22 = org.apache.commons.math3.util.MathArrays.equals(var0, var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);

  }

  public void test214() {}
//   public void test214() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)1, (java.lang.Number)1L, (java.lang.Number)(short)(-1));
//     java.lang.Number var5 = var4.getHi();
//     java.lang.String var6 = var4.toString();
// 
//   }

  public void test215() {}
//   public void test215() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(0L);
//     java.lang.String var4 = var0.nextHexString(100);
//     java.lang.String var6 = var0.nextSecureHexString(1);
//     var0.reSeed((-1L));
//     var0.reSeed(0L);
//     double var13 = var0.nextWeibull(128.35556077963213d, 0.3874438233115065d);
//     var0.reSeedSecure(100L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"+ "'", var4.equals("7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "d"+ "'", var6.equals("d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.3883722390257413d);
// 
//   }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    java.lang.Object var6 = null;
    org.apache.commons.math3.util.Pair var7 = new org.apache.commons.math3.util.Pair((java.lang.Object)var3, var6);
    java.lang.Object var8 = var7.getFirst();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)1, (java.lang.Number)1L, (java.lang.Number)(short)(-1));
    java.lang.Number var5 = var4.getLo();
    java.lang.Number var6 = var4.getHi();
    java.lang.Number var7 = var4.getLo();
    java.lang.Number var8 = var4.getLo();
    java.lang.Number var9 = var4.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1L+ "'", var5.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (short)(-1)+ "'", var6.equals((short)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 1L+ "'", var7.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 1L+ "'", var8.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + 1L+ "'", var9.equals(1L));

  }

  public void test218() {}
//   public void test218() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     double var11 = var0.nextGamma(0.36157468479281d, 0.8376757571801716d);
//     var0.reSeed();
//     var0.reSeedSecure();
//     int[] var16 = var0.nextPermutation(48, 21);
//     int[] var17 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var18 = new org.apache.commons.math3.random.Well19937c(var17);
//     int[] var20 = org.apache.commons.math3.util.MathArrays.copyOf(var17, 100);
//     int[] var22 = org.apache.commons.math3.util.MathArrays.copyOf(var17, 10);
//     int[] var24 = org.apache.commons.math3.util.MathArrays.copyOf(var17, 99);
//     int[] var25 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var26 = new org.apache.commons.math3.random.Well19937c(var25);
//     int[] var27 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var28 = new org.apache.commons.math3.random.Well19937c(var27);
//     int[] var30 = org.apache.commons.math3.util.MathArrays.copyOf(var27, 100);
//     int var31 = org.apache.commons.math3.util.MathArrays.distance1(var25, var27);
//     int[] var32 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var33 = new org.apache.commons.math3.random.Well19937c(var32);
//     int var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var27, var32);
//     int var35 = org.apache.commons.math3.util.MathArrays.distanceInf(var17, var27);
//     int[] var36 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var37 = new org.apache.commons.math3.random.Well19937c(var36);
//     int var38 = org.apache.commons.math3.util.MathArrays.distance1(var27, var36);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var39 = org.apache.commons.math3.util.MathArrays.distance1(var16, var36);
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.04953337045992509d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 146.1179335798121d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.5934624588466451d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "f"+ "'", var8.equals("f"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.061295987856120185d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 0);
// 
//   }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(0L);
    double var4 = var0.nextExponential(0.7432416673360078d);
    double var6 = var0.nextT(0.035899776418132384d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var9 = var0.nextSecureLong(0L, (-1L));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.36157468479281d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 27.366395926482813d);

  }

  public void test220() {}
//   public void test220() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
//     var1.reSeed();
//     double var5 = var1.nextCauchy(82.45368975667407d, 82.45368975667407d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var8 = var1.nextInt(114470686, 19);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 278.6072454488515d);
// 
//   }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(7);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(0.044259860704679646d, 0.0d, 29.858607101538823d, 0.19576879474708697d, 0.092975850275352d, 0.03863055888020799d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 5.848975234153567d);

  }

  public void test223() {}
//   public void test223() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     int var5 = var0.nextBinomial(10, 0.03863055888020799d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var8 = var0.nextWeibull((-0.781949188060055d), (-2.2726334418422858d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-1.0659337401875393d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
// 
//   }

  public void test224() {}
//   public void test224() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(0L);
//     java.lang.String var4 = var0.nextHexString(100);
//     java.lang.String var6 = var0.nextSecureHexString(1);
//     var0.reSeed((-1L));
//     double var10 = var0.nextExponential(0.915778680097192d);
//     var0.reSeedSecure();
//     long var14 = var0.nextLong(10L, 1024457413273955602L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var17 = var0.nextSecureLong(1024457413273955602L, 477836925424025280L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"+ "'", var4.equals("7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "3"+ "'", var6.equals("3"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.3650947445123496d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 477836925424025280L);
// 
//   }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)111.37835237422031d);

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    double[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 10);
    double[] var6 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var6);
    boolean var8 = org.apache.commons.math3.util.MathArrays.equals(var1, var6);
    double[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 0);
    org.apache.commons.math3.util.MathArrays.OrderDirection var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var13 = org.apache.commons.math3.util.MathArrays.isMonotonic(var10, var11, false);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
    var1.reSeed();
    var1.reSeedSecure();
    var1.reSeedSecure();

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.6062775910181382d, (java.lang.Number)0.014210808548593164d, true);

  }

  public void test229() {}
//   public void test229() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var8 = var0.nextUniform(0.3874438233115065d, 1.0d, true);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var0.nextPascal(44, 121.1195598148109d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.33588528048964567d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 125.35529482007253d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.5321042367720068d);
// 
//   }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }


    java.lang.Number var1 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.5206144238498145d, var1, var2);
    java.lang.Number var4 = var3.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }


    org.apache.commons.math3.exception.MathInternalError var0 = new org.apache.commons.math3.exception.MathInternalError();

  }

  public void test232() {}
//   public void test232() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     double var11 = var0.nextGamma(0.36157468479281d, 0.8376757571801716d);
//     int var14 = var0.nextBinomial(1, 0.7432416673360078d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var17 = var0.nextLong(477836925424025280L, 434277157163744896L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-1.3336036323537055d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 111.71630085861149d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.6852061705305726E-7d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "c"+ "'", var8.equals("c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.11824201442709817d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1);
// 
//   }

  public void test233() {}
//   public void test233() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     double var5 = var0.nextGaussian(0.0032241185303045258d, 128.35556077963213d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var8 = var0.nextF((-0.019977037496912195d), 0.6466912681842636d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "608727f50b6b475caff5c0bafcce8f2f45833950628de71d0c987ed4d7849a9ea8dcdc8cdf00612974777aa99d17f13a8f1d"+ "'", var2.equals("608727f50b6b475caff5c0bafcce8f2f45833950628de71d0c987ed4d7849a9ea8dcdc8cdf00612974777aa99d17f13a8f1d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-23.70546641650837d));
// 
//   }

  public void test234() {}
//   public void test234() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     int var5 = var0.nextBinomial(0, 0.0d);
//     var0.reSeed(0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var0.nextCauchy(61.42740682362571d, (-2.2726334418422858d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "613f2881bc9804bdf8652bdb4101febf577cd4f3e01a092b5f56a083d57e11035cb5873803614e75346cb9562a980567c1f2"+ "'", var2.equals("613f2881bc9804bdf8652bdb4101febf577cd4f3e01a092b5f56a083d57e11035cb5873803614e75346cb9562a980567c1f2"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
// 
//   }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.03863055888020799d, (java.lang.Number)1.4924399031740692E10d, 48);

  }

  public void test236() {}
//   public void test236() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     int var5 = var0.nextBinomial(0, 0.0d);
//     var0.reSeed(0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var0.nextZipf((-1276125876), 0.5206144238498145d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "38974a8bb847facb26a0881114574b613af4fafd4a4ee94ef6ab610a633c60f383f7021601fa7ae1a364e68d3735fcc2a4fb"+ "'", var2.equals("38974a8bb847facb26a0881114574b613af4fafd4a4ee94ef6ab610a633c60f383f7021601fa7ae1a364e68d3735fcc2a4fb"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
// 
//   }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(0L);
    double var3 = var0.nextDouble();
    var0.setSeed(48);
    double var6 = var0.nextDouble();
    int var7 = var0.nextInt();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.7432416673360078d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.6062775910181382d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-2087310710));

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var3 = new java.lang.Object[] { 'a'};
    org.apache.commons.math3.exception.NotFiniteNumberException var4 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)(short)0, var3);
    double[] var6 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var6);
    org.apache.commons.math3.util.MathArrays.OrderDirection var8 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var6, var8, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var6);
    org.apache.commons.math3.util.Pair var12 = new org.apache.commons.math3.util.Pair((java.lang.Object)(short)0, (java.lang.Object)var6);
    org.apache.commons.math3.util.MathArrays.OrderDirection var13 = null;
    boolean var16 = org.apache.commons.math3.util.MathArrays.checkOrder(var6, var13, false, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(0L);
    double var3 = var0.nextDouble();
    var0.setSeed(48);
    double var6 = var0.nextDouble();
    boolean var7 = var0.nextBoolean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.7432416673360078d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.6062775910181382d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);

  }

  public void test240() {}
//   public void test240() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }
// 
// 
//     double[] var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     java.lang.Object[] var4 = new java.lang.Object[] { 'a'};
//     org.apache.commons.math3.exception.NotFiniteNumberException var5 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Number)(short)0, var4);
//     double[] var7 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var7);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var9 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var7, var9, false);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var7);
//     org.apache.commons.math3.util.Pair var13 = new org.apache.commons.math3.util.Pair((java.lang.Object)(short)0, (java.lang.Object)var7);
//     double var14 = org.apache.commons.math3.util.MathArrays.distanceInf(var0, var7);
// 
//   }

  public void test241() {}
//   public void test241() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     int var5 = var0.nextBinomial(10, 0.03863055888020799d);
//     int var8 = var0.nextSecureInt(7, 48);
//     double var12 = var0.nextUniform(0.0d, 0.7140368591421311d, false);
//     int var15 = var0.nextPascal(100, 0.026278128681618596d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.087939294119887d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.6988080512387618d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 3276);
// 
//   }

  public void test242() {}
//   public void test242() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }
// 
// 
//     long[] var0 = null;
//     org.apache.commons.math3.util.MathArrays.checkNonNegative(var0);
// 
//   }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(0L);
    var0.clear();
    int var5 = var0.nextInt(1);
    double[] var7 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var7);
    org.apache.commons.math3.util.MathArrays.OrderDirection var9 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var7, var9, false);
    double var12 = org.apache.commons.math3.util.MathArrays.safeNorm(var7);
    double[] var14 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var14);
    double[] var17 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var17);
    double[] var20 = org.apache.commons.math3.util.MathArrays.copyOf(var17, 10);
    double var21 = org.apache.commons.math3.util.MathArrays.distanceInf(var14, var20);
    double[] var22 = org.apache.commons.math3.util.MathArrays.ebeDivide(var7, var14);
    double var23 = org.apache.commons.math3.util.MathArrays.safeNorm(var14);
    double[] var25 = org.apache.commons.math3.util.MathArrays.copyOf(var14, 1);
    double[] var27 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var27);
    org.apache.commons.math3.util.MathArrays.OrderDirection var29 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var27, var29, false);
    double var32 = org.apache.commons.math3.util.MathArrays.safeNorm(var27);
    double[] var34 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var34);
    double[] var37 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var37);
    double[] var40 = org.apache.commons.math3.util.MathArrays.copyOf(var37, 10);
    double var41 = org.apache.commons.math3.util.MathArrays.distanceInf(var34, var40);
    double[] var42 = org.apache.commons.math3.util.MathArrays.ebeDivide(var27, var34);
    org.apache.commons.math3.util.MathArrays.checkOrder(var34);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.DiscreteRealDistribution var44 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var0, var25, var34);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test244() {}
//   public void test244() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(0L);
//     java.lang.String var4 = var0.nextHexString(100);
//     java.lang.String var6 = var0.nextSecureHexString(1);
//     var0.reSeed((-1L));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("93ff0bec62218a692a39f2f5f5dfba15b9ba6f1ab34d57952e719f9627d64e7eb374877ff554a02c1b2a96d3c26314e8ff3f", "org.apache.commons.math3.exception.NonMonotonicSequenceException: points 0 and 1 are not strictly increasing (-1 >= 1)");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"+ "'", var4.equals("7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "a"+ "'", var6.equals("a"));
// 
//   }

  public void test245() {}
//   public void test245() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     double var11 = var0.nextGamma(0.36157468479281d, 0.8376757571801716d);
//     int var14 = var0.nextBinomial(1, 0.7432416673360078d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var18 = var0.nextUniform(0.0d, (-0.019977037496912195d), true);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.06072530182614889d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 86.66052140658857d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.5043191657033527d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "a"+ "'", var8.equals("a"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.9884725348101022d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1);
// 
//   }

  public void test246() {}
//   public void test246() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }
// 
// 
//     double[] var1 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var1);
//     double[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 10);
//     double[] var6 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var6);
//     boolean var8 = org.apache.commons.math3.util.MathArrays.equals(var1, var6);
//     double[] var10 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var10);
//     double[] var13 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 10);
//     double var14 = org.apache.commons.math3.util.MathArrays.distanceInf(var6, var13);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var15 = null;
//     boolean var17 = org.apache.commons.math3.util.MathArrays.isMonotonic(var6, var15, true);
//     double[] var19 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var19);
//     double var21 = org.apache.commons.math3.util.MathArrays.distance1(var6, var19);
//     double[] var23 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var23);
//     double[] var26 = org.apache.commons.math3.util.MathArrays.copyOf(var23, 10);
//     double[] var28 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var28);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var30 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var28, var30, false);
//     boolean var33 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var26, var28);
//     double[] var34 = org.apache.commons.math3.util.MathArrays.ebeAdd(var6, var28);
//     double[][] var35 = null;
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var34, var35);
// 
//   }

  public void test247() {}
//   public void test247() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     var0.reSeedSecure();
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var9 = var0.nextInt(274497138, 48);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.03400976154524346d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 118.75482493290772d);
// 
//   }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double[] var18 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 10.0d);
    double[] var20 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var20);
    org.apache.commons.math3.util.MathArrays.OrderDirection var22 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var20, var22, false);
    double var25 = org.apache.commons.math3.util.MathArrays.safeNorm(var20);
    double[] var27 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var27);
    double[] var30 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var30);
    double[] var33 = org.apache.commons.math3.util.MathArrays.copyOf(var30, 10);
    double var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var27, var33);
    double[] var35 = org.apache.commons.math3.util.MathArrays.ebeDivide(var20, var27);
    double[] var37 = org.apache.commons.math3.util.MathArrays.normalizeArray(var20, 10.0d);
    double[] var39 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var39);
    double[] var42 = org.apache.commons.math3.util.MathArrays.copyOf(var39, 10);
    double[] var44 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var44);
    boolean var46 = org.apache.commons.math3.util.MathArrays.equals(var39, var44);
    double[] var48 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var48);
    double[] var51 = org.apache.commons.math3.util.MathArrays.copyOf(var48, 10);
    double var52 = org.apache.commons.math3.util.MathArrays.distanceInf(var44, var51);
    double var53 = org.apache.commons.math3.util.MathArrays.distanceInf(var37, var44);
    double[] var55 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var55);
    org.apache.commons.math3.util.MathArrays.OrderDirection var57 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var55, var57, false);
    double var60 = org.apache.commons.math3.util.MathArrays.distanceInf(var44, var55);
    double[] var62 = org.apache.commons.math3.util.MathArrays.normalizeArray(var55, 98.30741799725186d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var63 = org.apache.commons.math3.util.MathArrays.linearCombination(var18, var55);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 11.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);

  }

  public void test249() {}
//   public void test249() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var0.nextPascal(44, 1.4480256314873523d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.2441311647534234d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 144.47739020164457d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.018034797215949326d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "a"+ "'", var8.equals("a"));
// 
//   }

  public void test250() {}
//   public void test250() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     double var5 = var0.nextWeibull(110.0d, 0.3874438233115065d);
//     double var8 = var0.nextBeta(140.37260799449047d, 0.5831186213437698d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "cd2708f57f357363327f67d2cd0b9c35dfc8c0eb2fda19605344b917729d5b5200ff3dd2d8667f29115ca8be1ebb0aaf4ca6"+ "'", var2.equals("cd2708f57f357363327f67d2cd0b9c35dfc8c0eb2fda19605344b917729d5b5200ff3dd2d8667f29115ca8be1ebb0aaf4ca6"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.39272166588919205d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.9886699244594495d);
// 
//   }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(0L);
    double var3 = var0.nextDouble();
    var0.clear();
    double var5 = var0.nextGaussian();
    boolean var6 = var0.nextBoolean();
    double var7 = var0.nextDouble();
    org.apache.commons.math3.random.RandomDataImpl var8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var11 = var8.nextWeibull((-0.9952372506839855d), 0.13606824750935648d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.7432416673360078d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1.2016184922621251d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.3874438233115065d);

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(274497138, (-1276125876));

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double[] var18 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var18);
    org.apache.commons.math3.util.MathArrays.OrderDirection var20 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var18, var20, false);
    double var23 = org.apache.commons.math3.util.MathArrays.safeNorm(var18);
    double[] var25 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    double[] var28 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var28);
    double[] var31 = org.apache.commons.math3.util.MathArrays.copyOf(var28, 10);
    double var32 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var31);
    double[] var33 = org.apache.commons.math3.util.MathArrays.ebeDivide(var18, var25);
    org.apache.commons.math3.util.MathArrays.OrderDirection var34 = null;
    boolean var36 = org.apache.commons.math3.util.MathArrays.isMonotonic(var18, var34, true);
    double[] var37 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var8, var18);
    double[] var39 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var39);
    org.apache.commons.math3.util.MathArrays.OrderDirection var41 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var39, var41, false);
    double var44 = org.apache.commons.math3.util.MathArrays.safeNorm(var39);
    double[] var46 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var46);
    double[] var49 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var49);
    double[] var52 = org.apache.commons.math3.util.MathArrays.copyOf(var49, 10);
    double var53 = org.apache.commons.math3.util.MathArrays.distanceInf(var46, var52);
    double[] var54 = org.apache.commons.math3.util.MathArrays.ebeDivide(var39, var46);
    double var55 = org.apache.commons.math3.util.MathArrays.safeNorm(var46);
    double[] var57 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var57);
    org.apache.commons.math3.util.MathArrays.OrderDirection var59 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var57, var59, false);
    double var62 = org.apache.commons.math3.util.MathArrays.safeNorm(var57);
    double[] var64 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var64);
    double[] var67 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var67);
    double[] var70 = org.apache.commons.math3.util.MathArrays.copyOf(var67, 10);
    double var71 = org.apache.commons.math3.util.MathArrays.distanceInf(var64, var70);
    double[] var72 = org.apache.commons.math3.util.MathArrays.ebeDivide(var57, var64);
    org.apache.commons.math3.util.MathArrays.OrderDirection var73 = null;
    boolean var75 = org.apache.commons.math3.util.MathArrays.isMonotonic(var57, var73, true);
    double var76 = org.apache.commons.math3.util.MathArrays.distance1(var46, var57);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var77 = org.apache.commons.math3.util.MathArrays.linearCombination(var8, var46);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == 0.0d);

  }

  public void test254() {}
//   public void test254() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }
// 
// 
//     double[] var0 = null;
//     org.apache.commons.math3.util.MathArrays.OrderDirection var1 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var0, var1, false);
// 
//   }

  public void test255() {}
//   public void test255() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     java.lang.String var10 = var0.nextSecureHexString(10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var0.nextUniform(112.79893611497971d, 5.610049266766251E-8d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.7665998846854355d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 111.12583746266272d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.5177357039109082d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "6"+ "'", var8.equals("6"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "a9c84739b2"+ "'", var10.equals("a9c84739b2"));
// 
//   }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double var17 = org.apache.commons.math3.util.MathArrays.safeNorm(var8);
    double[] var19 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var19);
    org.apache.commons.math3.util.MathArrays.OrderDirection var21 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var19, var21, false);
    double var24 = org.apache.commons.math3.util.MathArrays.safeNorm(var19);
    double[] var26 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var26);
    double[] var29 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var29);
    double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 10);
    double var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var26, var32);
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeDivide(var19, var26);
    org.apache.commons.math3.util.MathArrays.OrderDirection var35 = null;
    boolean var37 = org.apache.commons.math3.util.MathArrays.isMonotonic(var19, var35, true);
    double var38 = org.apache.commons.math3.util.MathArrays.distance1(var8, var19);
    double[] var40 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var40);
    org.apache.commons.math3.util.MathArrays.OrderDirection var42 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var40, var42, false);
    double var45 = org.apache.commons.math3.util.MathArrays.safeNorm(var40);
    org.apache.commons.math3.util.MathArrays.OrderDirection var46 = null;
    boolean var48 = org.apache.commons.math3.util.MathArrays.isMonotonic(var40, var46, false);
    double[] var50 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var50);
    org.apache.commons.math3.util.MathArrays.OrderDirection var52 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var50, var52, false);
    double var55 = org.apache.commons.math3.util.MathArrays.safeNorm(var50);
    double[] var57 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var57);
    double[] var60 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var60);
    double[] var63 = org.apache.commons.math3.util.MathArrays.copyOf(var60, 10);
    double var64 = org.apache.commons.math3.util.MathArrays.distanceInf(var57, var63);
    double[] var65 = org.apache.commons.math3.util.MathArrays.ebeDivide(var50, var57);
    double[] var67 = org.apache.commons.math3.util.MathArrays.normalizeArray(var50, 10.0d);
    double[] var68 = org.apache.commons.math3.util.MathArrays.copyOf(var50);
    double[] var69 = org.apache.commons.math3.util.MathArrays.ebeDivide(var40, var50);
    double[] var70 = org.apache.commons.math3.util.MathArrays.ebeAdd(var8, var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);

  }

  public void test257() {}
//   public void test257() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(0L);
//     java.lang.String var4 = var0.nextHexString(100);
//     java.lang.String var6 = var0.nextSecureHexString(1);
//     var0.reSeed((-1L));
//     double var10 = var0.nextExponential(0.915778680097192d);
//     var0.reSeedSecure();
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var15 = var0.nextLong(434277157163744896L, (-1L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"+ "'", var4.equals("7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "8"+ "'", var6.equals("8"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.3650947445123496d);
// 
//   }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkPositive(var1);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test259() {}
//   public void test259() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var5 = var0.nextF(0.044259860704679646d, 0.19576879474708697d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("5d405ba4cf1e23d400a3052fe75370b4a291b86079683fd5cf156e1d53727a91b267cf3799e43780e68577f6e7821a6ac82d", "b");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.028794237585292346d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.3322985844791263E-9d);
// 
//   }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double[] var18 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var18);
    org.apache.commons.math3.util.MathArrays.OrderDirection var20 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var18, var20, false);
    double var23 = org.apache.commons.math3.util.MathArrays.safeNorm(var18);
    double[] var25 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    double[] var28 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var28);
    double[] var31 = org.apache.commons.math3.util.MathArrays.copyOf(var28, 10);
    double var32 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var31);
    double[] var33 = org.apache.commons.math3.util.MathArrays.ebeDivide(var18, var25);
    double var34 = org.apache.commons.math3.util.MathArrays.safeNorm(var25);
    double[] var36 = org.apache.commons.math3.util.MathArrays.copyOf(var25, 1);
    double[] var38 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var38);
    org.apache.commons.math3.util.MathArrays.OrderDirection var40 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var38, var40, false);
    double var43 = org.apache.commons.math3.util.MathArrays.safeNorm(var38);
    double[] var45 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var45);
    double[] var48 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var48);
    double[] var51 = org.apache.commons.math3.util.MathArrays.copyOf(var48, 10);
    double var52 = org.apache.commons.math3.util.MathArrays.distanceInf(var45, var51);
    double[] var53 = org.apache.commons.math3.util.MathArrays.ebeDivide(var38, var45);
    double[] var55 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var55);
    org.apache.commons.math3.util.MathArrays.OrderDirection var57 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var55, var57, false);
    double var60 = org.apache.commons.math3.util.MathArrays.safeNorm(var55);
    double[] var62 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var62);
    double[] var65 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var65);
    double[] var68 = org.apache.commons.math3.util.MathArrays.copyOf(var65, 10);
    double var69 = org.apache.commons.math3.util.MathArrays.distanceInf(var62, var68);
    double[] var70 = org.apache.commons.math3.util.MathArrays.ebeDivide(var55, var62);
    double[] var72 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var72);
    org.apache.commons.math3.util.MathArrays.OrderDirection var74 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var72, var74, false);
    double var77 = org.apache.commons.math3.util.MathArrays.safeNorm(var72);
    org.apache.commons.math3.util.MathArrays.OrderDirection var78 = null;
    boolean var80 = org.apache.commons.math3.util.MathArrays.isMonotonic(var72, var78, false);
    double[][] var81 = new double[][] { var72};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var55, var81);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var53, var81);
    double[] var84 = org.apache.commons.math3.util.MathArrays.ebeAdd(var25, var53);
    double var85 = org.apache.commons.math3.util.MathArrays.distance(var1, var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 1.0d);

  }

  public void test261() {}
//   public void test261() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 36);
// 
//   }

  public void test262() {}
//   public void test262() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     double var11 = var0.nextGamma(0.36157468479281d, 0.8376757571801716d);
//     var0.reSeed();
//     var0.reSeedSecure();
//     long var16 = var0.nextLong((-1L), 10L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var18 = var0.nextHexString(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-1.786261522788588d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 119.7625010834664d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.9687886658764205d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "0"+ "'", var8.equals("0"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 3.244201245187834E-5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 6L);
// 
//   }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(0L);
    double var4 = var0.nextExponential(0.7432416673360078d);
    double var6 = var0.nextT(0.035899776418132384d);
    long var8 = var0.nextPoisson(7.277800330956172E-5d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var11 = var0.nextBinomial(31, 79.12714248109548d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.36157468479281d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 27.366395926482813d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0L);

  }

  public void test264() {}
//   public void test264() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     java.lang.String var10 = var0.nextSecureHexString(10);
//     int var13 = var0.nextInt(0, 100);
//     org.apache.commons.math3.distribution.RealDistribution var14 = null;
//     double var15 = var0.nextInversionDeviate(var14);
// 
//   }

  public void test265() {}
//   public void test265() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }
// 
// 
//     double[] var1 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var1);
//     double[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 10);
//     double[] var6 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var6);
//     boolean var8 = org.apache.commons.math3.util.MathArrays.equals(var1, var6);
//     double[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 0);
//     double[] var11 = null;
//     double var12 = org.apache.commons.math3.util.MathArrays.distance(var1, var11);
// 
//   }

  public void test266() {}
//   public void test266() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }
// 
// 
//     double[] var0 = null;
//     double[] var2 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var2);
//     double[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var2, 10);
//     double[] var7 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var7);
//     boolean var9 = org.apache.commons.math3.util.MathArrays.equals(var2, var7);
//     double[] var11 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var11);
//     double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
//     double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var7, var14);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var16 = null;
//     boolean var18 = org.apache.commons.math3.util.MathArrays.isMonotonic(var7, var16, true);
//     double[] var20 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var20);
//     double var22 = org.apache.commons.math3.util.MathArrays.distance1(var7, var20);
//     double[] var23 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var0, var7);
// 
//   }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)0.3633053259796431d);

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0d, (java.lang.Number)(byte)(-1), 1);
    int var4 = var3.getIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    long[] var2 = new long[] { };
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var2);
    long[][] var4 = new long[][] { var2};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var4);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var4);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var4);
    org.apache.commons.math3.exception.MathIllegalArgumentException var8 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.MathIllegalArgumentException var9 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var4);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1024457413273955602L, var2, true);
    boolean var5 = var4.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test271() {}
//   public void test271() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 0, 274497138);
// 
//   }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(0L);
    double var3 = var0.nextDouble();
    var0.clear();
    double var5 = var0.nextGaussian();
    var0.setSeed(0);
    double var8 = var0.nextDouble();
    var0.setSeed(85L);
    int[] var11 = null;
    var0.setSeed(var11);
    var0.setSeed(95L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.7432416673360078d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1.2016184922621251d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.9775554539871507d);

  }

  public void test273() {}
//   public void test273() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(0L);
//     double var4 = var0.nextExponential(0.7432416673360078d);
//     int var7 = var0.nextSecureInt(1, 100);
//     double var10 = var0.nextWeibull(10.0d, 114.23712557956448d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var0.nextPascal(0, 142.33436650128448d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.36157468479281d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 112.98997911642695d);
// 
//   }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0d, (java.lang.Number)(byte)(-1), 1);
    boolean var4 = var3.getStrict();
    java.lang.String var5 = var3.toString();
    java.lang.Number var6 = var3.getPrevious();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "org.apache.commons.math3.exception.NonMonotonicSequenceException: points 0 and 1 are not strictly increasing (-1 >= 1)"+ "'", var5.equals("org.apache.commons.math3.exception.NonMonotonicSequenceException: points 0 and 1 are not strictly increasing (-1 >= 1)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (byte)(-1)+ "'", var6.equals((byte)(-1)));

  }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }


    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)110.0d, (java.lang.Number)0.13357031857865004d, 48, var3, false);

  }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-1.0d), false);
    java.lang.Number var4 = var3.getMax();
    boolean var5 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (-1.0d)+ "'", var4.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double[] var18 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var18);
    org.apache.commons.math3.util.MathArrays.OrderDirection var20 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var18, var20, false);
    double var23 = org.apache.commons.math3.util.MathArrays.safeNorm(var18);
    double[] var25 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    double[] var28 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var28);
    double[] var31 = org.apache.commons.math3.util.MathArrays.copyOf(var28, 10);
    double var32 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var31);
    double[] var33 = org.apache.commons.math3.util.MathArrays.ebeDivide(var18, var25);
    double[] var35 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var35);
    org.apache.commons.math3.util.MathArrays.OrderDirection var37 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var35, var37, false);
    double var40 = org.apache.commons.math3.util.MathArrays.safeNorm(var35);
    org.apache.commons.math3.util.MathArrays.OrderDirection var41 = null;
    boolean var43 = org.apache.commons.math3.util.MathArrays.isMonotonic(var35, var41, false);
    double[][] var44 = new double[][] { var35};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var18, var44);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var16, var44);
    double[] var48 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var48);
    double[] var51 = org.apache.commons.math3.util.MathArrays.copyOf(var48, 10);
    double[] var53 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var53);
    boolean var55 = org.apache.commons.math3.util.MathArrays.equals(var48, var53);
    double[] var57 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var57);
    double[] var60 = org.apache.commons.math3.util.MathArrays.copyOf(var57, 10);
    double var61 = org.apache.commons.math3.util.MathArrays.distanceInf(var53, var60);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var62 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var16, var60);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 0.0d);

  }

  public void test278() {}
//   public void test278() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }
// 
// 
//     int[] var0 = null;
//     int[] var1 = new int[] { };
//     int[] var2 = null;
//     int var3 = org.apache.commons.math3.util.MathArrays.distance1(var1, var2);
//     org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(var1);
//     int[] var6 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 0);
//     int var7 = org.apache.commons.math3.util.MathArrays.distance1(var0, var1);
// 
//   }

  public void test279() {}
//   public void test279() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var6 = var0.nextHypergeometric(7, 44, (-1));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.4372387087685237d));
// 
//   }

  public void test280() {}
//   public void test280() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }
// 
// 
//     int[] var0 = new int[] { };
//     int[] var1 = null;
//     int var2 = org.apache.commons.math3.util.MathArrays.distance1(var0, var1);
//     org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var4 = var3.nextGaussian();
//     int[] var5 = null;
//     var3.setSeed(var5);
//     double var7 = var3.nextDouble();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.2478736222527921d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.94947016522495d);
// 
//   }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(0L);
    double var3 = var0.nextDouble();
    var0.clear();
    double var5 = var0.nextGaussian();
    boolean var6 = var0.nextBoolean();
    double var7 = var0.nextDouble();
    double var8 = var0.nextGaussian();
    double var9 = var0.nextGaussian();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.7432416673360078d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1.2016184922621251d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.3874438233115065d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-0.781949188060055d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-2.422255593706966d));

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(0L);
    double var4 = var0.nextExponential(0.7432416673360078d);
    var0.reSeedSecure();
    double var8 = var0.nextF(101.79109515357918d, 0.6116146111830432d);
    var0.reSeed(434277157163744896L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSecureAlgorithm("a", "6");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.36157468479281d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 7.890608942511265d);

  }

  public void test283() {}
//   public void test283() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     double var5 = var0.nextWeibull(110.0d, 0.3874438233115065d);
//     var0.reSeedSecure();
//     var0.reSeedSecure(95L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var0.nextBeta((-0.019977037496912195d), 114.18897334891658d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "8be8cfcdbe6658cd592b3f342ef9c03ac32fcfc09b74cd8b1c7769a30b4c7404a65848d3ebf1331a301780d1fe61ecd91d85"+ "'", var2.equals("8be8cfcdbe6658cd592b3f342ef9c03ac32fcfc09b74cd8b1c7769a30b4c7404a65848d3ebf1331a301780d1fe61ecd91d85"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.38732224403279175d);
// 
//   }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 33787721, 100);
    int var4 = var3.getDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 100);

  }

  public void test285() {}
//   public void test285() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var8 = var0.nextT((-1.2167966023461996d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-1.551363048413827d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 117.46854909555512d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.004252245205148698d);
// 
//   }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }


    int[] var0 = new int[] { };
    int[] var1 = null;
    int var2 = org.apache.commons.math3.util.MathArrays.distance1(var0, var1);
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var0);
    double var4 = var3.nextGaussian();
    long var5 = var3.nextLong();
    double var6 = var3.nextGaussian();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.2478736222527921d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1024457413273955602L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.4887708362197951d);

  }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0.05609443507672968d);
    java.lang.String var2 = var1.toString();
    boolean var3 = var1.getBoundIsAllowed();
    boolean var4 = var1.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "org.apache.commons.math3.exception.NotStrictlyPositiveException: 0.056 is smaller than, or equal to, the minimum (0)"+ "'", var2.equals("org.apache.commons.math3.exception.NotStrictlyPositiveException: 0.056 is smaller than, or equal to, the minimum (0)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(0L);
    double var3 = var0.nextDouble();
    var0.clear();
    double var5 = var0.nextGaussian();
    boolean var6 = var0.nextBoolean();
    double var7 = var0.nextDouble();
    var0.setSeed(100);
    var0.setSeed(0);
    boolean var12 = var0.nextBoolean();
    int var13 = var0.nextInt();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.7432416673360078d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1.2016184922621251d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.3874438233115065d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 60481539);

  }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.5206144238498145d, (java.lang.Number)114.81244598869324d, (java.lang.Number)101.29456331084373d);
    org.apache.commons.math3.exception.NotStrictlyPositiveException var5 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0.05609443507672968d);
    var3.addSuppressed((java.lang.Throwable)var5);
    boolean var7 = var5.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }


    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Object[] var3 = new java.lang.Object[] { (short)10};
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError(var1, var3);
    org.apache.commons.math3.exception.NotFiniteNumberException var5 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)0.04320404459989801d, var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test291() {}
//   public void test291() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     java.lang.String var10 = var0.nextSecureHexString(1);
//     double var13 = var0.nextCauchy(1.4924399031740692E10d, 0.6116146111830432d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var0.nextExponential((-0.9952372506839855d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.6776407490027875d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 105.28691424981353d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.022007384160239063d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "2"+ "'", var8.equals("2"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "3"+ "'", var10.equals("3"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.4924399031810497E10d);
// 
//   }

  public void test292() {}
//   public void test292() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }
// 
// 
//     double[] var1 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var1);
//     double[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 10);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var5 = null;
//     boolean var8 = org.apache.commons.math3.util.MathArrays.checkOrder(var4, var5, false, true);
// 
//   }

  public void test293() {}
//   public void test293() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(0L);
//     java.lang.String var4 = var0.nextHexString(100);
//     java.lang.String var6 = var0.nextSecureHexString(1);
//     var0.reSeed((-1L));
//     long var11 = var0.nextLong(0L, 95L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"+ "'", var4.equals("7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "f"+ "'", var6.equals("f"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 22L);
// 
//   }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var4 = var0.nextSecureLong(2L, 2L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)(short)10);

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1.9081813459147294E-5d, (java.lang.Number)(-0.1943431852363057d), true);

  }

  public void test297() {}
//   public void test297() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(0L);
//     double var4 = var0.nextExponential(0.7432416673360078d);
//     int var7 = var0.nextSecureInt(1, 100);
//     double var10 = var0.nextWeibull(10.0d, 114.23712557956448d);
//     double var13 = var0.nextCauchy(0.41852678359398926d, 1.4480256314873523d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var17 = var0.nextHypergeometric(19, 114470686, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.36157468479281d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 90);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 112.98997911642695d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-0.2748957434128349d));
// 
//   }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Object[] var7 = new java.lang.Object[] { 'a'};
    org.apache.commons.math3.exception.NotFiniteNumberException var8 = new org.apache.commons.math3.exception.NotFiniteNumberException(var4, (java.lang.Number)(short)0, var7);
    org.apache.commons.math3.exception.NotFiniteNumberException var9 = new org.apache.commons.math3.exception.NotFiniteNumberException(var2, (java.lang.Number)10L, var7);
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, var7);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var14 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0d, (java.lang.Number)(byte)(-1), 1);
    boolean var15 = var14.getStrict();
    java.lang.String var16 = var14.toString();
    var10.addSuppressed((java.lang.Throwable)var14);
    java.lang.Throwable[] var18 = var14.getSuppressed();
    org.apache.commons.math3.exception.NullArgumentException var19 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + "org.apache.commons.math3.exception.NonMonotonicSequenceException: points 0 and 1 are not strictly increasing (-1 >= 1)"+ "'", var16.equals("org.apache.commons.math3.exception.NonMonotonicSequenceException: points 0 and 1 are not strictly increasing (-1 >= 1)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test299() {}
//   public void test299() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var11 = var0.nextSecureLong(22L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.06318144363917982d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 100.78789766479716d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.21914894760579193d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "0"+ "'", var8.equals("0"));
// 
//   }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(75L);
    var1.clear();

  }

  public void test301() {}
//   public void test301() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     double var8 = var0.nextT(0.4887708362197951d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.4054370868227162d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 114.66035331336151d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.6171342864038818d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.0893641512959175d);
// 
//   }

  public void test302() {}
//   public void test302() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(0L);
//     double var4 = var0.nextExponential(0.7432416673360078d);
//     int var7 = var0.nextSecureInt(1, 100);
//     double var10 = var0.nextWeibull(10.0d, 114.23712557956448d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var13 = var0.nextSecureLong(100L, 68L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.36157468479281d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 112.98997911642695d);
// 
//   }

  public void test303() {}
//   public void test303() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 9);
// 
//   }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var3 = new java.lang.Object[] { 'a'};
    org.apache.commons.math3.exception.NotFiniteNumberException var4 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)(short)0, var3);
    double[] var6 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var6);
    org.apache.commons.math3.util.MathArrays.OrderDirection var8 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var6, var8, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var6);
    org.apache.commons.math3.util.Pair var12 = new org.apache.commons.math3.util.Pair((java.lang.Object)(short)0, (java.lang.Object)var6);
    java.lang.Object var13 = var12.getValue();
    org.apache.commons.math3.util.Pair var14 = new org.apache.commons.math3.util.Pair(var12);
    java.lang.Object var15 = var14.getKey();
    java.lang.Object var16 = var14.getValue();
    org.apache.commons.math3.util.Pair var17 = new org.apache.commons.math3.util.Pair(var14);
    java.lang.Object var18 = var17.getSecond();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + (short)0+ "'", var15.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test305() {}
//   public void test305() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     int var5 = var0.nextBinomial(10, 0.03863055888020799d);
//     int var8 = var0.nextSecureInt(7, 48);
//     double var12 = var0.nextUniform(0.0d, 0.7140368591421311d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var15 = var0.nextLong(95L, 75L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.9654123085569277d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.18145507047116d);
// 
//   }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0L);

  }

  public void test307() {}
//   public void test307() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     java.lang.String var10 = var0.nextSecureHexString(1);
//     double var13 = var0.nextCauchy(1.4924399031740692E10d, 0.6116146111830432d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("e", "7b8bf3fbd3cb8e00f4f6d09010c905085f2d3cdbb4a163336279773dccb66a187598a2fb8bc14cbca00b3ec2ab12100ab19d");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.13951859512205672d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 101.7550844186006d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.01495966654098427d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "1"+ "'", var8.equals("1"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "2"+ "'", var10.equals("2"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.4924399031263432E10d);
// 
//   }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.0d, (java.lang.Number)11787.308968688245d, false);

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }


    long[] var0 = new long[] { };
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var0);
    long[][] var2 = new long[][] { var0};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var2);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(42, 0);

  }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(0.4243146458091146d, (-0.1943431852363057d), 98.30741799725186d, (-1.0572941331941332d), (-0.3251554907629271d), 0.29461270966732284d, 0.0d, 0.21348139648244788d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-104.11811389796357d));

  }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(0L);
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c();
    var3.setSeed(0L);
    double var6 = var3.nextDouble();
    var3.setSeed(48);
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c();
    var9.setSeed(0L);
    double var12 = var9.nextDouble();
    var9.clear();
    byte[] var17 = new byte[] { (byte)0, (byte)(-1), (byte)10};
    var9.nextBytes(var17);
    var3.nextBytes(var17);
    var0.nextBytes(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.7432416673360078d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.7432416673360078d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(0L);
    double var4 = var0.nextExponential(0.7432416673360078d);
    var0.reSeedSecure();
    double var8 = var0.nextF(101.79109515357918d, 0.6116146111830432d);
    var0.reSeed(434277157163744896L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var13 = var0.nextGaussian(0.0d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.36157468479281d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 7.890608942511265d);

  }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)1, (java.lang.Number)1L, (java.lang.Number)(short)(-1));
    java.lang.Number var5 = var4.getLo();
    java.lang.Number var6 = var4.getLo();
    java.lang.Number var7 = var4.getLo();
    java.lang.Number var8 = var4.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1L+ "'", var5.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 1L+ "'", var6.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 1L+ "'", var7.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 1L+ "'", var8.equals(1L));

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(0L);
    double var3 = var0.nextDouble();
    var0.clear();
    double var5 = var0.nextGaussian();
    boolean var6 = var0.nextBoolean();
    double var7 = var0.nextDouble();
    double var8 = var0.nextGaussian();
    float var9 = var0.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.7432416673360078d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1.2016184922621251d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.3874438233115065d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-0.781949188060055d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.40733504f);

  }

  public void test316() {}
//   public void test316() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     double var11 = var0.nextGamma(0.36157468479281d, 0.8376757571801716d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var14 = var0.nextPermutation((-1), 80);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.6834567140991691d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 111.56599118809757d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.009568756803416824d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "7"+ "'", var8.equals("7"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.09912752124714595d);
// 
//   }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = null;
    boolean var9 = org.apache.commons.math3.util.MathArrays.isMonotonic(var1, var7, false);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    org.apache.commons.math3.util.MathArrays.OrderDirection var13 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var11, var13, false);
    double var16 = org.apache.commons.math3.util.MathArrays.safeNorm(var11);
    double[] var18 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var18);
    double[] var21 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var21);
    double[] var24 = org.apache.commons.math3.util.MathArrays.copyOf(var21, 10);
    double var25 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var24);
    double[] var26 = org.apache.commons.math3.util.MathArrays.ebeDivide(var11, var18);
    double[] var28 = org.apache.commons.math3.util.MathArrays.normalizeArray(var11, 10.0d);
    double[] var29 = org.apache.commons.math3.util.MathArrays.copyOf(var11);
    double[] var30 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var11);
    org.apache.commons.math3.util.MathArrays.OrderDirection var31 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var31, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test318() {}
//   public void test318() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     var0.reSeedSecure();
//     var0.reSeed();
//     double var9 = var0.nextUniform(0.0015326576218039215d, 114.81244598869324d);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var0.nextPascal(60481539, (-1.0790847054779544d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-1.1720082834602397d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 108.18360012162529d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 35.964791867462246d);
// 
//   }

  public void test319() {}
//   public void test319() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 80, 43);
// 
//   }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }


    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.lang.Object[] var4 = new java.lang.Object[] { 1.0f};
    org.apache.commons.math3.exception.MathArithmeticException var5 = new org.apache.commons.math3.exception.MathArithmeticException(var2, var4);
    org.apache.commons.math3.exception.MathIllegalArgumentException var6 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, var4);
    org.apache.commons.math3.exception.NotFiniteNumberException var7 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-0.9495266881108861d), var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test321() {}
//   public void test321() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(7, 312574995);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var6 = var0.nextCauchy(101.44314796560174d, (-1.4499579992030152d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 178525042);
// 
//   }

  public void test322() {}
//   public void test322() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     var0.reSeedSecure();
//     var0.reSeed();
//     int var9 = var0.nextZipf(21, 0.044259860704679646d);
//     java.lang.String var11 = var0.nextSecureHexString(48);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("5", "org.apache.commons.math3.exception.NonMonotonicSequenceException: points 9 and 10 are not strictly decreasing (null <= 0)");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-1.2121422191691096d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 117.30797836099067d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "4ed267cb84d15a615e8f1116c372044ddf369e2757673c67"+ "'", var11.equals("4ed267cb84d15a615e8f1116c372044ddf369e2757673c67"));
// 
//   }

  public void test323() {}
//   public void test323() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     double var11 = var0.nextGamma(0.36157468479281d, 0.8376757571801716d);
//     var0.reSeed();
//     var0.reSeedSecure();
//     double var16 = var0.nextCauchy(99.15680865820634d, 54.76711054963606d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var19 = var0.nextSecureInt(36, 7);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.5374074758843055d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 108.1399393029758d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.445101705774745E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "d"+ "'", var8.equals("d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.7418301927976371d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 139.99910502918772d);
// 
//   }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)(-2.2726334418422858d));

  }

  public void test325() {}
//   public void test325() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(0L);
//     double var4 = var0.nextExponential(0.7432416673360078d);
//     int var7 = var0.nextSecureInt(1, 100);
//     java.lang.String var9 = var0.nextHexString(7);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var0.nextT((-104.11811389796357d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.36157468479281d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "67c8011"+ "'", var9.equals("67c8011"));
// 
//   }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    java.lang.Object[] var8 = new java.lang.Object[] { 'a'};
    org.apache.commons.math3.exception.NotFiniteNumberException var9 = new org.apache.commons.math3.exception.NotFiniteNumberException(var5, (java.lang.Number)(short)0, var8);
    org.apache.commons.math3.exception.NotFiniteNumberException var10 = new org.apache.commons.math3.exception.NotFiniteNumberException(var3, (java.lang.Number)10L, var8);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, var8);
    org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, var8);
    org.apache.commons.math3.exception.MathInternalError var13 = new org.apache.commons.math3.exception.MathInternalError(var0, var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test327() {}
//   public void test327() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     org.apache.commons.math3.exception.util.Localizable var4 = null;
//     java.lang.Object[] var7 = new java.lang.Object[] { 'a'};
//     org.apache.commons.math3.exception.NotFiniteNumberException var8 = new org.apache.commons.math3.exception.NotFiniteNumberException(var4, (java.lang.Number)(short)0, var7);
//     org.apache.commons.math3.exception.NotFiniteNumberException var9 = new org.apache.commons.math3.exception.NotFiniteNumberException(var2, (java.lang.Number)10L, var7);
//     org.apache.commons.math3.exception.NotFiniteNumberException var10 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)114.23712557956448d, var7);
//     org.apache.commons.math3.exception.util.ExceptionContext var11 = var10.getContext();
//     java.lang.String var12 = var10.toString();
// 
//   }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.999946785885159d, (java.lang.Number)(-0.043481143175376734d), true);
    java.lang.Number var4 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (-0.043481143175376734d)+ "'", var4.equals((-0.043481143175376734d)));

  }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    int[] var2 = new int[] { };
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var2);
    int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var2, 100);
    int var6 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    int[] var7 = org.apache.commons.math3.util.MathArrays.copyOf(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test330() {}
//   public void test330() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(0L);
//     java.lang.String var4 = var0.nextHexString(100);
//     java.lang.String var6 = var0.nextSecureHexString(1);
//     var0.reSeed((-1L));
//     double var10 = var0.nextExponential(0.915778680097192d);
//     var0.reSeedSecure();
//     long var14 = var0.nextLong(10L, 1024457413273955602L);
//     double var17 = var0.nextWeibull(100.0d, 1.2933613415363947d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var20 = var0.nextSecureLong(0L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"+ "'", var4.equals("7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "c"+ "'", var6.equals("c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.3650947445123496d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 477836925424025280L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.2756063300353422d);
// 
//   }

  public void test331() {}
//   public void test331() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     java.lang.String var10 = var0.nextSecureHexString(1);
//     double var13 = var0.nextCauchy(1.4924399031740692E10d, 0.6116146111830432d);
//     org.apache.commons.math3.distribution.RealDistribution var14 = null;
//     double var15 = var0.nextInversionDeviate(var14);
// 
//   }

  public void test332() {}
//   public void test332() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(0L);
//     java.lang.String var4 = var0.nextHexString(100);
//     java.lang.String var6 = var0.nextSecureHexString(1);
//     double var9 = var0.nextCauchy((-0.4076885612903701d), 140.37260799449047d);
//     long var12 = var0.nextSecureLong(10L, 95L);
//     var0.reSeed(85L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"+ "'", var4.equals("7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "9"+ "'", var6.equals("9"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-132.37300774287698d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 86L);
// 
//   }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(-1L));

  }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)3.688927398073491E-4d, (java.lang.Number)1.0d, false);

  }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeedSecure();
    var0.reSeed(100L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSecureAlgorithm("f78407ea26d642b35647f09ff4971d4b74811e520d73dcbf", "f78407ea26d642b35647f09ff4971d4b74811e520d73dcbf");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }

  }

  public void test336() {}
//   public void test336() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var3 = var1.nextChiSquare(1.3650947445123496d);
//     double var6 = var1.nextWeibull(1.0d, 0.3874438233115065d);
//     long var9 = var1.nextSecureLong(1L, 10L);
//     int var13 = var1.nextHypergeometric(42, 0, 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.7436655355786597d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.0635047316396446d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 9L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0);
// 
//   }

  public void test337() {}
//   public void test337() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     java.lang.String var10 = var0.nextSecureHexString(10);
//     int var13 = var0.nextInt(0, 100);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var0.nextSecureInt(0, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2.116814394634739d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 114.8024954236355d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.008804606005225863d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "1"+ "'", var8.equals("1"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "fd50578e98"+ "'", var10.equals("fd50578e98"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 26);
// 
//   }

  public void test338() {}
//   public void test338() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextGaussian(117.9736690792914d, 113.5373271615141d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 135.5095521491629d);
// 
//   }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = null;
    boolean var9 = org.apache.commons.math3.util.MathArrays.isMonotonic(var1, var7, false);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    org.apache.commons.math3.util.MathArrays.OrderDirection var13 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var11, var13, false);
    double var16 = org.apache.commons.math3.util.MathArrays.safeNorm(var11);
    double[] var18 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var18);
    double[] var21 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var21);
    double[] var24 = org.apache.commons.math3.util.MathArrays.copyOf(var21, 10);
    double var25 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var24);
    double[] var26 = org.apache.commons.math3.util.MathArrays.ebeDivide(var11, var18);
    double[] var28 = org.apache.commons.math3.util.MathArrays.normalizeArray(var11, 10.0d);
    double[] var29 = org.apache.commons.math3.util.MathArrays.copyOf(var11);
    double[] var30 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var11);
    org.apache.commons.math3.util.MathArrays.OrderDirection var31 = null;
    double[] var33 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var33);
    org.apache.commons.math3.util.MathArrays.OrderDirection var35 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var33, var35, false);
    double var38 = org.apache.commons.math3.util.MathArrays.safeNorm(var33);
    double[] var40 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var40);
    double[] var43 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var43);
    double[] var46 = org.apache.commons.math3.util.MathArrays.copyOf(var43, 10);
    double var47 = org.apache.commons.math3.util.MathArrays.distanceInf(var40, var46);
    double[] var48 = org.apache.commons.math3.util.MathArrays.ebeDivide(var33, var40);
    double[] var50 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var50);
    org.apache.commons.math3.util.MathArrays.OrderDirection var52 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var50, var52, false);
    double var55 = org.apache.commons.math3.util.MathArrays.safeNorm(var50);
    double[] var57 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var57);
    double[] var60 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var60);
    double[] var63 = org.apache.commons.math3.util.MathArrays.copyOf(var60, 10);
    double var64 = org.apache.commons.math3.util.MathArrays.distanceInf(var57, var63);
    double[] var65 = org.apache.commons.math3.util.MathArrays.ebeDivide(var50, var57);
    org.apache.commons.math3.util.MathArrays.OrderDirection var66 = null;
    boolean var68 = org.apache.commons.math3.util.MathArrays.isMonotonic(var50, var66, true);
    double[] var69 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var40, var50);
    double[][] var70 = new double[][] { var50};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var30, var31, var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(0L);
    double var3 = var0.nextDouble();
    var0.clear();
    double var5 = var0.nextGaussian();
    var0.clear();
    long var7 = var0.nextLong();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.7432416673360078d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1.2016184922621251d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-8718518566784105311L));

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }


    float[] var0 = null;
    float[] var3 = new float[] { 100.0f, 10.0f};
    boolean var4 = org.apache.commons.math3.util.MathArrays.equals(var0, var3);
    float[] var8 = new float[] { 0.0f, (-1.0f), 0.0f};
    boolean var9 = org.apache.commons.math3.util.MathArrays.equals(var3, var8);
    float[] var11 = new float[] { 100.0f};
    float[] var12 = new float[] { };
    boolean var13 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var11, var12);
    boolean var14 = org.apache.commons.math3.util.MathArrays.equals(var3, var12);
    float[] var15 = null;
    float[] var18 = new float[] { 100.0f, 10.0f};
    boolean var19 = org.apache.commons.math3.util.MathArrays.equals(var15, var18);
    float[] var23 = new float[] { 0.0f, (-1.0f), 0.0f};
    boolean var24 = org.apache.commons.math3.util.MathArrays.equals(var18, var23);
    float[] var25 = null;
    float[] var28 = new float[] { 100.0f, 10.0f};
    boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var25, var28);
    float[] var33 = new float[] { 0.0f, (-1.0f), 0.0f};
    boolean var34 = org.apache.commons.math3.util.MathArrays.equals(var28, var33);
    boolean var35 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var23, var33);
    float[] var36 = null;
    float[] var39 = new float[] { 100.0f, 10.0f};
    boolean var40 = org.apache.commons.math3.util.MathArrays.equals(var36, var39);
    float[] var44 = new float[] { 0.0f, (-1.0f), 0.0f};
    boolean var45 = org.apache.commons.math3.util.MathArrays.equals(var39, var44);
    float[] var46 = null;
    float[] var49 = new float[] { 100.0f, 10.0f};
    boolean var50 = org.apache.commons.math3.util.MathArrays.equals(var46, var49);
    float[] var54 = new float[] { 0.0f, (-1.0f), 0.0f};
    boolean var55 = org.apache.commons.math3.util.MathArrays.equals(var49, var54);
    float[] var56 = null;
    float[] var59 = new float[] { 100.0f, 10.0f};
    boolean var60 = org.apache.commons.math3.util.MathArrays.equals(var56, var59);
    float[] var64 = new float[] { 0.0f, (-1.0f), 0.0f};
    boolean var65 = org.apache.commons.math3.util.MathArrays.equals(var59, var64);
    boolean var66 = org.apache.commons.math3.util.MathArrays.equals(var49, var59);
    boolean var67 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var44, var49);
    boolean var68 = org.apache.commons.math3.util.MathArrays.equals(var23, var49);
    boolean var69 = org.apache.commons.math3.util.MathArrays.equals(var12, var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);

  }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    double[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 10);
    double[] var6 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var6);
    boolean var8 = org.apache.commons.math3.util.MathArrays.equals(var1, var6);
    org.apache.commons.math3.util.MathArrays.OrderDirection var9 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var6, var9, false);
    double[] var13 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var13);
    double[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var13, 10);
    double[] var18 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var18);
    org.apache.commons.math3.util.MathArrays.OrderDirection var20 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var18, var20, false);
    double var23 = org.apache.commons.math3.util.MathArrays.safeNorm(var18);
    double[] var25 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    double[] var28 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var28);
    double[] var31 = org.apache.commons.math3.util.MathArrays.copyOf(var28, 10);
    double var32 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var31);
    double[] var33 = org.apache.commons.math3.util.MathArrays.ebeDivide(var18, var25);
    double[] var35 = org.apache.commons.math3.util.MathArrays.normalizeArray(var18, 10.0d);
    double var36 = org.apache.commons.math3.util.MathArrays.distance(var13, var18);
    double[] var37 = org.apache.commons.math3.util.MathArrays.ebeAdd(var6, var18);
    double[] var39 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var39);
    double[] var42 = org.apache.commons.math3.util.MathArrays.copyOf(var39, 10);
    double[] var44 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var44);
    boolean var46 = org.apache.commons.math3.util.MathArrays.equals(var39, var44);
    double[] var48 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var48);
    double[] var51 = org.apache.commons.math3.util.MathArrays.copyOf(var48, 10);
    double var52 = org.apache.commons.math3.util.MathArrays.distanceInf(var44, var51);
    org.apache.commons.math3.util.MathArrays.OrderDirection var53 = null;
    boolean var55 = org.apache.commons.math3.util.MathArrays.isMonotonic(var44, var53, true);
    double[] var57 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var57);
    double var59 = org.apache.commons.math3.util.MathArrays.distance1(var44, var57);
    boolean var60 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var6, var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == true);

  }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double[] var18 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var18);
    org.apache.commons.math3.util.MathArrays.OrderDirection var20 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var18, var20, false);
    double var23 = org.apache.commons.math3.util.MathArrays.safeNorm(var18);
    double[] var25 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    double[] var28 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var28);
    double[] var31 = org.apache.commons.math3.util.MathArrays.copyOf(var28, 10);
    double var32 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var31);
    double[] var33 = org.apache.commons.math3.util.MathArrays.ebeDivide(var18, var25);
    org.apache.commons.math3.util.MathArrays.OrderDirection var34 = null;
    boolean var36 = org.apache.commons.math3.util.MathArrays.isMonotonic(var18, var34, true);
    double[] var37 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var8, var18);
    org.apache.commons.math3.util.MathArrays.OrderDirection var38 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var37, var38, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test344() {}
//   public void test344() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     var0.reSeed();
//     double var12 = var0.nextF(82.45368975667407d, 0.5876583645210812d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var0.nextSecureInt(0, (-1276125876));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.6036973587522373d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 105.33415562100348d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.694115441401108d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "c"+ "'", var8.equals("c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 34.295496917737935d);
// 
//   }

  public void test345() {}
//   public void test345() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     double var11 = var0.nextGamma(0.36157468479281d, 0.8376757571801716d);
//     var0.reSeed();
//     var0.reSeedSecure();
//     int var16 = var0.nextSecureInt(0, 118517391);
//     java.util.Collection var17 = null;
//     java.lang.Object[] var19 = var0.nextSample(var17, 36);
// 
//   }

  public void test346() {}
//   public void test346() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     long var5 = var0.nextSecureLong(22L, 75L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "a3631a4fd75cef528afc592eb7304045734394a4bddc4c8668447a78adb005b4c38d9e3f726c06bd8be822d2637a687d50dd"+ "'", var2.equals("a3631a4fd75cef528afc592eb7304045734394a4bddc4c8668447a78adb005b4c38d9e3f726c06bd8be822d2637a687d50dd"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 69L);
// 
//   }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException((-1), (-1));
    int var3 = var2.getDimension();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var7 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0d, (java.lang.Number)(byte)(-1), 1);
    boolean var8 = var7.getStrict();
    java.lang.String var9 = var7.toString();
    var2.addSuppressed((java.lang.Throwable)var7);
    int var11 = var2.getDimension();
    org.apache.commons.math3.exception.MathInternalError var12 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var2);
    org.apache.commons.math3.exception.util.ExceptionContext var13 = var12.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "org.apache.commons.math3.exception.NonMonotonicSequenceException: points 0 and 1 are not strictly increasing (-1 >= 1)"+ "'", var9.equals("org.apache.commons.math3.exception.NonMonotonicSequenceException: points 0 and 1 are not strictly increasing (-1 >= 1)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    double[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 10);
    double[] var6 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var6);
    boolean var8 = org.apache.commons.math3.util.MathArrays.equals(var1, var6);
    org.apache.commons.math3.util.MathArrays.OrderDirection var9 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var6, var9, false);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    boolean var14 = org.apache.commons.math3.util.MathArrays.isMonotonic(var6, var12, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);

  }

  public void test349() {}
//   public void test349() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(0L);
//     double var4 = var0.nextExponential(0.7432416673360078d);
//     int var7 = var0.nextSecureInt(1, 100);
//     java.lang.String var9 = var0.nextHexString(7);
//     var0.reSeedSecure();
//     java.lang.String var12 = var0.nextHexString(118517391);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.36157468479281d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "67c8011"+ "'", var9.equals("67c8011"));
// 
//   }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var3 = new java.lang.Object[] { 'a'};
    org.apache.commons.math3.exception.NotFiniteNumberException var4 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)(short)0, var3);
    double[] var6 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var6);
    org.apache.commons.math3.util.MathArrays.OrderDirection var8 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var6, var8, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var6);
    org.apache.commons.math3.util.Pair var12 = new org.apache.commons.math3.util.Pair((java.lang.Object)(short)0, (java.lang.Object)var6);
    java.lang.Object var13 = var12.getValue();
    org.apache.commons.math3.util.Pair var14 = new org.apache.commons.math3.util.Pair(var12);
    java.lang.Object var15 = var14.getKey();
    java.lang.Object var16 = var14.getValue();
    org.apache.commons.math3.util.Pair var17 = new org.apache.commons.math3.util.Pair(var14);
    java.lang.Object var18 = var17.getKey();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + (short)0+ "'", var15.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + (short)0+ "'", var18.equals((short)0));

  }

  public void test351() {}
//   public void test351() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     var0.reSeedSecure();
//     var0.reSeed();
//     double var9 = var0.nextUniform(0.0015326576218039215d, 114.81244598869324d);
//     var0.reSeedSecure();
//     var0.reSeedSecure((-1L));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var14 = var0.nextSecureHexString((-1276125876));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.4554202160670622d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 106.35854649573372d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 94.10700616978173d);
// 
//   }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, (-1276125876), 0);

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double[] var18 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 10.0d);
    double[] var20 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var20);
    double[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 10);
    double[] var25 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var20, var25);
    double[] var29 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var29);
    double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 10);
    double var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var32);
    double var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var25);
    double[] var36 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var36);
    double[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var36, 10);
    double[] var41 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var41);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var36, var41);
    double[] var45 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var45);
    double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var45, 10);
    double var49 = org.apache.commons.math3.util.MathArrays.distanceInf(var41, var48);
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeAdd(var18, var41);
    double[] var52 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var52);
    double[] var55 = org.apache.commons.math3.util.MathArrays.copyOf(var52, 10);
    double[] var57 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var57);
    boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var52, var57);
    double[] var61 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var61);
    double[] var64 = org.apache.commons.math3.util.MathArrays.copyOf(var61, 10);
    double var65 = org.apache.commons.math3.util.MathArrays.distanceInf(var57, var64);
    org.apache.commons.math3.util.MathArrays.OrderDirection var66 = null;
    boolean var68 = org.apache.commons.math3.util.MathArrays.isMonotonic(var57, var66, true);
    double[] var70 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var70);
    double var72 = org.apache.commons.math3.util.MathArrays.distance1(var57, var70);
    double[] var74 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var74);
    double[] var77 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var77);
    double[] var80 = org.apache.commons.math3.util.MathArrays.copyOf(var77, 10);
    double var81 = org.apache.commons.math3.util.MathArrays.distanceInf(var74, var80);
    double[] var82 = org.apache.commons.math3.util.MathArrays.ebeDivide(var70, var74);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var83 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var18, var82);
    double var85 = var83.inverseCumulativeProbability(0.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var87 = var83.inverseCumulativeProbability(1.305475194865426d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 11.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 10.0d);

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0d, (java.lang.Number)(byte)(-1), 1);
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);

  }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(0L);
    double var3 = var0.nextDouble();
    var0.clear();
    double var5 = var0.nextGaussian();
    var0.setSeed(0);
    double var8 = var0.nextDouble();
    var0.clear();
    org.apache.commons.math3.random.RandomDataGenerator var10 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
    double var13 = var10.nextBeta(105.39091667829669d, 9.581426376563695E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.7432416673360078d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1.2016184922621251d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.9775554539871507d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.9999999984278495d);

  }

  public void test356() {}
//   public void test356() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }
// 
// 
//     double[] var1 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var1);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
//     double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
//     double[] var8 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var8);
//     double[] var11 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var11);
//     double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
//     double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
//     double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
//     double var17 = org.apache.commons.math3.util.MathArrays.safeNorm(var8);
//     double[] var19 = org.apache.commons.math3.util.MathArrays.copyOf(var8, 1);
//     double[] var21 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var21);
//     double[] var24 = org.apache.commons.math3.util.MathArrays.copyOf(var21, 10);
//     double[] var26 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var26);
//     boolean var28 = org.apache.commons.math3.util.MathArrays.equals(var21, var26);
//     double[] var30 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var30);
//     double[] var33 = org.apache.commons.math3.util.MathArrays.copyOf(var30, 10);
//     double var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var26, var33);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var35 = null;
//     boolean var37 = org.apache.commons.math3.util.MathArrays.isMonotonic(var26, var35, true);
//     double[] var39 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var39);
//     double var41 = org.apache.commons.math3.util.MathArrays.distance1(var26, var39);
//     double[] var43 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var43);
//     double[] var46 = org.apache.commons.math3.util.MathArrays.copyOf(var43, 10);
//     double[] var48 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var48);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var50 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var48, var50, false);
//     boolean var53 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var46, var48);
//     double[] var54 = org.apache.commons.math3.util.MathArrays.ebeAdd(var26, var48);
//     double[] var55 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var19, var26);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double[] var57 = org.apache.commons.math3.util.MathArrays.copyOf(var55, 60481539);
//       fail("Expected exception of type java.lang.OutOfMemoryError");
//     } catch (java.lang.OutOfMemoryError e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
// 
//   }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)(-1), (java.lang.Number)112.79893611497971d, (java.lang.Number)35.80121798427257d);

  }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }


    double[] var0 = null;
    double[] var1 = null;
    boolean var2 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double var17 = org.apache.commons.math3.util.MathArrays.safeNorm(var8);
    double[] var19 = org.apache.commons.math3.util.MathArrays.copyOf(var8, 1);
    double[] var21 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var21);
    org.apache.commons.math3.util.MathArrays.OrderDirection var23 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var21, var23, false);
    double var26 = org.apache.commons.math3.util.MathArrays.safeNorm(var21);
    double[] var28 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var28);
    double[] var31 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var31);
    double[] var34 = org.apache.commons.math3.util.MathArrays.copyOf(var31, 10);
    double var35 = org.apache.commons.math3.util.MathArrays.distanceInf(var28, var34);
    double[] var36 = org.apache.commons.math3.util.MathArrays.ebeDivide(var21, var28);
    double[] var38 = org.apache.commons.math3.util.MathArrays.normalizeArray(var21, 10.0d);
    double[] var40 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var40);
    double[] var43 = org.apache.commons.math3.util.MathArrays.copyOf(var40, 10);
    double[] var45 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var45);
    boolean var47 = org.apache.commons.math3.util.MathArrays.equals(var40, var45);
    double[] var49 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var49);
    double[] var52 = org.apache.commons.math3.util.MathArrays.copyOf(var49, 10);
    double var53 = org.apache.commons.math3.util.MathArrays.distanceInf(var45, var52);
    double var54 = org.apache.commons.math3.util.MathArrays.distanceInf(var38, var45);
    double[] var56 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var56);
    double[] var59 = org.apache.commons.math3.util.MathArrays.copyOf(var56, 10);
    double[] var61 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var61);
    boolean var63 = org.apache.commons.math3.util.MathArrays.equals(var56, var61);
    double[] var65 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var65);
    double[] var68 = org.apache.commons.math3.util.MathArrays.copyOf(var65, 10);
    double var69 = org.apache.commons.math3.util.MathArrays.distanceInf(var61, var68);
    double[] var70 = org.apache.commons.math3.util.MathArrays.ebeAdd(var38, var61);
    double[] var72 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var72);
    org.apache.commons.math3.util.MathArrays.OrderDirection var74 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var72, var74, false);
    double var77 = org.apache.commons.math3.util.MathArrays.safeNorm(var72);
    double[] var79 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var79);
    double[] var82 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var82);
    double[] var85 = org.apache.commons.math3.util.MathArrays.copyOf(var82, 10);
    double var86 = org.apache.commons.math3.util.MathArrays.distanceInf(var79, var85);
    double[] var87 = org.apache.commons.math3.util.MathArrays.ebeDivide(var72, var79);
    double var88 = org.apache.commons.math3.util.MathArrays.safeNorm(var79);
    double[] var89 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var79);
    double[] var90 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var8, var79);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var92 = org.apache.commons.math3.util.MathArrays.normalizeArray(var90, 1.2090062708162682E-4d);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 11.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double[] var18 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 10.0d);
    double[] var20 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var20);
    double[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 10);
    double[] var25 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var20, var25);
    double[] var29 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var29);
    double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 10);
    double var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var32);
    double var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var25);
    double[] var36 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var36);
    double[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var36, 10);
    double[] var41 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var41);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var36, var41);
    double[] var45 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var45);
    double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var45, 10);
    double var49 = org.apache.commons.math3.util.MathArrays.distanceInf(var41, var48);
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeAdd(var18, var41);
    double[] var52 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var52);
    double[] var55 = org.apache.commons.math3.util.MathArrays.copyOf(var52, 10);
    double[] var57 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var57);
    boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var52, var57);
    double[] var61 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var61);
    double[] var64 = org.apache.commons.math3.util.MathArrays.copyOf(var61, 10);
    double var65 = org.apache.commons.math3.util.MathArrays.distanceInf(var57, var64);
    org.apache.commons.math3.util.MathArrays.OrderDirection var66 = null;
    boolean var68 = org.apache.commons.math3.util.MathArrays.isMonotonic(var57, var66, true);
    double[] var70 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var70);
    double var72 = org.apache.commons.math3.util.MathArrays.distance1(var57, var70);
    double[] var74 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var74);
    double[] var77 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var77);
    double[] var80 = org.apache.commons.math3.util.MathArrays.copyOf(var77, 10);
    double var81 = org.apache.commons.math3.util.MathArrays.distanceInf(var74, var80);
    double[] var82 = org.apache.commons.math3.util.MathArrays.ebeDivide(var70, var74);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var83 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var18, var82);
    double var85 = var83.inverseCumulativeProbability(0.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var87 = var83.inverseCumulativeProbability(0.09175824555693415d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 11.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 10.0d);

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0f, var1, 10, var3, true);
    java.lang.Number var6 = var5.getArgument();
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = var5.getDirection();
    boolean var8 = var5.getStrict();
    boolean var9 = var5.getStrict();
    java.lang.Throwable[] var10 = var5.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 0.0f+ "'", var6.equals(0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test362() {}
//   public void test362() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
//     int var2 = var0.nextInt();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 477395393);
// 
//   }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double[] var18 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 10.0d);
    double[] var20 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var20);
    double[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 10);
    double[] var25 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var20, var25);
    double[] var29 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var29);
    double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 10);
    double var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var32);
    double var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var25);
    double[] var36 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var36);
    double[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var36, 10);
    double[] var41 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var41);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var36, var41);
    double[] var45 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var45);
    double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var45, 10);
    double var49 = org.apache.commons.math3.util.MathArrays.distanceInf(var41, var48);
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeAdd(var18, var41);
    double[] var52 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var52);
    double[] var55 = org.apache.commons.math3.util.MathArrays.copyOf(var52, 10);
    double[] var57 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var57);
    boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var52, var57);
    double[] var61 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var61);
    double[] var64 = org.apache.commons.math3.util.MathArrays.copyOf(var61, 10);
    double var65 = org.apache.commons.math3.util.MathArrays.distanceInf(var57, var64);
    org.apache.commons.math3.util.MathArrays.OrderDirection var66 = null;
    boolean var68 = org.apache.commons.math3.util.MathArrays.isMonotonic(var57, var66, true);
    double[] var70 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var70);
    double var72 = org.apache.commons.math3.util.MathArrays.distance1(var57, var70);
    double[] var74 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var74);
    double[] var77 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var77);
    double[] var80 = org.apache.commons.math3.util.MathArrays.copyOf(var77, 10);
    double var81 = org.apache.commons.math3.util.MathArrays.distanceInf(var74, var80);
    double[] var82 = org.apache.commons.math3.util.MathArrays.ebeDivide(var70, var74);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var83 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var18, var82);
    double var85 = var83.inverseCumulativeProbability(0.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var87 = var83.sample((-1));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 11.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 10.0d);

  }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeedSecure();
    var0.reSeed(100L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var6 = var0.nextSecureInt(118517391, 43);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test365() {}
//   public void test365() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     int var5 = var0.nextBinomial(10, 0.03863055888020799d);
//     int var8 = var0.nextSecureInt(7, 48);
//     int var11 = var0.nextSecureInt(39, 118517391);
//     long var13 = var0.nextPoisson(0.7088914394874254d);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var16 = var0.nextHexString(477395393);
//       fail("Expected exception of type java.lang.OutOfMemoryError");
//     } catch (java.lang.OutOfMemoryError e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.3680045431165799d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 19209774);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1L);
// 
//   }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(274497138);

  }

  public void test367() {}
//   public void test367() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     double var5 = var0.nextWeibull(110.0d, 0.3874438233115065d);
//     var0.reSeedSecure();
//     int var9 = var0.nextZipf(31, 0.6183635164792604d);
//     java.lang.String var11 = var0.nextHexString(36);
//     var0.reSeedSecure(90L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "155babaa6db0090d54f8dcbbc302ae30b68ecbb7d898c2b4a3b523512917dcd5a857fadc188975c996da0771198c53323fa9"+ "'", var2.equals("155babaa6db0090d54f8dcbbc302ae30b68ecbb7d898c2b4a3b523512917dcd5a857fadc188975c996da0771198c53323fa9"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.38303844979384266d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "4062f5fcd0938424eacbf21729a55a9bcb19"+ "'", var11.equals("4062f5fcd0938424eacbf21729a55a9bcb19"));
// 
//   }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    double[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 10);
    double[] var6 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var6);
    org.apache.commons.math3.util.MathArrays.OrderDirection var8 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var6, var8, false);
    double var11 = org.apache.commons.math3.util.MathArrays.safeNorm(var6);
    double[] var13 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var13);
    double[] var16 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var16);
    double[] var19 = org.apache.commons.math3.util.MathArrays.copyOf(var16, 10);
    double var20 = org.apache.commons.math3.util.MathArrays.distanceInf(var13, var19);
    double[] var21 = org.apache.commons.math3.util.MathArrays.ebeDivide(var6, var13);
    double[] var23 = org.apache.commons.math3.util.MathArrays.normalizeArray(var6, 10.0d);
    double var24 = org.apache.commons.math3.util.MathArrays.distance(var1, var6);
    org.apache.commons.math3.util.MathArrays.OrderDirection var25 = null;
    boolean var28 = org.apache.commons.math3.util.MathArrays.checkOrder(var6, var25, true, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);

  }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(0.4517190132114119d, 0.05609443507672968d, 0.09314254419077805d, 0.39257004669847934d, 103.25934629914218d, 103.06912597726082d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 10642.91247593167d);

  }

  public void test370() {}
//   public void test370() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(98.7281415762265d);
//     double var8 = var0.nextT(105.39091667829669d);
//     double[] var10 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var10);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var10, var12, false);
//     double var15 = org.apache.commons.math3.util.MathArrays.safeNorm(var10);
//     double[] var17 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var17);
//     double[] var20 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var20);
//     double[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 10);
//     double var24 = org.apache.commons.math3.util.MathArrays.distanceInf(var17, var23);
//     double[] var25 = org.apache.commons.math3.util.MathArrays.ebeDivide(var10, var17);
//     double[] var27 = org.apache.commons.math3.util.MathArrays.normalizeArray(var10, 10.0d);
//     double[] var29 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var29);
//     double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 10);
//     double[] var34 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var34);
//     boolean var36 = org.apache.commons.math3.util.MathArrays.equals(var29, var34);
//     double[] var38 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var38);
//     double[] var41 = org.apache.commons.math3.util.MathArrays.copyOf(var38, 10);
//     double var42 = org.apache.commons.math3.util.MathArrays.distanceInf(var34, var41);
//     double var43 = org.apache.commons.math3.util.MathArrays.distanceInf(var27, var34);
//     double[] var45 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var45);
//     double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var45, 10);
//     double[] var50 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var50);
//     boolean var52 = org.apache.commons.math3.util.MathArrays.equals(var45, var50);
//     double[] var54 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var54);
//     double[] var57 = org.apache.commons.math3.util.MathArrays.copyOf(var54, 10);
//     double var58 = org.apache.commons.math3.util.MathArrays.distanceInf(var50, var57);
//     double[] var59 = org.apache.commons.math3.util.MathArrays.ebeAdd(var27, var50);
//     double[] var61 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var61);
//     double[] var64 = org.apache.commons.math3.util.MathArrays.copyOf(var61, 10);
//     double[] var66 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var66);
//     boolean var68 = org.apache.commons.math3.util.MathArrays.equals(var61, var66);
//     double[] var70 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var70);
//     double[] var73 = org.apache.commons.math3.util.MathArrays.copyOf(var70, 10);
//     double var74 = org.apache.commons.math3.util.MathArrays.distanceInf(var66, var73);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var75 = null;
//     boolean var77 = org.apache.commons.math3.util.MathArrays.isMonotonic(var66, var75, true);
//     double[] var79 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var79);
//     double var81 = org.apache.commons.math3.util.MathArrays.distance1(var66, var79);
//     double[] var83 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var83);
//     double[] var86 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var86);
//     double[] var89 = org.apache.commons.math3.util.MathArrays.copyOf(var86, 10);
//     double var90 = org.apache.commons.math3.util.MathArrays.distanceInf(var83, var89);
//     double[] var91 = org.apache.commons.math3.util.MathArrays.ebeDivide(var79, var83);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var92 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var27, var91);
//     double var94 = var92.inverseCumulativeProbability(0.0d);
//     double var95 = var92.getNumericalMean();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var96 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var92);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.2610154351267619d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 81.23797388246139d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 87.06306675754168d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-0.2569472495148025d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 11.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var68 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var70);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var74 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var77 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var79);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var81 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var83);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var86);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var89);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var90 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var91);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var94 == 10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var95 == 10.0d);
// 
//   }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }


    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.4924399031470064E10d, (java.lang.Number)(-0.06187681393378908d), 1, var3, true);
    int var6 = var5.getIndex();
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    java.lang.Comparable[] var9 = new java.lang.Comparable[] { (byte)(-1)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var10 = null;
    boolean var12 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var9, var10, true);
    org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var5, var7, (java.lang.Object[])var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);

  }

  public void test372() {}
//   public void test372() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 100, 20);
// 
//   }

  public void test373() {}
//   public void test373() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     java.lang.String var10 = var0.nextSecureHexString(1);
//     org.apache.commons.math3.distribution.IntegerDistribution var11 = null;
//     int var12 = var0.nextInversionDeviate(var11);
// 
//   }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(0L);
    double var4 = var0.nextT(101.79109515357918d);
    double var6 = var0.nextT(10.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var9 = var0.nextGaussian(1.2090062708162682E-4d, (-185.7588642130088d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.6556684902257256d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.23842384721562462d);

  }

  public void test375() {}
//   public void test375() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     var0.reSeedSecure();
//     int var8 = var0.nextZipf(16, 100.38955484251419d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var0.nextUniform(0.07387106057974321d, (-185.7588642130088d), true);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.0242404323983145d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 93.39541454800836d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1);
// 
//   }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)1, (java.lang.Number)1L, (java.lang.Number)(short)(-1));
    java.lang.Number var5 = var4.getHi();
    java.lang.Number var6 = var4.getLo();
    java.lang.Number var7 = var4.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (short)(-1)+ "'", var5.equals((short)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 1L+ "'", var6.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (short)(-1)+ "'", var7.equals((short)(-1)));

  }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.clear();

  }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(0L);
    double var4 = var0.nextExponential(0.7432416673360078d);
    double var6 = var0.nextT(0.035899776418132384d);
    var0.reSeed(477836925424025280L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var11 = var0.nextInt(48, 41);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.36157468479281d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 27.366395926482813d);

  }

  public void test379() {}
//   public void test379() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     double var11 = var0.nextGamma(0.36157468479281d, 0.8376757571801716d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var0.nextBinomial(60481539, 54.76711054963606d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.4480496649650065d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 123.58180694723671d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.03861108857818934d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "5"+ "'", var8.equals("5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.010548434288564442d);
// 
//   }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)0L);
    org.apache.commons.math3.exception.OutOfRangeException var6 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(-1.0f), (java.lang.Number)100.0f, (java.lang.Number)(short)0);
    java.lang.Number var7 = var6.getLo();
    var2.addSuppressed((java.lang.Throwable)var6);
    java.lang.Throwable[] var9 = var2.getSuppressed();
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    org.apache.commons.math3.exception.util.Localizable var12 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var14 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var12, (java.lang.Number)0L);
    org.apache.commons.math3.exception.OutOfRangeException var18 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(-1.0f), (java.lang.Number)100.0f, (java.lang.Number)(short)0);
    java.lang.Number var19 = var18.getLo();
    var14.addSuppressed((java.lang.Throwable)var18);
    java.lang.Throwable[] var21 = var14.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var22 = new org.apache.commons.math3.exception.NotFiniteNumberException(var10, (java.lang.Number)9.745524084025742E9d, (java.lang.Object[])var21);
    var2.addSuppressed((java.lang.Throwable)var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 100.0f+ "'", var7.equals(100.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + 100.0f+ "'", var19.equals(100.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test381() {}
//   public void test381() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 0, 0);
// 
//   }

  public void test382() {}
//   public void test382() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     double var5 = var0.nextWeibull(110.0d, 0.3874438233115065d);
//     java.util.Collection var6 = null;
//     java.lang.Object[] var8 = var0.nextSample(var6, 100);
// 
//   }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)10.0f, (java.lang.Number)1.5528800970508765d, (java.lang.Number)0.6062775910181382d);

  }

  public void test384() {}
//   public void test384() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var3 = var1.nextChiSquare(1.3650947445123496d);
//     double var6 = var1.nextWeibull(1.0d, 0.3874438233115065d);
//     long var9 = var1.nextSecureLong(1L, 10L);
//     var1.reSeed(90L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var14 = var1.nextPermutation(9, 36);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.5818933321876674d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.022746352845071826d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 8L);
// 
//   }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }


    float[] var0 = null;
    float[] var1 = null;
    float[] var4 = new float[] { 100.0f, 10.0f};
    boolean var5 = org.apache.commons.math3.util.MathArrays.equals(var1, var4);
    float[] var9 = new float[] { 0.0f, (-1.0f), 0.0f};
    boolean var10 = org.apache.commons.math3.util.MathArrays.equals(var4, var9);
    float[] var11 = null;
    float[] var14 = new float[] { 100.0f, 10.0f};
    boolean var15 = org.apache.commons.math3.util.MathArrays.equals(var11, var14);
    float[] var19 = new float[] { 0.0f, (-1.0f), 0.0f};
    boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var14, var19);
    boolean var21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var9, var19);
    float[] var22 = null;
    float[] var25 = new float[] { 100.0f, 10.0f};
    boolean var26 = org.apache.commons.math3.util.MathArrays.equals(var22, var25);
    float[] var30 = new float[] { 0.0f, (-1.0f), 0.0f};
    boolean var31 = org.apache.commons.math3.util.MathArrays.equals(var25, var30);
    float[] var32 = null;
    float[] var35 = new float[] { 100.0f, 10.0f};
    boolean var36 = org.apache.commons.math3.util.MathArrays.equals(var32, var35);
    float[] var40 = new float[] { 0.0f, (-1.0f), 0.0f};
    boolean var41 = org.apache.commons.math3.util.MathArrays.equals(var35, var40);
    float[] var42 = null;
    float[] var45 = new float[] { 100.0f, 10.0f};
    boolean var46 = org.apache.commons.math3.util.MathArrays.equals(var42, var45);
    float[] var50 = new float[] { 0.0f, (-1.0f), 0.0f};
    boolean var51 = org.apache.commons.math3.util.MathArrays.equals(var45, var50);
    boolean var52 = org.apache.commons.math3.util.MathArrays.equals(var35, var45);
    boolean var53 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var30, var35);
    boolean var54 = org.apache.commons.math3.util.MathArrays.equals(var9, var35);
    float[] var55 = null;
    float[] var58 = new float[] { 100.0f, 10.0f};
    boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var55, var58);
    boolean var60 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var9, var58);
    boolean var61 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var0, var9);
    float[] var63 = new float[] { 100.0f};
    float[] var64 = null;
    float[] var67 = new float[] { 100.0f, 10.0f};
    boolean var68 = org.apache.commons.math3.util.MathArrays.equals(var64, var67);
    float[] var72 = new float[] { 0.0f, (-1.0f), 0.0f};
    boolean var73 = org.apache.commons.math3.util.MathArrays.equals(var67, var72);
    float[] var74 = null;
    float[] var77 = new float[] { 100.0f, 10.0f};
    boolean var78 = org.apache.commons.math3.util.MathArrays.equals(var74, var77);
    float[] var82 = new float[] { 0.0f, (-1.0f), 0.0f};
    boolean var83 = org.apache.commons.math3.util.MathArrays.equals(var77, var82);
    float[] var84 = null;
    float[] var87 = new float[] { 100.0f, 10.0f};
    boolean var88 = org.apache.commons.math3.util.MathArrays.equals(var84, var87);
    float[] var92 = new float[] { 0.0f, (-1.0f), 0.0f};
    boolean var93 = org.apache.commons.math3.util.MathArrays.equals(var87, var92);
    boolean var94 = org.apache.commons.math3.util.MathArrays.equals(var77, var87);
    boolean var95 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var72, var77);
    boolean var96 = org.apache.commons.math3.util.MathArrays.equals(var63, var77);
    boolean var97 = org.apache.commons.math3.util.MathArrays.equals(var9, var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var94 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var95 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var96 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var97 == false);

  }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var4 = var0.nextSecureLong(1024457413273955602L, 72L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test387() {}
//   public void test387() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 118517391, 104075088);
// 
//   }

  public void test388() {}
//   public void test388() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(7, 312574995);
//     double var6 = var0.nextGaussian(0.6183635164792604d, 148.33228964603538d);
//     org.apache.commons.math3.distribution.IntegerDistribution var7 = null;
//     int var8 = var0.nextInversionDeviate(var7);
// 
//   }

  public void test389() {}
//   public void test389() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }
// 
// 
//     double[] var1 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var1);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
//     double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
//     double[] var8 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var8);
//     double[] var11 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var11);
//     double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
//     double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
//     double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
//     double var17 = org.apache.commons.math3.util.MathArrays.safeNorm(var8);
//     double[] var19 = org.apache.commons.math3.util.MathArrays.copyOf(var8, 1);
//     double[] var21 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var21);
//     double[] var24 = org.apache.commons.math3.util.MathArrays.copyOf(var21, 10);
//     double[] var26 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var26);
//     boolean var28 = org.apache.commons.math3.util.MathArrays.equals(var21, var26);
//     double[] var30 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var30);
//     double[] var33 = org.apache.commons.math3.util.MathArrays.copyOf(var30, 10);
//     double var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var26, var33);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var35 = null;
//     boolean var37 = org.apache.commons.math3.util.MathArrays.isMonotonic(var26, var35, true);
//     double[] var39 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var39);
//     double var41 = org.apache.commons.math3.util.MathArrays.distance1(var26, var39);
//     double[] var43 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var43);
//     double[] var46 = org.apache.commons.math3.util.MathArrays.copyOf(var43, 10);
//     double[] var48 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var48);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var50 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var48, var50, false);
//     boolean var53 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var46, var48);
//     double[] var54 = org.apache.commons.math3.util.MathArrays.ebeAdd(var26, var48);
//     double[] var55 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var19, var26);
//     double[] var56 = null;
//     double[] var57 = org.apache.commons.math3.util.MathArrays.ebeAdd(var26, var56);
// 
//   }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(0L);
    double var4 = var0.nextExponential(0.7432416673360078d);
    var0.reSeedSecure();
    double var8 = var0.nextF(101.79109515357918d, 0.6116146111830432d);
    var0.reSeed(434277157163744896L);
    var0.reSeed(86L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.36157468479281d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 7.890608942511265d);

  }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    double[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 10);
    double[] var6 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var6);
    boolean var8 = org.apache.commons.math3.util.MathArrays.equals(var1, var6);
    org.apache.commons.math3.util.MathArrays.OrderDirection var9 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var6, var9, false);
    double[] var13 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var13);
    double[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var13, 10);
    double[] var18 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var18);
    org.apache.commons.math3.util.MathArrays.OrderDirection var20 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var18, var20, false);
    double var23 = org.apache.commons.math3.util.MathArrays.safeNorm(var18);
    double[] var25 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    double[] var28 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var28);
    double[] var31 = org.apache.commons.math3.util.MathArrays.copyOf(var28, 10);
    double var32 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var31);
    double[] var33 = org.apache.commons.math3.util.MathArrays.ebeDivide(var18, var25);
    double[] var35 = org.apache.commons.math3.util.MathArrays.normalizeArray(var18, 10.0d);
    double var36 = org.apache.commons.math3.util.MathArrays.distance(var13, var18);
    double[] var37 = org.apache.commons.math3.util.MathArrays.ebeAdd(var6, var18);
    double[] var39 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var39);
    org.apache.commons.math3.util.MathArrays.OrderDirection var41 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var39, var41, false);
    double var44 = org.apache.commons.math3.util.MathArrays.safeNorm(var39);
    double[] var46 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var46);
    double[] var49 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var49);
    double[] var52 = org.apache.commons.math3.util.MathArrays.copyOf(var49, 10);
    double var53 = org.apache.commons.math3.util.MathArrays.distanceInf(var46, var52);
    double[] var54 = org.apache.commons.math3.util.MathArrays.ebeDivide(var39, var46);
    double[] var56 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var56);
    org.apache.commons.math3.util.MathArrays.OrderDirection var58 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var56, var58, false);
    double var61 = org.apache.commons.math3.util.MathArrays.safeNorm(var56);
    org.apache.commons.math3.util.MathArrays.OrderDirection var62 = null;
    boolean var64 = org.apache.commons.math3.util.MathArrays.isMonotonic(var56, var62, false);
    double[][] var65 = new double[][] { var56};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var39, var65);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var18, var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }


    java.lang.Throwable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Object[] var2 = null;
    org.apache.commons.math3.exception.MathIllegalStateException var3 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var1, var2);

  }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)7L);
    boolean var3 = var2.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var3 = new java.lang.Object[] { 'a'};
    org.apache.commons.math3.exception.NotFiniteNumberException var4 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)(short)0, var3);
    double[] var6 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var6);
    org.apache.commons.math3.util.MathArrays.OrderDirection var8 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var6, var8, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var6);
    org.apache.commons.math3.util.Pair var12 = new org.apache.commons.math3.util.Pair((java.lang.Object)(short)0, (java.lang.Object)var6);
    java.lang.Object var13 = var12.getValue();
    org.apache.commons.math3.util.Pair var14 = new org.apache.commons.math3.util.Pair(var12);
    int[] var15 = new int[] { };
    int[] var16 = null;
    int var17 = org.apache.commons.math3.util.MathArrays.distance1(var15, var16);
    org.apache.commons.math3.random.Well19937c var18 = new org.apache.commons.math3.random.Well19937c(var15);
    double var19 = var18.nextGaussian();
    long var20 = var18.nextLong();
    boolean var21 = var12.equals((java.lang.Object)var20);
    org.apache.commons.math3.util.MathArrays.OrderDirection var25 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var27 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)100, (java.lang.Number)10.0d, 0, var25, false);
    boolean var28 = var12.equals((java.lang.Object)var25);
    boolean var30 = var12.equals((java.lang.Object)(-0.6330299880035857d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.2478736222527921d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1024457413273955602L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0f, var1, 10, var3, true);
    int var6 = var5.getIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 10);

  }

  public void test396() {}
//   public void test396() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     double var11 = var0.nextGamma(0.36157468479281d, 0.8376757571801716d);
//     double var14 = var0.nextCauchy(0.8376757571801716d, 0.3901018313315268d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var16 = var0.nextHexString((-1276125876));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.01999636038616999d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 114.87185612684675d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.04600513139217799d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "4"+ "'", var8.equals("4"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.3717896970335878d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.5827556901217078d);
// 
//   }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0f, var1, 10, var3, true);
    java.lang.Number var6 = var5.getArgument();
    java.lang.Throwable[] var7 = var5.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 0.0f+ "'", var6.equals(0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)(-0.2748957434128349d), var2, (java.lang.Number)0.9385577265294871d);

  }

  public void test399() {}
//   public void test399() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(98.7281415762265d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var0.nextCauchy(1.4924399031740692E10d, (-0.19424604130720316d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.204354099887673d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 84.14454507194165d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 110.57881150661152d);
// 
//   }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double[] var18 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 10.0d);
    double[] var20 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var20);
    double[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 10);
    double[] var25 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var20, var25);
    double[] var29 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var29);
    double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 10);
    double var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var32);
    double var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var25);
    double[] var36 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var36);
    org.apache.commons.math3.util.MathArrays.OrderDirection var38 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var36, var38, false);
    double var41 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var36);
    double[] var43 = org.apache.commons.math3.util.MathArrays.copyOf(var25, 10);
    double[] var45 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var45);
    double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var45, 10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var49 = org.apache.commons.math3.util.MathArrays.distance1(var43, var45);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 11.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);

  }

  public void test401() {}
//   public void test401() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(98.7281415762265d);
//     int var9 = var0.nextZipf(100, 114.23712557956448d);
//     double var12 = var0.nextWeibull(101.79109515357918d, 137.63359670277694d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.6466922963099893d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 96.80473661237758d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 102.88914887158289d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 138.08245836575858d);
// 
//   }

  public void test402() {}
//   public void test402() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     int var5 = var0.nextBinomial(10, 0.03863055888020799d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var8 = var0.nextLong(86L, 13L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-1.038273848066843d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
// 
//   }

  public void test403() {}
//   public void test403() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var3 = var1.nextChiSquare(1.3650947445123496d);
//     long var6 = var1.nextSecureLong(85L, 100L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("18b750b5aede8c5cb77a6d4310c7df1b25788d4f32b713b654134b3d7cbbcffd421462f89aeaa230ac23621fd38af23d96c8", "79866a06f1");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.2726236965363767d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 95L);
// 
//   }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(52084938);

  }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(-1));
    java.lang.Number var3 = var2.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));

  }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }


    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var5 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var3, (java.lang.Number)0L);
    java.lang.Throwable[] var6 = var5.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var7 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Number)0.0d, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.NotFiniteNumberException var8 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)0.3842834232631038d, (java.lang.Object[])var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test407() {}
//   public void test407() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     int var5 = var0.nextBinomial(0, 0.0d);
//     double var8 = var0.nextGaussian(108.97593914807048d, 101.79109515357918d);
//     double var10 = var0.nextT(0.00940319128424221d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var0.nextHypergeometric((-2087310710), 8, 21);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "57a8f1d876bbb59546e1422e1f86ead95a5d6441f8a3f1324ebfd39e03551aa6d991f094710a9cf63671694863afa89f6bd2"+ "'", var2.equals("57a8f1d876bbb59546e1422e1f86ead95a5d6441f8a3f1324ebfd39e03551aa6d991f094710a9cf63671694863afa89f6bd2"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 115.60973114710862d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.1930701114218484d);
// 
//   }

  public void test408() {}
//   public void test408() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var3 = var1.nextChiSquare(1.3650947445123496d);
//     long var6 = var1.nextSecureLong(85L, 100L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var8 = var1.nextSecureHexString((-1276125876));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.9750229153765735d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 91L);
// 
//   }

  public void test409() {}
//   public void test409() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(0L);
//     java.lang.String var4 = var0.nextHexString(100);
//     java.lang.String var6 = var0.nextSecureHexString(1);
//     var0.reSeed((-1L));
//     var0.reSeed(0L);
//     double var13 = var0.nextWeibull(128.35556077963213d, 0.3874438233115065d);
//     var0.reSeed(477836925424025280L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var19 = var0.nextHypergeometric(39, 99, 38);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"+ "'", var4.equals("7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "3"+ "'", var6.equals("3"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.3883722390257413d);
// 
//   }

  public void test410() {}
//   public void test410() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     double var11 = var0.nextGamma(0.36157468479281d, 0.8376757571801716d);
//     double var14 = var0.nextCauchy(0.8376757571801716d, 0.3901018313315268d);
//     long var17 = var0.nextLong(86L, 95L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var20 = var0.nextLong(0L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-1.0321013153666763d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.14505156290969d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.007445125624473155d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "4"+ "'", var8.equals("4"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.24902674738536373d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.0824870410385594d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 94L);
// 
//   }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(0.0653811700462978d, 95.53345784448464d, (-0.4578282015693922d), 3.688927398073491E-4d, 0.3535063099037627d, 82.45368975667407d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 35.39381996677296d);

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)7.890608942511265d, (java.lang.Number)1L, (java.lang.Number)(-185.7588642130088d));

  }

  public void test413() {}
//   public void test413() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var5 = var0.nextF(98.30741799725186d, 115.61573715905594d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var8 = var0.nextZipf(0, 13403.439260566649d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.9520273570625938d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.9668588570367386d);
// 
//   }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)72L, (java.lang.Number)0.00322408197305579d, false);

  }

  public void test415() {}
//   public void test415() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     double var5 = var0.nextWeibull(110.0d, 0.3874438233115065d);
//     var0.reSeedSecure();
//     var0.reSeedSecure(95L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var0.nextHypergeometric(7, 8, 14);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "90491e48ca9ed96ecc2a4516dfee2845a1aff0a4962e966fe1d9efa0ac862441f8f274886ebb5f9e3ed1331869bde7192188"+ "'", var2.equals("90491e48ca9ed96ecc2a4516dfee2845a1aff0a4962e966fe1d9efa0ac862441f8f274886ebb5f9e3ed1331869bde7192188"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.38278509317954995d);
// 
//   }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }


    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1.1917327900748924d), (java.lang.Number)4.149496931236865d, 312574995, var3, false);
    boolean var6 = var5.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = var5.getDirection();
    java.lang.Number var9 = null;
    org.apache.commons.math3.util.MathArrays.OrderDirection var11 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var13 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0f, var9, 10, var11, true);
    var5.addSuppressed((java.lang.Throwable)var13);
    java.lang.String var15 = var13.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "org.apache.commons.math3.exception.NonMonotonicSequenceException: points 9 and 10 are not strictly decreasing (null <= 0)"+ "'", var15.equals("org.apache.commons.math3.exception.NonMonotonicSequenceException: points 9 and 10 are not strictly decreasing (null <= 0)"));

  }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }


    org.apache.commons.math3.exception.MathArithmeticException var0 = new org.apache.commons.math3.exception.MathArithmeticException();
    java.lang.Throwable[] var1 = var0.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test418() {}
//   public void test418() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(0L);
//     java.lang.String var4 = var0.nextHexString(100);
//     java.lang.String var6 = var0.nextSecureHexString(1);
//     var0.reSeed((-1L));
//     double var10 = var0.nextExponential(0.915778680097192d);
//     var0.reSeedSecure();
//     double var13 = var0.nextT(0.7088914394874254d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"+ "'", var4.equals("7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "3"+ "'", var6.equals("3"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.3650947445123496d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-0.1141875233081197d));
// 
//   }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }


    int[] var0 = new int[] { };
    int[] var1 = null;
    int var2 = org.apache.commons.math3.util.MathArrays.distance1(var0, var1);
    int[] var3 = new int[] { };
    int[] var4 = null;
    int var5 = org.apache.commons.math3.util.MathArrays.distance1(var3, var4);
    org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c(var3);
    int[] var7 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var0, var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var3, (-1));
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);

  }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(0L);
    double var4 = var0.nextT(101.79109515357918d);
    double var6 = var0.nextT(10.0d);
    int[] var9 = var0.nextPermutation(19, 7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.6556684902257256d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.23842384721562462d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test421() {}
//   public void test421() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     var0.reSeedSecure();
//     var0.reSeed();
//     int var9 = var0.nextZipf(21, 0.044259860704679646d);
//     int var12 = var0.nextPascal(39, 0.29461270966732284d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var16 = var0.nextUniform(Double.NaN, 0.0181388340431587d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotANumberException");
//     } catch (org.apache.commons.math3.exception.NotANumberException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.0067651853359364375d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 85.68365263890715d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 65);
// 
//   }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double[] var18 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var18);
    org.apache.commons.math3.util.MathArrays.OrderDirection var20 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var18, var20, false);
    double var23 = org.apache.commons.math3.util.MathArrays.safeNorm(var18);
    double[] var25 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    double[] var28 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var28);
    double[] var31 = org.apache.commons.math3.util.MathArrays.copyOf(var28, 10);
    double var32 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var31);
    double[] var33 = org.apache.commons.math3.util.MathArrays.ebeDivide(var18, var25);
    org.apache.commons.math3.util.MathArrays.OrderDirection var34 = null;
    boolean var36 = org.apache.commons.math3.util.MathArrays.isMonotonic(var18, var34, true);
    double[] var37 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var8, var18);
    double[] var39 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var39);
    double[] var42 = org.apache.commons.math3.util.MathArrays.copyOf(var39, 10);
    double[] var44 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var44);
    boolean var46 = org.apache.commons.math3.util.MathArrays.equals(var39, var44);
    double[] var48 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var48);
    double[] var51 = org.apache.commons.math3.util.MathArrays.copyOf(var48, 10);
    double var52 = org.apache.commons.math3.util.MathArrays.distanceInf(var44, var51);
    org.apache.commons.math3.util.MathArrays.OrderDirection var53 = null;
    boolean var55 = org.apache.commons.math3.util.MathArrays.isMonotonic(var44, var53, true);
    double[] var57 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var57);
    double var59 = org.apache.commons.math3.util.MathArrays.distance1(var44, var57);
    double[] var61 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var61);
    double[] var64 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var64);
    double[] var67 = org.apache.commons.math3.util.MathArrays.copyOf(var64, 10);
    double var68 = org.apache.commons.math3.util.MathArrays.distanceInf(var61, var67);
    double[] var69 = org.apache.commons.math3.util.MathArrays.ebeDivide(var57, var61);
    boolean var70 = org.apache.commons.math3.util.MathArrays.equals(var37, var61);
    double[] var72 = org.apache.commons.math3.util.MathArrays.copyOf(var37, 39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);

  }

  public void test423() {}
//   public void test423() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(75L);
//     var1.setSeed(2L);
//     double[] var4 = null;
//     double[] var6 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var6);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var8 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var6, var8, false);
//     double var11 = org.apache.commons.math3.util.MathArrays.safeNorm(var6);
//     double[] var13 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var13);
//     double[] var16 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var16);
//     double[] var19 = org.apache.commons.math3.util.MathArrays.copyOf(var16, 10);
//     double var20 = org.apache.commons.math3.util.MathArrays.distanceInf(var13, var19);
//     double[] var21 = org.apache.commons.math3.util.MathArrays.ebeDivide(var6, var13);
//     double[] var23 = org.apache.commons.math3.util.MathArrays.normalizeArray(var6, 10.0d);
//     double[] var25 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var25);
//     double[] var28 = org.apache.commons.math3.util.MathArrays.copyOf(var25, 10);
//     double[] var30 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var30);
//     boolean var32 = org.apache.commons.math3.util.MathArrays.equals(var25, var30);
//     double[] var34 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var34);
//     double[] var37 = org.apache.commons.math3.util.MathArrays.copyOf(var34, 10);
//     double var38 = org.apache.commons.math3.util.MathArrays.distanceInf(var30, var37);
//     double var39 = org.apache.commons.math3.util.MathArrays.distanceInf(var23, var30);
//     double[] var41 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var41);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var43 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var41, var43, false);
//     double var46 = org.apache.commons.math3.util.MathArrays.distanceInf(var30, var41);
//     double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var30, 10);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var49 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var4, var48);
// 
//   }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(0L);
    double var3 = var0.nextDouble();
    var0.clear();
    double var5 = var0.nextGaussian();
    boolean var6 = var0.nextBoolean();
    double var7 = var0.nextDouble();
    var0.setSeed(100);
    var0.setSeed(0);
    var0.clear();
    var0.setSeed(3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.7432416673360078d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1.2016184922621251d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.3874438233115065d);

  }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(0L);
    double var3 = var0.nextDouble();
    var0.clear();
    var0.setSeed(1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.7432416673360078d);

  }

  public void test426() {}
//   public void test426() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     double var11 = var0.nextGamma(0.36157468479281d, 0.8376757571801716d);
//     double var14 = var0.nextCauchy(0.8376757571801716d, 0.3901018313315268d);
//     var0.reSeedSecure(477836925424025280L);
//     var0.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.30616747264586d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 122.17266510972681d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.06922450842808282d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "8"+ "'", var8.equals("8"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.3555301102081994d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.1412290133726715d);
// 
//   }

  public void test427() {}
//   public void test427() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     var0.reSeedSecure();
//     int var8 = var0.nextZipf(16, 100.38955484251419d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var0.nextSecureInt(39, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.7086286752451073d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 113.6745018569806d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1);
// 
//   }

  public void test428() {}
//   public void test428() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.util.MathArrays.OrderDirection var5 = null;
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var7 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(byte)100, (java.lang.Number)82.45368975667407d, 0, var5, false);
//     java.lang.Object[] var8 = new java.lang.Object[] { var7};
//     org.apache.commons.math3.exception.NotFiniteNumberException var9 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)100.38955484251419d, var8);
//     java.lang.String var10 = var9.toString();
// 
//   }

  public void test429() {}
//   public void test429() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)1, (java.lang.Number)1L, (java.lang.Number)(short)(-1));
//     java.lang.Number var5 = var4.getLo();
//     java.lang.String var6 = var4.toString();
// 
//   }

  public void test430() {}
//   public void test430() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     java.util.List var2 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var3 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var2);
// 
//   }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(0L);
    double var4 = var0.nextExponential(0.7432416673360078d);
    var0.reSeed(0L);
    double var9 = var0.nextGamma(103.25934629914218d, 140.37260799449047d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.36157468479281d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 14386.159160118537d);

  }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double var17 = org.apache.commons.math3.util.MathArrays.safeNorm(var8);
    java.lang.Comparable[] var20 = new java.lang.Comparable[] { (byte)(-1)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var21 = null;
    boolean var23 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var20, var21, true);
    org.apache.commons.math3.exception.NotFiniteNumberException var24 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)107.34245912507674d, (java.lang.Object[])var20);
    java.lang.Number var26 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var28 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.026278128681618596d, var26, 1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var29 = var28.getDirection();
    boolean var31 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var20, var29, true);
    boolean var33 = org.apache.commons.math3.util.MathArrays.isMonotonic(var8, var29, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);

  }

  public void test433() {}
//   public void test433() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }
// 
// 
//     double[] var1 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var1);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var1);
//     double[] var8 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 0.0d);
//     double[] var9 = null;
//     double[] var10 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var1, var9);
// 
//   }

  public void test434() {}
//   public void test434() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     int var5 = var0.nextBinomial(0, 0.0d);
//     long var7 = var0.nextPoisson(0.9385577265294871d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "a837ffcb9a220cc6a02b41bd93144152bab01d84d6e1a83908026ceb0a74dec2e5c2d2d13b7e1bd5989e622c0c2596b1427e"+ "'", var2.equals("a837ffcb9a220cc6a02b41bd93144152bab01d84d6e1a83908026ceb0a74dec2e5c2d2d13b7e1bd5989e622c0c2596b1427e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0L);
// 
//   }

  public void test435() {}
//   public void test435() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(98.7281415762265d);
//     int var9 = var0.nextZipf(100, 114.23712557956448d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var0.nextBinomial(3276, 1.3650947445123496d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.279183665745319d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 95.83302290170872d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 106.94616415928215d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
// 
//   }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double[] var18 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 10.0d);
    double[] var20 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var20);
    double[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 10);
    double[] var25 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var20, var25);
    double[] var29 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var29);
    double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 10);
    double var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var32);
    double var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var25);
    double[] var36 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var36);
    double[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var36, 10);
    double[] var41 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var41);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var36, var41);
    double[] var45 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var45);
    double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var45, 10);
    double var49 = org.apache.commons.math3.util.MathArrays.distanceInf(var41, var48);
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeAdd(var18, var41);
    double[] var52 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var52);
    double[] var55 = org.apache.commons.math3.util.MathArrays.copyOf(var52, 10);
    double[] var57 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var57);
    boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var52, var57);
    double[] var61 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var61);
    double[] var64 = org.apache.commons.math3.util.MathArrays.copyOf(var61, 10);
    double var65 = org.apache.commons.math3.util.MathArrays.distanceInf(var57, var64);
    org.apache.commons.math3.util.MathArrays.OrderDirection var66 = null;
    boolean var68 = org.apache.commons.math3.util.MathArrays.isMonotonic(var57, var66, true);
    double[] var70 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var70);
    double var72 = org.apache.commons.math3.util.MathArrays.distance1(var57, var70);
    double[] var74 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var74);
    double[] var77 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var77);
    double[] var80 = org.apache.commons.math3.util.MathArrays.copyOf(var77, 10);
    double var81 = org.apache.commons.math3.util.MathArrays.distanceInf(var74, var80);
    double[] var82 = org.apache.commons.math3.util.MathArrays.ebeDivide(var70, var74);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var83 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var18, var82);
    double var85 = var83.inverseCumulativeProbability(0.0d);
    double var86 = var83.getNumericalMean();
    boolean var87 = var83.isSupportLowerBoundInclusive();
    boolean var88 = var83.isSupportLowerBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 11.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == true);

  }

  public void test437() {}
//   public void test437() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(98.7281415762265d);
//     double var8 = var0.nextT(105.39091667829669d);
//     double var11 = var0.nextUniform((-0.28511490210253276d), 1.7436655355786597d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.540169246943888d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 100.15296555229952d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 101.46699383640379d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-0.742078808849123d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.7416991107644604d);
// 
//   }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double[] var18 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 10.0d);
    double[] var20 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var20);
    double[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 10);
    double[] var25 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var20, var25);
    double[] var29 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var29);
    double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 10);
    double var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var32);
    double var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var25);
    double[] var36 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var36);
    double[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var36, 10);
    double[] var41 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var41);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var36, var41);
    double[] var45 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var45);
    double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var45, 10);
    double var49 = org.apache.commons.math3.util.MathArrays.distanceInf(var41, var48);
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeAdd(var18, var41);
    double[] var52 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var52);
    double[] var55 = org.apache.commons.math3.util.MathArrays.copyOf(var52, 10);
    double[] var57 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var57);
    boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var52, var57);
    double[] var61 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var61);
    double[] var64 = org.apache.commons.math3.util.MathArrays.copyOf(var61, 10);
    double var65 = org.apache.commons.math3.util.MathArrays.distanceInf(var57, var64);
    org.apache.commons.math3.util.MathArrays.OrderDirection var66 = null;
    boolean var68 = org.apache.commons.math3.util.MathArrays.isMonotonic(var57, var66, true);
    double[] var70 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var70);
    double var72 = org.apache.commons.math3.util.MathArrays.distance1(var57, var70);
    double[] var74 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var74);
    double[] var77 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var77);
    double[] var80 = org.apache.commons.math3.util.MathArrays.copyOf(var77, 10);
    double var81 = org.apache.commons.math3.util.MathArrays.distanceInf(var74, var80);
    double[] var82 = org.apache.commons.math3.util.MathArrays.ebeDivide(var70, var74);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var83 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var18, var82);
    double var85 = var83.inverseCumulativeProbability(0.0d);
    boolean var86 = var83.isSupportUpperBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 11.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == true);

  }

  public void test439() {}
//   public void test439() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(0L);
//     long var5 = var0.nextSecureLong(10L, 100L);
//     int var8 = var0.nextSecureInt(0, 9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 29L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 5);
// 
//   }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }


    int[] var0 = new int[] { };
    int[] var1 = null;
    int var2 = org.apache.commons.math3.util.MathArrays.distance1(var0, var1);
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var3);
    double var7 = var4.nextGaussian(114.18897334891658d, 111.86588500825316d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 141.9175754724266d);

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(0L);
    double var3 = var0.nextDouble();
    var0.clear();
    double var5 = var0.nextGaussian();
    var0.setSeed(0);
    double var8 = var0.nextDouble();
    var0.clear();
    org.apache.commons.math3.random.RandomDataGenerator var10 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var13 = var10.nextF(102.08072974342622d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.7432416673360078d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1.2016184922621251d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.9775554539871507d);

  }

  public void test442() {}
//   public void test442() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 161574481, 19);
// 
//   }

  public void test443() {}
//   public void test443() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var8 = var0.nextUniform(0.3874438233115065d, 1.0d, true);
//     long var10 = var0.nextPoisson(0.5230125715149944d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var0.nextGamma((-0.1141875233081197d), 128.02836239135638d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.20057714260723755d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 103.3249364252739d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.46731183135078475d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0L);
// 
//   }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(15);

  }

  public void test445() {}
//   public void test445() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(111.86588500825316d);
//     java.util.Collection var3 = null;
//     java.lang.Object[] var5 = var0.nextSample(var3, 19);
// 
//   }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = null;
    boolean var9 = org.apache.commons.math3.util.MathArrays.isMonotonic(var1, var7, false);
    org.apache.commons.math3.util.MathArrays.OrderDirection var10 = null;
    boolean var12 = org.apache.commons.math3.util.MathArrays.isMonotonic(var1, var10, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkPositive(var1);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);

  }

  public void test447() {}
//   public void test447() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(0L);
//     double var4 = var0.nextExponential(0.7432416673360078d);
//     int var7 = var0.nextSecureInt(1, 100);
//     double var9 = var0.nextExponential(108.97593914807048d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.36157468479281d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 20.011572793205353d);
// 
//   }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0f, var1, 10, var3, true);
    java.lang.Number var6 = var5.getArgument();
    int var7 = var5.getIndex();
    java.lang.Number var8 = var5.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 0.0f+ "'", var6.equals(0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 0.0f+ "'", var8.equals(0.0f));

  }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double[] var18 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 10.0d);
    double[] var20 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var20);
    double[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 10);
    double[] var25 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var20, var25);
    double[] var29 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var29);
    double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 10);
    double var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var32);
    double var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var25);
    double[] var36 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var36);
    double[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var36, 10);
    double[] var41 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var41);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var36, var41);
    double[] var45 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var45);
    double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var45, 10);
    double var49 = org.apache.commons.math3.util.MathArrays.distanceInf(var41, var48);
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeAdd(var18, var41);
    double[] var52 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var52);
    double[] var55 = org.apache.commons.math3.util.MathArrays.copyOf(var52, 10);
    double[] var57 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var57);
    boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var52, var57);
    double[] var61 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var61);
    double[] var64 = org.apache.commons.math3.util.MathArrays.copyOf(var61, 10);
    double var65 = org.apache.commons.math3.util.MathArrays.distanceInf(var57, var64);
    org.apache.commons.math3.util.MathArrays.OrderDirection var66 = null;
    boolean var68 = org.apache.commons.math3.util.MathArrays.isMonotonic(var57, var66, true);
    double[] var70 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var70);
    double var72 = org.apache.commons.math3.util.MathArrays.distance1(var57, var70);
    double[] var74 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var74);
    double[] var77 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var77);
    double[] var80 = org.apache.commons.math3.util.MathArrays.copyOf(var77, 10);
    double var81 = org.apache.commons.math3.util.MathArrays.distanceInf(var74, var80);
    double[] var82 = org.apache.commons.math3.util.MathArrays.ebeDivide(var70, var74);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var83 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var18, var82);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var86 = var83.probability(112.60404725003615d, 0.36157468479281d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 11.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);

  }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException((-1), (-1));
    int var3 = var2.getDimension();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var7 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0d, (java.lang.Number)(byte)(-1), 1);
    boolean var8 = var7.getStrict();
    java.lang.String var9 = var7.toString();
    var2.addSuppressed((java.lang.Throwable)var7);
    java.lang.Throwable[] var11 = var2.getSuppressed();
    org.apache.commons.math3.exception.util.Localizable var12 = null;
    java.lang.Object[] var13 = null;
    org.apache.commons.math3.exception.MathIllegalStateException var14 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var2, var12, var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "org.apache.commons.math3.exception.NonMonotonicSequenceException: points 0 and 1 are not strictly increasing (-1 >= 1)"+ "'", var9.equals("org.apache.commons.math3.exception.NonMonotonicSequenceException: points 0 and 1 are not strictly increasing (-1 >= 1)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test451() {}
//   public void test451() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }
// 
// 
//     double[] var1 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var1);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
//     double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
//     double[] var8 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var8);
//     double[] var11 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var11);
//     double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
//     double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
//     double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
//     double[] var18 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 10.0d);
//     double[] var20 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var20);
//     double[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 10);
//     double[] var25 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var25);
//     boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var20, var25);
//     double[] var29 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var29);
//     double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 10);
//     double var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var32);
//     double var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var25);
//     double[] var36 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var36);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var38 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var36, var38, false);
//     double var41 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var36);
//     double[] var43 = org.apache.commons.math3.util.MathArrays.normalizeArray(var36, 98.30741799725186d);
//     double[] var44 = null;
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var45 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var36, var44);
// 
//   }

  public void test452() {}
//   public void test452() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var9 = var0.nextZipf(0, 102.88914887158289d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.4751224931848537d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 102.89838168084141d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.6693337239457806d);
// 
//   }

  public void test453() {}
//   public void test453() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     org.apache.commons.math3.exception.NotStrictlyPositiveException var4 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var2, (java.lang.Number)0L);
//     org.apache.commons.math3.exception.OutOfRangeException var8 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(-1.0f), (java.lang.Number)100.0f, (java.lang.Number)(short)0);
//     java.lang.Number var9 = var8.getLo();
//     var4.addSuppressed((java.lang.Throwable)var8);
//     java.lang.Throwable[] var11 = var4.getSuppressed();
//     org.apache.commons.math3.exception.NotFiniteNumberException var12 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)9.745524084025742E9d, (java.lang.Object[])var11);
//     org.apache.commons.math3.exception.MathInternalError var13 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var12);
// 
//   }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)118517391);

  }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0);
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var1.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(0L);
    double var3 = var0.nextDouble();
    var0.clear();
    double var5 = var0.nextGaussian();
    var0.setSeed(0);
    double var8 = var0.nextDouble();
    var0.clear();
    byte[] var10 = new byte[] { };
    var0.nextBytes(var10);
    long var12 = var0.nextLong();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.7432416673360078d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1.2016184922621251d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.9775554539871507d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-2269827290554446382L));

  }

  public void test457() {}
//   public void test457() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(0L);
//     double var4 = var0.nextExponential(0.7432416673360078d);
//     int var7 = var0.nextSecureInt(1, 100);
//     double var10 = var0.nextWeibull(10.0d, 114.23712557956448d);
//     int[] var13 = var0.nextPermutation(39, 36);
//     int[] var14 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var15 = new org.apache.commons.math3.random.Well19937c(var14);
//     int[] var17 = org.apache.commons.math3.util.MathArrays.copyOf(var14, 100);
//     int[] var19 = org.apache.commons.math3.util.MathArrays.copyOf(var14, 10);
//     int[] var21 = org.apache.commons.math3.util.MathArrays.copyOf(var14, 99);
//     int[] var22 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var23 = new org.apache.commons.math3.random.Well19937c(var22);
//     int[] var24 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var25 = new org.apache.commons.math3.random.Well19937c(var24);
//     int[] var27 = org.apache.commons.math3.util.MathArrays.copyOf(var24, 100);
//     int var28 = org.apache.commons.math3.util.MathArrays.distance1(var22, var24);
//     int[] var29 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var30 = new org.apache.commons.math3.random.Well19937c(var29);
//     int var31 = org.apache.commons.math3.util.MathArrays.distanceInf(var24, var29);
//     int var32 = org.apache.commons.math3.util.MathArrays.distanceInf(var14, var24);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var33 = org.apache.commons.math3.util.MathArrays.distance(var13, var24);
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.36157468479281d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 112.98997911642695d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 0);
// 
//   }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
    var0.setSeed(2L);
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);

  }

  public void test459() {}
//   public void test459() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 19, 0);
// 
//   }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(0L);
    var0.clear();
    int var4 = var0.nextInt();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1102768644));

  }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double[] var18 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 10.0d);
    double[] var20 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var20);
    double[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 10);
    double[] var24 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var20);
    double[] var26 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var26);
    org.apache.commons.math3.util.MathArrays.OrderDirection var28 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var26, var28, false);
    double var31 = org.apache.commons.math3.util.MathArrays.safeNorm(var26);
    double[] var33 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var33);
    double[] var36 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var36);
    double[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var36, 10);
    double var40 = org.apache.commons.math3.util.MathArrays.distanceInf(var33, var39);
    double[] var41 = org.apache.commons.math3.util.MathArrays.ebeDivide(var26, var33);
    double var42 = org.apache.commons.math3.util.MathArrays.safeNorm(var33);
    double[] var44 = org.apache.commons.math3.util.MathArrays.copyOf(var33, 1);
    double[] var46 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var46);
    double[] var49 = org.apache.commons.math3.util.MathArrays.copyOf(var46, 10);
    double[] var51 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var51);
    boolean var53 = org.apache.commons.math3.util.MathArrays.equals(var46, var51);
    double[] var55 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var55);
    double[] var58 = org.apache.commons.math3.util.MathArrays.copyOf(var55, 10);
    double var59 = org.apache.commons.math3.util.MathArrays.distanceInf(var51, var58);
    org.apache.commons.math3.util.MathArrays.OrderDirection var60 = null;
    boolean var62 = org.apache.commons.math3.util.MathArrays.isMonotonic(var51, var60, true);
    double[] var64 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var64);
    double var66 = org.apache.commons.math3.util.MathArrays.distance1(var51, var64);
    double[] var68 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var68);
    double[] var71 = org.apache.commons.math3.util.MathArrays.copyOf(var68, 10);
    double[] var73 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var73);
    org.apache.commons.math3.util.MathArrays.OrderDirection var75 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var73, var75, false);
    boolean var78 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var71, var73);
    double[] var79 = org.apache.commons.math3.util.MathArrays.ebeAdd(var51, var73);
    double[] var80 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var44, var51);
    double var81 = org.apache.commons.math3.util.MathArrays.distance1(var1, var51);
    double[] var82 = org.apache.commons.math3.util.MathArrays.copyOf(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);

  }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }


    org.apache.commons.math3.exception.MathArithmeticException var0 = new org.apache.commons.math3.exception.MathArithmeticException();
    org.apache.commons.math3.exception.util.ExceptionContext var1 = var0.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var0.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var0.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var0.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test463() {}
//   public void test463() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(0L);
//     long var5 = var0.nextSecureLong(10L, 100L);
//     double var7 = var0.nextT(119.7441447260784d);
//     int var10 = var0.nextPascal(62, 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 74L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.6553232415694416d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 2147483647);
// 
//   }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var1 = null;
    org.apache.commons.math3.exception.MathInternalError var2 = new org.apache.commons.math3.exception.MathInternalError(var0, var1);

  }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)110.0d);
    java.lang.Number var2 = var1.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 110.0d+ "'", var2.equals(110.0d));

  }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }


    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.lang.Object[] var4 = new java.lang.Object[] { (-1L)};
    org.apache.commons.math3.exception.MathIllegalArgumentException var5 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, var4);
    org.apache.commons.math3.exception.MathInternalError var6 = new org.apache.commons.math3.exception.MathInternalError(var1, var4);
    org.apache.commons.math3.exception.NotFiniteNumberException var7 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-0.28511490210253276d), var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(75L);
    var1.setSeed(2L);
    double[] var5 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var5);
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var5, var7, false);
    double var10 = org.apache.commons.math3.util.MathArrays.safeNorm(var5);
    double[] var12 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var12);
    double[] var15 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var15);
    double[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var15, 10);
    double var19 = org.apache.commons.math3.util.MathArrays.distanceInf(var12, var18);
    double[] var20 = org.apache.commons.math3.util.MathArrays.ebeDivide(var5, var12);
    double[] var22 = org.apache.commons.math3.util.MathArrays.normalizeArray(var5, 10.0d);
    double[] var24 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var24);
    double[] var27 = org.apache.commons.math3.util.MathArrays.copyOf(var24, 10);
    double[] var29 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var29);
    boolean var31 = org.apache.commons.math3.util.MathArrays.equals(var24, var29);
    double[] var33 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var33);
    double[] var36 = org.apache.commons.math3.util.MathArrays.copyOf(var33, 10);
    double var37 = org.apache.commons.math3.util.MathArrays.distanceInf(var29, var36);
    double var38 = org.apache.commons.math3.util.MathArrays.distanceInf(var22, var29);
    double[] var40 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var40);
    org.apache.commons.math3.util.MathArrays.OrderDirection var42 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var40, var42, false);
    double var45 = org.apache.commons.math3.util.MathArrays.safeNorm(var40);
    double[] var47 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var47);
    double[] var50 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var50);
    double[] var53 = org.apache.commons.math3.util.MathArrays.copyOf(var50, 10);
    double var54 = org.apache.commons.math3.util.MathArrays.distanceInf(var47, var53);
    double[] var55 = org.apache.commons.math3.util.MathArrays.ebeDivide(var40, var47);
    double[] var57 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var57);
    org.apache.commons.math3.util.MathArrays.OrderDirection var59 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var57, var59, false);
    double var62 = org.apache.commons.math3.util.MathArrays.safeNorm(var57);
    double[] var64 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var64);
    double[] var67 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var67);
    double[] var70 = org.apache.commons.math3.util.MathArrays.copyOf(var67, 10);
    double var71 = org.apache.commons.math3.util.MathArrays.distanceInf(var64, var70);
    double[] var72 = org.apache.commons.math3.util.MathArrays.ebeDivide(var57, var64);
    org.apache.commons.math3.util.MathArrays.OrderDirection var73 = null;
    boolean var75 = org.apache.commons.math3.util.MathArrays.isMonotonic(var57, var73, true);
    double[] var76 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var47, var57);
    org.apache.commons.math3.util.MathArrays.checkOrder(var47);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.DiscreteRealDistribution var78 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var22, var47);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 11.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);

  }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)161574481, (java.lang.Number)0.3979383851243543d, false);

  }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(0L);
    double var3 = var0.nextDouble();
    int[] var7 = new int[] { 1, 10, 100};
    var0.setSeed(var7);
    var0.setSeed(100);
    var0.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.7432416673360078d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test470() {}
//   public void test470() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(98.7281415762265d);
//     double var8 = var0.nextT(105.39091667829669d);
//     org.apache.commons.math3.distribution.IntegerDistribution var9 = null;
//     int var10 = var0.nextInversionDeviate(var9);
// 
//   }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(-0.3251554907629271d), (java.lang.Number)2.1070663248503236d, true);

  }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double[] var18 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 10.0d);
    double[] var20 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var20);
    double[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 10);
    double[] var25 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var20, var25);
    double[] var29 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var29);
    double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 10);
    double var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var32);
    double var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var25);
    double[] var36 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var36);
    double[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var36, 10);
    double[] var41 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var41);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var36, var41);
    double[] var45 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var45);
    double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var45, 10);
    double var49 = org.apache.commons.math3.util.MathArrays.distanceInf(var41, var48);
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeAdd(var18, var41);
    double[] var52 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var52);
    double[] var55 = org.apache.commons.math3.util.MathArrays.copyOf(var52, 10);
    double[] var57 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var57);
    boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var52, var57);
    double[] var61 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var61);
    double[] var64 = org.apache.commons.math3.util.MathArrays.copyOf(var61, 10);
    double var65 = org.apache.commons.math3.util.MathArrays.distanceInf(var57, var64);
    org.apache.commons.math3.util.MathArrays.OrderDirection var66 = null;
    boolean var68 = org.apache.commons.math3.util.MathArrays.isMonotonic(var57, var66, true);
    double[] var70 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var70);
    double var72 = org.apache.commons.math3.util.MathArrays.distance1(var57, var70);
    double[] var74 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var74);
    double[] var77 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var77);
    double[] var80 = org.apache.commons.math3.util.MathArrays.copyOf(var77, 10);
    double var81 = org.apache.commons.math3.util.MathArrays.distanceInf(var74, var80);
    double[] var82 = org.apache.commons.math3.util.MathArrays.ebeDivide(var70, var74);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var83 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var18, var82);
    double var85 = var83.inverseCumulativeProbability(0.0d);
    double var86 = var83.getNumericalMean();
    boolean var87 = var83.isSupportLowerBoundInclusive();
    double var88 = var83.getNumericalVariance();
    double var91 = var83.cumulativeProbability((-1.7185138799120012d), 0.29461270966732284d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 11.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var91 == 0.0d);

  }

  public void test473() {}
//   public void test473() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     java.util.List var1 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var2 = new org.apache.commons.math3.distribution.DiscreteDistribution(var0, var1);
// 
//   }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    double[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 10);
    double[] var6 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var6);
    boolean var8 = org.apache.commons.math3.util.MathArrays.equals(var1, var6);
    double[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var12 = org.apache.commons.math3.util.MathArrays.normalizeArray(var10, (-0.28511490210253276d));
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)114.23712557956448d, (java.lang.Number)0.09175824555693415d, 0);
    boolean var4 = var3.getStrict();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }


    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.4924399031470064E10d, (java.lang.Number)(-0.06187681393378908d), 1, var3, true);
    java.lang.Number var6 = var5.getPrevious();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (-0.06187681393378908d)+ "'", var6.equals((-0.06187681393378908d)));

  }

  public void test477() {}
//   public void test477() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }
// 
// 
//     double[] var1 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var1);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
//     double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
//     double[] var8 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var8);
//     double[] var11 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var11);
//     double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
//     double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
//     double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
//     double[] var18 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 10.0d);
//     double[] var20 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var20);
//     double[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 10);
//     double[] var25 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var25);
//     boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var20, var25);
//     double[] var29 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var29);
//     double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 10);
//     double var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var32);
//     double var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var25);
//     double[] var36 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var36);
//     double[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var36, 10);
//     double[] var41 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var41);
//     boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var36, var41);
//     double[] var45 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var45);
//     double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var45, 10);
//     double var49 = org.apache.commons.math3.util.MathArrays.distanceInf(var41, var48);
//     double[] var50 = org.apache.commons.math3.util.MathArrays.ebeAdd(var18, var41);
//     double[] var52 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var52);
//     double[] var55 = org.apache.commons.math3.util.MathArrays.copyOf(var52, 10);
//     double[] var57 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var57);
//     boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var52, var57);
//     double[] var61 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var61);
//     double[] var64 = org.apache.commons.math3.util.MathArrays.copyOf(var61, 10);
//     double var65 = org.apache.commons.math3.util.MathArrays.distanceInf(var57, var64);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var66 = null;
//     boolean var68 = org.apache.commons.math3.util.MathArrays.isMonotonic(var57, var66, true);
//     double[] var70 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var70);
//     double var72 = org.apache.commons.math3.util.MathArrays.distance1(var57, var70);
//     double[] var74 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var74);
//     double[] var77 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var77);
//     double[] var80 = org.apache.commons.math3.util.MathArrays.copyOf(var77, 10);
//     double var81 = org.apache.commons.math3.util.MathArrays.distanceInf(var74, var80);
//     double[] var82 = org.apache.commons.math3.util.MathArrays.ebeDivide(var70, var74);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var83 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var18, var82);
//     double var85 = var83.cumulativeProbability((-1.1720092180091226d));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double[] var87 = var83.sample(60420325);
//       fail("Expected exception of type java.lang.OutOfMemoryError");
//     } catch (java.lang.OutOfMemoryError e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 11.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var68 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var70);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var72 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var74);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var81 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var82);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var85 == 0.0d);
// 
//   }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double var17 = org.apache.commons.math3.util.MathArrays.safeNorm(var8);
    double[] var19 = org.apache.commons.math3.util.MathArrays.copyOf(var8, 1);
    double[] var20 = null;
    boolean var21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var8, var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);

  }

  public void test479() {}
//   public void test479() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     int var5 = var0.nextBinomial(10, 0.03863055888020799d);
//     int var8 = var0.nextSecureInt(7, 48);
//     long var11 = var0.nextSecureLong(0L, 95L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var14 = var0.nextPermutation(100, (-1276125876));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-1.4088144820197248d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 91L);
// 
//   }

  public void test480() {}
//   public void test480() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(111.86588500825316d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var5 = var0.nextCauchy(0.7416991107644604d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 91.32664160502d);
// 
//   }

  public void test481() {}
//   public void test481() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     double var11 = var0.nextGamma(0.36157468479281d, 0.8376757571801716d);
//     double var14 = var0.nextCauchy(0.8376757571801716d, 0.3901018313315268d);
//     var0.reSeedSecure(477836925424025280L);
//     double var19 = var0.nextGaussian(0.03863055888020799d, 105.27987576727645d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.2763414335696296d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 95.05446642472492d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.13907557142127921d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "8"+ "'", var8.equals("8"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.07001657430542792d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.0567312120713608d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-119.1861576778888d));
// 
//   }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.lang.Object[] var4 = new java.lang.Object[] { (short)10};
    org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError(var2, var4);
    org.apache.commons.math3.exception.NotFiniteNumberException var6 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)(-0.04467793504673921d), var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test483() {}
//   public void test483() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     int var5 = var0.nextBinomial(10, 0.03863055888020799d);
//     int var8 = var0.nextSecureInt(7, 48);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var11 = var0.nextSecureLong(1024457413273955602L, 434277157163744896L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.04857045881358565d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 26);
// 
//   }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)9.745524084025742E9d);

  }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    java.lang.Object[] var8 = new java.lang.Object[] { 'a'};
    org.apache.commons.math3.exception.NotFiniteNumberException var9 = new org.apache.commons.math3.exception.NotFiniteNumberException(var5, (java.lang.Number)(short)0, var8);
    org.apache.commons.math3.exception.NotFiniteNumberException var10 = new org.apache.commons.math3.exception.NotFiniteNumberException(var3, (java.lang.Number)10L, var8);
    org.apache.commons.math3.exception.NotFiniteNumberException var11 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Number)114.23712557956448d, var8);
    org.apache.commons.math3.exception.MathIllegalArgumentException var12 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    double[] var2 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var2);
    org.apache.commons.math3.util.MathArrays.OrderDirection var4 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var2, var4, false);
    double var7 = org.apache.commons.math3.util.MathArrays.safeNorm(var2);
    double[] var9 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    double[] var12 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var12);
    double[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var12, 10);
    double var16 = org.apache.commons.math3.util.MathArrays.distanceInf(var9, var15);
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeDivide(var2, var9);
    double[] var19 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var19);
    org.apache.commons.math3.util.MathArrays.OrderDirection var21 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var19, var21, false);
    double var24 = org.apache.commons.math3.util.MathArrays.safeNorm(var19);
    double[] var26 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var26);
    double[] var29 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var29);
    double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 10);
    double var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var26, var32);
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeDivide(var19, var26);
    double[] var36 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var36);
    org.apache.commons.math3.util.MathArrays.OrderDirection var38 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var36, var38, false);
    double var41 = org.apache.commons.math3.util.MathArrays.safeNorm(var36);
    org.apache.commons.math3.util.MathArrays.OrderDirection var42 = null;
    boolean var44 = org.apache.commons.math3.util.MathArrays.isMonotonic(var36, var42, false);
    double[][] var45 = new double[][] { var36};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var19, var45);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var17, var45);
    org.apache.commons.math3.exception.MathArithmeticException var48 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);

  }

  public void test487() {}
//   public void test487() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     var0.reSeedSecure();
//     var0.reSeed();
//     int var9 = var0.nextZipf(21, 0.044259860704679646d);
//     int var12 = var0.nextPascal(39, 0.29461270966732284d);
//     int var15 = var0.nextSecureInt(95, 100);
//     long var18 = var0.nextLong(0L, 87L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var20 = var0.nextHexString(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.077806206962262d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 145.55887787879266d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 82);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 100);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1L);
// 
//   }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    int[] var2 = new int[] { };
    int[] var3 = null;
    int var4 = org.apache.commons.math3.util.MathArrays.distance1(var2, var3);
    org.apache.commons.math3.random.Well19937c var5 = new org.apache.commons.math3.random.Well19937c(var2);
    int[] var7 = org.apache.commons.math3.util.MathArrays.copyOf(var2, 0);
    int[] var8 = new int[] { };
    int[] var9 = null;
    int var10 = org.apache.commons.math3.util.MathArrays.distance1(var8, var9);
    org.apache.commons.math3.random.Well19937c var11 = new org.apache.commons.math3.random.Well19937c(var8);
    int[] var12 = org.apache.commons.math3.util.MathArrays.copyOf(var8);
    org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(var8);
    int var14 = org.apache.commons.math3.util.MathArrays.distanceInf(var7, var8);
    var1.setSeed(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);

  }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(0L);
    double var3 = var0.nextDouble();
    var0.clear();
    double var5 = var0.nextGaussian();
    var0.setSeed(0);
    double var8 = var0.nextDouble();
    var0.clear();
    org.apache.commons.math3.random.RandomDataGenerator var10 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
    boolean var11 = var0.nextBoolean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.7432416673360078d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1.2016184922621251d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.9775554539871507d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test490() {}
//   public void test490() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var3 = var1.nextChiSquare(1.3650947445123496d);
//     double var6 = var1.nextWeibull(1.0d, 0.3874438233115065d);
//     long var9 = var1.nextSecureLong(1L, 10L);
//     var1.reSeed(90L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var13 = var1.nextPoisson((-0.14215215277913013d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.4116025067975983d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.3590440734975764d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 8L);
// 
//   }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException((-1102768644), (-1));

  }

  public void test492() {}
//   public void test492() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     int var5 = var0.nextBinomial(10, 0.03863055888020799d);
//     var0.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.9748894883400403d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
// 
//   }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }


    int[] var0 = new int[] { };
    int[] var1 = null;
    int var2 = org.apache.commons.math3.util.MathArrays.distance1(var0, var1);
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var0);
    double var4 = var3.nextGaussian();
    double var5 = var3.nextDouble();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.2478736222527921d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.055535956152579224d);

  }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    java.lang.Object[] var9 = new java.lang.Object[] { 'a'};
    org.apache.commons.math3.exception.NotFiniteNumberException var10 = new org.apache.commons.math3.exception.NotFiniteNumberException(var6, (java.lang.Number)(short)0, var9);
    org.apache.commons.math3.exception.NotFiniteNumberException var11 = new org.apache.commons.math3.exception.NotFiniteNumberException(var4, (java.lang.Number)10L, var9);
    org.apache.commons.math3.exception.NotFiniteNumberException var12 = new org.apache.commons.math3.exception.NotFiniteNumberException(var2, (java.lang.Number)114.23712557956448d, var9);
    org.apache.commons.math3.exception.MathInternalError var13 = new org.apache.commons.math3.exception.MathInternalError(var1, var9);
    org.apache.commons.math3.exception.MathInternalError var14 = new org.apache.commons.math3.exception.MathInternalError(var0, var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(byte)1, (java.lang.Number)(short)(-1), false);
    java.lang.Number var4 = var3.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (short)(-1)+ "'", var4.equals((short)(-1)));

  }

  public void test496() {}
//   public void test496() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }
// 
// 
//     int[] var0 = null;
//     int[] var1 = org.apache.commons.math3.util.MathArrays.copyOf(var0);
// 
//   }

  public void test497() {}
//   public void test497() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
//     var1.reSeed();
//     double var5 = var1.nextF(0.9776956941774123d, 0.0181388340431587d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("6", "4062f5fcd0938424eacbf21729a55a9bcb19");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 4.9572903468214035E9d);
// 
//   }

  public void test498() {}
//   public void test498() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     double var11 = var0.nextGamma(0.36157468479281d, 0.8376757571801716d);
//     var0.reSeed();
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var0.nextT((-119.1861576778888d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.24608355666454398d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 96.91354253498324d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3.2360466991606298E-6d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "7"+ "'", var8.equals("7"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2.0294799074246628d);
// 
//   }

  public void test499() {}
//   public void test499() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(0L);
//     double var4 = var0.nextExponential(0.7432416673360078d);
//     int var7 = var0.nextSecureInt(1, 100);
//     double var10 = var0.nextWeibull(10.0d, 114.23712557956448d);
//     int[] var13 = var0.nextPermutation(39, 36);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var16 = var0.nextBeta(128.02836239135638d, Double.NaN);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.36157468479281d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 112.98997911642695d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
// 
//   }

  public void test500() {}
//   public void test500() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(0L);
//     java.lang.String var4 = var0.nextHexString(100);
//     java.lang.String var6 = var0.nextSecureHexString(1);
//     var0.reSeed((-1L));
//     double var10 = var0.nextExponential(0.915778680097192d);
//     var0.reSeedSecure();
//     long var14 = var0.nextLong(10L, 1024457413273955602L);
//     var0.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"+ "'", var4.equals("7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "4"+ "'", var6.equals("4"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.3650947445123496d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 477836925424025280L);
// 
//   }

}
