
import junit.framework.*;

public class RandoopTest1 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test1"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    double[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 10);
    double[] var6 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var6);
    boolean var8 = org.apache.commons.math3.util.MathArrays.equals(var1, var6);
    org.apache.commons.math3.util.MathArrays.OrderDirection var9 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var6, var9, false);
    double[] var13 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var13);
    double[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var13, 10);
    double[] var18 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var18);
    org.apache.commons.math3.util.MathArrays.OrderDirection var20 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var18, var20, false);
    double var23 = org.apache.commons.math3.util.MathArrays.safeNorm(var18);
    double[] var25 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    double[] var28 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var28);
    double[] var31 = org.apache.commons.math3.util.MathArrays.copyOf(var28, 10);
    double var32 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var31);
    double[] var33 = org.apache.commons.math3.util.MathArrays.ebeDivide(var18, var25);
    double[] var35 = org.apache.commons.math3.util.MathArrays.normalizeArray(var18, 10.0d);
    double var36 = org.apache.commons.math3.util.MathArrays.distance(var13, var18);
    double[] var37 = org.apache.commons.math3.util.MathArrays.ebeAdd(var6, var18);
    double[] var39 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var39);
    double[] var42 = org.apache.commons.math3.util.MathArrays.copyOf(var39, 10);
    double[] var44 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var44);
    boolean var46 = org.apache.commons.math3.util.MathArrays.equals(var39, var44);
    double[] var48 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var48);
    double[] var51 = org.apache.commons.math3.util.MathArrays.copyOf(var48, 10);
    double var52 = org.apache.commons.math3.util.MathArrays.distanceInf(var44, var51);
    org.apache.commons.math3.util.MathArrays.OrderDirection var53 = null;
    boolean var55 = org.apache.commons.math3.util.MathArrays.isMonotonic(var44, var53, true);
    double[] var57 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var57);
    double var59 = org.apache.commons.math3.util.MathArrays.distance1(var44, var57);
    double[] var61 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var61);
    double[] var64 = org.apache.commons.math3.util.MathArrays.copyOf(var61, 10);
    double[] var66 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var66);
    org.apache.commons.math3.util.MathArrays.OrderDirection var68 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var66, var68, false);
    boolean var71 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var64, var66);
    double[] var72 = org.apache.commons.math3.util.MathArrays.ebeAdd(var44, var66);
    double[] var73 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var18, var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test2"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double[] var18 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 10.0d);
    double[] var20 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var20);
    double[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 10);
    double[] var25 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var20, var25);
    double[] var29 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var29);
    double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 10);
    double var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var32);
    double var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var25);
    double[] var36 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var36);
    double[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var36, 10);
    double[] var41 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var41);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var36, var41);
    double[] var45 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var45);
    double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var45, 10);
    double var49 = org.apache.commons.math3.util.MathArrays.distanceInf(var41, var48);
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeAdd(var18, var41);
    double[] var52 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var52);
    double[] var55 = org.apache.commons.math3.util.MathArrays.copyOf(var52, 10);
    double[] var57 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var57);
    boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var52, var57);
    double[] var61 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var61);
    double[] var64 = org.apache.commons.math3.util.MathArrays.copyOf(var61, 10);
    double var65 = org.apache.commons.math3.util.MathArrays.distanceInf(var57, var64);
    org.apache.commons.math3.util.MathArrays.OrderDirection var66 = null;
    boolean var68 = org.apache.commons.math3.util.MathArrays.isMonotonic(var57, var66, true);
    double[] var70 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var70);
    double var72 = org.apache.commons.math3.util.MathArrays.distance1(var57, var70);
    double[] var74 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var74);
    double[] var77 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var77);
    double[] var80 = org.apache.commons.math3.util.MathArrays.copyOf(var77, 10);
    double var81 = org.apache.commons.math3.util.MathArrays.distanceInf(var74, var80);
    double[] var82 = org.apache.commons.math3.util.MathArrays.ebeDivide(var70, var74);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var83 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var18, var82);
    double[] var84 = null;
    boolean var85 = org.apache.commons.math3.util.MathArrays.equals(var18, var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 11.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == false);

  }

  public void test3() {}
//   public void test3() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test3"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
//     var1.reSeed();
//     double var5 = var1.nextCauchy(82.45368975667407d, 82.45368975667407d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var8 = var1.nextUniform(119.0147763482431d, 0.5805999842164986d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-11.513936909777868d));
// 
//   }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test4"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)128.35556077963213d);
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    java.lang.Object[] var10 = new java.lang.Object[] { 'a'};
    org.apache.commons.math3.exception.NotFiniteNumberException var11 = new org.apache.commons.math3.exception.NotFiniteNumberException(var7, (java.lang.Number)(short)0, var10);
    org.apache.commons.math3.exception.NotFiniteNumberException var12 = new org.apache.commons.math3.exception.NotFiniteNumberException(var5, (java.lang.Number)10L, var10);
    org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException(var4, var10);
    org.apache.commons.math3.exception.NullArgumentException var14 = new org.apache.commons.math3.exception.NullArgumentException(var3, var10);
    var2.addSuppressed((java.lang.Throwable)var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test5"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(0L);
    double var3 = var0.nextDouble();
    var0.clear();
    double var5 = var0.nextGaussian();
    var0.setSeed(0);
    double var8 = var0.nextDouble();
    var0.clear();
    org.apache.commons.math3.random.RandomDataGenerator var10 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
    int var11 = var0.nextInt();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.7432416673360078d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1.2016184922621251d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.9775554539871507d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 669834927);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test6"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double[] var18 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var18);
    org.apache.commons.math3.util.MathArrays.OrderDirection var20 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var18, var20, false);
    double var23 = org.apache.commons.math3.util.MathArrays.safeNorm(var18);
    double[] var25 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    double[] var28 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var28);
    double[] var31 = org.apache.commons.math3.util.MathArrays.copyOf(var28, 10);
    double var32 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var31);
    double[] var33 = org.apache.commons.math3.util.MathArrays.ebeDivide(var18, var25);
    double[] var35 = org.apache.commons.math3.util.MathArrays.normalizeArray(var18, 10.0d);
    double[] var37 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var37);
    double[] var40 = org.apache.commons.math3.util.MathArrays.copyOf(var37, 10);
    double[] var42 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var42);
    boolean var44 = org.apache.commons.math3.util.MathArrays.equals(var37, var42);
    double[] var46 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var46);
    double[] var49 = org.apache.commons.math3.util.MathArrays.copyOf(var46, 10);
    double var50 = org.apache.commons.math3.util.MathArrays.distanceInf(var42, var49);
    double var51 = org.apache.commons.math3.util.MathArrays.distanceInf(var35, var42);
    double[] var53 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var53);
    double[] var56 = org.apache.commons.math3.util.MathArrays.copyOf(var53, 10);
    double[] var58 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var58);
    boolean var60 = org.apache.commons.math3.util.MathArrays.equals(var53, var58);
    double[] var62 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var62);
    double[] var65 = org.apache.commons.math3.util.MathArrays.copyOf(var62, 10);
    double var66 = org.apache.commons.math3.util.MathArrays.distanceInf(var58, var65);
    double[] var67 = org.apache.commons.math3.util.MathArrays.ebeAdd(var35, var58);
    double[] var69 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var69);
    org.apache.commons.math3.util.MathArrays.OrderDirection var71 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var69, var71, false);
    double var74 = org.apache.commons.math3.util.MathArrays.safeNorm(var69);
    double[] var76 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var76);
    double[] var79 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var79);
    double[] var82 = org.apache.commons.math3.util.MathArrays.copyOf(var79, 10);
    double var83 = org.apache.commons.math3.util.MathArrays.distanceInf(var76, var82);
    double[] var84 = org.apache.commons.math3.util.MathArrays.ebeDivide(var69, var76);
    double var85 = org.apache.commons.math3.util.MathArrays.safeNorm(var76);
    double[] var86 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var35, var76);
    boolean var87 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var1, var76);
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 11.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == true);

  }

  public void test7() {}
//   public void test7() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test7"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     double var11 = var0.nextGamma(0.36157468479281d, 0.8376757571801716d);
//     var0.reSeed();
//     java.lang.String var14 = var0.nextHexString(16);
//     double var16 = var0.nextExponential(1.1412290133726715d);
//     var0.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.3618916980462404d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 115.5832582562984d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.009869003737350644d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "1"+ "'", var8.equals("1"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.11616125877882791d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "b5e8d61fde0022e4"+ "'", var14.equals("b5e8d61fde0022e4"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 2.2604411028772566d);
// 
//   }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test8"); }


    float[] var0 = null;
    float[] var3 = new float[] { 100.0f, 10.0f};
    boolean var4 = org.apache.commons.math3.util.MathArrays.equals(var0, var3);
    float[] var8 = new float[] { 0.0f, (-1.0f), 0.0f};
    boolean var9 = org.apache.commons.math3.util.MathArrays.equals(var3, var8);
    float[] var10 = null;
    float[] var13 = new float[] { 100.0f, 10.0f};
    boolean var14 = org.apache.commons.math3.util.MathArrays.equals(var10, var13);
    float[] var18 = new float[] { 0.0f, (-1.0f), 0.0f};
    boolean var19 = org.apache.commons.math3.util.MathArrays.equals(var13, var18);
    float[] var20 = null;
    float[] var23 = new float[] { 100.0f, 10.0f};
    boolean var24 = org.apache.commons.math3.util.MathArrays.equals(var20, var23);
    float[] var28 = new float[] { 0.0f, (-1.0f), 0.0f};
    boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var23, var28);
    boolean var30 = org.apache.commons.math3.util.MathArrays.equals(var13, var23);
    boolean var31 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var8, var13);
    float[] var32 = null;
    float[] var35 = new float[] { 100.0f, 10.0f};
    boolean var36 = org.apache.commons.math3.util.MathArrays.equals(var32, var35);
    float[] var40 = new float[] { 0.0f, (-1.0f), 0.0f};
    boolean var41 = org.apache.commons.math3.util.MathArrays.equals(var35, var40);
    float[] var42 = null;
    float[] var45 = new float[] { 100.0f, 10.0f};
    boolean var46 = org.apache.commons.math3.util.MathArrays.equals(var42, var45);
    float[] var50 = new float[] { 0.0f, (-1.0f), 0.0f};
    boolean var51 = org.apache.commons.math3.util.MathArrays.equals(var45, var50);
    float[] var52 = null;
    float[] var55 = new float[] { 100.0f, 10.0f};
    boolean var56 = org.apache.commons.math3.util.MathArrays.equals(var52, var55);
    float[] var60 = new float[] { 0.0f, (-1.0f), 0.0f};
    boolean var61 = org.apache.commons.math3.util.MathArrays.equals(var55, var60);
    boolean var62 = org.apache.commons.math3.util.MathArrays.equals(var45, var55);
    boolean var63 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var40, var45);
    boolean var64 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var8, var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == true);

  }

  public void test9() {}
//   public void test9() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test9"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     var0.reSeedSecure();
//     var0.reSeed();
//     int var9 = var0.nextZipf(21, 0.044259860704679646d);
//     double var11 = var0.nextExponential(0.94947016522495d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var0.nextGamma(114.18897334891658d, (-2.1031364139386386d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.022964526252564607d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 135.06959891024903d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.22310387190641331d);
// 
//   }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test10"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double[] var18 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 10.0d);
    double[] var20 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var20);
    double[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 10);
    double[] var25 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var20, var25);
    double[] var29 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var29);
    double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 10);
    double var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var32);
    double var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var25);
    double[] var36 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var36);
    double[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var36, 10);
    double[] var41 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var41);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var36, var41);
    double[] var45 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var45);
    double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var45, 10);
    double var49 = org.apache.commons.math3.util.MathArrays.distanceInf(var41, var48);
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeAdd(var18, var41);
    double[] var52 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var52);
    double[] var55 = org.apache.commons.math3.util.MathArrays.copyOf(var52, 10);
    double[] var57 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var57);
    boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var52, var57);
    double[] var61 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var61);
    double[] var64 = org.apache.commons.math3.util.MathArrays.copyOf(var61, 10);
    double var65 = org.apache.commons.math3.util.MathArrays.distanceInf(var57, var64);
    org.apache.commons.math3.util.MathArrays.OrderDirection var66 = null;
    boolean var68 = org.apache.commons.math3.util.MathArrays.isMonotonic(var57, var66, true);
    double[] var70 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var70);
    double var72 = org.apache.commons.math3.util.MathArrays.distance1(var57, var70);
    double[] var74 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var74);
    double[] var77 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var77);
    double[] var80 = org.apache.commons.math3.util.MathArrays.copyOf(var77, 10);
    double var81 = org.apache.commons.math3.util.MathArrays.distanceInf(var74, var80);
    double[] var82 = org.apache.commons.math3.util.MathArrays.ebeDivide(var70, var74);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var83 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var18, var82);
    double var86 = var83.probability(0.0d, 76.50641463552304d);
    double var87 = var83.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 11.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == 10.0d);

  }

  public void test11() {}
//   public void test11() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test11"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     double var11 = var0.nextGamma(0.36157468479281d, 0.8376757571801716d);
//     int var14 = var0.nextBinomial(1, 0.7432416673360078d);
//     double var17 = var0.nextBeta(3.3900817738101328d, 11787.308968688245d);
//     double var20 = var0.nextBeta(0.3901018313315268d, 7.890608942511265d);
//     org.apache.commons.math3.distribution.RealDistribution var21 = null;
//     double var22 = var0.nextInversionDeviate(var21);
// 
//   }

  public void test12() {}
//   public void test12() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test12"); }
// 
// 
//     double[] var1 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var1);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
//     double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
//     double[] var8 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var8);
//     double[] var11 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var11);
//     double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
//     double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
//     double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
//     double[] var18 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var18);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var20 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var18, var20, false);
//     double var23 = org.apache.commons.math3.util.MathArrays.safeNorm(var18);
//     double[] var25 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var25);
//     double[] var28 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var28);
//     double[] var31 = org.apache.commons.math3.util.MathArrays.copyOf(var28, 10);
//     double var32 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var31);
//     double[] var33 = org.apache.commons.math3.util.MathArrays.ebeDivide(var18, var25);
//     double[] var35 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var35);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var37 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var35, var37, false);
//     double var40 = org.apache.commons.math3.util.MathArrays.safeNorm(var35);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var41 = null;
//     boolean var43 = org.apache.commons.math3.util.MathArrays.isMonotonic(var35, var41, false);
//     double[][] var44 = new double[][] { var35};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var18, var44);
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var16, var44);
//     double[] var47 = org.apache.commons.math3.util.MathArrays.copyOf(var16);
//     double[] var48 = null;
//     double[] var49 = org.apache.commons.math3.util.MathArrays.ebeDivide(var16, var48);
// 
//   }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test13"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(1);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test14"); }


    int[] var0 = new int[] { };
    int[] var1 = null;
    int var2 = org.apache.commons.math3.util.MathArrays.distance1(var0, var1);
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var0);
    double var4 = var3.nextGaussian();
    double[] var6 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var6);
    double[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var6, 10);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var6, var11);
    double[] var15 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var15);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.DiscreteRealDistribution var17 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var3, var11, var15);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.2478736222527921d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test15"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(-1.0f), (java.lang.Number)100.0f, (java.lang.Number)(short)0);
    java.lang.Number var4 = var3.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (short)0+ "'", var4.equals((short)0));

  }

  public void test16() {}
//   public void test16() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test16"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var0.nextUniform(0.9385577265294871d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.5856287402480556d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 102.88091160316019d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.0386422160578646E-6d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "7"+ "'", var8.equals("7"));
// 
//   }

  public void test17() {}
//   public void test17() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test17"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     var0.reSeedSecure();
//     var0.reSeed();
//     double var9 = var0.nextUniform(0.0015326576218039215d, 114.81244598869324d);
//     var0.reSeedSecure();
//     int var14 = var0.nextHypergeometric(669834927, 80, 36);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var17 = var0.nextBinomial(274497138, (-0.4563799204122316d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-2.227225167049173d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 102.05774699666976d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 61.92494935346379d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
// 
//   }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test18"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var3 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var1, (java.lang.Number)0L);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    org.apache.commons.math3.exception.NullArgumentException var5 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test19"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Object[] var3 = new java.lang.Object[] { (short)10};
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError(var1, var3);
    org.apache.commons.math3.exception.MathIllegalStateException var5 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var3);
    org.apache.commons.math3.exception.util.ExceptionContext var6 = var5.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test20"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(52084938, 0);
    int var3 = var2.getDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);

  }

  public void test21() {}
//   public void test21() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test21"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(0L);
//     java.lang.String var4 = var0.nextHexString(100);
//     java.lang.String var6 = var0.nextSecureHexString(1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var0.nextHypergeometric(5, 0, 36);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"+ "'", var4.equals("7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "3"+ "'", var6.equals("3"));
// 
//   }

  public void test22() {}
//   public void test22() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test22"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 15, 80);
// 
//   }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test23"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.6466912681842636d, (java.lang.Number)2L, false);

  }

  public void test24() {}
//   public void test24() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test24"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 11, 15);
// 
//   }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test25"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(0.0635047316396446d, 94.20964941102557d, 0.7128409704596d, 14386.159160118537d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 10261.026415388875d);

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test26"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double[] var18 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 10.0d);
    double[] var20 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var20);
    double[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 10);
    double[] var25 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var20, var25);
    double[] var29 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var29);
    double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 10);
    double var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var32);
    double var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var25);
    double[] var36 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var36);
    double[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var36, 10);
    double[] var41 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var41);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var36, var41);
    double[] var45 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var45);
    double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var45, 10);
    double var49 = org.apache.commons.math3.util.MathArrays.distanceInf(var41, var48);
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeAdd(var18, var41);
    double[] var52 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var52);
    double[] var55 = org.apache.commons.math3.util.MathArrays.copyOf(var52, 10);
    double[] var57 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var57);
    boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var52, var57);
    double[] var61 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var61);
    double[] var64 = org.apache.commons.math3.util.MathArrays.copyOf(var61, 10);
    double var65 = org.apache.commons.math3.util.MathArrays.distanceInf(var57, var64);
    org.apache.commons.math3.util.MathArrays.OrderDirection var66 = null;
    boolean var68 = org.apache.commons.math3.util.MathArrays.isMonotonic(var57, var66, true);
    double[] var70 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var70);
    double var72 = org.apache.commons.math3.util.MathArrays.distance1(var57, var70);
    double[] var74 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var74);
    double[] var77 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var77);
    double[] var80 = org.apache.commons.math3.util.MathArrays.copyOf(var77, 10);
    double var81 = org.apache.commons.math3.util.MathArrays.distanceInf(var74, var80);
    double[] var82 = org.apache.commons.math3.util.MathArrays.ebeDivide(var70, var74);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var83 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var18, var82);
    double var84 = var83.getSupportUpperBound();
    boolean var85 = var83.isSupportLowerBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 11.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == true);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test27"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(0L);
    double var3 = var0.nextDouble();
    var0.clear();
    double var5 = var0.nextGaussian();
    boolean var6 = var0.nextBoolean();
    double var7 = var0.nextDouble();
    var0.setSeed(100);
    var0.setSeed(1L);
    org.apache.commons.math3.random.RandomDataImpl var12 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    int var15 = var12.nextPascal(15, 0.4606158088105561d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var18 = var12.nextInt(60420325, (-2087310710));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.7432416673360078d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1.2016184922621251d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.3874438233115065d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 9);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test28"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)43.35042744195363d);
    boolean var3 = var2.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test29() {}
//   public void test29() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test29"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
//     var1.reSeed();
//     double var5 = var1.nextCauchy(82.45368975667407d, 82.45368975667407d);
//     long var7 = var1.nextPoisson(5.610049266766251E-8d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var1.nextBinomial(312574995, (-0.14067868274055728d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 121.39542324023108d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0L);
// 
//   }

  public void test30() {}
//   public void test30() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test30"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     double var5 = var0.nextWeibull(110.0d, 0.3874438233115065d);
//     var0.reSeedSecure();
//     var0.reSeedSecure(95L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var0.nextPascal(31, (-1.4156661027293431d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "0cb3e63485145f8023bf965f354f1b030dedd3fdea3b8fe902eba0ed0afbffdb04c1a0474250d4b551f6e56158d09a5b6955"+ "'", var2.equals("0cb3e63485145f8023bf965f354f1b030dedd3fdea3b8fe902eba0ed0afbffdb04c1a0474250d4b551f6e56158d09a5b6955"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.38241906752924487d);
// 
//   }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test31"); }


    long[] var0 = new long[] { };
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var0);
    long[][] var2 = new long[][] { var0};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var2);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var2);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var2);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var2);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test32"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(0L);
    double var3 = var0.nextDouble();
    var0.clear();
    double var5 = var0.nextGaussian();
    boolean var6 = var0.nextBoolean();
    double var7 = var0.nextDouble();
    var0.setSeed(100);
    var0.setSeed(1L);
    int var12 = var0.nextInt();
    int var14 = var0.nextInt(44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.7432416673360078d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1.2016184922621251d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.3874438233115065d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 312574995);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 33);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test33"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double[] var18 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 10.0d);
    double[] var20 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var20);
    double[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 10);
    double[] var24 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var20);
    java.lang.Number var26 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var28 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.026278128681618596d, var26, 1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var29 = var28.getDirection();
    org.apache.commons.math3.util.MathArrays.checkOrder(var20, var29, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test34"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)101.29456331084373d);

  }

  public void test35() {}
//   public void test35() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test35"); }
// 
// 
//     double[] var0 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double[] var2 = org.apache.commons.math3.util.MathArrays.copyOf(var0, 114470686);
//       fail("Expected exception of type java.lang.OutOfMemoryError");
//     } catch (java.lang.OutOfMemoryError e) {
//       // Expected exception.
//     }
// 
//   }

  public void test36() {}
//   public void test36() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test36"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     double var9 = var0.nextWeibull(0.09175824555693415d, 0.3901018313315268d);
//     double var11 = var0.nextT(0.06453083525684095d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var0.nextSecureInt(118517391, 60420325);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-1.3241462979125591d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 125.03243740118928d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.0026603415719485646d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.6746277831296756E-10d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 256.83266620626085d);
// 
//   }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test37"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(134.1595546043694d, 0.7767857089724116d, 1.4232227202160976d, 110.74774393374405d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 261.8319301179571d);

  }

  public void test38() {}
//   public void test38() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test38"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextBeta(115.17225623214854d, 0.2478736222527921d);
//     java.lang.String var5 = var0.nextHexString(48);
//     long var7 = var0.nextPoisson(1.4726118418053777d);
//     double var10 = var0.nextF(4.312670398775281d, 0.7128409704596d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.9995323548782489d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + "531c70a563cae278375a0a3407b46214f663fb196af6ed49"+ "'", var5.equals("531c70a563cae278375a0a3407b46214f663fb196af6ed49"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 62.25181071835983d);
// 
//   }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test39"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(0L);
    double var3 = var0.nextDouble();
    var0.clear();
    double var5 = var0.nextGaussian();
    boolean var6 = var0.nextBoolean();
    double var7 = var0.nextDouble();
    var0.setSeed(100);
    var0.setSeed(1L);
    double var12 = var0.nextGaussian();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.7432416673360078d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1.2016184922621251d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.3874438233115065d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1.327000036267693d);

  }

  public void test40() {}
//   public void test40() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test40"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     double var11 = var0.nextGamma(0.36157468479281d, 0.8376757571801716d);
//     var0.reSeed();
//     var0.reSeedSecure();
//     java.lang.String var15 = var0.nextSecureHexString(3276);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.4690796104145753d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 88.71348176041272d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 4.4391533076007056E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "d"+ "'", var8.equals("d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.6253992933810617d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "f758896d6f16a5376835be100d73c63be11ac5e8a607b7a7da5ad83a297d2ccbd04ef4ccfb4c54be0443a4dfa48ba2b7af7c99ac471c583eaeb130e171e03fa02ca51f85fda2f35ec5830fd9621636764a7f7e2100097b570b5da07ddb82646f603c348c87cb7a534ebd11c318bc8867209a598335d36e0634671c0a3a57af256b4c0fc123a9a121d5ce97b84a69efbc120feba7cdf5a589c97ee20a6ad28524ccfdce18f0a23d1783d10672601248336217d918eab74018610b3e146082be6dff604d91f67a193667bfda0952b8ab8eccc95c9128f33f858c121ed32e5c62973f1ba853291229d0699e20783602e181e26c82d02e8d9c041b0f6b799603617aca2ca871741461e3d92c2c8c060d38b5abda13c624c93783ba92608a61c97ce9824a7e68eeb7d2e5c9c76019203d3bc0d4d1824eb8bd4695c2d553cd0c2fcdde17fec2a2d11b92e0c5b7fa258a00003efaacb81b9bc811e51d5e0b4ea103df07b34d4dad9b75ea11342ceb9a5d86c53f280107ce0b1e01640dd0bd5117fe020f504c11e8c91d911c95921a4231972f7af7754773349de649a936f45cd9767935703db67137469c7a0a15b2fffaf5c8cebcb804255fb25985dc4cef19de253a23f23fb4c4b548668fa220dd797c12fc660be9074add13c70efb4e39da7840361c51f24f23fc5cf1872a205a69ade4a11f5675366b9fbf202f5d1a9ffc6fb97dd35954f0241f510e9facaf200527b20ec1dfa688cb82673788aa5054203510f9c87fe8cdb9339bed6bd0770b4d34eb160dae5b9c697e47b79e147c1e58def19cdfb7a27f45c0614b67c0b456d6100def1b77d06392202069fbc334608b73c37e1bb08009da24788c2d32c0650d564cdfba97cf644cf03db9f376b05f7509c45679e47cb328f289bd7c1a887ee7984faffe958249abf3c2c96c4239736b0b41ed2966654e66543b38641a91118c496a69485858f6c5589a8277e93e80e26af9712001d426a78ced7266981dcb591487855cb2968ec97af77826e7851bc2033afc0f79a42411c3a050cc5db17fb2f773e15dcf3cdf3303a92ee3d00667635f075851a5182fb43eb1f8397be445a2d0fd52c96a5915153ee0c6f5939936af3926df0d043463b2f440fbae7493c9c5b0126c79d8a74aa890f545e1bfbc04f7a39cf185ef33bef8b9b3b19f8484d92b42ca4725fa4e3624d7609b390f5b345b7a0babf86172d2a5bee99d9bf3b97ccc62448cacfa86bdb12f679399547d3a3b137bac91603ee29345ef16320468a57887bc40b27559b209476eb6901a034cac6755c2f9a9509bd7c03e992d27a18b54c5f865a9ac5a366403d5ff308d20aa221e5f9c2241dd2e7109519b7dbdc84a9053220b41972e52d5e2efb0a65563165e75e0c5028eca9ff96a01d5eb4b874998c83f0ead574c5bd2d2f1cd084f7c897485bd1fed36a6c80d5de12d5a174564dd8d85887cc94a1f70ac25731d642f82cb1f3dbadbf8dd191f89003a3e4275e302f59b73b993725237cf0d780d6697515067dbc4ba957b254b1470ae7c35609cbec98725abcc8bc31aa6ded524775749e2bdb506d77715169790e2f2c5890475eda16fd7625acad5b1faa56ac2ff907bfdaa7f048ef50fb448dd7b1ec83122ebbe0296de42bc4d6be9fed3ecde960d66bae7ca490afb690bcf1c1f0266bdfaae262e03e27147bf3b43e9312597a7e981e0b441cf14cc3553170b1500fb7e2e8993d4740981825fbed058c9ab42aea9df85cef3957603daf89218dfa1c858a86b1c29645822dcec0fc49b8684af607e43b6963d411caa4360fb0ef81ffc32a1746e09b97b8a36780bd7b794d4cd2cd4041a06b2f64156ee7d675141bc238e152198a33815ef02f6354c732af5e1ca0becc0aeeacaecfcc5ea9533eb97cc7abc0252f6496a975ffdea9f24af9818ea07a8d419fe083c1dacbf1fd6a99b65d863d73f0ceb5c7b9ad1c4a25b4c43ce679a0a1d1ad51685b6d8ef793cba2a0d8615da57f904a9e73f01c075b2289fdca22b505cd2498ee85bb3ea681326d8be2dcb1be8a48133d7a84aa1966c11aa30fe48a6fb8dde1b4d05b855b2530ffb04f8531080fd53547bba675a42136e25b245e1bc23d46bd1cdf80567c0cda0cd8371a68c7ecf2e1e4c0d03895b2fe785b60f946ecbd251297ccb61c6aa813cce6c62e660764101c4820656d641c2fd1bafff633da84ca99f957858ca226c2e6d0d3e3be04f66d529faa8a65129ef00ce6b6494961e839ac612a8f757f874cf5dca0b070e17d7d6a3fd00e1059d3682a0d785d81edc4bc6ac8fe0f7a953c401"+ "'", var15.equals("f758896d6f16a5376835be100d73c63be11ac5e8a607b7a7da5ad83a297d2ccbd04ef4ccfb4c54be0443a4dfa48ba2b7af7c99ac471c583eaeb130e171e03fa02ca51f85fda2f35ec5830fd9621636764a7f7e2100097b570b5da07ddb82646f603c348c87cb7a534ebd11c318bc8867209a598335d36e0634671c0a3a57af256b4c0fc123a9a121d5ce97b84a69efbc120feba7cdf5a589c97ee20a6ad28524ccfdce18f0a23d1783d10672601248336217d918eab74018610b3e146082be6dff604d91f67a193667bfda0952b8ab8eccc95c9128f33f858c121ed32e5c62973f1ba853291229d0699e20783602e181e26c82d02e8d9c041b0f6b799603617aca2ca871741461e3d92c2c8c060d38b5abda13c624c93783ba92608a61c97ce9824a7e68eeb7d2e5c9c76019203d3bc0d4d1824eb8bd4695c2d553cd0c2fcdde17fec2a2d11b92e0c5b7fa258a00003efaacb81b9bc811e51d5e0b4ea103df07b34d4dad9b75ea11342ceb9a5d86c53f280107ce0b1e01640dd0bd5117fe020f504c11e8c91d911c95921a4231972f7af7754773349de649a936f45cd9767935703db67137469c7a0a15b2fffaf5c8cebcb804255fb25985dc4cef19de253a23f23fb4c4b548668fa220dd797c12fc660be9074add13c70efb4e39da7840361c51f24f23fc5cf1872a205a69ade4a11f5675366b9fbf202f5d1a9ffc6fb97dd35954f0241f510e9facaf200527b20ec1dfa688cb82673788aa5054203510f9c87fe8cdb9339bed6bd0770b4d34eb160dae5b9c697e47b79e147c1e58def19cdfb7a27f45c0614b67c0b456d6100def1b77d06392202069fbc334608b73c37e1bb08009da24788c2d32c0650d564cdfba97cf644cf03db9f376b05f7509c45679e47cb328f289bd7c1a887ee7984faffe958249abf3c2c96c4239736b0b41ed2966654e66543b38641a91118c496a69485858f6c5589a8277e93e80e26af9712001d426a78ced7266981dcb591487855cb2968ec97af77826e7851bc2033afc0f79a42411c3a050cc5db17fb2f773e15dcf3cdf3303a92ee3d00667635f075851a5182fb43eb1f8397be445a2d0fd52c96a5915153ee0c6f5939936af3926df0d043463b2f440fbae7493c9c5b0126c79d8a74aa890f545e1bfbc04f7a39cf185ef33bef8b9b3b19f8484d92b42ca4725fa4e3624d7609b390f5b345b7a0babf86172d2a5bee99d9bf3b97ccc62448cacfa86bdb12f679399547d3a3b137bac91603ee29345ef16320468a57887bc40b27559b209476eb6901a034cac6755c2f9a9509bd7c03e992d27a18b54c5f865a9ac5a366403d5ff308d20aa221e5f9c2241dd2e7109519b7dbdc84a9053220b41972e52d5e2efb0a65563165e75e0c5028eca9ff96a01d5eb4b874998c83f0ead574c5bd2d2f1cd084f7c897485bd1fed36a6c80d5de12d5a174564dd8d85887cc94a1f70ac25731d642f82cb1f3dbadbf8dd191f89003a3e4275e302f59b73b993725237cf0d780d6697515067dbc4ba957b254b1470ae7c35609cbec98725abcc8bc31aa6ded524775749e2bdb506d77715169790e2f2c5890475eda16fd7625acad5b1faa56ac2ff907bfdaa7f048ef50fb448dd7b1ec83122ebbe0296de42bc4d6be9fed3ecde960d66bae7ca490afb690bcf1c1f0266bdfaae262e03e27147bf3b43e9312597a7e981e0b441cf14cc3553170b1500fb7e2e8993d4740981825fbed058c9ab42aea9df85cef3957603daf89218dfa1c858a86b1c29645822dcec0fc49b8684af607e43b6963d411caa4360fb0ef81ffc32a1746e09b97b8a36780bd7b794d4cd2cd4041a06b2f64156ee7d675141bc238e152198a33815ef02f6354c732af5e1ca0becc0aeeacaecfcc5ea9533eb97cc7abc0252f6496a975ffdea9f24af9818ea07a8d419fe083c1dacbf1fd6a99b65d863d73f0ceb5c7b9ad1c4a25b4c43ce679a0a1d1ad51685b6d8ef793cba2a0d8615da57f904a9e73f01c075b2289fdca22b505cd2498ee85bb3ea681326d8be2dcb1be8a48133d7a84aa1966c11aa30fe48a6fb8dde1b4d05b855b2530ffb04f8531080fd53547bba675a42136e25b245e1bc23d46bd1cdf80567c0cda0cd8371a68c7ecf2e1e4c0d03895b2fe785b60f946ecbd251297ccb61c6aa813cce6c62e660764101c4820656d641c2fd1bafff633da84ca99f957858ca226c2e6d0d3e3be04f66d529faa8a65129ef00ce6b6494961e839ac612a8f757f874cf5dca0b070e17d7d6a3fd00e1059d3682a0d785d81edc4bc6ac8fe0f7a953c401"));
// 
//   }

  public void test41() {}
//   public void test41() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test41"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(111.86588500825316d);
//     double var6 = var0.nextUniform(43.35042744195363d, 106.61438946517262d, true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 11.854391718727749d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 59.62992102298426d);
// 
//   }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test42"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double[] var18 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 10.0d);
    double[] var20 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var20);
    double[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 10);
    double[] var25 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var20, var25);
    double[] var29 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var29);
    double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 10);
    double var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var32);
    double var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var25);
    double[] var36 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var36);
    double[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var36, 10);
    double[] var41 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var41);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var36, var41);
    double[] var45 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var45);
    double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var45, 10);
    double var49 = org.apache.commons.math3.util.MathArrays.distanceInf(var41, var48);
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeAdd(var18, var41);
    double[] var52 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var52);
    double[] var55 = org.apache.commons.math3.util.MathArrays.copyOf(var52, 10);
    double[] var57 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var57);
    boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var52, var57);
    double[] var61 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var61);
    double[] var64 = org.apache.commons.math3.util.MathArrays.copyOf(var61, 10);
    double var65 = org.apache.commons.math3.util.MathArrays.distanceInf(var57, var64);
    org.apache.commons.math3.util.MathArrays.OrderDirection var66 = null;
    boolean var68 = org.apache.commons.math3.util.MathArrays.isMonotonic(var57, var66, true);
    double[] var70 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var70);
    double var72 = org.apache.commons.math3.util.MathArrays.distance1(var57, var70);
    double[] var74 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var74);
    double[] var77 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var77);
    double[] var80 = org.apache.commons.math3.util.MathArrays.copyOf(var77, 10);
    double var81 = org.apache.commons.math3.util.MathArrays.distanceInf(var74, var80);
    double[] var82 = org.apache.commons.math3.util.MathArrays.ebeDivide(var70, var74);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var83 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var18, var82);
    double var86 = var83.probability(0.0d, 76.50641463552304d);
    double var88 = var83.probability(113.5373271615141d);
    double var89 = var83.getSupportUpperBound();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var92 = var83.cumulativeProbability(128.35556077963213d, (-0.043481143175376734d));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 11.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == 10.0d);

  }

  public void test43() {}
//   public void test43() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test43"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var5 = var0.nextF(98.30741799725186d, 115.61573715905594d);
//     long var7 = var0.nextPoisson(0.6466912681842636d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var0.nextPascal(60420325, 98.30741799725186d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.9516666036877242d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.002160100554472d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0L);
// 
//   }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test44"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)9.160555011685411E-6d);
    java.lang.Number var2 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0+ "'", var2.equals(0));

  }

  public void test45() {}
//   public void test45() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test45"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     double var11 = var0.nextGamma(0.36157468479281d, 0.8376757571801716d);
//     int var14 = var0.nextBinomial(1, 0.7432416673360078d);
//     double var17 = var0.nextBeta(3.3900817738101328d, 11787.308968688245d);
//     var0.reSeed(0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.8970091466863487d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 120.33759751734549d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.11007690070621942d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "f"+ "'", var8.equals("f"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.004855959215203466d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.3790131551731492E-4d);
// 
//   }

  public void test46() {}
//   public void test46() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test46"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     double var11 = var0.nextGamma(0.36157468479281d, 0.8376757571801716d);
//     int var14 = var0.nextBinomial(669834927, 4.4391533076007056E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.38040503217213334d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 143.98991397557194d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.04720824805814445d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "d"+ "'", var8.equals("d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.4177929008847658d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 298012);
// 
//   }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test47"); }


    org.apache.commons.math3.exception.util.Localizable var1 = null;
    double[] var3 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var3);
    org.apache.commons.math3.util.MathArrays.OrderDirection var5 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var3, var5, false);
    double var8 = org.apache.commons.math3.util.MathArrays.safeNorm(var3);
    double[] var10 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var10);
    double[] var13 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var13);
    double[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var13, 10);
    double var17 = org.apache.commons.math3.util.MathArrays.distanceInf(var10, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeDivide(var3, var10);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var3, 10.0d);
    double[] var22 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var22);
    double[] var25 = org.apache.commons.math3.util.MathArrays.copyOf(var22, 10);
    double[] var27 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var27);
    boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var22, var27);
    double[] var31 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var31);
    double[] var34 = org.apache.commons.math3.util.MathArrays.copyOf(var31, 10);
    double var35 = org.apache.commons.math3.util.MathArrays.distanceInf(var27, var34);
    double var36 = org.apache.commons.math3.util.MathArrays.distanceInf(var20, var27);
    double[] var38 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var38);
    org.apache.commons.math3.util.MathArrays.OrderDirection var40 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var38, var40, false);
    double var43 = org.apache.commons.math3.util.MathArrays.distanceInf(var27, var38);
    double[] var45 = org.apache.commons.math3.util.MathArrays.copyOf(var27, 10);
    double[] var47 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var47);
    org.apache.commons.math3.util.MathArrays.OrderDirection var49 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var47, var49, false);
    double var52 = org.apache.commons.math3.util.MathArrays.safeNorm(var47);
    double[] var54 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var54);
    double[] var57 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var57);
    double[] var60 = org.apache.commons.math3.util.MathArrays.copyOf(var57, 10);
    double var61 = org.apache.commons.math3.util.MathArrays.distanceInf(var54, var60);
    double[] var62 = org.apache.commons.math3.util.MathArrays.ebeDivide(var47, var54);
    double[] var64 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var64);
    org.apache.commons.math3.util.MathArrays.OrderDirection var66 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var64, var66, false);
    double var69 = org.apache.commons.math3.util.MathArrays.safeNorm(var64);
    double[] var71 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var71);
    double[] var74 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var74);
    double[] var77 = org.apache.commons.math3.util.MathArrays.copyOf(var74, 10);
    double var78 = org.apache.commons.math3.util.MathArrays.distanceInf(var71, var77);
    double[] var79 = org.apache.commons.math3.util.MathArrays.ebeDivide(var64, var71);
    double[] var81 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var81);
    org.apache.commons.math3.util.MathArrays.OrderDirection var83 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var81, var83, false);
    double var86 = org.apache.commons.math3.util.MathArrays.safeNorm(var81);
    org.apache.commons.math3.util.MathArrays.OrderDirection var87 = null;
    boolean var89 = org.apache.commons.math3.util.MathArrays.isMonotonic(var81, var87, false);
    double[][] var90 = new double[][] { var81};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var64, var90);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var62, var90);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var27, var90);
    org.apache.commons.math3.exception.MathArithmeticException var94 = new org.apache.commons.math3.exception.MathArithmeticException(var1, (java.lang.Object[])var90);
    org.apache.commons.math3.exception.NotFiniteNumberException var95 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)47L, (java.lang.Object[])var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 11.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);

  }

  public void test48() {}
//   public void test48() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test48"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     var0.reSeedSecure();
//     var0.reSeed();
//     double var9 = var0.nextUniform(0.0015326576218039215d, 114.81244598869324d);
//     var0.reSeedSecure();
//     var0.reSeedSecure((-1L));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("cd2708f57f357363327f67d2cd0b9c35dfc8c0eb2fda19605344b917729d5b5200ff3dd2d8667f29115ca8be1ebb0aaf4ca6", "b");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.10509828047872623d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 124.8663090839217d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 9.95305416629438d);
// 
//   }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test49"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var4 = var1.nextSecureLong(13L, (-2269827290554446382L));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test50"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)(-2.422255593706966d), (java.lang.Number)9.581426376563695E-5d, (java.lang.Number)115.43891296718832d);

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test51"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double[] var18 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 10.0d);
    double[] var20 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var20);
    double[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 10);
    double[] var25 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var20, var25);
    double[] var29 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var29);
    double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 10);
    double var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var32);
    double var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var25);
    double[] var36 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var36);
    double[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var36, 10);
    double[] var41 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var41);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var36, var41);
    double[] var45 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var45);
    double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var45, 10);
    double var49 = org.apache.commons.math3.util.MathArrays.distanceInf(var41, var48);
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeAdd(var18, var41);
    double[] var52 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var52);
    double[] var55 = org.apache.commons.math3.util.MathArrays.copyOf(var52, 10);
    double[] var57 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var57);
    boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var52, var57);
    double[] var61 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var61);
    double[] var64 = org.apache.commons.math3.util.MathArrays.copyOf(var61, 10);
    double var65 = org.apache.commons.math3.util.MathArrays.distanceInf(var57, var64);
    org.apache.commons.math3.util.MathArrays.OrderDirection var66 = null;
    boolean var68 = org.apache.commons.math3.util.MathArrays.isMonotonic(var57, var66, true);
    double[] var70 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var70);
    double var72 = org.apache.commons.math3.util.MathArrays.distance1(var57, var70);
    double[] var74 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var74);
    double[] var77 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var77);
    double[] var80 = org.apache.commons.math3.util.MathArrays.copyOf(var77, 10);
    double var81 = org.apache.commons.math3.util.MathArrays.distanceInf(var74, var80);
    double[] var82 = org.apache.commons.math3.util.MathArrays.ebeDivide(var70, var74);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var83 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var18, var82);
    double var85 = var83.inverseCumulativeProbability(0.0d);
    double var86 = var83.getNumericalMean();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var89 = var83.cumulativeProbability(104.21185957727327d, 1.2933613415363947d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 11.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 10.0d);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test52"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(0L);
    var0.clear();
    var0.setSeed(104075088);
    var0.setSeed(68L);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test53"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeedSecure();
    java.lang.String var3 = var0.nextHexString(33787721);
    var0.reSeedSecure();

  }

  public void test54() {}
//   public void test54() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test54"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 477395393);
// 
//   }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test55"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(0L);
    double var4 = var0.nextExponential(0.7432416673360078d);
    double var6 = var0.nextT(0.035899776418132384d);
    var0.reSeed(477836925424025280L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var11 = var0.nextPascal(0, 4.089149533980427d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.36157468479281d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 27.366395926482813d);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test56"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double var17 = org.apache.commons.math3.util.MathArrays.safeNorm(var8);
    double[] var19 = org.apache.commons.math3.util.MathArrays.copyOf(var8, 1);
    double[] var21 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var21);
    double[] var24 = org.apache.commons.math3.util.MathArrays.copyOf(var21, 10);
    double[] var26 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var26);
    boolean var28 = org.apache.commons.math3.util.MathArrays.equals(var21, var26);
    double[] var30 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var30);
    double[] var33 = org.apache.commons.math3.util.MathArrays.copyOf(var30, 10);
    double var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var26, var33);
    org.apache.commons.math3.util.MathArrays.OrderDirection var35 = null;
    boolean var37 = org.apache.commons.math3.util.MathArrays.isMonotonic(var26, var35, true);
    double[] var39 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var39);
    double var41 = org.apache.commons.math3.util.MathArrays.distance1(var26, var39);
    double[] var43 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var43);
    double[] var46 = org.apache.commons.math3.util.MathArrays.copyOf(var43, 10);
    double[] var48 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var48);
    org.apache.commons.math3.util.MathArrays.OrderDirection var50 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var48, var50, false);
    boolean var53 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var46, var48);
    double[] var54 = org.apache.commons.math3.util.MathArrays.ebeAdd(var26, var48);
    double[] var55 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var19, var26);
    double var56 = org.apache.commons.math3.util.MathArrays.safeNorm(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 1.0d);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test57"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(0L);
    double var3 = var0.nextDouble();
    var0.clear();
    double var5 = var0.nextGaussian();
    boolean var6 = var0.nextBoolean();
    double var7 = var0.nextDouble();
    org.apache.commons.math3.random.RandomDataImpl var8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    long var11 = var8.nextLong(87L, 828254766248375101L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.7432416673360078d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1.2016184922621251d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.3874438233115065d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 337377217742076480L);

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test58"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.9776956941774123d, (java.lang.Number)33787721, false);

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test59"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double[] var18 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 10.0d);
    double[] var20 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var20);
    double[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 10);
    double[] var25 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var20, var25);
    double[] var29 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var29);
    double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 10);
    double var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var32);
    double var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var25);
    double[] var36 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var36);
    double[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var36, 10);
    double[] var41 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var41);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var36, var41);
    double[] var45 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var45);
    double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var45, 10);
    double var49 = org.apache.commons.math3.util.MathArrays.distanceInf(var41, var48);
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeAdd(var18, var41);
    double[] var52 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var52);
    double[] var55 = org.apache.commons.math3.util.MathArrays.copyOf(var52, 10);
    double[] var57 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var57);
    boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var52, var57);
    double[] var61 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var61);
    double[] var64 = org.apache.commons.math3.util.MathArrays.copyOf(var61, 10);
    double var65 = org.apache.commons.math3.util.MathArrays.distanceInf(var57, var64);
    org.apache.commons.math3.util.MathArrays.OrderDirection var66 = null;
    boolean var68 = org.apache.commons.math3.util.MathArrays.isMonotonic(var57, var66, true);
    double[] var70 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var70);
    double var72 = org.apache.commons.math3.util.MathArrays.distance1(var57, var70);
    double[] var74 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var74);
    double[] var77 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var77);
    double[] var80 = org.apache.commons.math3.util.MathArrays.copyOf(var77, 10);
    double var81 = org.apache.commons.math3.util.MathArrays.distanceInf(var74, var80);
    double[] var82 = org.apache.commons.math3.util.MathArrays.ebeDivide(var70, var74);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var83 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var18, var82);
    double var85 = var83.inverseCumulativeProbability(0.0d);
    double var86 = var83.getNumericalMean();
    boolean var87 = var83.isSupportLowerBoundInclusive();
    double var88 = var83.getNumericalVariance();
    boolean var89 = var83.isSupportConnected();
    double var91 = var83.probability(96.32603443714295d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 11.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var91 == 0.0d);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test60"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.5206144238498145d, (java.lang.Number)114.81244598869324d, (java.lang.Number)101.29456331084373d);
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var3.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test61"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0.0032241185303045258d);
    boolean var2 = var1.getBoundIsAllowed();
    java.lang.Number var3 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));

  }

  public void test62() {}
//   public void test62() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test62"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(7, 312574995);
//     double var6 = var0.nextGaussian(0.6183635164792604d, 148.33228964603538d);
//     java.lang.String var8 = var0.nextHexString(36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 129363264);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 162.64805588873247d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "746324cb0c37bab058d78cbf027f0a983fe2"+ "'", var8.equals("746324cb0c37bab058d78cbf027f0a983fe2"));
// 
//   }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test63"); }


    long[] var0 = new long[] { };
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var0);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var0);
    long[][] var3 = new long[][] { var0};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var3);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test64"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Comparable[] var2 = new java.lang.Comparable[] { (byte)(-1)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    boolean var5 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var3, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
    boolean var8 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var6, false);
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);

  }

  public void test65() {}
//   public void test65() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test65"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     var0.reSeedSecure();
//     var0.reSeed();
//     double var9 = var0.nextUniform(0.0015326576218039215d, 114.81244598869324d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var0.nextWeibull(0.6556684902257256d, (-1.5983977517168335d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.4376385452771901d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 99.63119151929043d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 76.78096265448998d);
// 
//   }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test66"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.0011501220925563495d, (java.lang.Number)0.003075002127154551d, true);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test67"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double[] var18 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 10.0d);
    double[] var20 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var20);
    double[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 10);
    double[] var25 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var20, var25);
    double[] var29 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var29);
    double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 10);
    double var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var32);
    double var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var25);
    double[] var36 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var36);
    double[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var36, 10);
    double[] var41 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var41);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var36, var41);
    double[] var45 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var45);
    double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var45, 10);
    double var49 = org.apache.commons.math3.util.MathArrays.distanceInf(var41, var48);
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeAdd(var18, var41);
    double[] var52 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var52);
    double[] var55 = org.apache.commons.math3.util.MathArrays.copyOf(var52, 10);
    double[] var57 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var57);
    boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var52, var57);
    double[] var61 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var61);
    double[] var64 = org.apache.commons.math3.util.MathArrays.copyOf(var61, 10);
    double var65 = org.apache.commons.math3.util.MathArrays.distanceInf(var57, var64);
    org.apache.commons.math3.util.MathArrays.OrderDirection var66 = null;
    boolean var68 = org.apache.commons.math3.util.MathArrays.isMonotonic(var57, var66, true);
    double[] var70 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var70);
    double var72 = org.apache.commons.math3.util.MathArrays.distance1(var57, var70);
    double[] var74 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var74);
    double[] var77 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var77);
    double[] var80 = org.apache.commons.math3.util.MathArrays.copyOf(var77, 10);
    double var81 = org.apache.commons.math3.util.MathArrays.distanceInf(var74, var80);
    double[] var82 = org.apache.commons.math3.util.MathArrays.ebeDivide(var70, var74);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var83 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var18, var82);
    double var85 = var83.inverseCumulativeProbability(0.0d);
    double var86 = var83.getNumericalMean();
    boolean var87 = var83.isSupportLowerBoundInclusive();
    double var88 = var83.getNumericalVariance();
    var83.reseedRandomGenerator(72L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 11.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == 0.0d);

  }

  public void test68() {}
//   public void test68() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test68"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     var0.setSeed(0L);
//     double var3 = var0.nextDouble();
//     var0.setSeed(48);
//     double var6 = var0.nextDouble();
//     java.util.List var7 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var8 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var0, var7);
// 
//   }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test69"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var3 = new java.lang.Object[] { 'a'};
    org.apache.commons.math3.exception.NotFiniteNumberException var4 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)(short)0, var3);
    double[] var6 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var6);
    org.apache.commons.math3.util.MathArrays.OrderDirection var8 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var6, var8, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var6);
    org.apache.commons.math3.util.Pair var12 = new org.apache.commons.math3.util.Pair((java.lang.Object)(short)0, (java.lang.Object)var6);
    java.lang.Object var13 = var12.getValue();
    org.apache.commons.math3.util.Pair var14 = new org.apache.commons.math3.util.Pair(var12);
    int[] var15 = new int[] { };
    int[] var16 = null;
    int var17 = org.apache.commons.math3.util.MathArrays.distance1(var15, var16);
    org.apache.commons.math3.random.Well19937c var18 = new org.apache.commons.math3.random.Well19937c(var15);
    double var19 = var18.nextGaussian();
    long var20 = var18.nextLong();
    boolean var21 = var12.equals((java.lang.Object)var20);
    org.apache.commons.math3.util.MathArrays.OrderDirection var25 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var27 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)100, (java.lang.Number)10.0d, 0, var25, false);
    boolean var28 = var12.equals((java.lang.Object)var25);
    java.lang.Object var29 = var12.getFirst();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.2478736222527921d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1024457413273955602L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var29 + "' != '" + (short)0+ "'", var29.equals((short)0));

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test70"); }


    int[] var0 = new int[] { };
    int[] var1 = null;
    int var2 = org.apache.commons.math3.util.MathArrays.distance1(var0, var1);
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var0);
    double var4 = var3.nextGaussian();
    long var5 = var3.nextLong();
    double var6 = var3.nextDouble();
    boolean var7 = var3.nextBoolean();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.2478736222527921d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1024457413273955602L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.09314254419077805d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test71"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double[] var18 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 10.0d);
    double[] var20 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var20);
    double[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 10);
    double[] var25 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var20, var25);
    double[] var29 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var29);
    double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 10);
    double var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var32);
    double var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var25);
    double[] var36 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var36);
    double[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var36, 10);
    double[] var41 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var41);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var36, var41);
    double[] var45 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var45);
    double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var45, 10);
    double var49 = org.apache.commons.math3.util.MathArrays.distanceInf(var41, var48);
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeAdd(var18, var41);
    double[] var52 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var52);
    double[] var55 = org.apache.commons.math3.util.MathArrays.copyOf(var52, 10);
    double[] var57 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var57);
    boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var52, var57);
    double[] var61 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var61);
    double[] var64 = org.apache.commons.math3.util.MathArrays.copyOf(var61, 10);
    double var65 = org.apache.commons.math3.util.MathArrays.distanceInf(var57, var64);
    org.apache.commons.math3.util.MathArrays.OrderDirection var66 = null;
    boolean var68 = org.apache.commons.math3.util.MathArrays.isMonotonic(var57, var66, true);
    double[] var70 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var70);
    double var72 = org.apache.commons.math3.util.MathArrays.distance1(var57, var70);
    double[] var74 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var74);
    double[] var77 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var77);
    double[] var80 = org.apache.commons.math3.util.MathArrays.copyOf(var77, 10);
    double var81 = org.apache.commons.math3.util.MathArrays.distanceInf(var74, var80);
    double[] var82 = org.apache.commons.math3.util.MathArrays.ebeDivide(var70, var74);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var83 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var18, var82);
    double var85 = var83.inverseCumulativeProbability(0.0d);
    double var86 = var83.getNumericalMean();
    boolean var87 = var83.isSupportLowerBoundInclusive();
    double var88 = var83.getNumericalVariance();
    double var89 = var83.sample();
    boolean var90 = var83.isSupportConnected();
    double[] var92 = var83.sample(30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 11.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test72"); }


    double[] var0 = null;
    double[] var2 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var2);
    double[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var2, 10);
    double[] var7 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var7);
    boolean var9 = org.apache.commons.math3.util.MathArrays.equals(var2, var7);
    double[] var11 = org.apache.commons.math3.util.MathArrays.copyOf(var2, 0);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var0, var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test73"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    long[] var1 = new long[] { };
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var1);
    long[][] var3 = new long[][] { var1};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var3);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var3);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var3);
    org.apache.commons.math3.exception.MathIllegalArgumentException var7 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var3);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var3);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test74"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var3 = new java.lang.Object[] { 'a'};
    org.apache.commons.math3.exception.NotFiniteNumberException var4 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)(short)0, var3);
    double[] var6 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var6);
    org.apache.commons.math3.util.MathArrays.OrderDirection var8 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var6, var8, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var6);
    org.apache.commons.math3.util.Pair var12 = new org.apache.commons.math3.util.Pair((java.lang.Object)(short)0, (java.lang.Object)var6);
    java.lang.Object var13 = var12.getValue();
    org.apache.commons.math3.util.Pair var14 = new org.apache.commons.math3.util.Pair(var12);
    java.lang.Object var15 = var12.getKey();
    org.apache.commons.math3.random.Well19937c var16 = new org.apache.commons.math3.random.Well19937c();
    var16.setSeed(0L);
    double var19 = var16.nextDouble();
    var16.clear();
    double var21 = var16.nextGaussian();
    boolean var22 = var16.nextBoolean();
    double var23 = var16.nextDouble();
    var16.setSeed(100);
    var16.setSeed(1L);
    boolean var28 = var12.equals((java.lang.Object)1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + (short)0+ "'", var15.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.7432416673360078d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == (-1.2016184922621251d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.3874438233115065d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);

  }

  public void test75() {}
//   public void test75() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test75"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
//     var1.reSeed();
//     double var5 = var1.nextCauchy(82.45368975667407d, 82.45368975667407d);
//     long var7 = var1.nextPoisson(5.610049266766251E-8d);
//     var1.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 196.03435534813178d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0L);
// 
//   }

  public void test76() {}
//   public void test76() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test76"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     double var5 = var0.nextWeibull(110.0d, 0.3874438233115065d);
//     var0.reSeedSecure();
//     int var9 = var0.nextZipf(31, 0.6183635164792604d);
//     java.lang.String var11 = var0.nextHexString(36);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var0.nextBinomial(16, 148.33228964603538d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "795884393445f9545214e2db7a2b321a447f1c26207854568dd38963b4dab2feaaad360d545b7d55e9fa3c9d8f844ecde370"+ "'", var2.equals("795884393445f9545214e2db7a2b321a447f1c26207854568dd38963b4dab2feaaad360d545b7d55e9fa3c9d8f844ecde370"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.38522012794777377d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "3356de39cfbc1e460166ca9f6c93b2f45015"+ "'", var11.equals("3356de39cfbc1e460166ca9f6c93b2f45015"));
// 
//   }

  public void test77() {}
//   public void test77() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test77"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     double var9 = var0.nextWeibull(0.09175824555693415d, 0.3901018313315268d);
//     double var11 = var0.nextT(0.06453083525684095d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var0.nextPascal(44, (-0.04467793504673921d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.1992474043303525d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 114.95019336311826d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.071928771345637d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 41.977062587883815d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-1971.2130210107243d));
// 
//   }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test78"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(161574481);
    int var2 = var1.nextInt();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1842980274));

  }

  public void test79() {}
//   public void test79() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test79"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     double var11 = var0.nextGamma(0.36157468479281d, 0.8376757571801716d);
//     var0.reSeed();
//     var0.reSeedSecure();
//     int[] var16 = var0.nextPermutation(48, 21);
//     int[] var17 = org.apache.commons.math3.util.MathArrays.copyOf(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.64979676671516d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.41337207493586d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.5463949061602234E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "9"+ "'", var8.equals("9"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.4082829096231935d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
// 
//   }

  public void test80() {}
//   public void test80() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test80"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     int var5 = var0.nextBinomial(0, 0.0d);
//     long var7 = var0.nextPoisson(96.32603443714295d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var0.nextF((-1.3407807929942597E154d), 116.97561523897781d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "23e29d9052cf700a7ee7741b2fa0a4024c80847425b7ac28b477e408ba4bc1b8d7b90036f2aecd1f2aa98b2fd11e26dc6d8d"+ "'", var2.equals("23e29d9052cf700a7ee7741b2fa0a4024c80847425b7ac28b477e408ba4bc1b8d7b90036f2aecd1f2aa98b2fd11e26dc6d8d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 108L);
// 
//   }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test81"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination((-0.33420519785105623d), 0.5805999842164986d, 0.38580107253710577d, 59.62992102298426d, 0.0d, 0.11616125877882791d, 103.8411028710254d, 0.3895561528043651d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 63.26318849077181d);

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test82"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var3 = new java.lang.Object[] { 'a'};
    org.apache.commons.math3.exception.NotFiniteNumberException var4 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)(short)0, var3);
    double[] var6 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var6);
    org.apache.commons.math3.util.MathArrays.OrderDirection var8 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var6, var8, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var6);
    org.apache.commons.math3.util.Pair var12 = new org.apache.commons.math3.util.Pair((java.lang.Object)(short)0, (java.lang.Object)var6);
    java.lang.Object var13 = var12.getValue();
    org.apache.commons.math3.util.Pair var14 = new org.apache.commons.math3.util.Pair(var12);
    java.lang.Object var15 = var12.getFirst();
    java.lang.Object var16 = var12.getFirst();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + (short)0+ "'", var15.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + (short)0+ "'", var16.equals((short)0));

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test83"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0f, var1, 10, var3, true);
    java.lang.Number var6 = var5.getArgument();
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = var5.getDirection();
    boolean var8 = var5.getStrict();
    boolean var9 = var5.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var10 = var5.getDirection();
    int var11 = var5.getIndex();
    int var12 = var5.getIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 0.0f+ "'", var6.equals(0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 10);

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test84"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double[] var18 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 10.0d);
    double[] var20 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var20);
    double[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 10);
    double[] var25 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var20, var25);
    double[] var29 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var29);
    double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 10);
    double var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var32);
    double var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var25);
    double[] var36 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var36);
    double[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var36, 10);
    double[] var41 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var41);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var36, var41);
    double[] var45 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var45);
    double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var45, 10);
    double var49 = org.apache.commons.math3.util.MathArrays.distanceInf(var41, var48);
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeAdd(var18, var41);
    double[] var52 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var52);
    double[] var55 = org.apache.commons.math3.util.MathArrays.copyOf(var52, 10);
    double[] var57 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var57);
    boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var52, var57);
    double[] var61 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var61);
    double[] var64 = org.apache.commons.math3.util.MathArrays.copyOf(var61, 10);
    double var65 = org.apache.commons.math3.util.MathArrays.distanceInf(var57, var64);
    org.apache.commons.math3.util.MathArrays.OrderDirection var66 = null;
    boolean var68 = org.apache.commons.math3.util.MathArrays.isMonotonic(var57, var66, true);
    double[] var70 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var70);
    double var72 = org.apache.commons.math3.util.MathArrays.distance1(var57, var70);
    double[] var74 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var74);
    double[] var77 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var77);
    double[] var80 = org.apache.commons.math3.util.MathArrays.copyOf(var77, 10);
    double var81 = org.apache.commons.math3.util.MathArrays.distanceInf(var74, var80);
    double[] var82 = org.apache.commons.math3.util.MathArrays.ebeDivide(var70, var74);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var83 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var18, var82);
    double var85 = var83.inverseCumulativeProbability(0.0d);
    double var86 = var83.getNumericalMean();
    boolean var87 = var83.isSupportLowerBoundInclusive();
    double var88 = var83.getNumericalVariance();
    double var89 = var83.sample();
    boolean var90 = var83.isSupportConnected();
    double var91 = var83.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 11.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var91 == 10.0d);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test85"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
    var0.setSeed(2L);
    int var5 = var0.nextInt(15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 6);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test86"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double[] var18 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 10.0d);
    double[] var20 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var20);
    double[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 10);
    double[] var25 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var20, var25);
    double[] var29 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var29);
    double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 10);
    double var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var32);
    double var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var25);
    double[] var36 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var36);
    double[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var36, 10);
    double[] var41 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var41);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var36, var41);
    double[] var45 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var45);
    double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var45, 10);
    double var49 = org.apache.commons.math3.util.MathArrays.distanceInf(var41, var48);
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeAdd(var18, var41);
    double[] var52 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var52);
    double[] var55 = org.apache.commons.math3.util.MathArrays.copyOf(var52, 10);
    double[] var57 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var57);
    boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var52, var57);
    double[] var61 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var61);
    double[] var64 = org.apache.commons.math3.util.MathArrays.copyOf(var61, 10);
    double var65 = org.apache.commons.math3.util.MathArrays.distanceInf(var57, var64);
    org.apache.commons.math3.util.MathArrays.OrderDirection var66 = null;
    boolean var68 = org.apache.commons.math3.util.MathArrays.isMonotonic(var57, var66, true);
    double[] var70 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var70);
    double var72 = org.apache.commons.math3.util.MathArrays.distance1(var57, var70);
    double[] var74 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var74);
    double[] var77 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var77);
    double[] var80 = org.apache.commons.math3.util.MathArrays.copyOf(var77, 10);
    double var81 = org.apache.commons.math3.util.MathArrays.distanceInf(var74, var80);
    double[] var82 = org.apache.commons.math3.util.MathArrays.ebeDivide(var70, var74);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var83 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var18, var82);
    double var84 = var83.getSupportUpperBound();
    double var86 = var83.cumulativeProbability((-45.82609203188007d));
    double var87 = var83.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 11.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == 10.0d);

  }

  public void test87() {}
//   public void test87() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test87"); }
// 
// 
//     double[] var1 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var1);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
//     double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
//     double[] var8 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var8);
//     double[] var11 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var11);
//     double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
//     double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
//     double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
//     double[] var18 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var18);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var20 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var18, var20, false);
//     double var23 = org.apache.commons.math3.util.MathArrays.safeNorm(var18);
//     double[] var25 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var25);
//     double[] var28 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var28);
//     double[] var31 = org.apache.commons.math3.util.MathArrays.copyOf(var28, 10);
//     double var32 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var31);
//     double[] var33 = org.apache.commons.math3.util.MathArrays.ebeDivide(var18, var25);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var34 = null;
//     boolean var36 = org.apache.commons.math3.util.MathArrays.isMonotonic(var18, var34, true);
//     double[] var37 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var8, var18);
//     double[] var39 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var39);
//     double[] var42 = org.apache.commons.math3.util.MathArrays.copyOf(var39, 10);
//     double[] var44 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var44);
//     boolean var46 = org.apache.commons.math3.util.MathArrays.equals(var39, var44);
//     double[] var48 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var48);
//     double[] var51 = org.apache.commons.math3.util.MathArrays.copyOf(var48, 10);
//     double var52 = org.apache.commons.math3.util.MathArrays.distanceInf(var44, var51);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var53 = null;
//     boolean var55 = org.apache.commons.math3.util.MathArrays.isMonotonic(var44, var53, true);
//     double[] var57 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var57);
//     double var59 = org.apache.commons.math3.util.MathArrays.distance1(var44, var57);
//     double[] var61 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var61);
//     double[] var64 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var64);
//     double[] var67 = org.apache.commons.math3.util.MathArrays.copyOf(var64, 10);
//     double var68 = org.apache.commons.math3.util.MathArrays.distanceInf(var61, var67);
//     double[] var69 = org.apache.commons.math3.util.MathArrays.ebeDivide(var57, var61);
//     boolean var70 = org.apache.commons.math3.util.MathArrays.equals(var37, var61);
//     double[] var71 = null;
//     double var72 = org.apache.commons.math3.util.MathArrays.distance(var37, var71);
// 
//   }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test88"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(0L);
    double var4 = var0.nextExponential(0.7432416673360078d);
    double var6 = var0.nextT(0.035899776418132384d);
    double var9 = var0.nextGaussian(102.85799933184796d, 0.4054370868227162d);
    long var12 = var0.nextLong(47L, 86L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.36157468479281d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 27.366395926482813d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 102.57046602831102d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 80L);

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test89"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(0L);
    double var3 = var0.nextDouble();
    var0.clear();
    double var5 = var0.nextGaussian();
    boolean var6 = var0.nextBoolean();
    double var7 = var0.nextDouble();
    org.apache.commons.math3.random.RandomDataImpl var8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    long var10 = var8.nextPoisson(0.014210808548593164d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var13 = var8.nextCauchy(88.71348176041272d, (-0.4578282015693922d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.7432416673360078d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1.2016184922621251d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.3874438233115065d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0L);

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test90"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.3864176294443096d, (java.lang.Number)(-0.6466922963099893d), false);

  }

  public void test91() {}
//   public void test91() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test91"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     var0.reSeedSecure();
//     var0.reSeed();
//     int var9 = var0.nextZipf(21, 0.044259860704679646d);
//     var0.reSeedSecure(0L);
//     org.apache.commons.math3.distribution.IntegerDistribution var12 = null;
//     int var13 = var0.nextInversionDeviate(var12);
// 
//   }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test92"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = null;
    boolean var9 = org.apache.commons.math3.util.MathArrays.isMonotonic(var1, var7, false);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    org.apache.commons.math3.util.MathArrays.OrderDirection var13 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var11, var13, false);
    double var16 = org.apache.commons.math3.util.MathArrays.safeNorm(var11);
    double[] var18 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var18);
    double[] var21 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var21);
    double[] var24 = org.apache.commons.math3.util.MathArrays.copyOf(var21, 10);
    double var25 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var24);
    double[] var26 = org.apache.commons.math3.util.MathArrays.ebeDivide(var11, var18);
    double[] var28 = org.apache.commons.math3.util.MathArrays.normalizeArray(var11, 10.0d);
    double[] var30 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var30);
    double[] var33 = org.apache.commons.math3.util.MathArrays.copyOf(var30, 10);
    double[] var35 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var35);
    boolean var37 = org.apache.commons.math3.util.MathArrays.equals(var30, var35);
    double[] var39 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var39);
    double[] var42 = org.apache.commons.math3.util.MathArrays.copyOf(var39, 10);
    double var43 = org.apache.commons.math3.util.MathArrays.distanceInf(var35, var42);
    double var44 = org.apache.commons.math3.util.MathArrays.distanceInf(var28, var35);
    double[] var46 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var46);
    org.apache.commons.math3.util.MathArrays.OrderDirection var48 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var46, var48, false);
    double var51 = org.apache.commons.math3.util.MathArrays.safeNorm(var46);
    double[] var53 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var53);
    double[] var56 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var56);
    double[] var59 = org.apache.commons.math3.util.MathArrays.copyOf(var56, 10);
    double var60 = org.apache.commons.math3.util.MathArrays.distanceInf(var53, var59);
    double[] var61 = org.apache.commons.math3.util.MathArrays.ebeDivide(var46, var53);
    double[] var63 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var63);
    org.apache.commons.math3.util.MathArrays.OrderDirection var65 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var63, var65, false);
    double var68 = org.apache.commons.math3.util.MathArrays.safeNorm(var63);
    double[] var70 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var70);
    double[] var73 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var73);
    double[] var76 = org.apache.commons.math3.util.MathArrays.copyOf(var73, 10);
    double var77 = org.apache.commons.math3.util.MathArrays.distanceInf(var70, var76);
    double[] var78 = org.apache.commons.math3.util.MathArrays.ebeDivide(var63, var70);
    double[] var80 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var80);
    org.apache.commons.math3.util.MathArrays.OrderDirection var82 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var80, var82, false);
    double var85 = org.apache.commons.math3.util.MathArrays.safeNorm(var80);
    org.apache.commons.math3.util.MathArrays.OrderDirection var86 = null;
    boolean var88 = org.apache.commons.math3.util.MathArrays.isMonotonic(var80, var86, false);
    double[][] var89 = new double[][] { var80};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var63, var89);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var61, var89);
    double[] var92 = org.apache.commons.math3.util.MathArrays.copyOf(var61);
    double var93 = org.apache.commons.math3.util.MathArrays.safeNorm(var92);
    double var94 = org.apache.commons.math3.util.MathArrays.distance1(var28, var92);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var95 = org.apache.commons.math3.util.MathArrays.linearCombination(var1, var28);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 11.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var94 == 9.0d);

  }

  public void test93() {}
//   public void test93() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test93"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var11 = var0.nextPermutation(5, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.145799088759763d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 112.08151349239289d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.062170887918478426d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "b"+ "'", var8.equals("b"));
// 
//   }

  public void test94() {}
//   public void test94() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test94"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     double var11 = var0.nextBeta(106.19070066324907d, 14386.159160118537d);
//     long var14 = var0.nextSecureLong(10L, 84L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-1.7624108373068774d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 110.65775795733349d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 8.353353932272944E-7d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "9"+ "'", var8.equals("9"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.006737005686531704d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 20L);
// 
//   }

  public void test95() {}
//   public void test95() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test95"); }
// 
// 
//     double[] var1 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var1);
//     double[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 10);
//     double[] var6 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var6);
//     double[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var6, 10);
//     double[] var11 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var11);
//     boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var6, var11);
//     double[] var15 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var15);
//     double[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var15, 10);
//     double var19 = org.apache.commons.math3.util.MathArrays.distanceInf(var11, var18);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var20 = null;
//     boolean var22 = org.apache.commons.math3.util.MathArrays.isMonotonic(var11, var20, true);
//     double[] var24 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var24);
//     double var26 = org.apache.commons.math3.util.MathArrays.distance1(var11, var24);
//     boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var1, var24);
//     double[] var29 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var29);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var31 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var29, var31, false);
//     double var34 = org.apache.commons.math3.util.MathArrays.safeNorm(var29);
//     double[] var36 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var36);
//     double[] var39 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var39);
//     double[] var42 = org.apache.commons.math3.util.MathArrays.copyOf(var39, 10);
//     double var43 = org.apache.commons.math3.util.MathArrays.distanceInf(var36, var42);
//     double[] var44 = org.apache.commons.math3.util.MathArrays.ebeDivide(var29, var36);
//     double[] var46 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var46);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var48 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var46, var48, false);
//     double var51 = org.apache.commons.math3.util.MathArrays.safeNorm(var46);
//     double[] var53 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var53);
//     double[] var56 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var56);
//     double[] var59 = org.apache.commons.math3.util.MathArrays.copyOf(var56, 10);
//     double var60 = org.apache.commons.math3.util.MathArrays.distanceInf(var53, var59);
//     double[] var61 = org.apache.commons.math3.util.MathArrays.ebeDivide(var46, var53);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var62 = null;
//     boolean var64 = org.apache.commons.math3.util.MathArrays.isMonotonic(var46, var62, true);
//     double[] var65 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var36, var46);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var36);
//     boolean var67 = org.apache.commons.math3.util.MathArrays.equals(var1, var36);
//     double[][] var68 = null;
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var36, var68);
// 
//   }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test96"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double var17 = org.apache.commons.math3.util.MathArrays.safeNorm(var8);
    double[] var19 = org.apache.commons.math3.util.MathArrays.copyOf(var8, 1);
    double[] var21 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var21);
    org.apache.commons.math3.util.MathArrays.OrderDirection var23 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var21, var23, false);
    double var26 = org.apache.commons.math3.util.MathArrays.safeNorm(var21);
    double[] var28 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var28);
    double[] var31 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var31);
    double[] var34 = org.apache.commons.math3.util.MathArrays.copyOf(var31, 10);
    double var35 = org.apache.commons.math3.util.MathArrays.distanceInf(var28, var34);
    double[] var36 = org.apache.commons.math3.util.MathArrays.ebeDivide(var21, var28);
    double[] var38 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var38);
    org.apache.commons.math3.util.MathArrays.OrderDirection var40 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var38, var40, false);
    double var43 = org.apache.commons.math3.util.MathArrays.safeNorm(var38);
    double[] var45 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var45);
    double[] var48 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var48);
    double[] var51 = org.apache.commons.math3.util.MathArrays.copyOf(var48, 10);
    double var52 = org.apache.commons.math3.util.MathArrays.distanceInf(var45, var51);
    double[] var53 = org.apache.commons.math3.util.MathArrays.ebeDivide(var38, var45);
    double[] var55 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var55);
    org.apache.commons.math3.util.MathArrays.OrderDirection var57 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var55, var57, false);
    double var60 = org.apache.commons.math3.util.MathArrays.safeNorm(var55);
    org.apache.commons.math3.util.MathArrays.OrderDirection var61 = null;
    boolean var63 = org.apache.commons.math3.util.MathArrays.isMonotonic(var55, var61, false);
    double[][] var64 = new double[][] { var55};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var38, var64);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var36, var64);
    double[] var67 = org.apache.commons.math3.util.MathArrays.ebeAdd(var8, var36);
    org.apache.commons.math3.util.MathArrays.OrderDirection var68 = null;
    boolean var70 = org.apache.commons.math3.util.MathArrays.isMonotonic(var8, var68, false);
    double[] var72 = org.apache.commons.math3.util.MathArrays.copyOf(var8, 42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);

  }

  public void test97() {}
//   public void test97() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test97"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 118517391);
// 
//   }

  public void test98() {}
//   public void test98() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test98"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     int var5 = var0.nextBinomial(0, 0.0d);
//     double var8 = var0.nextGaussian(108.97593914807048d, 101.79109515357918d);
//     double var10 = var0.nextT(0.00940319128424221d);
//     double var13 = var0.nextWeibull(35.80121798427257d, 0.0893641512959175d);
//     var0.reSeedSecure(95L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "984e148b7b23bc470ea6adf6966883f1f2a7f8d7bf44c3a4a8c2e8eeccc8da2c568cbec113c1558a9bc0d9775b659c4edd25"+ "'", var2.equals("984e148b7b23bc470ea6adf6966883f1f2a7f8d7bf44c3a4a8c2e8eeccc8da2c568cbec113c1558a9bc0d9775b659c4edd25"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-42.05705803570227d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-4.585950892045061E25d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.08764096233841684d);
// 
//   }

  public void test99() {}
//   public void test99() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test99"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     var0.reSeedSecure();
//     var0.reSeed();
//     double var9 = var0.nextUniform(0.0015326576218039215d, 114.81244598869324d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var0.nextGamma(1.4659703455572012E-4d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.7933361928369753d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 119.93898881480057d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 24.645115769104077d);
// 
//   }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test100"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(0L);
    var0.clear();
    int var5 = var0.nextInt(1);
    int[] var6 = new int[] { };
    int[] var7 = null;
    int var8 = org.apache.commons.math3.util.MathArrays.distance1(var6, var7);
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(var6);
    int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var6);
    var0.setSeed(var6);
    int[] var12 = new int[] { };
    org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(var12);
    int[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var12, 100);
    int[] var17 = org.apache.commons.math3.util.MathArrays.copyOf(var12, 10);
    int[] var19 = org.apache.commons.math3.util.MathArrays.copyOf(var12, 99);
    int[] var20 = new int[] { };
    org.apache.commons.math3.random.Well19937c var21 = new org.apache.commons.math3.random.Well19937c(var20);
    int[] var22 = new int[] { };
    org.apache.commons.math3.random.Well19937c var23 = new org.apache.commons.math3.random.Well19937c(var22);
    int[] var25 = org.apache.commons.math3.util.MathArrays.copyOf(var22, 100);
    int var26 = org.apache.commons.math3.util.MathArrays.distance1(var20, var22);
    int[] var27 = new int[] { };
    org.apache.commons.math3.random.Well19937c var28 = new org.apache.commons.math3.random.Well19937c(var27);
    int var29 = org.apache.commons.math3.util.MathArrays.distanceInf(var22, var27);
    int var30 = org.apache.commons.math3.util.MathArrays.distanceInf(var12, var22);
    int[] var31 = new int[] { };
    org.apache.commons.math3.random.Well19937c var32 = new org.apache.commons.math3.random.Well19937c(var31);
    int var33 = org.apache.commons.math3.util.MathArrays.distance1(var22, var31);
    int var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var6, var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0);

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test101"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)112.79893611497971d);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test102"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(0, 71);

  }

  public void test103() {}
//   public void test103() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test103"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     var0.reSeedSecure();
//     var0.reSeed();
//     int var9 = var0.nextZipf(21, 0.044259860704679646d);
//     int var12 = var0.nextPascal(39, 0.29461270966732284d);
//     int var15 = var0.nextSecureInt(95, 100);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var18 = var0.nextUniform(1.9081813459147294E-5d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.1971718170172951d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 104.06566909726905d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 86);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 99);
// 
//   }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test104"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(0L);
    double var3 = var0.nextDouble();
    int[] var7 = new int[] { 1, 10, 100};
    var0.setSeed(var7);
    int[] var9 = new int[] { };
    int[] var10 = null;
    int var11 = org.apache.commons.math3.util.MathArrays.distance1(var9, var10);
    org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(var9);
    int[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var9, 0);
    int[] var15 = new int[] { };
    int[] var16 = null;
    int var17 = org.apache.commons.math3.util.MathArrays.distance1(var15, var16);
    org.apache.commons.math3.random.Well19937c var18 = new org.apache.commons.math3.random.Well19937c(var15);
    int[] var19 = org.apache.commons.math3.util.MathArrays.copyOf(var15);
    org.apache.commons.math3.random.Well19937c var20 = new org.apache.commons.math3.random.Well19937c(var15);
    int var21 = org.apache.commons.math3.util.MathArrays.distanceInf(var14, var15);
    var0.setSeed(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.7432416673360078d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test105"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)7.277800330956172E-5d, (java.lang.Number)0.9999999984278495d, 6);

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test106"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(0.6529927310149576d, 0.06729966802586457d, 1.3790131551731492E-4d, 104.33721205938512d, 0.4177929008847658d, 0.0d, 0.13907557142127921d, (-0.9952372506839855d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-0.08007875651761061d));

  }

  public void test107() {}
//   public void test107() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test107"); }
// 
// 
//     int[] var0 = new int[] { };
//     int[] var1 = null;
//     int var2 = org.apache.commons.math3.util.MathArrays.distance1(var0, var1);
//     org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var4 = var3.nextGaussian();
//     var3.setSeed(477395393);
//     org.apache.commons.math3.random.RandomDataGenerator var7 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var3);
//     java.util.List var8 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var9 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var3, var8);
// 
//   }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test108"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(0L);
    double var3 = var0.nextDouble();
    var0.clear();
    double var5 = var0.nextGaussian();
    var0.setSeed(0);
    double var8 = var0.nextDouble();
    int var10 = var0.nextInt(274497138);
    long var11 = var0.nextLong();
    int var13 = var0.nextInt(15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.7432416673360078d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1.2016184922621251d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.9775554539871507d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 60420325);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-2269827290554446382L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 3);

  }

  public void test109() {}
//   public void test109() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test109"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     double var5 = var0.nextWeibull(110.0d, 0.3874438233115065d);
//     var0.reSeedSecure();
//     var0.reSeedSecure(95L);
//     long var11 = var0.nextLong(0L, 2L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var0.nextUniform(0.7416991107644604d, 0.5230125715149944d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "868dd64aba0014b60edcc27cf9d25d4b2a32c300c67ecdb2262b3509cf144e2cd7d1d2c7ae346c82bb0dff593a0e732b1586"+ "'", var2.equals("868dd64aba0014b60edcc27cf9d25d4b2a32c300c67ecdb2262b3509cf144e2cd7d1d2c7ae346c82bb0dff593a0e732b1586"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.39029889998054207d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0L);
// 
//   }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test110"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(0.6715417370103403d, 0.0d, 0.0653811700462978d, 20.011572793205353d, 112.60404725003615d, 0.014210808548593164d, 1.4924399031740692E10d, (-4.585950892045061E25d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-6.844256105284767E35d));

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test111"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(0L);
    double var3 = var0.nextDouble();
    var0.clear();
    double var5 = var0.nextGaussian();
    org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
    var6.reSeedSecure();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.7432416673360078d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1.2016184922621251d));

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test112"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var2 = new java.lang.Object[] { (short)10};
    org.apache.commons.math3.exception.MathInternalError var3 = new org.apache.commons.math3.exception.MathInternalError(var0, var2);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var3.getContext();
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    java.lang.Object[] var12 = new java.lang.Object[] { 'a'};
    org.apache.commons.math3.exception.NotFiniteNumberException var13 = new org.apache.commons.math3.exception.NotFiniteNumberException(var9, (java.lang.Number)(short)0, var12);
    org.apache.commons.math3.exception.NotFiniteNumberException var14 = new org.apache.commons.math3.exception.NotFiniteNumberException(var7, (java.lang.Number)10L, var12);
    org.apache.commons.math3.exception.MathIllegalStateException var15 = new org.apache.commons.math3.exception.MathIllegalStateException(var6, var12);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var19 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0d, (java.lang.Number)(byte)(-1), 1);
    boolean var20 = var19.getStrict();
    java.lang.String var21 = var19.toString();
    var15.addSuppressed((java.lang.Throwable)var19);
    var3.addSuppressed((java.lang.Throwable)var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + "org.apache.commons.math3.exception.NonMonotonicSequenceException: points 0 and 1 are not strictly increasing (-1 >= 1)"+ "'", var21.equals("org.apache.commons.math3.exception.NonMonotonicSequenceException: points 0 and 1 are not strictly increasing (-1 >= 1)"));

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test113"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeedSecure();
    var0.reSeed(100L);
    double var6 = var0.nextBeta(128.02836239135638d, 100.38955484251419d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.531763683635676d);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test114"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    double[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 10);
    double[] var6 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var6);
    boolean var8 = org.apache.commons.math3.util.MathArrays.equals(var1, var6);
    double[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 0);
    double[] var12 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var12);
    double[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var12, 10);
    double[] var17 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var17);
    boolean var19 = org.apache.commons.math3.util.MathArrays.equals(var12, var17);
    double[] var21 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var21);
    double[] var24 = org.apache.commons.math3.util.MathArrays.copyOf(var21, 10);
    double var25 = org.apache.commons.math3.util.MathArrays.distanceInf(var17, var24);
    org.apache.commons.math3.util.MathArrays.OrderDirection var26 = null;
    boolean var28 = org.apache.commons.math3.util.MathArrays.isMonotonic(var17, var26, true);
    double[] var30 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var30);
    double var32 = org.apache.commons.math3.util.MathArrays.distance1(var17, var30);
    double[] var33 = org.apache.commons.math3.util.MathArrays.copyOf(var30);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var34 = org.apache.commons.math3.util.MathArrays.linearCombination(var1, var30);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test115"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    double[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 10);
    double[] var6 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var6);
    double[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var6, 10);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var6, var11);
    double[] var15 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var15);
    double[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var15, 10);
    double var19 = org.apache.commons.math3.util.MathArrays.distanceInf(var11, var18);
    org.apache.commons.math3.util.MathArrays.OrderDirection var20 = null;
    boolean var22 = org.apache.commons.math3.util.MathArrays.isMonotonic(var11, var20, true);
    double[] var24 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var24);
    double var26 = org.apache.commons.math3.util.MathArrays.distance1(var11, var24);
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var1, var24);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkPositive(var24);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test116"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double[] var18 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 10.0d);
    double[] var20 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var20);
    double[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 10);
    double[] var25 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var20, var25);
    double[] var29 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var29);
    double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 10);
    double var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var32);
    double var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var25);
    double[] var36 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var36);
    double[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var36, 10);
    double[] var41 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var41);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var36, var41);
    double[] var45 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var45);
    double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var45, 10);
    double var49 = org.apache.commons.math3.util.MathArrays.distanceInf(var41, var48);
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeAdd(var18, var41);
    double[] var52 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var52);
    double[] var55 = org.apache.commons.math3.util.MathArrays.copyOf(var52, 10);
    double[] var57 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var57);
    boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var52, var57);
    double[] var61 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var61);
    double[] var64 = org.apache.commons.math3.util.MathArrays.copyOf(var61, 10);
    double var65 = org.apache.commons.math3.util.MathArrays.distanceInf(var57, var64);
    org.apache.commons.math3.util.MathArrays.OrderDirection var66 = null;
    boolean var68 = org.apache.commons.math3.util.MathArrays.isMonotonic(var57, var66, true);
    double[] var70 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var70);
    double var72 = org.apache.commons.math3.util.MathArrays.distance1(var57, var70);
    double[] var74 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var74);
    double[] var77 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var77);
    double[] var80 = org.apache.commons.math3.util.MathArrays.copyOf(var77, 10);
    double var81 = org.apache.commons.math3.util.MathArrays.distanceInf(var74, var80);
    double[] var82 = org.apache.commons.math3.util.MathArrays.ebeDivide(var70, var74);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var83 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var18, var82);
    double var86 = var83.probability(0.0d, 76.50641463552304d);
    double var88 = var83.probability(113.5373271615141d);
    double var89 = var83.sample();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 11.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == 10.0d);

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test117"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    double[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 10);
    double[] var6 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var6);
    boolean var8 = org.apache.commons.math3.util.MathArrays.equals(var1, var6);
    org.apache.commons.math3.util.MathArrays.OrderDirection var9 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var6, var9, false);
    double[] var13 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var13);
    org.apache.commons.math3.util.MathArrays.OrderDirection var15 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var13, var15, false);
    double var18 = org.apache.commons.math3.util.MathArrays.distanceInf(var6, var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);

  }

  public void test118() {}
//   public void test118() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test118"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 102269683, 0);
// 
//   }

  public void test119() {}
//   public void test119() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test119"); }
// 
// 
//     double[] var1 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var1);
//     double[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 10);
//     double[] var6 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var6);
//     boolean var8 = org.apache.commons.math3.util.MathArrays.equals(var1, var6);
//     double[] var10 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var10);
//     double[] var13 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 10);
//     double var14 = org.apache.commons.math3.util.MathArrays.distanceInf(var6, var13);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var15 = null;
//     boolean var17 = org.apache.commons.math3.util.MathArrays.isMonotonic(var6, var15, true);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double[] var19 = org.apache.commons.math3.util.MathArrays.copyOf(var6, 118517391);
//       fail("Expected exception of type java.lang.OutOfMemoryError");
//     } catch (java.lang.OutOfMemoryError e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == true);
// 
//   }

  public void test120() {}
//   public void test120() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test120"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     var0.reSeed();
//     long var11 = var0.nextPoisson(0.4517190132114119d);
//     var0.reSeedSecure((-1L));
//     var0.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-1.4285747415102923d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 111.8477520686252d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 5.493396928863362E-7d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "8"+ "'", var8.equals("8"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0L);
// 
//   }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test121"); }


    int[] var0 = new int[] { };
    int[] var1 = null;
    int var2 = org.apache.commons.math3.util.MathArrays.distance1(var0, var1);
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var0);
    double var4 = var3.nextGaussian();
    var3.setSeed(477395393);
    org.apache.commons.math3.random.RandomDataGenerator var7 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var3);
    double var9 = var7.nextExponential(0.2147672474351724d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.2478736222527921d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.45499047659240777d);

  }

  public void test122() {}
//   public void test122() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test122"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var3 = var1.nextChiSquare(1.3650947445123496d);
//     double var6 = var1.nextWeibull(1.0d, 0.3874438233115065d);
//     long var9 = var1.nextSecureLong(1L, 10L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var1.nextF(1.2090062708162682E-4d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2.0675010290063245d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.4291534209208756d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 7L);
// 
//   }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test123"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var3 = new java.lang.Object[] { 'a'};
    org.apache.commons.math3.exception.NotFiniteNumberException var4 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)(short)0, var3);
    double[] var6 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var6);
    org.apache.commons.math3.util.MathArrays.OrderDirection var8 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var6, var8, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var6);
    org.apache.commons.math3.util.Pair var12 = new org.apache.commons.math3.util.Pair((java.lang.Object)(short)0, (java.lang.Object)var6);
    java.lang.Object var13 = var12.getValue();
    org.apache.commons.math3.util.Pair var14 = new org.apache.commons.math3.util.Pair(var12);
    java.lang.Object var15 = var14.getKey();
    java.lang.Object var16 = var14.getValue();
    java.lang.Object var17 = var14.getSecond();
    org.apache.commons.math3.util.Pair var18 = new org.apache.commons.math3.util.Pair(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + (short)0+ "'", var15.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test124() {}
//   public void test124() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test124"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     double var5 = var0.nextWeibull(110.0d, 0.3874438233115065d);
//     java.util.Collection var6 = null;
//     java.lang.Object[] var8 = var0.nextSample(var6, 20);
// 
//   }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test125"); }


    java.lang.Object[] var1 = null;
    org.apache.commons.math3.exception.NotFiniteNumberException var2 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-6.844256105284767E35d), var1);

  }

  public void test126() {}
//   public void test126() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test126"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var0.nextExponential((-0.34851891419964814d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.7502192733289086d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 94.87630555103641d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.014093450897477443d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "f"+ "'", var8.equals("f"));
// 
//   }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test127"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(30);

  }

  public void test128() {}
//   public void test128() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test128"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(0L);
//     java.lang.String var4 = var0.nextHexString(100);
//     java.lang.String var6 = var0.nextSecureHexString(1);
//     var0.reSeed((-1L));
//     double var10 = var0.nextExponential(0.915778680097192d);
//     var0.reSeedSecure();
//     long var14 = var0.nextLong(10L, 1024457413273955602L);
//     long var16 = var0.nextPoisson(0.087939294119887d);
//     java.util.Collection var17 = null;
//     java.lang.Object[] var19 = var0.nextSample(var17, 118517391);
// 
//   }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test129"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.lang.Object[] var4 = new java.lang.Object[] { 1.0f};
    org.apache.commons.math3.exception.MathArithmeticException var5 = new org.apache.commons.math3.exception.MathArithmeticException(var2, var4);
    org.apache.commons.math3.exception.MathIllegalArgumentException var6 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, var4);
    org.apache.commons.math3.exception.MathIllegalArgumentException var7 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test130() {}
//   public void test130() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test130"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(0L);
//     java.lang.String var4 = var0.nextHexString(100);
//     java.lang.String var6 = var0.nextSecureHexString(1);
//     double var9 = var0.nextCauchy((-0.4076885612903701d), 140.37260799449047d);
//     long var12 = var0.nextSecureLong(10L, 95L);
//     double var14 = var0.nextT(0.30978201097942376d);
//     double var16 = var0.nextChiSquare(102.85799933184796d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"+ "'", var4.equals("7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "8"+ "'", var6.equals("8"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-132.37300774287698d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 79L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.11177662188552794d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 90.09727801817395d);
// 
//   }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test131"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(0L);
    double var3 = var0.nextDouble();
    var0.clear();
    double var5 = var0.nextGaussian();
    boolean var6 = var0.nextBoolean();
    double var7 = var0.nextDouble();
    org.apache.commons.math3.random.RandomDataImpl var8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    double var10 = var8.nextChiSquare(0.7328699155755845d);
    var8.reSeed(20L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.7432416673360078d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1.2016184922621251d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.3874438233115065d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.13141108969377363d);

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test132"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)1.3650947445123496d);

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test133"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0f, var1, 10, var3, true);
    java.lang.Number var6 = var5.getArgument();
    java.lang.String var7 = var5.toString();
    org.apache.commons.math3.util.MathArrays.OrderDirection var8 = var5.getDirection();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 0.0f+ "'", var6.equals(0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "org.apache.commons.math3.exception.NonMonotonicSequenceException: points 9 and 10 are not strictly decreasing (null <= 0)"+ "'", var7.equals("org.apache.commons.math3.exception.NonMonotonicSequenceException: points 9 and 10 are not strictly decreasing (null <= 0)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test134() {}
//   public void test134() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test134"); }
// 
// 
//     int[] var0 = null;
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     int[] var3 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(var3);
//     int[] var6 = org.apache.commons.math3.util.MathArrays.copyOf(var3, 100);
//     int var7 = org.apache.commons.math3.util.MathArrays.distance1(var1, var3);
//     int[] var8 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(var8);
//     int var10 = org.apache.commons.math3.util.MathArrays.distanceInf(var3, var8);
//     org.apache.commons.math3.random.Well19937c var11 = new org.apache.commons.math3.random.Well19937c();
//     var11.setSeed(0L);
//     double var14 = var11.nextDouble();
//     var11.clear();
//     double var16 = var11.nextGaussian();
//     boolean var17 = var11.nextBoolean();
//     int[] var18 = new int[] { };
//     int[] var19 = null;
//     int var20 = org.apache.commons.math3.util.MathArrays.distance1(var18, var19);
//     org.apache.commons.math3.random.Well19937c var21 = new org.apache.commons.math3.random.Well19937c(var18);
//     int[] var22 = org.apache.commons.math3.util.MathArrays.copyOf(var18);
//     var11.setSeed(var22);
//     double var24 = org.apache.commons.math3.util.MathArrays.distance(var3, var22);
//     int var25 = org.apache.commons.math3.util.MathArrays.distance1(var0, var22);
// 
//   }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test135"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)1, (java.lang.Number)1L, (java.lang.Number)(short)(-1));
    java.lang.Number var5 = var4.getHi();
    java.lang.Number var6 = var4.getLo();
    java.lang.Number var7 = var4.getLo();
    java.lang.Number var8 = var4.getLo();
    java.lang.Number var9 = var4.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (short)(-1)+ "'", var5.equals((short)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 1L+ "'", var6.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 1L+ "'", var7.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 1L+ "'", var8.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + (short)(-1)+ "'", var9.equals((short)(-1)));

  }

  public void test136() {}
//   public void test136() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test136"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 104075088);
// 
//   }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test137"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.006597507087946431d, (java.lang.Number)29L, true);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test138"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)1, (java.lang.Number)1L, (java.lang.Number)(short)(-1));
    java.lang.Number var5 = var4.getLo();
    java.lang.Number var6 = var4.getHi();
    java.lang.Number var7 = var4.getHi();
    java.lang.Number var8 = var4.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1L+ "'", var5.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (short)(-1)+ "'", var6.equals((short)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (short)(-1)+ "'", var7.equals((short)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 1L+ "'", var8.equals(1L));

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test139"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1.0f), (java.lang.Number)95.05446642472492d, 44);

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test140"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(0L);
    double var3 = var0.nextDouble();
    float var4 = var0.nextFloat();
    long var5 = var0.nextLong();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.7432416673360078d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.5918164f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 3932213204370553937L);

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test141"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double[] var18 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 10.0d);
    double[] var20 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var20);
    double[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 10);
    double[] var25 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var20, var25);
    double[] var29 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var29);
    double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 10);
    double var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var32);
    double var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var25);
    double[] var36 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var36);
    double[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var36, 10);
    double[] var41 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var41);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var36, var41);
    double[] var45 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var45);
    double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var45, 10);
    double var49 = org.apache.commons.math3.util.MathArrays.distanceInf(var41, var48);
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeAdd(var18, var41);
    double[] var52 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var52);
    double[] var55 = org.apache.commons.math3.util.MathArrays.copyOf(var52, 10);
    double[] var57 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var57);
    boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var52, var57);
    double[] var61 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var61);
    double[] var64 = org.apache.commons.math3.util.MathArrays.copyOf(var61, 10);
    double var65 = org.apache.commons.math3.util.MathArrays.distanceInf(var57, var64);
    org.apache.commons.math3.util.MathArrays.OrderDirection var66 = null;
    boolean var68 = org.apache.commons.math3.util.MathArrays.isMonotonic(var57, var66, true);
    double[] var70 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var70);
    double var72 = org.apache.commons.math3.util.MathArrays.distance1(var57, var70);
    double[] var74 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var74);
    double[] var77 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var77);
    double[] var80 = org.apache.commons.math3.util.MathArrays.copyOf(var77, 10);
    double var81 = org.apache.commons.math3.util.MathArrays.distanceInf(var74, var80);
    double[] var82 = org.apache.commons.math3.util.MathArrays.ebeDivide(var70, var74);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var83 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var18, var82);
    double var85 = var83.inverseCumulativeProbability(0.0d);
    double var86 = var83.getNumericalMean();
    boolean var87 = var83.isSupportLowerBoundInclusive();
    double var88 = var83.getNumericalVariance();
    double var89 = var83.sample();
    double var90 = var83.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 11.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 10.0d);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test142"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double[] var18 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 10.0d);
    double[] var20 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var20);
    double[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 10);
    double[] var25 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var20, var25);
    double[] var29 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var29);
    double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 10);
    double var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var32);
    double var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var25);
    double[] var36 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var36);
    double[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var36, 10);
    double[] var41 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var41);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var36, var41);
    double[] var45 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var45);
    double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var45, 10);
    double var49 = org.apache.commons.math3.util.MathArrays.distanceInf(var41, var48);
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeAdd(var18, var41);
    double[] var52 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var52);
    double[] var55 = org.apache.commons.math3.util.MathArrays.copyOf(var52, 10);
    double[] var57 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var57);
    boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var52, var57);
    double[] var61 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var61);
    double[] var64 = org.apache.commons.math3.util.MathArrays.copyOf(var61, 10);
    double var65 = org.apache.commons.math3.util.MathArrays.distanceInf(var57, var64);
    org.apache.commons.math3.util.MathArrays.OrderDirection var66 = null;
    boolean var68 = org.apache.commons.math3.util.MathArrays.isMonotonic(var57, var66, true);
    double[] var70 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var70);
    double var72 = org.apache.commons.math3.util.MathArrays.distance1(var57, var70);
    double[] var74 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var74);
    double[] var77 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var77);
    double[] var80 = org.apache.commons.math3.util.MathArrays.copyOf(var77, 10);
    double var81 = org.apache.commons.math3.util.MathArrays.distanceInf(var74, var80);
    double[] var82 = org.apache.commons.math3.util.MathArrays.ebeDivide(var70, var74);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var83 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var18, var82);
    double var85 = var83.inverseCumulativeProbability(0.0d);
    double var86 = var83.getNumericalMean();
    boolean var87 = var83.isSupportUpperBoundInclusive();
    double var89 = var83.cumulativeProbability(111.8477520686252d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 11.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == 1.0d);

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test143"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)7, (java.lang.Number)0.4054370868227162d, false);

  }

  public void test144() {}
//   public void test144() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test144"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(0L);
//     java.lang.String var4 = var0.nextHexString(100);
//     java.lang.String var6 = var0.nextSecureHexString(1);
//     var0.reSeed((-1L));
//     double var10 = var0.nextExponential(0.915778680097192d);
//     var0.reSeedSecure();
//     var0.reSeedSecure();
//     double var15 = var0.nextGaussian(0.3864176294443096d, 9.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var18 = var0.nextZipf(104075088, (-0.043481143175376734d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"+ "'", var4.equals("7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "a"+ "'", var6.equals("a"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.3650947445123496d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-14.882779139030047d));
// 
//   }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test145"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(-0.2763414335696296d));

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test146"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double[] var18 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 10.0d);
    double[] var20 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var20);
    double[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 10);
    double[] var25 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var20, var25);
    double[] var29 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var29);
    double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 10);
    double var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var32);
    double var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var25);
    double[] var36 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var36);
    double[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var36, 10);
    double[] var41 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var41);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var36, var41);
    double[] var45 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var45);
    double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var45, 10);
    double var49 = org.apache.commons.math3.util.MathArrays.distanceInf(var41, var48);
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeAdd(var18, var41);
    double[] var52 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var52);
    double[] var55 = org.apache.commons.math3.util.MathArrays.copyOf(var52, 10);
    double[] var57 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var57);
    boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var52, var57);
    double[] var61 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var61);
    double[] var64 = org.apache.commons.math3.util.MathArrays.copyOf(var61, 10);
    double var65 = org.apache.commons.math3.util.MathArrays.distanceInf(var57, var64);
    org.apache.commons.math3.util.MathArrays.OrderDirection var66 = null;
    boolean var68 = org.apache.commons.math3.util.MathArrays.isMonotonic(var57, var66, true);
    double[] var70 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var70);
    double var72 = org.apache.commons.math3.util.MathArrays.distance1(var57, var70);
    double[] var74 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var74);
    double[] var77 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var77);
    double[] var80 = org.apache.commons.math3.util.MathArrays.copyOf(var77, 10);
    double var81 = org.apache.commons.math3.util.MathArrays.distanceInf(var74, var80);
    double[] var82 = org.apache.commons.math3.util.MathArrays.ebeDivide(var70, var74);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var83 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var18, var82);
    double var85 = var83.inverseCumulativeProbability(0.0d);
    double var86 = var83.getNumericalMean();
    boolean var87 = var83.isSupportLowerBoundInclusive();
    double var88 = var83.getNumericalVariance();
    double var89 = var83.sample();
    var83.reseedRandomGenerator(0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 11.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == 10.0d);

  }

  public void test147() {}
//   public void test147() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test147"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(0L);
//     java.lang.String var4 = var0.nextHexString(100);
//     java.lang.String var6 = var0.nextSecureHexString(1);
//     var0.reSeed((-1L));
//     var0.reSeed(0L);
//     double var13 = var0.nextWeibull(128.35556077963213d, 0.3874438233115065d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var0.nextSecureInt(274497138, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"+ "'", var4.equals("7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "f"+ "'", var6.equals("f"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.3883722390257413d);
// 
//   }

  public void test148() {}
//   public void test148() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test148"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(0L);
//     java.lang.String var4 = var0.nextHexString(100);
//     java.lang.String var6 = var0.nextSecureHexString(1);
//     var0.reSeed((-1L));
//     int var11 = var0.nextZipf(1, 2.1070663248503236d);
//     int var14 = var0.nextPascal(60481539, 0.014771889457054958d);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var18 = var0.nextUniform(0.05609443507672968d, (-1.7624108373068774d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"+ "'", var4.equals("7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "1"+ "'", var6.equals("1"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 2147483647);
// 
//   }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test149"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(0L);
    var0.clear();
    int var5 = var0.nextInt(1);
    int[] var6 = new int[] { };
    int[] var7 = null;
    int var8 = org.apache.commons.math3.util.MathArrays.distance1(var6, var7);
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(var6);
    int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var6);
    var0.setSeed(var6);
    int[] var13 = org.apache.commons.math3.util.MathArrays.copyOf(var6, 0);
    org.apache.commons.math3.random.Well19937c var14 = new org.apache.commons.math3.random.Well19937c(var6);
    int[] var15 = null;
    int var16 = org.apache.commons.math3.util.MathArrays.distanceInf(var6, var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test150"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)5, (java.lang.Number)9L, true);

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test151"); }


    long[] var0 = new long[] { };
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var0);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var0);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test152"); }


    org.apache.commons.math3.exception.MathIllegalStateException var0 = new org.apache.commons.math3.exception.MathIllegalStateException();
    org.apache.commons.math3.exception.util.ExceptionContext var1 = var0.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test153"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var4 = var0.nextBinomial((-1102768644), 0.3902199481749119d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test154() {}
//   public void test154() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test154"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     int var5 = var0.nextBinomial(10, 0.03863055888020799d);
//     int var8 = var0.nextSecureInt(7, 48);
//     int var11 = var0.nextSecureInt(39, 118517391);
//     long var13 = var0.nextPoisson(0.7088914394874254d);
//     double var15 = var0.nextExponential(0.6183635164792604d);
//     int var18 = var0.nextZipf(31, 22.579321102366254d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.25863624275029323d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 43825767);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.20199078550748426d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1);
// 
//   }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test155"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(0L);
    double var4 = var0.nextExponential(0.7432416673360078d);
    var0.reSeedSecure();
    double var8 = var0.nextF(101.79109515357918d, 0.6116146111830432d);
    var0.reSeed(434277157163744896L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSecureAlgorithm("418abcee7df04a0f3ec62876a979497d366cc2b99ca03d1c", "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.36157468479281d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 7.890608942511265d);

  }

  public void test156() {}
//   public void test156() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test156"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(0L);
//     java.lang.String var4 = var0.nextHexString(100);
//     java.lang.String var6 = var0.nextSecureHexString(1);
//     double var9 = var0.nextCauchy((-0.4076885612903701d), 140.37260799449047d);
//     long var12 = var0.nextSecureLong(10L, 95L);
//     double var15 = var0.nextGaussian(0.0d, 103.06912597726082d);
//     double var18 = var0.nextCauchy(0.00322408197305579d, 128.35556077963213d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var20 = var0.nextPoisson(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"+ "'", var4.equals("7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "b"+ "'", var6.equals("b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-132.37300774287698d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 50L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-185.7588642130088d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-2021.3144698165793d));
// 
//   }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test157"); }


    float[] var0 = null;
    float[] var3 = new float[] { 100.0f, 10.0f};
    boolean var4 = org.apache.commons.math3.util.MathArrays.equals(var0, var3);
    float[] var8 = new float[] { 0.0f, (-1.0f), 0.0f};
    boolean var9 = org.apache.commons.math3.util.MathArrays.equals(var3, var8);
    float[] var10 = null;
    float[] var13 = new float[] { 100.0f, 10.0f};
    boolean var14 = org.apache.commons.math3.util.MathArrays.equals(var10, var13);
    float[] var18 = new float[] { 0.0f, (-1.0f), 0.0f};
    boolean var19 = org.apache.commons.math3.util.MathArrays.equals(var13, var18);
    boolean var20 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var8, var18);
    float[] var21 = null;
    float[] var24 = new float[] { 100.0f, 10.0f};
    boolean var25 = org.apache.commons.math3.util.MathArrays.equals(var21, var24);
    float[] var29 = new float[] { 0.0f, (-1.0f), 0.0f};
    boolean var30 = org.apache.commons.math3.util.MathArrays.equals(var24, var29);
    float[] var31 = null;
    float[] var34 = new float[] { 100.0f, 10.0f};
    boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var31, var34);
    float[] var39 = new float[] { 0.0f, (-1.0f), 0.0f};
    boolean var40 = org.apache.commons.math3.util.MathArrays.equals(var34, var39);
    float[] var41 = null;
    float[] var44 = new float[] { 100.0f, 10.0f};
    boolean var45 = org.apache.commons.math3.util.MathArrays.equals(var41, var44);
    float[] var49 = new float[] { 0.0f, (-1.0f), 0.0f};
    boolean var50 = org.apache.commons.math3.util.MathArrays.equals(var44, var49);
    boolean var51 = org.apache.commons.math3.util.MathArrays.equals(var34, var44);
    boolean var52 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var29, var34);
    boolean var53 = org.apache.commons.math3.util.MathArrays.equals(var8, var34);
    float[] var54 = null;
    float[] var57 = new float[] { 100.0f, 10.0f};
    boolean var58 = org.apache.commons.math3.util.MathArrays.equals(var54, var57);
    boolean var59 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var8, var57);
    float[] var60 = null;
    float[] var63 = new float[] { 100.0f, 10.0f};
    boolean var64 = org.apache.commons.math3.util.MathArrays.equals(var60, var63);
    float[] var68 = new float[] { 0.0f, (-1.0f), 0.0f};
    boolean var69 = org.apache.commons.math3.util.MathArrays.equals(var63, var68);
    float[] var71 = new float[] { 100.0f};
    float[] var72 = new float[] { };
    boolean var73 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var71, var72);
    boolean var74 = org.apache.commons.math3.util.MathArrays.equals(var63, var72);
    boolean var75 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var8, var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == false);

  }

  public void test158() {}
//   public void test158() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test158"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     int var5 = var0.nextBinomial(0, 0.0d);
//     double var8 = var0.nextGaussian(108.97593914807048d, 101.79109515357918d);
//     double var10 = var0.nextT(0.00940319128424221d);
//     double var12 = var0.nextT(1.9081813459147294E-5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "f50be494db776832566b5401d90ff00b892d9e475033f0f7a770e9d531ed12e2e9b353e2150d411c4cb7e4e8656951057bf2"+ "'", var2.equals("f50be494db776832566b5401d90ff00b892d9e475033f0f7a770e9d531ed12e2e9b353e2150d411c4cb7e4e8656951057bf2"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 76.94403264090633d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-8.6337413834089021E18d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1.3407807929942597E154d);
// 
//   }

  public void test159() {}
//   public void test159() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test159"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(0L);
//     java.lang.String var4 = var0.nextHexString(100);
//     java.lang.String var6 = var0.nextSecureHexString(1);
//     var0.reSeed((-1L));
//     double var10 = var0.nextExponential(0.915778680097192d);
//     var0.reSeed(7L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"+ "'", var4.equals("7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "a"+ "'", var6.equals("a"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.3650947445123496d);
// 
//   }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test160"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)114.23712557956448d, (java.lang.Number)0.09175824555693415d, 0);
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    java.lang.Object[] var8 = new java.lang.Object[] { (short)10};
    org.apache.commons.math3.exception.MathInternalError var9 = new org.apache.commons.math3.exception.MathInternalError(var6, var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var5, var8);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, var8);
    org.apache.commons.math3.exception.util.ExceptionContext var12 = var11.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test161() {}
//   public void test161() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test161"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 102269683, 43);
// 
//   }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test162"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(0L);
    var0.clear();
    int var5 = var0.nextInt(1);
    int[] var6 = new int[] { };
    int[] var7 = null;
    int var8 = org.apache.commons.math3.util.MathArrays.distance1(var6, var7);
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(var6);
    int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var6);
    var0.setSeed(var6);
    int[] var13 = org.apache.commons.math3.util.MathArrays.copyOf(var6, 0);
    org.apache.commons.math3.random.Well19937c var14 = new org.apache.commons.math3.random.Well19937c(var6);
    int var15 = var14.nextInt();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 752916846);

  }

  public void test163() {}
//   public void test163() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test163"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     int var5 = var0.nextBinomial(10, 0.03863055888020799d);
//     int var8 = var0.nextSecureInt(7, 48);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var0.nextPascal(41, 99.15680865820634d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.028796898941244247d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 46);
// 
//   }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test164"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(85L);
    float var2 = var1.nextFloat();
    int var4 = var1.nextInt(95);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.21589696f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 10);

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test165"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var3 = new java.lang.Object[] { 'a'};
    org.apache.commons.math3.exception.NotFiniteNumberException var4 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)(short)0, var3);
    double[] var6 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var6);
    org.apache.commons.math3.util.MathArrays.OrderDirection var8 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var6, var8, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var6);
    org.apache.commons.math3.util.Pair var12 = new org.apache.commons.math3.util.Pair((java.lang.Object)(short)0, (java.lang.Object)var6);
    java.lang.Object var13 = var12.getValue();
    org.apache.commons.math3.util.Pair var14 = new org.apache.commons.math3.util.Pair(var12);
    int[] var15 = new int[] { };
    int[] var16 = null;
    int var17 = org.apache.commons.math3.util.MathArrays.distance1(var15, var16);
    org.apache.commons.math3.random.Well19937c var18 = new org.apache.commons.math3.random.Well19937c(var15);
    double var19 = var18.nextGaussian();
    long var20 = var18.nextLong();
    boolean var21 = var12.equals((java.lang.Object)var20);
    java.lang.Object var22 = var12.getSecond();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.2478736222527921d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1024457413273955602L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test166"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(0L);
    double var3 = var0.nextDouble();
    var0.clear();
    double var5 = var0.nextGaussian();
    boolean var6 = var0.nextBoolean();
    double var7 = var0.nextDouble();
    var0.setSeed(100);
    var0.setSeed(1L);
    int var12 = var0.nextInt();
    long var13 = var0.nextLong();
    boolean var14 = var0.nextBoolean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.7432416673360078d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1.2016184922621251d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.3874438233115065d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 312574995);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 828254766248375101L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test167"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    double[] var4 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var4);
    double[] var7 = org.apache.commons.math3.util.MathArrays.copyOf(var4, 10);
    double[] var9 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var11 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var11, false);
    double var14 = org.apache.commons.math3.util.MathArrays.safeNorm(var9);
    double[] var16 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var16);
    double[] var19 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var19);
    double[] var22 = org.apache.commons.math3.util.MathArrays.copyOf(var19, 10);
    double var23 = org.apache.commons.math3.util.MathArrays.distanceInf(var16, var22);
    double[] var24 = org.apache.commons.math3.util.MathArrays.ebeDivide(var9, var16);
    double[] var26 = org.apache.commons.math3.util.MathArrays.normalizeArray(var9, 10.0d);
    double var27 = org.apache.commons.math3.util.MathArrays.distance(var4, var9);
    double[] var28 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.DiscreteRealDistribution var29 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var1, var4);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test168() {}
//   public void test168() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test168"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(0L);
//     long var5 = var0.nextSecureLong(10L, 100L);
//     double var7 = var0.nextT(119.7441447260784d);
//     double var11 = var0.nextUniform(0.092975850275352d, 0.3864176294443096d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var13 = var0.nextSecureHexString(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 12L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.6553232415694416d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.2666395291136514d);
// 
//   }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test169"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    long[] var2 = new long[] { };
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var2);
    long[][] var4 = new long[][] { var2};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var4);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var4);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var4);
    org.apache.commons.math3.exception.MathIllegalArgumentException var8 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.MathIllegalArgumentException var9 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var4);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test170"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(161574481);
    boolean var2 = var1.nextBoolean();
    double var3 = var1.nextDouble();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9954797483567299d);

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test171"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double[] var18 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 10.0d);
    double[] var20 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var20);
    double[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 10);
    double[] var25 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var20, var25);
    double[] var29 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var29);
    double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 10);
    double var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var32);
    double var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var25);
    org.apache.commons.math3.util.MathArrays.OrderDirection var35 = null;
    double[] var37 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var37);
    org.apache.commons.math3.util.MathArrays.OrderDirection var39 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var37, var39, false);
    double var42 = org.apache.commons.math3.util.MathArrays.safeNorm(var37);
    double[] var44 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var44);
    double[] var47 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var47);
    double[] var50 = org.apache.commons.math3.util.MathArrays.copyOf(var47, 10);
    double var51 = org.apache.commons.math3.util.MathArrays.distanceInf(var44, var50);
    double[] var52 = org.apache.commons.math3.util.MathArrays.ebeDivide(var37, var44);
    double[] var54 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var54);
    org.apache.commons.math3.util.MathArrays.OrderDirection var56 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var54, var56, false);
    double var59 = org.apache.commons.math3.util.MathArrays.safeNorm(var54);
    org.apache.commons.math3.util.MathArrays.OrderDirection var60 = null;
    boolean var62 = org.apache.commons.math3.util.MathArrays.isMonotonic(var54, var60, false);
    double[][] var63 = new double[][] { var54};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var37, var63);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var18, var35, var63);
    double[] var67 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var67);
    org.apache.commons.math3.util.MathArrays.OrderDirection var69 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var67, var69, false);
    double var72 = org.apache.commons.math3.util.MathArrays.safeNorm(var67);
    org.apache.commons.math3.util.MathArrays.OrderDirection var73 = null;
    boolean var75 = org.apache.commons.math3.util.MathArrays.isMonotonic(var67, var73, false);
    double var76 = org.apache.commons.math3.util.MathArrays.distance(var18, var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 11.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == 11.0d);

  }

  public void test172() {}
//   public void test172() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test172"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.exception.util.Localizable var3 = null;
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     java.lang.Object[] var8 = new java.lang.Object[] { 'a'};
//     org.apache.commons.math3.exception.NotFiniteNumberException var9 = new org.apache.commons.math3.exception.NotFiniteNumberException(var5, (java.lang.Number)(short)0, var8);
//     org.apache.commons.math3.exception.NotFiniteNumberException var10 = new org.apache.commons.math3.exception.NotFiniteNumberException(var3, (java.lang.Number)10L, var8);
//     org.apache.commons.math3.exception.NotFiniteNumberException var11 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Number)114.23712557956448d, var8);
//     org.apache.commons.math3.exception.MathInternalError var12 = new org.apache.commons.math3.exception.MathInternalError(var0, var8);
//     org.apache.commons.math3.exception.util.ExceptionContext var13 = var12.getContext();
//     org.apache.commons.math3.exception.util.Localizable var14 = null;
//     java.lang.Comparable[] var17 = new java.lang.Comparable[] { (byte)(-1)};
//     org.apache.commons.math3.util.MathArrays.OrderDirection var18 = null;
//     boolean var20 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var17, var18, true);
//     org.apache.commons.math3.exception.NotFiniteNumberException var21 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)107.34245912507674d, (java.lang.Object[])var17);
//     java.lang.Number var23 = null;
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var25 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.026278128681618596d, var23, 1);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var26 = var25.getDirection();
//     boolean var28 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var17, var26, true);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var29 = null;
//     boolean var31 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var17, var29, true);
//     org.apache.commons.math3.exception.MathIllegalStateException var32 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var12, var14, (java.lang.Object[])var17);
// 
//   }

  public void test173() {}
//   public void test173() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test173"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     var0.reSeed(75L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var9 = var0.nextSecureLong(75L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.5802797197021307d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 102.20603246210669d);
// 
//   }

  public void test174() {}
//   public void test174() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test174"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     var0.reSeedSecure();
//     var0.reSeed();
//     int var9 = var0.nextZipf(21, 0.044259860704679646d);
//     int var12 = var0.nextPascal(39, 0.29461270966732284d);
//     int var15 = var0.nextSecureInt(95, 100);
//     long var18 = var0.nextLong(0L, 87L);
//     var0.reSeedSecure(0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.8737826638044551d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 108.58953716726795d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 95);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 35L);
// 
//   }

  public void test175() {}
//   public void test175() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test175"); }
// 
// 
//     java.lang.Comparable[] var0 = null;
//     double[] var2 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var2);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var4 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var2, var4, false);
//     double var7 = org.apache.commons.math3.util.MathArrays.safeNorm(var2);
//     double[] var8 = org.apache.commons.math3.util.MathArrays.copyOf(var2);
//     java.lang.Number var10 = null;
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var12 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.026278128681618596d, var10, 1);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var13 = var12.getDirection();
//     double[] var15 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var15);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var17 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var15, var17, false);
//     double var20 = org.apache.commons.math3.util.MathArrays.safeNorm(var15);
//     double[] var22 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var22);
//     double[] var25 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var25);
//     double[] var28 = org.apache.commons.math3.util.MathArrays.copyOf(var25, 10);
//     double var29 = org.apache.commons.math3.util.MathArrays.distanceInf(var22, var28);
//     double[] var30 = org.apache.commons.math3.util.MathArrays.ebeDivide(var15, var22);
//     double[] var32 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var32);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var34 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var32, var34, false);
//     double var37 = org.apache.commons.math3.util.MathArrays.safeNorm(var32);
//     double[] var39 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var39);
//     double[] var42 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var42);
//     double[] var45 = org.apache.commons.math3.util.MathArrays.copyOf(var42, 10);
//     double var46 = org.apache.commons.math3.util.MathArrays.distanceInf(var39, var45);
//     double[] var47 = org.apache.commons.math3.util.MathArrays.ebeDivide(var32, var39);
//     double[] var49 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var49);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var51 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var49, var51, false);
//     double var54 = org.apache.commons.math3.util.MathArrays.safeNorm(var49);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var55 = null;
//     boolean var57 = org.apache.commons.math3.util.MathArrays.isMonotonic(var49, var55, false);
//     double[][] var58 = new double[][] { var49};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var32, var58);
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var30, var58);
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var8, var13, var58);
//     boolean var63 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var0, var13, true);
// 
//   }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test176"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    int[] var2 = new int[] { };
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var2);
    int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var2, 100);
    int var6 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    int[] var7 = new int[] { };
    org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(var7);
    int var9 = org.apache.commons.math3.util.MathArrays.distanceInf(var2, var7);
    org.apache.commons.math3.random.Well19937c var10 = new org.apache.commons.math3.random.Well19937c(var2);
    var10.setSeed(0L);
    int[] var13 = new int[] { };
    int[] var14 = null;
    int var15 = org.apache.commons.math3.util.MathArrays.distance1(var13, var14);
    org.apache.commons.math3.random.Well19937c var16 = new org.apache.commons.math3.random.Well19937c(var13);
    int[] var17 = org.apache.commons.math3.util.MathArrays.copyOf(var13);
    var10.setSeed(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test177() {}
//   public void test177() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test177"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(0L);
//     java.lang.String var4 = var0.nextHexString(100);
//     java.lang.String var6 = var0.nextSecureHexString(1);
//     var0.reSeed((-1L));
//     double var10 = var0.nextExponential(0.915778680097192d);
//     var0.reSeedSecure();
//     var0.reSeed();
//     java.lang.String var14 = var0.nextHexString(3);
//     double var16 = var0.nextT(110.74774393374405d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"+ "'", var4.equals("7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "1"+ "'", var6.equals("1"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.3650947445123496d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "97f"+ "'", var14.equals("97f"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.9642648988717306d);
// 
//   }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test178"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0d, (java.lang.Number)(-1.4055588913319086d), 11);

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test179"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(52084938, 10);
    java.lang.Number var3 = var2.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 52084938+ "'", var3.equals(52084938));

  }

  public void test180() {}
//   public void test180() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test180"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     int var5 = var0.nextBinomial(10, 0.03863055888020799d);
//     double var8 = var0.nextF(0.6062775910181382d, 1.305475194865426d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.8256644489823178d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.08905416082245278d);
// 
//   }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test181"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)0.0015326576218039215d);

  }

  public void test182() {}
//   public void test182() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test182"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var5 = var0.nextCauchy(0.3901018313315268d, 0.5002136323263786d);
//     var0.reSeed(85L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-1.2249234637323128d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.7856242548250161d);
// 
//   }

  public void test183() {}
//   public void test183() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test183"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(98.7281415762265d);
//     double var9 = var0.nextBeta(0.5230125715149944d, 99.46470318494777d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var0.nextChiSquare((-0.2763414335696296d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.6091669489885866d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 111.94532048520936d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 93.55771439338926d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.012260798563756163d);
// 
//   }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test184"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var5 = var0.nextHypergeometric(1, 3, 20);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test185() {}
//   public void test185() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test185"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     int var5 = var0.nextBinomial(10, 0.03863055888020799d);
//     int var8 = var0.nextSecureInt(7, 48);
//     int var11 = var0.nextSecureInt(39, 118517391);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var0.nextWeibull((-0.1943431852363057d), 0.001805751245344147d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.1795852492032277d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 57087238);
// 
//   }

  public void test186() {}
//   public void test186() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test186"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     var0.reSeed();
//     double var12 = var0.nextF(82.45368975667407d, 0.5876583645210812d);
//     int var15 = var0.nextInt(118517391, 752916846);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.3422223564715284d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 126.64645331962207d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.2093464542718285E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "e"+ "'", var8.equals("e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 12.552626105393347d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 668857625);
// 
//   }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test187"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.5206144238498145d, (java.lang.Number)114.81244598869324d, (java.lang.Number)101.29456331084373d);
    org.apache.commons.math3.exception.NotStrictlyPositiveException var5 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0.05609443507672968d);
    var3.addSuppressed((java.lang.Throwable)var5);
    org.apache.commons.math3.exception.util.ExceptionContext var7 = var5.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test188"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(0L);
    double var4 = var0.nextT(101.79109515357918d);
    int var7 = var0.nextPascal(30, 0.7432416673360078d);
    double var10 = var0.nextCauchy(121.1195598148109d, 0.004855959215203466d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.6556684902257256d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 121.11723441984769d);

  }

  public void test189() {}
//   public void test189() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test189"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     java.lang.Object[] var3 = new java.lang.Object[] { (short)10};
//     org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError(var1, var3);
//     org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError(var0, var3);
//     org.apache.commons.math3.exception.util.ExceptionContext var6 = var5.getContext();
//     org.apache.commons.math3.exception.util.Localizable var7 = null;
//     org.apache.commons.math3.exception.util.Localizable var8 = null;
//     org.apache.commons.math3.exception.util.Localizable var9 = null;
//     org.apache.commons.math3.exception.util.Localizable var10 = null;
//     java.lang.Object[] var12 = new java.lang.Object[] { (short)10};
//     org.apache.commons.math3.exception.MathInternalError var13 = new org.apache.commons.math3.exception.MathInternalError(var10, var12);
//     org.apache.commons.math3.exception.MathInternalError var14 = new org.apache.commons.math3.exception.MathInternalError(var9, var12);
//     org.apache.commons.math3.exception.NullArgumentException var15 = new org.apache.commons.math3.exception.NullArgumentException(var8, var12);
//     org.apache.commons.math3.exception.MathIllegalStateException var16 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var5, var7, var12);
// 
//   }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test190"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0.05609443507672968d);
    java.lang.String var2 = var1.toString();
    boolean var3 = var1.getBoundIsAllowed();
    java.lang.Number var5 = null;
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var9 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0f, var5, 10, var7, true);
    org.apache.commons.math3.exception.util.ExceptionContext var10 = var9.getContext();
    int var11 = var9.getIndex();
    boolean var12 = var9.getStrict();
    var1.addSuppressed((java.lang.Throwable)var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "org.apache.commons.math3.exception.NotStrictlyPositiveException: 0.056 is smaller than, or equal to, the minimum (0)"+ "'", var2.equals("org.apache.commons.math3.exception.NotStrictlyPositiveException: 0.056 is smaller than, or equal to, the minimum (0)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test191"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(34L);

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test192"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.9960669395743666d, (java.lang.Number)0.2666395291136514d, (java.lang.Number)(-1.0f));

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test193"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Object[] var6 = new java.lang.Object[] { 'a'};
    org.apache.commons.math3.exception.NotFiniteNumberException var7 = new org.apache.commons.math3.exception.NotFiniteNumberException(var3, (java.lang.Number)(short)0, var6);
    org.apache.commons.math3.exception.NotFiniteNumberException var8 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Number)10L, var6);
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var6);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var13 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0d, (java.lang.Number)(byte)(-1), 1);
    boolean var14 = var13.getStrict();
    java.lang.String var15 = var13.toString();
    var9.addSuppressed((java.lang.Throwable)var13);
    int var17 = var13.getIndex();
    java.lang.Number var18 = var13.getPrevious();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "org.apache.commons.math3.exception.NonMonotonicSequenceException: points 0 and 1 are not strictly increasing (-1 >= 1)"+ "'", var15.equals("org.apache.commons.math3.exception.NonMonotonicSequenceException: points 0 and 1 are not strictly increasing (-1 >= 1)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + (byte)(-1)+ "'", var18.equals((byte)(-1)));

  }

  public void test194() {}
//   public void test194() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test194"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     java.lang.String var10 = var0.nextSecureHexString(1);
//     double var14 = var0.nextUniform(1.5528800970508765d, 104.21185957727327d, true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-1.0468697497074575d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 123.14843614424522d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.637478530048477d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "0"+ "'", var8.equals("0"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "f"+ "'", var10.equals("f"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 39.94891670229468d);
// 
//   }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test195"); }


    double[] var3 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var4 = org.apache.commons.math3.util.MathArrays.safeNorm(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 14.177446878757825d);

  }

  public void test196() {}
//   public void test196() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test196"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     java.lang.Object[] var3 = new java.lang.Object[] { (short)10};
//     org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError(var1, var3);
//     org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError(var0, var3);
//     org.apache.commons.math3.exception.util.ExceptionContext var6 = var5.getContext();
//     org.apache.commons.math3.exception.util.ExceptionContext var7 = var5.getContext();
//     java.lang.String var8 = var5.toString();
// 
//   }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test197"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    long[] var1 = new long[] { };
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var1);
    long[][] var3 = new long[][] { var1};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var3);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var3);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var3);
    org.apache.commons.math3.exception.NullArgumentException var7 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test198"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException((-1), (-1));
    int var3 = var2.getDimension();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var7 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0d, (java.lang.Number)(byte)(-1), 1);
    boolean var8 = var7.getStrict();
    java.lang.String var9 = var7.toString();
    var2.addSuppressed((java.lang.Throwable)var7);
    org.apache.commons.math3.exception.MathInternalError var11 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var2);
    java.lang.Throwable[] var12 = var2.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "org.apache.commons.math3.exception.NonMonotonicSequenceException: points 0 and 1 are not strictly increasing (-1 >= 1)"+ "'", var9.equals("org.apache.commons.math3.exception.NonMonotonicSequenceException: points 0 and 1 are not strictly increasing (-1 >= 1)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test199"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    long[] var2 = new long[] { };
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var2);
    long[][] var4 = new long[][] { var2};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var4);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var4);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var4);
    org.apache.commons.math3.exception.NotFiniteNumberException var8 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)100.0d, (java.lang.Object[])var4);
    java.lang.Throwable[] var9 = var8.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test200() {}
//   public void test200() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test200"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var8 = var0.nextUniform(0.3874438233115065d, 1.0d, true);
//     long var10 = var0.nextPoisson(0.5230125715149944d);
//     double var12 = var0.nextT(0.3821299365949273d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var0.nextExponential((-0.02996456728244196d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.2436531083167197d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 88.33045616276995d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.817835770737772d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 39.58486749962608d);
// 
//   }

  public void test201() {}
//   public void test201() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test201"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     var0.reSeed();
//     long var11 = var0.nextPoisson(0.4517190132114119d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var0.nextInt(669834927, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.837503881427898d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 102.14655872764286d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.18254127258546593d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "b"+ "'", var8.equals("b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1L);
// 
//   }

  public void test202() {}
//   public void test202() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test202"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     long[] var3 = new long[] { };
//     org.apache.commons.math3.util.MathArrays.checkNonNegative(var3);
//     long[][] var5 = new long[][] { var3};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var5);
//     org.apache.commons.math3.util.MathArrays.checkNonNegative(var5);
//     org.apache.commons.math3.util.MathArrays.checkNonNegative(var5);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var9 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, (java.lang.Object[])var5);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var10 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, (java.lang.Object[])var5);
//     org.apache.commons.math3.exception.MathInternalError var11 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var5);
//     org.apache.commons.math3.exception.util.Localizable var12 = null;
//     org.apache.commons.math3.exception.util.Localizable var13 = null;
//     org.apache.commons.math3.exception.util.Localizable var15 = null;
//     java.lang.Object[] var18 = new java.lang.Object[] { 'a'};
//     org.apache.commons.math3.exception.NotFiniteNumberException var19 = new org.apache.commons.math3.exception.NotFiniteNumberException(var15, (java.lang.Number)(short)0, var18);
//     org.apache.commons.math3.exception.NotFiniteNumberException var20 = new org.apache.commons.math3.exception.NotFiniteNumberException(var13, (java.lang.Number)10L, var18);
//     org.apache.commons.math3.exception.MathIllegalStateException var21 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var11, var12, var18);
// 
//   }

  public void test203() {}
//   public void test203() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test203"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(98.7281415762265d);
//     int var9 = var0.nextZipf(100, 114.23712557956448d);
//     double var12 = var0.nextGaussian(316621.8458765788d, 0.3713843112707765d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.457382231084021d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 137.5054909626155d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 104.19959178213986d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 316621.74067207996d);
// 
//   }

  public void test204() {}
//   public void test204() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test204"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     var0.reSeedSecure();
//     double var7 = var0.nextChiSquare(0.09175824555693415d);
//     double var10 = var0.nextGamma(90.09727801817395d, 0.001805751245344147d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.07542070486250835d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 116.05850219767689d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.15236687205232924d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.15094594379840265d);
// 
//   }

  public void test205() {}
//   public void test205() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test205"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var8 = var0.nextUniform(0.3874438233115065d, 1.0d, true);
//     long var10 = var0.nextPoisson(0.5230125715149944d);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var0.nextUniform(102.08072974342622d, (-46.08081612693308d), true);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.09764511576918063d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 100.43930457614614d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.7150639062532831d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0L);
// 
//   }

  public void test206() {}
//   public void test206() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test206"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     double var11 = var0.nextBeta(106.19070066324907d, 14386.159160118537d);
//     double var14 = var0.nextGaussian(116.05850219767689d, 154.77942702297287d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.5611538553163746d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 111.145352497306d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.24320895211928395d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "c"+ "'", var8.equals("c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.007636099008066639d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 126.60285928099428d);
// 
//   }

  public void test207() {}
//   public void test207() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test207"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     double var5 = var0.nextWeibull(110.0d, 0.3874438233115065d);
//     var0.reSeedSecure();
//     int var9 = var0.nextZipf(31, 0.6183635164792604d);
//     var0.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "d7b9391c331a0f307f583f2ead5f1e4633d1e954d6de524b310fd6624344f042fe68261b7310759b943d6f7c82d412b9f0fe"+ "'", var2.equals("d7b9391c331a0f307f583f2ead5f1e4633d1e954d6de524b310fd6624344f042fe68261b7310759b943d6f7c82d412b9f0fe"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.38342028550333196d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 4);
// 
//   }

  public void test208() {}
//   public void test208() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test208"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     long var10 = var0.nextPoisson(98.7281415762265d);
//     double var13 = var0.nextBeta(89.61418224548213d, 111.67623937136405d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var0.nextPascal(16, (-1.4429699710362356d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.6080555611666112d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 102.63158938220127d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.45220122582319366d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "8"+ "'", var8.equals("8"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 119L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.41453962744996575d);
// 
//   }

  public void test209() {}
//   public void test209() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test209"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var5 = var0.nextCauchy(0.054183156649680556d, 7.277800330956172E-5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-2.0725018201915377d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.054168290098472925d);
// 
//   }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test210"); }


    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.4924399031470064E10d, (java.lang.Number)(-0.06187681393378908d), 1, var3, true);
    int var6 = var5.getIndex();
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = var5.getDirection();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test211"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.999946785885159d, (java.lang.Number)(-0.043481143175376734d), true);
    java.lang.Number var4 = var3.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0.999946785885159d+ "'", var4.equals(0.999946785885159d));

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test212"); }


    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1.1917327900748924d), (java.lang.Number)4.149496931236865d, 312574995, var3, false);
    boolean var6 = var5.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = var5.getDirection();
    java.lang.Number var9 = null;
    org.apache.commons.math3.util.MathArrays.OrderDirection var11 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var13 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0f, var9, 10, var11, true);
    var5.addSuppressed((java.lang.Throwable)var13);
    int var15 = var13.getIndex();
    int var16 = var13.getIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 10);

  }

  public void test213() {}
//   public void test213() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test213"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var5 = var0.nextCauchy(0.3901018313315268d, 0.5002136323263786d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var7 = var0.nextT(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.6684931167142459d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-0.09384259121063354d));
// 
//   }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test214"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    java.lang.Number var18 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var20 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.026278128681618596d, var18, 1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var21 = var20.getDirection();
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var21, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test215"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-2.422255593706966d), (java.lang.Number)0.06729966802586457d, false);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test216"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double[] var18 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 10.0d);
    double[] var20 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var20);
    double[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 10);
    double[] var25 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var20, var25);
    double[] var29 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var29);
    double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 10);
    double var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var32);
    double var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var25);
    double[] var36 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var36);
    double[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var36, 10);
    double[] var41 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var41);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var36, var41);
    double[] var45 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var45);
    double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var45, 10);
    double var49 = org.apache.commons.math3.util.MathArrays.distanceInf(var41, var48);
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeAdd(var18, var41);
    double[] var52 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var52);
    double[] var55 = org.apache.commons.math3.util.MathArrays.copyOf(var52, 10);
    double[] var57 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var57);
    boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var52, var57);
    double[] var61 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var61);
    double[] var64 = org.apache.commons.math3.util.MathArrays.copyOf(var61, 10);
    double var65 = org.apache.commons.math3.util.MathArrays.distanceInf(var57, var64);
    org.apache.commons.math3.util.MathArrays.OrderDirection var66 = null;
    boolean var68 = org.apache.commons.math3.util.MathArrays.isMonotonic(var57, var66, true);
    double[] var70 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var70);
    double var72 = org.apache.commons.math3.util.MathArrays.distance1(var57, var70);
    double[] var74 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var74);
    double[] var77 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var77);
    double[] var80 = org.apache.commons.math3.util.MathArrays.copyOf(var77, 10);
    double var81 = org.apache.commons.math3.util.MathArrays.distanceInf(var74, var80);
    double[] var82 = org.apache.commons.math3.util.MathArrays.ebeDivide(var70, var74);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var83 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var18, var82);
    double var85 = var83.inverseCumulativeProbability(0.0d);
    double var86 = var83.getNumericalMean();
    double var87 = var83.getSupportUpperBound();
    double var88 = var83.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 11.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == 10.0d);

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test217"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Object[] var6 = new java.lang.Object[] { 'a'};
    org.apache.commons.math3.exception.NotFiniteNumberException var7 = new org.apache.commons.math3.exception.NotFiniteNumberException(var3, (java.lang.Number)(short)0, var6);
    org.apache.commons.math3.exception.NotFiniteNumberException var8 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Number)10L, var6);
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var6);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var13 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0d, (java.lang.Number)(byte)(-1), 1);
    boolean var14 = var13.getStrict();
    java.lang.String var15 = var13.toString();
    var9.addSuppressed((java.lang.Throwable)var13);
    int var17 = var13.getIndex();
    boolean var18 = var13.getStrict();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "org.apache.commons.math3.exception.NonMonotonicSequenceException: points 0 and 1 are not strictly increasing (-1 >= 1)"+ "'", var15.equals("org.apache.commons.math3.exception.NonMonotonicSequenceException: points 0 and 1 are not strictly increasing (-1 >= 1)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test218"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(-0.33420519785105623d));
    java.lang.Number var2 = var1.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + (-0.33420519785105623d)+ "'", var2.equals((-0.33420519785105623d)));

  }

  public void test219() {}
//   public void test219() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test219"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var8 = var0.nextUniform(0.3874438233115065d, 1.0d, true);
//     long var10 = var0.nextPoisson(0.5230125715149944d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var0.nextBeta(7.67089341016808d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.42788685894722406d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 83.91171622714768d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.8626436563308595d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1L);
// 
//   }

  public void test220() {}
//   public void test220() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test220"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     double var5 = var0.nextWeibull(110.0d, 0.3874438233115065d);
//     var0.reSeedSecure();
//     double var8 = var0.nextExponential(1.3790131551731492E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "ef1abad15ad9a39964179c384774c8f806f7fce3aa5683123421fe99b376197c0cab892d4fbcf776e728cddd00e9acf32634"+ "'", var2.equals("ef1abad15ad9a39964179c384774c8f806f7fce3aa5683123421fe99b376197c0cab892d4fbcf776e728cddd00e9acf32634"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.381486780272475d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 6.312631185464617E-5d);
// 
//   }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test221"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double[] var18 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 10.0d);
    double[] var20 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var20);
    double[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 10);
    double[] var25 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var20, var25);
    double[] var29 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var29);
    double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 10);
    double var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var32);
    double var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var25);
    double[] var36 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var36);
    double[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var36, 10);
    double[] var41 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var41);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var36, var41);
    double[] var45 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var45);
    double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var45, 10);
    double var49 = org.apache.commons.math3.util.MathArrays.distanceInf(var41, var48);
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeAdd(var18, var41);
    double[] var52 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var52);
    double[] var55 = org.apache.commons.math3.util.MathArrays.copyOf(var52, 10);
    double[] var57 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var57);
    boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var52, var57);
    double[] var61 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var61);
    double[] var64 = org.apache.commons.math3.util.MathArrays.copyOf(var61, 10);
    double var65 = org.apache.commons.math3.util.MathArrays.distanceInf(var57, var64);
    org.apache.commons.math3.util.MathArrays.OrderDirection var66 = null;
    boolean var68 = org.apache.commons.math3.util.MathArrays.isMonotonic(var57, var66, true);
    double[] var70 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var70);
    double var72 = org.apache.commons.math3.util.MathArrays.distance1(var57, var70);
    double[] var74 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var74);
    double[] var77 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var77);
    double[] var80 = org.apache.commons.math3.util.MathArrays.copyOf(var77, 10);
    double var81 = org.apache.commons.math3.util.MathArrays.distanceInf(var74, var80);
    double[] var82 = org.apache.commons.math3.util.MathArrays.ebeDivide(var70, var74);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var83 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var18, var82);
    double var85 = var83.inverseCumulativeProbability(0.0d);
    double var86 = var83.getNumericalMean();
    boolean var87 = var83.isSupportLowerBoundInclusive();
    double var88 = var83.getNumericalVariance();
    boolean var89 = var83.isSupportConnected();
    double var90 = var83.getNumericalMean();
    double var91 = var83.getSupportLowerBound();
    boolean var92 = var83.isSupportLowerBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 11.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var91 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == true);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test222"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-2.422255593706966d), (java.lang.Number)101.44314796560174d, true);
    java.lang.Number var5 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 101.44314796560174d+ "'", var5.equals(101.44314796560174d));

  }

  public void test223() {}
//   public void test223() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test223"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     var0.reSeedSecure();
//     int var8 = var0.nextZipf(16, 100.38955484251419d);
//     int var11 = var0.nextInt((-1276125876), 39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.8736979400992977d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 109.24144102290273d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-50854423));
// 
//   }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test224"); }


    int[] var0 = new int[] { };
    int[] var1 = null;
    int var2 = org.apache.commons.math3.util.MathArrays.distance1(var0, var1);
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c();
    var3.setSeed(0L);
    double var6 = var3.nextDouble();
    int[] var10 = new int[] { 1, 10, 100};
    var3.setSeed(var10);
    int var12 = org.apache.commons.math3.util.MathArrays.distance1(var0, var10);
    int[] var13 = new int[] { };
    int[] var14 = null;
    int var15 = org.apache.commons.math3.util.MathArrays.distance1(var13, var14);
    org.apache.commons.math3.random.Well19937c var16 = new org.apache.commons.math3.random.Well19937c();
    var16.setSeed(0L);
    double var19 = var16.nextDouble();
    int[] var23 = new int[] { 1, 10, 100};
    var16.setSeed(var23);
    int var25 = org.apache.commons.math3.util.MathArrays.distance1(var13, var23);
    int var26 = org.apache.commons.math3.util.MathArrays.distanceInf(var0, var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.7432416673360078d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.7432416673360078d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);

  }

  public void test225() {}
//   public void test225() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test225"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     double var11 = var0.nextGamma(0.36157468479281d, 0.8376757571801716d);
//     var0.reSeed();
//     var0.reSeedSecure();
//     double var16 = var0.nextCauchy(99.15680865820634d, 54.76711054963606d);
//     java.lang.String var18 = var0.nextSecureHexString(71);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.827798029544068d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 105.66998161762055d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.5820989343200836d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "e"+ "'", var8.equals("e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.19326168815525727d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == (-46.41745928820278d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var18 + "' != '" + "81055ecfcfd726ec956c460d76ee061924d2f0d315f5ee8226edf19a65d12ba2c2085a8"+ "'", var18.equals("81055ecfcfd726ec956c460d76ee061924d2f0d315f5ee8226edf19a65d12ba2c2085a8"));
// 
//   }

  public void test226() {}
//   public void test226() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test226"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     double var11 = var0.nextGamma(0.36157468479281d, 0.8376757571801716d);
//     var0.reSeed();
//     var0.reSeedSecure();
//     long var15 = var0.nextPoisson(196.03435534813178d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.12609116060477937d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 133.93322667392013d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.002243081223676036d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "b"+ "'", var8.equals("b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.27601538321399927d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 189L);
// 
//   }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test227"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var3 = new java.lang.Object[] { 'a'};
    org.apache.commons.math3.exception.NotFiniteNumberException var4 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)(short)0, var3);
    double[] var6 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var6);
    org.apache.commons.math3.util.MathArrays.OrderDirection var8 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var6, var8, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var6);
    org.apache.commons.math3.util.Pair var12 = new org.apache.commons.math3.util.Pair((java.lang.Object)(short)0, (java.lang.Object)var6);
    java.lang.Object var13 = var12.getValue();
    org.apache.commons.math3.util.Pair var14 = new org.apache.commons.math3.util.Pair(var12);
    java.lang.Object var15 = var14.getKey();
    java.lang.Number var16 = null;
    org.apache.commons.math3.exception.util.Localizable var17 = null;
    org.apache.commons.math3.exception.util.Localizable var18 = null;
    java.lang.Object[] var20 = new java.lang.Object[] { 1.0f};
    org.apache.commons.math3.exception.MathArithmeticException var21 = new org.apache.commons.math3.exception.MathArithmeticException(var18, var20);
    org.apache.commons.math3.exception.MathIllegalArgumentException var22 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var17, var20);
    org.apache.commons.math3.exception.NotFiniteNumberException var23 = new org.apache.commons.math3.exception.NotFiniteNumberException(var16, var20);
    boolean var24 = var14.equals((java.lang.Object)var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + (short)0+ "'", var15.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test228"); }


    float[] var0 = null;
    float[] var3 = new float[] { 100.0f, 10.0f};
    boolean var4 = org.apache.commons.math3.util.MathArrays.equals(var0, var3);
    float[] var5 = new float[] { };
    boolean var6 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test229() {}
//   public void test229() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test229"); }
// 
// 
//     int[] var0 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double[] var2 = null;
//     double[] var3 = null;
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var4 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var2, var3);
// 
//   }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test230"); }


    int[] var0 = new int[] { };
    int[] var1 = null;
    int var2 = org.apache.commons.math3.util.MathArrays.distance1(var0, var1);
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var0);
    int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var0, 0);
    int[] var6 = new int[] { };
    int[] var7 = null;
    int var8 = org.apache.commons.math3.util.MathArrays.distance1(var6, var7);
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(var6);
    int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var6);
    org.apache.commons.math3.random.Well19937c var11 = new org.apache.commons.math3.random.Well19937c(var6);
    int var12 = org.apache.commons.math3.util.MathArrays.distanceInf(var5, var6);
    org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(var5);
    int[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var5, 1);
    int[] var16 = new int[] { };
    org.apache.commons.math3.random.Well19937c var17 = new org.apache.commons.math3.random.Well19937c(var16);
    int[] var18 = new int[] { };
    org.apache.commons.math3.random.Well19937c var19 = new org.apache.commons.math3.random.Well19937c(var18);
    int[] var21 = org.apache.commons.math3.util.MathArrays.copyOf(var18, 100);
    int var22 = org.apache.commons.math3.util.MathArrays.distance1(var16, var18);
    int[] var23 = new int[] { };
    org.apache.commons.math3.random.Well19937c var24 = new org.apache.commons.math3.random.Well19937c(var23);
    int var25 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var23);
    int var26 = org.apache.commons.math3.util.MathArrays.distanceInf(var5, var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test231"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Comparable[] var3 = new java.lang.Comparable[] { 84.46848877247005d};
    org.apache.commons.math3.util.MathArrays.OrderDirection var4 = null;
    boolean var6 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var3, var4, false);
    org.apache.commons.math3.exception.MathArithmeticException var7 = new org.apache.commons.math3.exception.MathArithmeticException(var1, (java.lang.Object[])var3);
    org.apache.commons.math3.exception.MathArithmeticException var8 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var3);
    java.lang.Comparable[] var10 = new java.lang.Comparable[] { (byte)(-1)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var11 = null;
    boolean var13 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var10, var11, true);
    double[] var15 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var15);
    org.apache.commons.math3.util.MathArrays.OrderDirection var17 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var15, var17, false);
    double var20 = org.apache.commons.math3.util.MathArrays.safeNorm(var15);
    double[] var21 = org.apache.commons.math3.util.MathArrays.copyOf(var15);
    java.lang.Number var23 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var25 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.026278128681618596d, var23, 1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var26 = var25.getDirection();
    double[] var28 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var28);
    org.apache.commons.math3.util.MathArrays.OrderDirection var30 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var28, var30, false);
    double var33 = org.apache.commons.math3.util.MathArrays.safeNorm(var28);
    double[] var35 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var35);
    double[] var38 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var38);
    double[] var41 = org.apache.commons.math3.util.MathArrays.copyOf(var38, 10);
    double var42 = org.apache.commons.math3.util.MathArrays.distanceInf(var35, var41);
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeDivide(var28, var35);
    double[] var45 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var45);
    org.apache.commons.math3.util.MathArrays.OrderDirection var47 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var45, var47, false);
    double var50 = org.apache.commons.math3.util.MathArrays.safeNorm(var45);
    double[] var52 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var52);
    double[] var55 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var55);
    double[] var58 = org.apache.commons.math3.util.MathArrays.copyOf(var55, 10);
    double var59 = org.apache.commons.math3.util.MathArrays.distanceInf(var52, var58);
    double[] var60 = org.apache.commons.math3.util.MathArrays.ebeDivide(var45, var52);
    double[] var62 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var62);
    org.apache.commons.math3.util.MathArrays.OrderDirection var64 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var62, var64, false);
    double var67 = org.apache.commons.math3.util.MathArrays.safeNorm(var62);
    org.apache.commons.math3.util.MathArrays.OrderDirection var68 = null;
    boolean var70 = org.apache.commons.math3.util.MathArrays.isMonotonic(var62, var68, false);
    double[][] var71 = new double[][] { var62};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var45, var71);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var43, var71);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var21, var26, var71);
    boolean var76 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var10, var26, true);
    boolean var78 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var3, var26, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == true);

  }

  public void test232() {}
//   public void test232() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test232"); }
// 
// 
//     double[] var0 = null;
//     java.lang.Number var5 = null;
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var7 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.026278128681618596d, var5, 1);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var8 = var7.getDirection();
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var10 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.087939294119887d, (java.lang.Number)0.3901018313315268d, 88, var8, false);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var0, var8, false);
// 
//   }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test233"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double[] var18 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 10.0d);
    double[] var20 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var20);
    double[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 10);
    double[] var25 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var20, var25);
    double[] var29 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var29);
    double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 10);
    double var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var32);
    double var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var25);
    double[] var36 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var36);
    double[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var36, 10);
    double[] var41 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var41);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var36, var41);
    double[] var45 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var45);
    double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var45, 10);
    double var49 = org.apache.commons.math3.util.MathArrays.distanceInf(var41, var48);
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeAdd(var18, var41);
    double[] var52 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var52);
    double[] var55 = org.apache.commons.math3.util.MathArrays.copyOf(var52, 10);
    double[] var57 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var57);
    boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var52, var57);
    double[] var61 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var61);
    double[] var64 = org.apache.commons.math3.util.MathArrays.copyOf(var61, 10);
    double var65 = org.apache.commons.math3.util.MathArrays.distanceInf(var57, var64);
    org.apache.commons.math3.util.MathArrays.OrderDirection var66 = null;
    boolean var68 = org.apache.commons.math3.util.MathArrays.isMonotonic(var57, var66, true);
    double[] var70 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var70);
    double var72 = org.apache.commons.math3.util.MathArrays.distance1(var57, var70);
    double[] var74 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var74);
    double[] var77 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var77);
    double[] var80 = org.apache.commons.math3.util.MathArrays.copyOf(var77, 10);
    double var81 = org.apache.commons.math3.util.MathArrays.distanceInf(var74, var80);
    double[] var82 = org.apache.commons.math3.util.MathArrays.ebeDivide(var70, var74);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var83 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var18, var82);
    double var86 = var83.probability(0.0d, 76.50641463552304d);
    double[] var88 = var83.sample(48);
    boolean var89 = var83.isSupportConnected();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 11.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == true);

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test234"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double[] var18 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var18);
    org.apache.commons.math3.util.MathArrays.OrderDirection var20 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var18, var20, false);
    double var23 = org.apache.commons.math3.util.MathArrays.safeNorm(var18);
    double[] var25 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    double[] var28 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var28);
    double[] var31 = org.apache.commons.math3.util.MathArrays.copyOf(var28, 10);
    double var32 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var31);
    double[] var33 = org.apache.commons.math3.util.MathArrays.ebeDivide(var18, var25);
    double[] var35 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var35);
    org.apache.commons.math3.util.MathArrays.OrderDirection var37 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var35, var37, false);
    double var40 = org.apache.commons.math3.util.MathArrays.safeNorm(var35);
    org.apache.commons.math3.util.MathArrays.OrderDirection var41 = null;
    boolean var43 = org.apache.commons.math3.util.MathArrays.isMonotonic(var35, var41, false);
    double[][] var44 = new double[][] { var35};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var18, var44);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var16, var44);
    double[] var47 = org.apache.commons.math3.util.MathArrays.copyOf(var16);
    double[] var49 = org.apache.commons.math3.util.MathArrays.normalizeArray(var47, (-185.7588642130088d));
    double[] var50 = org.apache.commons.math3.util.MathArrays.copyOf(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test235"); }


    java.lang.Object var0 = null;
    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair(var0, (java.lang.Object)0.0893641512959175d);

  }

  public void test236() {}
//   public void test236() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test236"); }
// 
// 
//     double[] var0 = null;
//     double[] var2 = new double[] { (-1.0d)};
//     double var3 = org.apache.commons.math3.util.MathArrays.distanceInf(var0, var2);
// 
//   }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test237"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(0.30978201097942376d, (-0.7983970751347875d), 1.3407807929942597E154d, 0.30616747264586d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 4.1050346676316445E153d);

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test238"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(3, 3);

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test239"); }


    double[] var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var2 = org.apache.commons.math3.util.MathArrays.copyOf(var0, (-2087310710));
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test240"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(0.0d, 35.80121798427257d, 0.4887708362197951d, 0.09270498349096469d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.04531149230262111d);

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test241"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var3 = new java.lang.Object[] { 'a'};
    org.apache.commons.math3.exception.NotFiniteNumberException var4 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)(short)0, var3);
    double[] var6 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var6);
    org.apache.commons.math3.util.MathArrays.OrderDirection var8 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var6, var8, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var6);
    org.apache.commons.math3.util.Pair var12 = new org.apache.commons.math3.util.Pair((java.lang.Object)(short)0, (java.lang.Object)var6);
    java.lang.Object var13 = var12.getValue();
    boolean var15 = var12.equals((java.lang.Object)(short)0);
    boolean var17 = var12.equals((java.lang.Object)"c");
    java.lang.Object var18 = var12.getFirst();
    org.apache.commons.math3.util.Pair var19 = new org.apache.commons.math3.util.Pair(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + (short)0+ "'", var18.equals((short)0));

  }

  public void test242() {}
//   public void test242() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test242"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     int var5 = var0.nextBinomial(0, 0.0d);
//     java.lang.String var7 = var0.nextSecureHexString(16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "94ed166238f7f2ce43568dfd73e397bb4120059d2dad5ccebb3ff74dff07eb047f283c72bf244703fcd05d3525a789413e4c"+ "'", var2.equals("94ed166238f7f2ce43568dfd73e397bb4120059d2dad5ccebb3ff74dff07eb047f283c72bf244703fcd05d3525a789413e4c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + "df5c5249e1cda0b5"+ "'", var7.equals("df5c5249e1cda0b5"));
// 
//   }

  public void test243() {}
//   public void test243() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test243"); }
// 
// 
//     double[] var0 = null;
//     double[] var2 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var2);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var4 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var2, var4, false);
//     double var7 = org.apache.commons.math3.util.MathArrays.safeNorm(var2);
//     double[] var9 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var9);
//     double[] var12 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var12);
//     double[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var12, 10);
//     double var16 = org.apache.commons.math3.util.MathArrays.distanceInf(var9, var15);
//     double[] var17 = org.apache.commons.math3.util.MathArrays.ebeDivide(var2, var9);
//     double[] var19 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var19);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var21 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var19, var21, false);
//     double var24 = org.apache.commons.math3.util.MathArrays.safeNorm(var19);
//     double[] var26 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var26);
//     double[] var29 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var29);
//     double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 10);
//     double var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var26, var32);
//     double[] var34 = org.apache.commons.math3.util.MathArrays.ebeDivide(var19, var26);
//     double var35 = org.apache.commons.math3.util.MathArrays.safeNorm(var26);
//     double[] var37 = org.apache.commons.math3.util.MathArrays.copyOf(var26, 1);
//     double[] var39 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var39);
//     double[] var42 = org.apache.commons.math3.util.MathArrays.copyOf(var39, 10);
//     double[] var44 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var44);
//     boolean var46 = org.apache.commons.math3.util.MathArrays.equals(var39, var44);
//     double[] var48 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var48);
//     double[] var51 = org.apache.commons.math3.util.MathArrays.copyOf(var48, 10);
//     double var52 = org.apache.commons.math3.util.MathArrays.distanceInf(var44, var51);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var53 = null;
//     boolean var55 = org.apache.commons.math3.util.MathArrays.isMonotonic(var44, var53, true);
//     double[] var57 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var57);
//     double var59 = org.apache.commons.math3.util.MathArrays.distance1(var44, var57);
//     double[] var61 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var61);
//     double[] var64 = org.apache.commons.math3.util.MathArrays.copyOf(var61, 10);
//     double[] var66 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var66);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var68 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var66, var68, false);
//     boolean var71 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var64, var66);
//     double[] var72 = org.apache.commons.math3.util.MathArrays.ebeAdd(var44, var66);
//     double[] var73 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var37, var44);
//     double[] var74 = org.apache.commons.math3.util.MathArrays.ebeAdd(var2, var37);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var75 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var74, var75, false);
//     double var78 = org.apache.commons.math3.util.MathArrays.distance1(var0, var74);
// 
//   }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test244"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(0L);
    var0.clear();
    int var5 = var0.nextInt(1);
    int[] var6 = new int[] { };
    int[] var7 = null;
    int var8 = org.apache.commons.math3.util.MathArrays.distance1(var6, var7);
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(var6);
    int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var6);
    var0.setSeed(var6);
    org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(var6);
    var12.setSeed(6L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test245() {}
//   public void test245() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test245"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(98.7281415762265d);
//     double var9 = var0.nextBeta(0.5230125715149944d, 99.46470318494777d);
//     double var13 = var0.nextUniform((-2.348549660830877E50d), 0.0d, false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-1.278539033278717d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 104.54080659896094d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 95.15272936012431d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.0022794846271843557d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-6.348608094701994E49d));
// 
//   }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test246"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    long[] var1 = new long[] { };
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var1);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var1);
    long[][] var4 = new long[][] { var1};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var4);
    org.apache.commons.math3.exception.NullArgumentException var6 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test247() {}
//   public void test247() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test247"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     double var11 = var0.nextGamma(0.36157468479281d, 0.8376757571801716d);
//     double var14 = var0.nextCauchy(0.8376757571801716d, 0.3901018313315268d);
//     long var17 = var0.nextLong(86L, 95L);
//     long var20 = var0.nextSecureLong(86L, 337377217742076480L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.0324888902963785d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 119.76701215512722d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.6876035595108527d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "a"+ "'", var8.equals("a"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.08103115008120475d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.7534276667534705d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 87L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 247577959006713568L);
// 
//   }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test248"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double[] var18 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 10.0d);
    double[] var20 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var20);
    double[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 10);
    double[] var25 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var20, var25);
    double[] var29 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var29);
    double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 10);
    double var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var32);
    double var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var25);
    double[] var36 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var36);
    double[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var36, 10);
    double[] var41 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var41);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var36, var41);
    double[] var45 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var45);
    double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var45, 10);
    double var49 = org.apache.commons.math3.util.MathArrays.distanceInf(var41, var48);
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeAdd(var18, var41);
    double[] var52 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var52);
    double[] var55 = org.apache.commons.math3.util.MathArrays.copyOf(var52, 10);
    double[] var57 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var57);
    boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var52, var57);
    double[] var61 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var61);
    double[] var64 = org.apache.commons.math3.util.MathArrays.copyOf(var61, 10);
    double var65 = org.apache.commons.math3.util.MathArrays.distanceInf(var57, var64);
    org.apache.commons.math3.util.MathArrays.OrderDirection var66 = null;
    boolean var68 = org.apache.commons.math3.util.MathArrays.isMonotonic(var57, var66, true);
    double[] var70 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var70);
    double var72 = org.apache.commons.math3.util.MathArrays.distance1(var57, var70);
    double[] var74 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var74);
    double[] var77 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var77);
    double[] var80 = org.apache.commons.math3.util.MathArrays.copyOf(var77, 10);
    double var81 = org.apache.commons.math3.util.MathArrays.distanceInf(var74, var80);
    double[] var82 = org.apache.commons.math3.util.MathArrays.ebeDivide(var70, var74);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var83 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var18, var82);
    double var86 = var83.probability(0.0d, 76.50641463552304d);
    double var88 = var83.probability(113.5373271615141d);
    double var89 = var83.getSupportUpperBound();
    var83.reseedRandomGenerator(1024457413273955602L);
    double var92 = var83.getSupportUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 11.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == 10.0d);

  }

  public void test249() {}
//   public void test249() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test249"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     var0.reSeedSecure();
//     double var7 = var0.nextChiSquare(0.09175824555693415d);
//     java.lang.String var9 = var0.nextSecureHexString(33787721);
//     double var11 = var0.nextChiSquare(76.94403264090633d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-1.5161421136822135d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 115.7752567357238d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 3.775462785206006E-5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 64.67921931439825d);
// 
//   }

  public void test250() {}
//   public void test250() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test250"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     var0.reSeedSecure();
//     var0.reSeed();
//     int var9 = var0.nextZipf(21, 0.044259860704679646d);
//     java.lang.String var11 = var0.nextSecureHexString(48);
//     double var14 = var0.nextF(161.03739115985056d, 1.4726118418053777d);
//     var0.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.6024060110025723d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 95.90355784689234d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "06d775ca8a44f4f46cdeabce7ad974df371ca903db6bf3bd"+ "'", var11.equals("06d775ca8a44f4f46cdeabce7ad974df371ca903db6bf3bd"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.8411874521534305d);
// 
//   }

  public void test251() {}
//   public void test251() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test251"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(0L);
//     double var4 = var0.nextExponential(0.7432416673360078d);
//     int var7 = var0.nextSecureInt(1, 100);
//     java.lang.String var9 = var0.nextHexString(7);
//     var0.reSeedSecure();
//     double var12 = var0.nextExponential(140.37260799449047d);
//     double var16 = var0.nextUniform(0.41613954551936133d, 105.39091667829669d, false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.36157468479281d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "67c8011"+ "'", var9.equals("67c8011"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 157.85071953316267d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 55.776495015261276d);
// 
//   }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test252"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.8736979400992977d);

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test253"); }


    int[] var0 = new int[] { };
    int[] var1 = null;
    int var2 = org.apache.commons.math3.util.MathArrays.distance1(var0, var1);
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var0);
    double var4 = var3.nextGaussian();
    var3.setSeed(477395393);
    int[] var7 = new int[] { };
    org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(var7);
    int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 100);
    int[] var12 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 10);
    int[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 99);
    int[] var15 = new int[] { };
    org.apache.commons.math3.random.Well19937c var16 = new org.apache.commons.math3.random.Well19937c(var15);
    int[] var17 = new int[] { };
    org.apache.commons.math3.random.Well19937c var18 = new org.apache.commons.math3.random.Well19937c(var17);
    int[] var20 = org.apache.commons.math3.util.MathArrays.copyOf(var17, 100);
    int var21 = org.apache.commons.math3.util.MathArrays.distance1(var15, var17);
    int[] var22 = new int[] { };
    org.apache.commons.math3.random.Well19937c var23 = new org.apache.commons.math3.random.Well19937c(var22);
    int var24 = org.apache.commons.math3.util.MathArrays.distanceInf(var17, var22);
    int var25 = org.apache.commons.math3.util.MathArrays.distanceInf(var7, var17);
    var3.setSeed(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.2478736222527921d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0);

  }

  public void test254() {}
//   public void test254() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test254"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     var0.reSeedSecure();
//     var0.reSeed();
//     double var9 = var0.nextUniform(0.0015326576218039215d, 114.81244598869324d);
//     var0.reSeed();
//     double var12 = var0.nextT(0.001805751245344147d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-1.2705406793464897d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 119.43331691156347d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 63.053127911698766d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 4.703074129986149E56d);
// 
//   }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test255"); }


    float[] var0 = null;
    float[] var3 = new float[] { 100.0f, 10.0f};
    boolean var4 = org.apache.commons.math3.util.MathArrays.equals(var0, var3);
    float[] var8 = new float[] { 0.0f, (-1.0f), 0.0f};
    boolean var9 = org.apache.commons.math3.util.MathArrays.equals(var3, var8);
    float[] var10 = null;
    float[] var13 = new float[] { 100.0f, 10.0f};
    boolean var14 = org.apache.commons.math3.util.MathArrays.equals(var10, var13);
    float[] var18 = new float[] { 0.0f, (-1.0f), 0.0f};
    boolean var19 = org.apache.commons.math3.util.MathArrays.equals(var13, var18);
    float[] var20 = null;
    float[] var23 = new float[] { 100.0f, 10.0f};
    boolean var24 = org.apache.commons.math3.util.MathArrays.equals(var20, var23);
    float[] var28 = new float[] { 0.0f, (-1.0f), 0.0f};
    boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var23, var28);
    boolean var30 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var18, var28);
    float[] var31 = null;
    float[] var34 = new float[] { 100.0f, 10.0f};
    boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var31, var34);
    float[] var39 = new float[] { 0.0f, (-1.0f), 0.0f};
    boolean var40 = org.apache.commons.math3.util.MathArrays.equals(var34, var39);
    float[] var41 = null;
    float[] var44 = new float[] { 100.0f, 10.0f};
    boolean var45 = org.apache.commons.math3.util.MathArrays.equals(var41, var44);
    float[] var49 = new float[] { 0.0f, (-1.0f), 0.0f};
    boolean var50 = org.apache.commons.math3.util.MathArrays.equals(var44, var49);
    float[] var51 = null;
    float[] var54 = new float[] { 100.0f, 10.0f};
    boolean var55 = org.apache.commons.math3.util.MathArrays.equals(var51, var54);
    float[] var59 = new float[] { 0.0f, (-1.0f), 0.0f};
    boolean var60 = org.apache.commons.math3.util.MathArrays.equals(var54, var59);
    boolean var61 = org.apache.commons.math3.util.MathArrays.equals(var44, var54);
    boolean var62 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var39, var44);
    boolean var63 = org.apache.commons.math3.util.MathArrays.equals(var18, var44);
    boolean var64 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var18);
    float[] var66 = new float[] { 100.0f};
    float[] var67 = new float[] { };
    boolean var68 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var66, var67);
    boolean var69 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);

  }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test256"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var1.nextUniform(110.74774393374405d, 0.19326168815525727d, true);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test257"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double[] var18 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 10.0d);
    double[] var20 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var20);
    double[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 10);
    double[] var25 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var20, var25);
    double[] var29 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var29);
    double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 10);
    double var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var32);
    double var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var25);
    double[] var36 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var36);
    double[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var36, 10);
    double[] var41 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var41);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var36, var41);
    double[] var45 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var45);
    double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var45, 10);
    double var49 = org.apache.commons.math3.util.MathArrays.distanceInf(var41, var48);
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeAdd(var18, var41);
    double[] var52 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var52);
    double[] var55 = org.apache.commons.math3.util.MathArrays.copyOf(var52, 10);
    double[] var57 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var57);
    boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var52, var57);
    double[] var61 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var61);
    double[] var64 = org.apache.commons.math3.util.MathArrays.copyOf(var61, 10);
    double var65 = org.apache.commons.math3.util.MathArrays.distanceInf(var57, var64);
    org.apache.commons.math3.util.MathArrays.OrderDirection var66 = null;
    boolean var68 = org.apache.commons.math3.util.MathArrays.isMonotonic(var57, var66, true);
    double[] var70 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var70);
    double var72 = org.apache.commons.math3.util.MathArrays.distance1(var57, var70);
    double[] var74 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var74);
    double[] var77 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var77);
    double[] var80 = org.apache.commons.math3.util.MathArrays.copyOf(var77, 10);
    double var81 = org.apache.commons.math3.util.MathArrays.distanceInf(var74, var80);
    double[] var82 = org.apache.commons.math3.util.MathArrays.ebeDivide(var70, var74);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var83 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var18, var82);
    double var85 = var83.inverseCumulativeProbability(0.0d);
    double var86 = var83.getNumericalMean();
    boolean var87 = var83.isSupportLowerBoundInclusive();
    double var88 = var83.getNumericalVariance();
    double var89 = var83.getSupportLowerBound();
    double var90 = var83.getNumericalMean();
    double var92 = var83.probability((-0.4563799204122316d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 11.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == 0.0d);

  }

  public void test258() {}
//   public void test258() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test258"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     var0.reSeedSecure();
//     var0.reSeed();
//     int var9 = var0.nextZipf(21, 0.044259860704679646d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var0.nextBeta((-1.278539033278717d), (-0.19424604130720316d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.5410513023650271d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 134.06576273131915d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 6);
// 
//   }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test259"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double[] var18 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 10.0d);
    double[] var20 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var20);
    double[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 10);
    double[] var25 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var20, var25);
    double[] var29 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var29);
    double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 10);
    double var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var32);
    double var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var25);
    double[] var36 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var36);
    double[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var36, 10);
    double[] var41 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var41);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var36, var41);
    double[] var45 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var45);
    double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var45, 10);
    double var49 = org.apache.commons.math3.util.MathArrays.distanceInf(var41, var48);
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeAdd(var18, var41);
    double[] var52 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var52);
    double[] var55 = org.apache.commons.math3.util.MathArrays.copyOf(var52, 10);
    double[] var57 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var57);
    boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var52, var57);
    double[] var61 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var61);
    double[] var64 = org.apache.commons.math3.util.MathArrays.copyOf(var61, 10);
    double var65 = org.apache.commons.math3.util.MathArrays.distanceInf(var57, var64);
    org.apache.commons.math3.util.MathArrays.OrderDirection var66 = null;
    boolean var68 = org.apache.commons.math3.util.MathArrays.isMonotonic(var57, var66, true);
    double[] var70 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var70);
    double var72 = org.apache.commons.math3.util.MathArrays.distance1(var57, var70);
    double[] var74 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var74);
    double[] var77 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var77);
    double[] var80 = org.apache.commons.math3.util.MathArrays.copyOf(var77, 10);
    double var81 = org.apache.commons.math3.util.MathArrays.distanceInf(var74, var80);
    double[] var82 = org.apache.commons.math3.util.MathArrays.ebeDivide(var70, var74);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var83 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var18, var82);
    double var85 = var83.cumulativeProbability((-1.1720092180091226d));
    boolean var86 = var83.isSupportLowerBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 11.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == true);

  }

  public void test260() {}
//   public void test260() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test260"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     java.lang.String var10 = var0.nextSecureHexString(10);
//     double var12 = var0.nextT(9.160555011685411E-6d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("6787d61a5ba90119d4c4a669e528ce4e723a8a80d17f5dba", "cae21caaa3");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.7006544701758052d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 83.57073554313004d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3.4880607830922435E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "d"+ "'", var8.equals("d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "07466dbfc8"+ "'", var10.equals("07466dbfc8"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-1.34078079299423E154d));
// 
//   }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test261"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)52084938, var1, (java.lang.Number)157.85071953316267d);

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test262"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(0L);
    double var4 = var0.nextExponential(0.7432416673360078d);
    java.lang.String var6 = var0.nextHexString(7);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var8 = var0.nextPoisson((-0.06187681393378908d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.36157468479281d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "67c8011"+ "'", var6.equals("67c8011"));

  }

  public void test263() {}
//   public void test263() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test263"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     var0.setSeed(0L);
//     double var3 = var0.nextDouble();
//     var0.clear();
//     double var5 = var0.nextGaussian();
//     var0.clear();
//     java.util.List var7 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var8 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var0, var7);
// 
//   }

  public void test264() {}
//   public void test264() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test264"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var8 = var0.nextUniform(0.3874438233115065d, 1.0d, true);
//     long var10 = var0.nextPoisson(0.5230125715149944d);
//     double var12 = var0.nextT(0.3821299365949273d);
//     double var15 = var0.nextGamma(98.7281415762265d, 0.3979383851243543d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var18 = var0.nextLong(120033824254318496L, 34L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.8606385010829081d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 126.09316112868382d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.9810007698053856d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 79.06374479272411d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 31.559209181184205d);
// 
//   }

  public void test265() {}
//   public void test265() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test265"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     double var11 = var0.nextGamma(0.36157468479281d, 0.8376757571801716d);
//     var0.reSeed();
//     var0.reSeedSecure();
//     double var15 = var0.nextExponential(0.3902199481749119d);
//     long var18 = var0.nextSecureLong((-1L), 72L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var21 = var0.nextSecureLong(0L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.013938237228247215d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 114.0173862544057d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 6.447893342474752E-5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "1"+ "'", var8.equals("1"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.1849885552336797d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.34553732607094856d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 39L);
// 
//   }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test266"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(0L);
    double var3 = var0.nextDouble();
    var0.clear();
    double var5 = var0.nextGaussian();
    boolean var6 = var0.nextBoolean();
    double var7 = var0.nextDouble();
    var0.setSeed(100);
    int var10 = var0.nextInt();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.7432416673360078d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1.2016184922621251d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.3874438233115065d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-1347491339));

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test267"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    double[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 10);
    double[] var6 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var6);
    boolean var8 = org.apache.commons.math3.util.MathArrays.equals(var1, var6);
    double[] var10 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var10);
    double[] var13 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 10);
    double var14 = org.apache.commons.math3.util.MathArrays.distanceInf(var6, var13);
    org.apache.commons.math3.util.MathArrays.OrderDirection var15 = null;
    boolean var17 = org.apache.commons.math3.util.MathArrays.isMonotonic(var6, var15, true);
    double[] var19 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var19);
    double var21 = org.apache.commons.math3.util.MathArrays.distance1(var6, var19);
    double[] var23 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var23);
    double[] var26 = org.apache.commons.math3.util.MathArrays.copyOf(var23, 10);
    double[] var28 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var28);
    org.apache.commons.math3.util.MathArrays.OrderDirection var30 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var28, var30, false);
    boolean var33 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var26, var28);
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeAdd(var6, var28);
    org.apache.commons.math3.util.MathArrays.checkOrder(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test268"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    long[] var2 = new long[] { };
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var2);
    long[][] var4 = new long[][] { var2};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var4);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var4);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var4);
    org.apache.commons.math3.exception.NotFiniteNumberException var8 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)100.0d, (java.lang.Object[])var4);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var4);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test269() {}
//   public void test269() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test269"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(0L);
//     double var4 = var0.nextExponential(0.7432416673360078d);
//     int var7 = var0.nextSecureInt(1, 100);
//     double var10 = var0.nextWeibull(10.0d, 114.23712557956448d);
//     double var13 = var0.nextCauchy(0.41852678359398926d, 1.4480256314873523d);
//     int var16 = var0.nextInt(80, 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.36157468479281d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 112.98997911642695d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-0.2748957434128349d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1132514546);
// 
//   }

  public void test270() {}
//   public void test270() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test270"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     var0.setSeed(0L);
//     double var3 = var0.nextDouble();
//     var0.clear();
//     double var5 = var0.nextGaussian();
//     boolean var6 = var0.nextBoolean();
//     double var7 = var0.nextDouble();
//     var0.setSeed(100);
//     var0.setSeed(1L);
//     org.apache.commons.math3.random.RandomDataImpl var12 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var15 = var12.nextGaussian((-46.08081612693308d), 0.1919548516136001d);
//     long var18 = var12.nextSecureLong(0L, 9L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.7432416673360078d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-1.2016184922621251d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.3874438233115065d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-45.82609203188007d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 2L);
// 
//   }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test271"); }


    int[] var0 = new int[] { };
    int[] var1 = null;
    int var2 = org.apache.commons.math3.util.MathArrays.distance1(var0, var1);
    int[] var3 = new int[] { };
    int[] var4 = null;
    int var5 = org.apache.commons.math3.util.MathArrays.distance1(var3, var4);
    org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c(var3);
    int[] var7 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var0, var3);
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);

  }

  public void test272() {}
//   public void test272() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test272"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var8 = var0.nextUniform(0.3874438233115065d, 1.0d, true);
//     long var10 = var0.nextPoisson(0.5230125715149944d);
//     double var12 = var0.nextT(0.3821299365949273d);
//     double var15 = var0.nextGamma(98.7281415762265d, 0.3979383851243543d);
//     int var18 = var0.nextBinomial(100, 0.0d);
//     org.apache.commons.math3.distribution.IntegerDistribution var19 = null;
//     int var20 = var0.nextInversionDeviate(var19);
// 
//   }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test273"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(0L);
    double var4 = var0.nextExponential(0.7432416673360078d);
    var0.reSeed(0L);
    var0.reSeed(95L);
    double var11 = var0.nextGaussian(1.0668785930747748d, 0.10029940941769501d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.36157468479281d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1.0975797851428717d);

  }

  public void test274() {}
//   public void test274() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test274"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     double var11 = var0.nextGamma(0.36157468479281d, 0.8376757571801716d);
//     double var13 = var0.nextT(110.0d);
//     double var16 = var0.nextGaussian(0.3633053259796431d, 0.0015326576218039215d);
//     java.util.Collection var17 = null;
//     java.lang.Object[] var19 = var0.nextSample(var17, 669834927);
// 
//   }

  public void test275() {}
//   public void test275() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test275"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(98.7281415762265d);
//     int var9 = var0.nextZipf(100, 114.23712557956448d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var0.nextChiSquare((-0.781949188060055d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-2.186479232623825d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 146.63314790544476d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 88.28035475540614d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
// 
//   }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test276"); }


    long[] var0 = new long[] { };
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var0);
    long[][] var2 = new long[][] { var0};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var2);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var2);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test277"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)43.35042744195363d, var1, true);

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test278"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double[] var18 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 10.0d);
    double[] var20 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var20);
    double[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 10);
    double[] var25 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var20, var25);
    double[] var29 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var29);
    double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 10);
    double var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var32);
    double var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var25);
    double[] var36 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var36);
    double[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var36, 10);
    double[] var41 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var41);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var36, var41);
    double[] var45 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var45);
    double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var45, 10);
    double var49 = org.apache.commons.math3.util.MathArrays.distanceInf(var41, var48);
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeAdd(var18, var41);
    double[] var52 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var52);
    double[] var55 = org.apache.commons.math3.util.MathArrays.copyOf(var52, 10);
    double[] var57 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var57);
    boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var52, var57);
    double[] var61 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var61);
    double[] var64 = org.apache.commons.math3.util.MathArrays.copyOf(var61, 10);
    double var65 = org.apache.commons.math3.util.MathArrays.distanceInf(var57, var64);
    org.apache.commons.math3.util.MathArrays.OrderDirection var66 = null;
    boolean var68 = org.apache.commons.math3.util.MathArrays.isMonotonic(var57, var66, true);
    double[] var70 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var70);
    double var72 = org.apache.commons.math3.util.MathArrays.distance1(var57, var70);
    double[] var74 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var74);
    double[] var77 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var77);
    double[] var80 = org.apache.commons.math3.util.MathArrays.copyOf(var77, 10);
    double var81 = org.apache.commons.math3.util.MathArrays.distanceInf(var74, var80);
    double[] var82 = org.apache.commons.math3.util.MathArrays.ebeDivide(var70, var74);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var83 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var18, var82);
    double var86 = var83.probability(0.0d, 76.50641463552304d);
    double var88 = var83.probability(113.5373271615141d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var90 = var83.sample((-1102768644));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 11.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == 0.0d);

  }

  public void test279() {}
//   public void test279() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test279"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     double var5 = var0.nextWeibull(110.0d, 0.3874438233115065d);
//     var0.reSeedSecure();
//     double var9 = var0.nextUniform((-0.4563799204122316d), 107.34245912507674d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var11 = var0.nextHexString(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "4c8d75958c2520085a72a7a7ff3acf3febe04b3465b0d27872a3117df52b6ac4b731b1e8f9fc6843b1e28dd3643aead55598"+ "'", var2.equals("4c8d75958c2520085a72a7a7ff3acf3febe04b3465b0d27872a3117df52b6ac4b731b1e8f9fc6843b1e28dd3643aead55598"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.3872193158902265d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 18.034513052401884d);
// 
//   }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test280"); }


    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)(-0.07542070486250835d), (java.lang.Object)35L);

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test281"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-0.06187681393378908d), (java.lang.Number)75L, true);
    java.lang.Number var4 = var3.getMax();
    java.lang.Number var5 = var3.getMax();
    java.lang.Number var6 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 75L+ "'", var4.equals(75L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 75L+ "'", var5.equals(75L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 75L+ "'", var6.equals(75L));

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test282"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double[] var18 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 10.0d);
    double[] var20 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var20);
    double[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 10);
    double[] var25 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var20, var25);
    double[] var29 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var29);
    double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 10);
    double var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var32);
    double var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var25);
    double[] var36 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var36);
    org.apache.commons.math3.util.MathArrays.OrderDirection var38 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var36, var38, false);
    double var41 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var36);
    double[] var43 = org.apache.commons.math3.util.MathArrays.normalizeArray(var36, 98.30741799725186d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkPositive(var36);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 11.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test283"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    long[] var4 = new long[] { };
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var4);
    long[][] var6 = new long[][] { var4};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var6);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var6);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var6);
    org.apache.commons.math3.exception.MathIllegalArgumentException var10 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, (java.lang.Object[])var6);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var6);
    org.apache.commons.math3.exception.NotFiniteNumberException var12 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)0.6062775910181382d, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.NotFiniteNumberException var13 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)84L, (java.lang.Object[])var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test284"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(0L);
    double var3 = var0.nextDouble();
    var0.setSeed(48);
    org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c();
    var6.setSeed(0L);
    double var9 = var6.nextDouble();
    var6.clear();
    byte[] var14 = new byte[] { (byte)0, (byte)(-1), (byte)10};
    var6.nextBytes(var14);
    var0.nextBytes(var14);
    float var17 = var0.nextFloat();
    int var18 = var0.nextInt();
    int[] var19 = new int[] { };
    org.apache.commons.math3.random.Well19937c var20 = new org.apache.commons.math3.random.Well19937c(var19);
    int[] var21 = new int[] { };
    org.apache.commons.math3.random.Well19937c var22 = new org.apache.commons.math3.random.Well19937c(var21);
    int[] var24 = org.apache.commons.math3.util.MathArrays.copyOf(var21, 100);
    int var25 = org.apache.commons.math3.util.MathArrays.distance1(var19, var21);
    int[] var26 = new int[] { };
    org.apache.commons.math3.random.Well19937c var27 = new org.apache.commons.math3.random.Well19937c(var26);
    int var28 = org.apache.commons.math3.util.MathArrays.distanceInf(var21, var26);
    org.apache.commons.math3.random.Well19937c var29 = new org.apache.commons.math3.random.Well19937c(var21);
    var0.setSeed(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.7432416673360078d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.7432416673360078d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.40188384f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == (-2087310710));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);

  }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test285"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)0.006827580264427062d);

  }

  public void test286() {}
//   public void test286() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test286"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     double[] var1 = null;
//     double[] var3 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var3);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var5 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var3, var5, false);
//     double var8 = org.apache.commons.math3.util.MathArrays.safeNorm(var3);
//     double[] var10 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var10);
//     double[] var13 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var13);
//     double[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var13, 10);
//     double var17 = org.apache.commons.math3.util.MathArrays.distanceInf(var10, var16);
//     double[] var18 = org.apache.commons.math3.util.MathArrays.ebeDivide(var3, var10);
//     double var19 = org.apache.commons.math3.util.MathArrays.safeNorm(var10);
//     double[] var21 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 1);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var22 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var0, var1, var10);
// 
//   }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test287"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    java.lang.Object[] var9 = new java.lang.Object[] { 'a'};
    org.apache.commons.math3.exception.NotFiniteNumberException var10 = new org.apache.commons.math3.exception.NotFiniteNumberException(var6, (java.lang.Number)(short)0, var9);
    org.apache.commons.math3.exception.NotFiniteNumberException var11 = new org.apache.commons.math3.exception.NotFiniteNumberException(var4, (java.lang.Number)10L, var9);
    org.apache.commons.math3.exception.NotFiniteNumberException var12 = new org.apache.commons.math3.exception.NotFiniteNumberException(var2, (java.lang.Number)114.23712557956448d, var9);
    org.apache.commons.math3.exception.MathInternalError var13 = new org.apache.commons.math3.exception.MathInternalError(var1, var9);
    org.apache.commons.math3.exception.MathIllegalStateException var14 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test288() {}
//   public void test288() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test288"); }
// 
// 
//     int[] var0 = new int[] { };
//     int[] var1 = null;
//     int var2 = org.apache.commons.math3.util.MathArrays.distance1(var0, var1);
//     int[] var3 = new int[] { };
//     int[] var4 = null;
//     int var5 = org.apache.commons.math3.util.MathArrays.distance1(var3, var4);
//     org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c(var3);
//     int[] var7 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
//     double var8 = org.apache.commons.math3.util.MathArrays.distance(var0, var3);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var0, 93581048);
//       fail("Expected exception of type java.lang.OutOfMemoryError");
//     } catch (java.lang.OutOfMemoryError e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.0d);
// 
//   }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test289"); }


    int[] var0 = new int[] { };
    int[] var1 = null;
    int var2 = org.apache.commons.math3.util.MathArrays.distance1(var0, var1);
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var0);
    double var4 = var3.nextGaussian();
    var3.setSeed(477395393);
    org.apache.commons.math3.random.RandomDataGenerator var7 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var3);
    double var9 = var7.nextChiSquare(1.3790131551731492E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.2478736222527921d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);

  }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test290"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(0L);
    double var3 = var0.nextDouble();
    var0.clear();
    double var5 = var0.nextGaussian();
    boolean var6 = var0.nextBoolean();
    double var7 = var0.nextDouble();
    var0.setSeed(100);
    var0.setSeed(1L);
    org.apache.commons.math3.random.RandomDataImpl var12 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    double var15 = var12.nextGaussian((-46.08081612693308d), 0.1919548516136001d);
    var12.reSeed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.7432416673360078d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1.2016184922621251d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.3874438233115065d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == (-45.82609203188007d));

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test291"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    double[] var8 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 0.0d);
    double[] var10 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var10);
    double[] var13 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 10);
    double[] var15 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var15);
    boolean var17 = org.apache.commons.math3.util.MathArrays.equals(var10, var15);
    double[] var19 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var19);
    double[] var22 = org.apache.commons.math3.util.MathArrays.copyOf(var19, 10);
    double var23 = org.apache.commons.math3.util.MathArrays.distanceInf(var15, var22);
    org.apache.commons.math3.util.MathArrays.OrderDirection var24 = null;
    boolean var26 = org.apache.commons.math3.util.MathArrays.isMonotonic(var15, var24, true);
    double[] var28 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var28);
    double var30 = org.apache.commons.math3.util.MathArrays.distance1(var15, var28);
    double[] var31 = org.apache.commons.math3.util.MathArrays.copyOf(var28);
    double var32 = org.apache.commons.math3.util.MathArrays.distance(var8, var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 1.0d);

  }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test292"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double[] var18 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 10.0d);
    double[] var20 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var20);
    double[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 10);
    double[] var25 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var20, var25);
    double[] var29 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var29);
    double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 10);
    double var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var32);
    double var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var25);
    double[] var36 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var36);
    double[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var36, 10);
    double[] var41 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var41);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var36, var41);
    double[] var45 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var45);
    double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var45, 10);
    double var49 = org.apache.commons.math3.util.MathArrays.distanceInf(var41, var48);
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeAdd(var18, var41);
    double[] var52 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var52);
    double[] var55 = org.apache.commons.math3.util.MathArrays.copyOf(var52, 10);
    double[] var57 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var57);
    boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var52, var57);
    double[] var61 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var61);
    double[] var64 = org.apache.commons.math3.util.MathArrays.copyOf(var61, 10);
    double var65 = org.apache.commons.math3.util.MathArrays.distanceInf(var57, var64);
    org.apache.commons.math3.util.MathArrays.OrderDirection var66 = null;
    boolean var68 = org.apache.commons.math3.util.MathArrays.isMonotonic(var57, var66, true);
    double[] var70 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var70);
    double var72 = org.apache.commons.math3.util.MathArrays.distance1(var57, var70);
    double[] var74 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var74);
    double[] var77 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var77);
    double[] var80 = org.apache.commons.math3.util.MathArrays.copyOf(var77, 10);
    double var81 = org.apache.commons.math3.util.MathArrays.distanceInf(var74, var80);
    double[] var82 = org.apache.commons.math3.util.MathArrays.ebeDivide(var70, var74);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var83 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var18, var82);
    double var85 = var83.inverseCumulativeProbability(0.0d);
    double var86 = var83.getNumericalMean();
    double var87 = var83.getNumericalVariance();
    double var88 = var83.getNumericalVariance();
    boolean var89 = var83.isSupportConnected();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 11.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == true);

  }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test293"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-0.06187681393378908d), (java.lang.Number)75L, true);
    java.lang.Number var4 = var3.getMax();
    java.lang.Number var5 = var3.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 75L+ "'", var4.equals(75L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-0.06187681393378908d)+ "'", var5.equals((-0.06187681393378908d)));

  }

  public void test294() {}
//   public void test294() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test294"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     int var5 = var0.nextBinomial(0, 0.0d);
//     double var8 = var0.nextGaussian(108.97593914807048d, 101.79109515357918d);
//     double var10 = var0.nextT(0.00940319128424221d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var13 = var0.nextLong(1024457413273955602L, 22L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "d8727301e831486c7ba2116a33a14f4da7c2724c04a5d9d489c631bc567d80ae061f3efa45ee12e583b7bc72966e4d01c76b"+ "'", var2.equals("d8727301e831486c7ba2116a33a14f4da7c2724c04a5d9d489c631bc567d80ae061f3efa45ee12e583b7bc72966e4d01c76b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 15.895068577245922d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.6397633219474928E102d);
// 
//   }

  public void test295() {}
//   public void test295() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test295"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var0.nextGamma(0.7416991107644604d, (-0.4563799204122316d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.332015149312848d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 120.22240855595658d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.6608572563111144d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "8"+ "'", var8.equals("8"));
// 
//   }

  public void test296() {}
//   public void test296() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test296"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     double var5 = var0.nextWeibull(110.0d, 0.3874438233115065d);
//     var0.reSeedSecure();
//     long var9 = var0.nextLong(80L, 98L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "a776ac9e3cb9e32e49d56bc5886896f25dd9d2c58ee2e56fbe2c31c27a8265d86099ff1a07eb96a00c8fda2153d9d5f3f9e1"+ "'", var2.equals("a776ac9e3cb9e32e49d56bc5886896f25dd9d2c58ee2e56fbe2c31c27a8265d86099ff1a07eb96a00c8fda2153d9d5f3f9e1"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.38488330017147976d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 83L);
// 
//   }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test297"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(102.76117401192116d, 110.65775795733349d, (-1.2705406793464897d), 0.3820913396294463d, (-0.14215215277913013d), 0.9954797483567299d, 96.24327708512766d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 11370.694149043098d);

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test298"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(-1));
    boolean var3 = var2.getBoundIsAllowed();
    java.lang.Number var4 = var2.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0+ "'", var4.equals(0));

  }

  public void test299() {}
//   public void test299() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test299"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var3 = var1.nextChiSquare(1.3650947445123496d);
//     int var6 = var1.nextBinomial(0, 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.43415600041984104d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0);
// 
//   }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test300"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)1, (java.lang.Number)1L, (java.lang.Number)(short)(-1));
    java.lang.Number var5 = var4.getLo();
    java.lang.Number var6 = var4.getLo();
    java.lang.Number var7 = var4.getLo();
    java.lang.Number var8 = var4.getHi();
    java.lang.Number var9 = var4.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1L+ "'", var5.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 1L+ "'", var6.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 1L+ "'", var7.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (short)(-1)+ "'", var8.equals((short)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + 1L+ "'", var9.equals(1L));

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test301"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.6553232415694416d, true);

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test302"); }


    int[] var0 = new int[] { };
    int[] var1 = null;
    int var2 = org.apache.commons.math3.util.MathArrays.distance1(var0, var1);
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var0);
    double var4 = var3.nextGaussian();
    long var5 = var3.nextLong();
    var3.clear();
    var3.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.2478736222527921d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1024457413273955602L);

  }

  public void test303() {}
//   public void test303() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test303"); }
// 
// 
//     int[] var0 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     int[] var2 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var2);
//     int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var2, 100);
//     int var6 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
//     int[] var7 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(var7);
//     int var9 = org.apache.commons.math3.util.MathArrays.distanceInf(var2, var7);
//     org.apache.commons.math3.random.Well19937c var10 = new org.apache.commons.math3.random.Well19937c(var2);
//     var10.setSeed(0L);
//     double var13 = var10.nextGaussian();
//     java.util.List var14 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var15 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var10, var14);
// 
//   }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test304"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double[] var18 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 10.0d);
    double[] var20 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var20);
    double[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 10);
    double[] var25 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var20, var25);
    double[] var29 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var29);
    double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 10);
    double var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var32);
    double var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var25);
    double[] var36 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var36);
    double[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var36, 10);
    double[] var41 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var41);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var36, var41);
    double[] var45 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var45);
    double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var45, 10);
    double var49 = org.apache.commons.math3.util.MathArrays.distanceInf(var41, var48);
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeAdd(var18, var41);
    double[] var52 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var52);
    double[] var55 = org.apache.commons.math3.util.MathArrays.copyOf(var52, 10);
    double[] var57 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var57);
    boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var52, var57);
    double[] var61 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var61);
    double[] var64 = org.apache.commons.math3.util.MathArrays.copyOf(var61, 10);
    double var65 = org.apache.commons.math3.util.MathArrays.distanceInf(var57, var64);
    org.apache.commons.math3.util.MathArrays.OrderDirection var66 = null;
    boolean var68 = org.apache.commons.math3.util.MathArrays.isMonotonic(var57, var66, true);
    double[] var70 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var70);
    double var72 = org.apache.commons.math3.util.MathArrays.distance1(var57, var70);
    double[] var74 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var74);
    double[] var77 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var77);
    double[] var80 = org.apache.commons.math3.util.MathArrays.copyOf(var77, 10);
    double var81 = org.apache.commons.math3.util.MathArrays.distanceInf(var74, var80);
    double[] var82 = org.apache.commons.math3.util.MathArrays.ebeDivide(var70, var74);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var83 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var18, var82);
    double[] var85 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var85);
    org.apache.commons.math3.util.MathArrays.OrderDirection var87 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var85, var87, false);
    double[] var90 = org.apache.commons.math3.util.MathArrays.ebeAdd(var18, var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 11.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);

  }

  public void test305() {}
//   public void test305() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test305"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     var0.reSeed(0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var10 = var0.nextPoisson((-0.25863624275029323d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.8750783689584948d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 88.07397692031768d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.2427669905014294d);
// 
//   }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test306"); }


    int[] var0 = new int[] { };
    int[] var1 = null;
    int var2 = org.apache.commons.math3.util.MathArrays.distance1(var0, var1);
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var0);
    double var4 = var3.nextGaussian();
    var3.setSeed(477395393);
    org.apache.commons.math3.random.RandomDataGenerator var7 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var3);
    org.apache.commons.math3.random.RandomDataGenerator var8 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.2478736222527921d);

  }

  public void test307() {}
//   public void test307() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test307"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     long var10 = var0.nextPoisson(98.7281415762265d);
//     double var13 = var0.nextBeta(89.61418224548213d, 111.67623937136405d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("f", "418abcee7df04a0f3ec62876a979497d366cc2b99ca03d1c");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.4060696647213629d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 136.32890483662567d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 5.1240718077112595d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "d"+ "'", var8.equals("d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 90L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.44728827684431666d);
// 
//   }

  public void test308() {}
//   public void test308() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test308"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     var0.reSeedSecure();
//     var0.reSeed();
//     int var9 = var0.nextZipf(21, 0.044259860704679646d);
//     java.lang.String var11 = var0.nextSecureHexString(48);
//     double var14 = var0.nextF(161.03739115985056d, 1.4726118418053777d);
//     double var17 = var0.nextWeibull(0.0032241185303045258d, 162.64805588873247d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("1f4ae567cf3dd2b0bfea7eeb9214f99847cf6b48b556319f3f6b78e6948c46203b324e821c1eccf66ff867376d2252583acd", "");
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.2571793086282053d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 112.38118247138226d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "fde30fa8a1421a4541ca805483cde33c74a341ea0a902765"+ "'", var11.equals("fde30fa8a1421a4541ca805483cde33c74a341ea0a902765"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 2.245155420783283d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 7.719979451023332E-112d);
// 
//   }

  public void test309() {}
//   public void test309() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test309"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(0L);
//     java.lang.String var4 = var0.nextHexString(100);
//     java.lang.String var6 = var0.nextSecureHexString(1);
//     var0.reSeed((-1L));
//     double var10 = var0.nextExponential(0.915778680097192d);
//     var0.reSeedSecure();
//     long var14 = var0.nextLong(10L, 1024457413273955602L);
//     double var17 = var0.nextWeibull(100.0d, 1.2933613415363947d);
//     double var20 = var0.nextGamma(114.66035331336151d, 119.0147763482431d);
//     double var22 = var0.nextT(0.092975850275352d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"+ "'", var4.equals("7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "e"+ "'", var6.equals("e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.3650947445123496d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 477836925424025280L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.2756063300353422d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 13403.439260566649d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == (-1.2004153307946548d));
// 
//   }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test310"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double[] var18 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 10.0d);
    double[] var20 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var20);
    double[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 10);
    double[] var25 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var20, var25);
    double[] var29 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var29);
    double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 10);
    double var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var32);
    double var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var25);
    double[] var36 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var36);
    double[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var36, 10);
    double[] var41 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var41);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var36, var41);
    double[] var45 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var45);
    double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var45, 10);
    double var49 = org.apache.commons.math3.util.MathArrays.distanceInf(var41, var48);
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeAdd(var18, var41);
    double[] var52 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var52);
    double[] var55 = org.apache.commons.math3.util.MathArrays.copyOf(var52, 10);
    double[] var57 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var57);
    boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var52, var57);
    double[] var61 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var61);
    double[] var64 = org.apache.commons.math3.util.MathArrays.copyOf(var61, 10);
    double var65 = org.apache.commons.math3.util.MathArrays.distanceInf(var57, var64);
    org.apache.commons.math3.util.MathArrays.OrderDirection var66 = null;
    boolean var68 = org.apache.commons.math3.util.MathArrays.isMonotonic(var57, var66, true);
    double[] var70 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var70);
    double var72 = org.apache.commons.math3.util.MathArrays.distance1(var57, var70);
    double[] var74 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var74);
    double[] var77 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var77);
    double[] var80 = org.apache.commons.math3.util.MathArrays.copyOf(var77, 10);
    double var81 = org.apache.commons.math3.util.MathArrays.distanceInf(var74, var80);
    double[] var82 = org.apache.commons.math3.util.MathArrays.ebeDivide(var70, var74);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var83 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var18, var82);
    double var86 = var83.probability(0.0d, 76.50641463552304d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var88 = var83.inverseCumulativeProbability((-6.348608094701994E49d));
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 11.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 1.0d);

  }

  public void test311() {}
//   public void test311() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test311"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var8 = var0.nextUniform(0.3874438233115065d, 1.0d, true);
//     var0.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-1.4287948748133021d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 112.70692448893847d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.39950753864364064d);
// 
//   }

  public void test312() {}
//   public void test312() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test312"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     double var11 = var0.nextGamma(0.36157468479281d, 0.8376757571801716d);
//     var0.reSeed();
//     java.lang.String var14 = var0.nextHexString(16);
//     double var16 = var0.nextExponential(1.1412290133726715d);
//     var0.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-1.756773515594173d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 115.11563719948273d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.1489447025862722d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "e"+ "'", var8.equals("e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.07105509573397607d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "bfe9704c657fa188"+ "'", var14.equals("bfe9704c657fa188"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.26835828596547595d);
// 
//   }

  public void test313() {}
//   public void test313() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test313"); }
// 
// 
//     int[] var0 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var0, 100);
//     int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var0, 10);
//     int[] var7 = org.apache.commons.math3.util.MathArrays.copyOf(var0, 99);
//     org.apache.commons.math3.random.RandomDataImpl var8 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var10 = var8.nextT(110.0d);
//     double var12 = var8.nextChiSquare(110.0d);
//     double var14 = var8.nextChiSquare(0.3874438233115065d);
//     java.lang.String var16 = var8.nextSecureHexString(1);
//     double var19 = var8.nextGamma(0.36157468479281d, 0.8376757571801716d);
//     double var22 = var8.nextCauchy(0.8376757571801716d, 0.3901018313315268d);
//     org.apache.commons.math3.util.Pair var23 = new org.apache.commons.math3.util.Pair((java.lang.Object)var7, (java.lang.Object)0.8376757571801716d);
//     java.lang.Object var24 = var23.getSecond();
//     java.lang.Object var25 = var23.getValue();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-1.488974125207433d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 71.38236721617473d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 2.4540706018546807E-6d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + "6"+ "'", var16.equals("6"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.3174899839135593d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0.41506380071488036d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var24 + "' != '" + 0.8376757571801716d+ "'", var24.equals(0.8376757571801716d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var25 + "' != '" + 0.8376757571801716d+ "'", var25.equals(0.8376757571801716d));
// 
//   }

  public void test314() {}
//   public void test314() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test314"); }
// 
// 
//     int[] var0 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var0, 100);
//     int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var0, 10);
//     int[] var7 = org.apache.commons.math3.util.MathArrays.copyOf(var0, 99);
//     org.apache.commons.math3.random.RandomDataImpl var8 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var10 = var8.nextT(110.0d);
//     double var12 = var8.nextChiSquare(110.0d);
//     double var14 = var8.nextChiSquare(0.3874438233115065d);
//     java.lang.String var16 = var8.nextSecureHexString(1);
//     double var19 = var8.nextGamma(0.36157468479281d, 0.8376757571801716d);
//     double var22 = var8.nextCauchy(0.8376757571801716d, 0.3901018313315268d);
//     org.apache.commons.math3.util.Pair var23 = new org.apache.commons.math3.util.Pair((java.lang.Object)var7, (java.lang.Object)0.8376757571801716d);
//     java.lang.Object var24 = var23.getSecond();
//     java.lang.Object var25 = var23.getFirst();
//     java.lang.Object var26 = var23.getValue();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.2348143012090919d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 106.897425493078d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.008734428979380718d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + "8"+ "'", var16.equals("8"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.055648662122075476d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1.035907532881369d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var24 + "' != '" + 0.8376757571801716d+ "'", var24.equals(0.8376757571801716d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var26 + "' != '" + 0.8376757571801716d+ "'", var26.equals(0.8376757571801716d));
// 
//   }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test315"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(0.7801405628951125d, (-0.34851891419964814d), (-0.9952372506839855d), 128.35556077963213d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-128.01612916222558d));

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test316"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.09270498349096469d);

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test317"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(0L);
    double var4 = var0.nextExponential(0.7432416673360078d);
    var0.reSeedSecure();
    double var8 = var0.nextF(101.79109515357918d, 0.6116146111830432d);
    var0.reSeed(434277157163744896L);
    double var12 = var0.nextExponential(0.3842834232631038d);
    int var15 = var0.nextBinomial(11, 0.054183156649680556d);
    var0.reSeed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.36157468479281d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 7.890608942511265d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.06729966802586457d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);

  }

  public void test318() {}
//   public void test318() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test318"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)1, (java.lang.Number)1L, (java.lang.Number)(short)(-1));
//     java.lang.Number var5 = var4.getLo();
//     java.lang.Number var6 = var4.getLo();
//     java.lang.Number var7 = var4.getLo();
//     java.lang.Number var8 = var4.getHi();
//     java.lang.String var9 = var4.toString();
// 
//   }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test319"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    double[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 10);
    double[] var6 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var6);
    boolean var8 = org.apache.commons.math3.util.MathArrays.equals(var1, var6);
    double[] var10 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var10);
    double[] var13 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 10);
    double var14 = org.apache.commons.math3.util.MathArrays.distanceInf(var6, var13);
    double[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test320() {}
//   public void test320() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test320"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(0L);
//     double var4 = var0.nextExponential(0.7432416673360078d);
//     int var7 = var0.nextSecureInt(1, 100);
//     double var10 = var0.nextWeibull(10.0d, 114.23712557956448d);
//     double var13 = var0.nextCauchy(0.41852678359398926d, 1.4480256314873523d);
//     double var16 = var0.nextGaussian(111.47394446539649d, 1.2756063300353422d);
//     var0.reSeed();
//     double var19 = var0.nextT(1.4480256314873523d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.36157468479281d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 112.98997911642695d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-0.2748957434128349d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 110.74774393374405d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1.0901946810989782d);
// 
//   }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test321"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    double[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 10);
    double[] var6 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var6);
    org.apache.commons.math3.util.MathArrays.OrderDirection var8 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var6, var8, false);
    double var11 = org.apache.commons.math3.util.MathArrays.safeNorm(var6);
    double[] var13 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var13);
    double[] var16 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var16);
    double[] var19 = org.apache.commons.math3.util.MathArrays.copyOf(var16, 10);
    double var20 = org.apache.commons.math3.util.MathArrays.distanceInf(var13, var19);
    double[] var21 = org.apache.commons.math3.util.MathArrays.ebeDivide(var6, var13);
    double[] var23 = org.apache.commons.math3.util.MathArrays.normalizeArray(var6, 10.0d);
    double var24 = org.apache.commons.math3.util.MathArrays.distance(var1, var6);
    java.lang.Number var29 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var31 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.026278128681618596d, var29, 1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var32 = var31.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var34 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.087939294119887d, (java.lang.Number)0.3901018313315268d, 88, var32, false);
    boolean var37 = org.apache.commons.math3.util.MathArrays.checkOrder(var1, var32, true, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);

  }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test322"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(10, 99);
    java.lang.String var3 = var2.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "org.apache.commons.math3.exception.DimensionMismatchException: 10 != 99"+ "'", var3.equals("org.apache.commons.math3.exception.DimensionMismatchException: 10 != 99"));

  }

  public void test323() {}
//   public void test323() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test323"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(98.7281415762265d);
//     var0.reSeedSecure(120033824254318496L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.03733103526430132d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 129.10515749295936d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 98.95145056968764d);
// 
//   }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test324"); }


    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(byte)100, (java.lang.Number)82.45368975667407d, 0, var3, false);
    boolean var6 = var5.getStrict();
    int var7 = var5.getIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);

  }

  public void test325() {}
//   public void test325() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test325"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(0L);
//     java.lang.String var4 = var0.nextHexString(100);
//     java.lang.String var6 = var0.nextSecureHexString(1);
//     var0.reSeed((-1L));
//     var0.reSeed(0L);
//     double var13 = var0.nextWeibull(128.35556077963213d, 0.3874438233115065d);
//     var0.reSeed(477836925424025280L);
//     double var17 = var0.nextChiSquare(0.7801405628951125d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var20 = var0.nextInt(52084938, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"+ "'", var4.equals("7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "e"+ "'", var6.equals("e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.3883722390257413d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.5902340274924074E-5d);
// 
//   }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test326"); }


    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.4924399031470064E10d, (java.lang.Number)(-0.06187681393378908d), 1, var3, true);
    java.lang.Number var6 = var5.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 1.4924399031470064E10d+ "'", var6.equals(1.4924399031470064E10d));

  }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test327"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(75L);
    double var2 = var1.nextDouble();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.050315949583375374d);

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test328"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double[] var18 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 10.0d);
    double[] var20 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var20);
    double[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 10);
    double[] var25 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var20, var25);
    double[] var29 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var29);
    double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 10);
    double var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var32);
    double var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var25);
    double[] var36 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var36);
    double[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var36, 10);
    double[] var41 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var41);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var36, var41);
    double[] var45 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var45);
    double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var45, 10);
    double var49 = org.apache.commons.math3.util.MathArrays.distanceInf(var41, var48);
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeAdd(var18, var41);
    double[] var52 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var52);
    double[] var55 = org.apache.commons.math3.util.MathArrays.copyOf(var52, 10);
    double[] var57 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var57);
    boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var52, var57);
    double[] var61 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var61);
    double[] var64 = org.apache.commons.math3.util.MathArrays.copyOf(var61, 10);
    double var65 = org.apache.commons.math3.util.MathArrays.distanceInf(var57, var64);
    org.apache.commons.math3.util.MathArrays.OrderDirection var66 = null;
    boolean var68 = org.apache.commons.math3.util.MathArrays.isMonotonic(var57, var66, true);
    double[] var70 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var70);
    double var72 = org.apache.commons.math3.util.MathArrays.distance1(var57, var70);
    double[] var74 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var74);
    double[] var77 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var77);
    double[] var80 = org.apache.commons.math3.util.MathArrays.copyOf(var77, 10);
    double var81 = org.apache.commons.math3.util.MathArrays.distanceInf(var74, var80);
    double[] var82 = org.apache.commons.math3.util.MathArrays.ebeDivide(var70, var74);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var83 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var18, var82);
    double var85 = var83.inverseCumulativeProbability(0.0d);
    double var86 = var83.getSupportLowerBound();
    double var87 = var83.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 11.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == 10.0d);

  }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test329"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    double[] var3 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var3);
    double[] var6 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var6);
    double[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var6, 10);
    double var10 = org.apache.commons.math3.util.MathArrays.distanceInf(var3, var9);
    double[] var12 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var12);
    org.apache.commons.math3.util.MathArrays.OrderDirection var14 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var12, var14, false);
    double var17 = org.apache.commons.math3.util.MathArrays.safeNorm(var12);
    double[] var19 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var19);
    double[] var22 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var22);
    double[] var25 = org.apache.commons.math3.util.MathArrays.copyOf(var22, 10);
    double var26 = org.apache.commons.math3.util.MathArrays.distanceInf(var19, var25);
    double[] var27 = org.apache.commons.math3.util.MathArrays.ebeDivide(var12, var19);
    double[] var29 = org.apache.commons.math3.util.MathArrays.normalizeArray(var12, 10.0d);
    double[] var31 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var31);
    double[] var34 = org.apache.commons.math3.util.MathArrays.copyOf(var31, 10);
    double[] var36 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var36);
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var31, var36);
    double[] var40 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var40);
    double[] var43 = org.apache.commons.math3.util.MathArrays.copyOf(var40, 10);
    double var44 = org.apache.commons.math3.util.MathArrays.distanceInf(var36, var43);
    double var45 = org.apache.commons.math3.util.MathArrays.distanceInf(var29, var36);
    org.apache.commons.math3.util.MathArrays.OrderDirection var46 = null;
    double[] var48 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var48);
    org.apache.commons.math3.util.MathArrays.OrderDirection var50 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var48, var50, false);
    double var53 = org.apache.commons.math3.util.MathArrays.safeNorm(var48);
    double[] var55 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var55);
    double[] var58 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var58);
    double[] var61 = org.apache.commons.math3.util.MathArrays.copyOf(var58, 10);
    double var62 = org.apache.commons.math3.util.MathArrays.distanceInf(var55, var61);
    double[] var63 = org.apache.commons.math3.util.MathArrays.ebeDivide(var48, var55);
    double[] var65 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var65);
    org.apache.commons.math3.util.MathArrays.OrderDirection var67 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var65, var67, false);
    double var70 = org.apache.commons.math3.util.MathArrays.safeNorm(var65);
    org.apache.commons.math3.util.MathArrays.OrderDirection var71 = null;
    boolean var73 = org.apache.commons.math3.util.MathArrays.isMonotonic(var65, var71, false);
    double[][] var74 = new double[][] { var65};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var48, var74);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var29, var46, var74);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var3, var74);
    org.apache.commons.math3.exception.NotFiniteNumberException var78 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)134.1595546043694d, (java.lang.Object[])var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 11.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);

  }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test330"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(0L);
    double var3 = var0.nextDouble();
    var0.clear();
    double var5 = var0.nextGaussian();
    var0.setSeed(0);
    double var8 = var0.nextDouble();
    var0.clear();
    org.apache.commons.math3.random.RandomDataGenerator var10 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
    double var11 = var0.nextDouble();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.7432416673360078d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1.2016184922621251d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.9775554539871507d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.15595809931982174d);

  }

  public void test331() {}
//   public void test331() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test331"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(0L);
//     java.lang.String var4 = var0.nextHexString(100);
//     java.lang.String var6 = var0.nextSecureHexString(1);
//     double var9 = var0.nextCauchy((-0.4076885612903701d), 140.37260799449047d);
//     int var12 = var0.nextZipf(62, 134.1595546043694d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"+ "'", var4.equals("7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "b"+ "'", var6.equals("b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-132.37300774287698d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1);
// 
//   }

  public void test332() {}
//   public void test332() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test332"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var3 = var1.nextChiSquare(1.3650947445123496d);
//     long var6 = var1.nextSecureLong(85L, 100L);
//     double var9 = var1.nextBeta(0.39950753864364064d, 0.6171342864038818d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.33996229163818387d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 87L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.6560115603612449d);
// 
//   }

  public void test333() {}
//   public void test333() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test333"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     double var11 = var0.nextGamma(0.36157468479281d, 0.8376757571801716d);
//     var0.reSeed();
//     var0.reSeedSecure();
//     double var16 = var0.nextBeta(37.93403740061004d, 100.0d);
//     java.lang.String var18 = var0.nextSecureHexString(42);
//     double var21 = var0.nextF(103.8411028710254d, 12.876047870502177d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var24 = var0.nextSecureInt(47, (-1842980274));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.05811121180878338d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 112.58514160741761d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.003566010707681029d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "7"+ "'", var8.equals("7"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.3112538608640641E-5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.25091164829922535d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var18 + "' != '" + "9be04cc79eba38c15f53b86a77f5bc21aa99a14dff"+ "'", var18.equals("9be04cc79eba38c15f53b86a77f5bc21aa99a14dff"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1.9444481839407037d);
// 
//   }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test334"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(99, 0);

  }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test335"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    double[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 10);
    double[] var6 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var6);
    boolean var8 = org.apache.commons.math3.util.MathArrays.equals(var1, var6);
    double[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var6);
    org.apache.commons.math3.util.MathArrays.OrderDirection var10 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var10, true);
    double[] var14 = org.apache.commons.math3.util.MathArrays.normalizeArray(var9, (-0.14215215277913013d));
    double[] var16 = org.apache.commons.math3.util.MathArrays.normalizeArray(var9, 161.03739115985056d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test336"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double[] var18 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 10.0d);
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    double[] var21 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, (-370.6085286825806d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test337() {}
//   public void test337() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test337"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var0.nextBeta(0.0d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2.324364824433198d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 108.70987068516058d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3.0670770757559904E-5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "c"+ "'", var8.equals("c"));
// 
//   }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test338"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(0L);
    var0.clear();
    int var5 = var0.nextInt(1);
    int[] var6 = new int[] { };
    int[] var7 = null;
    int var8 = org.apache.commons.math3.util.MathArrays.distance1(var6, var7);
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(var6);
    int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var6);
    var0.setSeed(var6);
    org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(var6);
    org.apache.commons.math3.random.RandomDataGenerator var13 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test339() {}
//   public void test339() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test339"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     int var5 = var0.nextBinomial(0, 0.0d);
//     double var8 = var0.nextGaussian(108.97593914807048d, 101.79109515357918d);
//     double var11 = var0.nextCauchy(0.712841061974317d, 5.610049266766251E-8d);
//     var0.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "4cb0fb299dae838e31b321050ccde8f76f892c4c52424bd7ab4dff5778124312cea460b1df9536defec303ee69a3f3acea08"+ "'", var2.equals("4cb0fb299dae838e31b321050ccde8f76f892c4c52424bd7ab4dff5778124312cea460b1df9536defec303ee69a3f3acea08"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-107.29156971713756d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.7128410262375056d);
// 
//   }

  public void test340() {}
//   public void test340() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test340"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     double var11 = var0.nextGamma(0.36157468479281d, 0.8376757571801716d);
//     int var14 = var0.nextBinomial(1, 0.7432416673360078d);
//     double var17 = var0.nextBeta(3.3900817738101328d, 11787.308968688245d);
//     var0.reSeedSecure(90L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.4162869225705147d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 112.03929571675057d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.1033281898594947d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "4"+ "'", var8.equals("4"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.024410645546207435d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 2.5965840567196256E-4d);
// 
//   }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test341"); }


    java.lang.Comparable[] var8 = new java.lang.Comparable[] { (byte)(-1)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var9 = null;
    boolean var11 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var8, var9, true);
    org.apache.commons.math3.exception.NotFiniteNumberException var12 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)107.34245912507674d, (java.lang.Object[])var8);
    java.lang.Number var14 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var16 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.026278128681618596d, var14, 1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var17 = var16.getDirection();
    boolean var19 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var8, var17, true);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var21 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.4232227202160976d, (java.lang.Number)(-42.05705803570227d), 41, var17, false);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var23 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.28598667745231526d, (java.lang.Number)0.08764096233841684d, 35, var17, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);

  }

  public void test342() {}
//   public void test342() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test342"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     int var5 = var0.nextBinomial(10, 0.03863055888020799d);
//     int var8 = var0.nextSecureInt(7, 48);
//     long var11 = var0.nextSecureLong(0L, 95L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var0.nextPascal(10, 111.67623937136405d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.15088698056015207d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 30L);
// 
//   }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test343"); }


    float[] var0 = null;
    float[] var3 = new float[] { 100.0f, 10.0f};
    boolean var4 = org.apache.commons.math3.util.MathArrays.equals(var0, var3);
    float[] var8 = new float[] { 0.0f, (-1.0f), 0.0f};
    boolean var9 = org.apache.commons.math3.util.MathArrays.equals(var3, var8);
    float[] var11 = new float[] { 100.0f};
    float[] var12 = new float[] { };
    boolean var13 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var11, var12);
    boolean var14 = org.apache.commons.math3.util.MathArrays.equals(var3, var12);
    float[] var15 = null;
    float[] var18 = new float[] { 100.0f, 10.0f};
    boolean var19 = org.apache.commons.math3.util.MathArrays.equals(var15, var18);
    float[] var23 = new float[] { 0.0f, (-1.0f), 0.0f};
    boolean var24 = org.apache.commons.math3.util.MathArrays.equals(var18, var23);
    float[] var25 = null;
    float[] var28 = new float[] { 100.0f, 10.0f};
    boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var25, var28);
    float[] var33 = new float[] { 0.0f, (-1.0f), 0.0f};
    boolean var34 = org.apache.commons.math3.util.MathArrays.equals(var28, var33);
    boolean var35 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var23, var33);
    boolean var36 = org.apache.commons.math3.util.MathArrays.equals(var3, var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test344"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)12.876047870502177d);

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test345"); }


    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var3 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var1, (java.lang.Number)0L);
    org.apache.commons.math3.exception.OutOfRangeException var7 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(-1.0f), (java.lang.Number)100.0f, (java.lang.Number)(short)0);
    java.lang.Number var8 = var7.getLo();
    var3.addSuppressed((java.lang.Throwable)var7);
    java.lang.Throwable[] var10 = var3.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var11 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.4046619969309039E-4d, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.util.ExceptionContext var12 = var11.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 100.0f+ "'", var8.equals(100.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test346"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double[] var18 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 10.0d);
    double[] var20 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var20);
    double[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 10);
    double[] var25 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var20, var25);
    double[] var29 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var29);
    double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 10);
    double var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var32);
    double var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var25);
    double[] var36 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var36);
    double[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var36, 10);
    double[] var41 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var41);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var36, var41);
    double[] var45 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var45);
    double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var45, 10);
    double var49 = org.apache.commons.math3.util.MathArrays.distanceInf(var41, var48);
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeAdd(var18, var41);
    double[] var52 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var52);
    double[] var55 = org.apache.commons.math3.util.MathArrays.copyOf(var52, 10);
    double[] var57 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var57);
    boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var52, var57);
    double[] var61 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var61);
    double[] var64 = org.apache.commons.math3.util.MathArrays.copyOf(var61, 10);
    double var65 = org.apache.commons.math3.util.MathArrays.distanceInf(var57, var64);
    org.apache.commons.math3.util.MathArrays.OrderDirection var66 = null;
    boolean var68 = org.apache.commons.math3.util.MathArrays.isMonotonic(var57, var66, true);
    double[] var70 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var70);
    double var72 = org.apache.commons.math3.util.MathArrays.distance1(var57, var70);
    double[] var74 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var74);
    double[] var77 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var77);
    double[] var80 = org.apache.commons.math3.util.MathArrays.copyOf(var77, 10);
    double var81 = org.apache.commons.math3.util.MathArrays.distanceInf(var74, var80);
    double[] var82 = org.apache.commons.math3.util.MathArrays.ebeDivide(var70, var74);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var83 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var18, var82);
    double var85 = var83.inverseCumulativeProbability(0.0d);
    double var86 = var83.getNumericalMean();
    boolean var87 = var83.isSupportLowerBoundInclusive();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var89 = var83.inverseCumulativeProbability(0.381486780272475d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 11.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == true);

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test347"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)19, (java.lang.Number)0.03761312215253111d, 16);
    int var4 = var3.getIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 16);

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test348"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double[] var18 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 10.0d);
    double[] var20 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var20);
    double[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 10);
    double[] var25 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var20, var25);
    double[] var29 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var29);
    double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 10);
    double var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var32);
    double var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var25);
    double[] var36 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var36);
    double[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var36, 10);
    double[] var41 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var41);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var36, var41);
    double[] var45 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var45);
    double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var45, 10);
    double var49 = org.apache.commons.math3.util.MathArrays.distanceInf(var41, var48);
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeAdd(var18, var41);
    double[] var52 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var52);
    double[] var55 = org.apache.commons.math3.util.MathArrays.copyOf(var52, 10);
    double[] var57 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var57);
    boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var52, var57);
    double[] var61 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var61);
    double[] var64 = org.apache.commons.math3.util.MathArrays.copyOf(var61, 10);
    double var65 = org.apache.commons.math3.util.MathArrays.distanceInf(var57, var64);
    org.apache.commons.math3.util.MathArrays.OrderDirection var66 = null;
    boolean var68 = org.apache.commons.math3.util.MathArrays.isMonotonic(var57, var66, true);
    double[] var70 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var70);
    double var72 = org.apache.commons.math3.util.MathArrays.distance1(var57, var70);
    double[] var74 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var74);
    double[] var77 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var77);
    double[] var80 = org.apache.commons.math3.util.MathArrays.copyOf(var77, 10);
    double var81 = org.apache.commons.math3.util.MathArrays.distanceInf(var74, var80);
    double[] var82 = org.apache.commons.math3.util.MathArrays.ebeDivide(var70, var74);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var83 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var18, var82);
    double var85 = var83.inverseCumulativeProbability(0.0d);
    double var86 = var83.getNumericalMean();
    boolean var87 = var83.isSupportLowerBoundInclusive();
    double var88 = var83.getNumericalVariance();
    double var89 = var83.sample();
    double var91 = var83.density(0.004209011779647481d);
    double var93 = var83.probability((-0.06187681393378908d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 11.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var91 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == 0.0d);

  }

  public void test349() {}
//   public void test349() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test349"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var8 = var0.nextUniform(0.3874438233115065d, 1.0d, true);
//     long var10 = var0.nextPoisson(0.5230125715149944d);
//     int var13 = var0.nextInt(0, 7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.3084404959037237d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 113.11146981632d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.8608107964946557d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 5);
// 
//   }

  public void test350() {}
//   public void test350() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test350"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     double var11 = var0.nextGamma(0.36157468479281d, 0.8376757571801716d);
//     var0.reSeed();
//     var0.reSeedSecure();
//     double var16 = var0.nextCauchy(99.15680865820634d, 54.76711054963606d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var19 = var0.nextCauchy(6.363756428691805E9d, (-0.2748957434128349d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.45919419168227993d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 110.29672802379646d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.4051664507088996E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "f"+ "'", var8.equals("f"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.10833547274989205d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 142.7870319298689d);
// 
//   }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test351"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 19, 36);
    int var4 = var3.getDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 36);

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test352"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double[] var18 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 10.0d);
    double[] var20 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var20);
    double[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 10);
    double[] var25 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var20, var25);
    double[] var29 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var29);
    double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 10);
    double var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var32);
    double var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var25);
    double[] var36 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var36);
    double[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var36, 10);
    double[] var41 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var41);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var36, var41);
    double[] var45 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var45);
    double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var45, 10);
    double var49 = org.apache.commons.math3.util.MathArrays.distanceInf(var41, var48);
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeAdd(var18, var41);
    double[] var52 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var52);
    double[] var55 = org.apache.commons.math3.util.MathArrays.copyOf(var52, 10);
    double[] var57 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var57);
    boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var52, var57);
    double[] var61 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var61);
    double[] var64 = org.apache.commons.math3.util.MathArrays.copyOf(var61, 10);
    double var65 = org.apache.commons.math3.util.MathArrays.distanceInf(var57, var64);
    org.apache.commons.math3.util.MathArrays.OrderDirection var66 = null;
    boolean var68 = org.apache.commons.math3.util.MathArrays.isMonotonic(var57, var66, true);
    double[] var70 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var70);
    double var72 = org.apache.commons.math3.util.MathArrays.distance1(var57, var70);
    double[] var74 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var74);
    double[] var77 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var77);
    double[] var80 = org.apache.commons.math3.util.MathArrays.copyOf(var77, 10);
    double var81 = org.apache.commons.math3.util.MathArrays.distanceInf(var74, var80);
    double[] var82 = org.apache.commons.math3.util.MathArrays.ebeDivide(var70, var74);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var83 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var18, var82);
    double var85 = var83.inverseCumulativeProbability(0.0d);
    double var86 = var83.getNumericalMean();
    double var87 = var83.getNumericalVariance();
    boolean var88 = var83.isSupportUpperBoundInclusive();
    boolean var89 = var83.isSupportLowerBoundInclusive();
    double[] var91 = var83.sample(8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 11.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test353"); }


    org.apache.commons.math3.exception.util.Localizable var1 = null;
    long[] var2 = new long[] { };
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var2);
    long[][] var4 = new long[][] { var2};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var4);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var4);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var4);
    org.apache.commons.math3.exception.MathIllegalArgumentException var8 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, (java.lang.Object[])var4);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var4);
    org.apache.commons.math3.exception.NotFiniteNumberException var10 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)0.6062775910181382d, (java.lang.Object[])var4);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test354() {}
//   public void test354() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test354"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     double var5 = var0.nextWeibull(110.0d, 0.3874438233115065d);
//     var0.reSeedSecure();
//     var0.reSeedSecure(95L);
//     double var10 = var0.nextExponential(134.1595546043694d);
//     double var13 = var0.nextCauchy(0.17846182358222898d, 0.15236687205232924d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "27be99475fff3d1bf27b796868adcfe622e00e7d8b8082a2c53e0e14199bfd8b0237a80e2815281fcc6b1fb8749d12ef0c53"+ "'", var2.equals("27be99475fff3d1bf27b796868adcfe622e00e7d8b8082a2c53e0e14199bfd8b0237a80e2815281fcc6b1fb8749d12ef0c53"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.3768062016343582d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 265.2968556350029d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.09794766209667058d);
// 
//   }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test355"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.lang.Object[] var4 = new java.lang.Object[] { (-1L)};
    org.apache.commons.math3.exception.MathIllegalArgumentException var5 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, var4);
    org.apache.commons.math3.exception.NotFiniteNumberException var6 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)10L, var4);
    org.apache.commons.math3.exception.util.ExceptionContext var7 = var6.getContext();
    java.lang.Number var8 = var6.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 10L+ "'", var8.equals(10L));

  }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test356"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)(-0.14215215277913013d));

  }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test357"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double[] var18 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 10.0d);
    double[] var20 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var20);
    double[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 10);
    double[] var25 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var20, var25);
    double[] var29 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var29);
    double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 10);
    double var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var32);
    double var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var25);
    double[] var36 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var36);
    double[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var36, 10);
    double[] var41 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var41);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var36, var41);
    double[] var45 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var45);
    double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var45, 10);
    double var49 = org.apache.commons.math3.util.MathArrays.distanceInf(var41, var48);
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeAdd(var18, var41);
    double[] var52 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var52);
    double[] var55 = org.apache.commons.math3.util.MathArrays.copyOf(var52, 10);
    double[] var57 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var57);
    boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var52, var57);
    double[] var61 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var61);
    double[] var64 = org.apache.commons.math3.util.MathArrays.copyOf(var61, 10);
    double var65 = org.apache.commons.math3.util.MathArrays.distanceInf(var57, var64);
    org.apache.commons.math3.util.MathArrays.OrderDirection var66 = null;
    boolean var68 = org.apache.commons.math3.util.MathArrays.isMonotonic(var57, var66, true);
    double[] var70 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var70);
    double var72 = org.apache.commons.math3.util.MathArrays.distance1(var57, var70);
    double[] var74 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var74);
    double[] var77 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var77);
    double[] var80 = org.apache.commons.math3.util.MathArrays.copyOf(var77, 10);
    double var81 = org.apache.commons.math3.util.MathArrays.distanceInf(var74, var80);
    double[] var82 = org.apache.commons.math3.util.MathArrays.ebeDivide(var70, var74);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var83 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var18, var82);
    double var85 = var83.inverseCumulativeProbability(0.0d);
    double var86 = var83.getNumericalMean();
    double var87 = var83.getSupportUpperBound();
    boolean var88 = var83.isSupportLowerBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 11.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == true);

  }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test358"); }


    int[] var0 = new int[] { };
    int[] var1 = null;
    int var2 = org.apache.commons.math3.util.MathArrays.distance1(var0, var1);
    int[] var3 = new int[] { };
    int[] var4 = null;
    int var5 = org.apache.commons.math3.util.MathArrays.distance1(var3, var4);
    org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c(var3);
    int[] var7 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var0, var3);
    int[] var9 = new int[] { };
    org.apache.commons.math3.random.Well19937c var10 = new org.apache.commons.math3.random.Well19937c(var9);
    int[] var11 = new int[] { };
    org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(var11);
    int[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 100);
    int var15 = org.apache.commons.math3.util.MathArrays.distance1(var9, var11);
    int[] var16 = new int[] { };
    org.apache.commons.math3.random.Well19937c var17 = new org.apache.commons.math3.random.Well19937c(var16);
    int var18 = org.apache.commons.math3.util.MathArrays.distanceInf(var11, var16);
    org.apache.commons.math3.random.Well19937c var19 = new org.apache.commons.math3.random.Well19937c(var11);
    double var20 = org.apache.commons.math3.util.MathArrays.distance(var3, var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);

  }

  public void test359() {}
//   public void test359() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test359"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     double var5 = var0.nextWeibull(110.0d, 0.3874438233115065d);
//     var0.reSeedSecure();
//     double var9 = var0.nextUniform((-0.4563799204122316d), 107.34245912507674d);
//     double var11 = var0.nextChiSquare(0.38303844979384266d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "f90a371d848e830417b23e93f9e6c137bcc51f2afc5f80972a2612c02a9cddf56ac4195dfebe9bf97236fd9d4cc9985a62dd"+ "'", var2.equals("f90a371d848e830417b23e93f9e6c137bcc51f2afc5f80972a2612c02a9cddf56ac4195dfebe9bf97236fd9d4cc9985a62dd"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.3807189594131344d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 102.28891218536575d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.5652046946948013d);
// 
//   }

  public void test360() {}
//   public void test360() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test360"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     double var5 = var0.nextWeibull(110.0d, 0.3874438233115065d);
//     int var8 = var0.nextBinomial(1, 0.39257004669847934d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "3a5effb4d3b28447a435b95acb3455188ba44b79c081b494af740f86c80196f604ca9201c2b11a2263b06735c150db186450"+ "'", var2.equals("3a5effb4d3b28447a435b95acb3455188ba44b79c081b494af740f86c80196f604ca9201c2b11a2263b06735c150db186450"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.3882569683252684d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
// 
//   }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test361"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double[] var18 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 10.0d);
    double[] var20 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var20);
    double[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 10);
    double[] var24 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var20);
    double[] var26 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var26);
    org.apache.commons.math3.util.MathArrays.OrderDirection var28 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var26, var28, false);
    double var31 = org.apache.commons.math3.util.MathArrays.safeNorm(var26);
    double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var26);
    java.lang.Number var34 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var36 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.026278128681618596d, var34, 1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var37 = var36.getDirection();
    double[] var39 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var39);
    org.apache.commons.math3.util.MathArrays.OrderDirection var41 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var39, var41, false);
    double var44 = org.apache.commons.math3.util.MathArrays.safeNorm(var39);
    double[] var46 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var46);
    double[] var49 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var49);
    double[] var52 = org.apache.commons.math3.util.MathArrays.copyOf(var49, 10);
    double var53 = org.apache.commons.math3.util.MathArrays.distanceInf(var46, var52);
    double[] var54 = org.apache.commons.math3.util.MathArrays.ebeDivide(var39, var46);
    double[] var56 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var56);
    org.apache.commons.math3.util.MathArrays.OrderDirection var58 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var56, var58, false);
    double var61 = org.apache.commons.math3.util.MathArrays.safeNorm(var56);
    double[] var63 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var63);
    double[] var66 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var66);
    double[] var69 = org.apache.commons.math3.util.MathArrays.copyOf(var66, 10);
    double var70 = org.apache.commons.math3.util.MathArrays.distanceInf(var63, var69);
    double[] var71 = org.apache.commons.math3.util.MathArrays.ebeDivide(var56, var63);
    double[] var73 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var73);
    org.apache.commons.math3.util.MathArrays.OrderDirection var75 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var73, var75, false);
    double var78 = org.apache.commons.math3.util.MathArrays.safeNorm(var73);
    org.apache.commons.math3.util.MathArrays.OrderDirection var79 = null;
    boolean var81 = org.apache.commons.math3.util.MathArrays.isMonotonic(var73, var79, false);
    double[][] var82 = new double[][] { var73};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var56, var82);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var54, var82);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var32, var37, var82);
    boolean var88 = org.apache.commons.math3.util.MathArrays.checkOrder(var20, var37, true, true);
    org.apache.commons.math3.util.MathArrays.checkOrder(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == true);

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test362"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var1 = null;
    org.apache.commons.math3.exception.MathIllegalStateException var2 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var1);
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var2.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test363"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0490478826880714d, (java.lang.Number)0.7534276667534705d, 93581048);

  }

  public void test364() {}
//   public void test364() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test364"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     double var11 = var0.nextGamma(0.36157468479281d, 0.8376757571801716d);
//     int var14 = var0.nextBinomial(1, 0.7432416673360078d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var17 = var0.nextF(0.0d, 1.2756063300353422d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.14218764530958297d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 107.78575331043311d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.5833136155832144d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "5"+ "'", var8.equals("5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.08640022756387927d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1);
// 
//   }

  public void test365() {}
//   public void test365() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test365"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     double var11 = var0.nextBeta(106.19070066324907d, 14386.159160118537d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var14 = var0.nextPermutation((-1347491339), 48);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.21923765326358957d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 108.78268563386071d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.2936176638403138d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "d"+ "'", var8.equals("d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.007406919451561091d);
// 
//   }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test366"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(0L);
    double var3 = var0.nextDouble();
    var0.clear();
    double var5 = var0.nextGaussian();
    boolean var6 = var0.nextBoolean();
    double var7 = var0.nextDouble();
    var0.setSeed(100);
    var0.setSeed(0);
    var0.clear();
    double var13 = var0.nextGaussian();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.7432416673360078d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1.2016184922621251d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.3874438233115065d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1.908642352606886d);

  }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test367"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double[] var18 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var18);
    org.apache.commons.math3.util.MathArrays.OrderDirection var20 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var18, var20, false);
    double var23 = org.apache.commons.math3.util.MathArrays.safeNorm(var18);
    double[] var25 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    double[] var28 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var28);
    double[] var31 = org.apache.commons.math3.util.MathArrays.copyOf(var28, 10);
    double var32 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var31);
    double[] var33 = org.apache.commons.math3.util.MathArrays.ebeDivide(var18, var25);
    double[] var35 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var35);
    org.apache.commons.math3.util.MathArrays.OrderDirection var37 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var35, var37, false);
    double var40 = org.apache.commons.math3.util.MathArrays.safeNorm(var35);
    org.apache.commons.math3.util.MathArrays.OrderDirection var41 = null;
    boolean var43 = org.apache.commons.math3.util.MathArrays.isMonotonic(var35, var41, false);
    double[][] var44 = new double[][] { var35};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var18, var44);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var16, var44);
    double[] var48 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var48);
    org.apache.commons.math3.util.MathArrays.OrderDirection var50 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var48, var50, false);
    double var53 = org.apache.commons.math3.util.MathArrays.safeNorm(var48);
    double[] var55 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var55);
    double[] var58 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var58);
    double[] var61 = org.apache.commons.math3.util.MathArrays.copyOf(var58, 10);
    double var62 = org.apache.commons.math3.util.MathArrays.distanceInf(var55, var61);
    double[] var63 = org.apache.commons.math3.util.MathArrays.ebeDivide(var48, var55);
    double[] var65 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var65);
    org.apache.commons.math3.util.MathArrays.OrderDirection var67 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var65, var67, false);
    double var70 = org.apache.commons.math3.util.MathArrays.safeNorm(var65);
    double[] var72 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var72);
    double[] var75 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var75);
    double[] var78 = org.apache.commons.math3.util.MathArrays.copyOf(var75, 10);
    double var79 = org.apache.commons.math3.util.MathArrays.distanceInf(var72, var78);
    double[] var80 = org.apache.commons.math3.util.MathArrays.ebeDivide(var65, var72);
    org.apache.commons.math3.util.MathArrays.OrderDirection var81 = null;
    boolean var83 = org.apache.commons.math3.util.MathArrays.isMonotonic(var65, var81, true);
    double[] var84 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var55, var65);
    double var85 = org.apache.commons.math3.util.MathArrays.distance(var16, var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 2.0d);

  }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test368"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(0L);
    double var3 = var0.nextDouble();
    var0.clear();
    double var5 = var0.nextGaussian();
    boolean var6 = var0.nextBoolean();
    int[] var7 = new int[] { };
    int[] var8 = null;
    int var9 = org.apache.commons.math3.util.MathArrays.distance1(var7, var8);
    org.apache.commons.math3.random.Well19937c var10 = new org.apache.commons.math3.random.Well19937c(var7);
    int[] var11 = org.apache.commons.math3.util.MathArrays.copyOf(var7);
    var0.setSeed(var11);
    int var14 = var0.nextInt(42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.7432416673360078d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1.2016184922621251d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 29);

  }

  public void test369() {}
//   public void test369() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test369"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(0L);
//     java.lang.String var4 = var0.nextHexString(100);
//     java.lang.String var6 = var0.nextSecureHexString(1);
//     var0.reSeed((-1L));
//     var0.reSeed(0L);
//     double var13 = var0.nextWeibull(128.35556077963213d, 0.3874438233115065d);
//     var0.reSeed(477836925424025280L);
//     double var18 = var0.nextCauchy(114.66035331336151d, 0.39272166588919205d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var21 = var0.nextSecureLong(75L, 22L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"+ "'", var4.equals("7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "4"+ "'", var6.equals("4"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.3883722390257413d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 103.83915948132459d);
// 
//   }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test370"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(0L);
    double var3 = var0.nextDouble();
    var0.clear();
    double var5 = var0.nextGaussian();
    boolean var6 = var0.nextBoolean();
    double var7 = var0.nextDouble();
    org.apache.commons.math3.random.RandomDataImpl var8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var11 = var8.nextLong(74L, 22L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.7432416673360078d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1.2016184922621251d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.3874438233115065d);

  }

  public void test371() {}
//   public void test371() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test371"); }
// 
// 
//     int[] var0 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var0, 100);
//     int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var0, 10);
//     int[] var7 = org.apache.commons.math3.util.MathArrays.copyOf(var0, 99);
//     org.apache.commons.math3.random.RandomDataImpl var8 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var10 = var8.nextT(110.0d);
//     double var12 = var8.nextChiSquare(110.0d);
//     double var14 = var8.nextChiSquare(0.3874438233115065d);
//     java.lang.String var16 = var8.nextSecureHexString(1);
//     double var19 = var8.nextGamma(0.36157468479281d, 0.8376757571801716d);
//     double var22 = var8.nextCauchy(0.8376757571801716d, 0.3901018313315268d);
//     org.apache.commons.math3.util.Pair var23 = new org.apache.commons.math3.util.Pair((java.lang.Object)var7, (java.lang.Object)0.8376757571801716d);
//     int[] var25 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 30);
//     int[] var26 = new int[] { };
//     int[] var27 = null;
//     int var28 = org.apache.commons.math3.util.MathArrays.distance1(var26, var27);
//     org.apache.commons.math3.random.Well19937c var29 = new org.apache.commons.math3.random.Well19937c();
//     var29.setSeed(0L);
//     double var32 = var29.nextDouble();
//     int[] var36 = new int[] { 1, 10, 100};
//     var29.setSeed(var36);
//     int var38 = org.apache.commons.math3.util.MathArrays.distance1(var26, var36);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var39 = org.apache.commons.math3.util.MathArrays.distance1(var25, var26);
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5020895172609998d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 99.47598265747807d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.011557757393257349d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + "f"+ "'", var16.equals("f"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.10054977667908985d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == (-0.11485938028686071d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 0.7432416673360078d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 0);
// 
//   }

  public void test372() {}
//   public void test372() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test372"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)100);
//     org.apache.commons.math3.exception.util.Localizable var3 = null;
//     org.apache.commons.math3.exception.util.Localizable var4 = null;
//     java.lang.Object[] var7 = new java.lang.Object[] { 'a'};
//     org.apache.commons.math3.exception.NotFiniteNumberException var8 = new org.apache.commons.math3.exception.NotFiniteNumberException(var4, (java.lang.Number)(short)0, var7);
//     org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var2, var3, var7);
// 
//   }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test373"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double[] var18 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 10.0d);
    double[] var20 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var20);
    double[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 10);
    double[] var25 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var20, var25);
    double[] var29 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var29);
    double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 10);
    double var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var32);
    double var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var25);
    double[] var36 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var36);
    double[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var36, 10);
    double[] var41 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var41);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var36, var41);
    double[] var45 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var45);
    double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var45, 10);
    double var49 = org.apache.commons.math3.util.MathArrays.distanceInf(var41, var48);
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeAdd(var18, var41);
    double[] var52 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var52);
    double[] var55 = org.apache.commons.math3.util.MathArrays.copyOf(var52, 10);
    double[] var57 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var57);
    boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var52, var57);
    double[] var61 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var61);
    double[] var64 = org.apache.commons.math3.util.MathArrays.copyOf(var61, 10);
    double var65 = org.apache.commons.math3.util.MathArrays.distanceInf(var57, var64);
    org.apache.commons.math3.util.MathArrays.OrderDirection var66 = null;
    boolean var68 = org.apache.commons.math3.util.MathArrays.isMonotonic(var57, var66, true);
    double[] var70 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var70);
    double var72 = org.apache.commons.math3.util.MathArrays.distance1(var57, var70);
    double[] var74 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var74);
    double[] var77 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var77);
    double[] var80 = org.apache.commons.math3.util.MathArrays.copyOf(var77, 10);
    double var81 = org.apache.commons.math3.util.MathArrays.distanceInf(var74, var80);
    double[] var82 = org.apache.commons.math3.util.MathArrays.ebeDivide(var70, var74);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var83 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var18, var82);
    double var85 = var83.inverseCumulativeProbability(0.0d);
    double var87 = var83.probability(98.41337207493586d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var89 = var83.inverseCumulativeProbability(114.81244598869324d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 11.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == 0.0d);

  }

  public void test374() {}
//   public void test374() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test374"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(0L);
//     java.lang.String var4 = var0.nextHexString(100);
//     java.lang.String var6 = var0.nextSecureHexString(1);
//     var0.reSeed((-1L));
//     int var11 = var0.nextZipf(1, 2.1070663248503236d);
//     long var14 = var0.nextSecureLong(74L, 83L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"+ "'", var4.equals("7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "5"+ "'", var6.equals("5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 77L);
// 
//   }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test375"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(1.305475194865426d, (-1.0572941331941332d), 0.0d, 0.04531149230262111d, 117.9736690792914d, 0.014771889457054958d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.3624227339207924d);

  }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test376"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Comparable[] var3 = new java.lang.Comparable[] { (byte)(-1)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var4 = null;
    boolean var6 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var3, var4, true);
    org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError(var1, (java.lang.Object[])var3);
    org.apache.commons.math3.exception.MathIllegalStateException var8 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test377"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double[] var18 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 10.0d);
    double[] var20 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var20);
    double[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 10);
    double[] var25 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var20, var25);
    double[] var29 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var29);
    double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 10);
    double var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var32);
    double var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var25);
    double[] var36 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var36);
    double[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var36, 10);
    double[] var41 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var41);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var36, var41);
    double[] var45 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var45);
    double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var45, 10);
    double var49 = org.apache.commons.math3.util.MathArrays.distanceInf(var41, var48);
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeAdd(var18, var41);
    double[] var52 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var52);
    double[] var55 = org.apache.commons.math3.util.MathArrays.copyOf(var52, 10);
    double[] var57 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var57);
    boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var52, var57);
    double[] var61 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var61);
    double[] var64 = org.apache.commons.math3.util.MathArrays.copyOf(var61, 10);
    double var65 = org.apache.commons.math3.util.MathArrays.distanceInf(var57, var64);
    org.apache.commons.math3.util.MathArrays.OrderDirection var66 = null;
    boolean var68 = org.apache.commons.math3.util.MathArrays.isMonotonic(var57, var66, true);
    double[] var70 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var70);
    double var72 = org.apache.commons.math3.util.MathArrays.distance1(var57, var70);
    double[] var74 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var74);
    double[] var77 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var77);
    double[] var80 = org.apache.commons.math3.util.MathArrays.copyOf(var77, 10);
    double var81 = org.apache.commons.math3.util.MathArrays.distanceInf(var74, var80);
    double[] var82 = org.apache.commons.math3.util.MathArrays.ebeDivide(var70, var74);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var83 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var18, var82);
    double var85 = var83.inverseCumulativeProbability(0.0d);
    double var86 = var83.getNumericalMean();
    boolean var87 = var83.isSupportLowerBoundInclusive();
    double var89 = var83.probability(0.9886699244594495d);
    double[] var91 = var83.sample(39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 11.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);

  }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test378"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var3 = new java.lang.Object[] { 'a'};
    org.apache.commons.math3.exception.NotFiniteNumberException var4 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)(short)0, var3);
    double[] var6 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var6);
    org.apache.commons.math3.util.MathArrays.OrderDirection var8 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var6, var8, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var6);
    org.apache.commons.math3.util.Pair var12 = new org.apache.commons.math3.util.Pair((java.lang.Object)(short)0, (java.lang.Object)var6);
    java.lang.Object var13 = var12.getValue();
    org.apache.commons.math3.util.Pair var14 = new org.apache.commons.math3.util.Pair(var12);
    java.lang.Object var15 = var14.getKey();
    java.lang.Object var16 = null;
    boolean var17 = var14.equals(var16);
    java.lang.Object var18 = var14.getSecond();
    java.lang.Object var19 = var14.getFirst();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + (short)0+ "'", var15.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + (short)0+ "'", var19.equals((short)0));

  }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test379"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)107.15931048659918d, (java.lang.Number)98.41337207493586d, true);

  }

  public void test380() {}
//   public void test380() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test380"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     var0.reSeedSecure();
//     int var8 = var0.nextSecureInt((-1), 1);
//     java.lang.String var10 = var0.nextHexString(5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.8894803052843523d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 120.41322467215485d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "a5ddb"+ "'", var10.equals("a5ddb"));
// 
//   }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test381"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException((-1), (-1));
    int var3 = var2.getDimension();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var7 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0d, (java.lang.Number)(byte)(-1), 1);
    boolean var8 = var7.getStrict();
    java.lang.String var9 = var7.toString();
    var2.addSuppressed((java.lang.Throwable)var7);
    org.apache.commons.math3.exception.MathInternalError var11 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var2);
    org.apache.commons.math3.exception.util.ExceptionContext var12 = var11.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "org.apache.commons.math3.exception.NonMonotonicSequenceException: points 0 and 1 are not strictly increasing (-1 >= 1)"+ "'", var9.equals("org.apache.commons.math3.exception.NonMonotonicSequenceException: points 0 and 1 are not strictly increasing (-1 >= 1)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test382() {}
//   public void test382() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test382"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(0L);
//     long var5 = var0.nextSecureLong(10L, 100L);
//     double var7 = var0.nextT(119.7441447260784d);
//     double var11 = var0.nextUniform(0.092975850275352d, 0.3864176294443096d, false);
//     var0.reSeedSecure(95L);
//     double var15 = var0.nextChiSquare(112.03929571675057d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 99L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.6553232415694416d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.2666395291136514d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 106.02799773760728d);
// 
//   }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test383"); }


    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)100, (java.lang.Number)10.0d, 0, var3, false);
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = var5.getDirection();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test384() {}
//   public void test384() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test384"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(0L);
//     double var4 = var0.nextExponential(0.7432416673360078d);
//     int var7 = var0.nextSecureInt(1, 100);
//     double var10 = var0.nextWeibull(10.0d, 114.23712557956448d);
//     int[] var13 = var0.nextPermutation(39, 36);
//     var0.reSeed(0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("efe9507f30546c28", "d7b9391c331a0f307f583f2ead5f1e4633d1e954d6de524b310fd6624344f042fe68261b7310759b943d6f7c82d412b9f0fe");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.36157468479281d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 91);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 112.98997911642695d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
// 
//   }

  public void test385() {}
//   public void test385() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test385"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(0L);
//     java.lang.String var4 = var0.nextHexString(100);
//     java.lang.String var6 = var0.nextSecureHexString(1);
//     var0.reSeed((-1L));
//     var0.reSeed(0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var0.nextSecureInt(41, 7);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"+ "'", var4.equals("7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "5"+ "'", var6.equals("5"));
// 
//   }

  public void test386() {}
//   public void test386() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test386"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     int var5 = var0.nextBinomial(10, 0.03863055888020799d);
//     int var8 = var0.nextSecureInt(7, 48);
//     long var11 = var0.nextSecureLong(0L, 95L);
//     double var14 = var0.nextGamma(110.0d, 1.0072979096734078d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var17 = var0.nextUniform(14386.159160118537d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.041374466753503d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 13L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 114.38552117777155d);
// 
//   }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test387"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Object[] var6 = new java.lang.Object[] { 'a'};
    org.apache.commons.math3.exception.NotFiniteNumberException var7 = new org.apache.commons.math3.exception.NotFiniteNumberException(var3, (java.lang.Number)(short)0, var6);
    org.apache.commons.math3.exception.NotFiniteNumberException var8 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Number)10L, var6);
    org.apache.commons.math3.exception.NotFiniteNumberException var9 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test388() {}
//   public void test388() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test388"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(0L);
//     java.lang.String var4 = var0.nextHexString(100);
//     java.lang.String var6 = var0.nextSecureHexString(1);
//     var0.reSeed((-1L));
//     int var11 = var0.nextZipf(1, 2.1070663248503236d);
//     int var14 = var0.nextPascal(60481539, 0.014771889457054958d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var18 = var0.nextUniform(0.9886699244594495d, 0.421049182685337d, true);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"+ "'", var4.equals("7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "9"+ "'", var6.equals("9"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 2147483647);
// 
//   }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test389"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(69, 33);

  }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test390"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double[] var18 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 10.0d);
    double[] var20 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var20);
    double[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 10);
    double[] var25 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var20, var25);
    double[] var29 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var29);
    double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 10);
    double var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var32);
    double var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var25);
    double[] var36 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var36);
    org.apache.commons.math3.util.MathArrays.OrderDirection var38 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var36, var38, false);
    double var41 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var36);
    double[] var43 = org.apache.commons.math3.util.MathArrays.normalizeArray(var36, 98.30741799725186d);
    org.apache.commons.math3.util.MathArrays.checkOrder(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 11.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);

  }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test391"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(7.67089341016808d, (-1.0572941331941332d), (-0.03733103526430132d), 0.21016255501601377d, 0.0d, 0.00940319128424221d, (-0.043481143175376734d), 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-8.118236184680788d));

  }

  public void test392() {}
//   public void test392() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test392"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     double var11 = var0.nextGamma(0.36157468479281d, 0.8376757571801716d);
//     var0.reSeed();
//     var0.reSeedSecure();
//     double var16 = var0.nextBeta(37.93403740061004d, 100.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var19 = var0.nextZipf(0, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.5821417899138095d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 102.06030828288476d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.0010900087445098385d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "e"+ "'", var8.equals("e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.2946956782657743d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.3360795441956606d);
// 
//   }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test393"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(0.0d, 0.0d, (-463.4955697271597d), 0.0d, 0.0d, 0.3535063099037627d, 0.0653811700462978d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);

  }

  public void test394() {}
//   public void test394() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test394"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(0L);
//     java.lang.String var4 = var0.nextHexString(100);
//     java.lang.String var6 = var0.nextSecureHexString(1);
//     var0.reSeed((-1L));
//     double var10 = var0.nextExponential(0.915778680097192d);
//     var0.reSeedSecure();
//     int var14 = var0.nextSecureInt(0, 5);
//     double var17 = var0.nextGamma(27.366395926482813d, 4.4126399167425654E-7d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"+ "'", var4.equals("7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "4"+ "'", var6.equals("4"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.3650947445123496d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 8.44432061308899E-6d);
// 
//   }

  public void test395() {}
//   public void test395() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test395"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(7, 312574995);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var6 = var0.nextBeta(0.0d, (-0.4578282015693922d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 172849536);
// 
//   }

  public void test396() {}
//   public void test396() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test396"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var8 = var0.nextUniform(0.3874438233115065d, 1.0d, true);
//     int var11 = var0.nextBinomial(3, 0.7417131086235617d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2.0833368439831124d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 120.10081243678735d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.962843520946781d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 3);
// 
//   }

  public void test397() {}
//   public void test397() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test397"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(0L);
//     double var4 = var0.nextExponential(0.7432416673360078d);
//     int var7 = var0.nextSecureInt(1, 100);
//     java.lang.String var9 = var0.nextHexString(7);
//     double var11 = var0.nextExponential(0.5230125715149944d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.36157468479281d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 89);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "67c8011"+ "'", var9.equals("67c8011"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.5881340520635757d);
// 
//   }

  public void test398() {}
//   public void test398() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test398"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-2.422255593706966d), (java.lang.Number)101.44314796560174d, true);
//     java.lang.String var5 = var4.toString();
// 
//   }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test399"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    java.lang.Object[] var9 = new java.lang.Object[] { 'a'};
    org.apache.commons.math3.exception.NotFiniteNumberException var10 = new org.apache.commons.math3.exception.NotFiniteNumberException(var6, (java.lang.Number)(short)0, var9);
    org.apache.commons.math3.exception.NotFiniteNumberException var11 = new org.apache.commons.math3.exception.NotFiniteNumberException(var4, (java.lang.Number)10L, var9);
    org.apache.commons.math3.exception.NotFiniteNumberException var12 = new org.apache.commons.math3.exception.NotFiniteNumberException(var2, (java.lang.Number)114.23712557956448d, var9);
    org.apache.commons.math3.exception.MathArithmeticException var13 = new org.apache.commons.math3.exception.MathArithmeticException(var1, var9);
    org.apache.commons.math3.exception.NullArgumentException var14 = new org.apache.commons.math3.exception.NullArgumentException(var0, var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test400"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(93581048);
    var1.setSeed(69L);

  }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test401"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(0L);
    double var3 = var0.nextDouble();
    var0.clear();
    double var5 = var0.nextGaussian();
    boolean var6 = var0.nextBoolean();
    double var7 = var0.nextDouble();
    org.apache.commons.math3.random.RandomDataImpl var8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    long var10 = var8.nextPoisson(0.014210808548593164d);
    int var14 = var8.nextHypergeometric(161574481, 10, 44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.7432416673360078d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1.2016184922621251d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.3874438233115065d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);

  }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test402"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)1.9081813459147294E-5d, (java.lang.Number)101.29456331084373d, (java.lang.Number)105.66998161762055d);

  }

  public void test403() {}
//   public void test403() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test403"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     int var5 = var0.nextBinomial(10, 0.03863055888020799d);
//     int var8 = var0.nextSecureInt(7, 48);
//     double var12 = var0.nextUniform(0.0d, 0.7140368591421311d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var0.nextBinomial(43, (-1.2705406793464897d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.4797580320440352d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5248299108514911d);
// 
//   }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test404"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(1, (-2087310710));

  }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test405"); }


    java.lang.Number var7 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var9 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.026278128681618596d, var7, 1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var10 = var9.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var12 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.087939294119887d, (java.lang.Number)0.3901018313315268d, 88, var10, false);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var14 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)6L, (java.lang.Number)(-1.4285747415102923d), (-1), var10, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test406"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(378.32817290051395d, (-6.348608094701994E49d), 0.36157468479281d, 0.381486780272475d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-2.4018573009300185E52d));

  }

  public void test407() {}
//   public void test407() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test407"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     long[] var1 = new long[] { };
//     org.apache.commons.math3.util.MathArrays.checkNonNegative(var1);
//     long[][] var3 = new long[][] { var1};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var3);
//     org.apache.commons.math3.util.MathArrays.checkNonNegative(var3);
//     org.apache.commons.math3.util.MathArrays.checkNonNegative(var3);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var7 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var3);
//     org.apache.commons.math3.exception.util.Localizable var8 = null;
//     org.apache.commons.math3.exception.util.Localizable var9 = null;
//     long[] var11 = new long[] { };
//     org.apache.commons.math3.util.MathArrays.checkNonNegative(var11);
//     long[][] var13 = new long[][] { var11};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var13);
//     org.apache.commons.math3.util.MathArrays.checkNonNegative(var13);
//     org.apache.commons.math3.util.MathArrays.checkNonNegative(var13);
//     org.apache.commons.math3.exception.NotFiniteNumberException var17 = new org.apache.commons.math3.exception.NotFiniteNumberException(var9, (java.lang.Number)100.0d, (java.lang.Object[])var13);
//     org.apache.commons.math3.util.MathArrays.checkNonNegative(var13);
//     org.apache.commons.math3.exception.MathIllegalStateException var19 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var7, var8, (java.lang.Object[])var13);
// 
//   }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test408"); }


    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1.1917327900748924d), (java.lang.Number)4.149496931236865d, 312574995, var3, false);
    boolean var6 = var5.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = var5.getDirection();
    java.lang.Number var9 = null;
    org.apache.commons.math3.util.MathArrays.OrderDirection var11 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var13 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0f, var9, 10, var11, true);
    var5.addSuppressed((java.lang.Throwable)var13);
    int var15 = var13.getIndex();
    java.lang.Throwable[] var16 = var13.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test409() {}
//   public void test409() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test409"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     var0.reSeed();
//     long var11 = var0.nextPoisson(0.4517190132114119d);
//     var0.reSeedSecure((-1L));
//     java.lang.String var15 = var0.nextSecureHexString(44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.7753366506945935d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 144.0831764524669d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 5.089865057755394E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "1"+ "'", var8.equals("1"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "1b450581b6f09efa23a1fb83de27bc73f225b217079d"+ "'", var15.equals("1b450581b6f09efa23a1fb83de27bc73f225b217079d"));
// 
//   }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test410"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    int[] var2 = new int[] { };
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var2);
    int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var2, 100);
    int var6 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    int[] var7 = new int[] { };
    org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(var7);
    int var9 = org.apache.commons.math3.util.MathArrays.distanceInf(var2, var7);
    int[] var10 = new int[] { };
    int[] var11 = null;
    int var12 = org.apache.commons.math3.util.MathArrays.distance1(var10, var11);
    int[] var13 = new int[] { };
    int[] var14 = null;
    int var15 = org.apache.commons.math3.util.MathArrays.distance1(var13, var14);
    org.apache.commons.math3.random.Well19937c var16 = new org.apache.commons.math3.random.Well19937c(var13);
    int[] var17 = org.apache.commons.math3.util.MathArrays.copyOf(var13);
    double var18 = org.apache.commons.math3.util.MathArrays.distance(var10, var13);
    double var19 = org.apache.commons.math3.util.MathArrays.distance(var2, var13);
    int[] var21 = org.apache.commons.math3.util.MathArrays.copyOf(var13, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test411() {}
//   public void test411() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test411"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
//     var1.reSeed();
//     double var5 = var1.nextCauchy(82.45368975667407d, 82.45368975667407d);
//     long var7 = var1.nextPoisson(5.610049266766251E-8d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var1.nextHypergeometric(94, 118517391, 80);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 237.6952006700619d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0L);
// 
//   }

  public void test412() {}
//   public void test412() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test412"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(0L);
//     double var4 = var0.nextExponential(0.7432416673360078d);
//     int var7 = var0.nextSecureInt(1, 100);
//     double var10 = var0.nextWeibull(10.0d, 114.23712557956448d);
//     double var13 = var0.nextCauchy(0.41852678359398926d, 1.4480256314873523d);
//     var0.reSeedSecure(39L);
//     int var18 = var0.nextZipf(3, 123.14843614424522d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.36157468479281d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 99);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 112.98997911642695d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-0.2748957434128349d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1);
// 
//   }

  public void test413() {}
//   public void test413() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test413"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     double var11 = var0.nextGamma(0.36157468479281d, 0.8376757571801716d);
//     var0.reSeed();
//     var0.reSeedSecure();
//     double var16 = var0.nextCauchy(99.15680865820634d, 54.76711054963606d);
//     double var18 = var0.nextChiSquare(0.15236687205232924d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.8123947100389868d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 133.7382290370341d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3.599908248720607E-5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "6"+ "'", var8.equals("6"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.2268499581683667d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == (-164.24944445337644d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 3.275105933954274E-6d);
// 
//   }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test414"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var0, (java.lang.Number)0.6988080512387618d, 41);

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test415"); }


    java.lang.Number var1 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.5206144238498145d, var1, var2);
    java.lang.Number var4 = var3.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test416() {}
//   public void test416() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test416"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     java.lang.String var10 = var0.nextSecureHexString(10);
//     double var12 = var0.nextT(9.160555011685411E-6d);
//     var0.reSeedSecure(87L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var17 = var0.nextUniform(102.88914887158289d, 0.002243081223676036d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.18666956929803008d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 109.33724470935702d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.0387402197215623d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "5"+ "'", var8.equals("5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "bd9e64782a"+ "'", var10.equals("bd9e64782a"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1.3407807929942188E154d);
// 
//   }

  public void test417() {}
//   public void test417() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test417"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(0L);
//     long var5 = var0.nextSecureLong(10L, 100L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var7 = var0.nextHexString(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 40L);
// 
//   }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test418"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double[] var18 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 10.0d);
    double[] var20 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var20);
    double[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 10);
    double[] var25 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var20, var25);
    double[] var29 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var29);
    double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 10);
    double var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var32);
    double var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var25);
    double[] var36 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var36);
    double[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var36, 10);
    double[] var41 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var41);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var36, var41);
    double[] var45 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var45);
    double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var45, 10);
    double var49 = org.apache.commons.math3.util.MathArrays.distanceInf(var41, var48);
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeAdd(var18, var41);
    double[] var52 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var52);
    double[] var55 = org.apache.commons.math3.util.MathArrays.copyOf(var52, 10);
    double[] var57 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var57);
    boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var52, var57);
    double[] var61 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var61);
    double[] var64 = org.apache.commons.math3.util.MathArrays.copyOf(var61, 10);
    double var65 = org.apache.commons.math3.util.MathArrays.distanceInf(var57, var64);
    org.apache.commons.math3.util.MathArrays.OrderDirection var66 = null;
    boolean var68 = org.apache.commons.math3.util.MathArrays.isMonotonic(var57, var66, true);
    double[] var70 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var70);
    double var72 = org.apache.commons.math3.util.MathArrays.distance1(var57, var70);
    double[] var74 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var74);
    double[] var77 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var77);
    double[] var80 = org.apache.commons.math3.util.MathArrays.copyOf(var77, 10);
    double var81 = org.apache.commons.math3.util.MathArrays.distanceInf(var74, var80);
    double[] var82 = org.apache.commons.math3.util.MathArrays.ebeDivide(var70, var74);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var83 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var18, var82);
    double var85 = var83.inverseCumulativeProbability(0.0d);
    double var86 = var83.getNumericalMean();
    double var87 = var83.getNumericalVariance();
    boolean var88 = var83.isSupportUpperBoundInclusive();
    double var89 = var83.sample();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 11.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == 10.0d);

  }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test419"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = null;
    boolean var9 = org.apache.commons.math3.util.MathArrays.isMonotonic(var1, var7, false);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    org.apache.commons.math3.util.MathArrays.OrderDirection var13 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var11, var13, false);
    double var16 = org.apache.commons.math3.util.MathArrays.safeNorm(var11);
    double[] var18 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var18);
    double[] var21 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var21);
    double[] var24 = org.apache.commons.math3.util.MathArrays.copyOf(var21, 10);
    double var25 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var24);
    double[] var26 = org.apache.commons.math3.util.MathArrays.ebeDivide(var11, var18);
    double[] var28 = org.apache.commons.math3.util.MathArrays.normalizeArray(var11, 10.0d);
    double[] var29 = org.apache.commons.math3.util.MathArrays.copyOf(var11);
    double[] var30 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var11);
    double[] var32 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var32);
    org.apache.commons.math3.util.MathArrays.OrderDirection var34 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var32, var34, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var32);
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var11, var32);
    double[] var40 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var40);
    org.apache.commons.math3.util.MathArrays.OrderDirection var42 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var40, var42, false);
    double var45 = org.apache.commons.math3.util.MathArrays.safeNorm(var40);
    double[] var47 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var47);
    double[] var50 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var50);
    double[] var53 = org.apache.commons.math3.util.MathArrays.copyOf(var50, 10);
    double var54 = org.apache.commons.math3.util.MathArrays.distanceInf(var47, var53);
    double[] var55 = org.apache.commons.math3.util.MathArrays.ebeDivide(var40, var47);
    double[] var57 = org.apache.commons.math3.util.MathArrays.normalizeArray(var40, 10.0d);
    double[] var58 = org.apache.commons.math3.util.MathArrays.copyOf(var40);
    double var59 = org.apache.commons.math3.util.MathArrays.distance1(var11, var40);
    double[] var61 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 95);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);

  }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test420"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    double[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 10);
    double[] var6 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var6);
    boolean var8 = org.apache.commons.math3.util.MathArrays.equals(var1, var6);
    double[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 0);
    double[] var12 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 0);
    double var13 = org.apache.commons.math3.util.MathArrays.safeNorm(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);

  }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test421"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double[] var18 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 10.0d);
    double[] var20 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var20);
    double[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 10);
    double[] var25 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var20, var25);
    double[] var29 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var29);
    double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 10);
    double var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var32);
    double var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var25);
    double[] var36 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var36);
    double[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var36, 10);
    double[] var41 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var41);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var36, var41);
    double[] var45 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var45);
    double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var45, 10);
    double var49 = org.apache.commons.math3.util.MathArrays.distanceInf(var41, var48);
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeAdd(var18, var41);
    double[] var52 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var52);
    double[] var55 = org.apache.commons.math3.util.MathArrays.copyOf(var52, 10);
    double[] var57 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var57);
    boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var52, var57);
    double[] var61 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var61);
    double[] var64 = org.apache.commons.math3.util.MathArrays.copyOf(var61, 10);
    double var65 = org.apache.commons.math3.util.MathArrays.distanceInf(var57, var64);
    org.apache.commons.math3.util.MathArrays.OrderDirection var66 = null;
    boolean var68 = org.apache.commons.math3.util.MathArrays.isMonotonic(var57, var66, true);
    double[] var70 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var70);
    double var72 = org.apache.commons.math3.util.MathArrays.distance1(var57, var70);
    double[] var74 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var74);
    double[] var77 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var77);
    double[] var80 = org.apache.commons.math3.util.MathArrays.copyOf(var77, 10);
    double var81 = org.apache.commons.math3.util.MathArrays.distanceInf(var74, var80);
    double[] var82 = org.apache.commons.math3.util.MathArrays.ebeDivide(var70, var74);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var83 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var18, var82);
    double var85 = var83.inverseCumulativeProbability(0.0d);
    double var86 = var83.getSupportLowerBound();
    boolean var87 = var83.isSupportUpperBoundInclusive();
    double var89 = var83.cumulativeProbability(Double.NaN);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 11.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == 0.0d);

  }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test422"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.4178011808388296d);

  }

  public void test423() {}
//   public void test423() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test423"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     var0.reSeedSecure();
//     var0.reSeed();
//     int var9 = var0.nextZipf(21, 0.044259860704679646d);
//     var0.reSeedSecure(0L);
//     java.util.Collection var12 = null;
//     java.lang.Object[] var14 = var0.nextSample(var12, 6);
// 
//   }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test424"); }


    java.lang.Throwable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    long[] var2 = new long[] { };
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var2);
    long[][] var4 = new long[][] { var2};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var4);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var4);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var4);
    org.apache.commons.math3.exception.MathIllegalStateException var8 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var1, (java.lang.Object[])var4);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test425() {}
//   public void test425() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test425"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(0.11007690070621942d, 143.98991397557194d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 24.071567653021926d);
// 
//   }

  public void test426() {}
//   public void test426() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test426"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     var0.setSeed(0L);
//     double var3 = var0.nextDouble();
//     var0.clear();
//     double var5 = var0.nextGaussian();
//     long var6 = var0.nextLong();
//     var0.setSeed(72L);
//     java.util.List var9 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var10 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var0, var9);
// 
//   }

  public void test427() {}
//   public void test427() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test427"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(0L);
//     java.lang.String var4 = var0.nextHexString(100);
//     java.lang.String var6 = var0.nextSecureHexString(1);
//     var0.reSeed((-1L));
//     int var11 = var0.nextBinomial(31, 0.712841061974317d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var0.nextBeta((-0.03733103526430132d), (-1.278539033278717d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"+ "'", var4.equals("7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "e"+ "'", var6.equals("e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 20);
// 
//   }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test428"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Comparable[] var3 = new java.lang.Comparable[] { 84.46848877247005d};
    org.apache.commons.math3.util.MathArrays.OrderDirection var4 = null;
    boolean var6 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var3, var4, false);
    org.apache.commons.math3.exception.MathArithmeticException var7 = new org.apache.commons.math3.exception.MathArithmeticException(var1, (java.lang.Object[])var3);
    org.apache.commons.math3.exception.MathArithmeticException var8 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var3);
    double[] var13 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var13);
    org.apache.commons.math3.util.MathArrays.OrderDirection var15 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var13, var15, false);
    double var18 = org.apache.commons.math3.util.MathArrays.safeNorm(var13);
    double[] var19 = org.apache.commons.math3.util.MathArrays.copyOf(var13);
    java.lang.Number var21 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var23 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.026278128681618596d, var21, 1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var24 = var23.getDirection();
    double[] var26 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var26);
    org.apache.commons.math3.util.MathArrays.OrderDirection var28 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var26, var28, false);
    double var31 = org.apache.commons.math3.util.MathArrays.safeNorm(var26);
    double[] var33 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var33);
    double[] var36 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var36);
    double[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var36, 10);
    double var40 = org.apache.commons.math3.util.MathArrays.distanceInf(var33, var39);
    double[] var41 = org.apache.commons.math3.util.MathArrays.ebeDivide(var26, var33);
    double[] var43 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var43);
    org.apache.commons.math3.util.MathArrays.OrderDirection var45 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var43, var45, false);
    double var48 = org.apache.commons.math3.util.MathArrays.safeNorm(var43);
    double[] var50 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var50);
    double[] var53 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var53);
    double[] var56 = org.apache.commons.math3.util.MathArrays.copyOf(var53, 10);
    double var57 = org.apache.commons.math3.util.MathArrays.distanceInf(var50, var56);
    double[] var58 = org.apache.commons.math3.util.MathArrays.ebeDivide(var43, var50);
    double[] var60 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var60);
    org.apache.commons.math3.util.MathArrays.OrderDirection var62 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var60, var62, false);
    double var65 = org.apache.commons.math3.util.MathArrays.safeNorm(var60);
    org.apache.commons.math3.util.MathArrays.OrderDirection var66 = null;
    boolean var68 = org.apache.commons.math3.util.MathArrays.isMonotonic(var60, var66, false);
    double[][] var69 = new double[][] { var60};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var43, var69);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var41, var69);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var19, var24, var69);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var74 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)5, (java.lang.Number)121.11723441984769d, 752916846, var24, true);
    boolean var76 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var3, var24, true);
    java.lang.Comparable[] var82 = new java.lang.Comparable[] { (byte)(-1)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var83 = null;
    boolean var85 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var82, var83, true);
    org.apache.commons.math3.exception.NotFiniteNumberException var86 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)107.34245912507674d, (java.lang.Object[])var82);
    java.lang.Number var88 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var90 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.026278128681618596d, var88, 1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var91 = var90.getDirection();
    boolean var93 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var82, var91, true);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var95 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.4232227202160976d, (java.lang.Number)(-42.05705803570227d), 41, var91, false);
    boolean var97 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var3, var91, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var97 == true);

  }

  public void test429() {}
//   public void test429() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test429"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     var0.reSeedSecure();
//     var0.reSeed();
//     int var9 = var0.nextZipf(21, 0.044259860704679646d);
//     java.lang.String var11 = var0.nextSecureHexString(48);
//     double var14 = var0.nextF(161.03739115985056d, 1.4726118418053777d);
//     double var18 = var0.nextUniform(0.13606824750935648d, 99.15680865820634d, true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.034848843986589d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 129.19269097224142d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "b746821659608f6eb1a6da604c2abe410b6489804fb49c46"+ "'", var11.equals("b746821659608f6eb1a6da604c2abe410b6489804fb49c46"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 17.942278101309693d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 82.74553540286507d);
// 
//   }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test430"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(48, (-1));
    int var3 = var2.getDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));

  }

  public void test431() {}
//   public void test431() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test431"); }
// 
// 
//     double[] var0 = null;
//     double[] var2 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var2);
//     double[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var2, 10);
//     double[] var7 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var7);
//     boolean var9 = org.apache.commons.math3.util.MathArrays.equals(var2, var7);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var10 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var7, var10, false);
//     double[] var14 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var14);
//     double[] var17 = org.apache.commons.math3.util.MathArrays.copyOf(var14, 10);
//     double[] var19 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var19);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var21 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var19, var21, false);
//     double var24 = org.apache.commons.math3.util.MathArrays.safeNorm(var19);
//     double[] var26 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var26);
//     double[] var29 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var29);
//     double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 10);
//     double var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var26, var32);
//     double[] var34 = org.apache.commons.math3.util.MathArrays.ebeDivide(var19, var26);
//     double[] var36 = org.apache.commons.math3.util.MathArrays.normalizeArray(var19, 10.0d);
//     double var37 = org.apache.commons.math3.util.MathArrays.distance(var14, var19);
//     double[] var38 = org.apache.commons.math3.util.MathArrays.ebeAdd(var7, var19);
//     double var39 = org.apache.commons.math3.util.MathArrays.linearCombination(var0, var7);
// 
//   }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test432"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double[] var18 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 10.0d);
    double[] var20 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var20);
    double[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 10);
    double[] var25 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var20, var25);
    double[] var29 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var29);
    double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 10);
    double var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var32);
    double var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var25);
    double[] var36 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var36);
    double[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var36, 10);
    double[] var41 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var41);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var36, var41);
    double[] var45 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var45);
    double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var45, 10);
    double var49 = org.apache.commons.math3.util.MathArrays.distanceInf(var41, var48);
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeAdd(var18, var41);
    double[] var52 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var52);
    double[] var55 = org.apache.commons.math3.util.MathArrays.copyOf(var52, 10);
    double[] var57 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var57);
    boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var52, var57);
    double[] var61 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var61);
    double[] var64 = org.apache.commons.math3.util.MathArrays.copyOf(var61, 10);
    double var65 = org.apache.commons.math3.util.MathArrays.distanceInf(var57, var64);
    org.apache.commons.math3.util.MathArrays.OrderDirection var66 = null;
    boolean var68 = org.apache.commons.math3.util.MathArrays.isMonotonic(var57, var66, true);
    double[] var70 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var70);
    double var72 = org.apache.commons.math3.util.MathArrays.distance1(var57, var70);
    double[] var74 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var74);
    double[] var77 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var77);
    double[] var80 = org.apache.commons.math3.util.MathArrays.copyOf(var77, 10);
    double var81 = org.apache.commons.math3.util.MathArrays.distanceInf(var74, var80);
    double[] var82 = org.apache.commons.math3.util.MathArrays.ebeDivide(var70, var74);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var83 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var18, var82);
    double var85 = var83.inverseCumulativeProbability(0.0d);
    double var86 = var83.getNumericalMean();
    boolean var87 = var83.isSupportLowerBoundInclusive();
    double var88 = var83.getNumericalVariance();
    double var89 = var83.getSupportLowerBound();
    double var90 = var83.getNumericalMean();
    double var92 = var83.probability((-185.7588642130088d));
    boolean var93 = var83.isSupportLowerBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 11.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == true);

  }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test433"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(0L);
    double var3 = var0.nextDouble();
    var0.clear();
    double var5 = var0.nextGaussian();
    var0.clear();
    var0.setSeed(7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.7432416673360078d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1.2016184922621251d));

  }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test434"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(0L);
    double var3 = var0.nextDouble();
    var0.clear();
    double var5 = var0.nextGaussian();
    boolean var6 = var0.nextBoolean();
    double var7 = var0.nextDouble();
    var0.setSeed(100);
    org.apache.commons.math3.random.RandomDataImpl var10 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.7432416673360078d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1.2016184922621251d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.3874438233115065d);

  }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test435"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double[] var18 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 10.0d);
    double[] var20 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var20);
    double[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 10);
    double[] var25 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var20, var25);
    double[] var29 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var29);
    double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 10);
    double var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var32);
    double var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var25);
    double[] var36 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var36);
    double[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var36, 10);
    double[] var41 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var41);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var36, var41);
    double[] var45 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var45);
    double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var45, 10);
    double var49 = org.apache.commons.math3.util.MathArrays.distanceInf(var41, var48);
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeAdd(var18, var41);
    double[] var52 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var52);
    double[] var55 = org.apache.commons.math3.util.MathArrays.copyOf(var52, 10);
    double[] var57 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var57);
    boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var52, var57);
    double[] var61 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var61);
    double[] var64 = org.apache.commons.math3.util.MathArrays.copyOf(var61, 10);
    double var65 = org.apache.commons.math3.util.MathArrays.distanceInf(var57, var64);
    org.apache.commons.math3.util.MathArrays.OrderDirection var66 = null;
    boolean var68 = org.apache.commons.math3.util.MathArrays.isMonotonic(var57, var66, true);
    double[] var70 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var70);
    double var72 = org.apache.commons.math3.util.MathArrays.distance1(var57, var70);
    double[] var74 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var74);
    double[] var77 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var77);
    double[] var80 = org.apache.commons.math3.util.MathArrays.copyOf(var77, 10);
    double var81 = org.apache.commons.math3.util.MathArrays.distanceInf(var74, var80);
    double[] var82 = org.apache.commons.math3.util.MathArrays.ebeDivide(var70, var74);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var83 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var18, var82);
    double var86 = var83.probability(0.0d, 76.50641463552304d);
    double[] var88 = var83.sample(48);
    var83.reseedRandomGenerator((-8718518566784105311L));
    double var92 = var83.density(3.2293620585613487d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 11.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == 0.0d);

  }

  public void test436() {}
//   public void test436() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test436"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     double var6 = var0.nextChiSquare(0.3874438233115065d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     var0.reSeed();
//     double var12 = var0.nextF(82.45368975667407d, 0.5876583645210812d);
//     long var15 = var0.nextSecureLong(75L, 477836925424025280L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var18 = var0.nextF(0.0d, 114.66035331336151d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-1.2483138776992913d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 128.17993029818822d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.46585806729557366d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "8"+ "'", var8.equals("8"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.35057430079383656d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 368509781294715328L);
// 
//   }

  public void test437() {}
//   public void test437() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test437"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
//     var1.reSeed();
//     double var4 = var1.nextExponential(0.09794766209667058d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.3201075250356919d);
// 
//   }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test438"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.050315949583375374d, (java.lang.Number)0.29461270966732284d, false);

  }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test439"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)161.03739115985056d);
    java.lang.Number var2 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0+ "'", var2.equals(0));

  }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test440"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(0L);
    var0.clear();
    int var5 = var0.nextInt(1);
    int[] var6 = new int[] { };
    int[] var7 = null;
    int var8 = org.apache.commons.math3.util.MathArrays.distance1(var6, var7);
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(var6);
    int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var6);
    var0.setSeed(var6);
    int[] var13 = org.apache.commons.math3.util.MathArrays.copyOf(var6, 0);
    org.apache.commons.math3.random.Well19937c var14 = new org.apache.commons.math3.random.Well19937c(var6);
    int[] var15 = new int[] { };
    org.apache.commons.math3.random.Well19937c var16 = new org.apache.commons.math3.random.Well19937c(var15);
    int[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var15, 100);
    int[] var20 = org.apache.commons.math3.util.MathArrays.copyOf(var15, 10);
    int[] var22 = org.apache.commons.math3.util.MathArrays.copyOf(var15, 99);
    double var23 = org.apache.commons.math3.util.MathArrays.distance(var6, var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test441"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(0L);
    double var4 = var0.nextExponential(0.7432416673360078d);
    double var6 = var0.nextT(0.035899776418132384d);
    double var9 = var0.nextGaussian(102.85799933184796d, 0.4054370868227162d);
    int[] var12 = var0.nextPermutation(48, 41);
    double var15 = var0.nextGamma(110.0d, 0.09314254419077805d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var18 = var0.nextLong(69L, 10L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.36157468479281d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 27.366395926482813d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 102.57046602831102d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 11.098637058361534d);

  }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test442"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(0L);
    double var3 = var0.nextDouble();
    double var4 = var0.nextGaussian();
    float var5 = var0.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.7432416673360078d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1.2016184922621251d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.52736807f);

  }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test443"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double[] var18 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 10.0d);
    double[] var20 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var20);
    double[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 10);
    double[] var25 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var20, var25);
    double[] var29 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var29);
    double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 10);
    double var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var32);
    double var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var25);
    double[] var36 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var36);
    double[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var36, 10);
    double[] var41 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var41);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var36, var41);
    double[] var45 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var45);
    double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var45, 10);
    double var49 = org.apache.commons.math3.util.MathArrays.distanceInf(var41, var48);
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeAdd(var18, var41);
    double[] var52 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var52);
    double[] var55 = org.apache.commons.math3.util.MathArrays.copyOf(var52, 10);
    double[] var57 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var57);
    boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var52, var57);
    double[] var61 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var61);
    double[] var64 = org.apache.commons.math3.util.MathArrays.copyOf(var61, 10);
    double var65 = org.apache.commons.math3.util.MathArrays.distanceInf(var57, var64);
    org.apache.commons.math3.util.MathArrays.OrderDirection var66 = null;
    boolean var68 = org.apache.commons.math3.util.MathArrays.isMonotonic(var57, var66, true);
    double[] var70 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var70);
    double var72 = org.apache.commons.math3.util.MathArrays.distance1(var57, var70);
    double[] var74 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var74);
    double[] var77 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var77);
    double[] var80 = org.apache.commons.math3.util.MathArrays.copyOf(var77, 10);
    double var81 = org.apache.commons.math3.util.MathArrays.distanceInf(var74, var80);
    double[] var82 = org.apache.commons.math3.util.MathArrays.ebeDivide(var70, var74);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var83 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var18, var82);
    double var85 = var83.inverseCumulativeProbability(0.0d);
    double var86 = var83.getNumericalMean();
    boolean var87 = var83.isSupportLowerBoundInclusive();
    double var88 = var83.getNumericalVariance();
    boolean var89 = var83.isSupportConnected();
    double var90 = var83.getNumericalMean();
    double var92 = var83.probability((-3.94566039451795E71d));
    double var93 = var83.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 11.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == 10.0d);

  }

  public void test444() {}
//   public void test444() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test444"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(0L);
//     java.lang.String var4 = var0.nextHexString(100);
//     java.lang.String var6 = var0.nextSecureHexString(1);
//     var0.reSeed((-1L));
//     double var10 = var0.nextExponential(0.915778680097192d);
//     long var13 = var0.nextSecureLong(0L, 477836925424025280L);
//     long var16 = var0.nextLong(1L, 100L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"+ "'", var4.equals("7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "1"+ "'", var6.equals("1"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.3650947445123496d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 301846741794720384L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 47L);
// 
//   }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test445"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(0L);
    double var3 = var0.nextDouble();
    int[] var7 = new int[] { 1, 10, 100};
    var0.setSeed(var7);
    int var9 = var0.nextInt();
    var0.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.7432416673360078d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-1276125876));

  }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test446"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)140.37260799449047d);
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var2.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test447"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var3 = new java.lang.Object[] { 'a'};
    org.apache.commons.math3.exception.NotFiniteNumberException var4 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)(short)0, var3);
    double[] var6 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var6);
    org.apache.commons.math3.util.MathArrays.OrderDirection var8 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var6, var8, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var6);
    org.apache.commons.math3.util.Pair var12 = new org.apache.commons.math3.util.Pair((java.lang.Object)(short)0, (java.lang.Object)var6);
    java.lang.Object var13 = var12.getValue();
    org.apache.commons.math3.util.Pair var14 = new org.apache.commons.math3.util.Pair(var12);
    java.lang.Object var15 = var12.getKey();
    java.lang.Object var16 = var12.getSecond();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + (short)0+ "'", var15.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test448() {}
//   public void test448() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test448"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(0L);
//     java.lang.String var4 = var0.nextHexString(100);
//     java.lang.String var6 = var0.nextSecureHexString(1);
//     var0.reSeed((-1L));
//     double var10 = var0.nextExponential(0.915778680097192d);
//     var0.reSeedSecure();
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var0.nextWeibull(126.60285928099428d, (-46.41745928820278d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"+ "'", var4.equals("7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "9"+ "'", var6.equals("9"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.3650947445123496d);
// 
//   }

  public void test449() {}
//   public void test449() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test449"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var6 = var0.nextHypergeometric(14, 0, 71);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.7166441635469922d));
// 
//   }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test450"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)1.2933613415363947d);

  }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test451"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var0, 100);
    int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var0, 10);
    int[] var7 = org.apache.commons.math3.util.MathArrays.copyOf(var0, 99);
    int[] var8 = new int[] { };
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(var8);
    int[] var10 = new int[] { };
    org.apache.commons.math3.random.Well19937c var11 = new org.apache.commons.math3.random.Well19937c(var10);
    int[] var13 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 100);
    int var14 = org.apache.commons.math3.util.MathArrays.distance1(var8, var10);
    int[] var15 = new int[] { };
    org.apache.commons.math3.random.Well19937c var16 = new org.apache.commons.math3.random.Well19937c(var15);
    int var17 = org.apache.commons.math3.util.MathArrays.distanceInf(var10, var15);
    int var18 = org.apache.commons.math3.util.MathArrays.distanceInf(var0, var10);
    int[] var19 = new int[] { };
    org.apache.commons.math3.random.Well19937c var20 = new org.apache.commons.math3.random.Well19937c(var19);
    int var21 = org.apache.commons.math3.util.MathArrays.distance1(var10, var19);
    int[] var22 = new int[] { };
    org.apache.commons.math3.random.Well19937c var23 = new org.apache.commons.math3.random.Well19937c(var22);
    int[] var24 = new int[] { };
    org.apache.commons.math3.random.Well19937c var25 = new org.apache.commons.math3.random.Well19937c(var24);
    int[] var27 = org.apache.commons.math3.util.MathArrays.copyOf(var24, 100);
    int var28 = org.apache.commons.math3.util.MathArrays.distance1(var22, var24);
    int[] var29 = new int[] { };
    org.apache.commons.math3.random.Well19937c var30 = new org.apache.commons.math3.random.Well19937c(var29);
    int var31 = org.apache.commons.math3.util.MathArrays.distanceInf(var24, var29);
    org.apache.commons.math3.random.Well19937c var32 = new org.apache.commons.math3.random.Well19937c(var24);
    double var33 = org.apache.commons.math3.util.MathArrays.distance(var19, var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);

  }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test452"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)114.23712557956448d, (java.lang.Number)0.09175824555693415d, 0);
    int var4 = var3.getIndex();
    boolean var5 = var3.getStrict();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test453"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(0L);
    double var3 = var0.nextDouble();
    var0.clear();
    double var5 = var0.nextGaussian();
    var0.setSeed(0);
    double var8 = var0.nextDouble();
    var0.clear();
    org.apache.commons.math3.random.RandomDataGenerator var10 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
    var10.reSeed(39L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.7432416673360078d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1.2016184922621251d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.9775554539871507d);

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test454"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(0L);
    var0.clear();
    int var5 = var0.nextInt(1);
    int[] var6 = new int[] { };
    int[] var7 = null;
    int var8 = org.apache.commons.math3.util.MathArrays.distance1(var6, var7);
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(var6);
    int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var6);
    var0.setSeed(var6);
    int[] var13 = org.apache.commons.math3.util.MathArrays.copyOf(var6, 0);
    org.apache.commons.math3.random.Well19937c var14 = new org.apache.commons.math3.random.Well19937c(var6);
    var14.setSeed(35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test455"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var3 = new java.lang.Object[] { 'a'};
    org.apache.commons.math3.exception.NotFiniteNumberException var4 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)(short)0, var3);
    double[] var6 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var6);
    org.apache.commons.math3.util.MathArrays.OrderDirection var8 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var6, var8, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var6);
    org.apache.commons.math3.util.Pair var12 = new org.apache.commons.math3.util.Pair((java.lang.Object)(short)0, (java.lang.Object)var6);
    java.lang.Object var13 = var12.getFirst();
    java.lang.Object var14 = var12.getFirst();
    java.lang.Object var15 = var12.getValue();
    java.lang.Object var16 = var12.getKey();
    java.lang.Object var17 = var12.getValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + (short)0+ "'", var13.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + (short)0+ "'", var14.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + (short)0+ "'", var16.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test456"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(0L);
    var0.clear();
    int var5 = var0.nextInt(1);
    int[] var6 = new int[] { };
    int[] var7 = null;
    int var8 = org.apache.commons.math3.util.MathArrays.distance1(var6, var7);
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(var6);
    int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var6);
    var0.setSeed(var6);
    int[] var13 = org.apache.commons.math3.util.MathArrays.copyOf(var6, 0);
    org.apache.commons.math3.random.Well19937c var14 = new org.apache.commons.math3.random.Well19937c(var6);
    float var15 = var14.nextFloat();
    float var16 = var14.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.17530203f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.88943887f);

  }

  public void test457() {}
//   public void test457() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test457"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(0L);
//     java.lang.String var4 = var0.nextHexString(100);
//     java.lang.String var6 = var0.nextSecureHexString(1);
//     var0.reSeed((-1L));
//     double var10 = var0.nextExponential(0.915778680097192d);
//     var0.reSeedSecure();
//     long var14 = var0.nextLong(10L, 1024457413273955602L);
//     double var17 = var0.nextWeibull(100.0d, 1.2933613415363947d);
//     double var19 = var0.nextExponential(0.38521648197200425d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"+ "'", var4.equals("7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "0"+ "'", var6.equals("0"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.3650947445123496d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 477836925424025280L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.2756063300353422d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.3095760743052602d);
// 
//   }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test458"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Object[] var3 = new java.lang.Object[] { (-1L)};
    org.apache.commons.math3.exception.MathIllegalArgumentException var4 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, var3);
    org.apache.commons.math3.exception.MathIllegalArgumentException var5 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test459() {}
//   public void test459() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test459"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(110.0d);
//     double var4 = var0.nextChiSquare(110.0d);
//     var0.reSeedSecure();
//     int var8 = var0.nextSecureInt((-1), 1);
//     double var11 = var0.nextF(114.28092195575411d, 0.748697168979193d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.8521016979368586d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 103.64377251286945d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.37121213181629964d);
// 
//   }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test460"); }


    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)117.9736690792914d, (java.lang.Number)105.39091667829669d, 36, var3, true);
    int var6 = var5.getIndex();
    java.lang.String var7 = var5.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "org.apache.commons.math3.exception.NonMonotonicSequenceException: points 35 and 36 are not strictly decreasing (105.391 <= 117.974)"+ "'", var7.equals("org.apache.commons.math3.exception.NonMonotonicSequenceException: points 35 and 36 are not strictly decreasing (105.391 <= 117.974)"));

  }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test461"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double[] var18 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 10.0d);
    double[] var20 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var20);
    double[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 10);
    double[] var24 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var20);
    double[] var26 = org.apache.commons.math3.util.MathArrays.normalizeArray(var24, 0.41613954551936133d);
    double var27 = org.apache.commons.math3.util.MathArrays.safeNorm(var24);
    double[] var29 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var29);
    org.apache.commons.math3.util.MathArrays.OrderDirection var31 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var29, var31, false);
    double var34 = org.apache.commons.math3.util.MathArrays.safeNorm(var29);
    double[] var35 = org.apache.commons.math3.util.MathArrays.copyOf(var29);
    java.lang.Number var37 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var39 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.026278128681618596d, var37, 1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var40 = var39.getDirection();
    double[] var42 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var42);
    org.apache.commons.math3.util.MathArrays.OrderDirection var44 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var42, var44, false);
    double var47 = org.apache.commons.math3.util.MathArrays.safeNorm(var42);
    double[] var49 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var49);
    double[] var52 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var52);
    double[] var55 = org.apache.commons.math3.util.MathArrays.copyOf(var52, 10);
    double var56 = org.apache.commons.math3.util.MathArrays.distanceInf(var49, var55);
    double[] var57 = org.apache.commons.math3.util.MathArrays.ebeDivide(var42, var49);
    double[] var59 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var59);
    org.apache.commons.math3.util.MathArrays.OrderDirection var61 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var59, var61, false);
    double var64 = org.apache.commons.math3.util.MathArrays.safeNorm(var59);
    double[] var66 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var66);
    double[] var69 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var69);
    double[] var72 = org.apache.commons.math3.util.MathArrays.copyOf(var69, 10);
    double var73 = org.apache.commons.math3.util.MathArrays.distanceInf(var66, var72);
    double[] var74 = org.apache.commons.math3.util.MathArrays.ebeDivide(var59, var66);
    double[] var76 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var76);
    org.apache.commons.math3.util.MathArrays.OrderDirection var78 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var76, var78, false);
    double var81 = org.apache.commons.math3.util.MathArrays.safeNorm(var76);
    org.apache.commons.math3.util.MathArrays.OrderDirection var82 = null;
    boolean var84 = org.apache.commons.math3.util.MathArrays.isMonotonic(var76, var82, false);
    double[][] var85 = new double[][] { var76};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var59, var85);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var57, var85);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var35, var40, var85);
    boolean var89 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var24, var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == false);

  }

  public void test462() {}
//   public void test462() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test462"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)1, (java.lang.Number)1L, (java.lang.Number)(short)(-1));
//     java.lang.Number var5 = var4.getHi();
//     java.lang.Number var6 = var4.getLo();
//     java.lang.Number var7 = var4.getLo();
//     java.lang.Number var8 = var4.getLo();
//     org.apache.commons.math3.exception.MathInternalError var9 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var4);
// 
//   }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test463"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var1, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var8 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var8);
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    double var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var8);
    double var17 = org.apache.commons.math3.util.MathArrays.safeNorm(var8);
    double[] var19 = org.apache.commons.math3.util.MathArrays.copyOf(var8, 1);
    double[] var21 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var21);
    double[] var24 = org.apache.commons.math3.util.MathArrays.copyOf(var21, 10);
    double[] var26 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var26);
    boolean var28 = org.apache.commons.math3.util.MathArrays.equals(var21, var26);
    double[] var30 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var30);
    double[] var33 = org.apache.commons.math3.util.MathArrays.copyOf(var30, 10);
    double var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var26, var33);
    org.apache.commons.math3.util.MathArrays.OrderDirection var35 = null;
    boolean var37 = org.apache.commons.math3.util.MathArrays.isMonotonic(var26, var35, true);
    double[] var39 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var39);
    double var41 = org.apache.commons.math3.util.MathArrays.distance1(var26, var39);
    double[] var43 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var43);
    double[] var46 = org.apache.commons.math3.util.MathArrays.copyOf(var43, 10);
    double[] var48 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var48);
    org.apache.commons.math3.util.MathArrays.OrderDirection var50 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var48, var50, false);
    boolean var53 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var46, var48);
    double[] var54 = org.apache.commons.math3.util.MathArrays.ebeAdd(var26, var48);
    double[] var55 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var19, var26);
    double[] var57 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var57);
    double[] var60 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.checkOrder(var60);
    double[] var63 = org.apache.commons.math3.util.MathArrays.copyOf(var60, 10);
    double var64 = org.apache.commons.math3.util.MathArrays.distanceInf(var57, var63);
    double var65 = org.apache.commons.math3.util.MathArrays.distance1(var19, var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);

  }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test464"); }


    int[] var0 = new int[] { };
    int[] var1 = null;
    int var2 = org.apache.commons.math3.util.MathArrays.distance1(var0, var1);
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var0);
    int[] var4 = null;
    double var5 = org.apache.commons.math3.util.MathArrays.distance(var0, var4);
    org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);

  }

}
