
import junit.framework.*;

public class RandoopTest1 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test1"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)10, (java.lang.Number)10.0f, (java.lang.Number)(short)10);
    java.lang.Number var4 = var3.getHi();
    java.lang.Number var5 = var3.getLo();
    java.lang.Number var6 = var3.getArgument();
    java.lang.Number var7 = var3.getLo();
    java.lang.Number var8 = var3.getArgument();
    org.apache.commons.math3.exception.util.ExceptionContext var9 = var3.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (short)10+ "'", var4.equals((short)10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 10.0f+ "'", var5.equals(10.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (short)10+ "'", var6.equals((short)10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 10.0f+ "'", var7.equals(10.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (short)10+ "'", var8.equals((short)10));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test2"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    java.lang.Object[] var11 = new java.lang.Object[] { (short)(-1)};
    org.apache.commons.math3.exception.NotFiniteNumberException var12 = new org.apache.commons.math3.exception.NotFiniteNumberException(var8, (java.lang.Number)0, var11);
    org.apache.commons.math3.exception.MathIllegalArgumentException var13 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var7, var11);
    org.apache.commons.math3.exception.NotFiniteNumberException var14 = new org.apache.commons.math3.exception.NotFiniteNumberException(var5, (java.lang.Number)0.5364627384899132d, var11);
    org.apache.commons.math3.exception.NotFiniteNumberException var15 = new org.apache.commons.math3.exception.NotFiniteNumberException(var3, (java.lang.Number)1.0f, var11);
    org.apache.commons.math3.exception.NotFiniteNumberException var16 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, var2, var11);
    org.apache.commons.math3.exception.MathIllegalArgumentException var17 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test3"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    int var5 = var0.nextZipf(1, 54.75212864082803d);
    double var8 = var0.nextBeta(3600.0d, 0.39846065982359696d);
    int var12 = var0.nextHypergeometric(110704524, 0, 22);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var15 = var0.nextLong(57L, 16L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.9999999132172324d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test4"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(32.43325533860437d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5109905411687983d);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test5"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    java.lang.Object[] var9 = new java.lang.Object[] { (short)(-1)};
    org.apache.commons.math3.exception.NotFiniteNumberException var10 = new org.apache.commons.math3.exception.NotFiniteNumberException(var6, (java.lang.Number)0, var9);
    org.apache.commons.math3.exception.MathIllegalArgumentException var11 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var5, var9);
    org.apache.commons.math3.exception.NotFiniteNumberException var12 = new org.apache.commons.math3.exception.NotFiniteNumberException(var3, (java.lang.Number)0.5364627384899132d, var9);
    org.apache.commons.math3.exception.NotFiniteNumberException var13 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Number)1.0f, var9);
    org.apache.commons.math3.exception.MathIllegalStateException var14 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test6"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(0.57205045f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.57205045f);

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test7"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(862908985188605553L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test8() {}
//   public void test8() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test8"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(1980.7585985364183d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test9"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var5 = var0.nextCauchy((-699.7827128954451d), 100.0d);
    var0.reSeedSecure(10L);
    double var11 = var0.nextUniform(0.9999999958776927d, 57.29577951308232d, false);
    double var14 = var0.nextGaussian(1.225262833408642E-304d, 1.0d);
    var0.reSeedSecure();
    double var18 = var0.nextBeta(0.8406398270218143d, 1.0d);
    double var21 = var0.nextGaussian(6.047909608775628E-6d, 1.5660768339053222d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-729.2529703881293d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 54.75212864082803d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == (-2.6649762425333257d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.7931001851778443d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.5940982417357954d);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test10"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(0.0f, 205977278);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test11"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp((-2.410126239324223E-6d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-2.4101262393242226E-6d));

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test12"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(7400.302272421626d, 5.070965234019122E-7d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7400.302272421626d);

  }

  public void test13() {}
//   public void test13() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test13"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var4 = var1.nextGaussian(0.0d, 7254.222364425498d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-11570.013065502968d));
// 
//   }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test14"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)10, (java.lang.Number)10.0f, (java.lang.Number)(short)10);
    java.lang.Number var4 = var3.getHi();
    java.lang.Number var5 = var3.getLo();
    java.lang.Number var6 = var3.getArgument();
    org.apache.commons.math3.exception.util.ExceptionContext var7 = var3.getContext();
    java.lang.Number var8 = var3.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (short)10+ "'", var4.equals((short)10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 10.0f+ "'", var5.equals(10.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (short)10+ "'", var6.equals((short)10));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (short)10+ "'", var8.equals((short)10));

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test15"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
    double var4 = var3.getNumericalMean();
    int var5 = var3.sample();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var7 = var3.inverseCumulativeProbability(Double.NEGATIVE_INFINITY);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test16"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(0.9577712f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test17"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(0.10513508f, 1433907990);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.POSITIVE_INFINITY);

  }

  public void test18() {}
//   public void test18() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test18"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.sqrt(Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test19"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    var0.reSeed(13L);
    int var5 = var0.nextPascal(12, 0.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var8 = var0.nextSecureInt(513171738, (-4));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2147483647);

  }

  public void test20() {}
//   public void test20() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test20"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed(13L);
//     var0.reSeed();
//     int var6 = var0.nextSecureInt(98, 2147483647);
//     var0.reSeedSecure(2372L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var0.nextBeta(0.0d, 1.5707963267948966d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1354857882);
// 
//   }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test21"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(55.24586419897384d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 55.0d);

  }

  public void test22() {}
//   public void test22() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test22"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     boolean var1 = var0.nextBoolean();
//     var0.clear();
//     float var3 = var0.nextFloat();
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var6 = var4.nextT(57.29577951308232d);
//     var4.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var10 = var4.nextSecureLong(53L, 17L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.70556533f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.7958378104248844d);
// 
//   }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test23"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, var1, (java.lang.Number)1.1920928E-7f, true);

  }

  public void test24() {}
//   public void test24() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test24"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     boolean var1 = var0.nextBoolean();
//     var0.clear();
//     var0.setSeed((-1023));
//     var0.setSeed(818120085);
//     long var8 = var0.nextLong(52L);
//     int[] var9 = null;
//     var0.setSeed(var9);
//     var0.setSeed(0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 13L);
// 
//   }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test25"); }


    double var2 = org.apache.commons.math3.util.FastMath.max((-0.0d), (-3.1266328832448305d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.0d));

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test26"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)10, (java.lang.Number)10.0f, (java.lang.Number)(short)10);
    org.apache.commons.math3.exception.OutOfRangeException var8 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)10, (java.lang.Number)10.0f, (java.lang.Number)(short)10);
    java.lang.Number var9 = var8.getHi();
    java.lang.Number var10 = var8.getLo();
    java.lang.Number var11 = var8.getArgument();
    var4.addSuppressed((java.lang.Throwable)var8);
    java.lang.Number var13 = var8.getArgument();
    org.apache.commons.math3.exception.util.Localizable var14 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var19 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(short)0, (java.lang.Number)2275.2336411793885d, false);
    java.lang.Object[] var20 = new java.lang.Object[] { var19};
    org.apache.commons.math3.exception.NotFiniteNumberException var21 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)60.446553428065656d, var20);
    org.apache.commons.math3.exception.MathIllegalStateException var22 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var8, var14, var20);
    org.apache.commons.math3.exception.MathIllegalArgumentException var23 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + (short)10+ "'", var9.equals((short)10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + 10.0f+ "'", var10.equals(10.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + (short)10+ "'", var11.equals((short)10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + (short)10+ "'", var13.equals((short)10));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test27() {}
//   public void test27() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test27"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-4));
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var5 = var2.nextSecureLong(864L, 2372L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1546L);
// 
//   }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test28"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(1.2511782723310527d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test29"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)1.0f);
    java.lang.Number var2 = var1.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 1.0f+ "'", var2.equals(1.0f));

  }

  public void test30() {}
//   public void test30() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test30"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int[] var1 = null;
//     var0.setSeed(var1);
//     var0.setSeed(100L);
//     int var5 = var0.nextInt();
//     long var6 = var0.nextLong();
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     var7.reSeed();
//     double var10 = var7.nextT(0.7838376650545498d);
//     double var12 = var7.nextExponential(0.043865248283487694d);
//     java.lang.String var14 = var7.nextSecureHexString(12);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var18 = var7.nextUniform(0.04383714613469767d, (-1.3581577268388338d), false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 818120085);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 862908985188605553L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 13.960843258349515d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.04969082578108749d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "717b334099c2"+ "'", var14.equals("717b334099c2"));
// 
//   }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test31"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(57.71535528726942d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.748595381914277d);

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test32"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(1546L, 86L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1546L);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test33"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    boolean var2 = var1.nextBoolean();
    long var4 = var1.nextLong(10L);
    var1.setSeed(1);
    long var8 = var1.nextLong(90L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 9L);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test34"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(0.463561233724663d, (-6612.714485975319d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.1415225520854944d);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test35"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(57.29577951308232d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6795226183513794d);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test36"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(12);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var2.nextBeta(0.0d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
    } catch (org.apache.commons.math3.exception.NoBracketingException e) {
      // Expected exception.
    }

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test37"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(0.25613621373411566d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.2533447179022933d);

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test38"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)10, (java.lang.Number)10.0f, (java.lang.Number)(short)10);
    java.lang.String var4 = var3.toString();
    java.lang.Number var5 = var3.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: 10 out of [10, 10] range"+ "'", var4.equals("org.apache.commons.math3.exception.OutOfRangeException: 10 out of [10, 10] range"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (short)10+ "'", var5.equals((short)10));

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test39"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(0.6547536468207042d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7677324907460247d);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test40"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    int[] var1 = null;
    var0.setSeed(var1);
    var0.setSeed(100L);
    int var5 = var0.nextInt();
    long var6 = var0.nextLong();
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    var7.reSeed(10L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var12 = var7.nextInt((-4), (-523));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 818120085);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 862908985188605553L);

  }

  public void test41() {}
//   public void test41() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test41"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextUniform((-1.5574077246549023d), 11013.232874703393d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var6 = var0.nextF(458.00107225800133d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 5579.618989209546d);
// 
//   }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test42"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(7400.302272421626d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7400.0d);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test43"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.48847377f, (java.lang.Number)0.2379278f, (java.lang.Number)1.1920929E-7f);

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test44"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-0.5413852756622436d), (java.lang.Number)0.7838376650545498d, true);
    java.lang.Number var5 = var4.getMax();
    org.apache.commons.math3.exception.util.ExceptionContext var6 = var4.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.7838376650545498d+ "'", var5.equals(0.7838376650545498d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test45"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(7514.9925667756825d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.29832703143931427d);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test46"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    var0.reSeed(13L);
    var0.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var6 = var0.nextZipf((-127), 1.2511782723310527d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test47"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var5 = var0.nextCauchy((-699.7827128954451d), 100.0d);
    var0.reSeedSecure(10L);
    long var9 = var0.nextPoisson(4815.223910021246d);
    var0.reSeedSecure(0L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var14 = var0.nextBinomial(98, 2814.407873720085d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-729.2529703881293d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 4864L);

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test48"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    var0.reSeed(13L);
    double var5 = var0.nextWeibull(1.5707899264686505d, 9263.640859542764d);
    var0.reSeedSecure();
    double var8 = var0.nextT(1.225262833408642E-304d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 5061.9280334995965d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-7.042669357219505E9d));

  }

  public void test49() {}
//   public void test49() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test49"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int[] var1 = null;
//     var0.setSeed(var1);
//     var0.setSeed(100L);
//     int var5 = var0.nextInt();
//     long var6 = var0.nextLong();
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     var7.reSeed();
//     var7.reSeed();
//     int var13 = var7.nextHypergeometric(818120085, 98, 146899547);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var7.setSecureAlgorithm("org.apache.commons.math3.exception.OutOfRangeException: 10 out of [10, 10] range", "hi!");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 818120085);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 862908985188605553L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 19);
// 
//   }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test50"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(0.027952873673631765d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.027956515178400813d);

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test51"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(48L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 48L);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test52"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(10240.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test53"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp((-0.7329424644654058d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.7329424644654057d));

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test54"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)63.38748545037136d, (java.lang.Number)1890823379, false);

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test55"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(1.2252628334086418E-304d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test56"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(12);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    long var5 = var2.nextLong(44L, 4864L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var8 = var2.nextSecureLong(102400L, 20L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2372L);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test57"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.29832703143931427d, 63.38748545037136d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.2983270314393143d);

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test58"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    int var5 = var0.nextZipf(1, 54.75212864082803d);
    double var8 = var0.nextUniform(1.1368683772161603E-13d, 60.446553428065656d);
    org.apache.commons.math3.random.RandomGenerator var9 = var0.getRandomGenerator();
    double var11 = var0.nextExponential(1.7581226324091723d);
    java.lang.String var13 = var0.nextHexString(15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 57.71535528726942d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1.2511782723310527d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "68febacfc31fc87"+ "'", var13.equals("68febacfc31fc87"));

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test59"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(1.6481544285300042E22d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.6481544285300044E22d);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test60"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(12);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeed(44L);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test61"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(0.57205045f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5720505f);

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test62"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(1.5660768339053222d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2514299156985669d);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test63"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var3 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)10, (java.lang.Number)1.6896826985536354E27d, var3);

  }

  public void test64() {}
//   public void test64() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test64"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextUniform((-1.5574077246549023d), 11013.232874703393d);
//     var0.reSeed();
//     int var7 = var0.nextInt(12, 98);
//     double var10 = var0.nextGaussian(0.34486529307927305d, 0.26669969365787255d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 5906.595432730464d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.7337278513253938d);
// 
//   }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test65"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, var1, (java.lang.Number)1.2252628283577319E-304d, (java.lang.Number)4815.223910021246d);
    java.lang.Number var5 = var4.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test66"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(19, 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test67"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(0.043865248283487694d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.655930097516513E-4d);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test68"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(12);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var3 = var1.nextDouble();
    boolean var4 = var1.nextBoolean();
    var1.clear();
    long var6 = var1.nextLong();
    var1.setSeed(86L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.7838376650545498d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-809800820540421050L));

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test69"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    int var5 = var0.nextZipf(1, 54.75212864082803d);
    double var8 = var0.nextUniform(1.1368683772161603E-13d, 60.446553428065656d);
    org.apache.commons.math3.random.RandomGenerator var9 = var0.getRandomGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var12 = var0.nextSecureLong(90L, 51L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 57.71535528726942d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test70"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.569420848330462d);

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test71"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(12);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var1.clear();

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test72"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
    double var4 = var3.getNumericalMean();
    double var6 = var3.cumulativeProbability(818120085);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var8 = var3.inverseCumulativeProbability(32.43325533860437d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test73"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(0.0d, 0.7336545584598283d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test74() {}
//   public void test74() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test74"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextUniform((-1.5574077246549023d), 11013.232874703393d);
//     var0.reSeed();
//     double var7 = var0.nextUniform(0.027952873673631765d, 0.7838376650545498d);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var0.nextInt(56, 11);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 10091.344007739985d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.7205734760855865d);
// 
//   }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test75"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(458.00107225800133d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test76"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    int[] var1 = null;
    var0.setSeed(var1);
    var0.setSeed(100L);
    int var6 = var0.nextInt(12);
    int var8 = var0.nextInt(513171738);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 100455827);

  }

  public void test77() {}
//   public void test77() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test77"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int[] var1 = null;
//     var0.setSeed(var1);
//     var0.setSeed(100L);
//     int var5 = var0.nextInt();
//     long var6 = var0.nextLong();
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     var7.reSeed();
//     var7.reSeed();
//     int var13 = var7.nextHypergeometric(818120085, 98, 146899547);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var17 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
//     double var19 = var17.probability(0);
//     boolean var20 = var17.isSupportConnected();
//     int var21 = var7.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var17);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var24 = var7.nextPermutation((-523), 513171738);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 818120085);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 862908985188605553L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0);
// 
//   }

  public void test78() {}
//   public void test78() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test78"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int[] var1 = null;
//     var0.setSeed(var1);
//     var0.setSeed(100L);
//     int var5 = var0.nextInt();
//     long var6 = var0.nextLong();
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     var7.reSeed();
//     double var10 = var7.nextT(0.7838376650545498d);
//     int var13 = var7.nextSecureInt((-1023), 10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var15 = var7.nextHexString((-523));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 818120085);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 862908985188605553L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-12.325091629994521d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-265));
// 
//   }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test79"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.16468322f, 60.446553428065656d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.16468324f);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test80"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    var0.reSeed(13L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var0.nextGaussian(0.043893404540024376d, (-1.3581577268388336d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test81"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    long var3 = var1.nextLong(4864L);
    int var5 = var1.nextInt(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 2819L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test82"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(0.27929378f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test83"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
    double var4 = var3.getNumericalMean();
    int var5 = var3.sample();
    int var6 = var3.sample();
    double var8 = var3.cumulativeProbability(12);
    double var9 = var3.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test84"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(0.0014562036505027243d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0014562036505027243d);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test85"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    java.lang.Object[] var11 = new java.lang.Object[] { (short)(-1)};
    org.apache.commons.math3.exception.NotFiniteNumberException var12 = new org.apache.commons.math3.exception.NotFiniteNumberException(var8, (java.lang.Number)0, var11);
    org.apache.commons.math3.exception.MathIllegalArgumentException var13 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var7, var11);
    org.apache.commons.math3.exception.NotFiniteNumberException var14 = new org.apache.commons.math3.exception.NotFiniteNumberException(var5, (java.lang.Number)0.5364627384899132d, var11);
    org.apache.commons.math3.exception.NotFiniteNumberException var15 = new org.apache.commons.math3.exception.NotFiniteNumberException(var3, (java.lang.Number)1.0f, var11);
    org.apache.commons.math3.exception.NotFiniteNumberException var16 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, var2, var11);
    org.apache.commons.math3.exception.MathInternalError var17 = new org.apache.commons.math3.exception.MathInternalError(var0, var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test86"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(16, (-523));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 16);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test87"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var5 = var0.nextCauchy((-699.7827128954451d), 100.0d);
    org.apache.commons.math3.random.RandomGenerator var6 = var0.getRandomGenerator();
    var0.reSeed(1L);
    double var10 = var0.nextChiSquare(0.027956515178400813d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-729.2529703881293d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test88"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(0.9999999979388463d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.017453292483969377d);

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test89"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(0.0d, 0.027952873673631765d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test90"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)4.9E-324d);
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var2.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test91"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(8440.19807688283d, 60.446553428065656d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.4536962690103032d);

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test92"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(0.0d, 3680.7382205113386d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test93"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.0d, 4971.100933318636d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test94"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0, var2, false);
    boolean var5 = var4.getBoundIsAllowed();
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var10 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var6, (java.lang.Number)8703.735538471214d, (java.lang.Number)10.0f, false);
    var4.addSuppressed((java.lang.Throwable)var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test95"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(1.4E-45f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test96"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.2379278f, 4679.465547253845d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.23792781f);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test97"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(44L);

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test98"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(63.38748545037136d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test99() {}
//   public void test99() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test99"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     boolean var1 = var0.nextBoolean();
//     var0.clear();
//     float var3 = var0.nextFloat();
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var6 = var4.nextT(57.29577951308232d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var4.nextWeibull(0.0d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.174384f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1.2865946725784256d));
// 
//   }

  public void test100() {}
//   public void test100() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test100"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed(13L);
//     double var5 = var0.nextWeibull(1.5707899264686505d, 9263.640859542764d);
//     double var9 = var0.nextUniform(0.4393086791491494d, 0.7309575981987914d, true);
//     java.util.Collection var10 = null;
//     java.lang.Object[] var12 = var0.nextSample(var10, 16);
// 
//   }

  public void test101() {}
//   public void test101() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test101"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextUniform((-1.5574077246549023d), 11013.232874703393d);
//     var0.reSeed();
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var8 = var0.nextSecureInt(55, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 10569.59475761623d);
// 
//   }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test102"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    int[] var1 = null;
    var0.setSeed(var1);
    var0.setSeed(100L);
    int var5 = var0.nextInt();
    long var6 = var0.nextLong();
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    var7.reSeed(10L);
    double var12 = var7.nextF(5.070965234019122E-7d, 1006.9465292964504d);
    var7.reSeed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 818120085);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 862908985188605553L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test103"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(byte)10, (java.lang.Number)0.5446694115309465d, false);

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test104"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    int[] var1 = null;
    var0.setSeed(var1);
    var0.setSeed(100L);
    int var5 = var0.nextInt();
    long var6 = var0.nextLong();
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    var7.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var11 = var7.nextLong(1546L, 89L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 818120085);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 862908985188605553L);

  }

  public void test105() {}
//   public void test105() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test105"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextUniform((-1.5574077246549023d), 11013.232874703393d);
//     var0.reSeed();
//     var0.reSeed(1L);
//     double var8 = var0.nextExponential(0.3905499213360595d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 8251.632939607316d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.8763448446585552d);
// 
//   }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test106"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(1.5109905411687983d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9206773132104868d);

  }

  public void test107() {}
//   public void test107() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test107"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int[] var1 = null;
//     var0.setSeed(var1);
//     var0.setSeed(100L);
//     int var5 = var0.nextInt();
//     long var6 = var0.nextLong();
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     var7.reSeed();
//     double var10 = var7.nextT(0.7838376650545498d);
//     double var13 = var7.nextBeta(5.070966519753761E-7d, 5251.203041428764d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 818120085);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 862908985188605553L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.12093859940736357d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.527243700696169E-9d);
// 
//   }

  public void test108() {}
//   public void test108() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test108"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.log(Double.NaN, (-4096.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test109"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(0.7337278513253938d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test110"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
    double var4 = var3.getNumericalMean();
    int var5 = var3.getSupportUpperBound();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var7 = var3.inverseCumulativeProbability(566.2637592611346d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);

  }

  public void test111() {}
//   public void test111() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test111"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     boolean var1 = var0.nextBoolean();
//     var0.clear();
//     org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
//     long var6 = var3.nextSecureLong(10L, 13L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 13L);
// 
//   }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test112"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
    int var4 = var3.getPopulationSize();
    double var6 = var3.upperCumulativeProbability(1);
    double var7 = var3.getNumericalVariance();
    double var9 = var3.cumulativeProbability(10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var12 = var3.cumulativeProbability(100455827, 12);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test113"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(0.4816756918203273d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0L);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test114"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    var0.reSeed(13L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var6 = var0.nextUniform((-0.3926164465348356d), Double.NaN, true);
      fail("Expected exception of type org.apache.commons.math3.exception.NotANumberException");
    } catch (org.apache.commons.math3.exception.NotANumberException e) {
      // Expected exception.
    }

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test115"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test116"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)2.153382805962634d, (java.lang.Number)102400.0d, false);

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test117"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test118() {}
//   public void test118() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test118"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test119"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.7838376650545498d, 0.4816756918203273d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.17951371858610488d));

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test120"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    int[] var1 = null;
    var0.setSeed(var1);
    var0.setSeed(100L);
    int var5 = var0.nextInt();
    long var6 = var0.nextLong();
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    boolean var8 = var0.nextBoolean();
    boolean var9 = var0.nextBoolean();
    int var10 = var0.nextInt();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 818120085);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 862908985188605553L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-1946542504));

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test121"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Object[] var7 = new java.lang.Object[] { (short)(-1)};
    org.apache.commons.math3.exception.NotFiniteNumberException var8 = new org.apache.commons.math3.exception.NotFiniteNumberException(var4, (java.lang.Number)0, var7);
    org.apache.commons.math3.exception.MathIllegalArgumentException var9 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, var7);
    org.apache.commons.math3.exception.MathIllegalArgumentException var10 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, var7);
    org.apache.commons.math3.exception.NotFiniteNumberException var11 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)(-2.4101262393242226E-6d), var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test122"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(55.24586419897384d, 5.079938978466521E45d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 55.24586419897384d);

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test123"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.42628059715133865d, var2, false);

  }

  public void test124() {}
//   public void test124() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test124"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int[] var1 = null;
//     var0.setSeed(var1);
//     var0.setSeed(100L);
//     int var5 = var0.nextInt();
//     long var6 = var0.nextLong();
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     var7.reSeed();
//     var7.reSeed();
//     int var13 = var7.nextHypergeometric(818120085, 98, 146899547);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var17 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
//     double var19 = var17.probability(0);
//     boolean var20 = var17.isSupportConnected();
//     int var21 = var7.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var17);
//     var7.reSeed(2819L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 818120085);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 862908985188605553L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0);
// 
//   }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test125"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)2.302585092994046d);

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test126"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(0.7309575981987914d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.012757616781038683d);

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test127"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(314814153, 16, 146899547);
    int var4 = var3.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test128"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
    double var4 = var3.getNumericalMean();
    int var5 = var3.sample();
    int var6 = var3.sample();
    int var7 = var3.getSupportLowerBound();
    int var8 = var3.getPopulationSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 12);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test129"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
    int var4 = var3.getPopulationSize();
    double var6 = var3.upperCumulativeProbability(1);
    double var7 = var3.getNumericalVariance();
    int var8 = var3.sample();
    int var9 = var3.getSampleSize();
    int var10 = var3.getSampleSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test130"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var5 = var0.nextCauchy((-699.7827128954451d), 100.0d);
    var0.reSeedSecure(10L);
    double var11 = var0.nextUniform(0.9999999958776927d, 57.29577951308232d, false);
    long var14 = var0.nextLong(48L, 4864L);
    double var17 = var0.nextGaussian(4.9E-324d, 0.8406398270218143d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var20 = var0.nextLong(864L, 0L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-729.2529703881293d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 54.75212864082803d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 864L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.4989420673958102d);

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test131"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(short)(-1), (java.lang.Number)0.7336545584598283d, false);
    boolean var5 = var4.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test132"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test133"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var5 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(short)0, (java.lang.Number)2275.2336411793885d, false);
    java.lang.Object[] var6 = new java.lang.Object[] { var5};
    org.apache.commons.math3.exception.NotFiniteNumberException var7 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)60.446553428065656d, var6);
    org.apache.commons.math3.exception.MathIllegalArgumentException var8 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test134"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    org.apache.commons.math3.random.RandomDataImpl var3 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var7 = var3.nextUniform(2664.984414458164d, (-580.8143408160142d), true);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test135() {}
//   public void test135() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test135"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int[] var1 = null;
//     var0.setSeed(var1);
//     var0.setSeed(100L);
//     int var5 = var0.nextInt();
//     long var6 = var0.nextLong();
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     var7.reSeed();
//     double var10 = var7.nextT(0.7838376650545498d);
//     double var12 = var7.nextExponential(0.043865248283487694d);
//     java.lang.String var14 = var7.nextSecureHexString(12);
//     double var17 = var7.nextGaussian((-11570.013065502968d), 3599.641648418025d);
//     java.util.Collection var18 = null;
//     java.lang.Object[] var20 = var7.nextSample(var18, 16);
// 
//   }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test136"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    java.lang.Object[] var9 = new java.lang.Object[] { (short)(-1)};
    org.apache.commons.math3.exception.NotFiniteNumberException var10 = new org.apache.commons.math3.exception.NotFiniteNumberException(var6, (java.lang.Number)0, var9);
    org.apache.commons.math3.exception.MathIllegalArgumentException var11 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var5, var9);
    org.apache.commons.math3.exception.NotFiniteNumberException var12 = new org.apache.commons.math3.exception.NotFiniteNumberException(var3, (java.lang.Number)0.5364627384899132d, var9);
    org.apache.commons.math3.exception.NotFiniteNumberException var13 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Number)1.0f, var9);
    org.apache.commons.math3.exception.MathInternalError var14 = new org.apache.commons.math3.exception.MathInternalError(var0, var9);
    org.apache.commons.math3.exception.util.ExceptionContext var15 = var14.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test137"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(0.9999102672187471d, 4.741450291257945d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9999102672187471d);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test138"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees((-0.013396175220330939d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.7675443017426985d));

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test139"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var5 = var0.nextCauchy((-699.7827128954451d), 100.0d);
    var0.reSeedSecure(10L);
    long var9 = var0.nextPoisson(4815.223910021246d);
    var0.reSeedSecure(0L);
    long var13 = var0.nextPoisson(1.5707963267948966d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var16 = var0.nextInt(1239612384, 10);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-729.2529703881293d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 4864L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 2L);

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test140"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    int var5 = var0.nextZipf(1, 54.75212864082803d);
    double var8 = var0.nextUniform(1.1368683772161603E-13d, 60.446553428065656d);
    double var10 = var0.nextExponential(5000.132733919664d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 57.71535528726942d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 3558.3737562600018d);

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test141"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var5 = var0.nextCauchy((-699.7827128954451d), 100.0d);
    var0.reSeedSecure(10L);
    long var9 = var0.nextPoisson(4815.223910021246d);
    var0.reSeedSecure(0L);
    long var13 = var0.nextPoisson(1.5707963267948966d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var16 = var0.nextBinomial(1239612384, 2.440814502246278d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-729.2529703881293d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 4864L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 2L);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test142"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
    int var4 = var3.getPopulationSize();
    double var6 = var3.upperCumulativeProbability(1);
    double var8 = var3.upperCumulativeProbability((-1023));
    int var9 = var3.getSupportUpperBound();
    double var10 = var3.getNumericalVariance();
    int var11 = var3.getNumberOfSuccesses();
    var3.reseedRandomGenerator(2372L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test143"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint((-4096.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-4096.0d));

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test144"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    int var5 = var0.nextZipf(1, 54.75212864082803d);
    double var8 = var0.nextBeta(3600.0d, 0.39846065982359696d);
    int var12 = var0.nextHypergeometric(110704524, 0, 22);
    double var14 = var0.nextExponential(2181.9579684095393d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSecureAlgorithm("hi!", "org.apache.commons.math3.exception.OutOfRangeException: 10 out of [10, 10] range");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.9999999132172324d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 8030.162769330424d);

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test145"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    java.lang.Object[] var9 = new java.lang.Object[] { (short)(-1)};
    org.apache.commons.math3.exception.NotFiniteNumberException var10 = new org.apache.commons.math3.exception.NotFiniteNumberException(var6, (java.lang.Number)0, var9);
    org.apache.commons.math3.exception.MathIllegalArgumentException var11 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var5, var9);
    org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException(var4, var9);
    org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException(var3, var9);
    org.apache.commons.math3.exception.MathInternalError var14 = new org.apache.commons.math3.exception.MathInternalError(var2, var9);
    org.apache.commons.math3.exception.MathIllegalStateException var15 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, var9);
    org.apache.commons.math3.exception.MathInternalError var16 = new org.apache.commons.math3.exception.MathInternalError(var0, var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test146"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-523), (java.lang.Number)0.3208414170352252d, false);
    boolean var4 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test147() {}
//   public void test147() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test147"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     boolean var1 = var0.nextBoolean();
//     var0.clear();
//     double var3 = var0.nextDouble();
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var7 = var4.nextInt(16, 10);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.48728718083468747d);
// 
//   }

  public void test148() {}
//   public void test148() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test148"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     boolean var1 = var0.nextBoolean();
//     var0.clear();
//     double var3 = var0.nextDouble();
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     int var7 = var4.nextSecureInt(1, 22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.16067107473230147d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 9);
// 
//   }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test149"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var5 = var0.nextCauchy((-699.7827128954451d), 100.0d);
    double var8 = var0.nextGaussian(6896.287303290861d, 63.38748545037136d);
    int var11 = var0.nextBinomial(513171738, 0.9206773132104868d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-729.2529703881293d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 6970.274656128737d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 472453751);

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test150"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
    double var4 = var3.getNumericalMean();
    double var6 = var3.cumulativeProbability(818120085);
    var3.reseedRandomGenerator(2372L);
    var3.reseedRandomGenerator(57L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var12 = var3.sample(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test151"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
    double var4 = var3.getNumericalMean();
    int var5 = var3.sample();
    double var7 = var3.upperCumulativeProbability(56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test152"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)10, (java.lang.Number)10.0f, (java.lang.Number)(short)10);
    java.lang.Number var5 = var4.getHi();
    java.lang.Number var6 = var4.getLo();
    java.lang.Number var7 = var4.getArgument();
    java.lang.Number var8 = var4.getLo();
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    java.lang.Number var11 = null;
    org.apache.commons.math3.exception.util.Localizable var12 = null;
    org.apache.commons.math3.exception.util.Localizable var14 = null;
    org.apache.commons.math3.exception.util.Localizable var16 = null;
    org.apache.commons.math3.exception.util.Localizable var17 = null;
    java.lang.Object[] var20 = new java.lang.Object[] { (short)(-1)};
    org.apache.commons.math3.exception.NotFiniteNumberException var21 = new org.apache.commons.math3.exception.NotFiniteNumberException(var17, (java.lang.Number)0, var20);
    org.apache.commons.math3.exception.MathIllegalArgumentException var22 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var16, var20);
    org.apache.commons.math3.exception.NotFiniteNumberException var23 = new org.apache.commons.math3.exception.NotFiniteNumberException(var14, (java.lang.Number)0.5364627384899132d, var20);
    org.apache.commons.math3.exception.NotFiniteNumberException var24 = new org.apache.commons.math3.exception.NotFiniteNumberException(var12, (java.lang.Number)1.0f, var20);
    org.apache.commons.math3.exception.NotFiniteNumberException var25 = new org.apache.commons.math3.exception.NotFiniteNumberException(var10, var11, var20);
    org.apache.commons.math3.exception.MathIllegalStateException var26 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var9, var20);
    org.apache.commons.math3.exception.MathIllegalStateException var27 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (short)10+ "'", var5.equals((short)10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 10.0f+ "'", var6.equals(10.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (short)10+ "'", var7.equals((short)10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 10.0f+ "'", var8.equals(10.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test153"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(3600.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test154"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(2760.9511701939477d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2761.0d);

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test155"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextUniform(0.0d, 1.6481544285300044E22d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 6.73725415751987E21d);

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test156"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(1.1368683772161603E-13d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1368683772161603E-13d);

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test157"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
    double var4 = var3.getNumericalMean();
    int var5 = var3.sample();
    int var6 = var3.sample();
    int var7 = var3.getPopulationSize();
    int var8 = var3.getSupportUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);

  }

  public void test158() {}
//   public void test158() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test158"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int[] var1 = null;
//     var0.setSeed(var1);
//     var0.setSeed(100L);
//     int var5 = var0.nextInt();
//     long var6 = var0.nextLong();
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     var7.reSeed(10L);
//     double var12 = var7.nextF(5.070965234019122E-7d, 1006.9465292964504d);
//     long var15 = var7.nextSecureLong(90L, 94L);
//     long var18 = var7.nextSecureLong(0L, 17L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 818120085);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 862908985188605553L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 92L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 17L);
// 
//   }

  public void test159() {}
//   public void test159() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test159"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log1p(Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test160() {}
//   public void test160() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test160"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int[] var1 = null;
//     var0.setSeed(var1);
//     var0.setSeed(100L);
//     int var5 = var0.nextInt();
//     long var6 = var0.nextLong();
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     var7.reSeed();
//     double var10 = var7.nextT(0.7838376650545498d);
//     int var13 = var7.nextSecureInt((-1023), 10);
//     long var15 = var7.nextPoisson(3680.7382205113386d);
//     var7.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 818120085);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 862908985188605553L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.4973313582014299d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-304));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 3753L);
// 
//   }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test161"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-17.76076974417489d), (java.lang.Number)2.302585092994046d, false);
    java.lang.Number var4 = var3.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (-17.76076974417489d)+ "'", var4.equals((-17.76076974417489d)));

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test162"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs((-346));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 346);

  }

  public void test163() {}
//   public void test163() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test163"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     boolean var1 = var0.nextBoolean();
//     var0.clear();
//     float var3 = var0.nextFloat();
//     var0.clear();
//     var0.setSeed(12);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     var0.clear();
//     var0.setSeed(16L);
//     boolean var11 = var0.nextBoolean();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.094938755f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == true);
// 
//   }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test164"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(71L);

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test165"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(4.78782785634617d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.0d);

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test166"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
    double var4 = var3.getNumericalMean();
    int var5 = var3.sample();
    int var6 = var3.sample();
    int var7 = var3.getSupportLowerBound();
    double var8 = var3.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);

  }

  public void test167() {}
//   public void test167() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test167"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     boolean var1 = var0.nextBoolean();
//     var0.clear();
//     float var3 = var0.nextFloat();
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var5 = var0.nextGaussian();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.92712975f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.7446444250736252d);
// 
//   }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test168"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var3);
    org.apache.commons.math3.random.RandomDataImpl var5 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var3);
    org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(0);
    boolean var8 = var7.nextBoolean();
    long var10 = var7.nextLong(10L);
    byte[] var11 = new byte[] { };
    var7.nextBytes(var11);
    var3.nextBytes(var11);
    var1.nextBytes(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test169"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var6 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var2, (java.lang.Number)4815.223910021246d, (java.lang.Number)10.0d, false);
    boolean var7 = var6.getBoundIsAllowed();
    java.lang.Throwable[] var8 = var6.getSuppressed();
    java.lang.Throwable[] var9 = var6.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var10 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)566.2637592611346d, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.util.ExceptionContext var12 = var11.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test170"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
    int var4 = var3.getPopulationSize();
    double var6 = var3.upperCumulativeProbability(1);
    double var7 = var3.getNumericalVariance();
    int var8 = var3.getNumberOfSuccesses();
    int var9 = var3.sample();
    boolean var10 = var3.isSupportConnected();
    double var13 = var3.cumulativeProbability(0, 11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test171"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)1L);
    boolean var2 = var1.getBoundIsAllowed();
    boolean var3 = var1.getBoundIsAllowed();
    java.lang.Number var4 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0+ "'", var4.equals(0));

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test172"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(5.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.0d);

  }

  public void test173() {}
//   public void test173() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test173"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextUniform((-1.5574077246549023d), 11013.232874703393d);
//     var0.reSeed();
//     org.apache.commons.math3.random.RandomGenerator var5 = var0.getRandomGenerator();
//     org.apache.commons.math3.random.RandomDataImpl var6 = new org.apache.commons.math3.random.RandomDataImpl(var5);
//     double var8 = var6.nextChiSquare(7254.222364425498d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 8408.602854895853d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 7340.344282109487d);
// 
//   }

  public void test174() {}
//   public void test174() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test174"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextUniform((-1.5574077246549023d), 11013.232874703393d);
//     var0.reSeed();
//     var0.reSeed(100L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var9 = var0.nextLong(1L, 1L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 10108.065328563856d);
// 
//   }

  public void test175() {}
//   public void test175() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test175"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Number var3 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)699.000000558915d, (java.lang.Number)5.070965234019339E-7d, var3);
//     org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var4);
// 
//   }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test176"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)10, (java.lang.Number)10.0f, (java.lang.Number)(short)10);
    java.lang.Number var4 = var3.getHi();
    java.lang.Number var5 = var3.getHi();
    org.apache.commons.math3.exception.MathInternalError var6 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (short)10+ "'", var4.equals((short)10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (short)10+ "'", var5.equals((short)10));

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test177"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    int[] var1 = null;
    var0.setSeed(var1);
    var0.setSeed(100L);
    int var5 = var0.nextInt();
    long var6 = var0.nextLong();
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    var7.reSeedSecure((-1L));
    java.lang.String var11 = var7.nextHexString(56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 818120085);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 862908985188605553L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "f002f5fe5939b741d89e7a0bddd61cc8fd8c86c6ab4d36279f1f1baf"+ "'", var11.equals("f002f5fe5939b741d89e7a0bddd61cc8fd8c86c6ab4d36279f1f1baf"));

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test178"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
    int var4 = var3.getPopulationSize();
    double var6 = var3.upperCumulativeProbability(1);
    double var7 = var3.getNumericalVariance();
    double var9 = var3.cumulativeProbability(10);
    int[] var11 = var3.sample(56);
    org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(var11);
    var12.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test179() {}
//   public void test179() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test179"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int[] var1 = null;
//     var0.setSeed(var1);
//     var0.setSeed(100L);
//     int var5 = var0.nextInt();
//     long var6 = var0.nextLong();
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     var7.reSeed();
//     var7.reSeed();
//     double var12 = var7.nextGaussian((-699.0d), 5428.269407301349d);
//     double var16 = var7.nextUniform(0.0d, 5.07096651975376E-7d, false);
//     int var20 = var7.nextHypergeometric(1433907990, 0, 818120085);
//     long var22 = var7.nextPoisson(10748.09353874134d);
//     var7.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 818120085);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 862908985188605553L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-10027.329094061923d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1.0044379215011857E-7d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 10582L);
// 
//   }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test180"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)0.04383714613469767d, (java.lang.Number)0.094938755f, true);

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test181"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)0.39846065982359696d);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test182"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var5 = var0.nextCauchy((-699.7827128954451d), 100.0d);
    var0.reSeedSecure(10L);
    long var9 = var0.nextPoisson(4815.223910021246d);
    double var12 = var0.nextUniform(0.0d, 5.070965234019122E-7d);
    java.lang.String var14 = var0.nextHexString(205977278);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-729.2529703881293d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 4864L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 3.598218254096089E-7d);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test183"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(8440.19807688283d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 483587.7280598201d);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test184"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(0.105135076f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.4505806E-9f);

  }

  public void test185() {}
//   public void test185() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test185"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     boolean var1 = var0.nextBoolean();
//     var0.clear();
//     float var3 = var0.nextFloat();
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var6 = var4.nextT(57.29577951308232d);
//     var4.reSeedSecure();
//     var4.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.6853914f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1.6014224655002613d));
// 
//   }

  public void test186() {}
//   public void test186() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test186"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextUniform(0.8266245477794862d, 1.4831081961289019d);
//     int var6 = var0.nextInt((-523), 11);
//     int var9 = var0.nextSecureInt((-1946542504), 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.3201585421468545d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-277));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1511724577));
// 
//   }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test187"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)1L);
    org.apache.commons.math3.exception.MathInternalError var2 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var1);
    org.apache.commons.math3.exception.NumberIsTooLargeException var6 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)1.2252628283577319E-304d, (java.lang.Number)102400.0d, false);
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    java.lang.Number var8 = null;
    java.lang.Number var9 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var11 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var7, var8, var9, false);
    java.lang.Number var12 = var11.getMin();
    var6.addSuppressed((java.lang.Throwable)var11);
    var2.addSuppressed((java.lang.Throwable)var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test188"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(0.25713405203159173d, 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1053.2210771213997d);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test189"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(92L, 51L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 92L);

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test190"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(0.0d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test191"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(5251.203041428764d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test192() {}
//   public void test192() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test192"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     boolean var1 = var0.nextBoolean();
//     var0.clear();
//     double var3 = var0.nextDouble();
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     java.lang.String var6 = var4.nextSecureHexString(1);
//     double var8 = var4.nextChiSquare(0.7309575981987914d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var4.nextInt(777026012, (-304));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.18317467995937609d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "2"+ "'", var6.equals("2"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.002359270810622542d);
// 
//   }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test193"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(52L);
    var1.setSeed(0L);

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test194"); }


    double var2 = org.apache.commons.math3.util.FastMath.min((-11570.013065502968d), 1.5660768339053222d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-11570.013065502968d));

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test195"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
    int var4 = var3.getPopulationSize();
    double var6 = var3.upperCumulativeProbability(1);
    double var7 = var3.getNumericalVariance();
    int var8 = var3.getSampleSize();
    int var9 = var3.getNumberOfSuccesses();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test196"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs((-1511724577));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1511724577);

  }

  public void test197() {}
//   public void test197() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test197"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int[] var1 = null;
//     var0.setSeed(var1);
//     var0.setSeed(100L);
//     int var5 = var0.nextInt();
//     long var6 = var0.nextLong();
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     var7.reSeedSecure((-1L));
//     org.apache.commons.math3.distribution.RealDistribution var10 = null;
//     double var11 = var7.nextInversionDeviate(var10);
// 
//   }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test198"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Object[] var7 = new java.lang.Object[] { (short)(-1)};
    org.apache.commons.math3.exception.NotFiniteNumberException var8 = new org.apache.commons.math3.exception.NotFiniteNumberException(var4, (java.lang.Number)0, var7);
    org.apache.commons.math3.exception.MathIllegalArgumentException var9 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, var7);
    org.apache.commons.math3.exception.NotFiniteNumberException var10 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)12.229789172123647d, var7);
    org.apache.commons.math3.exception.MathIllegalArgumentException var11 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, var7);
    org.apache.commons.math3.exception.MathIllegalArgumentException var12 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test199"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-4));
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextUniform(7.655930097516513E-4d, 0.8266245477794862d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.3289478138419481d);

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test200"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(0.57205045f, 39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.14488062E11f);

  }

  public void test201() {}
//   public void test201() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test201"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int[] var1 = null;
//     var0.setSeed(var1);
//     var0.setSeed(100L);
//     int var5 = var0.nextInt();
//     long var6 = var0.nextLong();
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
//     double var12 = var11.getNumericalMean();
//     int var13 = var11.sample();
//     int var14 = var11.sample();
//     int var15 = var7.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var11);
//     var7.reSeed();
//     java.util.Collection var17 = null;
//     java.lang.Object[] var19 = var7.nextSample(var17, 2147483647);
// 
//   }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test202"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(2.302585092994046d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.743980336957493d);

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test203"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(0.45464742f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test204() {}
//   public void test204() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test204"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     boolean var1 = var0.nextBoolean();
//     var0.clear();
//     double var3 = var0.nextDouble();
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var7 = var4.nextInt(22, (-1946542504));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.8661129288344127d);
// 
//   }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test205"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(0.23792781f, 0.053849697f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.23792781f);

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test206"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(10312.44413501291d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test207() {}
//   public void test207() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test207"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextUniform((-1.5574077246549023d), 11013.232874703393d);
//     var0.reSeed();
//     org.apache.commons.math3.random.RandomGenerator var5 = var0.getRandomGenerator();
//     org.apache.commons.math3.random.RandomDataImpl var6 = new org.apache.commons.math3.random.RandomDataImpl(var5);
//     double var9 = var6.nextUniform(4.696046811967199d, 4955.65320817631d);
//     double var11 = var6.nextChiSquare(7477.480004530905d);
//     var6.reSeed(93L);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var17 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
//     int var18 = var17.getPopulationSize();
//     double var20 = var17.upperCumulativeProbability(1);
//     double var21 = var17.getNumericalVariance();
//     double var23 = var17.cumulativeProbability(10);
//     int var24 = var6.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 4567.476839560251d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2058.3976831655614d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 7548.43903330616d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0);
// 
//   }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test208"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil((-1.5574077246549023d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test209"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var5 = var0.nextCauchy((-699.7827128954451d), 100.0d);
    double var8 = var0.nextGaussian(6896.287303290861d, 63.38748545037136d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var0.nextChiSquare((-0.17951371858610488d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-729.2529703881293d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 6970.274656128737d);

  }

  public void test210() {}
//   public void test210() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test210"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int[] var1 = null;
//     var0.setSeed(var1);
//     var0.setSeed(100L);
//     int var5 = var0.nextInt();
//     long var6 = var0.nextLong();
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     var7.reSeed();
//     var7.reSeed();
//     int var13 = var7.nextHypergeometric(818120085, 98, 146899547);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var17 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
//     double var19 = var17.probability(0);
//     boolean var20 = var17.isSupportConnected();
//     int var21 = var7.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var17);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var24 = var7.nextSecureLong(71L, 13L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 818120085);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 862908985188605553L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0);
// 
//   }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test211"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var5 = var0.nextCauchy((-699.7827128954451d), 100.0d);
    var0.reSeedSecure(10L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var10 = var0.nextInt(16, 11);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-729.2529703881293d));

  }

  public void test212() {}
//   public void test212() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test212"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     boolean var1 = var0.nextBoolean();
//     var0.clear();
//     double var3 = var0.nextDouble();
//     int var5 = var0.nextInt(37);
//     boolean var6 = var0.nextBoolean();
//     double var7 = var0.nextDouble();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.49544660421001874d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.016120851915797596d);
// 
//   }

  public void test213() {}
//   public void test213() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test213"); }
// 
// 
//     org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
//     double var5 = var3.probability(0);
//     boolean var6 = var3.isSupportConnected();
//     int var7 = var3.sample();
//     double var8 = var3.getNumericalMean();
//     double var9 = var3.getNumericalVariance();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.0d);
// 
//   }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test214"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextDouble();
    var1.setSeed(4864L);
    var1.setSeed((-304));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9775554539871507d);

  }

  public void test215() {}
//   public void test215() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test215"); }
// 
// 
//     org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
//     double var5 = var3.probability(0);
//     boolean var6 = var3.isSupportConnected();
//     int var7 = var3.sample();
//     int[] var9 = var3.sample(11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
// 
//   }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test216"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)39, (java.lang.Number)3680.7382205113386d, true);
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var3.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test217"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(5188.0104672658235d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test218() {}
//   public void test218() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test218"); }
// 
// 
//     org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(314814153, 16, 146899547);
//     int var4 = var3.sample();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 10);
// 
//   }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test219"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
    int var4 = var3.getPopulationSize();
    double var6 = var3.upperCumulativeProbability(1);
    double var9 = var3.cumulativeProbability(22, 22);
    int var10 = var3.getPopulationSize();
    int var11 = var3.getSupportUpperBound();
    int var12 = var3.getSampleSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);

  }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test220"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.0d, 10231.09454128264d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test221"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    int var5 = var0.nextZipf(1, 54.75212864082803d);
    double var8 = var0.nextBeta(3600.0d, 0.39846065982359696d);
    int var11 = var0.nextBinomial(110704524, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.9999999132172324d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test222"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(483587.7280598201d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test223() {}
//   public void test223() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test223"); }
// 
// 
//     int[] var0 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     var1.setSeed((-1L));
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     org.apache.commons.math3.random.Well19937c var5 = new org.apache.commons.math3.random.Well19937c();
//     boolean var6 = var5.nextBoolean();
//     var5.clear();
//     float var8 = var5.nextFloat();
//     org.apache.commons.math3.random.RandomDataImpl var9 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var5);
//     org.apache.commons.math3.random.Well19937c var10 = new org.apache.commons.math3.random.Well19937c();
//     int[] var11 = null;
//     var10.setSeed(var11);
//     var10.setSeed(100L);
//     int[] var18 = new int[] { 0, 0, (-1)};
//     var10.setSeed(var18);
//     var5.setSeed(var18);
//     var1.setSeed(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.4560318f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
// 
//   }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test224"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(0.012817571192011178d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.012900068351909072d);

  }

  public void test225() {}
//   public void test225() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test225"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(0L, 2L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
// 
//   }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test226"); }


    double var1 = org.apache.commons.math3.util.FastMath.acos(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5707963267948966d);

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test227"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(Float.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test228() {}
//   public void test228() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test228"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     boolean var1 = var0.nextBoolean();
//     var0.clear();
//     double var3 = var0.nextDouble();
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     java.lang.String var6 = var4.nextSecureHexString(1);
//     double var8 = var4.nextChiSquare(0.7309575981987914d);
//     double var11 = var4.nextBeta(4955.65320817631d, 1.5660768339053222d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var4.nextExponential(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.10365119990186167d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "c"+ "'", var6.equals("c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.4219534228855866d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.9997630695300573d);
// 
//   }

  public void test229() {}
//   public void test229() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test229"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextUniform((-1.5574077246549023d), 11013.232874703393d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("f002f5fe5939b741d89e7a0bddd61cc8fd8c86c6ab4d36279f1f1baf", "3fea5e983cb7");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 10951.88583556443d);
// 
//   }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test230"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    var0.reSeed(13L);
    int var5 = var0.nextPascal(12, 0.0d);
    double var9 = var0.nextUniform((-17.76076974417489d), 51.84967536015832d, false);
    double var11 = var0.nextChiSquare(4985.0230236268335d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var13 = var0.nextExponential(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 13.29426052891811d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 5019.582346786739d);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test231"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test232"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(1.6481544285300042E22d, 1.0599323982683158d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.6481544285300042E22d);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test233"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var5 = var0.nextCauchy((-699.7827128954451d), 100.0d);
    var0.reSeedSecure(10L);
    double var11 = var0.nextUniform(0.9999999958776927d, 57.29577951308232d, false);
    double var14 = var0.nextGamma(1.5614616939372625d, 4842.37128619779d);
    double var16 = var0.nextExponential(0.8077174135942793d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-729.2529703881293d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 54.75212864082803d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 8223.904456775725d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.3166649822958307d);

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test234"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.68616164f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test235() {}
//   public void test235() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test235"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int[] var1 = null;
//     var0.setSeed(var1);
//     var0.setSeed(100L);
//     int var5 = var0.nextInt();
//     long var6 = var0.nextLong();
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     var7.reSeed();
//     var7.reSeed();
//     int var13 = var7.nextHypergeometric(818120085, 98, 146899547);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var17 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
//     double var19 = var17.probability(0);
//     boolean var20 = var17.isSupportConnected();
//     int var21 = var7.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var17);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var24 = var7.nextBeta(5428.269407301349d, (-20.096831793142314d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 818120085);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 862908985188605553L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0);
// 
//   }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test236"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(8408.602854895853d, 0.5446694115309465d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.5707315515379165d);

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test237"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
    int var4 = var3.getPopulationSize();
    double var6 = var3.upperCumulativeProbability(1);
    double var9 = var3.cumulativeProbability(22, 22);
    int var10 = var3.getPopulationSize();
    int var11 = var3.getSupportUpperBound();
    double var12 = var3.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test238"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(0.28850019650325276d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.005035278321632392d);

  }

  public void test239() {}
//   public void test239() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test239"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     long var3 = var0.nextSecureLong(0L, 100L);
//     double var7 = var0.nextUniform(0.569420848330462d, 1.5614616939372625d, false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 43L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.1659976529101401d);
// 
//   }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test240"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(0.4699362606514058d, 2734.492055584669d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-10.479527179948583d));

  }

  public void test241() {}
//   public void test241() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test241"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextUniform((-1.5574077246549023d), 11013.232874703393d);
//     var0.reSeed();
//     var0.reSeed(1L);
//     double var9 = var0.nextBeta(100.0d, 4815.223910021246d);
//     double var11 = var0.nextChiSquare(60.446553428065656d);
//     var0.reSeedSecure(862908985188605553L);
//     double var16 = var0.nextWeibull(0.25713405203159173d, 0.016120851915797596d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 233.48094993261464d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.01749082497330633d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 55.24586419897384d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1.6993351403909247d);
// 
//   }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test242"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(8251.632939607316d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test243"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(0.26656938f, 0.7086221f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.26656938f);

  }

  public void test244() {}
//   public void test244() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test244"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     boolean var1 = var0.nextBoolean();
//     var0.clear();
//     var0.setSeed((-1023));
//     var0.setSeed(818120085);
//     float var7 = var0.nextFloat();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.3276757f);
// 
//   }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test245"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    int[] var1 = null;
    var0.setSeed(var1);
    var0.setSeed(100L);
    int var5 = var0.nextInt();
    long var6 = var0.nextLong();
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    var7.reSeed(10L);
    double var12 = var7.nextF(5.070965234019122E-7d, 1006.9465292964504d);
    double var15 = var7.nextBeta(7063.601114532782d, 4.741450291257945d);
    var7.reSeedSecure();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 818120085);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 862908985188605553L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.9997515182738776d);

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test246"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var5 = var0.nextCauchy((-699.7827128954451d), 100.0d);
    var0.reSeedSecure(10L);
    long var9 = var0.nextPoisson(4815.223910021246d);
    var0.reSeedSecure(0L);
    int var14 = var0.nextBinomial(22, 0.0d);
    var0.reSeedSecure(102400L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-729.2529703881293d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 4864L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test247"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(1.1368683772161603E-13d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1368683772161603E-13d);

  }

  public void test248() {}
//   public void test248() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test248"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int[] var1 = null;
//     var0.setSeed(var1);
//     var0.setSeed(100L);
//     int var5 = var0.nextInt();
//     long var6 = var0.nextLong();
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     var7.reSeed();
//     double var10 = var7.nextT(0.7838376650545498d);
//     int var13 = var7.nextSecureInt((-1023), 10);
//     int[] var16 = var7.nextPermutation(98, 11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 818120085);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 862908985188605553L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.44281641949083705d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-790));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
// 
//   }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test249"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    int[] var1 = null;
    var0.setSeed(var1);
    var0.setSeed(100L);
    int var5 = var0.nextInt();
    long var6 = var0.nextLong();
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    boolean var8 = var0.nextBoolean();
    boolean var9 = var0.nextBoolean();
    int[] var13 = new int[] { 100, (-1), 0};
    var0.setSeed(var13);
    double var15 = var0.nextDouble();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 818120085);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 862908985188605553L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.4874321750209638d);

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test250"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(314814153, 16, 146899547);
    double var4 = var3.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 7.465969142753249d);

  }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test251"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
    double var4 = var3.getNumericalMean();
    double var6 = var3.cumulativeProbability(818120085);
    var3.reseedRandomGenerator(2372L);
    int var9 = var3.getSampleSize();
    int var11 = var3.inverseCumulativeProbability(5.07096651975376E-7d);
    int var12 = var3.sample();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);

  }

  public void test252() {}
//   public void test252() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test252"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextUniform((-1.5574077246549023d), 11013.232874703393d);
//     var0.reSeed();
//     org.apache.commons.math3.random.RandomGenerator var5 = var0.getRandomGenerator();
//     org.apache.commons.math3.random.RandomDataImpl var6 = new org.apache.commons.math3.random.RandomDataImpl(var5);
//     var6.reSeedSecure((-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 7439.8422236430815d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
// 
//   }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test253"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(0.10513509f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.10513509f);

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test254"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians((-1.3216319964342262d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.023066829837483205d));

  }

  public void test255() {}
//   public void test255() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test255"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextUniform((-1.5574077246549023d), 11013.232874703393d);
//     var0.reSeed();
//     int var7 = var0.nextInt(12, 98);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("", "3fea5e983cb7");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3449.797240030672d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 85);
// 
//   }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test256"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
    int var4 = var3.getPopulationSize();
    double var6 = var3.upperCumulativeProbability(1);
    int var7 = var3.getSupportUpperBound();
    double var9 = var3.probability((-127));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);

  }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test257"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.26669969365787255d, (java.lang.Number)0.16468322f, true);
    org.apache.commons.math3.exception.NumberIsTooLargeException var8 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)1.2252628283577319E-304d, (java.lang.Number)102400.0d, false);
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    java.lang.Number var10 = null;
    java.lang.Number var11 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var13 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var9, var10, var11, false);
    java.lang.Number var14 = var13.getMin();
    var8.addSuppressed((java.lang.Throwable)var13);
    var4.addSuppressed((java.lang.Throwable)var8);
    org.apache.commons.math3.exception.MathInternalError var17 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test258"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(0.9775554539871507d, (-0.9746281154291627d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.9775554539871507d));

  }

  public void test259() {}
//   public void test259() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test259"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextUniform(0.8266245477794862d, 1.4831081961289019d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("5b6c396732", "3fea5e983cb7");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.4217322973491209d);
// 
//   }

  public void test260() {}
//   public void test260() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test260"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextUniform((-1.5574077246549023d), 11013.232874703393d);
//     var0.reSeed();
//     org.apache.commons.math3.random.RandomGenerator var5 = var0.getRandomGenerator();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var8 = var0.nextPascal(205977278, 8.609805374599405d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 9456.619189160861d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
// 
//   }

  public void test261() {}
//   public void test261() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test261"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     boolean var1 = var0.nextBoolean();
//     var0.clear();
//     double var3 = var0.nextDouble();
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     var0.setSeed(10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.6372169360618245d);
// 
//   }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test262"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(296.5312447637706d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test263"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(4985.0230236268335d, 0.6547536468207042d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4985.0230236268335d);

  }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test264"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(864L);

  }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test265"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
    double var4 = var3.getNumericalMean();
    double var6 = var3.cumulativeProbability(818120085);
    double var7 = var3.getNumericalVariance();
    int var8 = var3.getSampleSize();
    var3.reseedRandomGenerator((-809800820540421050L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test266"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(1190.6076761276186d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1191.0d);

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test267"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(1.5706366414653359d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.003838765202994d);

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test268"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(-1.3407807929942286E154d));

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test269"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.105135076f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-4));

  }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test270"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    int[] var1 = null;
    var0.setSeed(var1);
    var0.setSeed(100L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var6 = var0.nextLong(0L);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test271() {}
//   public void test271() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test271"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     boolean var1 = var0.nextBoolean();
//     var0.clear();
//     double var3 = var0.nextDouble();
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     java.lang.String var6 = var4.nextSecureHexString(1);
//     long var9 = var4.nextLong((-809800820540421050L), 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.6788887773419665d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "3"+ "'", var6.equals("3"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-226129617501886581L));
// 
//   }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test272"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
    double var4 = var3.getNumericalMean();
    double var6 = var3.cumulativeProbability(818120085);
    var3.reseedRandomGenerator(2372L);
    int var9 = var3.getNumberOfSuccesses();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test273"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(Double.NEGATIVE_INFINITY, 5251.203041428764d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.POSITIVE_INFINITY);

  }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test274"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(8223.904456775725d, 0.027415567780803774d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 8223.904456775723d);

  }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test275"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(1.6896826985536354E27d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.6896826985536354E27d);

  }

  public void test276() {}
//   public void test276() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test276"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextUniform((-1.5574077246549023d), 11013.232874703393d);
//     var0.reSeed();
//     org.apache.commons.math3.random.RandomGenerator var5 = var0.getRandomGenerator();
//     org.apache.commons.math3.random.RandomDataImpl var6 = new org.apache.commons.math3.random.RandomDataImpl(var5);
//     double var9 = var6.nextUniform(4.696046811967199d, 4955.65320817631d);
//     double var11 = var6.nextChiSquare(7477.480004530905d);
//     int var14 = var6.nextSecureInt(0, 818217249);
//     double var17 = var6.nextBeta(6853.595675476031d, 8440.19807688283d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 6343.243940816261d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2856.5741914286514d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 7564.84575294329d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 500457600);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.4452068561502894d);
// 
//   }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test277"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(12);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    long var5 = var2.nextLong(44L, 4864L);
    double var8 = var2.nextGaussian(714.486947643189d, 12.229789172123647d);
    double var11 = var2.nextWeibull(8926.338134378722d, 8.301344566699161E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2372L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 714.20578211514d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 8.300971167714308E-8d);

  }

  public void test278() {}
//   public void test278() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test278"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     boolean var1 = var0.nextBoolean();
//     var0.clear();
//     org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var7 = var3.nextUniform(0.3289478138419481d, 6853.595675476031d, false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1458.654240945818d);
// 
//   }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test279"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.743980336957493d, 73.61607252966621d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 73.61983184872712d);

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test280"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var5 = var0.nextCauchy((-699.7827128954451d), 100.0d);
    org.apache.commons.math3.random.RandomGenerator var6 = var0.getRandomGenerator();
    var0.reSeedSecure();
    var0.reSeed((-809800820540421050L));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var12 = var0.nextGamma(5428.269407301349d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-729.2529703881293d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test281() {}
//   public void test281() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test281"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     boolean var1 = var0.nextBoolean();
//     var0.clear();
//     double var3 = var0.nextDouble();
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     java.lang.String var6 = var4.nextSecureHexString(1);
//     double var8 = var4.nextChiSquare(0.7309575981987914d);
//     double var10 = var4.nextChiSquare(8.301344566699161E-8d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.03394116244800527d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "9"+ "'", var6.equals("9"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2.5657760368017617d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.0d);
// 
//   }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test282"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(8.300971167714308E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.448792779897331E-9d);

  }

  public void test283() {}
//   public void test283() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test283"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextUniform((-1.5574077246549023d), 11013.232874703393d);
//     var0.reSeed();
//     org.apache.commons.math3.random.RandomGenerator var5 = var0.getRandomGenerator();
//     double var8 = var0.nextF(6.944245010486608E-8d, 4914.984534854888d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 8827.019396945561d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.9668070200239503E-9d);
// 
//   }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test284"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.4393086791491494d, (java.lang.Number)1.6481544285300044E22d, false);

  }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test285"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    var1.setSeed((-1L));
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var6 = var1.nextLong(10582L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 8855L);

  }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test286"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    boolean var2 = var1.nextBoolean();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test287() {}
//   public void test287() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test287"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(10L);
//     double var5 = var0.nextCauchy((-699.7827128954451d), 100.0d);
//     var0.reSeedSecure(10L);
//     double var11 = var0.nextUniform(0.9999999958776927d, 57.29577951308232d, false);
//     double var14 = var0.nextGaussian(1.225262833408642E-304d, 1.0d);
//     var0.reSeedSecure();
//     var0.reSeed();
//     int var19 = var0.nextPascal(54, 0.3905499213360595d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var21 = var0.nextT((-1.3581577268388338d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-729.2529703881293d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 54.75212864082803d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-2.6649762425333257d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 83);
// 
//   }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test288"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var5 = var0.nextCauchy((-699.7827128954451d), 100.0d);
    double var8 = var0.nextGamma(0.7923558499802232d, 1.2252628283577319E-304d);
    var0.reSeed((-1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-729.2529703881293d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 3.1960696488861985E-304d);

  }

  public void test289() {}
//   public void test289() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test289"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextUniform((-1.5574077246549023d), 11013.232874703393d);
//     var0.reSeed();
//     org.apache.commons.math3.random.RandomGenerator var5 = var0.getRandomGenerator();
//     org.apache.commons.math3.random.RandomDataImpl var6 = new org.apache.commons.math3.random.RandomDataImpl(var5);
//     double var9 = var6.nextUniform(4.696046811967199d, 4955.65320817631d);
//     double var11 = var6.nextChiSquare(7477.480004530905d);
//     var6.reSeed(93L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var17 = var6.nextHypergeometric((-624), 0, 19);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 368.029263835097d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 170.8188445580729d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 7416.165161975935d);
// 
//   }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test290"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int var3 = var1.nextInt(100455827);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 74192438);

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test291"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    var0.reSeed(13L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var5 = var0.nextPermutation(10, (-1));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test292() {}
//   public void test292() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test292"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int[] var1 = null;
//     var0.setSeed(var1);
//     var0.setSeed(100L);
//     int var5 = var0.nextInt();
//     long var6 = var0.nextLong();
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     var7.reSeed();
//     var7.reSeed();
//     int var13 = var7.nextHypergeometric(818120085, 98, 146899547);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var17 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
//     double var19 = var17.probability(0);
//     boolean var20 = var17.isSupportConnected();
//     int var21 = var7.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var17);
//     double var25 = var7.nextUniform((-6612.714485975319d), 2275.2336411793885d, true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 818120085);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 862908985188605553L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == (-4930.474195962135d));
// 
//   }

  public void test293() {}
//   public void test293() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test293"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed(13L);
//     double var5 = var0.nextWeibull(1.5707899264686505d, 9263.640859542764d);
//     var0.reSeed();
//     double var8 = var0.nextT(1458.654240945818d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 5061.9280334995965d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-0.011458668911658781d));
// 
//   }

  public void test294() {}
//   public void test294() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test294"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(6439.0462019649585d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test295"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.9997515182738776d);

  }

  public void test296() {}
//   public void test296() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test296"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.log(0.0d, 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test297"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)0.017453292483969377d);

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test298"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.027415567780803774d);
    java.lang.Number var2 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0+ "'", var2.equals(0));

  }

  public void test299() {}
//   public void test299() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test299"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh(1.448792779897331E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test300"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
    double var4 = var3.getNumericalMean();
    int var5 = var3.sample();
    int var6 = var3.sample();
    int var7 = var3.getSupportLowerBound();
    int var8 = var3.getSupportUpperBound();
    double var10 = var3.probability(205977278);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);

  }

  public void test301() {}
//   public void test301() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test301"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(7400.302272421626d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test302"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(1.5588443417110756d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.159491538383606d);

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test303"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(0.68616164f, 0.7564535f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.7564535f);

  }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test304"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.4393086791491494d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.4393086791491494d);

  }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test305"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(48L);

  }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test306"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var5 = var0.nextCauchy((-699.7827128954451d), 100.0d);
    var0.reSeedSecure(10L);
    double var11 = var0.nextUniform(0.9999999958776927d, 57.29577951308232d, false);
    double var14 = var0.nextGaussian(1.225262833408642E-304d, 1.0d);
    var0.reSeedSecure();
    double var18 = var0.nextWeibull(0.355743491272146d, 63.38748545037136d);
    double var21 = var0.nextUniform((-17.575286498503647d), 1053.2210771213997d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-729.2529703881293d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 54.75212864082803d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == (-2.6649762425333257d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 296.5312447637706d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 313.8215497349619d);

  }

  public void test307() {}
//   public void test307() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test307"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c();
//     boolean var4 = var3.nextBoolean();
//     var3.clear();
//     float var6 = var3.nextFloat();
//     java.lang.Object[] var7 = new java.lang.Object[] { var6};
//     org.apache.commons.math3.exception.MathIllegalArgumentException var8 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, var7);
//     org.apache.commons.math3.exception.MathInternalError var9 = new org.apache.commons.math3.exception.MathInternalError(var1, var7);
//     org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var0, var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.2347976f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
// 
//   }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test308"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
    int var4 = var3.getPopulationSize();
    double var6 = var3.upperCumulativeProbability(1);
    double var7 = var3.getNumericalVariance();
    int var8 = var3.getNumberOfSuccesses();
    int var9 = var3.sample();
    boolean var10 = var3.isSupportConnected();
    int var12 = var3.inverseCumulativeProbability(0.33712995310036376d);
    double var14 = var3.probability(98);
    int var15 = var3.getPopulationSize();
    int[] var17 = var3.sample(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test309"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Object[] var6 = new java.lang.Object[] { (short)(-1)};
    org.apache.commons.math3.exception.NotFiniteNumberException var7 = new org.apache.commons.math3.exception.NotFiniteNumberException(var3, (java.lang.Number)0, var6);
    org.apache.commons.math3.exception.MathIllegalArgumentException var8 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, var6);
    org.apache.commons.math3.exception.NotFiniteNumberException var9 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)6.73725415751987E21d, var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test310"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(0.3289478138419481d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.38950534075016535d);

  }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test311"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var10 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(short)0, (java.lang.Number)2275.2336411793885d, false);
    java.lang.Object[] var11 = new java.lang.Object[] { var10};
    org.apache.commons.math3.exception.NotFiniteNumberException var12 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)60.446553428065656d, var11);
    org.apache.commons.math3.exception.NotFiniteNumberException var13 = new org.apache.commons.math3.exception.NotFiniteNumberException(var4, (java.lang.Number)(-4096.0d), var11);
    org.apache.commons.math3.exception.NotFiniteNumberException var14 = new org.apache.commons.math3.exception.NotFiniteNumberException(var2, (java.lang.Number)17.574668067145332d, var11);
    org.apache.commons.math3.exception.NotFiniteNumberException var15 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, var1, var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test312"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(6.047909608775628E-6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0L);

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test313"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(0.012818273171627077d, 7439.8422236430815d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.012818273171627077d);

  }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test314"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.15704548f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-3));

  }

  public void test315() {}
//   public void test315() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test315"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     boolean var1 = var0.nextBoolean();
//     var0.clear();
//     org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var6 = var3.nextLong(862908985188605553L, 1L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == true);
// 
//   }

  public void test316() {}
//   public void test316() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test316"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     long var3 = var0.nextSecureLong(0L, 100L);
//     double var6 = var0.nextGaussian((-0.8414709848078965d), 54.75212864082803d);
//     int var9 = var0.nextZipf(1, 4985.0230236268335d);
//     double var11 = var0.nextExponential(6439.0462019649585d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 70L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 23.952642260549254d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1157.8570678262859d);
// 
//   }

  public void test317() {}
//   public void test317() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test317"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.pow(5000.132733919664d, 185451434);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test318() {}
//   public void test318() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test318"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     long var3 = var0.nextSecureLong(0L, 100L);
//     org.apache.commons.math3.random.RandomGenerator var4 = var0.getRandomGenerator();
//     double var7 = var0.nextCauchy((-0.8414709848078965d), 5428.269407301349d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var0.nextHypergeometric(205977278, 513171738, 98);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 62L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 4838.355060798481d);
// 
//   }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test319"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(2761.0d, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2761.0d);

  }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test320"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-4));
    long var2 = var1.nextLong();
    double var3 = var1.nextGaussian();
    var1.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7330420552690794710L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.39054402182936837d);

  }

  public void test321() {}
//   public void test321() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test321"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextUniform((-1.5574077246549023d), 11013.232874703393d);
//     var0.reSeed();
//     org.apache.commons.math3.random.RandomGenerator var5 = var0.getRandomGenerator();
//     int var8 = var0.nextInt(22, 818120085);
//     double var11 = var0.nextF(4842.37128619779d, 0.28850019650325276d);
//     double var14 = var0.nextUniform(3.714998727304537E-24d, 3.598218254096089E-7d);
//     long var16 = var0.nextPoisson(1.5268888156225198d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var20 = var0.nextHypergeometric((-127), 39, 1);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 4072.6737514078786d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 794326986);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.5802636728725137d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.622940955498137E-7d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1L);
// 
//   }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test322"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)6970.274656128737d);
    java.lang.Number var3 = var2.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));

  }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test323"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(44L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 44L);

  }

  public void test324() {}
//   public void test324() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test324"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextUniform((-1.5574077246549023d), 11013.232874703393d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var6 = var0.nextInt(11, (-127));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 8520.788364660566d);
// 
//   }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test325"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    int[] var1 = null;
    var0.setSeed(var1);
    var0.setSeed(100L);
    org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
    var0.setSeed(9L);

  }

  public void test326() {}
//   public void test326() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test326"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int[] var1 = null;
//     var0.setSeed(var1);
//     var0.setSeed(100L);
//     int var5 = var0.nextInt();
//     long var6 = var0.nextLong();
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     var7.reSeed();
//     var7.reSeed();
//     java.lang.String var11 = var7.nextSecureHexString(12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 818120085);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 862908985188605553L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "892fd7af8317"+ "'", var11.equals("892fd7af8317"));
// 
//   }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test327"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(7439.8422236430815d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 19.521862154631936d);

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test328"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.4874321750209638d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test329() {}
//   public void test329() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test329"); }
// 
// 
//     org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
//     double var5 = var3.probability(0);
//     boolean var6 = var3.isSupportConnected();
//     double var7 = var3.getNumericalMean();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.0d);
// 
//   }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test330"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(0.38950534075016535d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.4762503723409001d);

  }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test331"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(0.012900068351909072d, 0.012817571192011178d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.012817571192011178d);

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test332"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)0.28850019650325276d, (java.lang.Number)992.5737239346395d, true);

  }

  public void test333() {}
//   public void test333() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test333"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextUniform((-1.5574077246549023d), 11013.232874703393d);
//     var0.reSeed();
//     var0.reSeed(0L);
//     int var9 = var0.nextPascal(12, 1.225262833408642E-304d);
//     int var12 = var0.nextSecureInt(0, 100);
//     var0.reSeedSecure();
//     long var16 = var0.nextSecureLong(57L, 2372L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 10349.504076564352d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 560L);
// 
//   }

  public void test334() {}
//   public void test334() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test334"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextUniform((-1.5574077246549023d), 11013.232874703393d);
//     var0.reSeed();
//     var0.reSeed(0L);
//     int var9 = var0.nextPascal(12, 1.225262833408642E-304d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var0.nextSecureInt(818120085, 16);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 9096.701412035629d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2147483647);
// 
//   }

  public void test335() {}
//   public void test335() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test335"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int[] var1 = null;
//     var0.setSeed(var1);
//     var0.setSeed(100L);
//     int var5 = var0.nextInt();
//     long var6 = var0.nextLong();
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     var7.reSeed();
//     var7.reSeed();
//     double var12 = var7.nextBeta(55.24586419897384d, 4815.223910021246d);
//     double var15 = var7.nextGamma(7063.601114532783d, 1.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var18 = var7.nextBinomial(36, 1.2514299156985669d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 818120085);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 862908985188605553L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.009606586131005046d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 7015.023480102328d);
// 
//   }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test336"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
    double var4 = var3.getNumericalMean();
    double var6 = var3.cumulativeProbability(818120085);
    var3.reseedRandomGenerator(2372L);
    var3.reseedRandomGenerator(57L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var12 = var3.sample((-1946542504));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);

  }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test337"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var5 = var0.nextCauchy((-699.7827128954451d), 100.0d);
    var0.reSeedSecure(10L);
    long var9 = var0.nextPoisson(4815.223910021246d);
    double var11 = var0.nextExponential(5428.269407301349d);
    int var14 = var0.nextPascal(1890823379, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-729.2529703881293d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 4864L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2275.2336411793885d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2147483647);

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test338"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    java.lang.Object[] var9 = new java.lang.Object[] { (short)(-1)};
    org.apache.commons.math3.exception.NotFiniteNumberException var10 = new org.apache.commons.math3.exception.NotFiniteNumberException(var6, (java.lang.Number)0, var9);
    org.apache.commons.math3.exception.MathIllegalArgumentException var11 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var5, var9);
    org.apache.commons.math3.exception.NotFiniteNumberException var12 = new org.apache.commons.math3.exception.NotFiniteNumberException(var3, (java.lang.Number)0.5364627384899132d, var9);
    java.lang.Throwable[] var13 = var12.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var14 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)7254.222364425498d, (java.lang.Object[])var13);
    org.apache.commons.math3.exception.NotFiniteNumberException var15 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)0.5364627384899132d, (java.lang.Object[])var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test339"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var5 = var0.nextCauchy((-699.7827128954451d), 100.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var8 = var0.nextZipf((-523), 51.84967536015832d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-729.2529703881293d));

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test340"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var5 = var0.nextCauchy((-699.7827128954451d), 100.0d);
    var0.reSeedSecure(10L);
    double var11 = var0.nextUniform(0.9999999958776927d, 57.29577951308232d, false);
    double var14 = var0.nextGaussian(1.225262833408642E-304d, 1.0d);
    double var17 = var0.nextGamma(1.6481544285300042E22d, 13.29426052891811d);
    var0.reSeed(0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-729.2529703881293d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 54.75212864082803d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == (-2.6649762425333257d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 2.1910994364832767E23d);

  }

  public void test341() {}
//   public void test341() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test341"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed(13L);
//     var0.reSeed();
//     int var6 = var0.nextSecureInt(98, 2147483647);
//     double var8 = var0.nextT(12.229789172123647d);
//     var0.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 883316441);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 3.032323097227393d);
// 
//   }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test342"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(16384.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 16384.002f);

  }

  public void test343() {}
//   public void test343() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test343"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-4));
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextGaussian(0.0d, 0.007616141650040061d);
//     java.util.Collection var6 = null;
//     java.lang.Object[] var8 = var2.nextSample(var6, 55);
// 
//   }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test344"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(0.4560318f, 0.9577712f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9577712f);

  }

  public void test345() {}
//   public void test345() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test345"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     boolean var1 = var0.nextBoolean();
//     var0.clear();
//     float var3 = var0.nextFloat();
//     var0.clear();
//     var0.setSeed(12);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var9 = var7.nextT(5.2193E-320d);
//     double var11 = var7.nextExponential(6.944245010486608E-8d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.74191153f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.0573776999657965E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2.640938699545163E-8d);
// 
//   }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test346"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(0.8406398270218143d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9432075667418472d);

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test347"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(17.574668067145332d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4);

  }

  public void test348() {}
//   public void test348() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test348"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int[] var1 = null;
//     var0.setSeed(var1);
//     var0.setSeed(100L);
//     org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var8 = var5.nextWeibull(2761.0d, 4971.100933318636d);
//     int var11 = var5.nextSecureInt(1, 818217249);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 4968.3030846774545d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 164960414);
// 
//   }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test349"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
    int var4 = var3.getPopulationSize();
    double var6 = var3.upperCumulativeProbability(1);
    double var8 = var3.upperCumulativeProbability((-1023));
    int var9 = var3.getSupportUpperBound();
    int var10 = var3.getNumberOfSuccesses();
    int var11 = var3.getNumberOfSuccesses();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);

  }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test350"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(699.000000558915d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 699.0000005589151d);

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test351"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(8.609805374599405d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.060969767939367d));

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test352"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-4));
    long var2 = var1.nextLong();
    org.apache.commons.math3.random.RandomDataImpl var3 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var5 = var3.nextHexString(2147483647);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7330420552690794710L);

  }

  public void test353() {}
//   public void test353() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test353"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int[] var1 = null;
//     var0.setSeed(var1);
//     double var3 = var0.nextGaussian();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-0.3494764431512303d));
// 
//   }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test354"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)1L);
    org.apache.commons.math3.exception.MathInternalError var2 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var1);
    org.apache.commons.math3.exception.MathInternalError var3 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var2);
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var2.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test355() {}
//   public void test355() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test355"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int[] var1 = null;
//     var0.setSeed(var1);
//     var0.setSeed(100L);
//     int var5 = var0.nextInt();
//     long var6 = var0.nextLong();
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     var7.reSeed();
//     var7.reSeed();
//     double var12 = var7.nextGaussian((-699.0d), 5428.269407301349d);
//     double var16 = var7.nextUniform(0.0d, 5.07096651975376E-7d, false);
//     int var20 = var7.nextHypergeometric(1433907990, 0, 818120085);
//     long var22 = var7.nextPoisson(10748.09353874134d);
//     long var24 = var7.nextPoisson(0.7309575981987914d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var28 = var7.nextHypergeometric((-523), (-4), (-127));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 818120085);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 862908985188605553L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-5366.458573495373d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1.6407659298215778E-7d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 10911L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0L);
// 
//   }

  public void test356() {}
//   public void test356() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test356"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     boolean var1 = var0.nextBoolean();
//     var0.clear();
//     float var3 = var0.nextFloat();
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var6 = var4.nextT(57.29577951308232d);
//     var4.reSeedSecure();
//     var4.reSeedSecure(93L);
//     long var12 = var4.nextLong(0L, 1546L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.41775692f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.5469634759649726d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 139L);
// 
//   }

  public void test357() {}
//   public void test357() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test357"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextUniform((-1.5574077246549023d), 11013.232874703393d);
//     var0.reSeed();
//     org.apache.commons.math3.random.RandomGenerator var5 = var0.getRandomGenerator();
//     var0.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 840.5656448339471d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
// 
//   }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test358"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.7446444250736252d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7353289256829704d);

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test359"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)0.34486529307927305d);

  }

  public void test360() {}
//   public void test360() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test360"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     long var3 = var0.nextSecureLong(0L, 100L);
//     double var6 = var0.nextGaussian((-0.8414709848078965d), 54.75212864082803d);
//     double var9 = var0.nextCauchy(4971.100933318636d, 57.29577951308232d);
//     double var12 = var0.nextBeta(0.28850019650325276d, 0.7838376650545498d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 79L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 40.65114604000717d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 4850.14277052147d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1.5122477502077182E-5d);
// 
//   }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test361"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)0.42349623513792045d);

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test362"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    int[] var1 = null;
    var0.setSeed(var1);
    var0.setSeed(100L);
    int var5 = var0.nextInt();
    long var6 = var0.nextLong();
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    var0.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 818120085);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 862908985188605553L);

  }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test363"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(6343.243940816261d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6343.243940816262d);

  }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test364"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(-1.0f));
    org.apache.commons.math3.exception.MathInternalError var3 = new org.apache.commons.math3.exception.MathInternalError();
    var2.addSuppressed((java.lang.Throwable)var3);
    java.lang.String var5 = var3.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "org.apache.commons.math3.exception.MathInternalError: illegal state: internal error, please fill a bug report at https://issues.apache.org/jira/browse/MATH"+ "'", var5.equals("org.apache.commons.math3.exception.MathInternalError: illegal state: internal error, please fill a bug report at https://issues.apache.org/jira/browse/MATH"));

  }

  public void test365() {}
//   public void test365() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test365"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextUniform((-1.5574077246549023d), 11013.232874703393d);
//     var0.reSeed();
//     double var7 = var0.nextUniform(0.027952873673631765d, 0.7838376650545498d);
//     var0.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 4616.552845439479d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.3448685130803916d);
// 
//   }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test366"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    java.lang.Object[] var9 = new java.lang.Object[] { (short)(-1)};
    org.apache.commons.math3.exception.NotFiniteNumberException var10 = new org.apache.commons.math3.exception.NotFiniteNumberException(var6, (java.lang.Number)0, var9);
    org.apache.commons.math3.exception.MathIllegalArgumentException var11 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var5, var9);
    org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException(var4, var9);
    org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException(var3, var9);
    org.apache.commons.math3.exception.MathInternalError var14 = new org.apache.commons.math3.exception.MathInternalError(var2, var9);
    org.apache.commons.math3.exception.NotFiniteNumberException var15 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)5061.9280334995965d, var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test367() {}
//   public void test367() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test367"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     long var3 = var0.nextSecureLong(0L, 100L);
//     double var6 = var0.nextGaussian((-0.8414709848078965d), 54.75212864082803d);
//     double var9 = var0.nextCauchy(4971.100933318636d, 57.29577951308232d);
//     int var12 = var0.nextSecureInt((-1023), 818120085);
//     double var14 = var0.nextExponential(7400.302272421626d);
//     double var17 = var0.nextWeibull(1.0044379215011857E-7d, 5.070965234019339E-7d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 63L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-56.01541346692555d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 4950.783714969341d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 753386476);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 272.30152375087255d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == Double.POSITIVE_INFINITY);
// 
//   }

  public void test368() {}
//   public void test368() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test368"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed(13L);
//     int var5 = var0.nextSecureInt((-1023), 818120085);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var7 = var0.nextExponential((-0.011458668911658781d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 817853899);
// 
//   }

  public void test369() {}
//   public void test369() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test369"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     long var3 = var0.nextSecureLong(0L, 100L);
//     double var6 = var0.nextGaussian((-0.8414709848078965d), 54.75212864082803d);
//     int var9 = var0.nextZipf(1, 4985.0230236268335d);
//     org.apache.commons.math3.random.RandomGenerator var10 = var0.getRandomGenerator();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var0.nextInt(19, (-304));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 55L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 25.87217953800585d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
// 
//   }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test370"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh(0.39846065982359696d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.42181772262635786d);

  }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test371"); }


    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Object[] var7 = new java.lang.Object[] { (short)(-1)};
    org.apache.commons.math3.exception.NotFiniteNumberException var8 = new org.apache.commons.math3.exception.NotFiniteNumberException(var4, (java.lang.Number)0, var7);
    org.apache.commons.math3.exception.MathIllegalArgumentException var9 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, var7);
    org.apache.commons.math3.exception.NotFiniteNumberException var10 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Number)0.5364627384899132d, var7);
    java.lang.Throwable[] var11 = var10.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var12 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)3599.641648418025d, (java.lang.Object[])var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test372"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)1458.654240945818d);

  }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test373"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(8408.602854895853d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 91.69843430994803d);

  }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test374"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(0.54969144f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.9604645E-8f);

  }

  public void test375() {}
//   public void test375() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test375"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     boolean var1 = var0.nextBoolean();
//     var0.clear();
//     var0.setSeed((-1023));
//     var0.setSeed(818120085);
//     int var7 = var0.nextInt();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1407356421);
// 
//   }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test376"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException(var0);
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.lang.Number var3 = null;
    org.apache.commons.math3.exception.NotPositiveException var4 = new org.apache.commons.math3.exception.NotPositiveException(var2, var3);
    boolean var5 = var4.getBoundIsAllowed();
    var1.addSuppressed((java.lang.Throwable)var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test377"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt((-1.3407807929942286E154d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-2.3756689782295585E51d));

  }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test378"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var5 = var0.nextCauchy((-699.7827128954451d), 100.0d);
    double var8 = var0.nextGaussian(6896.287303290861d, 63.38748545037136d);
    double var11 = var0.nextF(11013.232874703393d, 2340.865705580131d);
    double var14 = var0.nextGamma(0.8406398270218143d, 0.8406398270218143d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-729.2529703881293d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 6970.274656128737d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.9403135060181869d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0829533521508252d);

  }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test379"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0L);

  }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test380"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
    int var4 = var3.getPopulationSize();
    double var6 = var3.upperCumulativeProbability(1);
    double var8 = var3.upperCumulativeProbability((-1023));
    double var10 = var3.upperCumulativeProbability(533430167);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);

  }

  public void test381() {}
//   public void test381() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test381"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     boolean var1 = var0.nextBoolean();
//     var0.clear();
//     double var3 = var0.nextDouble();
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     java.lang.String var6 = var4.nextSecureHexString(1);
//     double var8 = var4.nextChiSquare(0.7309575981987914d);
//     double var11 = var4.nextBeta(4955.65320817631d, 1.5660768339053222d);
//     double var13 = var4.nextChiSquare(0.043893404540024376d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.9739211297917667d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "9"+ "'", var6.equals("9"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.026381504864221157d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.9988542188999172d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.040551741730125E-9d);
// 
//   }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test382"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var4 = var2.nextT(5.070965234019122E-7d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var7 = var2.nextLong(862908985188605553L, 0L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1.3407807929942286E154d));

  }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test383"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(7548.43903330616d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0464943341221409d));

  }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test384"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(0.017453292483969377d, 4616.552845439479d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.017453292483969377d);

  }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test385"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(0.68616164f, 7.4505806E-9f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7.4505806E-9f);

  }

}
