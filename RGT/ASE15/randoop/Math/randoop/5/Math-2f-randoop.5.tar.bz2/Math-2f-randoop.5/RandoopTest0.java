
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 11013.232874703393d);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(10.0f, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10240.0f);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1023));

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(100L, 10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10L);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)100.0f);
    java.lang.Number var2 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0+ "'", var2.equals(0));

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(11013.232874703393d, (-1023));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.2252628283577319E-304d);

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.5574077246549023d));

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(10.0d, 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10.0d);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 100);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(100.0d, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 102400.0d);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.NEGATIVE_INFINITY);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var4 = new org.apache.commons.math3.distribution.HypergeometricDistribution(var0, 1, 10, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999999958776927d);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 10);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(10L, 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10L);

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.302585092994046d);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(1.2252628283577319E-304d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-699.7827128954451d));

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(11013.232874703393d, (-1.5574077246549023d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5.070965234019122E-7d);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(5.070965234019122E-7d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 57.29577951308232d);

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(1.2252628283577319E-304d, 0.9999999958776927d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.2252628334086418E-304d);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(0.0f, 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(11013.232874703393d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 10.000000000000002d);

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.8414709848078965d));

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }


    float var2 = org.apache.commons.math3.util.FastMath.max((-1.0f), (-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.0f));

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var3 = var0.nextInt((-1023), (-1023));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh(1.2252628334086418E-304d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2252628334086418E-304d);

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var5 = var0.nextBinomial(0, (-699.7827128954451d));
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(Double.NEGATIVE_INFINITY, 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10.0d);

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(5.070965234019122E-7d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.070965234019339E-7d);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(4815.223910021246d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 12);

  }

  public void test34() {}
//   public void test34() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }
// 
// 
//     double var0 = org.apache.commons.math3.util.FastMath.random();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var0 == 0.5364627384899132d);
// 
//   }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(0.9999999958776927d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999999979388463d);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(1.2252628334086418E-304d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2252628334086418E-304d);

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(10L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(1.2252628334086418E-304d, 4815.223910021246d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.225262833408642E-304d);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var3 = var0.nextZipf((-1), 2.302585092994046d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs((-1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1L);

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }


    org.apache.commons.math3.exception.NotANumberException var0 = new org.apache.commons.math3.exception.NotANumberException();

  }

  public void test42() {}
//   public void test42() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }
// 
// 
//     org.apache.commons.math3.exception.MathInternalError var0 = new org.apache.commons.math3.exception.MathInternalError();
//     java.lang.Throwable var1 = null;
//     var0.addSuppressed(var1);
// 
//   }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign((-1.0f), 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0f);

  }

  public void test44() {}
//   public void test44() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextUniform((-1.5574077246549023d), 11013.232874703393d);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var7 = var0.nextSecureLong(100L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 9059.04176883711d);
// 
//   }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    int[] var1 = null;
    var0.setSeed(var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var4 = var0.nextLong((-1L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(5428.269407301349d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 17.574668067145332d);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var3 = var0.nextLong(1L, (-1L));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(102400.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 12.229789172123647d);

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(0.5364627384899132d, 12.229789172123647d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.04383714613469767d);

  }

  public void test50() {}
//   public void test50() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextUniform((-1.5574077246549023d), 11013.232874703393d);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var6 = var0.nextT((-1.0d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 7133.617342972916d);
// 
//   }

  public void test51() {}
//   public void test51() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(102400.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(0.04383714613469767d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test53() {}
//   public void test53() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.scalb(Double.NaN, (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var5 = var0.nextSecureLong(100L, 10L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(0.0d, 102400.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test56() {}
//   public void test56() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.log((-0.8414709848078965d), (-0.8414709848078965d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.04383714613469767d, 0.9999999958776927d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9999999958776927d);

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var5 = var3.sample(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }


    float var2 = org.apache.commons.math3.util.FastMath.min((-1.0f), 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.0f));

  }

  public void test60() {}
//   public void test60() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextUniform((-1.5574077246549023d), 11013.232874703393d);
//     var0.reSeed();
//     var0.reSeed(1L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("org.apache.commons.math3.exception.OutOfRangeException: 10 out of [10, 10] range", "");
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 7042.522042659457d);
// 
//   }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(1.2252628283577319E-304d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0L);

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.641588833612779d);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(0, 0, 1);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(short)100, (java.lang.Number)100L, false);

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(100, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100);

  }

  public void test66() {}
//   public void test66() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextUniform((-1.5574077246549023d), 11013.232874703393d);
//     java.util.Collection var4 = null;
//     java.lang.Object[] var6 = var0.nextSample(var4, 10);
// 
//   }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(5.070965234019122E-7d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.07096651975376E-7d);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var3 = var0.nextSecureLong(10L, 10L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = var0.nextSecureHexString((-1));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 100);

  }

  public void test72() {}
//   public void test72() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextUniform((-1.5574077246549023d), 11013.232874703393d);
//     var0.reSeed();
//     var0.reSeed(1L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var9 = var0.nextSecureInt(100, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1621.1694240779996d);
// 
//   }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var5 = var0.nextCauchy((-699.7827128954451d), 100.0d);
    var0.reSeedSecure(10L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var10 = var0.nextLong(4864L, (-1L));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-729.2529703881293d));

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(4971.100933318636d, 4.641588833612779d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4971.100933318636d);

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(57.29577951308232d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7336545584598283d);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(0.04383714613469767d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.3581577268388338d));

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0000001f);

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(12.229789172123647d, Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 12.229789172123647d);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var5 = var0.nextCauchy((-699.7827128954451d), 100.0d);
    var0.reSeedSecure(10L);
    double var11 = var0.nextUniform(0.9999999958776927d, 57.29577951308232d, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var13 = var0.nextSecureHexString((-1));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-729.2529703881293d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 54.75212864082803d);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)(short)1, (java.lang.Number)100.0f, (java.lang.Number)0.9999999958776927d);

  }

  public void test81() {}
//   public void test81() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     org.apache.commons.math3.exception.util.Localizable var3 = null;
//     java.lang.Object[] var6 = new java.lang.Object[] { (short)(-1)};
//     org.apache.commons.math3.exception.NotFiniteNumberException var7 = new org.apache.commons.math3.exception.NotFiniteNumberException(var3, (java.lang.Number)0, var6);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var8 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, var6);
//     org.apache.commons.math3.exception.NotFiniteNumberException var9 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)0.5364627384899132d, var6);
//     org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var9);
// 
//   }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)1.0000001f, (java.lang.Number)10, false);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(0.10513508f, 10240.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10240.0f);

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-57.29577951308232d));

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)102400.0d);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0f);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(10.0f, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.999999f);

  }

  public void test88() {}
//   public void test88() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }
// 
// 
//     org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)1.0f);
//     java.lang.Throwable var2 = null;
//     var1.addSuppressed(var2);
// 
//   }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder((-0.5413852756622436d), 0.04383714613469767d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.015339522045871551d));

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(54.75212864082803d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.5707963267948966d);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh((-1.5574077246549023d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.2261911708835171d));

  }

  public void test92() {}
//   public void test92() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     boolean var1 = var0.nextBoolean();
//     double var2 = var0.nextGaussian();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var4 = var0.nextInt((-1));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-1.2637238628728809d));
// 
//   }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(0.7336545584598283d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test95() {}
//   public void test95() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(1.5707963267948966d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(0.9999999958776927d, 1.225262833408642E-304d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.5707963267948966d);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(100L, (-1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100L);

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test99() {}
//   public void test99() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     org.apache.commons.math3.exception.util.Localizable var3 = null;
//     java.lang.Object[] var6 = new java.lang.Object[] { (short)(-1)};
//     org.apache.commons.math3.exception.NotFiniteNumberException var7 = new org.apache.commons.math3.exception.NotFiniteNumberException(var3, (java.lang.Number)0, var6);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var8 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, var6);
//     org.apache.commons.math3.exception.NotFiniteNumberException var9 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)0.5364627384899132d, var6);
//     java.lang.String var10 = var9.toString();
// 
//   }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(1.5707963267948966d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.027415567780803774d);

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(4.641588833612779d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 51.84967536015832d);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(1L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

//  public void test103() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }
//
//
//    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
//    int var4 = var3.getPopulationSize();
//    double var6 = var3.upperCumulativeProbability(1);
//    double var7 = var3.getNumericalVariance();
//    // The following exception was thrown during execution.
//    // This behavior will recorded for regression testing.
//    try {
//      int[] var9 = var3.sample(818120085);
//      fail("Expected exception of type java.lang.OutOfMemoryError");
//    } catch (java.lang.OutOfMemoryError e) {
//      // Expected exception.
//    }
//    
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var4 == 12);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var6 == 0.0d);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var7 == 0.0d);
//
//  }
//
  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(1.225262833408642E-304d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.020238914855607E-303d);

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh((-1.2261911708835171d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.8508157176809257d);

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(51.84967536015832d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.013396175220330939d));

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(94L, 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(2340.865705580131d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.39846065982359696d);

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(5.070965234019339E-7d, 1.225262833408642E-304d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5.070965234019339E-7d);

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(1L, 2L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2L);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp((-1.3581577268388338d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.3581577268388336d));

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(5428.269407301349d, 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5428.269407301349d);

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(57.29577951308232d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 57L);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)10, (java.lang.Number)10.0f, (java.lang.Number)(short)10);
    org.apache.commons.math3.exception.OutOfRangeException var7 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)10, (java.lang.Number)10.0f, (java.lang.Number)(short)10);
    java.lang.Number var8 = var7.getHi();
    java.lang.Number var9 = var7.getLo();
    java.lang.Number var10 = var7.getArgument();
    var3.addSuppressed((java.lang.Throwable)var7);
    java.lang.Number var12 = var3.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (short)10+ "'", var8.equals((short)10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + 10.0f+ "'", var9.equals(10.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + (short)10+ "'", var10.equals((short)10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + (short)10+ "'", var12.equals((short)10));

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(0L, 10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var5 = var0.nextCauchy((-699.7827128954451d), 100.0d);
    org.apache.commons.math3.random.RandomGenerator var6 = var0.getRandomGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSecureAlgorithm("org.apache.commons.math3.exception.OutOfRangeException: 10 out of [10, 10] range", "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-729.2529703881293d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(4815.223910021246d, (-1023));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5.357114422523554E-305d);

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(10240.0f, 818120085);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.POSITIVE_INFINITY);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(51.84967536015832d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999102672187471d);

  }

  public void test122() {}
//   public void test122() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextUniform((-1.5574077246549023d), 11013.232874703393d);
//     var0.reSeed();
//     org.apache.commons.math3.random.RandomGenerator var5 = var0.getRandomGenerator();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var8 = var0.nextPascal((-1), 60.446553428065656d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 9032.14898325533d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
// 
//   }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 10L);

  }

  public void test124() {}
//   public void test124() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextUniform((-1.5574077246549023d), 11013.232874703393d);
//     var0.reSeed();
//     var0.reSeed(0L);
//     var0.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 6896.287303290861d);
// 
//   }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(-1.0d));
    boolean var2 = var1.getBoundIsAllowed();
    java.lang.Number var3 = var1.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + (-1.0d)+ "'", var3.equals((-1.0d)));

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(51.84967536015832d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.6481544285300042E22d);

  }

  public void test127() {}
//   public void test127() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.max(1.6481544285300042E22d, Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(12.470149698897988d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 714.486947643189d);

  }

  public void test130() {}
//   public void test130() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(6970.274656128737d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(51.84967536015832d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 52L);

  }

  public void test132() {}
//   public void test132() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     long var3 = var0.nextSecureLong(0L, 100L);
//     double var6 = var0.nextGaussian((-0.8414709848078965d), 54.75212864082803d);
//     double var9 = var0.nextCauchy(4971.100933318636d, 57.29577951308232d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("hi!", "5b6c396732");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 9.713113778811376d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 5045.183422776908d);
// 
//   }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.10513508f, (-57.29577951308232d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.105135076f);

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(100.0f, Float.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100.0f);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(0.04383714613469767d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.043865248283487694d);

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
    int var4 = var3.getPopulationSize();
    double var6 = var3.upperCumulativeProbability(1);
    double var7 = var3.getNumericalVariance();
    int var8 = var3.sample();
    int var9 = var3.getNumberOfSuccesses();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 100.0d);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(7063.601114532783d, 33.33686274599023d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.5660768339053222d);

  }

  public void test139() {}
//   public void test139() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextUniform((-1.5574077246549023d), 11013.232874703393d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var6 = var0.nextZipf((-1), 10839.51476898481d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 7170.591475014769d);
// 
//   }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(714.486947643189d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1368683772161603E-13d);

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(94L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 94L);

  }

  public void test142() {}
//   public void test142() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(55.24586419897384d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }


    org.apache.commons.math3.exception.MathIllegalStateException var0 = new org.apache.commons.math3.exception.MathIllegalStateException();

  }

  public void test144() {}
//   public void test144() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     long var3 = var0.nextSecureLong(0L, 100L);
//     double var6 = var0.nextGaussian((-0.8414709848078965d), 54.75212864082803d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var9 = var0.nextZipf(0, 1.5660768339053222d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 75L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-13.457501112344206d));
// 
//   }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    int[] var1 = null;
    var0.setSeed(var1);
    var0.setSeed(100L);
    double var5 = var0.nextDouble();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.1904834217843172d);

  }

  public void test146() {}
//   public void test146() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(4.641588833612779d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var5 = var0.nextCauchy((-699.7827128954451d), 100.0d);
    var0.reSeedSecure(10L);
    long var9 = var0.nextPoisson(4815.223910021246d);
    double var12 = var0.nextUniform(0.0d, 5.070965234019122E-7d);
    var0.reSeedSecure(57L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-729.2529703881293d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 4864L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 3.598218254096089E-7d);

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    int[] var1 = null;
    var0.setSeed(var1);
    var0.setSeed(100L);
    int var5 = var0.nextInt();
    long var6 = var0.nextLong();
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var10 = var7.nextPermutation(0, 818120085);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 818120085);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 862908985188605553L);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(51.84967536015832d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.2963088570600084E22d);

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(0.10513508f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.10513509f);

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(3.598218254096089E-7d, 0.9999102672187471d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6.047909608775628E-6d);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var5 = var0.nextCauchy((-699.7827128954451d), 100.0d);
    org.apache.commons.math3.random.RandomGenerator var6 = var0.getRandomGenerator();
    var0.reSeed(1L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var11 = var0.nextInt((-1), (-1023));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-729.2529703881293d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp((-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1920929E-7f);

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var5 = var0.nextCauchy((-699.7827128954451d), 100.0d);
    double var8 = var0.nextGaussian(6896.287303290861d, 63.38748545037136d);
    double var11 = var0.nextF(11013.232874703393d, 2340.865705580131d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var15 = var0.nextHypergeometric((-1), 818120085, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-729.2529703881293d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 6970.274656128737d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.9403135060181869d);

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    int[] var1 = null;
    var0.setSeed(var1);
    var0.setSeed(100L);
    int var5 = var0.nextInt();
    long var6 = var0.nextLong();
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var10 = var7.nextSecureInt(10, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 818120085);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 862908985188605553L);

  }

  public void test156() {}
//   public void test156() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Number var1 = null;
//     java.lang.Number var2 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, var1, var2, false);
//     java.lang.Number var5 = var4.getMin();
//     java.lang.String var6 = var4.toString();
// 
//   }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(57L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 57L);

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(54.75212864082803d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.696046811967199d);

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    int[] var1 = null;
    var0.setSeed(var1);
    var0.setSeed(100L);
    int var5 = var0.nextInt();
    long var6 = var0.nextLong();
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
    double var12 = var11.getNumericalMean();
    int var13 = var11.sample();
    int var14 = var11.sample();
    int var15 = var7.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var11);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.setSecureAlgorithm("org.apache.commons.math3.exception.OutOfRangeException: 10 out of [10, 10] range", "org.apache.commons.math3.exception.OutOfRangeException: 10 out of [10, 10] range");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 818120085);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 862908985188605553L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4E-45f);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1920929E-7f);

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextDouble();
    float var3 = var1.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9775554539871507d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.15595806f);

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(0.10513509f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.4505806E-9f);

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(9.999999f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 10.0f);

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(10240.0f, 0.16468322f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10240.0f);

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(short)(-1));
    java.lang.Number var2 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0+ "'", var2.equals(0));

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(0.9775554539871507d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4831081961289019d);

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var1 = null;
    org.apache.commons.math3.exception.MathInternalError var2 = new org.apache.commons.math3.exception.MathInternalError(var0, var1);
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var2.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    int[] var1 = null;
    var0.setSeed(var1);
    var0.setSeed(100L);
    int var5 = var0.nextInt();
    long var6 = var0.nextLong();
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    var7.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var7.nextChiSquare((-1.2261911708835171d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 818120085);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 862908985188605553L);

  }

  public void test171() {}
//   public void test171() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextUniform((-1.5574077246549023d), 11013.232874703393d);
//     var0.reSeed();
//     org.apache.commons.math3.random.RandomGenerator var5 = var0.getRandomGenerator();
//     int var8 = var0.nextInt(1, 100);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 6853.595675476031d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 22);
// 
//   }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(6853.595675476031d, 0.043865248283487694d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.5707899264686505d);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
    double var4 = var3.getNumericalMean();
    int var5 = var3.sample();
    int var6 = var3.getPopulationSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 12);

  }

  public void test174() {}
//   public void test174() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     boolean var1 = var0.nextBoolean();
//     var0.clear();
//     float var3 = var0.nextFloat();
//     var0.clear();
//     double var5 = var0.nextGaussian();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.48847377f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.42349623513792045d);
// 
//   }

  public void test175() {}
//   public void test175() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos((-1.2261911708835171d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(5.357114422523554E-305d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.357114422523554E-305d);

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    int[] var1 = null;
    var0.setSeed(var1);
    var0.setSeed(100L);
    int var5 = var0.nextInt();
    long var6 = var0.nextLong();
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var11 = var7.nextHypergeometric(22, 22, 818120085);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 818120085);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 862908985188605553L);

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(5.070965234019339E-7d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.070965234019339E-7d);

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)1L, (java.lang.Number)(-1.0d), (java.lang.Number)(byte)0);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil((-699.7827128954451d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-699.0d));

  }

  public void test183() {}
//   public void test183() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(55.24586419897384d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)4815.223910021246d, (java.lang.Number)10.0d, false);
    java.lang.Number var5 = var4.getMax();
    boolean var6 = var4.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 10.0d+ "'", var5.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor((-0.015339522045871551d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(1);

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp((-0.015339522045871551d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.734723475976807E-18d);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    int[] var1 = null;
    var0.setSeed(var1);
    var0.setSeed(100L);
    int var5 = var0.nextInt();
    long var6 = var0.nextLong();
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    var7.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var11 = var7.nextSecureInt(110704524, (-1));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 818120085);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 862908985188605553L);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
    int var4 = var3.getPopulationSize();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var6 = var3.inverseCumulativeProbability(2340.865705580131d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 12);

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(1.1920929E-7f, (-1023));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)(-1));

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(33.33686274599023d, 0.39846065982359696d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.5588443417110756d);

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(0.16468322f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.16468324f);

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(0.043865248283487694d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-3.1266328832448305d));

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)10, (java.lang.Number)10.0f, (java.lang.Number)(short)10);
    org.apache.commons.math3.exception.OutOfRangeException var7 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)10, (java.lang.Number)10.0f, (java.lang.Number)(short)10);
    java.lang.Number var8 = var7.getHi();
    java.lang.Number var9 = var7.getLo();
    java.lang.Number var10 = var7.getArgument();
    var3.addSuppressed((java.lang.Throwable)var7);
    org.apache.commons.math3.exception.MathInternalError var12 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (short)10+ "'", var8.equals((short)10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + 10.0f+ "'", var9.equals(10.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + (short)10+ "'", var10.equals((short)10));

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(5.357114422523554E-305d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.357114422523554E-305d);

  }

  public void test197() {}
//   public void test197() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextUniform((-1.5574077246549023d), 11013.232874703393d);
//     var0.reSeed();
//     var0.reSeed(1L);
//     double var9 = var0.nextBeta(100.0d, 4815.223910021246d);
//     double var11 = var0.nextChiSquare(60.446553428065656d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var0.nextGamma(Double.NEGATIVE_INFINITY, 17.574668067145332d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3981.4942330625163d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.01749082497330633d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 55.24586419897384d);
// 
//   }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0.48847377f);

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10);
    var1.setSeed(100L);

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(0.16468324f, 9.999999f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.16468324f);

  }

  public void test201() {}
//   public void test201() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(4.696046811967199d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    int[] var1 = null;
    var0.setSeed(var1);
    var0.setSeed(100L);
    int var5 = var0.nextInt();
    long var6 = var0.nextLong();
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    var7.reSeed();
    var7.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var12 = var7.nextInt(818120085, 1);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 818120085);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 862908985188605553L);

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(1.5660768339053222d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.2894824375259724d);

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 818120085, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(63.38748545037136d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.6896826985536354E27d);

  }

  public void test206() {}
//   public void test206() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int[] var1 = null;
//     var0.setSeed(var1);
//     var0.setSeed(100L);
//     int var5 = var0.nextInt();
//     long var6 = var0.nextLong();
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     var7.reSeed();
//     java.util.Collection var9 = null;
//     java.lang.Object[] var11 = var7.nextSample(var9, (-1023));
// 
//   }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var5 = var0.nextCauchy((-699.7827128954451d), 100.0d);
    var0.reSeedSecure(10L);
    long var9 = var0.nextPoisson(4815.223910021246d);
    var0.reSeedSecure(0L);
    int var14 = var0.nextBinomial(22, 0.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var17 = var0.nextSecureInt(12, (-1));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-729.2529703881293d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 4864L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(2275.2336411793885d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 8.422985157797855d);

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
    int var4 = var3.getPopulationSize();
    double var6 = var3.upperCumulativeProbability(1);
    double var7 = var3.getNumericalVariance();
    int var8 = var3.sample();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var10 = var3.inverseCumulativeProbability(4971.100933318636d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(1.1368683772161603E-13d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.9842096344226883E-15d);

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(0.0d, 0.027415567780803774d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(1.734723475976807E-18d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-17.76076974417489d));

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var5 = var0.nextCauchy((-699.7827128954451d), 100.0d);
    var0.reSeedSecure(10L);
    long var9 = var0.nextPoisson(4815.223910021246d);
    double var11 = var0.nextExponential(5428.269407301349d);
    int var14 = var0.nextZipf(100, 6.047909608775628E-6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-729.2529703881293d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 4864L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2275.2336411793885d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 56);

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.10513509f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-4));

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var5 = var0.nextCauchy((-699.7827128954451d), 100.0d);
    var0.reSeedSecure(10L);
    double var11 = var0.nextUniform(0.9999999958776927d, 57.29577951308232d, false);
    int var14 = var0.nextInt(10, 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-729.2529703881293d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 54.75212864082803d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 39);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    int[] var1 = null;
    var0.setSeed(var1);
    var0.setSeed(100L);
    int var5 = var0.nextInt();
    long var6 = var0.nextLong();
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
    double var12 = var11.getNumericalMean();
    int var13 = var11.sample();
    int var14 = var11.sample();
    int var15 = var7.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var11);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var17 = var7.nextHexString(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 818120085);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 862908985188605553L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    java.lang.Object[] var8 = new java.lang.Object[] { (short)(-1)};
    org.apache.commons.math3.exception.NotFiniteNumberException var9 = new org.apache.commons.math3.exception.NotFiniteNumberException(var5, (java.lang.Number)0, var8);
    org.apache.commons.math3.exception.MathIllegalArgumentException var10 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var4, var8);
    org.apache.commons.math3.exception.NotFiniteNumberException var11 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)12.229789172123647d, var8);
    org.apache.commons.math3.exception.NotFiniteNumberException var12 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Number)0.04383714613469767d, var8);
    org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var5 = var0.nextCauchy((-699.7827128954451d), 100.0d);
    double var8 = var0.nextGaussian(6896.287303290861d, 63.38748545037136d);
    double var11 = var0.nextF(11013.232874703393d, 2340.865705580131d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var15 = var0.nextHypergeometric(10, 12, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-729.2529703881293d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 6970.274656128737d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.9403135060181869d);

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var5 = var0.nextCauchy((-699.7827128954451d), 100.0d);
    var0.reSeedSecure(10L);
    long var9 = var0.nextPoisson(4815.223910021246d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var12 = var0.nextPascal((-1), 0.9999999979388463d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-729.2529703881293d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 4864L);

  }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var3 = new java.lang.Object[] { (short)(-1)};
    org.apache.commons.math3.exception.NotFiniteNumberException var4 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)0, var3);
    java.lang.Number var5 = var4.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0+ "'", var5.equals(0));

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp((-3.1266328832448305d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-3.12663288324483d));

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    int[] var1 = null;
    var0.setSeed(var1);
    var0.setSeed(100L);
    int var5 = var0.nextInt();
    long var6 = var0.nextLong();
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
    double var12 = var11.getNumericalMean();
    int var13 = var11.sample();
    int var14 = var11.sample();
    int var15 = var7.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var11);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var17 = var7.nextPoisson(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 818120085);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 862908985188605553L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);

  }

  public void test223() {}
//   public void test223() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     boolean var1 = var0.nextBoolean();
//     var0.clear();
//     float var3 = var0.nextFloat();
//     long var5 = var0.nextLong(57L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.7086221f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 20L);
// 
//   }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Object[] var7 = new java.lang.Object[] { (short)(-1)};
    org.apache.commons.math3.exception.NotFiniteNumberException var8 = new org.apache.commons.math3.exception.NotFiniteNumberException(var4, (java.lang.Number)0, var7);
    org.apache.commons.math3.exception.MathIllegalArgumentException var9 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, var7);
    org.apache.commons.math3.exception.NotFiniteNumberException var10 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Number)0.5364627384899132d, var7);
    org.apache.commons.math3.exception.MathInternalError var11 = new org.apache.commons.math3.exception.MathInternalError(var0, var7);
    org.apache.commons.math3.exception.util.ExceptionContext var12 = var11.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test225() {}
//   public void test225() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     boolean var1 = var0.nextBoolean();
//     var0.clear();
//     double var3 = var0.nextDouble();
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var7 = var4.nextF((-699.0d), 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.16904021254049284d);
// 
//   }

  public void test226() {}
//   public void test226() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int[] var1 = null;
//     var0.setSeed(var1);
//     var0.setSeed(100L);
//     int var5 = var0.nextInt();
//     long var6 = var0.nextLong();
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     var7.reSeed();
//     var7.reSeed();
//     double var12 = var7.nextBeta(55.24586419897384d, 4815.223910021246d);
//     double var15 = var7.nextGamma(7063.601114532783d, 1.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var18 = var7.nextSecureLong(100L, 1L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 818120085);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 862908985188605553L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.009910777150063044d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 7130.970587203454d);
// 
//   }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(Double.NaN);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0L);

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(10839.51476898481d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9.98410068941516d);

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)10, (java.lang.Number)10.0f, (java.lang.Number)(short)10);
    java.lang.Number var4 = var3.getHi();
    java.lang.Number var5 = var3.getLo();
    java.lang.Number var6 = var3.getArgument();
    java.lang.Number var7 = var3.getLo();
    java.lang.Number var8 = var3.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (short)10+ "'", var4.equals((short)10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 10.0f+ "'", var5.equals(10.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (short)10+ "'", var6.equals((short)10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 10.0f+ "'", var7.equals(10.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 10.0f+ "'", var8.equals(10.0f));

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)5.070965234019122E-7d);
    java.lang.Number var2 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0+ "'", var2.equals(0));

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(1.0000001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos((-17.76076974417489d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.463561233724663d);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)55, (java.lang.Number)0.7923558499802232d, true);

  }

  public void test234() {}
//   public void test234() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     long var3 = var0.nextSecureLong(0L, 100L);
//     double var6 = var0.nextGaussian((-0.8414709848078965d), 54.75212864082803d);
//     double var9 = var0.nextCauchy(4971.100933318636d, 57.29577951308232d);
//     double var13 = var0.nextUniform(0.7336545584598283d, 54.75212864082803d, true);
//     var0.reSeedSecure(4864L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 16L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-20.096831793142318d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 4914.984534854888d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 12.724845994604195d);
// 
//   }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(7.4505806E-9f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.4505815E-9f);

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(57.29577951308232d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.741450291257945d);

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(6439.0462019649585d, 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5.079938978466521E45d);

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(1.9842096344226883E-15d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.9842096344226883E-15d);

  }

  public void test239() {}
//   public void test239() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     boolean var1 = var0.nextBoolean();
//     var0.clear();
//     double var3 = var0.nextDouble();
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     java.lang.String var6 = var4.nextSecureHexString(1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var4.nextBeta(1.9842096344226883E-15d, (-1.0d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.006365012818492444d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "6"+ "'", var6.equals("6"));
// 
//   }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(100L, 862908985188605553L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100L);

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Object[] var7 = new java.lang.Object[] { (short)(-1)};
    org.apache.commons.math3.exception.NotFiniteNumberException var8 = new org.apache.commons.math3.exception.NotFiniteNumberException(var4, (java.lang.Number)0, var7);
    org.apache.commons.math3.exception.MathIllegalArgumentException var9 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, var7);
    org.apache.commons.math3.exception.NotFiniteNumberException var10 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)12.229789172123647d, var7);
    org.apache.commons.math3.exception.NotFiniteNumberException var11 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)1346.8722274727033d, var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(818120085);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 818120085);

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(7063.601114532783d, 0.9999102672187471d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7063.601114532782d);

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
    int var4 = var3.getPopulationSize();
    double var6 = var3.upperCumulativeProbability(1);
    double var7 = var3.getNumericalVariance();
    int var9 = var3.inverseCumulativeProbability(1.9842096344226883E-15d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }


    double var2 = org.apache.commons.math3.util.FastMath.max((-1.3581577268388338d), (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.0d));

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(0.7086221f, 1.1920929E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.7086221f);

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
    double var4 = var3.getNumericalMean();
    double var6 = var3.cumulativeProbability(818120085);
    var3.reseedRandomGenerator(2372L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var10 = var3.inverseCumulativeProbability(1.6896826985536354E27d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-0.5413852756622436d), (java.lang.Number)0.7838376650545498d, true);
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    int[] var1 = null;
    var0.setSeed(var1);
    var0.setSeed(100L);
    int var5 = var0.nextInt();
    long var6 = var0.nextLong();
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    var7.reSeed(10L);
    double var12 = var7.nextCauchy(3.598218254096089E-7d, 0.3905499213360595d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var15 = var7.nextBinomial(0, (-17.76076974417489d));
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 818120085);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 862908985188605553L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-0.1150957076333865d));

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    var0.reSeed(13L);
    double var5 = var0.nextWeibull(1.5707899264686505d, 9263.640859542764d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var0.nextBeta(1.0d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
    } catch (org.apache.commons.math3.exception.NoBracketingException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 5061.9280334995965d);

  }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(0.4699362606514058d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.4393086791491494d);

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(8703.735538471214d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 93.29381296994573d);

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(3.2963088570600084E22d, 6.047909608775628E-6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-2.410126239324223E-6d));

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);

  }

  public void test256() {}
//   public void test256() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextUniform((-1.5574077246549023d), 11013.232874703393d);
//     var0.reSeed();
//     var0.reSeed(100L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("e", "e");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 8579.95475250597d);
// 
//   }

  public void test257() {}
//   public void test257() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(10L);
//     double var5 = var0.nextCauchy((-699.7827128954451d), 100.0d);
//     org.apache.commons.math3.random.RandomGenerator var6 = var0.getRandomGenerator();
//     var0.reSeed(1L);
//     java.lang.String var10 = var0.nextSecureHexString(10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var0.nextUniform(6896.287303290861d, 5.357114422523554E-305d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-729.2529703881293d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "4a3e09ea0a"+ "'", var10.equals("4a3e09ea0a"));
// 
//   }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(4914.984534854888d, 4914.984534854888d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4914.984534854888d);

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var5 = var0.nextCauchy((-699.7827128954451d), 100.0d);
    var0.reSeedSecure(10L);
    long var9 = var0.nextPoisson(4815.223910021246d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var12 = var0.nextGamma(2275.2336411793885d, (-6612.714485975319d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-729.2529703881293d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 4864L);

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(7063.601114532783d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.26669969365787255d);

  }

  public void test262() {}
//   public void test262() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(566.2637592611346d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test263() {}
//   public void test263() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int[] var1 = null;
//     var0.setSeed(var1);
//     var0.setSeed(100L);
//     int var5 = var0.nextInt();
//     long var6 = var0.nextLong();
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     var7.reSeed();
//     double var10 = var7.nextT(0.7838376650545498d);
//     double var12 = var7.nextExponential(0.043865248283487694d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var7.nextBinomial(12, 12.724845994604195d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 818120085);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 862908985188605553L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-4.826716866469137d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.006417465716145985d);
// 
//   }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var2.nextUniform(11013.232874703393d, 1.9842096344226883E-15d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
    int var4 = var3.getPopulationSize();
    double var6 = var3.upperCumulativeProbability(1);
    double var7 = var3.getNumericalVariance();
    int var8 = var3.getNumberOfSuccesses();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var10 = var3.inverseCumulativeProbability(12.470149698897988d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
    int var4 = var3.getPopulationSize();
    double var6 = var3.upperCumulativeProbability(1);
    double var8 = var3.upperCumulativeProbability((-1023));
    int var9 = var3.sample();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(1.141116379249869d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0682304897585864d);

  }

  public void test268() {}
//   public void test268() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     long var3 = var0.nextSecureLong(0L, 100L);
//     double var6 = var0.nextGaussian((-0.8414709848078965d), 54.75212864082803d);
//     double var9 = var0.nextCauchy(4971.100933318636d, 57.29577951308232d);
//     double var13 = var0.nextUniform(0.7336545584598283d, 54.75212864082803d, true);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var17 = var0.nextHypergeometric(56, (-1), 55);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 97L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 24.868039739713645d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 4949.151718362076d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 23.781953172674037d);
// 
//   }

  public void test269() {}
//   public void test269() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextUniform((-1.5574077246549023d), 11013.232874703393d);
//     var0.reSeed();
//     var0.reSeed(1L);
//     double var9 = var0.nextBeta(100.0d, 4815.223910021246d);
//     double var11 = var0.nextChiSquare(60.446553428065656d);
//     var0.reSeedSecure(862908985188605553L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var0.nextPascal(98, (-3.12663288324483d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 426.5094677183288d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.01749082497330633d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 55.24586419897384d);
// 
//   }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(1.2252628334086418E-304d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-699.7827128913228d));

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-3.1266328832448305d), var1, false);
    java.lang.Number var4 = var3.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test272() {}
//   public void test272() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(10L);
//     double var5 = var0.nextCauchy((-699.7827128954451d), 100.0d);
//     var0.reSeedSecure(10L);
//     long var9 = var0.nextPoisson(4815.223910021246d);
//     var0.reSeedSecure(0L);
//     int var14 = var0.nextBinomial(22, 0.0d);
//     java.util.Collection var15 = null;
//     java.lang.Object[] var17 = var0.nextSample(var15, 0);
// 
//   }

  public void test273() {}
//   public void test273() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     long var3 = var0.nextSecureLong(0L, 100L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var6 = var0.nextSecureInt(818120085, 10);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 96L);
// 
//   }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(0.3905499213360595d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7309575981987914d);

  }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)1L);
    org.apache.commons.math3.exception.MathInternalError var2 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var1);
    boolean var3 = var1.getBoundIsAllowed();
    java.lang.Number var4 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0+ "'", var4.equals(0));

  }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(0.4393086791491494d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.4253138896427425d);

  }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(0.0f, 0.48847377f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.48847377f);

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)8703.735538471214d, (java.lang.Number)10.0f, false);
    java.lang.Number var5 = var4.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 10.0f+ "'", var5.equals(10.0f));

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(1.0000001f, 0.7086221f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.7086221f);

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    int var5 = var0.nextZipf(1, 54.75212864082803d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var0.nextF(0.9403135060181869d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.9E-324d);

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)10, (java.lang.Number)10.0f, (java.lang.Number)(short)10);
    org.apache.commons.math3.exception.OutOfRangeException var7 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)10, (java.lang.Number)10.0f, (java.lang.Number)(short)10);
    java.lang.Number var8 = var7.getHi();
    java.lang.Number var9 = var7.getLo();
    java.lang.Number var10 = var7.getArgument();
    var3.addSuppressed((java.lang.Throwable)var7);
    java.lang.Number var12 = var3.getLo();
    org.apache.commons.math3.exception.MathInternalError var13 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (short)10+ "'", var8.equals((short)10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + 10.0f+ "'", var9.equals(10.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + (short)10+ "'", var10.equals((short)10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 10.0f+ "'", var12.equals(10.0f));

  }

  public void test284() {}
//   public void test284() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextUniform((-1.5574077246549023d), 11013.232874703393d);
//     var0.reSeed();
//     org.apache.commons.math3.random.RandomGenerator var5 = var0.getRandomGenerator();
//     long var8 = var0.nextSecureLong(16L, 57L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 8440.19807688283d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 53L);
// 
//   }

  public void test285() {}
//   public void test285() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     boolean var1 = var0.nextBoolean();
//     var0.clear();
//     float var3 = var0.nextFloat();
//     var0.clear();
//     var0.setSeed(12);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var8 = var0.nextInt((-4));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.9865328f);
// 
//   }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var5 = var0.nextCauchy((-699.7827128954451d), 100.0d);
    double var8 = var0.nextGaussian(6896.287303290861d, 63.38748545037136d);
    double var11 = var0.nextF(11013.232874703393d, 2340.865705580131d);
    var0.reSeed(57L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-729.2529703881293d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 6970.274656128737d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.9403135060181869d);

  }

  public void test287() {}
//   public void test287() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     boolean var1 = var0.nextBoolean();
//     var0.clear();
//     double var3 = var0.nextDouble();
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     org.apache.commons.math3.distribution.RealDistribution var5 = null;
//     double var6 = var4.nextInversionDeviate(var5);
// 
//   }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(9.999999f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(1.1920929E-7f, 37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 16384.0f);

  }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var3 = var0.nextPascal((-1), 1.5588443417110756d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test291() {}
//   public void test291() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     org.apache.commons.math3.distribution.RealDistribution var1 = null;
//     double var2 = var0.nextInversionDeviate(var1);
// 
//   }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var5 = var0.nextCauchy((-699.7827128954451d), 100.0d);
    double var8 = var0.nextGaussian(6896.287303290861d, 63.38748545037136d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var0.nextChiSquare(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-729.2529703881293d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 6970.274656128737d);

  }

  public void test293() {}
//   public void test293() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Number var1 = null;
//     java.lang.Number var2 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, var1, var2, false);
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     java.lang.Number var6 = null;
//     org.apache.commons.math3.exception.NotStrictlyPositiveException var7 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var5, var6);
//     var4.addSuppressed((java.lang.Throwable)var7);
//     java.lang.String var9 = var4.toString();
// 
//   }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(1.1368683772161603E-13d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(5.070965234019339E-7d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0587911840678754E-22d);

  }

  public void test296() {}
//   public void test296() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextUniform((-1.5574077246549023d), 11013.232874703393d);
//     var0.reSeed();
//     org.apache.commons.math3.random.RandomGenerator var5 = var0.getRandomGenerator();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("5b6c396732", "org.apache.commons.math3.exception.OutOfRangeException: 10 out of [10, 10] range");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 9962.177549397415d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
// 
//   }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    int[] var1 = null;
    var0.setSeed(var1);
    var0.setSeed(100L);
    int var5 = var0.nextInt();
    long var6 = var0.nextLong();
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    var7.reSeed(10L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var12 = var7.nextBinomial(0, 57.29577951308232d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 818120085);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 862908985188605553L);

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(0.027952873673631765d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.027949234728766696d);

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(0.23333633f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 39);

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(53L, 16L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 53L);

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(1.5660768339053222d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.78782785634617d);

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }


    long var2 = org.apache.commons.math3.util.FastMath.min((-1L), 100L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1L));

  }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(9263.640859542764d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.6090961411616793d));

  }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);

  }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(0.68616164f, 0.10513509f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.10513509f);

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    int var5 = var0.nextZipf(1, 54.75212864082803d);
    var0.reSeedSecure(94L);
    int var10 = var0.nextBinomial(100, 0.9403135060181869d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSecureAlgorithm("e", "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 98);

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }


    long var2 = org.apache.commons.math3.util.FastMath.max((-1L), 2372L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2372L);

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    java.lang.Object[] var9 = new java.lang.Object[] { (short)(-1)};
    org.apache.commons.math3.exception.NotFiniteNumberException var10 = new org.apache.commons.math3.exception.NotFiniteNumberException(var6, (java.lang.Number)0, var9);
    org.apache.commons.math3.exception.MathIllegalArgumentException var11 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var5, var9);
    org.apache.commons.math3.exception.NotFiniteNumberException var12 = new org.apache.commons.math3.exception.NotFiniteNumberException(var3, (java.lang.Number)0.5364627384899132d, var9);
    org.apache.commons.math3.exception.NotFiniteNumberException var13 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Number)1.0f, var9);
    org.apache.commons.math3.exception.MathIllegalArgumentException var14 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
    double var4 = var3.getNumericalMean();
    int var5 = var3.sample();
    int var6 = var3.sample();
    var3.reseedRandomGenerator(0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);

  }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(22, 0, (-1));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test312() {}
//   public void test312() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int[] var1 = null;
//     var0.setSeed(var1);
//     var0.setSeed(100L);
//     int var5 = var0.nextInt();
//     long var6 = var0.nextLong();
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     var7.reSeed();
//     double var10 = var7.nextT(0.7838376650545498d);
//     double var12 = var7.nextExponential(0.043865248283487694d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var7.nextSecureInt(55, 55);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 818120085);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 862908985188605553L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.24136704787995084d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.005148440670231566d);
// 
//   }

  public void test313() {}
//   public void test313() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     boolean var1 = var0.nextBoolean();
//     var0.clear();
//     org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
//     float var4 = var0.nextFloat();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.55086493f);
// 
//   }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)55, (java.lang.Number)9263.640859542764d, (java.lang.Number)0);

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
    double var4 = var3.getNumericalMean();
    int var5 = var3.getSupportUpperBound();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var3.cumulativeProbability(110704524, 1);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(0.68616164f, 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.POSITIVE_INFINITY);

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(5.07096651975376E-7d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.070966519753761E-7d);

  }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(102400.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 102400L);

  }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(57L, 2L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2L);

  }

  public void test320() {}
//   public void test320() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int[] var1 = null;
//     var0.setSeed(var1);
//     var0.setSeed(100L);
//     int var5 = var0.nextInt();
//     long var6 = var0.nextLong();
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     var7.reSeed();
//     double var10 = var7.nextT(0.7838376650545498d);
//     double var12 = var7.nextExponential(0.043865248283487694d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var7.setSecureAlgorithm("", "");
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 818120085);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 862908985188605553L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 6.200524688608745d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.029940851632549732d);
// 
//   }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    int var5 = var0.nextZipf(1, 54.75212864082803d);
    var0.reSeedSecure(94L);
    int var10 = var0.nextBinomial(100, 0.9403135060181869d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var14 = var0.nextHypergeometric(100, 2147483647, 818120085);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 98);

  }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(-1.0f));
    org.apache.commons.math3.exception.MathInternalError var3 = new org.apache.commons.math3.exception.MathInternalError();
    var2.addSuppressed((java.lang.Throwable)var3);
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var3.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.7309575981987914d, 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.4502956492584658E-14d);

  }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(2814.407873720085d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2814.407873720085d);

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution((-1), 39, (-4));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test326() {}
//   public void test326() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     boolean var1 = var0.nextBoolean();
//     var0.clear();
//     float var3 = var0.nextFloat();
//     var0.clear();
//     var0.setSeed(12);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var7.nextHypergeometric(146899547, 2147483647, 56);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.18961251f);
// 
//   }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var5 = var0.nextCauchy((-699.7827128954451d), 100.0d);
    double var8 = var0.nextGaussian(6896.287303290861d, 63.38748545037136d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var11 = var0.nextGaussian(1346.8722274727033d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-729.2529703881293d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 6970.274656128737d);

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(0.17144895f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(0.68616164f, 0.17144895f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.68616164f);

  }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = var1.nextF(0.7336545584598283d, (-0.015339522045871551d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(0.1904834217843172d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.1904834217843172d);

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(0.043865248283487694d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.043893404540024376d);

  }

  public void test333() {}
//   public void test333() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     long var3 = var0.nextSecureLong(0L, 100L);
//     double var6 = var0.nextGaussian((-0.8414709848078965d), 54.75212864082803d);
//     double var9 = var0.nextCauchy(4971.100933318636d, 57.29577951308232d);
//     var0.reSeedSecure(20L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 19.19320485386328d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 4985.0230236268335d);
// 
//   }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var5 = var0.nextCauchy((-699.7827128954451d), 100.0d);
    double var8 = var0.nextGaussian(6896.287303290861d, 63.38748545037136d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var12 = var0.nextHypergeometric(12, 0, 98);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-729.2529703881293d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 6970.274656128737d);

  }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin((-729.2529703881293d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.3926164465348356d));

  }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(4.696046811967199d, 0.04383714613469767d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.5614616939372625d);

  }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)1L);
    org.apache.commons.math3.exception.MathInternalError var2 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var1);
    org.apache.commons.math3.exception.MathInternalError var3 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var2);
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(6896.287303290861d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)1.2252628283577319E-304d, (java.lang.Number)102400.0d, false);
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Number var5 = null;
    java.lang.Number var6 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var8 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var4, var5, var6, false);
    java.lang.Number var9 = var8.getMin();
    var3.addSuppressed((java.lang.Throwable)var8);
    java.lang.Number var11 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + 102400.0d+ "'", var11.equals(102400.0d));

  }

  public void test340() {}
//   public void test340() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c();
//     boolean var4 = var3.nextBoolean();
//     var3.clear();
//     float var6 = var3.nextFloat();
//     java.lang.Object[] var7 = new java.lang.Object[] { var6};
//     org.apache.commons.math3.exception.MathIllegalArgumentException var8 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, var7);
//     org.apache.commons.math3.exception.NotFiniteNumberException var9 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)0.01749082497330633d, var7);
//     org.apache.commons.math3.exception.NumberIsTooLargeException var13 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)Float.POSITIVE_INFINITY, (java.lang.Number)4.696046811967199d, true);
//     var9.addSuppressed((java.lang.Throwable)var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.26656938f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
// 
//   }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var5 = var0.nextCauchy((-699.7827128954451d), 100.0d);
    var0.reSeedSecure(10L);
    double var11 = var0.nextUniform(0.9999999958776927d, 57.29577951308232d, false);
    double var14 = var0.nextGaussian(1.225262833408642E-304d, 1.0d);
    int var17 = var0.nextZipf(1, 0.01749082497330633d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var20 = var0.nextCauchy(5.070965234019122E-7d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-729.2529703881293d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 54.75212864082803d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == (-2.6649762425333257d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1);

  }

  public void test342() {}
//   public void test342() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextUniform((-1.5574077246549023d), 11013.232874703393d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("5b6c396732", "org.apache.commons.math3.exception.OutOfRangeException: 10 out of [10, 10] range");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 964.6043441093286d);
// 
//   }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0, var2, false);
    java.lang.Number var5 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test344() {}
//   public void test344() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int[] var1 = null;
//     var0.setSeed(var1);
//     var0.setSeed(100L);
//     int var5 = var0.nextInt();
//     long var6 = var0.nextLong();
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     java.util.Collection var8 = null;
//     java.lang.Object[] var10 = var7.nextSample(var8, 110704524);
// 
//   }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(57.29577951308232d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.7581226324091723d);

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-127));

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot((-699.0d), 0.027952873673631765d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 699.000000558915d);

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(2.4502956492584658E-14d, 39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)(short)(-1));

  }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(37);

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(0.027949234728766696d, 19.19320485386328d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0014562036505027243d);

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var5 = var0.nextCauchy((-699.7827128954451d), 100.0d);
    org.apache.commons.math3.random.RandomGenerator var6 = var0.getRandomGenerator();
    var0.reSeed(1L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var11 = var0.nextPermutation((-4), 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-729.2529703881293d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(19.19320485386328d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(1.0f, 0.23333633f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0f);

  }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(0.03510046f, 7.4505806E-9f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7.4505806E-9f);

  }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.027415567780803774d, 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.714998727304537E-24d);

  }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Object[] var7 = new java.lang.Object[] { (short)(-1)};
    org.apache.commons.math3.exception.NotFiniteNumberException var8 = new org.apache.commons.math3.exception.NotFiniteNumberException(var4, (java.lang.Number)0, var7);
    org.apache.commons.math3.exception.MathIllegalArgumentException var9 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, var7);
    org.apache.commons.math3.exception.NotFiniteNumberException var10 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Number)0.5364627384899132d, var7);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    int[] var1 = null;
    var0.setSeed(var1);
    var0.setSeed(100L);
    int var5 = var0.nextInt();
    long var6 = var0.nextLong();
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var10 = var7.nextLong(10L, (-1L));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 818120085);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 862908985188605553L);

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.1904834217843172d);

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(0.7309575981987914d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8549605828333792d);

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(0.26669969365787255d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.3216319964342262d));

  }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(146899547);

  }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)Float.POSITIVE_INFINITY, (java.lang.Number)4.696046811967199d, true);
    boolean var4 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }


    int var2 = org.apache.commons.math3.util.FastMath.max((-1023), 56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 56);

  }

  public void test366() {}
//   public void test366() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int[] var1 = null;
//     var0.setSeed(var1);
//     var0.setSeed(100L);
//     int var5 = var0.nextInt();
//     long var6 = var0.nextLong();
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     var7.reSeed();
//     double var10 = var7.nextT(0.7838376650545498d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var7.nextBinomial((-4), 0.0014562036505027243d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 818120085);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 862908985188605553L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 3.333630406697082d);
// 
//   }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }


    double var1 = org.apache.commons.math3.util.FastMath.acos(0.043893404540024376d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5268888156225198d);

  }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
    int var4 = var3.getPopulationSize();
    double var6 = var3.upperCumulativeProbability(1);
    double var8 = var3.upperCumulativeProbability((-1023));
    int var9 = var3.getPopulationSize();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var11 = var3.inverseCumulativeProbability((-2.410126239324223E-6d));
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 12);

  }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    int[] var1 = null;
    var0.setSeed(var1);
    var0.setSeed(100L);
    int var5 = var0.nextInt();
    long var6 = var0.nextLong();
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
    double var12 = var11.getNumericalMean();
    int var13 = var11.sample();
    int var14 = var11.sample();
    int var15 = var7.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var11);
    double var16 = var11.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 818120085);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 862908985188605553L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);

  }

  public void test370() {}
//   public void test370() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int[] var1 = null;
//     var0.setSeed(var1);
//     var0.setSeed(100L);
//     int var5 = var0.nextInt();
//     long var6 = var0.nextLong();
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     var7.reSeed();
//     var7.reSeed();
//     double var12 = var7.nextGaussian((-699.0d), 5428.269407301349d);
//     double var16 = var7.nextUniform(0.0d, 5.07096651975376E-7d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var19 = var7.nextPermutation(1, 15);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 818120085);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 862908985188605553L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 2221.70468821379d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 3.483765121390701E-7d);
// 
//   }

  public void test371() {}
//   public void test371() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextUniform((-1.5574077246549023d), 11013.232874703393d);
//     var0.reSeed();
//     var0.reSeed(100L);
//     java.lang.String var8 = var0.nextSecureHexString(55);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var0.nextBeta((-699.7827128954451d), 102400.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 5632.393475254001d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "bad66295c20b95cdee0233b832f6bbe7196276ddef00b07af7abaeb"+ "'", var8.equals("bad66295c20b95cdee0233b832f6bbe7196276ddef00b07af7abaeb"));
// 
//   }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
    int var4 = var3.getPopulationSize();
    double var6 = var3.upperCumulativeProbability(1);
    double var7 = var3.getNumericalVariance();
    double var9 = var3.cumulativeProbability(10);
    int[] var11 = var3.sample(56);
    double var13 = var3.probability(55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);

  }

  public void test373() {}
//   public void test373() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Object[] var3 = new java.lang.Object[] { (short)(-1)};
//     org.apache.commons.math3.exception.NotFiniteNumberException var4 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)0, var3);
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     org.apache.commons.math3.exception.util.Localizable var6 = null;
//     org.apache.commons.math3.exception.util.Localizable var7 = null;
//     java.lang.Object[] var10 = new java.lang.Object[] { (short)(-1)};
//     org.apache.commons.math3.exception.NotFiniteNumberException var11 = new org.apache.commons.math3.exception.NotFiniteNumberException(var7, (java.lang.Number)0, var10);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var12 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var6, var10);
//     org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var5, var10);
// 
//   }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(1.7581226324091723d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1644468492049203d);

  }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0);

  }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, var1, var2, false);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    java.lang.Number var6 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var7 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var5, var6);
    var4.addSuppressed((java.lang.Throwable)var7);
    org.apache.commons.math3.exception.NotPositiveException var10 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.027415567780803774d);
    var4.addSuppressed((java.lang.Throwable)var10);

  }

  public void test377() {}
//   public void test377() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     boolean var1 = var0.nextBoolean();
//     var0.clear();
//     double var3 = var0.nextDouble();
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     java.lang.String var6 = var4.nextSecureHexString(1);
//     java.util.Collection var7 = null;
//     java.lang.Object[] var9 = var4.nextSample(var7, 0);
// 
//   }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(3599.641648418025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3600.0d);

  }

  public void test379() {}
//   public void test379() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextUniform((-1.5574077246549023d), 11013.232874703393d);
//     var0.reSeed();
//     org.apache.commons.math3.random.RandomGenerator var5 = var0.getRandomGenerator();
//     org.apache.commons.math3.random.RandomDataImpl var6 = new org.apache.commons.math3.random.RandomDataImpl(var5);
//     int var9 = var6.nextSecureInt(22, 2147483647);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var12 = var6.nextPermutation(2147483647, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 6783.939256542535d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1025111073);
// 
//   }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(0.4393086791491494d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.42628059715133865d);

  }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
    int var4 = var3.getPopulationSize();
    double var6 = var3.upperCumulativeProbability(1);
    double var8 = var3.upperCumulativeProbability((-1023));
    int var9 = var3.getSupportUpperBound();
    boolean var10 = var3.isSupportConnected();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);

  }

  public void test382() {}
//   public void test382() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextUniform((-1.5574077246549023d), 11013.232874703393d);
//     var0.reSeed();
//     org.apache.commons.math3.random.RandomGenerator var5 = var0.getRandomGenerator();
//     org.apache.commons.math3.random.RandomDataImpl var6 = new org.apache.commons.math3.random.RandomDataImpl(var5);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var6.nextCauchy(11013.232874703393d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 7875.068208322589d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
// 
//   }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(0.26656938f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test384() {}
//   public void test384() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int[] var1 = null;
//     var0.setSeed(var1);
//     var0.setSeed(100L);
//     int var5 = var0.nextInt();
//     long var6 = var0.nextLong();
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
//     double var12 = var11.getNumericalMean();
//     int var13 = var11.sample();
//     int var14 = var11.sample();
//     int var15 = var7.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var11);
//     org.apache.commons.math3.distribution.RealDistribution var16 = null;
//     double var17 = var7.nextInversionDeviate(var16);
// 
//   }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(0.48847377f, 0.7564535f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.48847377f);

  }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(1.1920929E-7f, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.1920928E-7f);

  }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh(0.04383714613469767d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.04386525910364574d);

  }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(2L, 102400L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 102400L);

  }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.0d, 0.7309575981987914d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(19, 56, (-523));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test392() {}
//   public void test392() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int[] var1 = null;
//     var0.setSeed(var1);
//     var0.setSeed(100L);
//     int var5 = var0.nextInt();
//     long var6 = var0.nextLong();
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     var7.reSeed();
//     var7.reSeed();
//     int var13 = var7.nextHypergeometric(818120085, 98, 146899547);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var7.nextSecureInt(100, 37);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 818120085);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 862908985188605553L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 15);
// 
//   }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test394() {}
//   public void test394() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int[] var1 = null;
//     var0.setSeed(var1);
//     var0.setSeed(100L);
//     int var5 = var0.nextInt();
//     long var6 = var0.nextLong();
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     var7.reSeed();
//     var7.reSeed();
//     int var13 = var7.nextHypergeometric(818120085, 98, 146899547);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var17 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
//     double var19 = var17.probability(0);
//     boolean var20 = var17.isSupportConnected();
//     int var21 = var7.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var17);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var25 = var7.nextUniform(566.2637592611346d, 0.7923558499802232d, true);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 818120085);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 862908985188605553L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0);
// 
//   }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)10, (java.lang.Number)10.0f, (java.lang.Number)(short)10);
    org.apache.commons.math3.exception.OutOfRangeException var7 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)10, (java.lang.Number)10.0f, (java.lang.Number)(short)10);
    java.lang.Number var8 = var7.getHi();
    java.lang.Number var9 = var7.getLo();
    java.lang.Number var10 = var7.getArgument();
    var3.addSuppressed((java.lang.Throwable)var7);
    java.lang.Number var12 = var7.getArgument();
    org.apache.commons.math3.exception.util.Localizable var13 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var18 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(short)0, (java.lang.Number)2275.2336411793885d, false);
    java.lang.Object[] var19 = new java.lang.Object[] { var18};
    org.apache.commons.math3.exception.NotFiniteNumberException var20 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)60.446553428065656d, var19);
    org.apache.commons.math3.exception.MathIllegalStateException var21 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var7, var13, var19);
    java.lang.Number var22 = var7.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (short)10+ "'", var8.equals((short)10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + 10.0f+ "'", var9.equals(10.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + (short)10+ "'", var10.equals((short)10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + (short)10+ "'", var12.equals((short)10));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + 10.0f+ "'", var22.equals(10.0f));

  }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp((-1.3581577268388338d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.25713405203159173d);

  }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
    int var4 = var3.getPopulationSize();
    double var6 = var3.upperCumulativeProbability(1);
    double var8 = var3.upperCumulativeProbability((-1023));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var10 = var3.inverseCumulativeProbability(8.422985157797855d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);

  }

  public void test398() {}
//   public void test398() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int[] var1 = null;
//     var0.setSeed(var1);
//     var0.setSeed(100L);
//     int var5 = var0.nextInt();
//     long var6 = var0.nextLong();
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     var7.reSeed();
//     double var10 = var7.nextT(0.7838376650545498d);
//     int var13 = var7.nextSecureInt((-1023), 10);
//     org.apache.commons.math3.distribution.RealDistribution var14 = null;
//     double var15 = var7.nextInversionDeviate(var14);
// 
//   }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(0, 110704524);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)3680.7382205113386d, (java.lang.Number)102400.0d, (java.lang.Number)10.000000000000002d);

  }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
    int var4 = var3.getPopulationSize();
    double var6 = var3.upperCumulativeProbability(1);
    double var8 = var3.upperCumulativeProbability((-1023));
    int var9 = var3.getSupportUpperBound();
    int var10 = var3.sample();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);

  }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(8440.19807688283d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 147.3092459620989d);

  }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)7254.222364425498d);

  }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(7.4505806E-9f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.4505806E-9f);

  }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    java.lang.Object[] var9 = new java.lang.Object[] { (short)(-1)};
    org.apache.commons.math3.exception.NotFiniteNumberException var10 = new org.apache.commons.math3.exception.NotFiniteNumberException(var6, (java.lang.Number)0, var9);
    org.apache.commons.math3.exception.MathIllegalArgumentException var11 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var5, var9);
    org.apache.commons.math3.exception.NotFiniteNumberException var12 = new org.apache.commons.math3.exception.NotFiniteNumberException(var3, (java.lang.Number)0.5364627384899132d, var9);
    org.apache.commons.math3.exception.MathInternalError var13 = new org.apache.commons.math3.exception.MathInternalError(var2, var9);
    org.apache.commons.math3.exception.NotFiniteNumberException var14 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, var9);
    org.apache.commons.math3.exception.MathIllegalStateException var15 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(12);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var5 = var2.nextLong(94L, 0L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    int[] var1 = null;
    var0.setSeed(var1);
    var0.setSeed(100L);
    int var5 = var0.nextInt();
    long var6 = var0.nextLong();
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    var7.reSeed();
    var7.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var12 = var7.nextUniform(1980.7585985364183d, 1.5707963267948966d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 818120085);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 862908985188605553L);

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
    int var4 = var3.getPopulationSize();
    double var6 = var3.upperCumulativeProbability(1);
    double var8 = var3.upperCumulativeProbability((-1023));
    boolean var9 = var3.isSupportConnected();
    boolean var10 = var3.isSupportConnected();
    boolean var11 = var3.isSupportConnected();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(9263.640859542764d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9.133960374831913d);

  }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(5.070965234019339E-7d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.070965234019122E-7d);

  }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(0.17144895f, 0.10513509f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.10513509f);

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.5268888156225198d, (java.lang.Number)0.04386525910364574d, false);

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.3440585709080678E43d);

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(19.19320485386328d, 3600.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 19.19320485386328d);

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)1.4E-45f);

  }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0, var2, false);
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test417() {}
//   public void test417() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     boolean var1 = var0.nextBoolean();
//     var0.clear();
//     double var3 = var0.nextDouble();
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     java.lang.String var6 = var4.nextSecureHexString(1);
//     double var9 = var4.nextF(6439.0462019649585d, 57.29577951308232d);
//     java.util.Collection var10 = null;
//     java.lang.Object[] var12 = var4.nextSample(var10, 110704524);
// 
//   }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
    double var4 = var3.getNumericalMean();
    int var5 = var3.sample();
    int var6 = var3.sample();
    double var8 = var3.probability(146899547);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);

  }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(3.1960696488861985E-304d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    java.lang.Object[] var10 = new java.lang.Object[] { (short)(-1)};
    org.apache.commons.math3.exception.NotFiniteNumberException var11 = new org.apache.commons.math3.exception.NotFiniteNumberException(var7, (java.lang.Number)0, var10);
    org.apache.commons.math3.exception.MathIllegalArgumentException var12 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var6, var10);
    org.apache.commons.math3.exception.NotFiniteNumberException var13 = new org.apache.commons.math3.exception.NotFiniteNumberException(var4, (java.lang.Number)0.5364627384899132d, var10);
    org.apache.commons.math3.exception.NotFiniteNumberException var14 = new org.apache.commons.math3.exception.NotFiniteNumberException(var2, (java.lang.Number)1.0f, var10);
    org.apache.commons.math3.exception.NotFiniteNumberException var15 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, var1, var10);
    java.lang.Number var16 = var15.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test421() {}
//   public void test421() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     boolean var1 = var0.nextBoolean();
//     var0.clear();
//     org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
//     byte[] var7 = new byte[] { (byte)0, (byte)1, (byte)1};
//     var0.nextBytes(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
// 
//   }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var1.setSeed(0L);

  }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb((-1.0d), 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-4096.0d));

  }

  public void test424() {}
//   public void test424() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     long var3 = var0.nextSecureLong(0L, 100L);
//     double var6 = var0.nextGaussian((-0.8414709848078965d), 54.75212864082803d);
//     double var9 = var0.nextCauchy(4971.100933318636d, 57.29577951308232d);
//     int var12 = var0.nextSecureInt((-1023), 818120085);
//     double var15 = var0.nextCauchy(32.43325533860437d, 0.043865248283487694d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 90L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 21.80857459377457d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1190.6076761276186d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 777026012);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 32.50905983460604d);
// 
//   }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)63.38748545037136d, (java.lang.Number)0.0f, false);

  }

  public void test426() {}
//   public void test426() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(-1.0f));
//     org.apache.commons.math3.exception.MathInternalError var3 = new org.apache.commons.math3.exception.MathInternalError();
//     var2.addSuppressed((java.lang.Throwable)var3);
//     org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var2);
// 
//   }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, var1, var2, false);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    java.lang.Number var6 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var7 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var5, var6);
    var4.addSuppressed((java.lang.Throwable)var7);
    boolean var9 = var7.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(0.0f, (-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(2819L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2819L);

  }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var1.nextUniform(1.5268888156225198d, 2.4502956492584658E-14d, false);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(3788.543052731631d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test432() {}
//   public void test432() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.pow(3788.543052731631d, 98);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
    int var4 = var3.getPopulationSize();
    double var6 = var3.upperCumulativeProbability(1);
    double var9 = var3.cumulativeProbability(22, 22);
    int var10 = var3.getPopulationSize();
    int var11 = var3.getSupportUpperBound();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var13 = var3.inverseCumulativeProbability(5061.9280334995965d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);

  }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(0.012818273171627077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.01281757119201118d);

  }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)1.2252628283577319E-304d, (java.lang.Number)102400.0d, false);
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Number var5 = null;
    java.lang.Number var6 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var8 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var4, var5, var6, false);
    java.lang.Number var9 = var8.getMin();
    var3.addSuppressed((java.lang.Throwable)var8);
    java.lang.Number var11 = var8.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
    double var4 = var3.getNumericalMean();
    double var6 = var3.cumulativeProbability(818120085);
    var3.reseedRandomGenerator(2372L);
    double var10 = var3.probability(39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);

  }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(147.3092459620989d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.8421709430404007E-14d);

  }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)1190.6076761276186d, false);

  }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }


    java.lang.Throwable var0 = null;
    org.apache.commons.math3.exception.MathInternalError var1 = new org.apache.commons.math3.exception.MathInternalError(var0);

  }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(37, 818217249);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 818217249);

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)57.29577951308232d, var1, false);

  }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var5 = var0.nextCauchy((-699.7827128954451d), 100.0d);
    var0.reSeedSecure(10L);
    double var11 = var0.nextUniform(0.9999999958776927d, 57.29577951308232d, false);
    double var14 = var0.nextGamma(10839.51476898481d, 4.9E-324d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var17 = var0.nextF(57.29577951308232d, (-729.2529703881293d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-729.2529703881293d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 54.75212864082803d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 5.2193E-320d);

  }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(55, 37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 37);

  }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(6262.315982628583d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5706366414653359d);

  }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.54969144f, 6896.287303290861d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.5496915f);

  }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(-1.0f));
    org.apache.commons.math3.exception.NotStrictlyPositiveException var4 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)1L);
    org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var4);
    var2.addSuppressed((java.lang.Throwable)var4);

  }

  public void test447() {}
//   public void test447() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextUniform((-1.5574077246549023d), 11013.232874703393d);
//     var0.reSeed();
//     org.apache.commons.math3.random.RandomGenerator var5 = var0.getRandomGenerator();
//     int var8 = var0.nextInt(22, 818120085);
//     org.apache.commons.math3.random.RandomGenerator var9 = var0.getRandomGenerator();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2760.9511701939477d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 538588776);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
// 
//   }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var5 = var0.nextCauchy((-699.7827128954451d), 100.0d);
    org.apache.commons.math3.random.RandomGenerator var6 = var0.getRandomGenerator();
    var0.reSeed(1L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSecureAlgorithm("c5f8f6e706", "org.apache.commons.math3.exception.OutOfRangeException: 10 out of [10, 10] range");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-729.2529703881293d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var5 = var0.nextCauchy((-699.7827128954451d), 100.0d);
    var0.reSeedSecure(10L);
    double var11 = var0.nextUniform(0.9999999958776927d, 57.29577951308232d, false);
    double var14 = var0.nextGaussian(1.225262833408642E-304d, 1.0d);
    int var17 = var0.nextZipf(1, 0.01749082497330633d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var20 = var0.nextCauchy(566.2637592611346d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-729.2529703881293d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 54.75212864082803d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == (-2.6649762425333257d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1);

  }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.01281757119201118d, (-57.29577951308232d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.012817571192011178d);

  }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(1.0000001f, 8440.19807688283d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0000002f);

  }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(1.0682304897585864d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.4816756918203273d);

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(146899547, 56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 146899547);

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
    int var4 = var3.getPopulationSize();
    double var6 = var3.upperCumulativeProbability(1);
    double var7 = var3.getNumericalVariance();
    double var9 = var3.cumulativeProbability(10);
    int var10 = var3.sample();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);

  }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);

  }

  public void test456() {}
//   public void test456() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder((-1.3581577268388338d), 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp((-20.096831793142318d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-20.096831793142314d));

  }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var5 = var0.nextCauchy((-699.7827128954451d), 100.0d);
    var0.reSeedSecure(10L);
    long var9 = var0.nextPoisson(4815.223910021246d);
    double var11 = var0.nextExponential(5428.269407301349d);
    var0.reSeedSecure(100L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var16 = var0.nextBeta(Double.NaN, 12.229789172123647d);
      fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
    } catch (org.apache.commons.math3.exception.NoBracketingException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-729.2529703881293d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 4864L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2275.2336411793885d);

  }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
    int var4 = var3.getPopulationSize();
    double var6 = var3.upperCumulativeProbability(1);
    double var8 = var3.upperCumulativeProbability((-1023));
    var3.reseedRandomGenerator(0L);
    double var12 = var3.cumulativeProbability(0);
    double var15 = var3.cumulativeProbability(37, 513171738);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);

  }

  public void test460() {}
//   public void test460() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var5 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var1, (java.lang.Number)4815.223910021246d, (java.lang.Number)10.0d, false);
//     boolean var6 = var5.getBoundIsAllowed();
//     java.lang.Throwable[] var7 = var5.getSuppressed();
//     org.apache.commons.math3.exception.MathInternalError var8 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var7);
//     org.apache.commons.math3.exception.util.Localizable var9 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var13 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)10, (java.lang.Number)10.0f, (java.lang.Number)(short)10);
//     org.apache.commons.math3.exception.OutOfRangeException var17 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)10, (java.lang.Number)10.0f, (java.lang.Number)(short)10);
//     java.lang.Number var18 = var17.getHi();
//     java.lang.Number var19 = var17.getLo();
//     java.lang.Number var20 = var17.getArgument();
//     var13.addSuppressed((java.lang.Throwable)var17);
//     java.lang.Number var22 = var17.getArgument();
//     org.apache.commons.math3.exception.util.Localizable var23 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var28 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(short)0, (java.lang.Number)2275.2336411793885d, false);
//     java.lang.Object[] var29 = new java.lang.Object[] { var28};
//     org.apache.commons.math3.exception.NotFiniteNumberException var30 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)60.446553428065656d, var29);
//     org.apache.commons.math3.exception.MathIllegalStateException var31 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var17, var23, var29);
//     org.apache.commons.math3.exception.MathIllegalStateException var32 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var8, var9, var29);
// 
//   }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }


    int var1 = org.apache.commons.math3.util.FastMath.round((-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
    int var4 = var3.getPopulationSize();
    double var6 = var3.upperCumulativeProbability(1);
    double var8 = var3.upperCumulativeProbability((-1023));
    int var9 = var3.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);

  }

  public void test463() {}
//   public void test463() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     boolean var1 = var0.nextBoolean();
//     var0.clear();
//     float var3 = var0.nextFloat();
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     float var5 = var0.nextFloat();
//     double var6 = var0.nextDouble();
//     var0.setSeed(10L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.9577712f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.2379278f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.7262100161290994d);
// 
//   }

  public void test464() {}
//   public void test464() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.rint(Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test465() {}
//   public void test465() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextUniform((-1.5574077246549023d), 11013.232874703393d);
//     var0.reSeed();
//     var0.reSeed(1L);
//     double var9 = var0.nextBeta(100.0d, 4815.223910021246d);
//     double var11 = var0.nextChiSquare(60.446553428065656d);
//     var0.reSeedSecure(862908985188605553L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var16 = var0.nextCauchy(2.302585092994046d, (-3.1266328832448305d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 7219.659806019025d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.01749082497330633d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 55.24586419897384d);
// 
//   }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(54.75212864082803d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.9746281154291627d));

  }

  public void test467() {}
//   public void test467() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int[] var1 = null;
//     var0.setSeed(var1);
//     var0.setSeed(100L);
//     int var5 = var0.nextInt();
//     long var6 = var0.nextLong();
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     var7.reSeed();
//     double var10 = var7.nextT(0.7838376650545498d);
//     double var12 = var7.nextExponential(0.043865248283487694d);
//     java.lang.String var14 = var7.nextSecureHexString(12);
//     double var17 = var7.nextF(3680.7382205113386d, 9.98410068941516d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 818120085);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 862908985188605553L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.7815026979307647d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.05731100092466772d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "3fea5e983cb7"+ "'", var14.equals("3fea5e983cb7"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.9676999066984584d);
// 
//   }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, var1, var2, false);
    java.lang.Number var5 = var4.getMin();
    java.lang.Number var6 = var4.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    boolean var2 = var1.nextBoolean();
    long var4 = var1.nextLong(10L);
    byte[] var5 = new byte[] { };
    var1.nextBytes(var5);
    double var7 = var1.nextGaussian();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.0599323982683158d);

  }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)10, (java.lang.Number)10.0f, (java.lang.Number)(short)10);
    org.apache.commons.math3.exception.OutOfRangeException var7 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)10, (java.lang.Number)10.0f, (java.lang.Number)(short)10);
    java.lang.Number var8 = var7.getHi();
    java.lang.Number var9 = var7.getLo();
    java.lang.Number var10 = var7.getArgument();
    var3.addSuppressed((java.lang.Throwable)var7);
    java.lang.Number var12 = var3.getLo();
    java.lang.Number var13 = var3.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (short)10+ "'", var8.equals((short)10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + 10.0f+ "'", var9.equals(10.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + (short)10+ "'", var10.equals((short)10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 10.0f+ "'", var12.equals(10.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + (short)10+ "'", var13.equals((short)10));

  }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(0.7677324907460247d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6547536468207042d);

  }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(777026012);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 777026012);

  }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    var0.reSeed(13L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var5 = var0.nextSecureInt(1433907990, 777026012);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    int[] var1 = null;
    var0.setSeed(var1);
    var0.setSeed(100L);
    int var5 = var0.nextInt();
    long var6 = var0.nextLong();
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
    var7.reSeedSecure((-1L));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var12 = var7.nextCauchy(0.0d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 818120085);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 862908985188605553L);

  }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(0, 513171738, 10);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)0.57205045f, (java.lang.Number)12, false);

  }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.26669969365787255d, (java.lang.Number)0.16468322f, true);
    org.apache.commons.math3.exception.NumberIsTooLargeException var8 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)1.2252628283577319E-304d, (java.lang.Number)102400.0d, false);
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    java.lang.Number var10 = null;
    java.lang.Number var11 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var13 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var9, var10, var11, false);
    java.lang.Number var14 = var13.getMin();
    var8.addSuppressed((java.lang.Throwable)var13);
    var4.addSuppressed((java.lang.Throwable)var8);
    java.lang.Number var17 = var4.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + 0.26669969365787255d+ "'", var17.equals(0.26669969365787255d));

  }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(1.0587911840678754E-22d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test479() {}
//   public void test479() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextUniform((-1.5574077246549023d), 11013.232874703393d);
//     var0.reSeed();
//     int var7 = var0.nextInt(12, 98);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var0.nextBeta(7.020238914855607E-303d, Double.NEGATIVE_INFINITY);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 6649.1348885959105d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 17);
// 
//   }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
    int var4 = var3.getPopulationSize();
    double var6 = var3.upperCumulativeProbability(1);
    double var7 = var3.getNumericalVariance();
    int var8 = var3.getNumberOfSuccesses();
    int var9 = var3.sample();
    boolean var10 = var3.isSupportConnected();
    int var12 = var3.inverseCumulativeProbability(0.33712995310036376d);
    double var14 = var3.upperCumulativeProbability((-4));
    boolean var15 = var3.isSupportConnected();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);

  }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(1.734723475976807E-18d, 54.75212864082803d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 54.75212864082803d);

  }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(1239612384);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1239612384);

  }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var2 = null;
    org.apache.commons.math3.exception.NotFiniteNumberException var3 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)0.027952873673631765d, var2);

  }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(0.13667173987129622d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.9901732876313765d));

  }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(2147483647, 56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2147483647);

  }

  public void test486() {}
//   public void test486() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextUniform((-1.5574077246549023d), 11013.232874703393d);
//     var0.reSeed();
//     org.apache.commons.math3.random.RandomGenerator var5 = var0.getRandomGenerator();
//     org.apache.commons.math3.random.RandomDataImpl var6 = new org.apache.commons.math3.random.RandomDataImpl(var5);
//     int var9 = var6.nextSecureInt(22, 2147483647);
//     java.util.Collection var10 = null;
//     java.lang.Object[] var12 = var6.nextSample(var10, 513171738);
// 
//   }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder((-0.013396175220330939d), (-0.013396175220330939d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.0d));

  }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)10839.51476898481d);
    java.lang.Number var2 = var1.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 10839.51476898481d+ "'", var2.equals(10839.51476898481d));

  }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    var0.reSeed(13L);
    var0.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var6 = var0.nextLong(52L, 48L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(12, 0, 0);
    double var4 = var3.getNumericalMean();
    double var6 = var3.cumulativeProbability(818120085);
    boolean var7 = var3.isSupportConnected();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);

  }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }


    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.lang.Object[] var5 = new java.lang.Object[] { (short)(-1)};
    org.apache.commons.math3.exception.NotFiniteNumberException var6 = new org.apache.commons.math3.exception.NotFiniteNumberException(var2, (java.lang.Number)0, var5);
    org.apache.commons.math3.exception.MathIllegalArgumentException var7 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, var5);
    org.apache.commons.math3.exception.NotFiniteNumberException var8 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)12.229789172123647d, var5);
    org.apache.commons.math3.exception.OutOfRangeException var12 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)10, (java.lang.Number)10.0f, (java.lang.Number)(short)10);
    org.apache.commons.math3.exception.OutOfRangeException var16 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)10, (java.lang.Number)10.0f, (java.lang.Number)(short)10);
    java.lang.Number var17 = var16.getHi();
    java.lang.Number var18 = var16.getLo();
    java.lang.Number var19 = var16.getArgument();
    var12.addSuppressed((java.lang.Throwable)var16);
    java.lang.Number var21 = var12.getLo();
    org.apache.commons.math3.exception.util.ExceptionContext var22 = var12.getContext();
    var8.addSuppressed((java.lang.Throwable)var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + (short)10+ "'", var17.equals((short)10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + 10.0f+ "'", var18.equals(10.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + (short)10+ "'", var19.equals((short)10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + 10.0f+ "'", var21.equals(10.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)10, (java.lang.Number)10.0f, (java.lang.Number)(short)10);
    org.apache.commons.math3.exception.OutOfRangeException var7 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)10, (java.lang.Number)10.0f, (java.lang.Number)(short)10);
    java.lang.Number var8 = var7.getHi();
    java.lang.Number var9 = var7.getLo();
    java.lang.Number var10 = var7.getArgument();
    var3.addSuppressed((java.lang.Throwable)var7);
    java.lang.Number var12 = var3.getLo();
    org.apache.commons.math3.exception.util.ExceptionContext var13 = var3.getContext();
    org.apache.commons.math3.exception.MathInternalError var14 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (short)10+ "'", var8.equals((short)10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + 10.0f+ "'", var9.equals(10.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + (short)10+ "'", var10.equals((short)10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 10.0f+ "'", var12.equals(10.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(1.5707899264686505d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.1961181074614399d);

  }

  public void test494() {}
//   public void test494() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextUniform((-1.5574077246549023d), 11013.232874703393d);
//     var0.reSeed();
//     var0.reSeed(0L);
//     int var9 = var0.nextPascal(12, 1.225262833408642E-304d);
//     int var12 = var0.nextSecureInt(0, 100);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var15 = var0.nextSecureHexString((-1023));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3713.2481690415666d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 99);
// 
//   }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.9E-324d);

  }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(1, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(1.9842096344226883E-15d, 10839.51476898481d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10839.51476898481d);

  }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    var0.reSeed(13L);
    var0.reSeedSecure(2819L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var7 = var0.nextPascal((-4), 0.7309575981987914d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test499() {}
//   public void test499() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextUniform((-1.5574077246549023d), 11013.232874703393d);
//     var0.reSeed();
//     org.apache.commons.math3.random.RandomGenerator var5 = var0.getRandomGenerator();
//     org.apache.commons.math3.random.RandomDataImpl var6 = new org.apache.commons.math3.random.RandomDataImpl(var5);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var6.setSecureAlgorithm("", "org.apache.commons.math3.exception.OutOfRangeException: 10 out of [10, 10] range");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 9747.056869215983d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
// 
//   }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.26669969365787255d, (java.lang.Number)0.16468322f, true);
    org.apache.commons.math3.exception.NumberIsTooLargeException var8 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)1.2252628283577319E-304d, (java.lang.Number)102400.0d, false);
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    java.lang.Number var10 = null;
    java.lang.Number var11 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var13 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var9, var10, var11, false);
    java.lang.Number var14 = var13.getMin();
    var8.addSuppressed((java.lang.Throwable)var13);
    var4.addSuppressed((java.lang.Throwable)var8);
    org.apache.commons.math3.exception.NumberIsTooSmallException var20 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(short)0, (java.lang.Number)2275.2336411793885d, false);
    var4.addSuppressed((java.lang.Throwable)var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

}
