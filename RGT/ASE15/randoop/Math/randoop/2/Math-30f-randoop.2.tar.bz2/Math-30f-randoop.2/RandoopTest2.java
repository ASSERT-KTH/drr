
import junit.framework.*;

public class RandoopTest2 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test1"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(2.1317761108019555d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2870058778506d);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test2"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(5.403757938292075E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5707963267948966d);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test3"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4E-45f);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test4"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)1.0d);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test5"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(100L, 27L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test6"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(1.3418720970618036E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.6631572407716864E21d);

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test7"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(110, 127);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test8"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)0.03674973340708589d);

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test9"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.9E-324d);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test10"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp((-3.4536536242642804E43d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test11() {}
//   public void test11() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test11"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     java.lang.String var4 = var0.nextHexString(110);
//     int var7 = var0.nextPascal(3, 0.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var0.nextCauchy(0.4566344307670791d, (-0.9064833280591146d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.8406680756807966d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "9aa908fbc51bee921c83ed33c1fc4febe36d28b7a29aa2219e89f5c6d2e41da167450d1be9f35ee7f0a8b992f81e91b0ce19137dee38b3"+ "'", var4.equals("9aa908fbc51bee921c83ed33c1fc4febe36d28b7a29aa2219e89f5c6d2e41da167450d1be9f35ee7f0a8b992f81e91b0ce19137dee38b3"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2147483647);
// 
//   }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test12"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin((-0.47598581837512266d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.4960846371049067d));

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test13"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    java.lang.String var2 = var1.name();
    java.lang.String var3 = var1.name();
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var5.getTiesStrategy();
    int var7 = var6.ordinal();
    java.lang.String var8 = var6.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var6);
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = var11.getTiesStrategy();
    int var13 = var12.ordinal();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var14 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var12);
    java.lang.String var15 = var12.name();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "MAXIMAL"+ "'", var2.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "MAXIMAL"+ "'", var3.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "AVERAGE"+ "'", var15.equals("AVERAGE"));

  }

  public void test14() {}
//   public void test14() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test14"); }
// 
// 
//     org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     var0.setContractionCriteria(5.0f);
//     var0.setElement(110, Double.NaN);
//     var0.discardFrontElements(10);
//     org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     var8.setContractionCriteria(50.000008f);
//     org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var8);
//     double var13 = var8.substituteMostRecentElement(2.649558242894909d);
//     var8.setNumElements(96);
//     int var16 = var8.start();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var8.setContractionCriteria(1.4E-45f);
//       fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
//     } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 10);
// 
//   }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test15"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(50.000008f, (-1.8851541128986008E43d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 50.000004f);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test16"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(27000L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test17"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-9223372036854775808L), 540L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-9223372036854775268L));

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test18"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(4.3461844317156794E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.585522823235727E41d);

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test19"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.contract();
    int var2 = var0.getNumElements();
    float var3 = var0.getContractionCriteria();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 2.5f);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test20"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var4 = var1.nextPermutation(1612775, 12827000);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test21"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(3.7494465410713904E42d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 141);

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test22"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(5.403757938292075E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9.431336800397727E41d);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test23"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(0.9898371621797909d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.017275917538634444d);

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test24"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = var2.copy();
    var2.addElement(0.0018388436884212223d);
    int var6 = var2.start();
    int var7 = var2.getExpansionMode();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test25"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(100.0f, (-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100.0f);

  }

  public void test26() {}
//   public void test26() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test26"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     double var4 = var0.nextExponential(0.056182176564052d);
//     var0.reSeed();
//     double var8 = var0.nextGaussian(0.4054581033635218d, 3.846438844184768d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "af78c5798e4bce5f867fb772ab4ae89803e418570ba6458e9ea40420a999dbb8be11ddd22d62666bea88e366f732c7cfac33"+ "'", var2.equals("af78c5798e4bce5f867fb772ab4ae89803e418570ba6458e9ea40420a999dbb8be11ddd22d62666bea88e366f732c7cfac33"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.06578711824213442d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-2.400188641955425d));
// 
//   }

  public void test27() {}
//   public void test27() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test27"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     java.lang.String var4 = var0.nextHexString(110);
//     double var7 = var0.nextGamma(0.9999999999999971d, 1.151569395337692d);
//     org.apache.commons.math3.distribution.NormalDistribution var11 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var11.reseedRandomGenerator(1L);
//     boolean var14 = var11.isSupportConnected();
//     double var15 = var11.getMean();
//     double var16 = var11.getStandardDeviation();
//     double var17 = var11.getStandardDeviation();
//     double var20 = var11.cumulativeProbability(0.5d, 3.899584967339712E86d);
//     double var21 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var11);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var24 = var0.nextBeta(0.5723313665990505d, (-5.479216675175599E43d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.008330571096675676d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "13d008c6056befafc5820ad0c195157c79683ebb8443205640c221f90f3ce76b97ed7cea8972f28c15f859e06164fde5c229e2cdcec5ea"+ "'", var4.equals("13d008c6056befafc5820ad0c195157c79683ebb8443205640c221f90f3ce76b97ed7cea8972f28c15f859e06164fde5c229e2cdcec5ea"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.32623103105314366d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 2.6881171418161356E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 2.6881171418161356E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1.7319151371457245E42d);
// 
//   }

  public void test28() {}
//   public void test28() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test28"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.sqrt((-5.794109633340552E-10d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test29"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(50.000004f, 50.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 50.000004f);

  }

  public void test30() {}
//   public void test30() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test30"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     java.lang.String var4 = var0.nextHexString(110);
//     double var6 = var0.nextChiSquare(0.9865330122406505d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var0.nextBeta((-4.155599707401653d), (-1.0223787590678046d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.744103213937977d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "ee1c6f083b42ef0d3f9406ba590b176e115e8a8a231ac879c9283a1838c42dcf07b6e2f3fe3bc53c320fce715a3c05346ec2d6915da6aa"+ "'", var4.equals("ee1c6f083b42ef0d3f9406ba590b176e115e8a8a231ac879c9283a1838c42dcf07b6e2f3fe3bc53c320fce715a3c05346ec2d6915da6aa"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3.022902676155884d);
// 
//   }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test31"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(94L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test32() {}
//   public void test32() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test32"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     double var5 = var0.nextGaussian(0.0d, 0.5d);
//     var0.reSeed(10L);
//     double var10 = var0.nextF(1.3872175661331396d, 2.636818730233018d);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var14 = var0.nextSecureLong(27000L, 300L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.2918097280177072d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-0.1716499405641302d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5088599843857857d);
// 
//   }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test33"); }


    double var1 = org.apache.commons.math3.special.Erf.erf((-100.92211084316018d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test34"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(50.000008f, 1.1585384597896089E44d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 50.00001f);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test35"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(2.622236500484369d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.6916959825260405d);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test36"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)10.0d);
    java.lang.Number var2 = var1.getMax();
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var1.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var1.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var1.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 10.0d+ "'", var2.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test37() {}
//   public void test37() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test37"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
//     java.lang.String var2 = var1.name();
//     java.lang.String var3 = var1.toString();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var5.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var8 = var7.getNanStrategy();
//     java.lang.String var9 = var8.name();
//     java.lang.String var10 = var8.name();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var11 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var13 = var12.getTiesStrategy();
//     int var14 = var13.ordinal();
//     java.lang.String var15 = var13.name();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8, var13);
//     double[] var18 = new double[] { 1.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray(var18);
//     var19.setContractionCriteria(50.000008f);
//     var19.setExpansionMode(0);
//     boolean var24 = var13.equals((java.lang.Object)var19);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var25 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var6, var13);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var26 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var13);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var27 = null;
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var28 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var27);
//     org.apache.commons.math3.util.ResizableDoubleArray var33 = new org.apache.commons.math3.util.ResizableDoubleArray(2, 10.0f, 10.0f, 1);
//     org.apache.commons.math3.util.ResizableDoubleArray var34 = new org.apache.commons.math3.util.ResizableDoubleArray(var33);
//     org.apache.commons.math3.util.ResizableDoubleArray var35 = var33.copy();
//     double[] var36 = var35.getInternalValues();
//     org.apache.commons.math3.util.ResizableDoubleArray var37 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     var37.setContractionCriteria(5.0f);
//     var37.setElement(110, Double.NaN);
//     var37.discardFrontElements(10);
//     int var45 = var37.getExpansionMode();
//     double[] var47 = new double[] { 1.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var48 = new org.apache.commons.math3.util.ResizableDoubleArray(var47);
//     org.apache.commons.math3.util.ResizableDoubleArray var49 = new org.apache.commons.math3.util.ResizableDoubleArray(var47);
//     double[] var50 = var49.getElements();
//     var37.addElements(var50);
//     double var52 = var28.mannWhitneyU(var36, var50);
// 
//   }

  public void test38() {}
//   public void test38() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test38"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(1.8031769674261714E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test39"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(5, 768793337);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-768793332));

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test40"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(1, 645781745);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 645781746);

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test41"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(12700, 102399.99f, 50.000004f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test42() {}
//   public void test42() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test42"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh(0.4566344307670791d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test43"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.NotPositiveException var8 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(short)1);
    java.lang.Object[] var9 = new java.lang.Object[] { (short)1};
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var6, var9);
    org.apache.commons.math3.exception.MathInternalError var11 = new org.apache.commons.math3.exception.MathInternalError(var5, var9);
    java.lang.Object[] var12 = new java.lang.Object[] { var9};
    org.apache.commons.math3.exception.MathInternalError var13 = new org.apache.commons.math3.exception.MathInternalError(var4, var12);
    org.apache.commons.math3.exception.MathIllegalStateException var14 = new org.apache.commons.math3.exception.MathIllegalStateException(var3, var12);
    org.apache.commons.math3.exception.MathInternalError var15 = new org.apache.commons.math3.exception.MathInternalError(var2, var12);
    org.apache.commons.math3.exception.MaxCountExceededException var16 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)1.7430659953803302d, var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test44() {}
//   public void test44() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test44"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     java.lang.String var4 = var0.nextHexString(110);
//     double var7 = var0.nextGamma(0.9999999999999971d, 1.151569395337692d);
//     org.apache.commons.math3.distribution.NormalDistribution var11 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var11.reseedRandomGenerator(1L);
//     boolean var14 = var11.isSupportConnected();
//     double var15 = var11.getMean();
//     double var16 = var11.getStandardDeviation();
//     double var17 = var11.getStandardDeviation();
//     double var20 = var11.cumulativeProbability(0.5d, 3.899584967339712E86d);
//     double var21 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var11);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var24 = var0.nextBeta(1.5485965529242296d, (-100.92211084316018d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.4351724925616531d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "297bdf1945c9ade093000c3568ddc13aa4b98bfe3ff17170a320a65254ca785bb8c874f591279db1c44ad3052f1d617644b67271001d65"+ "'", var4.equals("297bdf1945c9ade093000c3568ddc13aa4b98bfe3ff17170a320a65254ca785bb8c874f591279db1c44ad3052f1d617644b67271001d65"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2.4032206335703994d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 2.6881171418161356E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 2.6881171418161356E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == (-1.0750235529935673E43d));
// 
//   }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test45"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(287, 70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2870);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test46"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var2.setContractionCriteria(50.000008f);
    double[] var5 = var2.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    int var7 = var2.start();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setExpansionFactor((-0.9999999f));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test47"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(126.32054207990153d, 0.9865330122406505d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.04431651309826634d);

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test48"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(0.10247043485974927d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.46795008060179255d);

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test49"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test50"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.lang.Number var3 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var4 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var2, var3);
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
    java.lang.Throwable[] var6 = var4.getSuppressed();
    org.apache.commons.math3.exception.MaxCountExceededException var7 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)94L, (java.lang.Object[])var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test51"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(0, 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test52"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(22927, 47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 335.0334109186577d);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test53"); }


    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(2, 10.0f, 10.0f, 1);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    double[] var7 = var6.getInternalValues();
    var6.addElement(7.381472028861085E-11d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test54"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(50.00001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 50.000015f);

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test55"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(2.5091784786580567d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5910937589642483d);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test56"); }


    long var2 = org.apache.commons.math3.util.FastMath.max((-92L), 75324600L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 75324600L);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test57"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan((-6.712617880482323E42d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.9739225021895803d));

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test58"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(5.1474095423356387E42d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 141);

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test59"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(49298L, 27898L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 49298L);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test60"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    java.lang.String var2 = var1.name();
    java.lang.String var3 = var1.toString();
    org.apache.commons.math3.exception.MathArithmeticException var4 = new org.apache.commons.math3.exception.MathArithmeticException();
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var6 = var4.getContext();
    boolean var7 = var1.equals((java.lang.Object)var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "MAXIMAL"+ "'", var2.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "MAXIMAL"+ "'", var3.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test61"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)50.000008f);
    java.lang.Number var3 = var2.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));

  }

  public void test62() {}
//   public void test62() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test62"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.0d, 4.5194037630894135d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test63"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(4.815792779656395E42d, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.815792779656395E42d);

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test64"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(2L, 27898L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2L);

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test65"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(31.4789883982983d, (-0.08494423315824018d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.5734947625231348d);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test66"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(90L, (-1L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test67"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.6969136111134943d, (-9.588492076026093E41d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.6969136111134943d);

  }

  public void test68() {}
//   public void test68() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test68"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     double var17 = var0.nextBeta(1.1265425086815434E43d, 1.1282937610745374d);
//     long var19 = var0.nextPoisson(31.402066659134473d);
//     java.lang.String var21 = var0.nextSecureHexString(47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "76908ceb4d2895b6a1499da1334ce68658c3253cb0de85bd2f8e2bb38c0dc058b24304b1fdf065dc67773e4183855f95939a"+ "'", var2.equals("76908ceb4d2895b6a1499da1334ce68658c3253cb0de85bd2f8e2bb38c0dc058b24304b1fdf065dc67773e4183855f95939a"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 4.752533803998109E42d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 27L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var21 + "' != '" + "9046f41e083910d9d508f93093454737ac93698efe80179"+ "'", var21.equals("9046f41e083910d9d508f93093454737ac93698efe80179"));
// 
//   }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test69"); }


    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.math.BigInteger var4 = null;
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var8 = new org.apache.commons.math3.exception.OutOfRangeException(var2, (java.lang.Number)100.0f, (java.lang.Number)var6, (java.lang.Number)0.5000672346092545d);
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    java.math.BigInteger var11 = null;
    java.math.BigInteger var13 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var15 = new org.apache.commons.math3.exception.OutOfRangeException(var9, (java.lang.Number)100.0f, (java.lang.Number)var13, (java.lang.Number)0.5000672346092545d);
    java.math.BigInteger var16 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, var13);
    java.math.BigInteger var18 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, 31L);
    org.apache.commons.math3.exception.OutOfRangeException var19 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)8.799063409660144E86d, (java.lang.Number)0.99999994f, (java.lang.Number)var6);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.math.BigInteger var21 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, (-9223372036854775268L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test70"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(22927, 61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test71() {}
//   public void test71() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test71"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     java.lang.String var4 = var0.nextHexString(110);
//     int var7 = var0.nextPascal(3, 0.0d);
//     int var10 = var0.nextSecureInt(47, 110);
//     var0.reSeedSecure(300L);
//     long var15 = var0.nextSecureLong(0L, 28798L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var19 = var0.nextHypergeometric(2, (-254), 20);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.31806907173001475d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "df785434fb215f7d5f7db9f9cca21a467f7072e78135e579d14d0f4302664d1b0a77ecb09521e50ba2541fe5eedbce30c3b73d160247d7"+ "'", var4.equals("df785434fb215f7d5f7db9f9cca21a467f7072e78135e579d14d0f4302664d1b0a77ecb09521e50ba2541fe5eedbce30c3b73d160247d7"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 21576L);
// 
//   }

  public void test72() {}
//   public void test72() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test72"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     var0.reSeed(1L);
//     java.lang.String var6 = var0.nextHexString(10);
//     double var9 = var0.nextUniform(8.451195606992581E-30d, 6.770911672198756d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var0.nextUniform(0.2523930260097898d, 0.117469904020025d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "c8de36ca120df883be97190f52eb821a74a884a17c7f33d120783071924ed3ee17bf6b7facb636e5eb0b23c8b941a26380d0"+ "'", var2.equals("c8de36ca120df883be97190f52eb821a74a884a17c7f33d120783071924ed3ee17bf6b7facb636e5eb0b23c8b941a26380d0"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "93042192d2"+ "'", var6.equals("93042192d2"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2.2682182275901375d);
// 
//   }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test73"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(102400.01f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 102400);

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test74"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(4.951760157141521E27d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 63.76954061151497d);

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test75"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.math.BigInteger var3 = null;
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var7 = new org.apache.commons.math3.exception.OutOfRangeException(var1, (java.lang.Number)100.0f, (java.lang.Number)var5, (java.lang.Number)0.5000672346092545d);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    java.math.BigInteger var10 = null;
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var10, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var14 = new org.apache.commons.math3.exception.OutOfRangeException(var8, (java.lang.Number)100.0f, (java.lang.Number)var12, (java.lang.Number)0.5000672346092545d);
    java.math.BigInteger var15 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, var12);
    org.apache.commons.math3.exception.util.Localizable var16 = null;
    java.lang.Object[] var19 = new java.lang.Object[] { '4'};
    org.apache.commons.math3.exception.MaxCountExceededException var20 = new org.apache.commons.math3.exception.MaxCountExceededException(var16, (java.lang.Number)Double.NaN, var19);
    java.lang.Throwable[] var21 = var20.getSuppressed();
    org.apache.commons.math3.exception.MaxCountExceededException var22 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)var5, (java.lang.Object[])var21);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.math.BigInteger var24 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, (-27000L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test76"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter((-5.329951075180856E43d), 0.35364893135754055d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-5.329951075180855E43d));

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test77"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(0.6120891811851691d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.702033134407494d);

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test78"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians((-0.08494423315824018d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.0014825565491930325d));

  }

  public void test79() {}
//   public void test79() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test79"); }
// 
// 
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
//     java.lang.String var3 = var2.name();
//     java.lang.String var4 = var2.name();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var5 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
//     int var8 = var7.ordinal();
//     java.lang.String var9 = var7.name();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var7);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var11 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var13 = var12.getTiesStrategy();
//     int var14 = var13.ordinal();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var15 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var13);
//     double[] var17 = new double[] { 1.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray(var17);
//     double[] var21 = new double[] { 1.0d, 100.0d};
//     var18.addElements(var21);
//     double[] var23 = var18.getInternalValues();
//     org.apache.commons.math3.util.ResizableDoubleArray var24 = new org.apache.commons.math3.util.ResizableDoubleArray(var23);
//     org.apache.commons.math3.util.ResizableDoubleArray var27 = new org.apache.commons.math3.util.ResizableDoubleArray(10, 50.0f);
//     var27.setElement(12700, 1.0806511876345213E86d);
//     org.apache.commons.math3.distribution.NormalDistribution var31 = new org.apache.commons.math3.distribution.NormalDistribution();
//     boolean var32 = var31.isSupportUpperBoundInclusive();
//     boolean var33 = var31.isSupportLowerBoundInclusive();
//     double var34 = var31.getMean();
//     double[] var36 = var31.sample(110);
//     var27.addElements(var36);
//     double var38 = var15.mannWhitneyUTest(var23, var36);
//     org.apache.commons.math3.util.ResizableDoubleArray var39 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     var39.contract();
//     org.apache.commons.math3.util.ResizableDoubleArray var41 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     var41.setContractionCriteria(5.0f);
//     var41.setElement(110, Double.NaN);
//     var41.setElement(100, (-0.6120891811851691d));
//     org.apache.commons.math3.util.ResizableDoubleArray.copy(var39, var41);
//     double[] var51 = var41.getElements();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var52 = var0.mannWhitneyU(var36, var51);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoDataException");
//     } catch (org.apache.commons.math3.exception.NoDataException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "MAXIMAL"+ "'", var3.equals("MAXIMAL"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "MAXIMAL"+ "'", var4.equals("MAXIMAL"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "AVERAGE"+ "'", var9.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 0.05423232845161463d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
// 
//   }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test80"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)0.6647615947356664d);
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var1.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test81() {}
//   public void test81() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test81"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     java.lang.String var4 = var0.nextHexString(110);
//     double var7 = var0.nextGamma(0.9999999999999971d, 1.151569395337692d);
//     double var9 = var0.nextT(1.2982587902415216E14d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var0.nextF((-4.192979513069657E43d), 6.109911595445588E43d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.737514318761784d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "441f3780ba6ddf4f8a7941bfaa9b559fd229866e4cc629da1dd5ac18bc2a8d25460f53620300e9940c6b58a71bc76053bb4f822b59fc31"+ "'", var4.equals("441f3780ba6ddf4f8a7941bfaa9b559fd229866e4cc629da1dd5ac18bc2a8d25460f53620300e9940c6b58a71bc76053bb4f822b59fc31"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.0973131142185028d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.5077523993644797d);
// 
//   }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test82"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.2212373401672254d, 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.2212373401672254d);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test83"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(5.551115123125783E-17d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test84"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(2.6881171418161356E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test85"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(1.021295736467202d, 0.9935433396122214d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.021295736467202d);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test86"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder((-1.7925274837903817d), 1.5485965529242296d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.24393093086615214d));

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test87"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    double var4 = var3.getSupportLowerBound();
    double var6 = var3.probability(6.419286864170918E43d);
    boolean var7 = var3.isSupportUpperBoundInclusive();
    double var10 = var3.cumulativeProbability(0.0d, 0.10561069428565839d);
    double var11 = var3.getSupportUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1.567363659778374E-45d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == Double.POSITIVE_INFINITY);

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test88"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray((-90), 50.000015f, 9.999999f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test89"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(100.0d, 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 800.0d);

  }

  public void test90() {}
//   public void test90() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test90"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     double var4 = var0.nextExponential(0.056182176564052d);
//     double var7 = var0.nextGamma((-2.0537907646431078E43d), 5.840802579076462E13d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var10 = var0.nextLong(862L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "fb266cae9e62f385a130201ab44b8fd620299a24340ddcb46e3f0db5ee28a7d2d1c286afea97effc1a587505f2b136ab1a51"+ "'", var2.equals("fb266cae9e62f385a130201ab44b8fd620299a24340ddcb46e3f0db5ee28a7d2d1c286afea97effc1a587505f2b136ab1a51"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.07685789981320433d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == Double.NaN);
// 
//   }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test91"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)2.9681911862806774E-44d, var1, false);
    java.lang.Number var4 = var3.getArgument();
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var3.getContext();
    boolean var6 = var3.getBoundIsAllowed();
    boolean var7 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 2.9681911862806774E-44d+ "'", var4.equals(2.9681911862806774E-44d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test92"); }


    double var1 = org.apache.commons.math3.util.FastMath.acos(4.9784122222889134E-60d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5707963267948966d);

  }

  public void test93() {}
//   public void test93() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test93"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.log((-5.2432435475000995E42d), 1.7151785181287122d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test94() {}
//   public void test94() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test94"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     java.lang.Object[] var4 = new java.lang.Object[] { '4'};
//     org.apache.commons.math3.exception.MaxCountExceededException var5 = new org.apache.commons.math3.exception.MaxCountExceededException(var1, (java.lang.Number)Double.NaN, var4);
//     java.lang.Throwable[] var6 = var5.getSuppressed();
//     org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var6);
//     java.lang.String var8 = var7.toString();
// 
//   }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test95"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)1.7130083828445737d, (java.lang.Number)50.0f, (java.lang.Number)9.143324706424012E42d);
    java.lang.Number var5 = null;
    org.apache.commons.math3.exception.OutOfRangeException var7 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)31L, var5, (java.lang.Number)76.42898646301789d);
    var3.addSuppressed((java.lang.Throwable)var7);

  }

  public void test96() {}
//   public void test96() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test96"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     double var16 = var0.nextWeibull(1.0d, 1.6298598478788293d);
//     double var19 = var0.nextWeibull(1.151569395337692d, 7.22597376812575E86d);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var22 = var0.nextSecureHexString((-4));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "33e53281da832753520b305acba9d8ebe8116b5cc3f083bbe2a283958ea9aef94f1df36e9fbbd1d50fcda61771900d53f0f2"+ "'", var2.equals("33e53281da832753520b305acba9d8ebe8116b5cc3f083bbe2a283958ea9aef94f1df36e9fbbd1d50fcda61771900d53f0f2"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-3.0759067441795004E43d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 2.0746279117502784d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1.2214393533825553E87d);
// 
//   }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test97"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var5 = new double[] { 1.0d, 100.0d};
    var2.addElements(var5);
    double[] var7 = var2.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    int var9 = var8.getExpansionMode();
    float var10 = var8.getExpansionFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 2.0f);

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test98"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1.0912873587286057E-45d, false);

  }

  public void test99() {}
//   public void test99() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test99"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     boolean var9 = var6.isSupportConnected();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     double var12 = var6.probability(6.0d);
//     double var15 = var6.cumulativeProbability((-2.1317761108019555d), 0.9640275797804917d);
//     boolean var16 = var6.isSupportUpperBoundInclusive();
//     double var18 = var6.probability((-238.09832457991453d));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double[] var20 = var6.sample((-127));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "662f488704f0a187ca31f12440391c7a13942a066ac2901dcaa8efff66b6b19ff12b7740b8cf52d1d2daa1d41c2ffe44fe70"+ "'", var2.equals("662f488704f0a187ca31f12440391c7a13942a066ac2901dcaa8efff66b6b19ff12b7740b8cf52d1d2daa1d41c2ffe44fe70"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 4.4854868851094094E42d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 4.594468614421035E-44d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.0d);
// 
//   }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test100"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(4.605170185988092d, 0.015050303523504572d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.605170185988091d);

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test101"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(100, 100.0f);
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.OutOfRangeException var7 = new org.apache.commons.math3.exception.OutOfRangeException(var3, (java.lang.Number)1.4640953062334716d, (java.lang.Number)Double.NEGATIVE_INFINITY, (java.lang.Number)1.0d);
    boolean var8 = var2.equals((java.lang.Object)var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setExpansionMode(5);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test102"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.addElement(0.02797455810085192d);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var3 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var5 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray(var5);
    var6.setContractionCriteria(50.000008f);
    double[] var9 = var6.getInternalValues();
    double[] var11 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var11);
    var12.setContractionCriteria(50.000008f);
    double[] var15 = var12.getInternalValues();
    double[] var16 = var12.getElements();
    double var17 = var3.mannWhitneyU(var9, var16);
    var0.addElements(var9);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setExpansionMode(47);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.5d);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test103"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(63.76954061151497d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test104"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign((-0.99999994f), 2.5000002f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.99999994f);

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test105"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(111, 2.3841858E-7f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test106() {}
//   public void test106() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test106"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     double var5 = var0.nextCauchy(0.0d, 6.770911672198756d);
//     java.util.Collection var6 = null;
//     java.lang.Object[] var8 = var0.nextSample(var6, 1612922);
// 
//   }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test107"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)1.1585384597896089E44d);

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test108"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    java.lang.String var2 = var1.toString();
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.NotPositiveException var5 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(short)1);
    java.lang.Object[] var6 = new java.lang.Object[] { (short)1};
    org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException(var3, var6);
    boolean var8 = var1.equals((java.lang.Object)var3);
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    int var10 = var1.ordinal();
    java.lang.String var11 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "MAXIMAL"+ "'", var2.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "MAXIMAL"+ "'", var11.equals("MAXIMAL"));

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test109"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(100, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test110"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(68397.35544481203d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test111"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(61, (-90));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test112"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.0d, 0.645632820750788d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.645632820750788d);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test113"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(436.05387683681073d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test114"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.NotPositiveException var7 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(short)1);
    java.lang.Object[] var8 = new java.lang.Object[] { (short)1};
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException(var5, var8);
    org.apache.commons.math3.exception.MathArithmeticException var10 = new org.apache.commons.math3.exception.MathArithmeticException(var4, var8);
    org.apache.commons.math3.exception.MaxCountExceededException var11 = new org.apache.commons.math3.exception.MaxCountExceededException(var2, (java.lang.Number)1.3872175661331396d, var8);
    org.apache.commons.math3.exception.MathIllegalArgumentException var12 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, var8);
    org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test115"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(20500L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 20500L);

  }

  public void test116() {}
//   public void test116() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test116"); }
// 
// 
//     org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     var0.setContractionCriteria(5.0f);
//     org.apache.commons.math3.random.RandomDataImpl var3 = new org.apache.commons.math3.random.RandomDataImpl();
//     boolean var4 = var0.equals((java.lang.Object)var3);
//     long var6 = var3.nextPoisson(1.8622531212727638d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var3.nextUniform(0.4349627593755754d, (-4.874405868194998E42d), false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3L);
// 
//   }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test117"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(1.0f, 2.3841858E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.3841858E-7f);

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test118"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(4.5194037630894135d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.0d);

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test119"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("df05634d7c1839c260864d12f314c5b6259f04a10ebb71688dc62c1abe42598439eb93cbd80f379311e8dc04dafa1a96b4f4");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test120"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(27900L, (-9223372036854775808L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-9223372036854775808L));

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test121"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(2.0000002f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test122() {}
//   public void test122() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test122"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     double var5 = var0.nextCauchy(0.0d, 6.770911672198756d);
//     int var9 = var0.nextHypergeometric(10, 0, 3);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var0.nextT((-3.173462429162327E42d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "dd7dee4d1e3b5c00ba21bb348bd806625e808973f8916739bba0228f97b9ce4e0ccf9ec4cb2a83a0f0212a58d2ca7d6ae40c"+ "'", var2.equals("dd7dee4d1e3b5c00ba21bb348bd806625e808973f8916739bba0228f97b9ce4e0ccf9ec4cb2a83a0f0212a58d2ca7d6ae40c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 5.515853455947765d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
// 
//   }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test123"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var2.setContractionCriteria(5.0f);
    var2.setElement(110, Double.NaN);
    var2.setElement(100, (-0.6120891811851691d));
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var13 = var12.getNanStrategy();
    java.lang.String var14 = var13.name();
    java.lang.String var15 = var13.name();
    org.apache.commons.math3.stat.ranking.NaNStrategy var16 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var16);
    org.apache.commons.math3.stat.ranking.TiesStrategy var18 = var17.getTiesStrategy();
    int var19 = var18.ordinal();
    java.lang.String var20 = var18.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var13, var18);
    org.apache.commons.math3.stat.ranking.NaNStrategy var22 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var22);
    org.apache.commons.math3.stat.ranking.TiesStrategy var24 = var23.getTiesStrategy();
    int var25 = var24.ordinal();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var26 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var13, var24);
    double[] var28 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var29 = new org.apache.commons.math3.util.ResizableDoubleArray(var28);
    var29.setContractionCriteria(50.000008f);
    double[] var32 = var29.getInternalValues();
    double[] var33 = var29.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var34 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var34.addElement(0.02797455810085192d);
    var34.discardFrontElements(1);
    org.apache.commons.math3.util.ResizableDoubleArray var39 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var40 = var39.getInternalValues();
    var34.addElements(var40);
    double var42 = var26.mannWhitneyUTest(var33, var40);
    var0.addElements(var40);
    double var45 = var0.substituteMostRecentElement(4.9E-324d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setExpansionFactor(100.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "MAXIMAL"+ "'", var14.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "MAXIMAL"+ "'", var15.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "AVERAGE"+ "'", var20.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0.10247043485974927d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.0d);

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test124"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp((-0.9064833280591146d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.40394226160288377d);

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test125"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(2432902008176640000L, 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2432902008176640001L);

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test126"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    int var4 = var3.getNumElements();
    double var6 = var3.addElementRolling(1.2982587902415216E14d);
    var3.setNumElements(3);
    int var9 = var3.getNumElements();
    var3.addElement(1.999999995819933d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 3);

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test127"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(0.10247043485974927d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test128"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var2 = var0.addElementRolling(4.629628685877713E42d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = var0.getElement(1496370343);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test129"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(0.4273372138374235d, 0.6647615947356664d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.19845492814580867d);

  }

  public void test130() {}
//   public void test130() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test130"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     double var16 = var0.nextWeibull(1.0d, 1.6298598478788293d);
//     double var19 = var0.nextWeibull(1.151569395337692d, 7.22597376812575E86d);
//     var0.reSeedSecure();
//     var0.reSeedSecure(0L);
//     double var24 = var0.nextChiSquare(0.9640275797804917d);
//     double var26 = var0.nextExponential(0.028514560146996132d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var29 = var0.nextPascal(227, 7.22597376812575E86d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "64ae1354d246b1e7a9a8fdf1e9ac12081076c5a523e4a71f06580d1ec3d883cb381a56ea6cd67b6fb70e67f2b6904cf46cdd"+ "'", var2.equals("64ae1354d246b1e7a9a8fdf1e9ac12081076c5a523e4a71f06580d1ec3d883cb381a56ea6cd67b6fb70e67f2b6904cf46cdd"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 4.8528236623418215E42d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 4.745970233916842d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 3.176673994330439E87d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0.37398213915614326d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 0.0010044050478822412d);
// 
//   }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test131"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(102400.01f, 768793337);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.POSITIVE_INFINITY);

  }

  public void test132() {}
//   public void test132() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test132"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     double var4 = var0.nextChiSquare(0.5d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var8 = var0.nextHypergeometric(2, 70, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 3.0567335163023093d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.3591939027534996d);
// 
//   }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test133"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(61, 1.0f, 50.000004f, 52037);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test134"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(1.4E-45f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-127));

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test135"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot((-0.4960846371049067d), 2.1317761108019555d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.1887369311448595d);

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test136"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(-0.9366718398504545d), (java.lang.Number)(-3.378211155916252E42d), true);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test137"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(75324600L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 75324600L);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test138"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(1.5485965529242296d, (-3.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.3761148208745517d);

  }

  public void test139() {}
//   public void test139() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test139"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh(2.2530284241517084E-8d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test140"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(1.293606294858882E100d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.3474735454811792E33d);

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test141"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck((-127), (-100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 12700);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test142"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.03674973340708589d);
    java.lang.Number var2 = var1.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0.03674973340708589d+ "'", var2.equals(0.03674973340708589d));

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test143"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(645781745, 1612775);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test144"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp((-2.1317761108019555d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-2.131776110801955d));

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test145"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2((-1.9544896811699656E43d), (-1.9739225021895803d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.5707963267948966d));

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test146"); }


    double var1 = org.apache.commons.math3.util.FastMath.acos(0.5434235565682811d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.996286284644239d);

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test147"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.06535479195982165d, 0.117469904020025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.7258230469631404d);

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test148"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.math.BigInteger var2 = null;
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var6 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)100.0f, (java.lang.Number)var4, (java.lang.Number)0.5000672346092545d);
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    java.math.BigInteger var9 = null;
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var13 = new org.apache.commons.math3.exception.OutOfRangeException(var7, (java.lang.Number)100.0f, (java.lang.Number)var11, (java.lang.Number)0.5000672346092545d);
    java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, var11);
    java.math.BigInteger var16 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 10L);
    org.apache.commons.math3.exception.OutOfRangeException var19 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)var16, (java.lang.Number)4.951760157141521E27d, (java.lang.Number)0.5088599843857857d);
    org.apache.commons.math3.exception.NotStrictlyPositiveException var20 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)4.951760157141521E27d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test149"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(862L, 49298L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-48436L));

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test150"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var5 = new double[] { 1.0d, 100.0d};
    var2.addElements(var5);
    double var8 = var2.addElementRolling(0.9999999985344892d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test151"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(5.0f);
    var0.setElement(110, Double.NaN);
    var0.discardFrontElements(10);
    var0.discardMostRecentElements(96);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var11 = var0.getElement(645781745);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test152"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var2.clear();
    var2.addElement((-3.0d));
    var2.contract();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test153"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(3, 47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 141);

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test154"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(2L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test155"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    boolean var1 = var0.isSupportUpperBoundInclusive();
    boolean var2 = var0.isSupportLowerBoundInclusive();
    double var3 = var0.getMean();
    double[] var5 = var0.sample(110);
    boolean var6 = var0.isSupportLowerBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test156() {}
//   public void test156() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test156"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     double var16 = var0.nextWeibull(1.0d, 1.6298598478788293d);
//     double var19 = var0.nextWeibull(1.151569395337692d, 7.22597376812575E86d);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var23 = var0.nextInt(111, (-90));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "b7a1148ed38b53688865098190237680ab923fe9a874d635a0af590b39c5a4b7f591062d6d031a512b8c7d1771726441008c"+ "'", var2.equals("b7a1148ed38b53688865098190237680ab923fe9a874d635a0af590b39c5a4b7f591062d6d031a512b8c7d1771726441008c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.3014471600320498E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1.0789048466827993d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1.0716458025889524E86d);
// 
//   }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test157"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(3.3030345912774096E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.3030345912774096E43d);

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test158"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1.0713813143399866d, (java.lang.Number)1.3057219004014247d, true);
    java.lang.Number var5 = var4.getMax();
    boolean var6 = var4.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1.3057219004014247d+ "'", var5.equals(1.3057219004014247d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test159"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(1.6298598478788293d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.6298598478788293d);

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test160"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(1.1597528820798812E14d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 115975288207988L);

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test161"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(28798L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test162"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(100.5f, 100.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100.5f);

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test163"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var2.setContractionCriteria(50.000008f);
    double[] var5 = var2.getInternalValues();
    double[] var6 = var2.getElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.discardFrontElements(10);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test164"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.math.BigInteger var2 = null;
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var6 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)100.0f, (java.lang.Number)var4, (java.lang.Number)0.5000672346092545d);
    java.lang.Number var7 = var6.getArgument();
    java.lang.Number var8 = var6.getHi();
    org.apache.commons.math3.exception.util.ExceptionContext var9 = var6.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 100.0f+ "'", var7.equals(100.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 0.5000672346092545d+ "'", var8.equals(0.5000672346092545d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test165"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.math.BigInteger var6 = null;
    java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var10 = new org.apache.commons.math3.exception.OutOfRangeException(var4, (java.lang.Number)100.0f, (java.lang.Number)var8, (java.lang.Number)0.5000672346092545d);
    org.apache.commons.math3.exception.util.Localizable var11 = null;
    java.math.BigInteger var13 = null;
    java.math.BigInteger var15 = org.apache.commons.math3.util.ArithmeticUtils.pow(var13, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var17 = new org.apache.commons.math3.exception.OutOfRangeException(var11, (java.lang.Number)100.0f, (java.lang.Number)var15, (java.lang.Number)0.5000672346092545d);
    java.math.BigInteger var18 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, var15);
    java.math.BigInteger var20 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, 31L);
    org.apache.commons.math3.exception.OutOfRangeException var21 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)8.799063409660144E86d, (java.lang.Number)0.99999994f, (java.lang.Number)var8);
    org.apache.commons.math3.exception.util.Localizable var22 = null;
    org.apache.commons.math3.exception.util.Localizable var23 = null;
    org.apache.commons.math3.exception.NotPositiveException var25 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(short)1);
    java.lang.Object[] var26 = new java.lang.Object[] { (short)1};
    org.apache.commons.math3.exception.MathIllegalStateException var27 = new org.apache.commons.math3.exception.MathIllegalStateException(var23, var26);
    org.apache.commons.math3.exception.MathIllegalStateException var28 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var21, var22, var26);
    org.apache.commons.math3.exception.MathInternalError var29 = new org.apache.commons.math3.exception.MathInternalError(var1, var26);
    org.apache.commons.math3.exception.MathIllegalStateException var30 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test166"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(111);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 111);

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test167"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(9.45825370755923E42d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test168() {}
//   public void test168() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test168"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     double var17 = var0.nextGamma(0.9775852669347048d, 3.199763873047224E14d);
//     double var20 = var0.nextUniform(0.0d, 8.799063409660144E86d);
//     var0.reSeed();
//     org.apache.commons.math3.distribution.NormalDistribution var22 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var23 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var22);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var26 = var22.cumulativeProbability(7.942528294953089E86d, 5.694508929246172E14d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "3c731dbaf4232f2a7d11eb6c6ff2004d312ea40a8e2db954f25932472b0b5c7b7913363bcb1b76c1200d86af34e00f58a663"+ "'", var2.equals("3c731dbaf4232f2a7d11eb6c6ff2004d312ea40a8e2db954f25932472b0b5c7b7913363bcb1b76c1200d86af34e00f58a663"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-9.344695034144519E42d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 5.633075902206751E13d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 8.720758382166722E86d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == (-0.3476297550004014d));
// 
//   }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test169"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var2 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var3.setContractionCriteria(50.000008f);
    double[] var6 = var3.getInternalValues();
    double[] var8 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
    var9.setContractionCriteria(50.000008f);
    double[] var12 = var9.getInternalValues();
    double[] var13 = var9.getElements();
    double var14 = var0.mannWhitneyUTest(var6, var13);
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var13);
    var15.contract();
    int var17 = var15.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test170"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1((-100.92211084316018d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test171() {}
//   public void test171() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test171"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var17 = var0.nextSecureLong(0L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "59a074ab83459e806655771432d7713a7619e6cc48bc31a7dd291df1a0255d6059e52e05d8d2afeb84b380de98ca30d23787"+ "'", var2.equals("59a074ab83459e806655771432d7713a7619e6cc48bc31a7dd291df1a0255d6059e52e05d8d2afeb84b380de98ca30d23787"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 5.454346516782942E43d);
// 
//   }

  public void test172() {}
//   public void test172() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test172"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(3.693917551910061E13d, 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test173() {}
//   public void test173() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test173"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     double var17 = var0.nextGamma(0.9775852669347048d, 3.199763873047224E14d);
//     double var20 = var0.nextUniform(0.0d, 8.799063409660144E86d);
//     org.apache.commons.math3.distribution.NormalDistribution var24 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var24.reseedRandomGenerator(1L);
//     boolean var27 = var24.isSupportConnected();
//     double var28 = var24.getMean();
//     double var29 = var24.sample();
//     double var30 = var24.getSupportUpperBound();
//     boolean var31 = var24.isSupportUpperBoundInclusive();
//     boolean var32 = var24.isSupportUpperBoundInclusive();
//     double var33 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var24);
//     double var37 = var0.nextUniform((-3.4536536242642804E43d), 0.1672559658154289d, true);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var41 = var0.nextHypergeometric(66, 0, 645781745);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "adefc8d7ff6b5895e7272bff63af9f893705e6bc916aa90f7d4c4fb5c69630e2c19cd000f052c720d4a0f70eed82a22ed628"+ "'", var2.equals("adefc8d7ff6b5895e7272bff63af9f893705e6bc916aa90f7d4c4fb5c69630e2c19cd000f052c720d4a0f70eed82a22ed628"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-3.5232147221222364E43d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 3.942912325248749E13d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 6.774797120282563E85d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 3.5671315446818194E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == (-4.78091731778863E43d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == (-2.4851875290066193E43d));
// 
//   }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test174"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.9999999981643266d, 0.6362189423446424d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.1852318502836434d);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test175"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(0.21212719734331667d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-4.987930596591171d));

  }

  public void test176() {}
//   public void test176() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test176"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var16 = var0.nextExponential(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "81c13d55b2f6c5318a920a16ff88373ffff088e97941f1ef8e4bbf344276fdfc721f12678d42c75a8b500fdeb3419c520ec1"+ "'", var2.equals("81c13d55b2f6c5318a920a16ff88373ffff088e97941f1ef8e4bbf344276fdfc721f12678d42c75a8b500fdeb3419c520ec1"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-1.0007807892549421E43d));
// 
//   }

  public void test177() {}
//   public void test177() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test177"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     double var17 = var0.nextUniform(0.5274450245437947d, 0.6040929060689715d, false);
//     java.util.Collection var18 = null;
//     java.lang.Object[] var20 = var0.nextSample(var18, 110);
// 
//   }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test178"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble(70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1978571669969933E100d);

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test179"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(4.246383128529704E21d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test180"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog((-100));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test181() {}
//   public void test181() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test181"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     java.lang.String var4 = var0.nextHexString(110);
//     int var7 = var0.nextPascal(3, 0.0d);
//     int var10 = var0.nextSecureInt(47, 110);
//     var0.reSeedSecure(300L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var0.nextWeibull(0.0d, 1365503.475321342d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.911194678265069d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "13c9a8382e6065b883d03c60f38fb9c0f68c0eddf2b23ae3203a61995128064d9156b424b9f2ea51fd8d7dddcfec8b32fbe6f56bb8c0a0"+ "'", var4.equals("13c9a8382e6065b883d03c60f38fb9c0f68c0eddf2b23ae3203a61995128064d9156b424b9f2ea51fd8d7dddcfec8b32fbe6f56bb8c0a0"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 65);
// 
//   }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test182"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(1612820, 2.5000002f, 0.0f, 12700);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test183"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(68397.35544481203d, 1.1004260542535134d, 6.722308758188109E59d, 4233);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test184"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(12827000, 94L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test185"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(100, 100.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = var2.copy();
    double[] var4 = var3.getInternalValues();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test186"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var3 = new java.lang.Object[] { '4'};
    org.apache.commons.math3.exception.MaxCountExceededException var4 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)Double.NaN, var3);
    java.lang.Number var5 = var4.getMax();
    java.lang.Number var6 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + Double.NaN+ "'", var5.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + Double.NaN+ "'", var6.equals(Double.NaN));

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test187"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(1.0244211201800262E14d, 0.02797455810085192d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0244211201800262E14d);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test188"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(3.3821920585064405E42d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.8390736957790573E21d);

  }

  public void test189() {}
//   public void test189() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test189"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     double var17 = var0.nextBeta(1.1265425086815434E43d, 1.1282937610745374d);
//     long var19 = var0.nextPoisson(31.402066659134473d);
//     long var22 = var0.nextSecureLong(0L, 6L);
//     int var25 = var0.nextInt(0, 2147483647);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var28 = var0.nextGaussian(8.451195606992581E-30d, (-0.1204050495694422d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "85a3c2792169dfdccde500abd499a4180aaa6585e51973c27d0a552f9779c143c378fe70a059f7e77e402f7806890cf79995"+ "'", var2.equals("85a3c2792169dfdccde500abd499a4180aaa6585e51973c27d0a552f9779c143c378fe70a059f7e77e402f7806890cf79995"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-1.919756914743361E43d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.9999999985798501d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 24L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 5L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1802965075);
// 
//   }

  public void test190() {}
//   public void test190() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test190"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1.538521790062942d, (java.lang.Number)0.015050303523504572d, true);
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     org.apache.commons.math3.exception.util.Localizable var6 = null;
//     org.apache.commons.math3.exception.util.Localizable var7 = null;
//     org.apache.commons.math3.exception.util.Localizable var8 = null;
//     java.lang.Number var9 = null;
//     org.apache.commons.math3.exception.NotStrictlyPositiveException var10 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var8, var9);
//     org.apache.commons.math3.exception.util.ExceptionContext var11 = var10.getContext();
//     java.lang.Throwable[] var12 = var10.getSuppressed();
//     org.apache.commons.math3.exception.MathInternalError var13 = new org.apache.commons.math3.exception.MathInternalError(var7, (java.lang.Object[])var12);
//     org.apache.commons.math3.exception.MathInternalError var14 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var12);
//     org.apache.commons.math3.exception.MathIllegalStateException var15 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var5, (java.lang.Object[])var12);
// 
//   }

  public void test191() {}
//   public void test191() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test191"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     java.lang.String var4 = var0.nextHexString(110);
//     double var7 = var0.nextGamma(0.9999999999999971d, 1.151569395337692d);
//     org.apache.commons.math3.distribution.NormalDistribution var11 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var11.reseedRandomGenerator(1L);
//     boolean var14 = var11.isSupportConnected();
//     double var15 = var11.getMean();
//     double var16 = var11.getStandardDeviation();
//     double var17 = var11.getStandardDeviation();
//     double var20 = var11.cumulativeProbability(0.5d, 3.899584967339712E86d);
//     double var21 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var11);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var24 = var0.nextInt(4400, 54);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.014698537037289293d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "7c9da9b243063b3a5fcd4e769c7ac443e65d53000129b147fc79e8f2506e34e2b25e143f9f25a2243fed05654be04875ede33f53b25070"+ "'", var4.equals("7c9da9b243063b3a5fcd4e769c7ac443e65d53000129b147fc79e8f2506e34e2b25e143f9f25a2243fed05654be04875ede33f53b25070"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2.0962986082804727d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 2.6881171418161356E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 2.6881171418161356E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == (-5.135234159744003E43d));
// 
//   }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test192"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var3 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var1, var2);
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var3.getContext();
    java.lang.Throwable[] var5 = var3.getSuppressed();
    org.apache.commons.math3.exception.MathArithmeticException var6 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test193"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(102400.01f, 9.999999f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 102400.01f);

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test194"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(4.629628685877712E42d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 8.080226371334438E40d);

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test195"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck((-9223372036854775268L), 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test196"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(5.0f);
    var0.setElement(110, Double.NaN);
    var0.discardFrontElements(10);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var8.setContractionCriteria(50.000008f);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var8);
    int var12 = var8.getExpansionMode();
    var8.setExpansionMode(0);
    var8.clear();
    var8.setNumElements(287);
    var8.addElement(1.5485965529242296d);
    double var21 = var8.substituteMostRecentElement(0.6647615947356664d);
    int var22 = var8.getNumElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1.5485965529242296d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 288);

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test197"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(96, 145);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test198"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.math.BigInteger var5 = null;
    java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var9 = new org.apache.commons.math3.exception.OutOfRangeException(var3, (java.lang.Number)100.0f, (java.lang.Number)var7, (java.lang.Number)0.5000672346092545d);
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    java.math.BigInteger var12 = null;
    java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var16 = new org.apache.commons.math3.exception.OutOfRangeException(var10, (java.lang.Number)100.0f, (java.lang.Number)var14, (java.lang.Number)0.5000672346092545d);
    java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, var14);
    org.apache.commons.math3.exception.util.Localizable var18 = null;
    java.lang.Object[] var21 = new java.lang.Object[] { '4'};
    org.apache.commons.math3.exception.MaxCountExceededException var22 = new org.apache.commons.math3.exception.MaxCountExceededException(var18, (java.lang.Number)Double.NaN, var21);
    java.lang.Throwable[] var23 = var22.getSuppressed();
    org.apache.commons.math3.exception.MaxCountExceededException var24 = new org.apache.commons.math3.exception.MaxCountExceededException(var2, (java.lang.Number)var7, (java.lang.Object[])var23);
    org.apache.commons.math3.exception.MaxCountExceededException var25 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)var7);
    org.apache.commons.math3.exception.util.Localizable var26 = null;
    java.lang.Object[] var29 = new java.lang.Object[] { '4'};
    org.apache.commons.math3.exception.MaxCountExceededException var30 = new org.apache.commons.math3.exception.MaxCountExceededException(var26, (java.lang.Number)Double.NaN, var29);
    java.lang.Throwable[] var31 = var30.getSuppressed();
    org.apache.commons.math3.exception.MaxCountExceededException var32 = new org.apache.commons.math3.exception.MaxCountExceededException(var1, (java.lang.Number)var7, (java.lang.Object[])var31);
    org.apache.commons.math3.exception.NumberIsTooLargeException var35 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)var7, (java.lang.Number)7.73868401503849E-14d, true);
    boolean var36 = var35.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test199"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = var2.copy();
    var2.addElement(0.0018388436884212223d);
    int var6 = var2.start();
    int var7 = var2.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test200"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.math.BigInteger var6 = null;
    java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var10 = new org.apache.commons.math3.exception.OutOfRangeException(var4, (java.lang.Number)100.0f, (java.lang.Number)var8, (java.lang.Number)0.5000672346092545d);
    org.apache.commons.math3.exception.util.Localizable var11 = null;
    java.math.BigInteger var13 = null;
    java.math.BigInteger var15 = org.apache.commons.math3.util.ArithmeticUtils.pow(var13, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var17 = new org.apache.commons.math3.exception.OutOfRangeException(var11, (java.lang.Number)100.0f, (java.lang.Number)var15, (java.lang.Number)0.5000672346092545d);
    java.math.BigInteger var18 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, var15);
    org.apache.commons.math3.exception.util.Localizable var19 = null;
    java.lang.Object[] var22 = new java.lang.Object[] { '4'};
    org.apache.commons.math3.exception.MaxCountExceededException var23 = new org.apache.commons.math3.exception.MaxCountExceededException(var19, (java.lang.Number)Double.NaN, var22);
    java.lang.Throwable[] var24 = var23.getSuppressed();
    org.apache.commons.math3.exception.MaxCountExceededException var25 = new org.apache.commons.math3.exception.MaxCountExceededException(var3, (java.lang.Number)var8, (java.lang.Object[])var24);
    org.apache.commons.math3.exception.MaxCountExceededException var26 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)var8);
    org.apache.commons.math3.exception.util.Localizable var27 = null;
    java.lang.Object[] var30 = new java.lang.Object[] { '4'};
    org.apache.commons.math3.exception.MaxCountExceededException var31 = new org.apache.commons.math3.exception.MaxCountExceededException(var27, (java.lang.Number)Double.NaN, var30);
    java.lang.Throwable[] var32 = var31.getSuppressed();
    org.apache.commons.math3.exception.MaxCountExceededException var33 = new org.apache.commons.math3.exception.MaxCountExceededException(var2, (java.lang.Number)var8, (java.lang.Object[])var32);
    org.apache.commons.math3.exception.MaxCountExceededException var34 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)(-3941415383162945536L), (java.lang.Object[])var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test201"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(-90L));

  }

  public void test202() {}
//   public void test202() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test202"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(1.1265425086815431E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test203"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(54, (-90));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test204"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.math.BigInteger var4 = null;
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var8 = new org.apache.commons.math3.exception.OutOfRangeException(var2, (java.lang.Number)100.0f, (java.lang.Number)var6, (java.lang.Number)0.5000672346092545d);
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    java.math.BigInteger var11 = null;
    java.math.BigInteger var13 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var15 = new org.apache.commons.math3.exception.OutOfRangeException(var9, (java.lang.Number)100.0f, (java.lang.Number)var13, (java.lang.Number)0.5000672346092545d);
    java.math.BigInteger var16 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, var13);
    org.apache.commons.math3.exception.util.Localizable var17 = null;
    java.lang.Object[] var20 = new java.lang.Object[] { '4'};
    org.apache.commons.math3.exception.MaxCountExceededException var21 = new org.apache.commons.math3.exception.MaxCountExceededException(var17, (java.lang.Number)Double.NaN, var20);
    java.lang.Throwable[] var22 = var21.getSuppressed();
    org.apache.commons.math3.exception.MaxCountExceededException var23 = new org.apache.commons.math3.exception.MaxCountExceededException(var1, (java.lang.Number)var6, (java.lang.Object[])var22);
    org.apache.commons.math3.exception.MaxCountExceededException var24 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)var6);
    org.apache.commons.math3.exception.util.Localizable var25 = null;
    java.lang.Object[] var28 = new java.lang.Object[] { '4'};
    org.apache.commons.math3.exception.MaxCountExceededException var29 = new org.apache.commons.math3.exception.MaxCountExceededException(var25, (java.lang.Number)Double.NaN, var28);
    java.lang.Throwable[] var30 = var29.getSuppressed();
    org.apache.commons.math3.exception.MaxCountExceededException var31 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)var6, (java.lang.Object[])var30);
    java.lang.Number var32 = var31.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test205"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(33.50507345013689d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.03029605514406195d);

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test206"); }


    double[] var0 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setExpansionFactor(100.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test207"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(1496370343, 645781746);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test208"); }


    java.lang.Number var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, var1, false);

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test209"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    java.lang.String var2 = var1.name();
    java.lang.String var3 = var1.name();
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var5.getTiesStrategy();
    int var7 = var6.ordinal();
    java.lang.String var8 = var6.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var6);
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = var11.getTiesStrategy();
    int var13 = var12.ordinal();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var14 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var12);
    double[] var16 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var17 = new org.apache.commons.math3.util.ResizableDoubleArray(var16);
    var17.setContractionCriteria(50.000008f);
    double[] var20 = var17.getInternalValues();
    double[] var21 = var17.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var22 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var22.addElement(0.02797455810085192d);
    var22.discardFrontElements(1);
    org.apache.commons.math3.util.ResizableDoubleArray var27 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var28 = var27.getInternalValues();
    var22.addElements(var28);
    double var30 = var14.mannWhitneyUTest(var21, var28);
    double[] var32 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var33 = new org.apache.commons.math3.util.ResizableDoubleArray(var32);
    var33.setContractionCriteria(50.000008f);
    double[] var36 = var33.getInternalValues();
    double[] var37 = var33.getElements();
    org.apache.commons.math3.distribution.NormalDistribution var38 = new org.apache.commons.math3.distribution.NormalDistribution();
    double[] var40 = var38.sample(1);
    double var41 = var14.mannWhitneyU(var37, var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "MAXIMAL"+ "'", var2.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "MAXIMAL"+ "'", var3.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.10247043485974927d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 1.0d);

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test210"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble(1612773);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test211"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(7.180580376996924E86d, 0.6647615947356664d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test212"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd((-768793332), 52037);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test213() {}
//   public void test213() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test213"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     var0.reSeed(1L);
//     java.lang.String var6 = var0.nextHexString(10);
//     var0.reSeed();
//     double var10 = var0.nextUniform(0.0d, 1.475484072313353d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "ed8f4c6ca52118cd7daa3fe60d780107a8df514978c3509676d6542f04088040285d9f4ec525c811e9266b66e753f277b20b"+ "'", var2.equals("ed8f4c6ca52118cd7daa3fe60d780107a8df514978c3509676d6542f04088040285d9f4ec525c811e9266b66e753f277b20b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "93042192d2"+ "'", var6.equals("93042192d2"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.7546837768046001d);
// 
//   }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test214"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(44, 47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2068);

  }

  public void test215() {}
//   public void test215() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test215"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     boolean var9 = var6.isSupportConnected();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     int var13 = var0.nextInt((-1), 3);
//     org.apache.commons.math3.distribution.RealDistribution var14 = null;
//     double var15 = var0.nextInversionDeviate(var14);
// 
//   }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test216"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.0d, 0.5845547826755761d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.5845547826755761d);

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test217"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(0.10561069428565839d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.4726822555462428d);

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test218"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(102400.01f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 102400.016f);

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test219"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)8100);

  }

  public void test220() {}
//   public void test220() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test220"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Number var1 = null;
//     org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, var1);
//     org.apache.commons.math3.exception.util.ExceptionContext var3 = var2.getContext();
//     boolean var4 = var2.getBoundIsAllowed();
//     org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var2);
// 
//   }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test221"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(9.5367426E-7f, Float.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.POSITIVE_INFINITY);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test222"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial((-4));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test223"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(645781745, (-768793332));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test224() {}
//   public void test224() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test224"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     double var16 = var0.nextWeibull(1.0d, 1.6298598478788293d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var20 = var0.nextHypergeometric(5, 102400, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "5e60ae2bbe9ad87d034ac0cba811cf247ea152f866fdc397a684d4b3528053746c6dda7f71c8c1546cbe308babcb2b1ab32c"+ "'", var2.equals("5e60ae2bbe9ad87d034ac0cba811cf247ea152f866fdc397a684d4b3528053746c6dda7f71c8c1546cbe308babcb2b1ab32c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-2.636191455367776E43d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.7911234322230165d);
// 
//   }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test225"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(27L, 27000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 27027L);

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test226"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(0L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test227"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(12700, 0.0f, 2560.0f, 111);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test228"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(4.629628685877712E42d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999999999999971d);

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test229"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(9.536743E-7f, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.5367426E-7f);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test230"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)Double.NaN);
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var2.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test231"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.0d, (-0.8813735870195429d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test232"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(2.5000002f, 5.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5.0f);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test233"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.NotPositiveException var5 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(short)1);
    java.lang.Object[] var6 = new java.lang.Object[] { (short)1};
    org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException(var3, var6);
    org.apache.commons.math3.exception.MathArithmeticException var8 = new org.apache.commons.math3.exception.MathArithmeticException(var2, var6);
    org.apache.commons.math3.exception.MaxCountExceededException var9 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)1.3872175661331396d, var6);
    java.lang.Number var10 = var9.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + 1.3872175661331396d+ "'", var10.equals(1.3872175661331396d));

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test234"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(61);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test235"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var2.setContractionCriteria(50.000008f);
    double[] var5 = var2.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    int var7 = var2.start();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.discardMostRecentElements(96);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);

  }

  public void test236() {}
//   public void test236() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test236"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     java.math.BigInteger var3 = null;
//     java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0L);
//     org.apache.commons.math3.exception.OutOfRangeException var7 = new org.apache.commons.math3.exception.OutOfRangeException(var1, (java.lang.Number)100.0f, (java.lang.Number)var5, (java.lang.Number)0.5000672346092545d);
//     org.apache.commons.math3.exception.util.Localizable var8 = null;
//     java.math.BigInteger var10 = null;
//     java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var10, 0L);
//     org.apache.commons.math3.exception.OutOfRangeException var14 = new org.apache.commons.math3.exception.OutOfRangeException(var8, (java.lang.Number)100.0f, (java.lang.Number)var12, (java.lang.Number)0.5000672346092545d);
//     java.math.BigInteger var15 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, var12);
//     java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 12700);
//     java.math.BigInteger var19 = org.apache.commons.math3.util.ArithmeticUtils.pow(var17, 768793337);
//     java.math.BigInteger var20 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, var17);
// 
//   }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test237"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(1.5143400261808895d, 0.48098477301608916d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.7637480459284904d));

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test238"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(100, 2.0000005f);

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test239"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs((-48436L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 48436L);

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test240"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(1.5707963267948923d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.33640501788154E14d);

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test241"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(0.48098477301608916d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.46413974520156737d);

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test242"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(4.951760157141521E27d, 0.7760228659329313d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test243"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.NotPositiveException var7 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(short)1);
    java.lang.Object[] var8 = new java.lang.Object[] { (short)1};
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException(var5, var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var4, var8);
    java.lang.Object[] var11 = new java.lang.Object[] { var8};
    org.apache.commons.math3.exception.MathInternalError var12 = new org.apache.commons.math3.exception.MathInternalError(var3, var11);
    org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, var11);
    org.apache.commons.math3.exception.MathInternalError var14 = new org.apache.commons.math3.exception.MathInternalError(var1, var11);
    org.apache.commons.math3.exception.NullArgumentException var15 = new org.apache.commons.math3.exception.NullArgumentException(var0, var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test244"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(8.799063409660144E86d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test245"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = var0.nextSecureHexString(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test246"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(4.3097516144514474E33d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.320319334986273E-34d);

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test247"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma((-0.1204050495694422d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 70.96796119341717d);

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test248"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    java.lang.String var2 = var1.name();
    java.lang.String var3 = var1.name();
    boolean var5 = var1.equals((java.lang.Object)"bbc76c98706e096cbdb48c11be18b37feafe094ae0e5291b81fe65cbd0c42cc6f465c322de0f5afaf8fdd0237c92d0d9c2d6");
    int var6 = var1.ordinal();
    org.apache.commons.math3.random.RandomGenerator var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = var9.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var12 = var11.getNanStrategy();
    java.lang.String var13 = var12.name();
    java.lang.String var14 = var12.name();
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15);
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    int var18 = var17.ordinal();
    java.lang.String var19 = var17.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12, var17);
    double[] var22 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var23 = new org.apache.commons.math3.util.ResizableDoubleArray(var22);
    var23.setContractionCriteria(50.000008f);
    var23.setExpansionMode(0);
    boolean var28 = var17.equals((java.lang.Object)var23);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var29 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var10, var17);
    org.apache.commons.math3.stat.ranking.NaturalRanking var30 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var17);
    org.apache.commons.math3.stat.ranking.NaNStrategy var31 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var32 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var31);
    org.apache.commons.math3.stat.ranking.TiesStrategy var33 = var32.getTiesStrategy();
    int var34 = var33.ordinal();
    java.lang.String var35 = var33.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var36 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "MAXIMAL"+ "'", var2.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "MAXIMAL"+ "'", var3.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "MAXIMAL"+ "'", var13.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "MAXIMAL"+ "'", var14.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "AVERAGE"+ "'", var19.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var35 + "' != '" + "AVERAGE"+ "'", var35.equals("AVERAGE"));

  }

  public void test249() {}
//   public void test249() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test249"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     java.lang.String var4 = var0.nextHexString(110);
//     long var7 = var0.nextSecureLong(0L, 27898L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var0.nextUniform(136.80272263732638d, 2.5091784786580567d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.5336250599442651d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "f921b0c589fab74e1598e9016ed4a0c542a019f07b8be8d8d039f293864f0ab99c7fbd8eb6905a5283805d921f7ea8ff2345d6580bc85c"+ "'", var4.equals("f921b0c589fab74e1598e9016ed4a0c542a019f07b8be8d8d039f293864f0ab99c7fbd8eb6905a5283805d921f7ea8ff2345d6580bc85c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2675L);
// 
//   }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test250"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(27000L, 42L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1134000L);

  }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test251"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.06535479195982165d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0675377109994062d);

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test252"); }


    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(2, 10.0f, 10.0f, 1);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    var6.setNumElements(2068);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test253"); }


    double var2 = org.apache.commons.math3.util.FastMath.max((-0.47598581837512266d), 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test254"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    float var3 = var2.getExpansionFactor();
    org.apache.commons.math3.util.ResizableDoubleArray var4 = var2.copy();
    double var6 = var2.substituteMostRecentElement(1.0920559274043928d);
    int var7 = var2.getNumElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setExpansionMode(102400);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test255"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(300L, 2L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 90000L);

  }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test256"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("735ac4af79d794edd7f04c6a38b7e75b9672cd103d4217f9dfc226d52849210544a82886d4934293d50ce1a78445465efb03");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test257() {}
//   public void test257() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test257"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
//     org.apache.commons.math3.random.RandomGenerator var2 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var4 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var5.getTiesStrategy();
//     int var7 = var6.ordinal();
//     java.lang.String var8 = var6.name();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var6);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var10 = var9.getTiesStrategy();
//     double[] var11 = null;
//     double[] var12 = var9.rank(var11);
// 
//   }

  public void test258() {}
//   public void test258() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test258"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     double var4 = var0.nextExponential(0.056182176564052d);
//     var0.reSeedSecure();
//     var0.reSeedSecure(75324600L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "9d300c99aa05553b905babdec4f04f22875c1ab5d9f63fbff9f0e27818dfce309dd1fa10a9ce99684e56ba06f7d6bd6f42e6"+ "'", var2.equals("9d300c99aa05553b905babdec4f04f22875c1ab5d9f63fbff9f0e27818dfce309dd1fa10a9ce99684e56ba06f7d6bd6f42e6"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.0034856617493327535d);
// 
//   }

  public void test259() {}
//   public void test259() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test259"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Number var1 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     org.apache.commons.math3.exception.util.Localizable var3 = null;
//     org.apache.commons.math3.exception.util.Localizable var4 = null;
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     org.apache.commons.math3.exception.NotPositiveException var7 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(short)1);
//     java.lang.Object[] var8 = new java.lang.Object[] { (short)1};
//     org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException(var5, var8);
//     org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var4, var8);
//     java.lang.Object[] var11 = new java.lang.Object[] { var8};
//     org.apache.commons.math3.exception.MathInternalError var12 = new org.apache.commons.math3.exception.MathInternalError(var3, var11);
//     org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, var11);
//     org.apache.commons.math3.exception.MaxCountExceededException var14 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, var1, var11);
//     org.apache.commons.math3.exception.util.ExceptionContext var15 = var14.getContext();
//     java.lang.String var16 = var14.toString();
// 
//   }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test260"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(0.03673319830899499d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.1916590679018214d);

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test261"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution((-0.3781696985345623d), 200.0d, 3.072433293358163E86d);
    var3.reseedRandomGenerator(5144L);

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test262"); }


    float var2 = org.apache.commons.math3.util.FastMath.min((-0.99999994f), 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.99999994f));

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test263"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(10L, 28798L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-28788L));

  }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test264"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(2560.0f, 3.1596484740079465d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2559.9998f);

  }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test265"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(645781746);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }

  }

  public void test266() {}
//   public void test266() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test266"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     var0.reSeed(1L);
//     double var7 = var0.nextWeibull(6.389056068043896d, 6.770911672198755d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var0.nextUniform(0.5075374788683407d, 0.0d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "6623e7ccf75a6f1fbaf3c46875412901a606eba3b9d3c10370fe3d1e140572fae4f9f6d476305195d135e20d5bb9d07c90ba"+ "'", var2.equals("6623e7ccf75a6f1fbaf3c46875412901a606eba3b9d3c10370fe3d1e140572fae4f9f6d476305195d135e20d5bb9d07c90ba"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 4.5194037630894135d);
// 
//   }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test267"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(0L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test268"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var2.setContractionCriteria(50.000008f);
    var2.setExpansionMode(0);
    var2.setContractionCriteria(5.0f);
    double[] var10 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var10);
    var11.setContractionCriteria(50.000008f);
    double[] var14 = var11.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var11);
    boolean var16 = var2.equals((java.lang.Object)var11);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setExpansionMode(2870);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test269"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(0.08648854529952615d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0863810803914614d);

  }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test270"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(7.942528294953089E86d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.8182491541652396E43d);

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test271"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    java.lang.String var2 = var1.name();
    java.lang.String var3 = var1.name();
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var5.getTiesStrategy();
    int var7 = var6.ordinal();
    java.lang.String var8 = var6.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var6);
    org.apache.commons.math3.stat.ranking.TiesStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var10);
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var13 = var12.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var14 = var12.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var15 = var12.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var15);
    org.apache.commons.math3.stat.ranking.NaNStrategy var17 = var16.getNanStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "MAXIMAL"+ "'", var2.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "MAXIMAL"+ "'", var3.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test272"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    float var3 = var2.getExpansionFactor();
    org.apache.commons.math3.util.ResizableDoubleArray var4 = var2.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = var4.copy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.discardMostRecentElements(227);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test273"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double var4 = var2.substituteMostRecentElement(1.0159453334112069E43d);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var5 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var7 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    var8.setContractionCriteria(50.000008f);
    double[] var11 = var8.getInternalValues();
    double[] var13 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var13);
    var14.setContractionCriteria(50.000008f);
    double[] var17 = var14.getInternalValues();
    double[] var18 = var14.getElements();
    double var19 = var5.mannWhitneyUTest(var11, var18);
    org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray(var18);
    var2.addElements(var18);
    var2.setContractionCriteria(Float.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);

  }

  public void test274() {}
//   public void test274() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test274"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.log((-0.0014825565491930325d), 68397.35544481203d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test275"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(4.840511699713244E43d, (-0.37349236086573334d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.37349236086573334d));

  }

  public void test276() {}
//   public void test276() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test276"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     double var16 = var0.nextWeibull(1.0d, 1.6298598478788293d);
//     double var19 = var0.nextWeibull(1.151569395337692d, 7.22597376812575E86d);
//     double var22 = var0.nextGaussian(2.4188678176733584E-44d, 0.9732473842406115d);
//     java.util.Collection var23 = null;
//     java.lang.Object[] var25 = var0.nextSample(var23, 0);
// 
//   }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test277"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(2.684812598778797d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.361844326364504d);

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test278"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)1.3418720970618036E43d, (java.lang.Number)5.0f, true);
    boolean var4 = var3.getBoundIsAllowed();
    java.lang.Number var5 = var3.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1.3418720970618036E43d+ "'", var5.equals(1.3418720970618036E43d));

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test279"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var3 = var1.getElement(0);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test280() {}
//   public void test280() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test280"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     double var16 = var0.nextWeibull(1.0d, 1.6298598478788293d);
//     double var19 = var0.nextCauchy((-1.1440883267692863E33d), 3.3030345912774096E43d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var22 = var0.nextZipf(287, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "192564ff8e39ed9ba6ed6e570c93eb099164ce51505c613d9b7f8a98707cdd60628465a0f0e41f00697be7c9e5723984536d"+ "'", var2.equals("192564ff8e39ed9ba6ed6e570c93eb099164ce51505c613d9b7f8a98707cdd60628465a0f0e41f00697be7c9e5723984536d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-1.3521412695532086E43d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 2.617968045472897d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1.6225379593336269E44d);
// 
//   }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test281"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(1.684024197549089d, 4.9E-324d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.9827609794007427d));

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test282"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(102, 8100);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test283() {}
//   public void test283() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test283"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.0d, 0.06535479195982165d, 4.067958619401342E86d, 96);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test284"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(0.8686804224492061d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test285"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(2.9681911862806774E-44d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 32.94631867978169d);

  }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test286"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-1.0f), (java.lang.Number)1.4640953062334716d, false);
    java.lang.Number var4 = var3.getArgument();
    boolean var5 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (-1.0f)+ "'", var4.equals((-1.0f)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test287"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(2560.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2560);

  }

  public void test288() {}
//   public void test288() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test288"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     double var5 = var0.nextGaussian(0.0d, 0.5d);
//     var0.reSeed(10L);
//     long var10 = var0.nextLong((-1L), 10L);
//     double var12 = var0.nextT(0.9640275797804917d);
//     long var14 = var0.nextPoisson(1.4640953062334716d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.108460887756702d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.4260292805193087d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 3L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 7.483725781796605d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1L);
// 
//   }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test289"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)0.7258230469631404d);

  }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test290"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var2.setContractionCriteria(5.0f);
    var2.setElement(110, Double.NaN);
    var2.setElement(100, (-0.6120891811851691d));
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var13 = var12.getNanStrategy();
    java.lang.String var14 = var13.name();
    java.lang.String var15 = var13.name();
    org.apache.commons.math3.stat.ranking.NaNStrategy var16 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var16);
    org.apache.commons.math3.stat.ranking.TiesStrategy var18 = var17.getTiesStrategy();
    int var19 = var18.ordinal();
    java.lang.String var20 = var18.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var13, var18);
    org.apache.commons.math3.stat.ranking.NaNStrategy var22 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var22);
    org.apache.commons.math3.stat.ranking.TiesStrategy var24 = var23.getTiesStrategy();
    int var25 = var24.ordinal();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var26 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var13, var24);
    double[] var28 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var29 = new org.apache.commons.math3.util.ResizableDoubleArray(var28);
    var29.setContractionCriteria(50.000008f);
    double[] var32 = var29.getInternalValues();
    double[] var33 = var29.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var34 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var34.addElement(0.02797455810085192d);
    var34.discardFrontElements(1);
    org.apache.commons.math3.util.ResizableDoubleArray var39 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var40 = var39.getInternalValues();
    var34.addElements(var40);
    double var42 = var26.mannWhitneyUTest(var33, var40);
    var0.addElements(var40);
    double var45 = var0.addElementRolling(0.21212719734331667d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "MAXIMAL"+ "'", var14.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "MAXIMAL"+ "'", var15.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "AVERAGE"+ "'", var20.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0.10247043485974927d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.0d);

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test291"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.0f, 3.3030345912774096E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.4E-45f);

  }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test292"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.contract();
    double[] var2 = var0.getInternalValues();
    double var4 = var0.addElementRolling(1.231628095073697d);
    var0.setElement(70, 1.3627213323660777E-44d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setElement(645781745, (-4.152257768472053E8d));
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);

  }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test293"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var5 = new double[] { 1.0d, 100.0d};
    var2.addElements(var5);
    double[] var7 = var2.getInternalValues();
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    java.lang.Object[] var11 = new java.lang.Object[] { (-4.155599707401653d)};
    org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException(var9, var11);
    org.apache.commons.math3.exception.MathInternalError var13 = new org.apache.commons.math3.exception.MathInternalError(var8, var11);
    boolean var14 = var2.equals((java.lang.Object)var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test294() {}
//   public void test294() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test294"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     java.lang.String var4 = var0.nextHexString(110);
//     int var7 = var0.nextPascal(3, 0.0d);
//     int var10 = var0.nextSecureInt(47, 110);
//     var0.reSeedSecure(300L);
//     int var15 = var0.nextBinomial(1, 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 4.93982304811884d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "96661a89b0a0c6fc55efdf6adee3b58fd546d6727124a9b7da2d8a7b319916391613b628983e1bca77ca61bfac5a8fe7cf36f9f3ad57fd"+ "'", var4.equals("96661a89b0a0c6fc55efdf6adee3b58fd546d6727124a9b7da2d8a7b319916391613b628983e1bca77ca61bfac5a8fe7cf36f9f3ad57fd"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 83);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0);
// 
//   }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test295"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(50.00001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test296"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(1.0920559274043928d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 62.57019563251673d);

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test297"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(5.0f);
    var0.setElement(110, Double.NaN);
    var0.discardFrontElements(10);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var8.setContractionCriteria(50.000008f);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var8);
    int var12 = var8.getExpansionMode();
    var8.setExpansionMode(0);
    var8.clear();
    var8.setNumElements(287);
    var8.addElement(1.5485965529242296d);
    int var20 = var8.getNumElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 288);

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test298"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(227, 96);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 21792);

  }

  public void test299() {}
//   public void test299() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test299"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh(0.028514560146996132d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test300() {}
//   public void test300() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test300"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.5274450245437947d, (-2.791500647694174E42d), 1.1102230246251565E-16d, 4233);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test301() {}
//   public void test301() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test301"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     double var17 = var0.nextBeta(1.1265425086815434E43d, 1.1282937610745374d);
//     long var19 = var0.nextPoisson(31.402066659134473d);
//     long var22 = var0.nextLong((-9223372036854775808L), 2L);
//     int var25 = var0.nextZipf(127000, 0.4349627593755754d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var27 = var0.nextPoisson((-4.009723999311411E42d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "e093042065cea58ad960f69845a4d87cc61d134e9af3641036ba90a1d82c391dd4bb7495ccf4235ba72fdb4878c43419eeaf"+ "'", var2.equals("e093042065cea58ad960f69845a4d87cc61d134e9af3641036ba90a1d82c391dd4bb7495ccf4235ba72fdb4878c43419eeaf"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 3.4478881692558447E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 36L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == (-1959320533252284416L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 100021);
// 
//   }

  public void test302() {}
//   public void test302() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test302"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     double var17 = var0.nextGamma(0.9775852669347048d, 3.199763873047224E14d);
//     var0.reSeed(27900L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var22 = var0.nextWeibull(1.7130083828445737d, (-6.935585632560808E42d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "ae3f6d756a4cbc198e9947c22297b9acacc6c0d838a1efe0912f011b7df19ac95ee7b6ab55d2ab4cadb9e5685503986d57fc"+ "'", var2.equals("ae3f6d756a4cbc198e9947c22297b9acacc6c0d838a1efe0912f011b7df19ac95ee7b6ab55d2ab4cadb9e5685503986d57fc"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.5751008474859364E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 2.9397395613297325E14d);
// 
//   }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test303"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder((-5.376974961543461E42d), 7.381472028861085E-11d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-2.5228617716135773E-11d));

  }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test304"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)2.30584301E18f);

  }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test305"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(94L, 5144L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2L);

  }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test306"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(12700);
    var1.setExpansionFactor(2.0000005f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setExpansionFactor(50.000015f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test307"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(17, 102400.0f);

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test308"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(9.536743E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test309"); }


    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(2, 10.0f, 10.0f, 1);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setExpansionFactor(9.5367426E-7f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test310"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test311"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(0.5274450245437947d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6945971187784026d);

  }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test312"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(4400, 47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test313"); }


    double var2 = org.apache.commons.math3.util.FastMath.min((-1.0223787590678046d), 1.3872175661331396d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.0223787590678046d));

  }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test314"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var2.setContractionCriteria(50.000008f);
    double[] var5 = var2.getInternalValues();
    double[] var6 = var2.getElements();
    var2.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test315"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(127, 1496370343);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 127);

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test316"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(27L, 42L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1134L);

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test317"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(0.5274450245437947d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.42359642093724637d);

  }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test318"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(2.0000005f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0000007f);

  }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test319"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)88.72804665106598d);
    java.lang.String var2 = var1.toString();
    org.apache.commons.math3.exception.OutOfRangeException var6 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)2.636818730233018d, (java.lang.Number)(-3.0d), (java.lang.Number)7.446477798073399d);
    var1.addSuppressed((java.lang.Throwable)var6);
    org.apache.commons.math3.exception.util.ExceptionContext var8 = var1.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "org.apache.commons.math3.exception.NotPositiveException: 88.728 is smaller than the minimum (0)"+ "'", var2.equals("org.apache.commons.math3.exception.NotPositiveException: 88.728 is smaller than the minimum (0)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test320"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(5.0f);
    var0.setElement(110, Double.NaN);
    var0.discardFrontElements(10);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var8.setContractionCriteria(50.000008f);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var8);
    int var12 = var8.getExpansionMode();
    double[] var13 = var8.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var13);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var14.discardMostRecentElements(288);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test321"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)10.0f);
    java.lang.Number var3 = var2.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));

  }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test322"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(3.199763873047224E14d, 11.551986904995205d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.5707963267948606d);

  }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test323"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(2560.0f, 2.0000005f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2560.0f);

  }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test324"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(5.0f);
    org.apache.commons.math3.random.RandomDataImpl var3 = new org.apache.commons.math3.random.RandomDataImpl();
    boolean var4 = var0.equals((java.lang.Object)var3);
    var0.addElement(Double.NaN);
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var8 = var7.getNanStrategy();
    java.lang.String var9 = var8.name();
    java.lang.String var10 = var8.name();
    org.apache.commons.math3.stat.ranking.NaNStrategy var11 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11);
    org.apache.commons.math3.stat.ranking.TiesStrategy var13 = var12.getTiesStrategy();
    int var14 = var13.ordinal();
    java.lang.String var15 = var13.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8, var13);
    double[] var18 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray(var18);
    var19.setContractionCriteria(50.000008f);
    var19.setExpansionMode(0);
    boolean var24 = var13.equals((java.lang.Object)var19);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var19);
    int var26 = var19.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "MAXIMAL"+ "'", var9.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "MAXIMAL"+ "'", var10.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "AVERAGE"+ "'", var15.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);

  }

  public void test325() {}
//   public void test325() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test325"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     boolean var9 = var6.isSupportConnected();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     double var12 = var6.probability(6.0d);
//     double var15 = var6.cumulativeProbability((-2.1317761108019555d), 0.9640275797804917d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var18 = var6.cumulativeProbability(1.70638274610834d, (-0.9844545308417082d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "154ff484dfc682e0e593b7e5b0da9f811ef179b58f3a18a26c0f7cfecccb73705410d1f23bd771fa269086f2a6ec7c657308"+ "'", var2.equals("154ff484dfc682e0e593b7e5b0da9f811ef179b58f3a18a26c0f7cfecccb73705410d1f23bd771fa269086f2a6ec7c657308"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-3.971863878456021E42d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 4.594468614421035E-44d);
// 
//   }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test326"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(3.208055017124592E42d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test327"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.4210854715202004E-14d, 1.999999995819933d, 7.353300445964135E86d);

  }

  public void test328() {}
//   public void test328() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test328"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ((-1.3748933199434673E43d), 1.7430659953803302d, 0.47968781985228015d, 8100);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test329() {}
//   public void test329() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test329"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     double var17 = var0.nextGamma(0.9775852669347048d, 3.199763873047224E14d);
//     double var20 = var0.nextUniform(0.0d, 8.799063409660144E86d);
//     org.apache.commons.math3.distribution.NormalDistribution var24 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var24.reseedRandomGenerator(1L);
//     boolean var27 = var24.isSupportConnected();
//     double var28 = var24.getMean();
//     double var29 = var24.sample();
//     double var30 = var24.getSupportUpperBound();
//     boolean var31 = var24.isSupportUpperBoundInclusive();
//     boolean var32 = var24.isSupportUpperBoundInclusive();
//     double var33 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var24);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var36 = var0.nextWeibull(0.4260292805193087d, (-6.460450326344049E42d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "865c7722e240133ddb5237096bb581d9622ea2b9ee7de0e4dbdfdccec6dda0cf58789bc99d3fc35dbe6419553f660067c55b"+ "'", var2.equals("865c7722e240133ddb5237096bb581d9622ea2b9ee7de0e4dbdfdccec6dda0cf58789bc99d3fc35dbe6419553f660067c55b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-2.5175400785352648E42d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.238728262594742E14d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 6.619596808135078E86d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 3.5671315446818194E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1.1628400026164497E43d);
// 
//   }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test330"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    java.lang.String var2 = var1.name();
    java.lang.String var3 = var1.toString();
    java.lang.String var4 = var1.toString();
    java.lang.Class var5 = var1.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var7 = java.lang.Enum.<java.lang.Enum>valueOf(var5, "9d10eaa63e23e02fe16574529e2d505c4bb34ce139304a55b05aadb42048073238a683cc78586e95e80092af9bd6694952b5");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "MAXIMAL"+ "'", var2.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "MAXIMAL"+ "'", var3.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "MAXIMAL"+ "'", var4.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test331"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1023));

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test332"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(27027L, 75324600L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-75297573L));

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test333"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)540L, var1, false);

  }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test334"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(0.0d, 0.2212373401672254d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test335"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(0.9732473842406115d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8267171054865511d);

  }

  public void test336() {}
//   public void test336() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test336"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
//     org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double[] var5 = var3.sample(1);
//     double[] var6 = var1.rank(var5);
// 
//   }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test337"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(5.957132015917886E42d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 42.77503722459932d);

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test338"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("0d57cc62b77ce34958fef4a13326feb40a3893ef3fbf0f1b1c5539df58e8f16e352b05f937b22389681c7582e168e8a2f1c9");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test339"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double[] var2 = var0.sample(1);
    double var3 = var0.getMean();
    boolean var4 = var0.isSupportUpperBoundInclusive();
    double var5 = var0.getSupportUpperBound();
    boolean var6 = var0.isSupportUpperBoundInclusive();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var9 = var0.cumulativeProbability(1.432080595809531E43d, 0.6120891811851691d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test340"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(2.3474735454811792E33d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 77.53179491216964d);

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test341"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var2.setContractionCriteria(50.000008f);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = var2.copy();
    var2.addElement(0.383865505085317d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setExpansionMode(1612900);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test342"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    var3.reseedRandomGenerator(1L);
    double var7 = var3.cumulativeProbability(0.0d);
    double var8 = var3.getStandardDeviation();
    double[] var10 = var3.sample(1612900);
    double var12 = var3.probability(0.13194341175745541d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.6881171418161356E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);

  }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test343"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    int var4 = var3.getNumElements();
    double var6 = var3.addElementRolling(1.2982587902415216E14d);
    var3.setNumElements(3);
    double[] var9 = var3.getInternalValues();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test344"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(2.0000007f, 2559.9998f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0000007f);

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test345"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(227, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 227);

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test346"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(2.0000005f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test347"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(100.0f, 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100.0f);

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test348"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(1612900, 645781745);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test349"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(1612922, 1820841484);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2);

  }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test350"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)88.72804665106598d);
    java.lang.String var2 = var1.toString();
    org.apache.commons.math3.exception.MathInternalError var3 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var1);
    java.lang.Number var4 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "org.apache.commons.math3.exception.NotPositiveException: 88.728 is smaller than the minimum (0)"+ "'", var2.equals("org.apache.commons.math3.exception.NotPositiveException: 88.728 is smaller than the minimum (0)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0+ "'", var4.equals(0));

  }

  public void test351() {}
//   public void test351() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test351"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy[] var3 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
//     org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError(var2, (java.lang.Object[])var3);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var5 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, (java.lang.Object[])var3);
//     org.apache.commons.math3.exception.MathInternalError var6 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var3);
//     org.apache.commons.math3.exception.util.Localizable var7 = null;
//     org.apache.commons.math3.exception.util.Localizable var8 = null;
//     org.apache.commons.math3.exception.util.Localizable var9 = null;
//     org.apache.commons.math3.exception.util.Localizable var10 = null;
//     org.apache.commons.math3.exception.util.Localizable var11 = null;
//     java.lang.Number var12 = null;
//     org.apache.commons.math3.exception.NotStrictlyPositiveException var13 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var11, var12);
//     org.apache.commons.math3.exception.util.ExceptionContext var14 = var13.getContext();
//     java.lang.Throwable[] var15 = var13.getSuppressed();
//     org.apache.commons.math3.exception.MathInternalError var16 = new org.apache.commons.math3.exception.MathInternalError(var10, (java.lang.Object[])var15);
//     org.apache.commons.math3.exception.MathInternalError var17 = new org.apache.commons.math3.exception.MathInternalError(var9, (java.lang.Object[])var15);
//     org.apache.commons.math3.exception.MathArithmeticException var18 = new org.apache.commons.math3.exception.MathArithmeticException(var8, (java.lang.Object[])var15);
//     org.apache.commons.math3.exception.MathIllegalStateException var19 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var6, var7, (java.lang.Object[])var15);
// 
//   }

  public void test352() {}
//   public void test352() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test352"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh((-1.9739225021895803d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test353() {}
//   public void test353() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test353"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.9542512052939294d, (-5.2432435475000995E42d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test354"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 100);

  }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test355"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck((-4), 101);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-105));

  }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test356"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(50.00001f, 3.899584967339712E86d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 50.000015f);

  }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test357"); }


    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(2, 10.0f, 10.0f, 1);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = var4.copy();
    double[] var9 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(var9);
    double var12 = var10.substituteMostRecentElement(1.0159453334112069E43d);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var13 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var15 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray(var15);
    var16.setContractionCriteria(50.000008f);
    double[] var19 = var16.getInternalValues();
    double[] var21 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var22 = new org.apache.commons.math3.util.ResizableDoubleArray(var21);
    var22.setContractionCriteria(50.000008f);
    double[] var25 = var22.getInternalValues();
    double[] var26 = var22.getElements();
    double var27 = var13.mannWhitneyUTest(var19, var26);
    org.apache.commons.math3.util.ResizableDoubleArray var28 = new org.apache.commons.math3.util.ResizableDoubleArray(var26);
    var10.addElements(var26);
    var4.addElements(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 1.0d);

  }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test358"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(3.8621646488805664E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 100.36238681490227d);

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test359"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(9.431336800397727E41d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 97.34317384029565d);

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test360"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum((-2.717631281479366E43d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test361"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.0034856617493327535d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test362() {}
//   public void test362() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test362"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     double var16 = var6.cumulativeProbability(0.14423894632267276d, 5.694508929246172E14d);
//     double var17 = var6.getSupportUpperBound();
//     double var18 = var6.sample();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "86082afbc6852eb6d88844217a64b88bab190b8a5d58afdb0a6d6da755767685c78816f1482ce28ac7b59be425945b24e959"+ "'", var2.equals("86082afbc6852eb6d88844217a64b88bab190b8a5d58afdb0a6d6da755767685c78816f1482ce28ac7b59be425945b24e959"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-7.707739625128683E41d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 8.451195606992581E-30d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 3.5671315446818194E43d);
// 
//   }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test363"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(0.5782731623958087d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.010092770659726724d);

  }

  public void test364() {}
//   public void test364() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test364"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var18 = var0.nextF(0.19842513149602495d, 1.8630202480631338E86d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "49ac3ca81ec17cbaedca68c30b0538ca1a02f8a8ec2e96c67ffca0d23eb900953f6bc2ba14660b39fef550ac0f7bdc393367"+ "'", var2.equals("49ac3ca81ec17cbaedca68c30b0538ca1a02f8a8ec2e96c67ffca0d23eb900953f6bc2ba14660b39fef550ac0f7bdc393367"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-5.953063454500565E42d));
// 
//   }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test365"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(69L, 1134000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3L);

  }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test366"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1.2696572718964828E42d, (java.lang.Number)4400, true);
    boolean var5 = var4.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test367"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    var3.reseedRandomGenerator(1L);
    boolean var6 = var3.isSupportConnected();
    double var7 = var3.getMean();
    double var8 = var3.getStandardDeviation();
    double var9 = var3.getStandardDeviation();
    boolean var10 = var3.isSupportUpperBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.6881171418161356E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 2.6881171418161356E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test368() {}
//   public void test368() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test368"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     var0.reSeed(1L);
//     java.lang.String var6 = var0.nextHexString(10);
//     double var9 = var0.nextUniform(8.451195606992581E-30d, 6.770911672198756d);
//     long var12 = var0.nextSecureLong(0L, 94L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var14 = var0.nextHexString((-4));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "112cad6f39fcef882773e2761f093f447ac658ead7599f00e88e04df8f19e6f4d993f5c3acffca72591d80880de1e25981dc"+ "'", var2.equals("112cad6f39fcef882773e2761f093f447ac658ead7599f00e88e04df8f19e6f4d993f5c3acffca72591d80880de1e25981dc"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "93042192d2"+ "'", var6.equals("93042192d2"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2.2682182275901375d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 88L);
// 
//   }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test369"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(136.80272263732638d, 0.0d, 0.5845547826755761d, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);

  }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test370"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.0d, 0.8335894960500023d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.8335894960500023d);

  }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test371"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(96, 127000);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 12192000);

  }

  public void test372() {}
//   public void test372() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test372"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     double var17 = var0.nextBeta(1.1265425086815434E43d, 1.1282937610745374d);
//     double var20 = var0.nextGamma(3.3030345912774096E43d, 1.8497873475441418d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var24 = var0.nextUniform(1.3662466260540767E86d, 0.08949018759546412d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "ba1d22ea99153a29466a04c37e2d3e2741e7795a19cb71902ed6fb321c09ff6a877b753d72e4be004aaf62cd1c6df50261d2"+ "'", var2.equals("ba1d22ea99153a29466a04c37e2d3e2741e7795a19cb71902ed6fb321c09ff6a877b753d72e4be004aaf62cd1c6df50261d2"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-4.285676298959401E43d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.9999999982406087d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 6.109911595445588E43d);
// 
//   }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test373"); }


    double[] var0 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var3 = var1.getElement(287);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test374() {}
//   public void test374() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test374"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(1.2186889243031047d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test375"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0d);

  }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test376"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(1820841484, (-127));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test377() {}
//   public void test377() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test377"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log((-0.9366718398504545d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test378"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.02744636141299663d, 0.10898669456022518d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.11238951172585744d);

  }

  public void test379() {}
//   public void test379() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test379"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(7.353300445964135E86d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test380"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-105), 29L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 41453239);

  }

  public void test381() {}
//   public void test381() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test381"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     var0.reSeed(1L);
//     double var7 = var0.nextCauchy(8.799063409660144E86d, 0.02797091068267617d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var0.nextUniform(0.6598643964752995d, (-1.854385601600511E39d), true);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "8fcc8aacca7616718853d62e74e720b227cc5fdd4b016e664d4ecdfcf65420a61f83f0ece46be93c824b9d6006a26471e304"+ "'", var2.equals("8fcc8aacca7616718853d62e74e720b227cc5fdd4b016e664d4ecdfcf65420a61f83f0ece46be93c824b9d6006a26471e304"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 8.799063409660144E86d);
// 
//   }

  public void test382() {}
//   public void test382() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test382"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     long var16 = var0.nextLong((-92L), 900L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var20 = var0.nextUniform(126.32054207990153d, 0.9640275797804917d, true);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "f087d6b8b316246879d3f03ccff3cad100a7a77fae6c22fd0a5b26f6d5788460caa70992dfe52cc076a0e80b445db88c29ee"+ "'", var2.equals("f087d6b8b316246879d3f03ccff3cad100a7a77fae6c22fd0a5b26f6d5788460caa70992dfe52cc076a0e80b445db88c29ee"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 2.669209122709544E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 834L);
// 
//   }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test383"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(Double.POSITIVE_INFINITY, 4.111122573849115E13d);
    boolean var3 = var2.isSupportConnected();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);

  }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test384"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.9999999988737325d, 2.2530284241517084E-8d, 0.32530717150821276d);
    double var4 = var3.getStandardDeviation();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.2530284241517084E-8d);

  }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test385"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm((-1L), 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test386"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos((-7.770157123792972E-15d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 32.94631867978203d);

  }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test387"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test388"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)1.2539861847696195E14d, (java.lang.Number)0.3989422804014327d, (java.lang.Number)(-7.135024516229892E42d));

  }

  public void test389() {}
//   public void test389() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test389"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     double var17 = var0.nextGamma(0.9775852669347048d, 3.199763873047224E14d);
//     double var20 = var0.nextGaussian(1.8622531212727638d, 1.1265425086815434E43d);
//     long var23 = var0.nextLong(27898L, 27900L);
//     int var26 = var0.nextBinomial(0, 0.5337063989568023d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "b5cc8d24a926cbc69b4dc93af349cddcc9a59a400b2e741165351a188d782f33d6dd942cd66c50c96bd7482fa7bd5c804b4e"+ "'", var2.equals("b5cc8d24a926cbc69b4dc93af349cddcc9a59a400b2e741165351a188d782f33d6dd942cd66c50c96bd7482fa7bd5c804b4e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 6.359453951695099E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.8960306466706722E14d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 5.810921362670137E42d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 27898L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 0);
// 
//   }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test390"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("22193b7450ca14cc2ff948301bd7f4b7a74c3ba2a1e1dd67ace66057608a6596d55708ed0e452a2989d99525877589ed3120");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test391"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(6.389056068043896d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4155383305749059d);

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test392"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(20, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test393() {}
//   public void test393() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test393"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(1.108460887756702d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test394"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var1 = null;
    org.apache.commons.math3.exception.MathInternalError var2 = new org.apache.commons.math3.exception.MathInternalError(var0, var1);
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Number var4 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var5 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var3, var4);
    org.apache.commons.math3.exception.util.ExceptionContext var6 = var5.getContext();
    boolean var7 = var5.getBoundIsAllowed();
    boolean var8 = var5.getBoundIsAllowed();
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    org.apache.commons.math3.exception.NotPositiveException var11 = new org.apache.commons.math3.exception.NotPositiveException(var9, (java.lang.Number)100);
    var5.addSuppressed((java.lang.Throwable)var11);
    var2.addSuppressed((java.lang.Throwable)var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test395"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(0.6945971187784026d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7518132117785729d);

  }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test396"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.math.BigInteger var2 = null;
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var6 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)100.0f, (java.lang.Number)var4, (java.lang.Number)0.5000672346092545d);
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    java.math.BigInteger var9 = null;
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var13 = new org.apache.commons.math3.exception.OutOfRangeException(var7, (java.lang.Number)100.0f, (java.lang.Number)var11, (java.lang.Number)0.5000672346092545d);
    java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, var11);
    java.math.BigInteger var16 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 10L);
    org.apache.commons.math3.exception.OutOfRangeException var19 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)var16, (java.lang.Number)4.951760157141521E27d, (java.lang.Number)0.5088599843857857d);
    java.lang.Number var20 = var19.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + 0.5088599843857857d+ "'", var20.equals(0.5088599843857857d));

  }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test397"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(5.403757938292075E43d, 2.320319334986273E-34d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5.403757938292074E43d);

  }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test398"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)2.2530284241517084E-8d);

  }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test399"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(0.6040929060689715d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6040929060689716d);

  }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test400"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)88.72804665106598d);
    java.lang.String var2 = var1.toString();
    org.apache.commons.math3.exception.MathInternalError var3 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var1);
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.NotPositiveException var9 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(short)1);
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var11 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var9, var10, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.MathIllegalArgumentException var13 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var7, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.MaxCountExceededException var14 = new org.apache.commons.math3.exception.MaxCountExceededException(var5, (java.lang.Number)0.9640275797804917d, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.MathIllegalStateException var15 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, (java.lang.Object[])var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "org.apache.commons.math3.exception.NotPositiveException: 88.728 is smaller than the minimum (0)"+ "'", var2.equals("org.apache.commons.math3.exception.NotPositiveException: 88.728 is smaller than the minimum (0)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test401() {}
//   public void test401() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test401"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     double var17 = var0.nextGamma(0.9775852669347048d, 3.199763873047224E14d);
//     double var20 = var0.nextGaussian(1.8622531212727638d, 1.1265425086815434E43d);
//     long var23 = var0.nextLong(27898L, 27900L);
//     double var25 = var0.nextExponential(0.626181665648831d);
//     var0.reSeedSecure(27900L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "8646495f4a96033108555f4186540dc745982f1a0ba60e9cfb2f1696707085b48936453651987f5c19af536dc47aeb4e726d"+ "'", var2.equals("8646495f4a96033108555f4186540dc745982f1a0ba60e9cfb2f1696707085b48936453651987f5c19af536dc47aeb4e726d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.7645501572145885E42d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 2.2715895134179253E14d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 2.510420559925157E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 27898L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 2.5183972256671465d);
// 
//   }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test402"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.math.BigInteger var2 = null;
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var6 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)100.0f, (java.lang.Number)var4, (java.lang.Number)0.5000672346092545d);
    java.lang.Number var7 = var6.getArgument();
    java.lang.Number var8 = var6.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 100.0f+ "'", var7.equals(100.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test403"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(7.932683319781395E42d, 3.6710379822636514E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.21281613660536508d);

  }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test404"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(102400.016f, 0.99999994f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 102400.016f);

  }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test405"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(102399.99f, (-0.9999999f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.9999999f));

  }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test406"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(0.13930833414080868d, 1.1340120103131339E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.13930833414080868d);

  }

  public void test407() {}
//   public void test407() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test407"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     double var17 = var0.nextBeta(1.1265425086815434E43d, 1.1282937610745374d);
//     long var19 = var0.nextPoisson(31.402066659134473d);
//     org.apache.commons.math3.distribution.RealDistribution var20 = null;
//     double var21 = var0.nextInversionDeviate(var20);
// 
//   }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test408"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)1.3418720970618036E43d, (java.lang.Number)5.0f, true);
    boolean var4 = var3.getBoundIsAllowed();
    boolean var5 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test409"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(0.7258230469631404d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.676109417652407d);

  }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test410"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray((-105), 2.5f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test411"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(100L, (-3941415383162945536L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-3941415383162945436L));

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test412"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(1.3662466260540767E86d, 0.08648854529952615d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test413"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    java.lang.String var2 = var1.toString();
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.NotPositiveException var5 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(short)1);
    java.lang.Object[] var6 = new java.lang.Object[] { (short)1};
    org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException(var3, var6);
    boolean var8 = var1.equals((java.lang.Object)var3);
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    java.lang.String var10 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "MAXIMAL"+ "'", var2.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "MAXIMAL"+ "'", var10.equals("MAXIMAL"));

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test414"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    java.lang.String var2 = var1.name();
    java.lang.String var3 = var1.toString();
    java.lang.Class var4 = var1.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var6 = java.lang.Enum.<java.lang.Enum>valueOf(var4, "31772f5794d6bb11e621a74af237b9888b374523e27fee0ad2d76202cad2f4f81ea299fc3e76fdc005dc077c512317c886ea");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "MAXIMAL"+ "'", var2.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "MAXIMAL"+ "'", var3.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test415"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.random.RandomGenerator var1 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var1);
    org.apache.commons.math3.stat.ranking.TiesStrategy var3 = var2.getTiesStrategy();
    java.lang.String var4 = var3.name();
    int var5 = var3.ordinal();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "RANDOM"+ "'", var4.equals("RANDOM"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 4);

  }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test416"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(5.957132015917888E42d, 0.0d, (-0.08494423315824018d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test417"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-5.376974961543461E42d), 4.840511699713244E43d);

  }

  public void test418() {}
//   public void test418() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test418"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     double var4 = var3.getSupportLowerBound();
//     double var5 = var3.sample();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.3393061770222213E43d);
// 
//   }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test419"); }


    org.apache.commons.math3.exception.MathArithmeticException var0 = new org.apache.commons.math3.exception.MathArithmeticException();
    org.apache.commons.math3.exception.util.ExceptionContext var1 = var0.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var0.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var0.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var0.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test420"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(0L, 27000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-27000L));

  }

  public void test421() {}
//   public void test421() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test421"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     java.lang.String var4 = var0.nextHexString(110);
//     int var7 = var0.nextPascal(3, 0.0d);
//     var0.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.45757818517005444d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "c26fa3602a2f677f7d0d3cea1f1704fb504a6a70d9a8dd39d75f2f022888939196b8988733b3f66f6db20ab2ae904511a12e5872ed78fe"+ "'", var4.equals("c26fa3602a2f677f7d0d3cea1f1704fb504a6a70d9a8dd39d75f2f022888939196b8988733b3f66f6db20ab2ae904511a12e5872ed78fe"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2147483647);
// 
//   }

  public void test422() {}
//   public void test422() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test422"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     var0.reSeed(1L);
//     var0.reSeed();
//     int var8 = var0.nextZipf(4400, 1.259921049017114d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "c8d891264a8ffdffe6b06cfd99d620371fb276fad65e05656fb69dce81b67e2ea3498b6f184207b8ff3b396ae7ae85234aad"+ "'", var2.equals("c8d891264a8ffdffe6b06cfd99d620371fb276fad65e05656fb69dce81b67e2ea3498b6f184207b8ff3b396ae7ae85234aad"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2);
// 
//   }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test423"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(6.136369304788742E42d, 63.76954061151497d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 26.387081609342943d);

  }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test424"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    var3.reseedRandomGenerator(1L);
    double var7 = var3.cumulativeProbability(0.0d);
    double var9 = var3.cumulativeProbability(1.0d);
    double var10 = var3.sample();
    double var11 = var3.getSupportLowerBound();
    boolean var12 = var3.isSupportUpperBoundInclusive();
    double var13 = var3.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 3.5671315446818194E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);

  }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test425"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.645632820750788d, 1.293606294858882E100d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test426"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(0L, (-9223372036854775808L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-9223372036854775808L));

  }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test427"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(5.0f);
    var0.setElement(110, Double.NaN);
    var0.discardFrontElements(10);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var8.setContractionCriteria(50.000008f);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var8);
    int var12 = var8.getExpansionMode();
    var8.setExpansionMode(0);
    var8.clear();
    double[] var16 = var8.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var17 = new org.apache.commons.math3.util.ResizableDoubleArray(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test428"); }


    float var2 = org.apache.commons.math3.util.FastMath.min((-1.0f), 9.999999f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.0f));

  }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test429"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos((-4.152257768472053E8d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999999730206884d);

  }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test430"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var2 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var3.setContractionCriteria(50.000008f);
    double[] var6 = var3.getInternalValues();
    double[] var8 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
    var9.setContractionCriteria(50.000008f);
    double[] var12 = var9.getInternalValues();
    double[] var13 = var9.getElements();
    double var14 = var0.mannWhitneyUTest(var6, var13);
    org.apache.commons.math3.distribution.NormalDistribution var18 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    var18.reseedRandomGenerator(1L);
    boolean var21 = var18.isSupportConnected();
    double var22 = var18.getMean();
    double var23 = var18.sample();
    double[] var25 = var18.sample(8100);
    org.apache.commons.math3.util.ResizableDoubleArray var26 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var27 = var26.getInternalValues();
    double var28 = var0.mannWhitneyUTest(var25, var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 3.5671315446818194E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.8508952569561938d);

  }

  public void test431() {}
//   public void test431() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test431"); }
// 
// 
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     double[] var2 = new double[] { 1.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
//     var3.setContractionCriteria(50.000008f);
//     double[] var6 = var3.getInternalValues();
//     double[] var8 = new double[] { 1.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
//     var9.setContractionCriteria(50.000008f);
//     double[] var12 = var9.getInternalValues();
//     double[] var13 = var9.getElements();
//     double var14 = var0.mannWhitneyU(var6, var13);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var15 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     double[] var17 = new double[] { 1.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray(var17);
//     var18.setContractionCriteria(50.000008f);
//     double[] var21 = var18.getInternalValues();
//     double[] var23 = new double[] { 1.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var24 = new org.apache.commons.math3.util.ResizableDoubleArray(var23);
//     var24.setContractionCriteria(50.000008f);
//     double[] var27 = var24.getInternalValues();
//     double[] var28 = var24.getElements();
//     double var29 = var15.mannWhitneyU(var21, var28);
//     org.apache.commons.math3.util.ResizableDoubleArray var30 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     var30.addElement(0.02797455810085192d);
//     var30.discardFrontElements(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var35 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     double[] var36 = var35.getInternalValues();
//     var30.addElements(var36);
//     double var38 = var0.mannWhitneyUTest(var21, var36);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var39 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var40 = var39.getNanStrategy();
//     java.lang.String var41 = var40.name();
//     java.lang.String var42 = var40.name();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var43 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var44 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var43);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var45 = var44.getTiesStrategy();
//     int var46 = var45.ordinal();
//     java.lang.String var47 = var45.name();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var48 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var40, var45);
//     double[] var50 = new double[] { 1.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var51 = new org.apache.commons.math3.util.ResizableDoubleArray(var50);
//     var51.setContractionCriteria(50.000008f);
//     var51.setExpansionMode(0);
//     boolean var56 = var45.equals((java.lang.Object)var51);
//     org.apache.commons.math3.util.ResizableDoubleArray var57 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     var57.setContractionCriteria(5.0f);
//     var57.setElement(110, Double.NaN);
//     var57.discardFrontElements(10);
//     int var65 = var57.getExpansionMode();
//     double[] var67 = new double[] { 1.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var68 = new org.apache.commons.math3.util.ResizableDoubleArray(var67);
//     org.apache.commons.math3.util.ResizableDoubleArray var69 = new org.apache.commons.math3.util.ResizableDoubleArray(var67);
//     double[] var70 = var69.getElements();
//     var57.addElements(var70);
//     var51.addElements(var70);
//     org.apache.commons.math3.distribution.NormalDistribution var73 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var74 = var73.getNumericalVariance();
//     double[] var76 = var73.sample(12700);
//     double var77 = var0.mannWhitneyU(var70, var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 0.10247043485974927d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var41 + "' != '" + "MAXIMAL"+ "'", var41.equals("MAXIMAL"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var42 + "' != '" + "MAXIMAL"+ "'", var42.equals("MAXIMAL"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var47 + "' != '" + "AVERAGE"+ "'", var47.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var70);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var74 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var77 == 10722.0d);
// 
//   }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test432"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(5.957132015917888E42d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 42.77503722459932d);

  }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test433"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck((-3941415383162945436L), (-9223372036854775808L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5281956653691830372L);

  }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test434"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(66, (-90));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test435"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var4 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError(var3, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.MathIllegalArgumentException var6 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError(var1, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.MathInternalError var8 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test436"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(5.889838469655482E86d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999999999999971d);

  }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test437"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor((-0.7853981633974483d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test438"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(1.1597528820798812E14d, (-0.11419179453672551d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.04347172367143415d);

  }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test439"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-28788L), 90);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test440"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog((-4));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test441"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.9999999985344892d, 9.332621544395286E157d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9999999985344893d);

  }

  public void test442() {}
//   public void test442() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test442"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     long var16 = var0.nextLong((-92L), 900L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var19 = var0.nextF(335.0334109186577d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "07a6d8a95e1c349c24d57f54ec53ef8aee39b91b9a276747bef0ac7c190a406af1ae4d22648f8179015e026f2b80aad34d3b"+ "'", var2.equals("07a6d8a95e1c349c24d57f54ec53ef8aee39b91b9a276747bef0ac7c190a406af1ae4d22648f8179015e026f2b80aad34d3b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.361245755553618E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 679L);
// 
//   }

  public void test443() {}
//   public void test443() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test443"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     java.lang.String var4 = var0.nextHexString(110);
//     double var6 = var0.nextChiSquare(0.9865330122406505d);
//     var0.reSeedSecure(28798L);
//     var0.reSeedSecure((-3941415383162945536L));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var12 = var0.nextPoisson(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.3467675512400605d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "8a86a44aaf29503865c16d16ed35df6bff343ef9744f26a47bb71c2ce96ae6be5122b33b58a0af0465487c2440acac53ee7ed48b4bbcae"+ "'", var4.equals("8a86a44aaf29503865c16d16ed35df6bff343ef9744f26a47bb71c2ce96ae6be5122b33b58a0af0465487c2440acac53ee7ed48b4bbcae"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.16063087488089875d);
// 
//   }

  public void test444() {}
//   public void test444() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test444"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     var0.reSeed(1L);
//     java.lang.String var6 = var0.nextHexString(10);
//     double var9 = var0.nextUniform(8.451195606992581E-30d, 6.770911672198756d);
//     long var12 = var0.nextSecureLong(0L, 94L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("8eb583acb1c02a2e4835dd3f2c20845cf1956e7ddf8c5bc31c6a81a2951af4b56f8c38c9e01f0c032927b7bf9399984f1619", "a07e9c23292c34d84451fa9479a50ab77e4fabe6089b0903b17b1e3bd281371ed9da375d4283c286747b6f0d0d4137bd76be");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "21f7b6e790c93e884f869a48de203891b4912e42163c3f4852cfc5f4f916febc0a93a0a3375cfdece13c352d93e2a625e5d1"+ "'", var2.equals("21f7b6e790c93e884f869a48de203891b4912e42163c3f4852cfc5f4f916febc0a93a0a3375cfdece13c352d93e2a625e5d1"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "93042192d2"+ "'", var6.equals("93042192d2"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2.2682182275901375d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 21L);
// 
//   }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test445"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    var3.reseedRandomGenerator(1L);
    double var7 = var3.cumulativeProbability(0.0d);
    double var9 = var3.cumulativeProbability(1.0d);
    double var10 = var3.sample();
    boolean var11 = var3.isSupportConnected();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 3.5671315446818194E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);

  }

  public void test446() {}
//   public void test446() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test446"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(1.9999999958199324d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test447"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(2068, 322L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test448"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    java.lang.String var2 = var1.toString();
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.NotPositiveException var5 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(short)1);
    java.lang.Object[] var6 = new java.lang.Object[] { (short)1};
    org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException(var3, var6);
    boolean var8 = var1.equals((java.lang.Object)var3);
    org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    var12.reseedRandomGenerator(1L);
    boolean var15 = var12.isSupportConnected();
    double var16 = var12.getMean();
    double var17 = var12.sample();
    double var18 = var12.getSupportUpperBound();
    boolean var19 = var12.isSupportUpperBoundInclusive();
    double var20 = var12.getMean();
    boolean var21 = var1.equals((java.lang.Object)var20);
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var23 = var22.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var24 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var25 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var23, var24);
    org.apache.commons.math3.stat.ranking.NaNStrategy var26 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var27 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var26);
    org.apache.commons.math3.stat.ranking.TiesStrategy var28 = var27.getTiesStrategy();
    int var29 = var28.ordinal();
    java.lang.String var30 = var28.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var31 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var23, var28);
    org.apache.commons.math3.stat.ranking.TiesStrategy var32 = var31.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var33 = var31.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var34 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "MAXIMAL"+ "'", var2.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 3.5671315446818194E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + "AVERAGE"+ "'", var30.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test449"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(141, 70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 95.02828702867782d);

  }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test450"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh((-1.8851541128986008E43d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-100.33831575436781d));

  }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test451"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var5 = new double[] { 1.0d, 100.0d};
    var2.addElements(var5);
    double[] var7 = var2.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    int var9 = var8.getNumElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 4);

  }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test452"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(3.3030345912774096E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.8924994166591445E45d);

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test453"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    var3.reseedRandomGenerator(1L);
    double var7 = var3.probability(0.0d);
    double var9 = var3.probability((-1.7637480459284904d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test454"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(1.2870058778506d, 0.4260292805193087d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-3.381627649217266d));

  }

  public void test455() {}
//   public void test455() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test455"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
//     java.lang.String var3 = var2.name();
//     java.lang.String var4 = var2.toString();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var6.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var9 = var8.getNanStrategy();
//     java.lang.String var10 = var9.name();
//     java.lang.String var11 = var9.name();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var12 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var14 = var13.getTiesStrategy();
//     int var15 = var14.ordinal();
//     java.lang.String var16 = var14.name();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var9, var14);
//     double[] var19 = new double[] { 1.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray(var19);
//     var20.setContractionCriteria(50.000008f);
//     var20.setExpansionMode(0);
//     boolean var25 = var14.equals((java.lang.Object)var20);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var26 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var7, var14);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var27 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var14);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var28 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var14);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var29 = var28.getNanStrategy();
//     org.apache.commons.math3.util.ResizableDoubleArray var30 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     var30.contract();
//     org.apache.commons.math3.util.ResizableDoubleArray var32 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     var32.setContractionCriteria(5.0f);
//     var32.setElement(110, Double.NaN);
//     var32.setElement(100, (-0.6120891811851691d));
//     org.apache.commons.math3.util.ResizableDoubleArray.copy(var30, var32);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var42 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var43 = var42.getNanStrategy();
//     java.lang.String var44 = var43.name();
//     java.lang.String var45 = var43.name();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var46 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var47 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var46);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var48 = var47.getTiesStrategy();
//     int var49 = var48.ordinal();
//     java.lang.String var50 = var48.name();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var51 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var43, var48);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var52 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var53 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var52);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var54 = var53.getTiesStrategy();
//     int var55 = var54.ordinal();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var56 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var43, var54);
//     double[] var58 = new double[] { 1.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var59 = new org.apache.commons.math3.util.ResizableDoubleArray(var58);
//     var59.setContractionCriteria(50.000008f);
//     double[] var62 = var59.getInternalValues();
//     double[] var63 = var59.getElements();
//     org.apache.commons.math3.util.ResizableDoubleArray var64 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     var64.addElement(0.02797455810085192d);
//     var64.discardFrontElements(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var69 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     double[] var70 = var69.getInternalValues();
//     var64.addElements(var70);
//     double var72 = var56.mannWhitneyUTest(var63, var70);
//     var30.addElements(var70);
//     double var75 = var30.substituteMostRecentElement(4.9E-324d);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var76 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     double[] var78 = new double[] { 1.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var79 = new org.apache.commons.math3.util.ResizableDoubleArray(var78);
//     var79.setContractionCriteria(50.000008f);
//     double[] var82 = var79.getInternalValues();
//     double[] var84 = new double[] { 1.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var85 = new org.apache.commons.math3.util.ResizableDoubleArray(var84);
//     var85.setContractionCriteria(50.000008f);
//     double[] var88 = var85.getInternalValues();
//     double[] var89 = var85.getElements();
//     double var90 = var76.mannWhitneyUTest(var82, var89);
//     var30.addElements(var82);
//     double[] var92 = var28.rank(var82);
// 
//   }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test456"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(2560.0f, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2559.9998f);

  }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test457"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(4.93982304811884d, 0.47968781985228015d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.1429448495960386d);

  }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test458"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(50.0f, 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 50.0f);

  }

  public void test459() {}
//   public void test459() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test459"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     double var17 = var0.nextGamma(0.9775852669347048d, 3.199763873047224E14d);
//     double var20 = var0.nextUniform(0.0d, 8.799063409660144E86d);
//     org.apache.commons.math3.distribution.NormalDistribution var24 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var24.reseedRandomGenerator(1L);
//     boolean var27 = var24.isSupportConnected();
//     double var28 = var24.getMean();
//     double var29 = var24.sample();
//     double var30 = var24.getSupportUpperBound();
//     boolean var31 = var24.isSupportUpperBoundInclusive();
//     boolean var32 = var24.isSupportUpperBoundInclusive();
//     double var33 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var24);
//     double var37 = var0.nextUniform((-3.4536536242642804E43d), 0.1672559658154289d, true);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var40 = var0.nextPermutation((-90), 1612773);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "99682e66c06b4e5374bdc435a0e5891956887bcdb9caf717288322a28d12f609bdaf54680795eedc9f040bbcfec6234bd7aa"+ "'", var2.equals("99682e66c06b4e5374bdc435a0e5891956887bcdb9caf717288322a28d12f609bdaf54680795eedc9f040bbcfec6234bd7aa"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-3.088495895089274E43d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 5.233957735377196E13d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1.6727744312408358E86d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 3.5671315446818194E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1.6493444713619207E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == (-2.1810378364011382E43d));
// 
//   }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test460"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(12827000, 1612773);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4851079.098769953d);

  }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test461"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var2.getNanStrategy();
    java.lang.String var4 = var3.name();
    java.lang.String var5 = var3.name();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    org.apache.commons.math3.stat.ranking.TiesStrategy var8 = var7.getTiesStrategy();
    int var9 = var8.ordinal();
    java.lang.String var10 = var8.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3, var8);
    double[] var13 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var13);
    var14.setContractionCriteria(50.000008f);
    var14.setExpansionMode(0);
    boolean var19 = var8.equals((java.lang.Object)var14);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var20 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var8);
    org.apache.commons.math3.stat.ranking.NaNStrategy var21 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var21);
    org.apache.commons.math3.stat.ranking.TiesStrategy var23 = var22.getTiesStrategy();
    int var24 = var23.ordinal();
    java.lang.String var25 = var23.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var26 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var23);
    org.apache.commons.math3.stat.ranking.NaturalRanking var27 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "MAXIMAL"+ "'", var4.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "MAXIMAL"+ "'", var5.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "AVERAGE"+ "'", var10.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + "AVERAGE"+ "'", var25.equals("AVERAGE"));

  }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test462"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(0.117469904020025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.9300733860920883d));

  }

  public void test463() {}
//   public void test463() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test463"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     double var16 = var0.nextWeibull(1.0d, 1.6298598478788293d);
//     double var19 = var0.nextCauchy((-1.1440883267692863E33d), 3.3030345912774096E43d);
//     var0.reSeedSecure();
//     double var24 = var0.nextUniform(0.0d, 2.4188678176733584E-44d, true);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var28 = var0.nextPascal(54, (-1.190693709545786E43d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "ee64ca2f4105c46083c9778cc33134f49282574d3391ed0867a2e381350cdd3e708596054b644c41f8f1bee938f5320aa05b"+ "'", var2.equals("ee64ca2f4105c46083c9778cc33134f49282574d3391ed0867a2e381350cdd3e708596054b644c41f8f1bee938f5320aa05b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-5.377785570294888E43d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.14591924123260538d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-1.3503082481405152E44d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 3.937210579150693E-45d);
// 
//   }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test464"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(6.136369304788742E42d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6.136369304788742E42d);

  }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test465"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(436.05387683681073d, 5.458802422386986E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 16.5699685764709d);

  }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test466"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(141, 110);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 31);

  }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test467"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var2.setContractionCriteria(50.000008f);
    var2.setExpansionMode(0);
    var2.setContractionCriteria(5.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setContractionCriteria(0.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test468() {}
//   public void test468() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test468"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     double var17 = var0.nextGamma(0.9775852669347048d, 3.199763873047224E14d);
//     double var20 = var0.nextF(2.636818730233018d, 1.1282937610745374d);
//     var0.reSeed(6L);
//     int var25 = var0.nextInt((-100), 2147483647);
//     org.apache.commons.math3.distribution.NormalDistribution var26 = new org.apache.commons.math3.distribution.NormalDistribution();
//     boolean var27 = var26.isSupportUpperBoundInclusive();
//     boolean var28 = var26.isSupportLowerBoundInclusive();
//     double var29 = var26.getMean();
//     double var30 = var26.getSupportUpperBound();
//     double var32 = var26.probability(3.874110573361593E-4d);
//     double var33 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var26);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var36 = var0.nextPermutation(227, 12700);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "d21c489604dc40dff4e721f50e7ce55ca94b5185ef1e69827cf4acb7ca060a4fbfdb3ffed517fcf40cb1692520f6db96b80e"+ "'", var2.equals("d21c489604dc40dff4e721f50e7ce55ca94b5185ef1e69827cf4acb7ca060a4fbfdb3ffed517fcf40cb1692520f6db96b80e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-4.38238875726838E43d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 2.1088731831663426E13d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.6697579862591374d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1742979373);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == (-1.3405768023430444d));
// 
//   }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test469"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(540L, (-90L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-48600L));

  }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test470"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var2.setContractionCriteria(50.000008f);
    double[] var5 = var2.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    int var7 = var2.start();
    float var8 = var2.getContractionCriteria();
    boolean var10 = var2.equals((java.lang.Object)(-8615948696432275456L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 50.000008f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test471"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(5.0f);
    var0.setElement(110, Double.NaN);
    var0.discardFrontElements(10);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var8.setContractionCriteria(50.000008f);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var8);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var13 = var0.getElement((-105));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test472() {}
//   public void test472() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test472"); }
// 
// 
//     org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     var0.setContractionCriteria(5.0f);
//     org.apache.commons.math3.random.RandomDataImpl var3 = new org.apache.commons.math3.random.RandomDataImpl();
//     boolean var4 = var0.equals((java.lang.Object)var3);
//     int var8 = var3.nextHypergeometric(287, 127, 96);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 45);
// 
//   }

  public void test473() {}
//   public void test473() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test473"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     java.lang.String var4 = var0.nextSecureHexString(101);
//     int var7 = var0.nextSecureInt(1612775, 645781745);
//     int var10 = var0.nextBinomial(47, 0.46795008060179255d);
//     org.apache.commons.math3.distribution.IntegerDistribution var11 = null;
//     int var12 = var0.nextInversionDeviate(var11);
// 
//   }

  public void test474() {}
//   public void test474() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test474"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.log(100.36238681490227d, (-0.833026455507159d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test475"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    var3.reseedRandomGenerator(1L);
    boolean var6 = var3.isSupportConnected();
    double var7 = var3.getMean();
    double var8 = var3.getMean();
    double var9 = var3.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);

  }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test476"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    var3.reseedRandomGenerator(1L);
    boolean var6 = var3.isSupportConnected();
    double var7 = var3.getMean();
    double var8 = var3.getStandardDeviation();
    double var9 = var3.getMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.6881171418161356E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);

  }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test477"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    var3.reseedRandomGenerator(1L);
    boolean var6 = var3.isSupportConnected();
    double var7 = var3.getNumericalVariance();
    double var9 = var3.cumulativeProbability(0.8267171054865511d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 7.22597376812575E86d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.5d);

  }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test478"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("f6fb2cdb6d6906353160a8bf553212f66f9acb415bff6e78d473cd57e05d1421c3628d8147c45bf3863e68ca847d76b42662");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test479"); }


    int var2 = org.apache.commons.math3.util.FastMath.min((-1), 45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));

  }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test480"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.math.BigInteger var3 = null;
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var7 = new org.apache.commons.math3.exception.OutOfRangeException(var1, (java.lang.Number)100.0f, (java.lang.Number)var5, (java.lang.Number)0.5000672346092545d);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    java.math.BigInteger var10 = null;
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var10, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var14 = new org.apache.commons.math3.exception.OutOfRangeException(var8, (java.lang.Number)100.0f, (java.lang.Number)var12, (java.lang.Number)0.5000672346092545d);
    java.math.BigInteger var15 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, var12);
    java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 10L);
    org.apache.commons.math3.exception.NotStrictlyPositiveException var18 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)var17);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.math.BigInteger var23 = null;
    java.math.BigInteger var25 = org.apache.commons.math3.util.ArithmeticUtils.pow(var23, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var27 = new org.apache.commons.math3.exception.OutOfRangeException(var21, (java.lang.Number)100.0f, (java.lang.Number)var25, (java.lang.Number)0.5000672346092545d);
    org.apache.commons.math3.exception.util.Localizable var28 = null;
    java.math.BigInteger var30 = null;
    java.math.BigInteger var32 = org.apache.commons.math3.util.ArithmeticUtils.pow(var30, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var34 = new org.apache.commons.math3.exception.OutOfRangeException(var28, (java.lang.Number)100.0f, (java.lang.Number)var32, (java.lang.Number)0.5000672346092545d);
    java.math.BigInteger var35 = org.apache.commons.math3.util.ArithmeticUtils.pow(var25, var32);
    java.math.BigInteger var37 = org.apache.commons.math3.util.ArithmeticUtils.pow(var25, 31L);
    org.apache.commons.math3.exception.OutOfRangeException var38 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)8.799063409660144E86d, (java.lang.Number)0.99999994f, (java.lang.Number)var25);
    java.math.BigInteger var39 = org.apache.commons.math3.util.ArithmeticUtils.pow(var17, var25);
    java.math.BigInteger var41 = org.apache.commons.math3.util.ArithmeticUtils.pow(var39, 145);
    org.apache.commons.math3.exception.util.Localizable var42 = null;
    java.math.BigInteger var44 = null;
    java.math.BigInteger var46 = org.apache.commons.math3.util.ArithmeticUtils.pow(var44, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var48 = new org.apache.commons.math3.exception.OutOfRangeException(var42, (java.lang.Number)100.0f, (java.lang.Number)var46, (java.lang.Number)0.5000672346092545d);
    org.apache.commons.math3.exception.util.Localizable var49 = null;
    java.math.BigInteger var51 = null;
    java.math.BigInteger var53 = org.apache.commons.math3.util.ArithmeticUtils.pow(var51, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var55 = new org.apache.commons.math3.exception.OutOfRangeException(var49, (java.lang.Number)100.0f, (java.lang.Number)var53, (java.lang.Number)0.5000672346092545d);
    java.math.BigInteger var56 = org.apache.commons.math3.util.ArithmeticUtils.pow(var46, var53);
    java.math.BigInteger var57 = org.apache.commons.math3.util.ArithmeticUtils.pow(var39, var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);

  }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test481"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var2.setContractionCriteria(50.000008f);
    double[] var5 = var2.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    int var7 = var2.getNumElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.discardMostRecentElements(127);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);

  }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test482"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint((-3.381627649217266d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-3.0d));

  }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test483"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    double var6 = var3.cumulativeProbability(1.4210854715202004E-14d, 2.0d);
    double var7 = var3.getMean();
    boolean var8 = var3.isSupportLowerBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.9681911862806774E-44d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test484() {}
//   public void test484() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test484"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     java.lang.String var4 = var0.nextSecureHexString(101);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var7 = var0.nextUniform(7.483725781796605d, (-1.9544896811699656E43d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "5c2aa82f929533020c3f94810e29d183d6244018243882caa70058d4e35d9894881e20dce522c6b6fbc783960a2ec73a4c20"+ "'", var2.equals("5c2aa82f929533020c3f94810e29d183d6244018243882caa70058d4e35d9894881e20dce522c6b6fbc783960a2ec73a4c20"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "74dc42b37ab878af7e5652b3edd19c95c44ee96b0a25046efd0cc4027aff193151b6ad5362d931c1fcd8a43e775fd6b25569b"+ "'", var4.equals("74dc42b37ab878af7e5652b3edd19c95c44ee96b0a25046efd0cc4027aff193151b6ad5362d931c1fcd8a43e775fd6b25569b"));
// 
//   }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test485"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    boolean var1 = var0.isSupportLowerBoundInclusive();
    boolean var2 = var0.isSupportConnected();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test486() {}
//   public void test486() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test486"); }
// 
// 
//     double var1 = org.apache.commons.math3.special.Gamma.logGamma((-3.173462429162327E42d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test487"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin((-8.09678153389256E42d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.7174750631912934d));

  }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test488"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)1.9222222798755142E-4d, (java.lang.Number)1.188156673789677E14d, false);

  }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test489"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(47, 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 229345007);

  }

  public void test490() {}
//   public void test490() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test490"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     double var16 = var0.nextWeibull(1.0d, 1.6298598478788293d);
//     double var19 = var0.nextWeibull(1.151569395337692d, 7.22597376812575E86d);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var23 = var0.nextPascal(1612773, 6.447535148721949E86d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "a22361934056980c64df323edf3baac26561a4ee9d5e3550eddab451a3ac1f5e991438f4425d45d6705f3ccbf271f9035fa8"+ "'", var2.equals("a22361934056980c64df323edf3baac26561a4ee9d5e3550eddab451a3ac1f5e991438f4425d45d6705f3ccbf271f9035fa8"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 5.114853844150616E42d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 2.2888413311111075d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 2.7705246168414045E86d);
// 
//   }

  public void test491() {}
//   public void test491() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test491"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     var0.reSeed(1L);
//     java.lang.String var6 = var0.nextHexString(10);
//     int var9 = var0.nextPascal(21792, 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "1d6438bd1334a2033c7c3252af8fa0debba3104e822a189a27e4cd145462a91ef600c53218b32c2ac28e7c2e05ba674dd3c8"+ "'", var2.equals("1d6438bd1334a2033c7c3252af8fa0debba3104e822a189a27e4cd145462a91ef600c53218b32c2ac28e7c2e05ba674dd3c8"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "93042192d2"+ "'", var6.equals("93042192d2"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2147483647);
// 
//   }

  public void test492() {}
//   public void test492() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test492"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(5.694508929246172E14d, (-2.791500647694174E42d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test493"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    java.lang.String var2 = var1.name();
    java.lang.String var3 = var1.name();
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var5.getTiesStrategy();
    int var7 = var6.ordinal();
    java.lang.String var8 = var6.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var6);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    java.lang.Class var11 = var6.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var13 = java.lang.Enum.<java.lang.Enum>valueOf(var11, "org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (10) exceeded");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "MAXIMAL"+ "'", var2.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "MAXIMAL"+ "'", var3.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test494"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.math.BigInteger var4 = null;
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var8 = new org.apache.commons.math3.exception.OutOfRangeException(var2, (java.lang.Number)100.0f, (java.lang.Number)var6, (java.lang.Number)0.5000672346092545d);
    java.lang.Number var9 = var8.getHi();
    java.lang.Number var10 = var8.getLo();
    org.apache.commons.math3.exception.NumberIsTooLargeException var12 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)20500L, var10, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + 0.5000672346092545d+ "'", var9.equals(0.5000672346092545d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test495"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(4400, 12700);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 558800);

  }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test496"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-1.836491304057643E43d), (java.lang.Number)0.02797091068267617d, true);

  }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test497"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(1.151569395337692d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test498"); }


    double var1 = org.apache.commons.math3.special.Gamma.logGamma(2.3474735454811792E33d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.7802921927502E35d);

  }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test499"); }


    double var1 = org.apache.commons.math3.special.Gamma.logGamma(7.445046712564365E14d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.4750119900492516E16d);

  }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test500"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    var3.reseedRandomGenerator(1L);
    boolean var6 = var3.isSupportConnected();
    double var7 = var3.getNumericalVariance();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var9 = var3.inverseCumulativeProbability((-6.715388288934036E43d));
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 7.22597376812575E86d);

  }

}
