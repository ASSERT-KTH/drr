
import junit.framework.*;

public class RandoopTest3 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test1"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.math.BigInteger var5 = null;
    java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var9 = new org.apache.commons.math3.exception.OutOfRangeException(var3, (java.lang.Number)100.0f, (java.lang.Number)var7, (java.lang.Number)0.5000672346092545d);
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    java.math.BigInteger var12 = null;
    java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var16 = new org.apache.commons.math3.exception.OutOfRangeException(var10, (java.lang.Number)100.0f, (java.lang.Number)var14, (java.lang.Number)0.5000672346092545d);
    java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, var14);
    java.math.BigInteger var19 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, 31L);
    org.apache.commons.math3.exception.OutOfRangeException var20 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)8.799063409660144E86d, (java.lang.Number)0.99999994f, (java.lang.Number)var7);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    org.apache.commons.math3.exception.util.Localizable var22 = null;
    org.apache.commons.math3.exception.NotPositiveException var24 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(short)1);
    java.lang.Object[] var25 = new java.lang.Object[] { (short)1};
    org.apache.commons.math3.exception.MathIllegalStateException var26 = new org.apache.commons.math3.exception.MathIllegalStateException(var22, var25);
    org.apache.commons.math3.exception.MathIllegalStateException var27 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var20, var21, var25);
    org.apache.commons.math3.exception.MathInternalError var28 = new org.apache.commons.math3.exception.MathInternalError(var0, var25);
    org.apache.commons.math3.exception.util.ExceptionContext var29 = var28.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test2() {}
//   public void test2() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test2"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     double var4 = var0.nextExponential(0.056182176564052d);
//     double var7 = var0.nextWeibull(1.200541497195915d, 2.2682182275901375d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var0.nextBeta(0.4471007338497455d, (-1.7925274837903817d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "d82c068a6e8d90cf79cb13502d0c04103cdfd429d3e60fb0907c5dbf84ad3db2700d3a41970bd5a8fd06bb747d56f0b72433"+ "'", var2.equals("d82c068a6e8d90cf79cb13502d0c04103cdfd429d3e60fb0907c5dbf84ad3db2700d3a41970bd5a8fd06bb747d56f0b72433"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.009420435420690954d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.7490843573309774d);
// 
//   }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test3"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(0.08971084836383868d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test4"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)33.50507345013689d, (java.lang.Number)1.5804317627621424E42d, (java.lang.Number)1.2539861847696195E14d);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test5"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(1.2696572718964828E42d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test6"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(88.72804665106598d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6);

  }

  public void test7() {}
//   public void test7() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test7"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     var0.reSeed();
//     double var18 = var0.nextGamma(2.636818730233018d, 0.5d);
//     var0.reSeedSecure(0L);
//     int var23 = var0.nextZipf(47, 6.770911672198755d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var26 = var0.nextBeta(6.338556874787449d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "38d412fb46fb112edff293ccd82e842d83c2bc5f16c0a274601008eb843cf6acc419c560b91d0ac0815265db018c08cfd8d4"+ "'", var2.equals("38d412fb46fb112edff293ccd82e842d83c2bc5f16c0a274601008eb843cf6acc419c560b91d0ac0815265db018c08cfd8d4"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-4.4050832372137756E43d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.8621758869804248d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1);
// 
//   }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test8"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.addElement(0.02797455810085192d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setContractionCriteria(9.5367426E-7f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test9"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh(0.47968781985228015d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5225787170494783d);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test10"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.3088209685048367d, 0.3618530048246771d);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test11"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)1.0d);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test12"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)83, (java.lang.Number)(-0.5606386275277435d), true);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test13"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var2 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var3 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)9.999999f, var2);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test14"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.contract();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setExpansionFactor(10.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test15() {}
//   public void test15() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test15"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     boolean var9 = var6.isSupportConnected();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var6.inverseCumulativeProbability(4.3097516144514474E33d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "148db6288df69da14f2092ba555856e224e2467c396db43ec80a885ad8759fc5fef2e85b2451b040f9ba3dcd1b9a249792d3"+ "'", var2.equals("148db6288df69da14f2092ba555856e224e2467c396db43ec80a885ad8759fc5fef2e85b2451b040f9ba3dcd1b9a249792d3"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 3.6869450176934306E43d);
// 
//   }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test16"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(540L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test17"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(10, 50.0f);
    var2.setElement(12700, 1.0806511876345213E86d);
    org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution();
    boolean var7 = var6.isSupportUpperBoundInclusive();
    boolean var8 = var6.isSupportLowerBoundInclusive();
    double var9 = var6.getMean();
    double[] var11 = var6.sample(110);
    var2.addElements(var11);
    var2.setElement(1612773, 4.605170185988092d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setElement((-105), 0.08269089827181393d);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test18"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    double var6 = var3.cumulativeProbability(1.4210854715202004E-14d, 2.0d);
    double var7 = var3.getMean();
    double var8 = var3.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.9681911862806774E-44d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == Double.NEGATIVE_INFINITY);

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test19"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var2.setContractionCriteria(50.000008f);
    var2.clear();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var6 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var8 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
    var9.setContractionCriteria(50.000008f);
    double[] var12 = var9.getInternalValues();
    double[] var14 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    var15.setContractionCriteria(50.000008f);
    double[] var18 = var15.getInternalValues();
    double[] var19 = var15.getElements();
    double var20 = var6.mannWhitneyUTest(var12, var19);
    var2.addElements(var19);
    org.apache.commons.math3.exception.NotStrictlyPositiveException var23 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)645781746);
    boolean var24 = var2.equals((java.lang.Object)645781746);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test20"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(768793337, (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test21"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(4.629628685877712E42d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.6525818441349044E44d);

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test22"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(1.4840955931403377E-44d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2182346215488778E-22d);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test23"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    java.lang.String var2 = var1.name();
    java.lang.String var3 = var1.toString();
    java.lang.String var4 = var1.toString();
    java.lang.Class var5 = var1.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var7 = java.lang.Enum.<java.lang.Enum>valueOf(var5, "a18a6960667ebe830870bef0dd47c8668e7a7b64af443e11aff71cf15c6f5f62a57ec39698a54a0583a9a53b49df838fad26");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "MAXIMAL"+ "'", var2.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "MAXIMAL"+ "'", var3.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "MAXIMAL"+ "'", var4.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test24"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(66, (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-66));

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test25"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    boolean var1 = var0.isSupportLowerBoundInclusive();
    var0.reseedRandomGenerator((-1L));
    double var5 = var0.probability((-27.741692681648217d));
    double var6 = var0.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);

  }

  public void test26() {}
//   public void test26() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test26"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP((-2.1850350060982735d), 0.4471007338497455d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test27() {}
//   public void test27() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test27"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     double var5 = var0.nextGaussian(0.0d, 0.5d);
//     var0.reSeed(10L);
//     double var9 = var0.nextExponential(2.0000008411562833d);
//     var0.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.5174537782658822d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.08142857470882658d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2.656500765412644d);
// 
//   }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test28"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(3.552713678800501E-15d, 2.1347061858261838E-44d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.5527136788005005E-15d);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test29"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(90, 1820841484);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1820841394));

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test30"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(0.584554782675576d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5518281445502153d);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test31"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(50.00001f, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 50.000008f);

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test32"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(100.0f, 2560.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100.0f);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test33"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(42L, (-90L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 132L);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test34"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(2.3841858E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-22));

  }

  public void test35() {}
//   public void test35() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test35"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     double var4 = var0.nextExponential(0.056182176564052d);
//     double var7 = var0.nextGamma((-2.0537907646431078E43d), 5.840802579076462E13d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var0.nextSecureInt(229345007, 102400);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "4e674aea875b5d6da79f1d44d66bbbfb0818974c1f5d704bf2d81d049d32ec76937c860b36853b6a1af6b9d2092a2b98339d"+ "'", var2.equals("4e674aea875b5d6da79f1d44d66bbbfb0818974c1f5d704bf2d81d049d32ec76937c860b36853b6a1af6b9d2092a2b98339d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.013536203214211557d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == Double.NaN);
// 
//   }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test36"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil((-2.1850350060982735d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-2.0d));

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test37"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var5 = new double[] { 1.0d, 100.0d};
    var2.addElements(var5);
    double[] var7 = var2.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    float var9 = var8.getExpansionFactor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var8.setElement((-66), 0.6598643964752995d);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 2.0f);

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test38"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(101);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test39"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(988L, (-2L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 986L);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test40"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(47, 66);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test41() {}
//   public void test41() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test41"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     double var16 = var0.nextWeibull(1.0d, 1.6298598478788293d);
//     double var19 = var0.nextWeibull(1.151569395337692d, 7.22597376812575E86d);
//     var0.reSeedSecure();
//     int var23 = var0.nextInt(47, 4400);
//     int var26 = var0.nextSecureInt(0, 1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var29 = var0.nextF((-1.7925274837903817d), 4.605170185988091d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "c8bab82de9aac386ab5867baa57ec819ce77c3e55b5b3306f5b6d7a2950f490e440a193c5e1c9d03ead1f76806580cf50499"+ "'", var2.equals("c8bab82de9aac386ab5867baa57ec819ce77c3e55b5b3306f5b6d7a2950f490e440a193c5e1c9d03ead1f76806580cf50499"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 2.001576004765447E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.31727946807030927d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 5.063675266307908E86d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 2649);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 1);
// 
//   }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test42"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-92L), 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test43"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan((-4.152257768472053E8d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8882849706472548d);

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test44"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.4471007338497455d, 0.8267171054865511d, 1.4407207406957656d, 22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.4536571913483398d);

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test45"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(27027L, (-5129524049062756352L));
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test46"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)0.9775852669347048d);
    java.lang.Number var3 = var2.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0.9775852669347048d+ "'", var3.equals(0.9775852669347048d));

  }

  public void test47() {}
//   public void test47() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test47"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     java.lang.String var4 = var0.nextHexString(110);
//     int var7 = var0.nextPascal(3, 0.0d);
//     int var10 = var0.nextSecureInt(47, 110);
//     double var13 = var0.nextGaussian(4.3461844317156794E43d, 97.34317384029565d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2.0484556054289236d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "59e9593a806d0924420d67a4eb54de8a45289a15cc843242d0514f6ea01870b97a2291839faa883a4a576d233d40c1bc4494aab2ad9cd2"+ "'", var4.equals("59e9593a806d0924420d67a4eb54de8a45289a15cc843242d0514f6ea01870b97a2291839faa883a4a576d233d40c1bc4494aab2ad9cd2"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 108);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 4.3461844317156794E43d);
// 
//   }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test48"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(0.04431651309826634d, 6.389056068043896d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9500268869550641d);

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test49"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(0.9865330122406505d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8370349259249118d);

  }

  public void test50() {}
//   public void test50() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test50"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     java.lang.String var4 = var0.nextHexString(110);
//     double var6 = var0.nextChiSquare(0.9865330122406505d);
//     var0.reSeedSecure(28798L);
//     org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var12.reseedRandomGenerator(1L);
//     boolean var15 = var12.isSupportConnected();
//     double var16 = var12.getMean();
//     double var17 = var12.sample();
//     double var18 = var12.getSupportUpperBound();
//     boolean var19 = var12.isSupportUpperBoundInclusive();
//     double var20 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var12);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var23 = var0.nextInt(127, (-768793332));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.22177209012873d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "2500a39c266dab502c51e2ecf4cadd387b04c2c5918562542779afa948da09e920f0b2d2d9313062e8cc9930deed7d7d925471bdda3fb2"+ "'", var4.equals("2500a39c266dab502c51e2ecf4cadd387b04c2c5918562542779afa948da09e920f0b2d2d9313062e8cc9930deed7d7d925471bdda3fb2"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 4.433784738588253d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 3.5671315446818194E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 3.406224888104429E42d);
// 
//   }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test51"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(0.1429448495960386d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0102340234033103d);

  }

  public void test52() {}
//   public void test52() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test52"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     double var16 = var0.nextWeibull(1.0d, 1.6298598478788293d);
//     double var19 = var0.nextWeibull(1.151569395337692d, 7.22597376812575E86d);
//     double var22 = var0.nextGaussian(2.4188678176733584E-44d, 0.9732473842406115d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var25 = var0.nextLong(100L, 90L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "f9cfa1aa94732596c4530924dda8aba4f80c03fdf2e9fb6115e802272aa18e9663b9c390eef8f85a7237f3812b75584cf5d4"+ "'", var2.equals("f9cfa1aa94732596c4530924dda8aba4f80c03fdf2e9fb6115e802272aa18e9663b9c390eef8f85a7237f3812b75584cf5d4"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 5.243404081781354E40d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.40849907225249704d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 3.036935102061053E86d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == (-0.28042101462801783d));
// 
//   }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test53"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm((-9223372036854775808L), (-48600L));
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test54"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(5.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2);

  }

  public void test55() {}
//   public void test55() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test55"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     var0.reSeed(1L);
//     var0.reSeedSecure(27898L);
//     int var9 = var0.nextBinomial(288, 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "ca8aaff2f2756660c5fcc45d661137dc1c16f43b3b13d94c671d75349a917ce4009ec40c6a3f3cea9692974e0327672684c2"+ "'", var2.equals("ca8aaff2f2756660c5fcc45d661137dc1c16f43b3b13d94c671d75349a917ce4009ec40c6a3f3cea9692974e0327672684c2"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
// 
//   }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test56"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var3 = var0.nextZipf(8100, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test57"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(1612922);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test58"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(10, 50.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = var2.substituteMostRecentElement(0.33076205045336105d);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException");
    } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
      // Expected exception.
    }

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test59"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var2 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var3.setContractionCriteria(50.000008f);
    double[] var6 = var3.getInternalValues();
    double[] var8 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
    var9.setContractionCriteria(50.000008f);
    double[] var12 = var9.getInternalValues();
    double[] var13 = var9.getElements();
    double var14 = var0.mannWhitneyUTest(var6, var13);
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var13);
    var15.discardFrontElements(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0d);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test60"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(768793337, 9.536743E-7f);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test61"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(5.0f);
    var0.setElement(110, Double.NaN);
    var0.discardFrontElements(10);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var8.setContractionCriteria(50.000008f);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var8);
    int var12 = var8.getExpansionMode();
    double[] var13 = var8.getInternalValues();
    var8.discardMostRecentElements(0);
    double[] var16 = var8.getElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test62"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)2.636818730233018d, (java.lang.Number)(-3.0d), (java.lang.Number)7.446477798073399d);
    java.lang.Number var4 = var3.getArgument();
    java.lang.Number var5 = var3.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 2.636818730233018d+ "'", var4.equals(2.636818730233018d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-3.0d)+ "'", var5.equals((-3.0d)));

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test63"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(2.509178478658057d, 1.8246532949072747d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.009479769440616246d));

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test64"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(20, (-105));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test65() {}
//   public void test65() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test65"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     double var17 = var0.nextGamma(0.9775852669347048d, 3.199763873047224E14d);
//     double var20 = var0.nextUniform(0.0d, 8.799063409660144E86d);
//     org.apache.commons.math3.distribution.NormalDistribution var24 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var24.reseedRandomGenerator(1L);
//     boolean var27 = var24.isSupportConnected();
//     double var28 = var24.getMean();
//     double var29 = var24.sample();
//     double var30 = var24.getSupportUpperBound();
//     boolean var31 = var24.isSupportUpperBoundInclusive();
//     boolean var32 = var24.isSupportUpperBoundInclusive();
//     double var33 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var24);
//     double var37 = var0.nextUniform((-3.4536536242642804E43d), 0.1672559658154289d, true);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var40 = var0.nextHexString(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "40c114eeec19462e4695ea64270f29d497b3eb58c1a8335bac5423e5626fcd42098c8f29b3c03d328d53012524eb92a02c77"+ "'", var2.equals("40c114eeec19462e4695ea64270f29d497b3eb58c1a8335bac5423e5626fcd42098c8f29b3c03d328d53012524eb92a02c77"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-2.733356509038837E43d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 6.490345675466734E13d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 3.1638800535229994E86d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 3.5671315446818194E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1.4937601786028552E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == (-1.2620300816010174E43d));
// 
//   }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test66"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(1612820, 0.0f, 0.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test67"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(0.32530717150821276d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0533806469857276d);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test68"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    boolean var1 = var0.isSupportLowerBoundInclusive();
    var0.reseedRandomGenerator((-1L));
    double var5 = var0.probability((-27.741692681648217d));
    double var6 = var0.sample();
    double var8 = var0.probability(0.6969136111134943d);
    boolean var9 = var0.isSupportConnected();
    double var10 = var0.sample();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.08971084836383868d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1.3629014047559318d);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test69"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(4.6310740263131307E86d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 8.082748966275464E84d);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test70"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var5 = new double[] { 1.0d, 100.0d};
    var2.addElements(var5);
    double[] var7 = var2.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    int var9 = var8.getExpansionMode();
    double[] var10 = var8.getInternalValues();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test71"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    var3.reseedRandomGenerator(1L);
    boolean var6 = var3.isSupportConnected();
    double var7 = var3.getMean();
    double var8 = var3.getStandardDeviation();
    double var9 = var3.getStandardDeviation();
    double var11 = var3.density(0.08648854529952615d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.6881171418161356E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 2.6881171418161356E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1.4840955931403377E-44d);

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test72"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(1.538521790062942d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.657700121095908d);

  }

  public void test73() {}
//   public void test73() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test73"); }
// 
// 
//     java.lang.Number var1 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)2.9681911862806774E-44d, var1, false);
//     org.apache.commons.math3.exception.util.Localizable var4 = null;
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     org.apache.commons.math3.exception.NotPositiveException var7 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(short)1);
//     java.lang.Object[] var8 = new java.lang.Object[] { (short)1};
//     org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException(var5, var8);
//     org.apache.commons.math3.exception.MathArithmeticException var10 = new org.apache.commons.math3.exception.MathArithmeticException(var4, var8);
//     var3.addSuppressed((java.lang.Throwable)var10);
//     org.apache.commons.math3.exception.MathInternalError var12 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var10);
// 
//   }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test74"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(2.2334789518497913d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9984147991325157d);

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test75"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    java.lang.String var5 = var4.name();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "RANDOM"+ "'", var5.equals("RANDOM"));

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test76"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(2.0000008411562833d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.00467771759691192d);

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test77"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-22), (-768793332));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test78"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0000001f);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test79"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(2870, (-4));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-11480));

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test80"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(9.536743E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9.536743E-7f);

  }

  public void test81() {}
//   public void test81() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test81"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(6.722308758188109E59d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test82"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test83"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var2.setContractionCriteria(50.000008f);
    double[] var5 = var2.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var2.setNumElements(101);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setExpansionFactor(1.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test84() {}
//   public void test84() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test84"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     double var17 = var0.nextGamma(0.9775852669347048d, 3.199763873047224E14d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("bbc76c98706e096cbdb48c11be18b37feafe094ae0e5291b81fe65cbd0c42cc6f465c322de0f5afaf8fdd0237c92d0d9c2d6", "");
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "0511ed16809916aeb8296401d5c4f0c1eda22604dd55896a20df9e28f2de7db171d226cd45b7018bf5f2afd02211237a1f93"+ "'", var2.equals("0511ed16809916aeb8296401d5c4f0c1eda22604dd55896a20df9e28f2de7db171d226cd45b7018bf5f2afd02211237a1f93"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 2.3924476004323356E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 4.313932294153437E14d);
// 
//   }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test85"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(0.11859337015859625d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.11915249691498865d);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test86"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(4233, 50.000015f, 2.5f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test87"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(5.0f);
    var0.setElement(110, Double.NaN);
    var0.discardFrontElements(10);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var8.setContractionCriteria(50.000008f);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var8);
    int var12 = var8.getExpansionMode();
    var8.setExpansionMode(0);
    var8.clear();
    double[] var16 = var8.getInternalValues();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var8.setNumElements((-22));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test88"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var2.setContractionCriteria(5.0f);
    var2.setElement(110, Double.NaN);
    var2.setElement(100, (-0.6120891811851691d));
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var2);
    double[] var12 = var2.getElements();
    var2.setContractionCriteria(102400.01f);
    var2.setContractionCriteria(102400.01f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test89"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.259921049017114d, 31.402066659134473d, 0.0d);
    double var4 = var3.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 986.0897904647248d);

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test90"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(41453239, 288);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test91() {}
//   public void test91() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test91"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     java.lang.String var4 = var0.nextHexString(110);
//     int var7 = var0.nextPascal(3, 0.0d);
//     double var10 = var0.nextGamma(5.889838469655482E86d, (-6.935585632560808E42d));
//     java.lang.String var12 = var0.nextHexString(101);
//     double var15 = var0.nextGamma(0.09249839913279755d, 2.376313347579354E14d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.0078830563026993d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "30f878824731fd2ea7d0841dc65bf9650aff373c20a5cbe575bdf4e21bcab253f8cd186c779a2a0d532bbc163f2d9ed96889c7d9f009b2"+ "'", var4.equals("30f878824731fd2ea7d0841dc65bf9650aff373c20a5cbe575bdf4e21bcab253f8cd186c779a2a0d532bbc163f2d9ed96889c7d9f009b2"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-4.08494790682465E129d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "a73e609c16f34c7094853e36a5f7a060af592bca3ad676ea3b9dee95e835983d7038768bb6847b7a7ff46e6c1345105024c9f"+ "'", var12.equals("a73e609c16f34c7094853e36a5f7a060af592bca3ad676ea3b9dee95e835983d7038768bb6847b7a7ff46e6c1345105024c9f"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 3.1540754195491516E13d);
// 
//   }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test92"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)5.458802422386986E43d);

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test93"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(1.3872175661331396d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test94"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow((-3.378211155916252E42d), 9.332621544395286E157d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.POSITIVE_INFINITY);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test95"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)0.9775852669347048d);
    org.apache.commons.math3.exception.MathInternalError var2 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var1);

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test96"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(0.9999999730206884d, 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 15.999999568331015d);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test97"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(100, 2870);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test98"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(1.0920559274043928d, 1.5707963267948966d, (-6.23409514341469E42d), (-768793332));
      fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException");
    } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
      // Expected exception.
    }

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test99"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(2560.0f, 0.4260292805193087d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2559.9998f);

  }

  public void test100() {}
//   public void test100() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test100"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     double var4 = var0.nextExponential(0.056182176564052d);
//     var0.reSeedSecure();
//     double var9 = var0.nextUniform(0.056182176564052d, 3.181467854611004d, true);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("2aabd6eea19e19d6b315a3a56a4773b8da6ba88f96dfb0ed7d77f7e6312d97096b66e8ed02fd45e89bcacbfec531b0232769", "b5cc8d24a926cbc69b4dc93af349cddcc9a59a400b2e741165351a188d782f33d6dd942cd66c50c96bd7482fa7bd5c804b4e");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "3f2687355930e3cc54667e6c3f4a801b5c27bb3db154e94226d60b0a870540b0616c9baf840cbfced9a960b74a468f06eb85"+ "'", var2.equals("3f2687355930e3cc54667e6c3f4a801b5c27bb3db154e94226d60b0a870540b0616c9baf840cbfced9a960b74a468f06eb85"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.04551106706959826d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2.5507071152812264d);
// 
//   }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test101"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1.5428819133018126E43d), (java.lang.Number)(-5.870904417073582E43d), false);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test102"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var2 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var3.setContractionCriteria(50.000008f);
    double[] var6 = var3.getInternalValues();
    double[] var8 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
    var9.setContractionCriteria(50.000008f);
    double[] var12 = var9.getInternalValues();
    double[] var13 = var9.getElements();
    double var14 = var0.mannWhitneyU(var6, var13);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var15 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var17 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray(var17);
    var18.setContractionCriteria(50.000008f);
    double[] var21 = var18.getInternalValues();
    double[] var23 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var24 = new org.apache.commons.math3.util.ResizableDoubleArray(var23);
    var24.setContractionCriteria(50.000008f);
    double[] var27 = var24.getInternalValues();
    double[] var28 = var24.getElements();
    double var29 = var15.mannWhitneyU(var21, var28);
    org.apache.commons.math3.util.ResizableDoubleArray var30 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var30.addElement(0.02797455810085192d);
    var30.discardFrontElements(1);
    org.apache.commons.math3.util.ResizableDoubleArray var35 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var36 = var35.getInternalValues();
    var30.addElements(var36);
    double var38 = var0.mannWhitneyUTest(var21, var36);
    org.apache.commons.math3.util.ResizableDoubleArray var39 = new org.apache.commons.math3.util.ResizableDoubleArray(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.10247043485974927d);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test103"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-4), 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1048576);

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test104"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb((-1.6253158860283166E43d), 45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-5.718571889590995E56d));

  }

  public void test105() {}
//   public void test105() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test105"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     double var16 = var0.nextWeibull(1.0d, 1.6298598478788293d);
//     double var19 = var0.nextCauchy((-1.1440883267692863E33d), 3.3030345912774096E43d);
//     double var22 = var0.nextUniform(335.0334109186577d, 7.22597376812575E86d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var25 = var0.nextUniform(3.7037409303329316E43d, 0.5650934208572123d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "af920c516b62f48280b53a88cacaa396b2fe6750e374b4f46f3615a5e764e963c7813c7520e8548ed49a70e9ead2748303f0"+ "'", var2.equals("af920c516b62f48280b53a88cacaa396b2fe6750e374b4f46f3615a5e764e963c7813c7520e8548ed49a70e9ead2748303f0"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 3.154250328140012E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1.7033129788293093d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 3.267506017772554E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 9.637868946975234E85d);
// 
//   }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test106"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(2560.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2560.0002f);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test107"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(0, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test108"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    var3.reseedRandomGenerator(1L);
    boolean var6 = var3.isSupportConnected();
    double var7 = var3.getSupportLowerBound();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var3.cumulativeProbability(0.9999999985344893d, 0.017275917538634444d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == Double.NEGATIVE_INFINITY);

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test109"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(0, 6L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test110"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var2.setContractionCriteria(5.0f);
    var2.setElement(110, Double.NaN);
    var2.setElement(100, (-0.6120891811851691d));
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var13 = var12.getNanStrategy();
    java.lang.String var14 = var13.name();
    java.lang.String var15 = var13.name();
    org.apache.commons.math3.stat.ranking.NaNStrategy var16 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var16);
    org.apache.commons.math3.stat.ranking.TiesStrategy var18 = var17.getTiesStrategy();
    int var19 = var18.ordinal();
    java.lang.String var20 = var18.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var13, var18);
    org.apache.commons.math3.stat.ranking.NaNStrategy var22 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var22);
    org.apache.commons.math3.stat.ranking.TiesStrategy var24 = var23.getTiesStrategy();
    int var25 = var24.ordinal();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var26 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var13, var24);
    double[] var28 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var29 = new org.apache.commons.math3.util.ResizableDoubleArray(var28);
    var29.setContractionCriteria(50.000008f);
    double[] var32 = var29.getInternalValues();
    double[] var33 = var29.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var34 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var34.addElement(0.02797455810085192d);
    var34.discardFrontElements(1);
    org.apache.commons.math3.util.ResizableDoubleArray var39 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var40 = var39.getInternalValues();
    var34.addElements(var40);
    double var42 = var26.mannWhitneyUTest(var33, var40);
    var0.addElements(var40);
    double var45 = var0.substituteMostRecentElement(4.9E-324d);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var46 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var48 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var49 = new org.apache.commons.math3.util.ResizableDoubleArray(var48);
    var49.setContractionCriteria(50.000008f);
    double[] var52 = var49.getInternalValues();
    double[] var54 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var55 = new org.apache.commons.math3.util.ResizableDoubleArray(var54);
    var55.setContractionCriteria(50.000008f);
    double[] var58 = var55.getInternalValues();
    double[] var59 = var55.getElements();
    double var60 = var46.mannWhitneyUTest(var52, var59);
    var0.addElements(var52);
    boolean var63 = var0.equals((java.lang.Object)70.96796119341717d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "MAXIMAL"+ "'", var14.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "MAXIMAL"+ "'", var15.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "AVERAGE"+ "'", var20.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0.10247043485974927d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);

  }

  public void test111() {}
//   public void test111() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test111"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     double var6 = var3.cumulativeProbability(1.4210854715202004E-14d, 2.0d);
//     double var7 = var3.sample();
//     double[] var9 = var3.sample(1612820);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.9681911862806774E-44d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.2364874454765395E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
// 
//   }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test112"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var5 = new double[] { 1.0d, 100.0d};
    var2.addElements(var5);
    double[] var7 = var2.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    float var9 = var8.getExpansionFactor();
    var8.setContractionCriteria(2.30584301E18f);
    var8.addElement(0.3284090290722705d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 2.0f);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test113"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(50.000015f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test114"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double[] var2 = var0.sample(1);
    double var3 = var0.getMean();
    double var5 = var0.probability(6.991412387147916E14d);
    double var8 = var0.cumulativeProbability(0.13194341175745541d, 0.6945971187784026d);
    double var9 = var0.getStandardDeviation();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.2038606163816573d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test115"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(1.0102340234033103d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8469056854758309d);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test116"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs((-0.9999999f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999999f);

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test117"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(42L, (-2L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 40L);

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test118"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(-5.718571889590995E56d), (java.lang.Number)0.0f, true);

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test119"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var2.setContractionCriteria(5.0f);
    var2.setElement(110, Double.NaN);
    var2.setElement(100, (-0.6120891811851691d));
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var2);
    double[] var12 = var2.getInternalValues();
    double var14 = var2.addElementRolling(68397.35544481203d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test120"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.math.BigInteger var2 = null;
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var6 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)100.0f, (java.lang.Number)var4, (java.lang.Number)0.5000672346092545d);
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    java.math.BigInteger var9 = null;
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var13 = new org.apache.commons.math3.exception.OutOfRangeException(var7, (java.lang.Number)100.0f, (java.lang.Number)var11, (java.lang.Number)0.5000672346092545d);
    java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, var11);
    java.math.BigInteger var16 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 12700);
    java.math.BigInteger var18 = org.apache.commons.math3.util.ArithmeticUtils.pow(var16, 768793337);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.math.BigInteger var20 = org.apache.commons.math3.util.ArithmeticUtils.pow(var18, (-5129524049062756352L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test121"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(3.7800726666287974E42d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.165822100505927E44d);

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test122"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(1612900, 47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 47);

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test123"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(0.0d, 3.1471375077713234E41d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test124"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.5434235565682811d, (java.lang.Number)0.8341186568683249d, (java.lang.Number)6L);

  }

  public void test125() {}
//   public void test125() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test125"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     double var16 = var0.nextWeibull(1.0d, 1.6298598478788293d);
//     double var19 = var0.nextCauchy((-1.1440883267692863E33d), 3.3030345912774096E43d);
//     var0.reSeedSecure();
//     double var24 = var0.nextUniform(0.0d, 2.4188678176733584E-44d, true);
//     int var27 = var0.nextPascal(66, 0.8341186568683249d);
//     org.apache.commons.math3.distribution.IntegerDistribution var28 = null;
//     int var29 = var0.nextInversionDeviate(var28);
// 
//   }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test126"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    java.lang.String var2 = var1.name();
    java.lang.String var3 = var1.name();
    boolean var5 = var1.equals((java.lang.Object)"bbc76c98706e096cbdb48c11be18b37feafe094ae0e5291b81fe65cbd0c42cc6f465c322de0f5afaf8fdd0237c92d0d9c2d6");
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var6.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7, var8);
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = var11.getTiesStrategy();
    int var13 = var12.ordinal();
    java.lang.String var14 = var12.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7, var12);
    org.apache.commons.math3.stat.ranking.TiesStrategy var16 = var15.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var15.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var18 = var15.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var19 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "MAXIMAL"+ "'", var2.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "MAXIMAL"+ "'", var3.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "AVERAGE"+ "'", var14.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test127"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(0.027442916677309914d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.027073110299788997d);

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test128"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(16.5699685764709d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 17L);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test129"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, var1, (java.lang.Number)(-1.190693709545786E43d), false);
    java.lang.Number var5 = var4.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-1.190693709545786E43d)+ "'", var5.equals((-1.190693709545786E43d)));

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test130"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(0.7518132117785729d, 0.7546837768046001d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.7518132117785729d);

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test131"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(90, 12827000);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 115443000);

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test132"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(0.6635655058964316d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5807313490167082d);

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test133"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(5.0f, 1.7130083828445737d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.9999995f);

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test134"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    var3.reseedRandomGenerator(1L);
    boolean var6 = var3.isSupportConnected();
    double var7 = var3.getMean();
    double var8 = var3.sample();
    double[] var10 = var3.sample(8100);
    double var11 = var3.sample();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 3.5671315446818194E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1.3629994011288507E43d);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test135"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    double var4 = var3.getSupportLowerBound();
    double var6 = var3.probability((-0.5606386275277436d));
    double var8 = var3.inverseCumulativeProbability(0.5d);
    boolean var9 = var3.isSupportConnected();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test136"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.math.BigInteger var2 = null;
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var6 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)100.0f, (java.lang.Number)var4, (java.lang.Number)0.5000672346092545d);
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    java.math.BigInteger var9 = null;
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var13 = new org.apache.commons.math3.exception.OutOfRangeException(var7, (java.lang.Number)100.0f, (java.lang.Number)var11, (java.lang.Number)0.5000672346092545d);
    java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, var11);
    java.math.BigInteger var16 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 10L);
    org.apache.commons.math3.exception.util.Localizable var17 = null;
    java.math.BigInteger var19 = null;
    java.math.BigInteger var21 = org.apache.commons.math3.util.ArithmeticUtils.pow(var19, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var23 = new org.apache.commons.math3.exception.OutOfRangeException(var17, (java.lang.Number)100.0f, (java.lang.Number)var21, (java.lang.Number)0.5000672346092545d);
    org.apache.commons.math3.exception.util.Localizable var24 = null;
    java.math.BigInteger var26 = null;
    java.math.BigInteger var28 = org.apache.commons.math3.util.ArithmeticUtils.pow(var26, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var30 = new org.apache.commons.math3.exception.OutOfRangeException(var24, (java.lang.Number)100.0f, (java.lang.Number)var28, (java.lang.Number)0.5000672346092545d);
    java.math.BigInteger var31 = org.apache.commons.math3.util.ArithmeticUtils.pow(var21, var28);
    java.math.BigInteger var33 = org.apache.commons.math3.util.ArithmeticUtils.pow(var21, 12700);
    java.math.BigInteger var35 = org.apache.commons.math3.util.ArithmeticUtils.pow(var33, 768793337);
    java.math.BigInteger var36 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, var33);
    java.math.BigInteger var38 = org.apache.commons.math3.util.ArithmeticUtils.pow(var33, 20500L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test137() {}
//   public void test137() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test137"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     boolean var9 = var6.isSupportConnected();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var0.nextHypergeometric(102400, 478245873, (-1820841394));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "58ee72c81fa2c7a2c83ce46db65cad00d6549dd78ccfa5dead8f0bc31ec62ebbeb76875a6535ded0d2ec88c606e6b0dce0bd"+ "'", var2.equals("58ee72c81fa2c7a2c83ce46db65cad00d6549dd78ccfa5dead8f0bc31ec62ebbeb76875a6535ded0d2ec88c606e6b0dce0bd"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-2.928852472141946E43d));
// 
//   }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test138"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(short)0, (java.lang.Number)10, false);
    boolean var4 = var3.getBoundIsAllowed();
    java.lang.Throwable[] var5 = var3.getSuppressed();
    java.lang.Number var6 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var7 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var6);
    var3.addSuppressed((java.lang.Throwable)var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test139"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(2.0000007f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0000007f);

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test140"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(1.7744421521450668E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.7744421521450668E43d);

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test141"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(27900L, 40L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test142"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)88.72804665106598d, (java.lang.Number)3.5671315446818194E43d, false);
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
    boolean var6 = var4.getBoundIsAllowed();
    boolean var7 = var4.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test143"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(0, 45);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test144() {}
//   public void test144() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test144"); }
// 
// 
//     org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     var0.setContractionCriteria(5.0f);
//     var0.setElement(110, Double.NaN);
//     var0.discardFrontElements(10);
//     org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     var8.setContractionCriteria(50.000008f);
//     org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var8);
//     int var12 = var8.getExpansionMode();
//     double[] var13 = var8.getInternalValues();
//     var8.discardMostRecentElements(0);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var17 = var16.getNanStrategy();
//     java.lang.String var18 = var17.name();
//     java.lang.String var19 = var17.name();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var20 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var22 = var21.getTiesStrategy();
//     int var23 = var22.ordinal();
//     java.lang.String var24 = var22.name();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var25 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var17, var22);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var26 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var27 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var26);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var28 = var27.getTiesStrategy();
//     int var29 = var28.ordinal();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var30 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var17, var28);
//     double[] var32 = new double[] { 1.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var33 = new org.apache.commons.math3.util.ResizableDoubleArray(var32);
//     double[] var36 = new double[] { 1.0d, 100.0d};
//     var33.addElements(var36);
//     double[] var38 = var33.getInternalValues();
//     org.apache.commons.math3.util.ResizableDoubleArray var39 = new org.apache.commons.math3.util.ResizableDoubleArray(var38);
//     org.apache.commons.math3.util.ResizableDoubleArray var42 = new org.apache.commons.math3.util.ResizableDoubleArray(10, 50.0f);
//     var42.setElement(12700, 1.0806511876345213E86d);
//     org.apache.commons.math3.distribution.NormalDistribution var46 = new org.apache.commons.math3.distribution.NormalDistribution();
//     boolean var47 = var46.isSupportUpperBoundInclusive();
//     boolean var48 = var46.isSupportLowerBoundInclusive();
//     double var49 = var46.getMean();
//     double[] var51 = var46.sample(110);
//     var42.addElements(var51);
//     double var53 = var30.mannWhitneyUTest(var38, var51);
//     var8.addElements(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var18 + "' != '" + "MAXIMAL"+ "'", var18.equals("MAXIMAL"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var19 + "' != '" + "MAXIMAL"+ "'", var19.equals("MAXIMAL"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var24 + "' != '" + "AVERAGE"+ "'", var24.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 0.0376197072270027d);
// 
//   }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test145"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(1.2696572718964828E42d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.18270418265156882d);

  }

  public void test146() {}
//   public void test146() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test146"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
//     java.lang.String var2 = var1.name();
//     java.lang.String var3 = var1.name();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var4 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var5.getTiesStrategy();
//     int var7 = var6.ordinal();
//     java.lang.String var8 = var6.name();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var6);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var10 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var12 = var11.getTiesStrategy();
//     int var13 = var12.ordinal();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var14 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var12);
//     double[] var16 = new double[] { 1.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var17 = new org.apache.commons.math3.util.ResizableDoubleArray(var16);
//     double[] var20 = new double[] { 1.0d, 100.0d};
//     var17.addElements(var20);
//     double[] var22 = var17.getInternalValues();
//     org.apache.commons.math3.util.ResizableDoubleArray var23 = new org.apache.commons.math3.util.ResizableDoubleArray(var22);
//     org.apache.commons.math3.util.ResizableDoubleArray var26 = new org.apache.commons.math3.util.ResizableDoubleArray(10, 50.0f);
//     var26.setElement(12700, 1.0806511876345213E86d);
//     org.apache.commons.math3.distribution.NormalDistribution var30 = new org.apache.commons.math3.distribution.NormalDistribution();
//     boolean var31 = var30.isSupportUpperBoundInclusive();
//     boolean var32 = var30.isSupportLowerBoundInclusive();
//     double var33 = var30.getMean();
//     double[] var35 = var30.sample(110);
//     var26.addElements(var35);
//     double var37 = var14.mannWhitneyUTest(var22, var35);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var38 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     double[] var40 = new double[] { 1.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var41 = new org.apache.commons.math3.util.ResizableDoubleArray(var40);
//     var41.setContractionCriteria(50.000008f);
//     double[] var44 = var41.getInternalValues();
//     double[] var46 = new double[] { 1.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var47 = new org.apache.commons.math3.util.ResizableDoubleArray(var46);
//     var47.setContractionCriteria(50.000008f);
//     double[] var50 = var47.getInternalValues();
//     double[] var51 = var47.getElements();
//     double var52 = var38.mannWhitneyUTest(var44, var51);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var53 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     double[] var55 = new double[] { 1.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var56 = new org.apache.commons.math3.util.ResizableDoubleArray(var55);
//     var56.setContractionCriteria(50.000008f);
//     double[] var59 = var56.getInternalValues();
//     double[] var61 = new double[] { 1.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var62 = new org.apache.commons.math3.util.ResizableDoubleArray(var61);
//     var62.setContractionCriteria(50.000008f);
//     double[] var65 = var62.getInternalValues();
//     double[] var66 = var62.getElements();
//     double var67 = var53.mannWhitneyU(var59, var66);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var68 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     double[] var70 = new double[] { 1.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var71 = new org.apache.commons.math3.util.ResizableDoubleArray(var70);
//     var71.setContractionCriteria(50.000008f);
//     double[] var74 = var71.getInternalValues();
//     double[] var76 = new double[] { 1.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var77 = new org.apache.commons.math3.util.ResizableDoubleArray(var76);
//     var77.setContractionCriteria(50.000008f);
//     double[] var80 = var77.getInternalValues();
//     double[] var81 = var77.getElements();
//     double var82 = var68.mannWhitneyU(var74, var81);
//     org.apache.commons.math3.util.ResizableDoubleArray var83 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     var83.addElement(0.02797455810085192d);
//     var83.discardFrontElements(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var88 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     double[] var89 = var88.getInternalValues();
//     var83.addElements(var89);
//     double var91 = var53.mannWhitneyUTest(var74, var89);
//     double var92 = var14.mannWhitneyU(var44, var74);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "MAXIMAL"+ "'", var2.equals("MAXIMAL"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "MAXIMAL"+ "'", var3.equals("MAXIMAL"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 0.05618776986912999d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var67 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var70);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var74);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var81);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var82 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var89);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var91 == 0.10247043485974927d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var92 == 0.5d);
// 
//   }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test147"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(100.0f, 61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.305843E20f);

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test148"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var2.setContractionCriteria(50.000008f);
    double[] var5 = var2.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    int var7 = var2.start();
    double var9 = var2.substituteMostRecentElement(31.4789883982983d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test149"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(33440.02188934844d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 32.21727847584094d);

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test150"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(1.7005629616909042d, 0.8623188722876839d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.5806817922988654d);

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test151"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(5.0f);
    var0.setElement(110, Double.NaN);
    var0.discardFrontElements(10);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var8.setContractionCriteria(50.000008f);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var8);
    int var12 = var8.getExpansionMode();
    var8.setExpansionMode(0);
    var8.clear();
    var8.setNumElements(287);
    var8.addElement(1.5485965529242296d);
    double var21 = var8.substituteMostRecentElement(0.6647615947356664d);
    org.apache.commons.math3.distribution.NormalDistribution var24 = new org.apache.commons.math3.distribution.NormalDistribution(1.8246532949072747d, 0.9732473842406115d);
    boolean var25 = var8.equals((java.lang.Object)var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1.5485965529242296d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test152"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(0.0078125d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.36353847812057E-4d);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test153"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var2.setContractionCriteria(50.000008f);
    var2.setExpansionMode(0);
    var2.discardFrontElements(0);
    double var10 = var2.addElementRolling(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1.0d);

  }

  public void test154() {}
//   public void test154() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test154"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     double var16 = var0.nextWeibull(1.0d, 1.6298598478788293d);
//     double var19 = var0.nextWeibull(1.151569395337692d, 7.22597376812575E86d);
//     var0.reSeedSecure();
//     var0.reSeedSecure(0L);
//     java.lang.String var24 = var0.nextSecureHexString(2951);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "4054567616853307764c16c3eaeb8d8d51ee269bf8f96a24ee6121b9e87735d64fe2c251968bb4493ea1a8d853fbedd91524"+ "'", var2.equals("4054567616853307764c16c3eaeb8d8d51ee269bf8f96a24ee6121b9e87735d64fe2c251968bb4493ea1a8d853fbedd91524"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.7705999455763922E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.04384961235783543d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1.8850185598529162E86d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var24 + "' != '" + "ac9d8f43434b08175c20382902505f32cb4b197f54938c0bfbbf2c1a3c8f291d312b8001c2f74b021b10f464a070383633387d52d8c1be010d21761acc5cdf0821b0b34488ec40cfa46b509aaef63274c4375c9207f420193bcbf96f1e483d8528eed8b0983fc5b0122626ee57e5a23c2e6f2458e48cfd8dad636f1f42d15719f839248cc176cc92ceaeee0fe1997006cc32e72b8041220d8f83e7c6c51f90253fe37185863519f4bb91d61f4b05a38550cfde158acc853f9ed92266687899543595408e80ebdf41168e920e6e0fdb1153961f2727ee733b09c64ba519adaf7ac815d66e531b5b6f40af5d8fe039c6901a2dbcccb41d1b67168c2cca651fd4329eca01f2d9d8a2eeeb84191b8ad30dd43adf18141ed2c1fad1132b4210944419bcecdd9ece2ff17b0f377966a2aaa85597905cf488cd28b54db2cfe5f251527f92fa65196ae5a9e7fce66b228f43eac16eef649ea3e0c591adb6555f73cc5b87f26884f1f59bb7ea0ed5022d068d334bd057ed69aa99c2e8cca7659cc22784c8e03d588f632742137ed8d3760e41420ea5e327cd27d9be77be4766af25d5397f59217b8652c22d83fa2f75c1e5dc316ff6ccca6b567e98e0783842d1a7ae6cd044f423512f6bf39ffff5e0b1f75c15e8adb9b2ff3538beda7a36823bfb838693734d1ad27454c57003e7a15676bfb07eb951668a17d583910726b5f7eb7e4d188e6f9b95023de3afae7dbf19fc718d76f3b3e156daae513501c53e54ad88e4c72fe4e41d746fa7ca8739b7ebbebc52c3e9126500ef504b7fd16734d254ddc87fc34110f53056d76d82909dc3a26f036bc6b2c83e5ad4984dea9a5d5969d810c5346a3cd8bd9003e97bdc5597a1b8872db095e8090b7f6ee9bfc2eb88c166bfd95c0b38313d2d51e7759fa939e7cb31730b19b7b4aac5b29916bb3990c7b99113ab9f2d1bf459e1561e6d6144c10c67830f19dd2e1927a378a25bcae0578672e7d273d7b3d48fd3eb5d8af3f280262f554858b71a29a5b9cf8b138c785923464e9f26a3bb141312dc10f4d3eeec38cd1c793cc806d49a7566978d4b0d66d5da6088f5d4aa2f36138137ee05479f1ed07355e96e065e9ef828bfd23284c5acf95e0698282c69e20cc516828bcd10c4c3abf6bc4365f7516d4df95885d04a125574a9eae8f87bc9309e7656f2ed0b9cec379aae48566f83a20c5373ecc41bd3210534e9f345eb583867b97e5233d7b2acbbaa872182a6c59f7059b8a9821469cce5d30647d8ba95275a9625971e4dd2fa57e488461dc0b1a5024119c354e0534f1f40559e1c528b6215a9103c503740d8a012027ea538f3eacc058c4e3858a4f1f0f7bb36295d2657de96455d9f5d10a6eadeda8d72104f3b117a934391ed68238c24f8fe91783ffdff757a7270850356387e535c7a19459517bd152e2a17f19733bdec0d21a2e9fd374133b23e37f967f183487e8697cfea4a1ccb0d61147c0915f05b69484fc0c0554c5aee42c855be791febb8f17de67106d935008044c67164e2af38473c6cef10e624c477ed983b74e59491c1b6d075ae43577da785224b48fa84ee7b12d7a0ecbc1fb0d4a0b8d282998bcd156faef405581b131b908c8bc44347e6b986cb8a48d26e0ffcd0772371f4ca10942c9c60f1ddce3bae7a9b9aef2a8b5d515bc87ba37744ff4a25ad6076fefa1b109392f923b50aaf219bb741b2303e1e78d29569ecf301636951ffb838c40cc18a2a18c9c9368faba77f109f07b6f1aef8b8ae47b7778679ecca546e1710d8b72540a189c6b11a47fc17ff85db4c613dc1c962c664b57d9c148106b8d33e77a8d84f4743260042d75e1349d7ed93bd40b7e88b1264f9a6deb8c8e3c73d0c8aa8c9fb50da5c734a4cd3ef1504be9454f915bd42cd021986289a50fe6af8e9de4df7994daa6f4af4403dcdf19b5e01990048183a22cca3b0bb213c7929ba568c16b67e9a2fdd037f6cf351f5311fee05f7d0ab3f29c05b77644be69de9c10acfec690d0db1e284699db9d440a5e3f89aa7594527484f53ea47a2a5e7c332936cc45b4fc40cc8c5df06809fa63389679340c"+ "'", var24.equals("ac9d8f43434b08175c20382902505f32cb4b197f54938c0bfbbf2c1a3c8f291d312b8001c2f74b021b10f464a070383633387d52d8c1be010d21761acc5cdf0821b0b34488ec40cfa46b509aaef63274c4375c9207f420193bcbf96f1e483d8528eed8b0983fc5b0122626ee57e5a23c2e6f2458e48cfd8dad636f1f42d15719f839248cc176cc92ceaeee0fe1997006cc32e72b8041220d8f83e7c6c51f90253fe37185863519f4bb91d61f4b05a38550cfde158acc853f9ed92266687899543595408e80ebdf41168e920e6e0fdb1153961f2727ee733b09c64ba519adaf7ac815d66e531b5b6f40af5d8fe039c6901a2dbcccb41d1b67168c2cca651fd4329eca01f2d9d8a2eeeb84191b8ad30dd43adf18141ed2c1fad1132b4210944419bcecdd9ece2ff17b0f377966a2aaa85597905cf488cd28b54db2cfe5f251527f92fa65196ae5a9e7fce66b228f43eac16eef649ea3e0c591adb6555f73cc5b87f26884f1f59bb7ea0ed5022d068d334bd057ed69aa99c2e8cca7659cc22784c8e03d588f632742137ed8d3760e41420ea5e327cd27d9be77be4766af25d5397f59217b8652c22d83fa2f75c1e5dc316ff6ccca6b567e98e0783842d1a7ae6cd044f423512f6bf39ffff5e0b1f75c15e8adb9b2ff3538beda7a36823bfb838693734d1ad27454c57003e7a15676bfb07eb951668a17d583910726b5f7eb7e4d188e6f9b95023de3afae7dbf19fc718d76f3b3e156daae513501c53e54ad88e4c72fe4e41d746fa7ca8739b7ebbebc52c3e9126500ef504b7fd16734d254ddc87fc34110f53056d76d82909dc3a26f036bc6b2c83e5ad4984dea9a5d5969d810c5346a3cd8bd9003e97bdc5597a1b8872db095e8090b7f6ee9bfc2eb88c166bfd95c0b38313d2d51e7759fa939e7cb31730b19b7b4aac5b29916bb3990c7b99113ab9f2d1bf459e1561e6d6144c10c67830f19dd2e1927a378a25bcae0578672e7d273d7b3d48fd3eb5d8af3f280262f554858b71a29a5b9cf8b138c785923464e9f26a3bb141312dc10f4d3eeec38cd1c793cc806d49a7566978d4b0d66d5da6088f5d4aa2f36138137ee05479f1ed07355e96e065e9ef828bfd23284c5acf95e0698282c69e20cc516828bcd10c4c3abf6bc4365f7516d4df95885d04a125574a9eae8f87bc9309e7656f2ed0b9cec379aae48566f83a20c5373ecc41bd3210534e9f345eb583867b97e5233d7b2acbbaa872182a6c59f7059b8a9821469cce5d30647d8ba95275a9625971e4dd2fa57e488461dc0b1a5024119c354e0534f1f40559e1c528b6215a9103c503740d8a012027ea538f3eacc058c4e3858a4f1f0f7bb36295d2657de96455d9f5d10a6eadeda8d72104f3b117a934391ed68238c24f8fe91783ffdff757a7270850356387e535c7a19459517bd152e2a17f19733bdec0d21a2e9fd374133b23e37f967f183487e8697cfea4a1ccb0d61147c0915f05b69484fc0c0554c5aee42c855be791febb8f17de67106d935008044c67164e2af38473c6cef10e624c477ed983b74e59491c1b6d075ae43577da785224b48fa84ee7b12d7a0ecbc1fb0d4a0b8d282998bcd156faef405581b131b908c8bc44347e6b986cb8a48d26e0ffcd0772371f4ca10942c9c60f1ddce3bae7a9b9aef2a8b5d515bc87ba37744ff4a25ad6076fefa1b109392f923b50aaf219bb741b2303e1e78d29569ecf301636951ffb838c40cc18a2a18c9c9368faba77f109f07b6f1aef8b8ae47b7778679ecca546e1710d8b72540a189c6b11a47fc17ff85db4c613dc1c962c664b57d9c148106b8d33e77a8d84f4743260042d75e1349d7ed93bd40b7e88b1264f9a6deb8c8e3c73d0c8aa8c9fb50da5c734a4cd3ef1504be9454f915bd42cd021986289a50fe6af8e9de4df7994daa6f4af4403dcdf19b5e01990048183a22cca3b0bb213c7929ba568c16b67e9a2fdd037f6cf351f5311fee05f7d0ab3f29c05b77644be69de9c10acfec690d0db1e284699db9d440a5e3f89aa7594527484f53ea47a2a5e7c332936cc45b4fc40cc8c5df06809fa63389679340c"));
// 
//   }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test155"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(891L, 5144L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4583304L);

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test156"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh((-1.3748933199434673E43d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.NEGATIVE_INFINITY);

  }

  public void test157() {}
//   public void test157() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test157"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     double var17 = var0.nextGamma(0.9775852669347048d, 3.199763873047224E14d);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var22 = var0.nextUniform(0.098945418308171d, (-2.791500647694174E42d), false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "bd338612d343f3caa27689e513b2908f6120edea1ed52eccaa35d83418d9f8a2aa1c2f239374b57129d637a2a6d592df2374"+ "'", var2.equals("bd338612d343f3caa27689e513b2908f6120edea1ed52eccaa35d83418d9f8a2aa1c2f239374b57129d637a2a6d592df2374"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-3.045214081717432E42d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.6583116258242225E13d);
// 
//   }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test158"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(12700, 2068);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4);

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test159"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    java.lang.String var2 = var1.name();
    java.lang.String var3 = var1.toString();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = var4.getNanStrategy();
    java.lang.String var6 = var5.toString();
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.NotPositiveException var9 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(short)1);
    java.lang.Object[] var10 = new java.lang.Object[] { (short)1};
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException(var7, var10);
    boolean var12 = var5.equals((java.lang.Object)var7);
    org.apache.commons.math3.random.RandomGenerator var13 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5, var13);
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    boolean var16 = var1.equals((java.lang.Object)var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "MAXIMAL"+ "'", var2.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "MAXIMAL"+ "'", var3.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "MAXIMAL"+ "'", var6.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test160"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-1.1980127630095007E43d), (java.lang.Number)0.02797455810085192d, false);

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test161"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(1.8622531212727638d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0d);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test162"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)2.320319334986273E-34d);

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test163"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-0.8813735870195429d), (java.lang.Number)10L, false);
    boolean var4 = var3.getBoundIsAllowed();
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    java.math.BigInteger var10 = null;
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var10, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var14 = new org.apache.commons.math3.exception.OutOfRangeException(var8, (java.lang.Number)100.0f, (java.lang.Number)var12, (java.lang.Number)0.5000672346092545d);
    org.apache.commons.math3.exception.util.Localizable var15 = null;
    java.math.BigInteger var17 = null;
    java.math.BigInteger var19 = org.apache.commons.math3.util.ArithmeticUtils.pow(var17, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var21 = new org.apache.commons.math3.exception.OutOfRangeException(var15, (java.lang.Number)100.0f, (java.lang.Number)var19, (java.lang.Number)0.5000672346092545d);
    java.math.BigInteger var22 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, var19);
    java.math.BigInteger var24 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, 31L);
    org.apache.commons.math3.exception.OutOfRangeException var25 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)8.799063409660144E86d, (java.lang.Number)0.99999994f, (java.lang.Number)var12);
    org.apache.commons.math3.exception.util.Localizable var26 = null;
    org.apache.commons.math3.exception.util.Localizable var27 = null;
    org.apache.commons.math3.exception.NotPositiveException var29 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(short)1);
    java.lang.Object[] var30 = new java.lang.Object[] { (short)1};
    org.apache.commons.math3.exception.MathIllegalStateException var31 = new org.apache.commons.math3.exception.MathIllegalStateException(var27, var30);
    org.apache.commons.math3.exception.MathIllegalStateException var32 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var25, var26, var30);
    org.apache.commons.math3.exception.MathIllegalStateException var33 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var5, var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test164"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm((-75297573L), 69L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1731844179L);

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test165"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(0.1644372693914552d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.15223793975554561d);

  }

  public void test166() {}
//   public void test166() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test166"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     double var17 = var0.nextGamma(0.9775852669347048d, 3.199763873047224E14d);
//     double var20 = var0.nextF(2.636818730233018d, 1.1282937610745374d);
//     var0.reSeed(6L);
//     int var25 = var0.nextInt((-100), 2147483647);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var27 = var0.nextHexString((-254));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "f7e6b9a633c449f3cdd91a94dbff116e4f45f7aaba4cc307061cf4206e0cbfa70eec28354d531968ea4dfc1e45cb97d70bed"+ "'", var2.equals("f7e6b9a633c449f3cdd91a94dbff116e4f45f7aaba4cc307061cf4206e0cbfa70eec28354d531968ea4dfc1e45cb97d70bed"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-4.665194975340066E43d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 8.53378301482205E14d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.28611487553814935d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1742979373);
// 
//   }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test167"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1.3629994011288507E43d, (java.lang.Number)900L, true);

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test168"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-9223372036854775808L), 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test169"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    java.lang.String var2 = var1.toString();
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.NotPositiveException var5 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(short)1);
    java.lang.Object[] var6 = new java.lang.Object[] { (short)1};
    org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException(var3, var6);
    boolean var8 = var1.equals((java.lang.Object)var3);
    java.lang.String var9 = var1.name();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "MAXIMAL"+ "'", var2.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "MAXIMAL"+ "'", var9.equals("MAXIMAL"));

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test170"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    java.lang.String var2 = var1.name();
    java.lang.String var3 = var1.toString();
    java.lang.String var4 = var1.toString();
    java.lang.Class var5 = var1.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var6.getNanStrategy();
    java.lang.String var8 = var7.name();
    java.lang.String var9 = var7.toString();
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var12 = var11.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var14 = var13.getNanStrategy();
    java.lang.String var15 = var14.name();
    java.lang.String var16 = var14.name();
    org.apache.commons.math3.stat.ranking.NaNStrategy var17 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var17);
    org.apache.commons.math3.stat.ranking.TiesStrategy var19 = var18.getTiesStrategy();
    int var20 = var19.ordinal();
    java.lang.String var21 = var19.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var14, var19);
    double[] var24 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var25 = new org.apache.commons.math3.util.ResizableDoubleArray(var24);
    var25.setContractionCriteria(50.000008f);
    var25.setExpansionMode(0);
    boolean var30 = var19.equals((java.lang.Object)var25);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var31 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var12, var19);
    org.apache.commons.math3.stat.ranking.NaturalRanking var32 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7, var19);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var33 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var19);
    double[] var35 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var36 = new org.apache.commons.math3.util.ResizableDoubleArray(var35);
    var36.setContractionCriteria(50.000008f);
    var36.setExpansionMode(0);
    var36.setContractionCriteria(5.0f);
    double[] var44 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var45 = new org.apache.commons.math3.util.ResizableDoubleArray(var44);
    var45.setContractionCriteria(50.000008f);
    double[] var48 = var45.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var49 = new org.apache.commons.math3.util.ResizableDoubleArray(var45);
    boolean var50 = var36.equals((java.lang.Object)var45);
    double[] var51 = var45.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var52 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var52.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var54 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var54.setContractionCriteria(5.0f);
    var54.setElement(110, Double.NaN);
    var54.setElement(100, (-0.6120891811851691d));
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var52, var54);
    double[] var64 = var54.getInternalValues();
    double var65 = var33.mannWhitneyU(var51, var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "MAXIMAL"+ "'", var2.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "MAXIMAL"+ "'", var3.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "MAXIMAL"+ "'", var4.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "MAXIMAL"+ "'", var8.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "MAXIMAL"+ "'", var9.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "MAXIMAL"+ "'", var15.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + "MAXIMAL"+ "'", var16.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + "AVERAGE"+ "'", var21.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 1.0d);

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test171"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck((-22), 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-122));

  }

  public void test172() {}
//   public void test172() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test172"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(1.9586146923852683d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test173"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(-4.152257768472053E8d));
    org.apache.commons.math3.exception.MathInternalError var2 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var1);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test174"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Throwable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Object[] var6 = new java.lang.Object[] { 0.056182176564052d};
    org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException(var3, var4, var6);
    org.apache.commons.math3.exception.MaxCountExceededException var8 = new org.apache.commons.math3.exception.MaxCountExceededException(var1, (java.lang.Number)0.4855570380544819d, var6);
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var0, var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test175() {}
//   public void test175() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test175"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     boolean var9 = var6.isSupportConnected();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var0.nextGaussian(16.0d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "36748d5c44bd8116bc074caffb723819e0222a8f5a3ca39b8867bf7d4ad21a12c73e6801f5621765f5b2036944d9652a6250"+ "'", var2.equals("36748d5c44bd8116bc074caffb723819e0222a8f5a3ca39b8867bf7d4ad21a12c73e6801f5621765f5b2036944d9652a6250"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-1.1111286669218328E43d));
// 
//   }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test176"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    var3.reseedRandomGenerator(1L);
    boolean var6 = var3.isSupportConnected();
    double var7 = var3.getMean();
    double var8 = var3.sample();
    double var9 = var3.getSupportUpperBound();
    boolean var10 = var3.isSupportUpperBoundInclusive();
    double[] var12 = var3.sample(10);
    var3.reseedRandomGenerator(988L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 3.5671315446818194E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test177"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    var3.reseedRandomGenerator(1L);
    boolean var6 = var3.isSupportConnected();
    double var7 = var3.getMean();
    double var8 = var3.getStandardDeviation();
    double var9 = var3.getStandardDeviation();
    double var10 = var3.getSupportUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.6881171418161356E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 2.6881171418161356E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == Double.POSITIVE_INFINITY);

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test178"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign((-0.9999999f), 50.00001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9999999f);

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test179"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var5 = new double[] { 1.0d, 100.0d};
    var2.addElements(var5);
    float var7 = var2.getContractionCriteria();
    double var9 = var2.addElementRolling((-5.870904417073582E43d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test180"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(5.0f);
    var0.setElement(110, Double.NaN);
    var0.discardFrontElements(10);
    var0.setElement(10, (-1.1440883267692863E33d));
    double[] var12 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray(var12);
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var12);
    double[] var15 = var14.getElements();
    var0.addElements(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test181() {}
//   public void test181() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test181"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.0d, 0.03673319830899499d, 0.702033134407494d, 288);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test182"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(4583304L, 9944796L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 14528100L);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test183"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(0.9999999f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test184"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)31L, var1, (java.lang.Number)76.42898646301789d);
    java.lang.Number var4 = var3.getHi();
    java.lang.Number var5 = var3.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 76.42898646301789d+ "'", var4.equals(76.42898646301789d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test185"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(0.9999999f, 50.000015f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9999999f);

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test186"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil((-7.707739625128683E41d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-7.707739625128683E41d));

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test187"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var2.setContractionCriteria(50.000008f);
    var2.setExpansionMode(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.discardFrontElements(2870);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test188"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)2.622236500484369d);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test189"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(12192000, 12827000);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 25019000);

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test190"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(0.46413974520156737d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-2.1520997728497173d));

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test191"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(2.1077142824428754d, (-3.173462429162327E42d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-3.173462429162327E42d));

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test192"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)3.3170891650425603E43d);

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test193"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    java.lang.String var2 = var1.name();
    java.lang.String var3 = var1.name();
    boolean var5 = var1.equals((java.lang.Object)"bbc76c98706e096cbdb48c11be18b37feafe094ae0e5291b81fe65cbd0c42cc6f465c322de0f5afaf8fdd0237c92d0d9c2d6");
    int var6 = var1.ordinal();
    org.apache.commons.math3.random.RandomGenerator var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = var9.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var12 = var11.getNanStrategy();
    java.lang.String var13 = var12.name();
    java.lang.String var14 = var12.name();
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15);
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    int var18 = var17.ordinal();
    java.lang.String var19 = var17.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12, var17);
    double[] var22 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var23 = new org.apache.commons.math3.util.ResizableDoubleArray(var22);
    var23.setContractionCriteria(50.000008f);
    var23.setExpansionMode(0);
    boolean var28 = var17.equals((java.lang.Object)var23);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var29 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var10, var17);
    org.apache.commons.math3.stat.ranking.NaturalRanking var30 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var17);
    org.apache.commons.math3.stat.ranking.NaturalRanking var31 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "MAXIMAL"+ "'", var2.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "MAXIMAL"+ "'", var3.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "MAXIMAL"+ "'", var13.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "MAXIMAL"+ "'", var14.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "AVERAGE"+ "'", var19.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test194"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double[] var2 = var0.sample(1);
    double var3 = var0.getMean();
    double var4 = var0.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test195"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    var3.reseedRandomGenerator(1L);
    double var7 = var3.cumulativeProbability(0.0d);
    double var9 = var3.probability(6.770911672198755d);
    double var11 = var3.inverseCumulativeProbability(1.0d);
    double var13 = var3.cumulativeProbability(1.1282937610745374d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var16 = var3.cumulativeProbability(0.584554782675576d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.5d);

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test196"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(3.181467854611004d, 0.10898669456022518d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.020853712364473545d);

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test197"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.5075374788683407d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8739440070527092d);

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test198"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(49298L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 49298L);

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test199"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(0.5434235565682811d, 2.5091784786580567d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.5434235565682811d);

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test200"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(0, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test201"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(2951, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2951);

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test202"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(8100, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test203"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)88.72804665106598d);
    java.lang.Number var2 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0+ "'", var2.equals(0));

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test204"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(2.0000005f, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0000005f);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test205"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("a07e9c23292c34d84451fa9479a50ab77e4fabe6089b0903b17b1e3bd281371ed9da375d4283c286747b6f0d0d4137bd76be");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test206"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(5.0f);
    org.apache.commons.math3.random.RandomDataImpl var3 = new org.apache.commons.math3.random.RandomDataImpl();
    boolean var4 = var0.equals((java.lang.Object)var3);
    var0.addElement(Double.NaN);
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var8 = var7.getNanStrategy();
    java.lang.String var9 = var8.name();
    java.lang.String var10 = var8.name();
    org.apache.commons.math3.stat.ranking.NaNStrategy var11 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11);
    org.apache.commons.math3.stat.ranking.TiesStrategy var13 = var12.getTiesStrategy();
    int var14 = var13.ordinal();
    java.lang.String var15 = var13.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8, var13);
    double[] var18 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray(var18);
    var19.setContractionCriteria(50.000008f);
    var19.setExpansionMode(0);
    boolean var24 = var13.equals((java.lang.Object)var19);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var19);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var26 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var28 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var29 = new org.apache.commons.math3.util.ResizableDoubleArray(var28);
    var29.setContractionCriteria(50.000008f);
    double[] var32 = var29.getInternalValues();
    double[] var34 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var35 = new org.apache.commons.math3.util.ResizableDoubleArray(var34);
    var35.setContractionCriteria(50.000008f);
    double[] var38 = var35.getInternalValues();
    double[] var39 = var35.getElements();
    double var40 = var26.mannWhitneyU(var32, var39);
    var0.addElements(var39);
    org.apache.commons.math3.util.ResizableDoubleArray var42 = new org.apache.commons.math3.util.ResizableDoubleArray(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "MAXIMAL"+ "'", var9.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "MAXIMAL"+ "'", var10.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "AVERAGE"+ "'", var15.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.5d);

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test207"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    var3.reseedRandomGenerator(1L);
    boolean var6 = var3.isSupportConnected();
    double var7 = var3.getMean();
    double var8 = var3.sample();
    double var9 = var3.getSupportLowerBound();
    double var10 = var3.sample();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 3.5671315446818194E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1.7552256037579106E43d);

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test208"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(2.30584301E18f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test209() {}
//   public void test209() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test209"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.log((-0.009479769440616246d), 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test210"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(4.9999995f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.7683716E-7f);

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test211"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.5606386275277436d), 3.5671315446818194E43d);
    double var4 = var2.probability(1.0713813143399866d);
    double var5 = var2.getNumericalVariance();
    double var7 = var2.inverseCumulativeProbability(0.383865505085317d);
    double var8 = var2.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.2724427457064103E87d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-1.0535313540516738E43d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.2724427457064103E87d);

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test212"); }


    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.math.BigInteger var4 = null;
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var8 = new org.apache.commons.math3.exception.OutOfRangeException(var2, (java.lang.Number)100.0f, (java.lang.Number)var6, (java.lang.Number)0.5000672346092545d);
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    java.math.BigInteger var11 = null;
    java.math.BigInteger var13 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var15 = new org.apache.commons.math3.exception.OutOfRangeException(var9, (java.lang.Number)100.0f, (java.lang.Number)var13, (java.lang.Number)0.5000672346092545d);
    java.math.BigInteger var16 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, var13);
    java.math.BigInteger var18 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, 31L);
    org.apache.commons.math3.exception.OutOfRangeException var19 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)8.799063409660144E86d, (java.lang.Number)0.99999994f, (java.lang.Number)var6);
    org.apache.commons.math3.exception.util.Localizable var20 = null;
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    org.apache.commons.math3.exception.NotPositiveException var23 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(short)1);
    java.lang.Object[] var24 = new java.lang.Object[] { (short)1};
    org.apache.commons.math3.exception.MathIllegalStateException var25 = new org.apache.commons.math3.exception.MathIllegalStateException(var21, var24);
    org.apache.commons.math3.exception.MathIllegalStateException var26 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var19, var20, var24);
    org.apache.commons.math3.exception.util.ExceptionContext var27 = var19.getContext();
    org.apache.commons.math3.exception.MathInternalError var28 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test213() {}
//   public void test213() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test213"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     double var17 = var0.nextGamma(0.9775852669347048d, 3.199763873047224E14d);
//     var0.reSeed(27900L);
//     double var21 = var0.nextExponential(4.951760157141521E27d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var24 = var0.nextSecureLong(9944796L, 10L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "b5206fbcad9e054fba2a8f5fb7c846cd7a95d83188097eabe19a66e2d51f8e15e2bcfd62f97fa6a7a90582b1599336a7e15c"+ "'", var2.equals("b5206fbcad9e054fba2a8f5fb7c846cd7a95d83188097eabe19a66e2d51f8e15e2bcfd62f97fa6a7a90582b1599336a7e15c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.946100102363309E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 3.584463481490884E14d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 3.695123743844796E27d);
// 
//   }

  public void test214() {}
//   public void test214() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test214"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     boolean var9 = var6.isSupportConnected();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     double var12 = var6.probability(6.0d);
//     double var15 = var6.cumulativeProbability((-2.1317761108019555d), 0.9640275797804917d);
//     double var17 = var6.probability(1.7005629616909042d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "585f043bfe555968862aeb82737829891d9a45dfc23d0ef93592082b3ea2ce75cbb9ba2a0d66a97377960aa2f2e66c615914"+ "'", var2.equals("585f043bfe555968862aeb82737829891d9a45dfc23d0ef93592082b3ea2ce75cbb9ba2a0d66a97377960aa2f2e66c615914"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 2.686101895876746E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 4.594468614421035E-44d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.0d);
// 
//   }

  public void test215() {}
//   public void test215() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test215"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     double var17 = var0.nextUniform(0.5274450245437947d, 0.6040929060689715d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var20 = var0.nextBeta(0.0d, 0.7518132117785729d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "151143ce80d815e7f2108d9e49a12604287fcc4e586af1b34481329ceb8e0f73faeedcd912d21b470a0b6c592fdcde48869e"+ "'", var2.equals("151143ce80d815e7f2108d9e49a12604287fcc4e586af1b34481329ceb8e0f73faeedcd912d21b470a0b6c592fdcde48869e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-1.367391811431284E43d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.5805004924291369d);
// 
//   }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test216"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var2 = var0.addElementRolling(4.629628685877713E42d);
    double[] var4 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    double[] var7 = var6.getElements();
    var0.addElements(var7);
    var0.setNumElements(227);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test217() {}
//   public void test217() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test217"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP((-27.741692681648217d), 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test218"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    org.apache.commons.math3.distribution.NormalDistribution var8 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    var8.reseedRandomGenerator(1L);
    boolean var11 = var8.isSupportConnected();
    double var12 = var8.getMean();
    double var13 = var8.sample();
    double var14 = var8.getSupportUpperBound();
    boolean var15 = var8.isSupportUpperBoundInclusive();
    double[] var17 = var8.sample(10);
    double[] var18 = var3.rank(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 3.5671315446818194E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test219"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(4.791816278040792E86d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.072983782968729d);

  }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test220"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(1.0d, 2.1317761108019555d);
    double var4 = var2.cumulativeProbability((-5.905492376427268E43d));
    boolean var5 = var2.isSupportUpperBoundInclusive();
    double var7 = var2.probability(3.7760951459250447d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test221"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = var2.copy();
    double[] var5 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray(var5);
    double[] var9 = new double[] { 1.0d, 100.0d};
    var6.addElements(var9);
    double[] var11 = var6.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var11);
    int var13 = var12.getExpansionMode();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var3, var12);
    double var16 = var3.substituteMostRecentElement(Double.NEGATIVE_INFINITY);
    int var17 = var3.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test222"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var2.setContractionCriteria(50.000008f);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = var2.copy();
    int var6 = var2.getNumElements();
    var2.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setExpansionMode(12827000);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test223"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    java.lang.String var2 = var1.name();
    java.lang.String var3 = var1.name();
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var5.getTiesStrategy();
    int var7 = var6.ordinal();
    java.lang.String var8 = var6.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var6);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    java.lang.Class var11 = var6.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var13 = java.lang.Enum.<java.lang.Enum>valueOf(var11, "ef5bb6f08632c0d7800279a7ad9c064f3a35ae8083d2e8205f4d078caff83380f83cd152f7f27a5a3296fbf1abbfbd6c64ad37b60eed3adf55dff20ebf0c410");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "MAXIMAL"+ "'", var2.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "MAXIMAL"+ "'", var3.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test224"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    java.lang.String var2 = var1.name();
    java.lang.String var3 = var1.name();
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var5.getTiesStrategy();
    int var7 = var6.ordinal();
    java.lang.String var8 = var6.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var6);
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = var11.getTiesStrategy();
    int var13 = var12.ordinal();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var14 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var12);
    java.lang.String var15 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "MAXIMAL"+ "'", var2.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "MAXIMAL"+ "'", var3.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "MAXIMAL"+ "'", var15.equals("MAXIMAL"));

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test225"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(2.5000002f, 9.999999f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.5000002f);

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test226"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(100.5f, 102248832);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.POSITIVE_INFINITY);

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test227"); }


    double var1 = org.apache.commons.math3.special.Gamma.logGamma(0.46795008060179255d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6379266394342542d);

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test228"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(1.9999999958199324d, (-100.33831575436781d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6.239608407802531E-31d);

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test229"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(0.6945971187784026d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 39.7974833679496d);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test230"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)2432902008176640001L, (java.lang.Number)0.8882849706472548d, false);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test231"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var2.setContractionCriteria(50.000008f);
    var2.setExpansionMode(0);
    double[] var8 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
    double[] var12 = new double[] { 1.0d, 100.0d};
    var9.addElements(var12);
    float var14 = var9.getContractionCriteria();
    boolean var15 = var2.equals((java.lang.Object)var14);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.discardMostRecentElements(3);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test232"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(100.0f, 0.051884571948430845d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 99.99999f);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test233"); }


    double[] var0 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    float var2 = var1.getExpansionFactor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setExpansionFactor(0.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0f);

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test234"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var2 = var0.addElementRolling(4.629628685877713E42d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setExpansionMode(127000);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test235() {}
//   public void test235() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test235"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     java.lang.String var4 = var0.nextHexString(110);
//     double var6 = var0.nextChiSquare(0.9865330122406505d);
//     var0.reSeedSecure(28798L);
//     org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var12.reseedRandomGenerator(1L);
//     boolean var15 = var12.isSupportConnected();
//     double var16 = var12.getMean();
//     double var17 = var12.sample();
//     double var18 = var12.getSupportUpperBound();
//     boolean var19 = var12.isSupportUpperBoundInclusive();
//     double var20 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var12);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("aa3a2882bd6ec0869eac67225294b684b312d05a161db790b95d9bb088b0b995a0deecf1ac7ea02b837d8205c4449fa1c44d", "5686f275942bfb4ef42afc1dd53bfb09c9a33dcaafddc78f8f20fb0b9b6416a528ea2acfdc445aed74bb1b763ea79d57a668");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.6080010072956461d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "b57f42f3dc4712348f3035dd2462ca5175a1f5bbb1535db2992c45e52998d4e7b23276fa89517a2a746adf71ba9308f78e9c29fc496801"+ "'", var4.equals("b57f42f3dc4712348f3035dd2462ca5175a1f5bbb1535db2992c45e52998d4e7b23276fa89517a2a746adf71ba9308f78e9c29fc496801"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.7582157056474286d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 3.5671315446818194E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == (-2.4638325943133644E43d));
// 
//   }

  public void test236() {}
//   public void test236() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test236"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     double var16 = var0.nextWeibull(1.0d, 1.6298598478788293d);
//     double var19 = var0.nextCauchy((-1.1440883267692863E33d), 3.3030345912774096E43d);
//     double var22 = var0.nextBeta(0.46413974520156737d, 1.8850185598529162E86d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "a0ac77e6c5f63769d52136283b4cdcf4382a49aa0f93ecc342e02a35ff95bdce52aef1bcd8e019eacf18df301887e0fcb4ea"+ "'", var2.equals("a0ac77e6c5f63769d52136283b4cdcf4382a49aa0f93ecc342e02a35ff95bdce52aef1bcd8e019eacf18df301887e0fcb4ea"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-2.4509435857990157E43d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1.2444311290650028d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-3.766937272570637E43d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0.0d);
// 
//   }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test237"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(100.5f, 2.30584301E18f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100.5f);

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test238"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double var4 = var2.substituteMostRecentElement(1.0159453334112069E43d);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var5 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var7 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    var8.setContractionCriteria(50.000008f);
    double[] var11 = var8.getInternalValues();
    double[] var13 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var13);
    var14.setContractionCriteria(50.000008f);
    double[] var17 = var14.getInternalValues();
    double[] var18 = var14.getElements();
    double var19 = var5.mannWhitneyUTest(var11, var18);
    org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray(var18);
    var2.addElements(var18);
    int var22 = var2.getExpansionMode();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var23 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var25 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var26 = new org.apache.commons.math3.util.ResizableDoubleArray(var25);
    var26.setContractionCriteria(50.000008f);
    double[] var29 = var26.getInternalValues();
    double[] var31 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var32 = new org.apache.commons.math3.util.ResizableDoubleArray(var31);
    var32.setContractionCriteria(50.000008f);
    double[] var35 = var32.getInternalValues();
    double[] var36 = var32.getElements();
    double var37 = var23.mannWhitneyU(var29, var36);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var38 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var40 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var41 = new org.apache.commons.math3.util.ResizableDoubleArray(var40);
    var41.setContractionCriteria(50.000008f);
    double[] var44 = var41.getInternalValues();
    double[] var46 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var47 = new org.apache.commons.math3.util.ResizableDoubleArray(var46);
    var47.setContractionCriteria(50.000008f);
    double[] var50 = var47.getInternalValues();
    double[] var51 = var47.getElements();
    double var52 = var38.mannWhitneyU(var44, var51);
    org.apache.commons.math3.util.ResizableDoubleArray var53 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var53.addElement(0.02797455810085192d);
    var53.discardFrontElements(1);
    org.apache.commons.math3.util.ResizableDoubleArray var58 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var59 = var58.getInternalValues();
    var53.addElements(var59);
    double var61 = var23.mannWhitneyUTest(var44, var59);
    boolean var62 = var2.equals((java.lang.Object)var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 0.10247043485974927d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test239"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(2, 102400.0f);

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test240"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    java.lang.String var2 = var1.name();
    java.lang.String var3 = var1.name();
    org.apache.commons.math3.random.RandomGenerator var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var4);
    org.apache.commons.math3.random.RandomGenerator var6 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "MAXIMAL"+ "'", var2.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "MAXIMAL"+ "'", var3.equals("MAXIMAL"));

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test241"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)0.9732473842406116d);

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test242"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0.5d);
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var1.getContext();
    org.apache.commons.math3.exception.MathInternalError var3 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test243"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(-0.8813735870195429d));
    java.lang.Number var3 = var2.getArgument();
    boolean var4 = var2.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + (-0.8813735870195429d)+ "'", var3.equals((-0.8813735870195429d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test244"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    java.lang.String var2 = var1.toString();
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.NotPositiveException var5 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(short)1);
    java.lang.Object[] var6 = new java.lang.Object[] { (short)1};
    org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException(var3, var6);
    boolean var8 = var1.equals((java.lang.Object)var3);
    org.apache.commons.math3.random.RandomGenerator var9 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var9);
    java.lang.String var11 = var1.name();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "MAXIMAL"+ "'", var2.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "MAXIMAL"+ "'", var11.equals("MAXIMAL"));

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test245"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog(90);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 318.15263962020936d);

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test246"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var2.setContractionCriteria(5.0f);
    var2.setElement(110, Double.NaN);
    var2.setElement(100, (-0.6120891811851691d));
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var2);
    int var12 = var0.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test247"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(1.2982587902415216E14d, 1.231628095073697d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.2982587902415216E14d);

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test248"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(288, 1048576);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 288);

  }

  public void test249() {}
//   public void test249() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test249"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log1p((-2.3251745304976303d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test250"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var2.setContractionCriteria(50.000008f);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = var2.copy();
    var2.setNumElements(2);
    var2.addElement(1.1972693843357008E86d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test251"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(1.2444311290650028d, 2.959565980661239E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.959565980661239E43d);

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test252"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(42L, (-3941415383162945436L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3941415383162945436L);

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test253"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble(2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0d);

  }

  public void test254() {}
//   public void test254() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test254"); }
// 
// 
//     double var1 = org.apache.commons.math3.special.Gamma.digamma((-5.479216675175599E43d));
// 
//   }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test255"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = var2.copy();
    double[] var5 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray(var5);
    double[] var9 = new double[] { 1.0d, 100.0d};
    var6.addElements(var9);
    double[] var11 = var6.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var11);
    int var13 = var12.getExpansionMode();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var3, var12);
    double var16 = var3.substituteMostRecentElement(Double.NEGATIVE_INFINITY);
    org.apache.commons.math3.util.ResizableDoubleArray var17 = var3.copy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test256() {}
//   public void test256() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test256"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     double var4 = var0.nextExponential(0.056182176564052d);
//     var0.reSeedSecure();
//     double var9 = var0.nextUniform(0.056182176564052d, 3.181467854611004d, true);
//     int[] var12 = var0.nextPermutation(12700, 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "ea54313b4182ac96f658accbbf2feceff4a671235f51b3d967fc394ec5dd8e14a99ae47e72756e53eebed3f01204a63cbfeb"+ "'", var2.equals("ea54313b4182ac96f658accbbf2feceff4a671235f51b3d967fc394ec5dd8e14a99ae47e72756e53eebed3f01204a63cbfeb"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.05656261219375315d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.07839344951566077d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
// 
//   }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test257"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(7.353300445964135E86d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.353300445964136E86d);

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test258"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(17, 88);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test259"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)17L, (java.lang.Number)3.181467854611004d, (java.lang.Number)7.381472028861085E-11d);

  }

  public void test260() {}
//   public void test260() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test260"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     java.lang.String var4 = var0.nextHexString(110);
//     double var7 = var0.nextGamma(0.9999999999999971d, 1.151569395337692d);
//     double var9 = var0.nextT(1.2982587902415216E14d);
//     var0.reSeedSecure(0L);
//     int var14 = var0.nextSecureInt(21792, 2147483647);
//     org.apache.commons.math3.distribution.NormalDistribution var17 = new org.apache.commons.math3.distribution.NormalDistribution(Double.POSITIVE_INFINITY, 4.111122573849115E13d);
//     double var19 = var17.probability(0.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var20 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var17);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 3.1585611386090657d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "443be2c9465b53a67d10cead322813cd901aa1759375edf3c36d6d3e4fb6d464bb7fec2d38f97df1bf8f4a9a0c6cf5211ef2b657acf194"+ "'", var4.equals("443be2c9465b53a67d10cead322813cd901aa1759375edf3c36d6d3e4fb6d464bb7fec2d38f97df1bf8f4a9a0c6cf5211ef2b657acf194"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2.469183096783427d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-0.44194173889768307d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 2075284194);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.0d);
// 
//   }

  public void test261() {}
//   public void test261() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test261"); }
// 
// 
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     double[] var2 = new double[] { 1.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
//     var3.setContractionCriteria(50.000008f);
//     double[] var6 = var3.getInternalValues();
//     double[] var8 = new double[] { 1.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
//     var9.setContractionCriteria(50.000008f);
//     double[] var12 = var9.getInternalValues();
//     double[] var13 = var9.getElements();
//     double var14 = var0.mannWhitneyUTest(var6, var13);
//     org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var13);
//     float var16 = var15.getContractionCriteria();
//     org.apache.commons.math3.random.RandomDataImpl var17 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var19 = var17.nextSecureHexString(100);
//     double var21 = var17.nextExponential(0.056182176564052d);
//     var17.reSeedSecure();
//     boolean var23 = var15.equals((java.lang.Object)var17);
//     org.apache.commons.math3.util.ResizableDoubleArray var24 = var15.copy();
//     var15.setContractionCriteria(2560.0f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 2.5f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var19 + "' != '" + "4be0ed66bfdc6c51d660f8511a9b0908fb03c512d464058d7231b6a17405e01db04cc6f135c1b0210c3cae9c3d4ade9a9a2f"+ "'", var19.equals("4be0ed66bfdc6c51d660f8511a9b0908fb03c512d464058d7231b6a17405e01db04cc6f135c1b0210c3cae9c3d4ade9a9a2f"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1.6385692476926722E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
// 
//   }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test262"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var2.setContractionCriteria(50.000008f);
    double[] var5 = var2.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    int var7 = var2.start();
    var2.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test263"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(27.386710845917314d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 27L);

  }

  public void test264() {}
//   public void test264() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test264"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     double var5 = var0.nextGaussian(0.0d, 0.5d);
//     var0.reSeed(10L);
//     double var10 = var0.nextF(1.3872175661331396d, 2.636818730233018d);
//     var0.reSeedSecure();
//     double var14 = var0.nextGaussian(0.0d, 10.0d);
//     var0.reSeedSecure(0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.580253128293357d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-0.919898919507881d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5088599843857857d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 11.672233456208478d);
// 
//   }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test265"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var2.setContractionCriteria(50.000008f);
    var2.contract();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test266"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(2);
    var1.addElement(68397.35544481203d);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    int var5 = var1.getNumElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test267"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test268() {}
//   public void test268() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test268"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     double var16 = var0.nextWeibull(1.0d, 1.6298598478788293d);
//     double var19 = var0.nextWeibull(1.151569395337692d, 7.22597376812575E86d);
//     var0.reSeedSecure();
//     var0.reSeedSecure(0L);
//     double var24 = var0.nextChiSquare(0.9640275797804917d);
//     int var27 = var0.nextBinomial(1612820, 0.8882849706472548d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "5364b16f426f6a53babe7bae92a5efd0dcd9a80214799d3c68831cac575eaf9bb1b41398d0402973be358c7c2b5b45eb15c2"+ "'", var2.equals("5364b16f426f6a53babe7bae92a5efd0dcd9a80214799d3c68831cac575eaf9bb1b41398d0402973be358c7c2b5b45eb15c2"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-3.879737992297923E43d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.6898364755844348d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1.7429222192408544E87d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1.7964601481377767d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1431966);
// 
//   }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test269"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    java.lang.String var2 = var1.name();
    java.lang.String var3 = var1.toString();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var5.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var8 = var7.getNanStrategy();
    java.lang.String var9 = var8.name();
    java.lang.String var10 = var8.name();
    org.apache.commons.math3.stat.ranking.NaNStrategy var11 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11);
    org.apache.commons.math3.stat.ranking.TiesStrategy var13 = var12.getTiesStrategy();
    int var14 = var13.ordinal();
    java.lang.String var15 = var13.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8, var13);
    double[] var18 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray(var18);
    var19.setContractionCriteria(50.000008f);
    var19.setExpansionMode(0);
    boolean var24 = var13.equals((java.lang.Object)var19);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var25 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var6, var13);
    org.apache.commons.math3.stat.ranking.NaturalRanking var26 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var13);
    org.apache.commons.math3.stat.ranking.NaturalRanking var27 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var13);
    java.lang.Class var28 = var13.getDeclaringClass();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "MAXIMAL"+ "'", var2.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "MAXIMAL"+ "'", var3.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "MAXIMAL"+ "'", var9.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "MAXIMAL"+ "'", var10.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "AVERAGE"+ "'", var15.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test270"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)5.574834946764142E86d);

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test271"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    var0.reSeed();

  }

  public void test272() {}
//   public void test272() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test272"); }
// 
// 
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     double[] var2 = new double[] { 1.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
//     var3.setContractionCriteria(50.000008f);
//     double[] var6 = var3.getInternalValues();
//     double[] var8 = new double[] { 1.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
//     var9.setContractionCriteria(50.000008f);
//     double[] var12 = var9.getInternalValues();
//     double[] var13 = var9.getElements();
//     double var14 = var0.mannWhitneyUTest(var6, var13);
//     org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var13);
//     float var16 = var15.getContractionCriteria();
//     org.apache.commons.math3.random.RandomDataImpl var17 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var19 = var17.nextSecureHexString(100);
//     double var21 = var17.nextExponential(0.056182176564052d);
//     var17.reSeedSecure();
//     boolean var23 = var15.equals((java.lang.Object)var17);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var26 = var17.nextF((-1.3042834595792821E43d), 0.2309697915176785d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 2.5f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var19 + "' != '" + "1702e31f05a5ecc2002887942b68f79a29d9233b74a6956e96d878efa08c39dd17a8d65c3afeda9b0696e11550aff704dff1"+ "'", var19.equals("1702e31f05a5ecc2002887942b68f79a29d9233b74a6956e96d878efa08c39dd17a8d65c3afeda9b0696e11550aff704dff1"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.03901258344117826d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == false);
// 
//   }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test273"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-2.1850350060982735d), var2, false);

  }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test274"); }


    double var2 = org.apache.commons.math3.util.FastMath.min((-0.7949577687638787d), (-0.9300733860920883d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.9300733860920883d));

  }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test275"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(1.1597528820798812E14d, 2.2161543004921728E14d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.1597528820798812E14d);

  }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test276"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double var4 = var2.substituteMostRecentElement(1.0159453334112069E43d);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var5 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var7 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    var8.setContractionCriteria(50.000008f);
    double[] var11 = var8.getInternalValues();
    double[] var13 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var13);
    var14.setContractionCriteria(50.000008f);
    double[] var17 = var14.getInternalValues();
    double[] var18 = var14.getElements();
    double var19 = var5.mannWhitneyUTest(var11, var18);
    org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray(var18);
    var2.addElements(var18);
    int var22 = var2.getNumElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 2);

  }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test277"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    var3.reseedRandomGenerator(1L);
    double var7 = var3.probability(0.0d);
    double var9 = var3.probability(1.432080595809531E43d);
    boolean var10 = var3.isSupportLowerBoundInclusive();
    double var11 = var3.sample();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 3.5671315446818194E43d);

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test278"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(0, 61);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test279"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.math.BigInteger var2 = null;
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var6 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)100.0f, (java.lang.Number)var4, (java.lang.Number)0.5000672346092545d);
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    java.math.BigInteger var9 = null;
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var13 = new org.apache.commons.math3.exception.OutOfRangeException(var7, (java.lang.Number)100.0f, (java.lang.Number)var11, (java.lang.Number)0.5000672346092545d);
    java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, var11);
    java.math.BigInteger var16 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 31L);
    java.math.BigInteger var18 = org.apache.commons.math3.util.ArithmeticUtils.pow(var16, 20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test280"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(0.5397465212455828d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5990851178057973d);

  }

//  public void test281() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest3.test281"); }
//
//
//    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution((-0.3781696985345623d), 200.0d, 3.072433293358163E86d);
//    // The following exception was thrown during execution.
//    // This behavior will recorded for regression testing.
//    try {
//      double[] var5 = var3.sample(229345007);
//      fail("Expected exception of type java.lang.OutOfMemoryError");
//    } catch (java.lang.OutOfMemoryError e) {
//      // Expected exception.
//    }
//
//  }
//
  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test282"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)4851079.098769953d, (java.lang.Number)83, true);

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test283"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(0.9500268869550641d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8209031109473406d);

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test284"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var3.getElements();
    var3.clear();
    var3.contract();
    var3.addElement((-5.329951075180856E43d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test285"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(0, 2432902008176640000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test286"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = var2.copy();
    double[] var5 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray(var5);
    double[] var9 = new double[] { 1.0d, 100.0d};
    var6.addElements(var9);
    double[] var11 = var6.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var11);
    int var13 = var12.getExpansionMode();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var3, var12);
    double var16 = var3.substituteMostRecentElement(Double.NEGATIVE_INFINITY);
    int var17 = var3.getExpansionMode();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);

  }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test287"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)100.0d, (java.lang.Number)1.432080595809531E43d, (java.lang.Number)1.4210854715202004E-14d);
    java.lang.Number var4 = var3.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 1.432080595809531E43d+ "'", var4.equals(1.432080595809531E43d));

  }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test288"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog(88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 309.16419358014696d);

  }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test289"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(27000L, 40L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test290"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(5.072983782968729d, 0.8508952569561938d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9983956055111356d);

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test291"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    var3.reseedRandomGenerator(1L);
    double var7 = var3.probability(0.0d);
    double var8 = var3.getMean();
    double var10 = var3.density(1.8622531212727638d);
    double var13 = var3.cumulativeProbability(0.0d, 0.0d);
    var3.reseedRandomGenerator(1134L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1.4840955931403377E-44d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);

  }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test292"); }


    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.math.BigInteger var5 = null;
    java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var9 = new org.apache.commons.math3.exception.OutOfRangeException(var3, (java.lang.Number)100.0f, (java.lang.Number)var7, (java.lang.Number)0.5000672346092545d);
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    java.math.BigInteger var12 = null;
    java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var16 = new org.apache.commons.math3.exception.OutOfRangeException(var10, (java.lang.Number)100.0f, (java.lang.Number)var14, (java.lang.Number)0.5000672346092545d);
    java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, var14);
    java.math.BigInteger var19 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, 10L);
    org.apache.commons.math3.exception.NotStrictlyPositiveException var20 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var2, (java.lang.Number)var19);
    org.apache.commons.math3.exception.util.Localizable var23 = null;
    java.math.BigInteger var25 = null;
    java.math.BigInteger var27 = org.apache.commons.math3.util.ArithmeticUtils.pow(var25, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var29 = new org.apache.commons.math3.exception.OutOfRangeException(var23, (java.lang.Number)100.0f, (java.lang.Number)var27, (java.lang.Number)0.5000672346092545d);
    org.apache.commons.math3.exception.util.Localizable var30 = null;
    java.math.BigInteger var32 = null;
    java.math.BigInteger var34 = org.apache.commons.math3.util.ArithmeticUtils.pow(var32, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var36 = new org.apache.commons.math3.exception.OutOfRangeException(var30, (java.lang.Number)100.0f, (java.lang.Number)var34, (java.lang.Number)0.5000672346092545d);
    java.math.BigInteger var37 = org.apache.commons.math3.util.ArithmeticUtils.pow(var27, var34);
    java.math.BigInteger var39 = org.apache.commons.math3.util.ArithmeticUtils.pow(var27, 31L);
    org.apache.commons.math3.exception.OutOfRangeException var40 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)8.799063409660144E86d, (java.lang.Number)0.99999994f, (java.lang.Number)var27);
    java.math.BigInteger var41 = org.apache.commons.math3.util.ArithmeticUtils.pow(var19, var27);
    java.math.BigInteger var43 = org.apache.commons.math3.util.ArithmeticUtils.pow(var27, 48436L);
    org.apache.commons.math3.exception.OutOfRangeException var44 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)1.8031769674261714E43d, (java.lang.Number)(-5129524049062756352L), (java.lang.Number)48436L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);

  }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test293"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test294() {}
//   public void test294() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test294"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     double var4 = var0.nextExponential(0.056182176564052d);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var7 = var0.nextPoisson((-4.9E-324d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "ed86540b0090ef7c5f1221011b60147439af2024746c76e85e153f680cedb9466451c628edca06cd4bff3394f4ae0a21476b"+ "'", var2.equals("ed86540b0090ef7c5f1221011b60147439af2024746c76e85e153f680cedb9466451c628edca06cd4bff3394f4ae0a21476b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.054493400542466874d);
// 
//   }

  public void test295() {}
//   public void test295() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test295"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(16.5699685764709d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test296"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt((-8.942315757770787E-8d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.004471809905857561d));

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test297"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient((-1820841394), 1820841484);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test298"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    var3.reseedRandomGenerator(1L);
    boolean var6 = var3.isSupportConnected();
    double var7 = var3.getMean();
    double var10 = var3.cumulativeProbability(0.0d, 1.6298598478788293d);
    double var11 = var3.getStandardDeviation();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 2.4188678176733584E-44d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2.6881171418161356E43d);

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test299"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)2068);

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test300"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.46795008060179255d, 5.889838469655482E86d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5.889838469655482E86d);

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test301"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble(66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.443449390774456E92d);

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test302"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(4.6310740263131307E86d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.6310740263131307E86d);

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test303"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)0.0078125d, var2, false);

  }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test304"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(645781746, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test305"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(1.0912873587286057E-45d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test306"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    var1.reSeed((-5129524049062756352L));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var6 = var1.nextSecureLong(90000L, 540L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test307"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(70, (-122));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4270);

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test308"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(2.9681911862806774E-44d, 986.0897904647248d, 0.0d, 44);
      fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException");
    } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
      // Expected exception.
    }

  }

  public void test309() {}
//   public void test309() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test309"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     double var4 = var0.nextExponential(0.056182176564052d);
//     double var7 = var0.nextGaussian(0.14423894632267276d, 0.0078125d);
//     double var10 = var0.nextGamma(0.10898669456022518d, 1.9586146923852683d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "c6ccc717de0a21e2e4470af9f9420df886973a77dc96da6bc3837be882d0bb5f5076762da4efa3d227c343ae5628fe696ee8"+ "'", var2.equals("c6ccc717de0a21e2e4470af9f9420df886973a77dc96da6bc3837be882d0bb5f5076762da4efa3d227c343ae5628fe696ee8"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.12103050919847745d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.14473363781667506d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 3.456281063036932E-4d);
// 
//   }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test310"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(5.957132015917886E42d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0397156765373438E41d);

  }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test311"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(4270, 50.00001f, (-0.99999994f));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test312"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var5.getTiesStrategy();
    int var7 = var6.ordinal();
    java.lang.String var8 = var6.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var6);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var11 = var10.getNanStrategy();
    java.lang.String var12 = var11.name();
    java.lang.String var13 = var11.name();
    boolean var15 = var11.equals((java.lang.Object)"bbc76c98706e096cbdb48c11be18b37feafe094ae0e5291b81fe65cbd0c42cc6f465c322de0f5afaf8fdd0237c92d0d9c2d6");
    boolean var16 = var1.equals((java.lang.Object)var11);
    java.lang.String var17 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "MAXIMAL"+ "'", var12.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "MAXIMAL"+ "'", var13.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + "MAXIMAL"+ "'", var17.equals("MAXIMAL"));

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test313"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(1.7802921927502E35d, 0.5474978282396834d, 1.684024197549089d, 2560);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);

  }

  public void test314() {}
//   public void test314() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test314"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.08949018759546412d, 1.8246532949072747d, (-6.715388288934036E43d));
//     double var4 = var3.sample();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-1.735209471803884d));
// 
//   }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test315"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(short)0, (java.lang.Number)10, false);
    boolean var4 = var3.getBoundIsAllowed();
    org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test316"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(102400.016f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 102400.02f);

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test317"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(3.199763873047224E14d, 1.8246532949072747d);
    var2.reseedRandomGenerator(0L);
    double var6 = var2.density(1.5804317627621424E42d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);

  }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test318"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(12192000, 127000);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test319() {}
//   public void test319() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test319"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     double var17 = var0.nextGamma(0.9775852669347048d, 3.199763873047224E14d);
//     var0.reSeed(27900L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var22 = var0.nextPermutation((-22), 229345007);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "b37daa655d9c0764187ad92d248851627d77b68343a9d5444471eeff98de2ba6bb2a351176b0e626352f835dc5f548b2ff81"+ "'", var2.equals("b37daa655d9c0764187ad92d248851627d77b68343a9d5444471eeff98de2ba6bb2a351176b0e626352f835dc5f548b2ff81"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-2.9104004038323886E43d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 5.840805390396113E13d);
// 
//   }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test320"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(2.5000002f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3);

  }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test321"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)1.3418720970618036E43d, (java.lang.Number)5.0f, true);
    java.lang.Number var5 = var4.getMax();
    java.lang.Throwable[] var6 = var4.getSuppressed();
    org.apache.commons.math3.exception.MathArithmeticException var7 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 5.0f+ "'", var5.equals(5.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test322"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    java.lang.String var2 = var1.name();
    java.lang.String var3 = var1.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = var4.getNanStrategy();
    java.lang.String var6 = var5.name();
    java.lang.String var7 = var5.name();
    org.apache.commons.math3.stat.ranking.NaNStrategy var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8);
    org.apache.commons.math3.stat.ranking.TiesStrategy var10 = var9.getTiesStrategy();
    int var11 = var10.ordinal();
    java.lang.String var12 = var10.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5, var10);
    double[] var15 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray(var15);
    var16.setContractionCriteria(50.000008f);
    var16.setExpansionMode(0);
    boolean var21 = var10.equals((java.lang.Object)var16);
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var10);
    java.lang.Class var23 = var1.getDeclaringClass();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "MAXIMAL"+ "'", var2.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "MAXIMAL"+ "'", var3.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "MAXIMAL"+ "'", var6.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "MAXIMAL"+ "'", var7.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "AVERAGE"+ "'", var12.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test323() {}
//   public void test323() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test323"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     double var16 = var0.nextWeibull(1.0d, 1.6298598478788293d);
//     double var19 = var0.nextCauchy((-1.1440883267692863E33d), 3.3030345912774096E43d);
//     double var22 = var0.nextUniform(335.0334109186577d, 7.22597376812575E86d);
//     long var25 = var0.nextSecureLong(34L, 5144L);
//     var0.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "2ce9b6ae684dd28bb4ba0787af97e24b791d27727d7d57cabbbfe5ae89c10119aab07f04ace600463b63267a56bb616bef1e"+ "'", var2.equals("2ce9b6ae684dd28bb4ba0787af97e24b791d27727d7d57cabbbfe5ae89c10119aab07f04ace600463b63267a56bb616bef1e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-4.839774317206307E43d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 2.225470140808926d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 7.759158747274979E42d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 3.36006510980552E86d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1313L);
// 
//   }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test324"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = var3.copy();
    double var6 = var3.addElementRolling(0.3088209685048367d);
    int var7 = var3.getNumElements();
    var3.addElement(1.4640953062334716d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test325"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Number var4 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var5 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var3, var4);
    org.apache.commons.math3.exception.util.ExceptionContext var6 = var5.getContext();
    java.lang.Throwable[] var7 = var5.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var8 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MaxCountExceededException var9 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)1.7005629616909042d, (java.lang.Object[])var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test326"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(1.7802921927502E35d, 4.9E-324d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.7802921927502E35d);

  }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test327"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    java.lang.String var2 = var1.name();
    java.lang.String var3 = var1.name();
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var5.getTiesStrategy();
    int var7 = var6.ordinal();
    java.lang.String var8 = var6.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var6);
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = var11.getTiesStrategy();
    int var13 = var12.ordinal();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var14 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var12);
    double[] var16 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var17 = new org.apache.commons.math3.util.ResizableDoubleArray(var16);
    var17.setContractionCriteria(50.000008f);
    double[] var20 = var17.getInternalValues();
    double[] var21 = var17.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var22 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var22.addElement(0.02797455810085192d);
    var22.discardFrontElements(1);
    org.apache.commons.math3.util.ResizableDoubleArray var27 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var28 = var27.getInternalValues();
    var22.addElements(var28);
    double var30 = var14.mannWhitneyUTest(var21, var28);
    org.apache.commons.math3.util.ResizableDoubleArray var31 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var31.addElement(0.02797455810085192d);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var34 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var36 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var37 = new org.apache.commons.math3.util.ResizableDoubleArray(var36);
    var37.setContractionCriteria(50.000008f);
    double[] var40 = var37.getInternalValues();
    double[] var42 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var43 = new org.apache.commons.math3.util.ResizableDoubleArray(var42);
    var43.setContractionCriteria(50.000008f);
    double[] var46 = var43.getInternalValues();
    double[] var47 = var43.getElements();
    double var48 = var34.mannWhitneyU(var40, var47);
    var31.addElements(var40);
    org.apache.commons.math3.stat.ranking.NaturalRanking var50 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var51 = var50.getNanStrategy();
    java.lang.String var52 = var51.name();
    java.lang.String var53 = var51.name();
    org.apache.commons.math3.stat.ranking.NaNStrategy var54 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var55 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var54);
    org.apache.commons.math3.stat.ranking.TiesStrategy var56 = var55.getTiesStrategy();
    int var57 = var56.ordinal();
    java.lang.String var58 = var56.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var59 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var51, var56);
    org.apache.commons.math3.stat.ranking.NaNStrategy var60 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var61 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var60);
    org.apache.commons.math3.stat.ranking.TiesStrategy var62 = var61.getTiesStrategy();
    int var63 = var62.ordinal();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var64 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var51, var62);
    double[] var66 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var67 = new org.apache.commons.math3.util.ResizableDoubleArray(var66);
    var67.setContractionCriteria(50.000008f);
    double[] var70 = var67.getInternalValues();
    double[] var71 = var67.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var72 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var72.addElement(0.02797455810085192d);
    var72.discardFrontElements(1);
    org.apache.commons.math3.util.ResizableDoubleArray var77 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var78 = var77.getInternalValues();
    var72.addElements(var78);
    double var80 = var64.mannWhitneyUTest(var71, var78);
    double var81 = var14.mannWhitneyU(var40, var71);
    double[] var82 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var87 = new org.apache.commons.math3.util.ResizableDoubleArray(2, 10.0f, 10.0f, 1);
    org.apache.commons.math3.util.ResizableDoubleArray var88 = new org.apache.commons.math3.util.ResizableDoubleArray(var87);
    org.apache.commons.math3.util.ResizableDoubleArray var89 = var87.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var90 = var87.copy();
    double[] var92 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var93 = new org.apache.commons.math3.util.ResizableDoubleArray(var92);
    double[] var96 = new double[] { 1.0d, 100.0d};
    var93.addElements(var96);
    var90.addElements(var96);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var99 = var14.mannWhitneyU(var82, var96);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "MAXIMAL"+ "'", var2.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "MAXIMAL"+ "'", var3.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.10247043485974927d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var52 + "' != '" + "MAXIMAL"+ "'", var52.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var53 + "' != '" + "MAXIMAL"+ "'", var53.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var58 + "' != '" + "AVERAGE"+ "'", var58.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == 0.10247043485974927d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var96);

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test328"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(0.29133893113058534d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-3.6114882783346047d));

  }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test329"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(10, 50.0f);
    var3.setElement(12700, 1.0806511876345213E86d);
    org.apache.commons.math3.distribution.NormalDistribution var7 = new org.apache.commons.math3.distribution.NormalDistribution();
    boolean var8 = var7.isSupportUpperBoundInclusive();
    boolean var9 = var7.isSupportLowerBoundInclusive();
    double var10 = var7.getMean();
    double[] var12 = var7.sample(110);
    var3.addElements(var12);
    double[] var14 = var0.rank(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test330"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(1.1965196338861661d, 0.46795008060179255d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.1965196338861661d);

  }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test331"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    var3.reseedRandomGenerator(1L);
    boolean var6 = var3.isSupportConnected();
    double var7 = var3.getMean();
    double var8 = var3.sample();
    double var9 = var3.getSupportLowerBound();
    double var11 = var3.inverseCumulativeProbability(2.3977699460038757E-44d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 3.5671315446818194E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-8.679894338181829E64d));

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test332"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(10, 50.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = var2.substituteMostRecentElement(0.021068746917469138d);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException");
    } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
      // Expected exception.
    }

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test333"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter((-2.4509435857990157E43d), 126.32054207990153d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-2.450943585799015E43d));

  }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test334"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(3.181467854611004d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6.8185608967289556E-6d);

  }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test335"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-92L), (-100));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test336() {}
//   public void test336() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test336"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.259921049017114d, 31.402066659134473d, 0.0d);
//     double var4 = var3.getNumericalMean();
//     double var5 = var3.sample();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.259921049017114d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-0.810721850987725d));
// 
//   }

  public void test337() {}
//   public void test337() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test337"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     org.apache.commons.math3.exception.util.Localizable var3 = null;
//     java.math.BigInteger var5 = null;
//     java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 0L);
//     org.apache.commons.math3.exception.OutOfRangeException var9 = new org.apache.commons.math3.exception.OutOfRangeException(var3, (java.lang.Number)100.0f, (java.lang.Number)var7, (java.lang.Number)0.5000672346092545d);
//     org.apache.commons.math3.exception.util.Localizable var10 = null;
//     java.math.BigInteger var12 = null;
//     java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, 0L);
//     org.apache.commons.math3.exception.OutOfRangeException var16 = new org.apache.commons.math3.exception.OutOfRangeException(var10, (java.lang.Number)100.0f, (java.lang.Number)var14, (java.lang.Number)0.5000672346092545d);
//     java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, var14);
//     org.apache.commons.math3.exception.util.Localizable var18 = null;
//     java.lang.Object[] var21 = new java.lang.Object[] { '4'};
//     org.apache.commons.math3.exception.MaxCountExceededException var22 = new org.apache.commons.math3.exception.MaxCountExceededException(var18, (java.lang.Number)Double.NaN, var21);
//     java.lang.Throwable[] var23 = var22.getSuppressed();
//     org.apache.commons.math3.exception.MaxCountExceededException var24 = new org.apache.commons.math3.exception.MaxCountExceededException(var2, (java.lang.Number)var7, (java.lang.Object[])var23);
//     org.apache.commons.math3.exception.MaxCountExceededException var25 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)var7);
//     org.apache.commons.math3.exception.util.Localizable var26 = null;
//     java.lang.Object[] var29 = new java.lang.Object[] { '4'};
//     org.apache.commons.math3.exception.MaxCountExceededException var30 = new org.apache.commons.math3.exception.MaxCountExceededException(var26, (java.lang.Number)Double.NaN, var29);
//     java.lang.Throwable[] var31 = var30.getSuppressed();
//     org.apache.commons.math3.exception.MaxCountExceededException var32 = new org.apache.commons.math3.exception.MaxCountExceededException(var1, (java.lang.Number)var7, (java.lang.Object[])var31);
//     org.apache.commons.math3.exception.NumberIsTooLargeException var35 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)var7, (java.lang.Number)7.73868401503849E-14d, true);
//     java.math.BigInteger var36 = null;
//     java.math.BigInteger var37 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, var36);
// 
//   }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test338"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt((-0.009479769440616246d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.21164073363140634d));

  }

  public void test339() {}
//   public void test339() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test339"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     double var4 = var0.nextChiSquare(0.5d);
//     int[] var7 = var0.nextPermutation(1, 1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("64398e7834ca38bce7d4911807c52dcc9d854379476344cb88fada6a42cbd2847c1e4328605f9d76a4ab9df48938f7542422", "ba24a339aead7636a511a32854e80fbb6776e7595b2f663cde9a4e94225cace4a5f1e6f3a655cb7e63e67d5a1db10672cff0");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.0578269442668615d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.021744198907338554d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
// 
//   }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test340"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    java.lang.String var2 = var1.name();
    java.lang.String var3 = var1.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = var4.getNanStrategy();
    java.lang.String var6 = var5.name();
    java.lang.String var7 = var5.name();
    org.apache.commons.math3.stat.ranking.NaNStrategy var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8);
    org.apache.commons.math3.stat.ranking.TiesStrategy var10 = var9.getTiesStrategy();
    int var11 = var10.ordinal();
    java.lang.String var12 = var10.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5, var10);
    java.lang.String var14 = var5.name();
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15);
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    int var18 = var17.ordinal();
    java.lang.String var19 = var17.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5, var17);
    org.apache.commons.math3.stat.ranking.TiesStrategy var21 = var20.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var21);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var23 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var21);
    java.lang.String var24 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "MAXIMAL"+ "'", var2.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "MAXIMAL"+ "'", var3.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "MAXIMAL"+ "'", var6.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "MAXIMAL"+ "'", var7.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "AVERAGE"+ "'", var12.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "MAXIMAL"+ "'", var14.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "AVERAGE"+ "'", var19.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + "MAXIMAL"+ "'", var24.equals("MAXIMAL"));

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test341"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)1.7130083828445737d, (java.lang.Number)50.0f, (java.lang.Number)9.143324706424012E42d);
    java.lang.Number var4 = var3.getArgument();
    java.lang.Number var5 = var3.getLo();
    java.lang.Number var6 = var3.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 1.7130083828445737d+ "'", var4.equals(1.7130083828445737d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 50.0f+ "'", var5.equals(50.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 50.0f+ "'", var6.equals(50.0f));

  }

  public void test342() {}
//   public void test342() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test342"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ((-2.5228617716135773E-11d), 0.4999724791450286d, 1.0533806469857276d, 4270);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test343"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(3.199763873047224E14d, 1.8246532949072747d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var2.cumulativeProbability(4.629628685877713E42d, 0.3989422804014327d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test344"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getNumericalVariance();
    double var3 = var0.probability(1.107148716958077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test345"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var3 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError(var2, (java.lang.Object[])var3);
    org.apache.commons.math3.exception.MathArithmeticException var5 = new org.apache.commons.math3.exception.MathArithmeticException(var1, (java.lang.Object[])var3);
    org.apache.commons.math3.exception.NullArgumentException var6 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test346"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(99.99999f, 2.0000002f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 99.99999f);

  }

  public void test347() {}
//   public void test347() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test347"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     java.lang.String var4 = var0.nextHexString(110);
//     long var7 = var0.nextSecureLong(0L, 27898L);
//     java.util.Collection var8 = null;
//     java.lang.Object[] var10 = var0.nextSample(var8, 0);
// 
//   }

  public void test348() {}
//   public void test348() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test348"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     double var17 = var0.nextGamma(0.9775852669347048d, 3.199763873047224E14d);
//     double var20 = var0.nextUniform(0.0d, 8.799063409660144E86d);
//     long var23 = var0.nextLong((-5129524049062756352L), (-75297573L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "10b17dbde22158efbca044a320ad178c9e0c8a240b57c500ed14900de44d1a5ada58d92439138fb1b81f41893b724a8e2fd1"+ "'", var2.equals("10b17dbde22158efbca044a320ad178c9e0c8a240b57c500ed14900de44d1a5ada58d92439138fb1b81f41893b724a8e2fd1"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 8.653057390823534E42d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.7088131643672584E14d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 2.1519889316031178E86d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == (-4844103623415461888L));
// 
//   }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test349"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(short)10);

  }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test350"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var1 = null;
    org.apache.commons.math3.exception.MathIllegalStateException var2 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var1);

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test351"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(1742979373, 88);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test352() {}
//   public void test352() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test352"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     java.lang.String var4 = var0.nextHexString(110);
//     double var7 = var0.nextGamma(0.9999999999999971d, 1.151569395337692d);
//     double var9 = var0.nextT(1.2982587902415216E14d);
//     var0.reSeedSecure(0L);
//     var0.reSeedSecure();
//     var0.reSeedSecure(27000L);
//     long var17 = var0.nextSecureLong(1134L, 27898L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.08076458768236794d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "d23206bd0769e775d0040c4a50ea5dbd70cee5260dabf07e62c1b03e19c9baf0d04254f198659ab56a4df1c5c672a3422670cffda3e4b6"+ "'", var4.equals("d23206bd0769e775d0040c4a50ea5dbd70cee5260dabf07e62c1b03e19c9baf0d04254f198659ab56a4df1c5c672a3422670cffda3e4b6"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2.2059776357132024d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1.7297940636256233d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 10669L);
// 
//   }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test353"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(50.000008f);
    var0.clear();

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test354"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(2.4750119900492516E16d, 2.7573353102077896E-32d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.5707963267948966d);

  }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test355"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Number var5 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var6 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var4, var5);
    org.apache.commons.math3.exception.util.ExceptionContext var7 = var6.getContext();
    java.lang.Throwable[] var8 = var6.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var9 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MaxCountExceededException var10 = new org.apache.commons.math3.exception.MaxCountExceededException(var1, var2, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var11 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test356() {}
//   public void test356() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test356"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     double var17 = var0.nextGamma(0.9775852669347048d, 3.199763873047224E14d);
//     var0.reSeed();
//     var0.reSeedSecure(27900L);
//     var0.reSeed();
//     org.apache.commons.math3.random.RandomDataImpl var22 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var24 = var22.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var28 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var28.reseedRandomGenerator(1L);
//     double var32 = var28.cumulativeProbability(0.0d);
//     double var34 = var28.cumulativeProbability(1.0d);
//     double var35 = var22.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var28);
//     var22.reSeed();
//     double var39 = var22.nextGamma(0.9775852669347048d, 3.199763873047224E14d);
//     double var42 = var22.nextUniform(0.0d, 8.799063409660144E86d);
//     var22.reSeed();
//     org.apache.commons.math3.distribution.NormalDistribution var44 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var45 = var22.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var44);
//     double var46 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "9de477efdd740eb2f5773f2c32970b36c00e5ecf6959906d6e8189a9d4651ed50e88f25f5bba18978b1bc9bd46621bb5292e"+ "'", var2.equals("9de477efdd740eb2f5773f2c32970b36c00e5ecf6959906d6e8189a9d4651ed50e88f25f5bba18978b1bc9bd46621bb5292e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-7.444906026390347E42d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.6761739310385016E14d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var24 + "' != '" + "2452f6412e087e279aa2795bd1669c726b67f370ec307674d6fcd8b78872e89196b9a69a017285601eabeec37c7b4e63b87e"+ "'", var24.equals("2452f6412e087e279aa2795bd1669c726b67f370ec307674d6fcd8b78872e89196b9a69a017285601eabeec37c7b4e63b87e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 2.7177862822969723E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 4.88929883633965E14d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 4.303745879065703E86d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 1.0110371456733591d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == (-0.2769561605253511d));
// 
//   }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test357"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(100, 100.0f);
    var2.clear();
    var2.setNumElements(110);
    var2.addElement(2.1559381324233437E43d);
    float var8 = var2.getContractionCriteria();
    double var10 = var2.addElementRolling(0.5174537782658822d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 100.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);

  }

  public void test358() {}
//   public void test358() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test358"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     var0.reSeed(1L);
//     java.lang.String var6 = var0.nextHexString(10);
//     double var9 = var0.nextUniform(8.451195606992581E-30d, 6.770911672198756d);
//     long var12 = var0.nextSecureLong(0L, 94L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var0.nextPascal(70, 1.999999995819933d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "7d8f4d5559a1123fc85ebfdc71ede496dc43de692da7acf3418b5864e2e30f6785b249db9ecfe060e7ccf902997664e01b17"+ "'", var2.equals("7d8f4d5559a1123fc85ebfdc71ede496dc43de692da7acf3418b5864e2e30f6785b249db9ecfe060e7ccf902997664e01b17"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "93042192d2"+ "'", var6.equals("93042192d2"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2.2682182275901375d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 51L);
// 
//   }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test359"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.distribution.NormalDistribution var4 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    var4.reseedRandomGenerator(1L);
    double var8 = var4.cumulativeProbability(0.0d);
    double var9 = var4.getStandardDeviation();
    double[] var11 = var4.sample(1612900);
    java.lang.Object[] var12 = new java.lang.Object[] { var4};
    org.apache.commons.math3.exception.MathArithmeticException var13 = new org.apache.commons.math3.exception.MathArithmeticException(var0, var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 2.6881171418161356E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test360() {}
//   public void test360() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test360"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     var0.reSeed();
//     double var18 = var0.nextGamma(2.636818730233018d, 0.5d);
//     var0.reSeedSecure(0L);
//     int var23 = var0.nextZipf(47, 6.770911672198755d);
//     java.util.Collection var24 = null;
//     java.lang.Object[] var26 = var0.nextSample(var24, 2951);
// 
//   }

  public void test361() {}
//   public void test361() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test361"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     double var5 = var0.nextGaussian(0.0d, 0.5d);
//     var0.reSeed(10L);
//     double var9 = var0.nextExponential(2.0000008411562833d);
//     double var11 = var0.nextT(9.431336800397727E41d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var0.nextPascal(0, 1.3119152085309351d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.797821987461086d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-0.22586051372903543d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2.656500765412644d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 8.033357312847968E-10d);
// 
//   }

  public void test362() {}
//   public void test362() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test362"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     double var16 = var0.nextWeibull(1.0d, 1.6298598478788293d);
//     double var19 = var0.nextWeibull(1.151569395337692d, 7.22597376812575E86d);
//     double var22 = var0.nextGaussian(2.4188678176733584E-44d, 0.9732473842406115d);
//     int var25 = var0.nextInt(66, 96);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var27 = var0.nextSecureHexString((-254));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "d619f098fcd5b0d51d8ec1cf570fce275e8c9a4210eeadaee178f61d89957df9e3fa67d84cbd443c34db2aeb990eb1ba96a3"+ "'", var2.equals("d619f098fcd5b0d51d8ec1cf570fce275e8c9a4210eeadaee178f61d89957df9e3fa67d84cbd443c34db2aeb990eb1ba96a3"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 4.715014496394922E42d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1.6398435457388043d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 5.482106974843362E86d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == (-1.2223892868145632d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 66);
// 
//   }

  public void test363() {}
//   public void test363() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test363"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     double var4 = var0.nextChiSquare(1.4640953062334716d);
//     var0.reSeed();
//     var0.reSeedSecure(48436L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.5076859704998449d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.07833444006837648d);
// 
//   }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test364"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(0.01266092703436589d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test365() {}
//   public void test365() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test365"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     double var17 = var0.nextGamma(0.9775852669347048d, 3.199763873047224E14d);
//     double var20 = var0.nextUniform(0.0d, 8.799063409660144E86d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var23 = var0.nextGaussian(32.94631867978169d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "b71ac7f25a5c4e3a7191f8a13b019829bfa39d03b85bdd7341a35b7f527e585e28ec25b9555202f688b246cb3403bdf9512d"+ "'", var2.equals("b71ac7f25a5c4e3a7191f8a13b019829bfa39d03b85bdd7341a35b7f527e585e28ec25b9555202f688b246cb3403bdf9512d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-2.470326754527749E43d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 7.541405176545473E13d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 5.895484792436752E86d);
// 
//   }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test366"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(0, 88);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test367() {}
//   public void test367() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test367"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     var0.reSeed(1L);
//     java.lang.String var6 = var0.nextHexString(10);
//     double var9 = var0.nextUniform(8.451195606992581E-30d, 6.770911672198756d);
//     var0.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "f48e15c00720fde0c3da2618d7807ea7ef0cbf298c3f2f7c61d7a29caec37f78daae8ee01e155c2ca4587a4202d4bc5f2feb"+ "'", var2.equals("f48e15c00720fde0c3da2618d7807ea7ef0cbf298c3f2f7c61d7a29caec37f78daae8ee01e155c2ca4587a4202d4bc5f2feb"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "93042192d2"+ "'", var6.equals("93042192d2"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2.2682182275901375d);
// 
//   }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test368"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    java.lang.String var2 = var1.name();
    java.lang.String var3 = var1.name();
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var5.getTiesStrategy();
    int var7 = var6.ordinal();
    java.lang.String var8 = var6.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var6);
    java.lang.String var10 = var1.toString();
    java.lang.String var11 = var1.name();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "MAXIMAL"+ "'", var2.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "MAXIMAL"+ "'", var3.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "MAXIMAL"+ "'", var10.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "MAXIMAL"+ "'", var11.equals("MAXIMAL"));

  }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test369"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh((-5.329951075180855E43d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-101.37764823829899d));

  }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test370"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(5.0f);
    var0.setElement(110, Double.NaN);
    var0.discardFrontElements(10);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var8.setContractionCriteria(50.000008f);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var8);
    int var12 = var8.getExpansionMode();
    var8.setExpansionMode(0);
    var8.clear();
    var8.setNumElements(287);
    var8.addElement(1.5485965529242296d);
    double var21 = var8.substituteMostRecentElement(0.6647615947356664d);
    org.apache.commons.math3.util.ResizableDoubleArray var22 = var8.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var26 = new org.apache.commons.math3.util.ResizableDoubleArray(3, 2.0f, 2.5f);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var22, var26);
    org.apache.commons.math3.stat.ranking.NaturalRanking var28 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var29 = var28.getNanStrategy();
    java.lang.String var30 = var29.name();
    java.lang.String var31 = var29.name();
    org.apache.commons.math3.stat.ranking.NaNStrategy var32 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var33 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var32);
    org.apache.commons.math3.stat.ranking.TiesStrategy var34 = var33.getTiesStrategy();
    int var35 = var34.ordinal();
    java.lang.String var36 = var34.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var37 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var29, var34);
    java.lang.String var38 = var29.name();
    org.apache.commons.math3.stat.ranking.NaNStrategy var39 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var40 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var39);
    org.apache.commons.math3.stat.ranking.TiesStrategy var41 = var40.getTiesStrategy();
    int var42 = var41.ordinal();
    java.lang.String var43 = var41.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var44 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var29, var41);
    boolean var45 = var26.equals((java.lang.Object)var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1.5485965529242296d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + "MAXIMAL"+ "'", var30.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var31 + "' != '" + "MAXIMAL"+ "'", var31.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var36 + "' != '" + "AVERAGE"+ "'", var36.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var38 + "' != '" + "MAXIMAL"+ "'", var38.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var43 + "' != '" + "AVERAGE"+ "'", var43.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);

  }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test371"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var5 = new double[] { 1.0d, 100.0d};
    var2.addElements(var5);
    var2.setNumElements(10);
    double[] var9 = var2.getElements();
    double var11 = var2.substituteMostRecentElement((-3.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);

  }

  public void test372() {}
//   public void test372() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test372"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     double var17 = var0.nextGamma(0.9775852669347048d, 3.199763873047224E14d);
//     double var20 = var0.nextUniform(0.0d, 8.799063409660144E86d);
//     org.apache.commons.math3.distribution.NormalDistribution var24 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var24.reseedRandomGenerator(1L);
//     boolean var27 = var24.isSupportConnected();
//     double var28 = var24.getMean();
//     double var29 = var24.sample();
//     double var30 = var24.getSupportUpperBound();
//     boolean var31 = var24.isSupportUpperBoundInclusive();
//     boolean var32 = var24.isSupportUpperBoundInclusive();
//     double var33 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var24);
//     double var37 = var0.nextUniform((-3.4536536242642804E43d), 0.1672559658154289d, true);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var41 = var0.nextPascal(449542426, (-0.24393093086615214d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "f52f64980af8b843fcea98d2b5322aeb7056c08fe3b868cdcd346d260dabd0a19be80ef8dea9d84ec0d5c573e51991765a7c"+ "'", var2.equals("f52f64980af8b843fcea98d2b5322aeb7056c08fe3b868cdcd346d260dabd0a19be80ef8dea9d84ec0d5c573e51991765a7c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-1.262550854338233E42d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.6596875585968812E14d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 7.685407631450026E86d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 3.5671315446818194E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 2.388399326643605E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == (-1.0598693759377125E43d));
// 
//   }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test373"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)2.4188678176733584E-44d);

  }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test374"); }


    int var1 = org.apache.commons.math3.util.FastMath.round((-0.99999994f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test375"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(12192000, 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 12192000);

  }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test376"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(31L, 111);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-2153345741252449825L));

  }

  public void test377() {}
//   public void test377() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test377"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     double var17 = var0.nextGamma(0.9775852669347048d, 3.199763873047224E14d);
//     double var20 = var0.nextUniform(0.0d, 8.799063409660144E86d);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var24 = var0.nextF(1.70638274610834d, (-8.679894338181829E64d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "06fa4a15179c635a6aa48c2917501b0fa3bd132153407a56a6a1658dfb6c9264ce8e2156bf0e376ac939845291d93ae7d85b"+ "'", var2.equals("06fa4a15179c635a6aa48c2917501b0fa3bd132153407a56a6a1658dfb6c9264ce8e2156bf0e376ac939845291d93ae7d85b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.5514877654176292E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.145857133332216E13d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 6.64306293962643E86d);
// 
//   }

  public void test378() {}
//   public void test378() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test378"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     double var17 = var0.nextGamma(0.9775852669347048d, 3.199763873047224E14d);
//     var0.reSeed();
//     var0.reSeedSecure(27900L);
//     double var22 = var0.nextExponential(1.1282937610745374d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "2f3ae8402c59f8b1ecd2415a2530ecbaa509dc24417bf3bea38262bd5eb85ebee1243ae4532b82ce2a0b62902d256c0c64af"+ "'", var2.equals("2f3ae8402c59f8b1ecd2415a2530ecbaa509dc24417bf3bea38262bd5eb85ebee1243ae4532b82ce2a0b62902d256c0c64af"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 2.6574013571658466E42d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 5.11990916534964E14d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0.0888514038380437d);
// 
//   }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test379"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(4.5194037630894135d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.508380074322216d);

  }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test380"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(0.4855570380544819d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.39578981171956806d);

  }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test381"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)436.05387683681073d, false);

  }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test382"); }


    double var1 = org.apache.commons.math3.special.Gamma.logGamma(2.2715895134179253E14d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.281959793887915E15d);

  }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test383"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(5.0f);
    var0.setElement(110, Double.NaN);
    var0.discardFrontElements(10);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var8.setContractionCriteria(50.000008f);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var8);
    int var12 = var8.getExpansionMode();
    var8.setExpansionMode(0);
    var8.clear();
    var8.setNumElements(287);
    var8.addElement(1.5485965529242296d);
    int var20 = var8.getExpansionMode();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);

  }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test384"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(4400, 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test385"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.14473363781667506d, 7.592249261653048E42d, 7.180580376996924E86d, 108);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);

  }

  public void test386() {}
//   public void test386() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test386"); }
// 
// 
//     double var1 = org.apache.commons.math3.special.Gamma.trigamma((-3.6187645784596483E43d));
// 
//   }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test387"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    java.lang.String var2 = var1.name();
    java.lang.String var3 = var1.toString();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var5.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var8 = var7.getNanStrategy();
    java.lang.String var9 = var8.name();
    java.lang.String var10 = var8.name();
    org.apache.commons.math3.stat.ranking.NaNStrategy var11 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11);
    org.apache.commons.math3.stat.ranking.TiesStrategy var13 = var12.getTiesStrategy();
    int var14 = var13.ordinal();
    java.lang.String var15 = var13.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8, var13);
    double[] var18 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray(var18);
    var19.setContractionCriteria(50.000008f);
    var19.setExpansionMode(0);
    boolean var24 = var13.equals((java.lang.Object)var19);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var25 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var6, var13);
    org.apache.commons.math3.stat.ranking.NaturalRanking var26 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var13);
    org.apache.commons.math3.stat.ranking.NaturalRanking var27 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "MAXIMAL"+ "'", var2.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "MAXIMAL"+ "'", var3.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "MAXIMAL"+ "'", var9.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "MAXIMAL"+ "'", var10.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "AVERAGE"+ "'", var15.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);

  }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test388"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(6.380871670939738E-45d, 0.996286284644239d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.996286284644239d);

  }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test389"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(4, (-105));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test390"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(90000L, 2432902008176640001L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2432902008176730001L);

  }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test391"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(862L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test392"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(0.0888514038380437d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test393"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.05902633562621646d, 0.14473363781667506d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.08662759912540907d);

  }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test394"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(2.3602882503786575d, 2.6574013571658466E42d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 8.439843259122971E-4d);

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test395"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0.99999994f);

  }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test396"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(3.874110573361593E-4d, 6.419286864170918E43d);

  }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test397"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(5.0f);
    var0.setElement(110, Double.NaN);
    var0.discardFrontElements(10);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var8.setContractionCriteria(50.000008f);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var8);
    int var12 = var8.getExpansionMode();
    var8.setExpansionMode(0);
    double var16 = var8.addElementRolling(0.35364893135754055d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);

  }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test398"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(28494L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 28494L);

  }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test399"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.0f, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test400"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(5.0f);
    var0.setElement(110, Double.NaN);
    var0.discardFrontElements(10);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var8.setContractionCriteria(50.000008f);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var8);
    int var12 = var8.getExpansionMode();
    var8.setExpansionMode(0);
    var8.clear();
    var8.setNumElements(287);
    var8.addElement(1.5485965529242296d);
    double var21 = var8.substituteMostRecentElement(0.6647615947356664d);
    var8.setContractionCriteria(2.30584301E18f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1.5485965529242296d);

  }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test401"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)1.4640953062334716d, (java.lang.Number)Double.NEGATIVE_INFINITY, (java.lang.Number)1.0d);
    java.lang.Number var5 = var4.getLo();
    java.lang.Number var6 = var4.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + Double.NEGATIVE_INFINITY+ "'", var5.equals(Double.NEGATIVE_INFINITY));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 1.0d+ "'", var6.equals(1.0d));

  }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test402"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.0f, (-3.1199010195518257E42d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.4E-45f));

  }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test403"); }


    int var2 = org.apache.commons.math3.util.FastMath.min((-122), 88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-122));

  }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test404"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var1);
    org.apache.commons.math3.stat.ranking.TiesStrategy var3 = var2.getTiesStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test405"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs((-100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 100);

  }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test406"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(5.0f);
    org.apache.commons.math3.random.RandomDataImpl var3 = new org.apache.commons.math3.random.RandomDataImpl();
    boolean var4 = var0.equals((java.lang.Object)var3);
    var0.addElement(Double.NaN);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var0.getElement((-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test407"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(800.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 800.0d);

  }

  public void test408() {}
//   public void test408() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test408"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(8.799063409660144E86d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test409"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.addElement(0.02797455810085192d);
    var0.discardFrontElements(1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var6 = var0.substituteMostRecentElement((-1.0535313540516738E43d));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException");
    } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
      // Expected exception.
    }

  }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test410"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 47);

  }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test411"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(2);
    var1.contract();

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test412"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    java.lang.String var2 = var1.name();
    java.lang.String var3 = var1.name();
    boolean var5 = var1.equals((java.lang.Object)"bbc76c98706e096cbdb48c11be18b37feafe094ae0e5291b81fe65cbd0c42cc6f465c322de0f5afaf8fdd0237c92d0d9c2d6");
    int var6 = var1.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var8 = var7.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var9 = var7.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var10 = var7.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var11 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var10);
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var13 = var12.getNanStrategy();
    java.lang.String var14 = var13.name();
    java.lang.String var15 = var13.name();
    org.apache.commons.math3.stat.ranking.NaNStrategy var16 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var16);
    org.apache.commons.math3.stat.ranking.TiesStrategy var18 = var17.getTiesStrategy();
    int var19 = var18.ordinal();
    java.lang.String var20 = var18.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var13, var18);
    org.apache.commons.math3.stat.ranking.NaNStrategy var22 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var22);
    org.apache.commons.math3.stat.ranking.TiesStrategy var24 = var23.getTiesStrategy();
    int var25 = var24.ordinal();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var26 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var13, var24);
    org.apache.commons.math3.distribution.NormalDistribution var29 = new org.apache.commons.math3.distribution.NormalDistribution(1.8246532949072747d, 0.9732473842406115d);
    boolean var30 = var29.isSupportConnected();
    boolean var31 = var24.equals((java.lang.Object)var30);
    org.apache.commons.math3.stat.ranking.NaturalRanking var32 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var24);
    int var33 = var24.ordinal();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "MAXIMAL"+ "'", var2.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "MAXIMAL"+ "'", var3.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "MAXIMAL"+ "'", var14.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "MAXIMAL"+ "'", var15.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "AVERAGE"+ "'", var20.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 3);

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test413"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(5, 101);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test414"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var2.setContractionCriteria(50.000008f);
    var2.setExpansionMode(0);
    var2.setContractionCriteria(5.0f);
    double[] var10 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var10);
    var11.setContractionCriteria(50.000008f);
    double[] var14 = var11.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var11);
    boolean var16 = var2.equals((java.lang.Object)var11);
    float var17 = var2.getContractionCriteria();
    double[] var18 = var2.getInternalValues();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.discardFrontElements(25019000);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 5.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test415() {}
//   public void test415() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test415"); }
// 
// 
//     double[] var1 = new double[] { 1.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
//     float var3 = var2.getExpansionFactor();
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = var2.copy();
//     org.apache.commons.math3.util.ResizableDoubleArray var5 = var4.copy();
//     double var7 = var5.addElementRolling(8.854857970931142E43d);
//     double[] var8 = null;
//     var5.addElements(var8);
// 
//   }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test416"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    java.lang.String var2 = var1.name();
    java.lang.String var3 = var1.name();
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var5.getTiesStrategy();
    int var7 = var6.ordinal();
    java.lang.String var8 = var6.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var6);
    double[] var11 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var11);
    var12.setContractionCriteria(50.000008f);
    var12.setExpansionMode(0);
    boolean var17 = var6.equals((java.lang.Object)var12);
    int var18 = var12.getExpansionMode();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "MAXIMAL"+ "'", var2.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "MAXIMAL"+ "'", var3.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);

  }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test417"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc((-2.3251745304976303d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.9989920324989237d);

  }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test418"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.NotPositiveException var4 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(short)1);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var6 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var5, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MathIllegalArgumentException var8 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MaxCountExceededException var9 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)0.9640275797804917d, (java.lang.Object[])var6);
    java.lang.Number var10 = var9.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + 0.9640275797804917d+ "'", var10.equals(0.9640275797804917d));

  }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test419"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var2.setContractionCriteria(50.000008f);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = var2.copy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var7 = var2.getElement((-122));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test420"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(2700L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2700L);

  }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test421"); }


    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(2, 10.0f, 10.0f, 1);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    var4.addElement(0.2523930260097898d);
    double var10 = var4.substituteMostRecentElement(4.6310740263131307E86d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.2523930260097898d);

  }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test422"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(66, 2.3841856E-7f, 2.0000002f, 229345007);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test423"); }


    float var2 = org.apache.commons.math3.util.FastMath.max((-0.99999994f), 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100.0f);

  }

  public void test424() {}
//   public void test424() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test424"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     boolean var14 = var6.isSupportUpperBoundInclusive();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "f3bec3fcd161cd75fd8ef25f0a9b830cf590f737c390acd4956bc027931d4edc242b329dfc8220358647d78edf801c589fde"+ "'", var2.equals("f3bec3fcd161cd75fd8ef25f0a9b830cf590f737c390acd4956bc027931d4edc242b329dfc8220358647d78edf801c589fde"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-2.1568343228582852E42d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
// 
//   }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test425"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd((-8615948696432275456L), 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 8615948696432275456L);

  }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test426"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(0, 88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 88);

  }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test427"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(short)0, (java.lang.Number)10, false);
    boolean var4 = var3.getBoundIsAllowed();
    java.lang.Throwable[] var5 = var3.getSuppressed();
    boolean var6 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test428"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(0.02744636141299663d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.027442915639507723d);

  }

  public void test429() {}
//   public void test429() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test429"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     double var16 = var0.nextWeibull(1.0d, 1.6298598478788293d);
//     double var19 = var0.nextCauchy((-1.1440883267692863E33d), 3.3030345912774096E43d);
//     var0.reSeedSecure();
//     double var24 = var0.nextUniform(0.0d, 2.4188678176733584E-44d, true);
//     var0.reSeed();
//     double var28 = var0.nextGamma((-2.1317761108019555d), 1.9480212129433703E13d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "914810af3159f2669f4b1ca9133fbd5d9765a359bbc870a9611d75058f70eef3becd95f1cd9a47f30ba7a6aa68050881ce6b"+ "'", var2.equals("914810af3159f2669f4b1ca9133fbd5d9765a359bbc870a9611d75058f70eef3becd95f1cd9a47f30ba7a6aa68050881ce6b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-3.2812801842882495E42d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.33519895020450047d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-2.9893235759400047E43d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1.4029941052194305E-44d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 4.584747594504899E13d);
// 
//   }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test430"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(4.067958619401342E86d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.067958619401342E86d);

  }

  public void test431() {}
//   public void test431() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test431"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     double var5 = var0.nextGaussian(0.0d, 0.5d);
//     var0.reSeed(10L);
//     long var10 = var0.nextLong((-1L), 10L);
//     double var13 = var0.nextF(0.9999999999999971d, 0.5088599843857857d);
//     var0.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.9175289829302102d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-0.21306319806090124d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 3L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 33440.02188934844d);
// 
//   }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test432"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var3.getElements();
    var3.clear();
    double[] var6 = var3.getInternalValues();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test433"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)0.3324193131412804d);
    java.lang.Throwable[] var2 = var1.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test434"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(42.77503722459932d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.6311903961542493d);

  }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test435"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double[] var2 = var0.sample(1);
    double var3 = var0.getMean();
    boolean var4 = var0.isSupportUpperBoundInclusive();
    boolean var5 = var0.isSupportUpperBoundInclusive();
    double var8 = var0.cumulativeProbability(1.3626999595542073d, 5.458802422386986E43d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var0.inverseCumulativeProbability(1.3119152085309351d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.08648854529952615d);

  }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test436"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.NotPositiveException var5 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(short)1);
    java.lang.Object[] var6 = new java.lang.Object[] { (short)1};
    org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException(var3, var6);
    org.apache.commons.math3.exception.MathInternalError var8 = new org.apache.commons.math3.exception.MathInternalError(var2, var6);
    org.apache.commons.math3.exception.MaxCountExceededException var9 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)1.0499768188068717d, var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test437"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)0.18029079387572064d, var2, true);

  }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test438"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    double var4 = var3.getSupportLowerBound();
    double var6 = var3.probability((-0.5606386275277436d));
    double var8 = var3.inverseCumulativeProbability(0.5d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var11 = var3.cumulativeProbability(0.8399341499662786d, 0.4566344307670791d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);

  }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test439"); }


    org.apache.commons.math3.exception.NullArgumentException var0 = new org.apache.commons.math3.exception.NullArgumentException();
    org.apache.commons.math3.exception.MathInternalError var1 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var0);
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var1.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test440"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    java.lang.String var2 = var1.toString();
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.NotPositiveException var5 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(short)1);
    java.lang.Object[] var6 = new java.lang.Object[] { (short)1};
    org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException(var3, var6);
    boolean var8 = var1.equals((java.lang.Object)var3);
    boolean var10 = var1.equals((java.lang.Object)(-2.791500647694174E42d));
    int var11 = var1.ordinal();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "MAXIMAL"+ "'", var2.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test441"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    java.lang.String var3 = var2.toString();
    int var4 = var2.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    java.lang.String var6 = var2.name();
    double[] var8 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
    var9.setContractionCriteria(50.000008f);
    var9.setExpansionMode(0);
    var9.setContractionCriteria(5.0f);
    float var16 = var9.getExpansionFactor();
    float var17 = var9.getExpansionFactor();
    boolean var18 = var2.equals((java.lang.Object)var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "AVERAGE"+ "'", var3.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "AVERAGE"+ "'", var6.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test442"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var2.setContractionCriteria(50.000008f);
    var2.setExpansionMode(0);
    var2.setContractionCriteria(5.0f);
    double[] var10 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var10);
    var11.setContractionCriteria(50.000008f);
    double[] var14 = var11.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var11);
    boolean var16 = var2.equals((java.lang.Object)var11);
    float var17 = var2.getContractionCriteria();
    var2.addElement(4.953013069603387E43d);
    double[] var20 = var2.getElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 5.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test443"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(127, 2951);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2951);

  }

  public void test444() {}
//   public void test444() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test444"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     var0.reSeed(1L);
//     double var7 = var0.nextWeibull(6.389056068043896d, 6.770911672198755d);
//     int var10 = var0.nextInt(657919, 645781745);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "3fcb0af1f9e529346f89a727bfee8ee2dfaa23a9e052d2f75f00f5e9e5bb9f9b65de7bec3df72b74092831a130f998068cde"+ "'", var2.equals("3fcb0af1f9e529346f89a727bfee8ee2dfaa23a9e052d2f75f00f5e9e5bb9f9b65de7bec3df72b74092831a130f998068cde"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 4.5194037630894135d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 216770858);
// 
//   }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test445"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1.2539861847696195E14d, var2, false);

  }

  public void test446() {}
//   public void test446() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test446"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     double var17 = var0.nextBeta(1.1265425086815434E43d, 1.1282937610745374d);
//     long var19 = var0.nextPoisson(31.402066659134473d);
//     long var22 = var0.nextSecureLong(0L, 6L);
//     int var25 = var0.nextInt(0, 2147483647);
//     long var28 = var0.nextSecureLong(29L, 75324600L);
//     org.apache.commons.math3.distribution.IntegerDistribution var29 = null;
//     int var30 = var0.nextInversionDeviate(var29);
// 
//   }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test447"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(23333L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test448"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double var4 = var2.substituteMostRecentElement(1.0159453334112069E43d);
    double var6 = var2.substituteMostRecentElement(3.693917551910061E13d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0159453334112069E43d);

  }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test449"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(0.5990851178057973d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.4694316643336099d);

  }

  public void test450() {}
//   public void test450() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test450"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 986L);
// 
//   }

  public void test451() {}
//   public void test451() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test451"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos((-1.6847179505492349E43d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test452"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(41453239, (-66));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test453"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.5274450245437947d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.6945971187784026d);

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test454"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var2.setContractionCriteria(50.000008f);
    double[] var5 = var2.getInternalValues();
    double[] var6 = var2.getElements();
    double[] var7 = var2.getInternalValues();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test455"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(70);

  }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test456"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = var2.copy();
    var2.addElement(0.0018388436884212223d);
    double[] var6 = var2.getElements();
    boolean var8 = var2.equals((java.lang.Object)5.810921362670137E42d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test457"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)10.0d);
    java.lang.Throwable[] var2 = var1.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test458"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(2.6881171418161356E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.6881171418161356E43d);

  }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test459"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.NotPositiveException var6 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(short)1);
    java.lang.Object[] var7 = new java.lang.Object[] { (short)1};
    org.apache.commons.math3.exception.MathIllegalStateException var8 = new org.apache.commons.math3.exception.MathIllegalStateException(var4, var7);
    org.apache.commons.math3.exception.MathArithmeticException var9 = new org.apache.commons.math3.exception.MathArithmeticException(var3, var7);
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, var7);
    org.apache.commons.math3.exception.MaxCountExceededException var11 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)(-0.24393093086615214d), var7);
    java.lang.Number var12 = var11.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + (-0.24393093086615214d)+ "'", var12.equals((-0.24393093086615214d)));

  }

  public void test460() {}
//   public void test460() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test460"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     double var5 = var0.nextGaussian(0.0d, 0.5d);
//     var0.reSeed(10L);
//     double var10 = var0.nextF(1.3872175661331396d, 2.636818730233018d);
//     double var14 = var0.nextUniform(0.9732473842406116d, 5.840802579076462E13d, true);
//     double var16 = var0.nextT(0.1916590679018214d);
//     org.apache.commons.math3.distribution.IntegerDistribution var17 = null;
//     int var18 = var0.nextInversionDeviate(var17);
// 
//   }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test461"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(3.5671315446818194E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test462"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-48600L));

  }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test463"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    var3.reseedRandomGenerator(1L);
    boolean var6 = var3.isSupportConnected();
    double var7 = var3.getMean();
    double var8 = var3.getStandardDeviation();
    boolean var9 = var3.isSupportUpperBoundInclusive();
    double var11 = var3.density(0.0863810803914614d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.6881171418161356E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1.4840955931403377E-44d);

  }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test464"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.0f, 1.9586146923852683d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.4E-45f);

  }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test465"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(5.0f);
    var0.setElement(110, Double.NaN);
    var0.discardFrontElements(10);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var8.setContractionCriteria(50.000008f);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var8);
    int var12 = var8.getExpansionMode();
    var8.setExpansionMode(0);
    var8.clear();
    var8.setNumElements(287);
    var8.addElement(1.5485965529242296d);
    double[] var20 = var8.getElements();
    float var21 = var8.getContractionCriteria();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 5.0f);

  }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test466"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(12700);
    var1.setExpansionFactor(2.0000005f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.discardMostRecentElements(31);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test467"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(287, 4400);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4400);

  }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test468"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var1 = null;
    org.apache.commons.math3.exception.MathArithmeticException var2 = new org.apache.commons.math3.exception.MathArithmeticException(var0, var1);

  }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test469"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(3.6710379822636514E43d, 0.8209031109473406d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.6710379822636514E43d);

  }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test470"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(0.5266862993088351d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6933118728172234d);

  }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test471"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var5.getTiesStrategy();
    int var7 = var6.ordinal();
    java.lang.String var8 = var6.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var6);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var11 = var10.getNanStrategy();
    java.lang.String var12 = var11.name();
    java.lang.String var13 = var11.name();
    boolean var15 = var11.equals((java.lang.Object)"bbc76c98706e096cbdb48c11be18b37feafe094ae0e5291b81fe65cbd0c42cc6f465c322de0f5afaf8fdd0237c92d0d9c2d6");
    boolean var16 = var1.equals((java.lang.Object)var11);
    org.apache.commons.math3.random.RandomGenerator var17 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var17);
    org.apache.commons.math3.stat.ranking.NaNStrategy var19 = var18.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var20 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var19, var20);
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var23 = var22.getNanStrategy();
    java.lang.String var24 = var23.name();
    java.lang.String var25 = var23.name();
    org.apache.commons.math3.stat.ranking.NaNStrategy var26 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var27 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var26);
    org.apache.commons.math3.stat.ranking.TiesStrategy var28 = var27.getTiesStrategy();
    int var29 = var28.ordinal();
    java.lang.String var30 = var28.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var31 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var23, var28);
    org.apache.commons.math3.stat.ranking.NaturalRanking var32 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var19, var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "MAXIMAL"+ "'", var12.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "MAXIMAL"+ "'", var13.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + "MAXIMAL"+ "'", var24.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + "MAXIMAL"+ "'", var25.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + "AVERAGE"+ "'", var30.equals("AVERAGE"));

  }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test472"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(2559.9998f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test473"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.08971084836383868d, (java.lang.Number)9.143324706424012E42d, false);
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);

  }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test474"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(102400.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 102400.0f);

  }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test475"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    var3.reseedRandomGenerator(1L);
    boolean var6 = var3.isSupportConnected();
    double var7 = var3.getNumericalMean();
    double var9 = var3.cumulativeProbability(1.107148716958077d);
    boolean var10 = var3.isSupportConnected();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var13 = var3.cumulativeProbability((-101.37764823829899d), (-1.1980127630095007E43d));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);

  }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test476"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var5.getTiesStrategy();
    int var7 = var6.ordinal();
    java.lang.String var8 = var6.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var6);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var11 = var10.getNanStrategy();
    java.lang.String var12 = var11.name();
    java.lang.String var13 = var11.name();
    boolean var15 = var11.equals((java.lang.Object)"bbc76c98706e096cbdb48c11be18b37feafe094ae0e5291b81fe65cbd0c42cc6f465c322de0f5afaf8fdd0237c92d0d9c2d6");
    boolean var16 = var1.equals((java.lang.Object)var11);
    org.apache.commons.math3.random.RandomGenerator var17 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var17);
    org.apache.commons.math3.stat.ranking.NaNStrategy var19 = var18.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var20 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var19, var20);
    java.lang.String var22 = var19.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "MAXIMAL"+ "'", var12.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "MAXIMAL"+ "'", var13.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + "MAXIMAL"+ "'", var22.equals("MAXIMAL"));

  }

  public void test477() {}
//   public void test477() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test477"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     double var17 = var0.nextGamma(0.9775852669347048d, 3.199763873047224E14d);
//     double var20 = var0.nextF(2.636818730233018d, 1.1282937610745374d);
//     var0.reSeed(6L);
//     int var25 = var0.nextInt((-100), 2147483647);
//     org.apache.commons.math3.distribution.NormalDistribution var26 = new org.apache.commons.math3.distribution.NormalDistribution();
//     boolean var27 = var26.isSupportUpperBoundInclusive();
//     boolean var28 = var26.isSupportLowerBoundInclusive();
//     double var29 = var26.getMean();
//     double var30 = var26.getSupportUpperBound();
//     double var32 = var26.probability(3.874110573361593E-4d);
//     double var33 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var26);
//     double var36 = var0.nextUniform(1.81934158241626E-8d, 3.456281063036932E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "6b02745fffa51f5a32274b017a9d573918e841f84fbd7bff28f9602327d2925694d6a37c2931a243550aff0c9931d78dd11c"+ "'", var2.equals("6b02745fffa51f5a32274b017a9d573918e841f84fbd7bff28f9602327d2925694d6a37c2931a243550aff0c9931d78dd11c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 5.484911756749627E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.1359066536634168E15d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.2122439117578808d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1742979373);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == (-1.3405768023430444d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 3.1920703896089355E-4d);
// 
//   }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test478"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(0, 768793337);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test479"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.math.BigInteger var4 = null;
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var8 = new org.apache.commons.math3.exception.OutOfRangeException(var2, (java.lang.Number)100.0f, (java.lang.Number)var6, (java.lang.Number)0.5000672346092545d);
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    java.math.BigInteger var11 = null;
    java.math.BigInteger var13 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var15 = new org.apache.commons.math3.exception.OutOfRangeException(var9, (java.lang.Number)100.0f, (java.lang.Number)var13, (java.lang.Number)0.5000672346092545d);
    java.math.BigInteger var16 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, var13);
    org.apache.commons.math3.exception.util.Localizable var17 = null;
    java.lang.Object[] var20 = new java.lang.Object[] { '4'};
    org.apache.commons.math3.exception.MaxCountExceededException var21 = new org.apache.commons.math3.exception.MaxCountExceededException(var17, (java.lang.Number)Double.NaN, var20);
    java.lang.Throwable[] var22 = var21.getSuppressed();
    org.apache.commons.math3.exception.MaxCountExceededException var23 = new org.apache.commons.math3.exception.MaxCountExceededException(var1, (java.lang.Number)var6, (java.lang.Object[])var22);
    org.apache.commons.math3.exception.MaxCountExceededException var24 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)var6);
    org.apache.commons.math3.exception.util.Localizable var25 = null;
    java.lang.Object[] var28 = new java.lang.Object[] { '4'};
    org.apache.commons.math3.exception.MaxCountExceededException var29 = new org.apache.commons.math3.exception.MaxCountExceededException(var25, (java.lang.Number)Double.NaN, var28);
    java.lang.Throwable[] var30 = var29.getSuppressed();
    org.apache.commons.math3.exception.MaxCountExceededException var31 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)var6, (java.lang.Object[])var30);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.math.BigInteger var33 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, (-1L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test480"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(-0.7997115369080445d));

  }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test481"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    java.lang.String var2 = var1.toString();
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.NotPositiveException var5 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(short)1);
    java.lang.Object[] var6 = new java.lang.Object[] { (short)1};
    org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException(var3, var6);
    boolean var8 = var1.equals((java.lang.Object)var3);
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.random.RandomGenerator var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "MAXIMAL"+ "'", var2.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test482"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(0, 96);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test483() {}
//   public void test483() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test483"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     java.lang.String var4 = var0.nextHexString(110);
//     int var7 = var0.nextPascal(3, 0.0d);
//     int var10 = var0.nextSecureInt(47, 110);
//     var0.reSeedSecure(300L);
//     long var15 = var0.nextSecureLong(0L, 28798L);
//     java.util.Collection var16 = null;
//     java.lang.Object[] var18 = var0.nextSample(var16, 2951);
// 
//   }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test484"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(1.4E-45f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.8E-45f);

  }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test485"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("2bd463ccf1ed12079e7ae690d442bfb4318ac54e1b580b3c47d4bb951f146ad1ae6dc8b880ef6387025ae93c88fc04b129da");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test486"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    int var4 = var3.getNumElements();
    double var6 = var3.addElementRolling(1.2982587902415216E14d);
    int var7 = var3.getExpansionMode();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setExpansionFactor(100.5f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);

  }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test487"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = var2.copy();
    double var5 = var2.substituteMostRecentElement(7.010934642525645E42d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);

  }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test488"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray((-100), 102399.99f, 1.0f, 2068);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test489"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.NotPositiveException var6 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(short)1);
    java.lang.Object[] var7 = new java.lang.Object[] { (short)1};
    org.apache.commons.math3.exception.MathIllegalStateException var8 = new org.apache.commons.math3.exception.MathIllegalStateException(var4, var7);
    org.apache.commons.math3.exception.MathInternalError var9 = new org.apache.commons.math3.exception.MathInternalError(var3, var7);
    java.lang.Object[] var10 = new java.lang.Object[] { var7};
    org.apache.commons.math3.exception.MathInternalError var11 = new org.apache.commons.math3.exception.MathInternalError(var2, var10);
    org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, var10);
    org.apache.commons.math3.exception.NullArgumentException var13 = new org.apache.commons.math3.exception.NullArgumentException(var0, var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test490() {}
//   public void test490() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test490"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.sqrt((-0.5606386275277435d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test491() {}
//   public void test491() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test491"); }
// 
// 
//     org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     var0.setContractionCriteria(5.0f);
//     org.apache.commons.math3.random.RandomDataImpl var3 = new org.apache.commons.math3.random.RandomDataImpl();
//     boolean var4 = var0.equals((java.lang.Object)var3);
//     var3.reSeedSecure(27900L);
//     int var9 = var3.nextSecureInt(2951, 449542426);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var3.setSecureAlgorithm("ea4e0c6ed94942961b1475e10e002237a91656f46124176fe6ad65149c099c48b1890ca098f2303cc26df51e8220e595a0ed", "d23206bd0769e775d0040c4a50ea5dbd70cee5260dabf07e62c1b03e19c9baf0d04254f198659ab56a4df1c5c672a3422670cffda3e4b6");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 288377583);
// 
//   }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test492"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)0.3324193131412804d);

  }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test493"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(33440.02188934844d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 33441.0d);

  }

  public void test494() {}
//   public void test494() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test494"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     long var16 = var0.nextLong((-92L), 900L);
//     double var19 = var0.nextGaussian(0.9500268869550641d, 2.7573353102077896E-32d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "5462bbeb8abd2cb46e936260346d192289dcbf4fc25942d85f25f522f610b756961a1bd1f85e5adf3e99ba3f22db068eaab3"+ "'", var2.equals("5462bbeb8abd2cb46e936260346d192289dcbf4fc25942d85f25f522f610b756961a1bd1f85e5adf3e99ba3f22db068eaab3"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-5.582997880991177E43d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == (-60L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.9500268869550641d);
// 
//   }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test495"); }


    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.math.BigInteger var4 = null;
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var8 = new org.apache.commons.math3.exception.OutOfRangeException(var2, (java.lang.Number)100.0f, (java.lang.Number)var6, (java.lang.Number)0.5000672346092545d);
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    java.math.BigInteger var11 = null;
    java.math.BigInteger var13 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var15 = new org.apache.commons.math3.exception.OutOfRangeException(var9, (java.lang.Number)100.0f, (java.lang.Number)var13, (java.lang.Number)0.5000672346092545d);
    java.math.BigInteger var16 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, var13);
    java.math.BigInteger var18 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, 31L);
    org.apache.commons.math3.exception.OutOfRangeException var19 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)8.799063409660144E86d, (java.lang.Number)0.99999994f, (java.lang.Number)var6);
    org.apache.commons.math3.exception.util.Localizable var20 = null;
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    org.apache.commons.math3.exception.util.Localizable var22 = null;
    org.apache.commons.math3.exception.util.Localizable var23 = null;
    java.lang.Number var24 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var25 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var23, var24);
    org.apache.commons.math3.exception.util.ExceptionContext var26 = var25.getContext();
    java.lang.Throwable[] var27 = var25.getSuppressed();
    org.apache.commons.math3.exception.MathInternalError var28 = new org.apache.commons.math3.exception.MathInternalError(var22, (java.lang.Object[])var27);
    org.apache.commons.math3.exception.MathInternalError var29 = new org.apache.commons.math3.exception.MathInternalError(var21, (java.lang.Object[])var27);
    org.apache.commons.math3.exception.MathIllegalStateException var30 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var19, var20, (java.lang.Object[])var27);
    java.lang.Throwable[] var31 = var19.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test496"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var0.getNanStrategy();
    java.lang.String var3 = var2.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "MAXIMAL"+ "'", var3.equals("MAXIMAL"));

  }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test497"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.math.BigInteger var3 = null;
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var7 = new org.apache.commons.math3.exception.OutOfRangeException(var1, (java.lang.Number)100.0f, (java.lang.Number)var5, (java.lang.Number)0.5000672346092545d);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    java.math.BigInteger var10 = null;
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var10, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var14 = new org.apache.commons.math3.exception.OutOfRangeException(var8, (java.lang.Number)100.0f, (java.lang.Number)var12, (java.lang.Number)0.5000672346092545d);
    java.math.BigInteger var15 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, var12);
    org.apache.commons.math3.exception.util.Localizable var16 = null;
    java.lang.Object[] var19 = new java.lang.Object[] { '4'};
    org.apache.commons.math3.exception.MaxCountExceededException var20 = new org.apache.commons.math3.exception.MaxCountExceededException(var16, (java.lang.Number)Double.NaN, var19);
    java.lang.Throwable[] var21 = var20.getSuppressed();
    org.apache.commons.math3.exception.MaxCountExceededException var22 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)var5, (java.lang.Object[])var21);
    java.math.BigInteger var24 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 5144L);
    org.apache.commons.math3.exception.util.Localizable var25 = null;
    org.apache.commons.math3.exception.util.Localizable var26 = null;
    org.apache.commons.math3.exception.util.Localizable var27 = null;
    org.apache.commons.math3.exception.util.Localizable var28 = null;
    java.math.BigInteger var30 = null;
    java.math.BigInteger var32 = org.apache.commons.math3.util.ArithmeticUtils.pow(var30, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var34 = new org.apache.commons.math3.exception.OutOfRangeException(var28, (java.lang.Number)100.0f, (java.lang.Number)var32, (java.lang.Number)0.5000672346092545d);
    org.apache.commons.math3.exception.util.Localizable var35 = null;
    java.math.BigInteger var37 = null;
    java.math.BigInteger var39 = org.apache.commons.math3.util.ArithmeticUtils.pow(var37, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var41 = new org.apache.commons.math3.exception.OutOfRangeException(var35, (java.lang.Number)100.0f, (java.lang.Number)var39, (java.lang.Number)0.5000672346092545d);
    java.math.BigInteger var42 = org.apache.commons.math3.util.ArithmeticUtils.pow(var32, var39);
    org.apache.commons.math3.exception.util.Localizable var43 = null;
    java.lang.Object[] var46 = new java.lang.Object[] { '4'};
    org.apache.commons.math3.exception.MaxCountExceededException var47 = new org.apache.commons.math3.exception.MaxCountExceededException(var43, (java.lang.Number)Double.NaN, var46);
    java.lang.Throwable[] var48 = var47.getSuppressed();
    org.apache.commons.math3.exception.MaxCountExceededException var49 = new org.apache.commons.math3.exception.MaxCountExceededException(var27, (java.lang.Number)var32, (java.lang.Object[])var48);
    org.apache.commons.math3.exception.MaxCountExceededException var50 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)var32);
    org.apache.commons.math3.exception.util.Localizable var51 = null;
    java.lang.Object[] var54 = new java.lang.Object[] { '4'};
    org.apache.commons.math3.exception.MaxCountExceededException var55 = new org.apache.commons.math3.exception.MaxCountExceededException(var51, (java.lang.Number)Double.NaN, var54);
    java.lang.Throwable[] var56 = var55.getSuppressed();
    org.apache.commons.math3.exception.MaxCountExceededException var57 = new org.apache.commons.math3.exception.MaxCountExceededException(var26, (java.lang.Number)var32, (java.lang.Object[])var56);
    org.apache.commons.math3.exception.NumberIsTooLargeException var60 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var25, (java.lang.Number)var32, (java.lang.Number)7.73868401503849E-14d, true);
    java.math.BigInteger var61 = org.apache.commons.math3.util.ArithmeticUtils.pow(var24, var32);
    java.math.BigInteger var63 = org.apache.commons.math3.util.ArithmeticUtils.pow(var24, 88);
    java.math.BigInteger var65 = org.apache.commons.math3.util.ArithmeticUtils.pow(var63, 90L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);

  }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test498"); }


    double var2 = org.apache.commons.math3.util.FastMath.min((-2.400188641955425d), 0.6040929060689716d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-2.400188641955425d));

  }

  public void test499() {}
//   public void test499() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test499"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     double var4 = var0.nextExponential(0.056182176564052d);
//     double var7 = var0.nextGamma((-2.0537907646431078E43d), 5.840802579076462E13d);
//     double var10 = var0.nextF(0.03673319830899499d, 2.6881171418161356E43d);
//     java.lang.String var12 = var0.nextSecureHexString(66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "4cefb3556f7396d80895c81020075fe77036a5a9ed09c49b9af8a499cf779c3ece8d52615b675f81a2604db57ec4bea8492c"+ "'", var2.equals("4cefb3556f7396d80895c81020075fe77036a5a9ed09c49b9af8a499cf779c3ece8d52615b675f81a2604db57ec4bea8492c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.013371683042039914d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "96c9abfc3a53b4c90932cd1319df273e201f79e8a0169540c9e1d9b48cb5766dd2"+ "'", var12.equals("96c9abfc3a53b4c90932cd1319df273e201f79e8a0169540c9e1d9b48cb5766dd2"));
// 
//   }

  public void test500() {}
//   public void test500() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test500"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy[] var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
//     org.apache.commons.math3.exception.MathInternalError var2 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var1);
//     org.apache.commons.math3.exception.util.Localizable var3 = null;
//     org.apache.commons.math3.exception.util.Localizable var4 = null;
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     org.apache.commons.math3.exception.util.Localizable var6 = null;
//     org.apache.commons.math3.exception.util.Localizable var7 = null;
//     org.apache.commons.math3.exception.util.Localizable var8 = null;
//     java.lang.Object[] var11 = new java.lang.Object[] { '4'};
//     org.apache.commons.math3.exception.MaxCountExceededException var12 = new org.apache.commons.math3.exception.MaxCountExceededException(var8, (java.lang.Number)Double.NaN, var11);
//     java.lang.Throwable[] var13 = var12.getSuppressed();
//     org.apache.commons.math3.exception.MathInternalError var14 = new org.apache.commons.math3.exception.MathInternalError(var7, (java.lang.Object[])var13);
//     org.apache.commons.math3.exception.MathArithmeticException var15 = new org.apache.commons.math3.exception.MathArithmeticException(var6, (java.lang.Object[])var13);
//     org.apache.commons.math3.exception.MathArithmeticException var16 = new org.apache.commons.math3.exception.MathArithmeticException(var5, (java.lang.Object[])var13);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var17 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var4, (java.lang.Object[])var13);
//     org.apache.commons.math3.exception.MathIllegalStateException var18 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var2, var3, (java.lang.Object[])var13);
// 
//   }

}
