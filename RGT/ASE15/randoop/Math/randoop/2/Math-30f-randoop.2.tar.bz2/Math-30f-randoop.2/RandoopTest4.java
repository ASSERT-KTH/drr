
import junit.framework.*;

public class RandoopTest4 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test1"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.contract();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setNumElements((-1820841394));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test2"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    double var6 = var3.cumulativeProbability(1.4210854715202004E-14d, 2.0d);
    boolean var7 = var3.isSupportConnected();
    double var8 = var3.getMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.9681911862806774E-44d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test3"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    int var4 = var3.getNumElements();
    double var6 = var3.addElementRolling(1.2982587902415216E14d);
    var3.setNumElements(3);
    int var9 = var3.getNumElements();
    var3.setElement(6, 1.1972693843357008E86d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 3);

  }

  public void test4() {}
//   public void test4() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test4"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP((-9.18479816376678E43d), 1.7964601481377767d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test5"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var2.clear();
    int var4 = var2.getExpansionMode();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.discardMostRecentElements((-105));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test6"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.4855570380544819d, 4.629628685877712E42d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test7"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray((-105));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test8"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)0.8636996284436825d);

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test9"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(0.0f, 4.9999995f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test10"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos((-2.791500647694174E42d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9694668376839274d);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test11"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    var3.reseedRandomGenerator(1L);
    boolean var6 = var3.isSupportConnected();
    double var7 = var3.getNumericalMean();
    var3.reseedRandomGenerator((-3941415383162945536L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test12"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var2 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathInternalError var3 = new org.apache.commons.math3.exception.MathInternalError(var1, (java.lang.Object[])var2);
    org.apache.commons.math3.exception.MathArithmeticException var4 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var2);
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var6 = var4.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var7 = var4.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test13"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs((-2.5228617716135773E-11d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.5228617716135773E-11d);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test14"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var5.getTiesStrategy();
    int var7 = var6.ordinal();
    java.lang.String var8 = var6.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var6);
    org.apache.commons.math3.stat.ranking.TiesStrategy var10 = var9.getTiesStrategy();
    java.lang.String var11 = var10.toString();
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    boolean var14 = var10.equals((java.lang.Object)1.2182346215488778E-22d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "AVERAGE"+ "'", var11.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test15"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(100, 100.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = var2.copy();
    var2.setExpansionFactor(2.0000005f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test16"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(2.5228617716135773E-11d, 0.9932436822052534d, 0.2379496012179797d, 12192000);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.9209371504696899d);

  }

  public void test17() {}
//   public void test17() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test17"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(2.0d);
//     var0.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.2048783586126193d);
// 
//   }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test18"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(0, 108);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test19"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution((-0.7949577687638787d), 7.315651600646374E86d, 7.381472028861085E-11d);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test20"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1((-0.21306319806090124d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.1918949350704374d));

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test21"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    java.lang.String var2 = var1.name();
    java.lang.String var3 = var1.name();
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var5.getTiesStrategy();
    int var7 = var6.ordinal();
    java.lang.String var8 = var6.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var6);
    java.lang.String var10 = var1.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "MAXIMAL"+ "'", var2.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "MAXIMAL"+ "'", var3.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "MAXIMAL"+ "'", var10.equals("MAXIMAL"));

  }

  public void test22() {}
//   public void test22() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test22"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     double var16 = var0.nextWeibull(1.0d, 1.6298598478788293d);
//     double var19 = var0.nextCauchy((-1.1440883267692863E33d), 3.3030345912774096E43d);
//     var0.reSeedSecure();
//     double var24 = var0.nextUniform(0.0d, 2.4188678176733584E-44d, true);
//     double var27 = var0.nextCauchy(0.0d, 2.2530284241517077E-8d);
//     var0.reSeedSecure();
//     java.lang.String var30 = var0.nextHexString(141);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "73fcf47be059608e27fd99f6b155d914269933300dbdd54659853a1de12f438bbd08361a4a1acac51f17d1ea91bdb54eb613"+ "'", var2.equals("73fcf47be059608e27fd99f6b155d914269933300dbdd54659853a1de12f438bbd08361a4a1acac51f17d1ea91bdb54eb613"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-3.732524721053539E41d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.13598794187750315d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-1.667065263824446E43d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 8.716897605503555E-45d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1.593959488655669E-8d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var30 + "' != '" + "2983f93855e9e38f55476c59e26ba8b0743a9d031cce11ae306d740307895a31297f0db87c27543d851ba44848736beba0194f3ed030a31128ee78fba357142bdcf05c4736567"+ "'", var30.equals("2983f93855e9e38f55476c59e26ba8b0743a9d031cce11ae306d740307895a31297f0db87c27543d851ba44848736beba0194f3ed030a31128ee78fba357142bdcf05c4736567"));
// 
//   }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test23"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(1612775, 100.5f, 99.99999f, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test24"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees((-0.4217216060310984d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-24.16286815506078d));

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test25"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(2.0484556054289236d, 0.06128730532108836d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-3.8937895592837686d));

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test26"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(0.05902633562621646d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.057349934701195336d);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test27"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(3941415383162945436L, 6L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-6890464530323402752L));

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test28"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(61, (-1820841394));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test29() {}
//   public void test29() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test29"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     var0.reSeed(1L);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var8 = var0.nextSecureInt(41453239, 10);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "60881b782aabee818ee19bad2bc590fe2a79be138f54c63132f389ab3be6cca8e34ca582f91469ae8d73f5a2432dc5f7e18d"+ "'", var2.equals("60881b782aabee818ee19bad2bc590fe2a79be138f54c63132f389ab3be6cca8e34ca582f91469ae8d73f5a2432dc5f7e18d"));
// 
//   }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test30"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(0.8739440070527092d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1L);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test31"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.NotPositiveException var7 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(short)1);
    java.lang.Object[] var8 = new java.lang.Object[] { (short)1};
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException(var5, var8);
    org.apache.commons.math3.exception.MathArithmeticException var10 = new org.apache.commons.math3.exception.MathArithmeticException(var4, var8);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException(var3, var8);
    org.apache.commons.math3.exception.MaxCountExceededException var12 = new org.apache.commons.math3.exception.MaxCountExceededException(var1, (java.lang.Number)(-0.24393093086615214d), var8);
    org.apache.commons.math3.exception.MathInternalError var13 = new org.apache.commons.math3.exception.MathInternalError(var0, var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test32"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    var3.reseedRandomGenerator(1L);
    boolean var6 = var3.isSupportConnected();
    double var7 = var3.getMean();
    double var8 = var3.getStandardDeviation();
    boolean var9 = var3.isSupportUpperBoundInclusive();
    boolean var10 = var3.isSupportConnected();
    double var12 = var3.inverseCumulativeProbability(0.06578711824213442d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var14 = var3.sample(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.6881171418161356E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-4.05347365262866E43d));

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test33"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(9.999999f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9.999999f);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test34"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)3.199763873047224E14d);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test35"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(0.027073110299788997d, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.027073110299788997d);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test36"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(61.385627560860215d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.7880667001042165d);

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test37"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0.6040929060689716d, (java.lang.Number)0.46474439745601875d, (java.lang.Number)(-4.888155648766879E43d));
    java.lang.Number var5 = var4.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-4.888155648766879E43d)+ "'", var5.equals((-4.888155648766879E43d)));

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test38"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(8.653057390823534E42d, 0.9640275797804917d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.5707963267948966d);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test39"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0L);

  }

  public void test40() {}
//   public void test40() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test40"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP((-100.92211084316018d), 0.9542512052939294d, 1.1265425086815431E43d, 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test41"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var5.getTiesStrategy();
    int var7 = var6.ordinal();
    java.lang.String var8 = var6.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var6);
    java.lang.String var10 = var6.name();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "AVERAGE"+ "'", var10.equals("AVERAGE"));

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test42"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(127000, 41453239);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 41580239);

  }

  public void test43() {}
//   public void test43() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test43"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.5606386275277436d), 3.5671315446818194E43d);
//     double var3 = var2.sample();
//     double var5 = var2.inverseCumulativeProbability(0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.4472475295846865E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == Double.NEGATIVE_INFINITY);
// 
//   }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test44"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    var3.reseedRandomGenerator(1L);
    boolean var6 = var3.isSupportConnected();
    double var7 = var3.getSupportLowerBound();
    double var8 = var3.getStandardDeviation();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.6881171418161356E43d);

  }

  public void test45() {}
//   public void test45() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test45"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     java.lang.String var4 = var0.nextHexString(110);
//     double var6 = var0.nextChiSquare(0.9865330122406505d);
//     var0.reSeedSecure(28798L);
//     var0.reSeedSecure((-3941415383162945536L));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var0.nextF(1.3418720970618036E43d, 0.29174783509481605d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.12252468220955516d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "c052fe14c712b6ffffd025c74a36ed3b32f148a731cb48d8661aca052638ac09b2b398f7f5c7af9276bd25cf39b93c23c4974b2c9ae5bc"+ "'", var4.equals("c052fe14c712b6ffffd025c74a36ed3b32f148a731cb48d8661aca052638ac09b2b398f7f5c7af9276bd25cf39b93c23c4974b2c9ae5bc"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.7749772921157636d);
// 
//   }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test46"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(102399.99f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test47"); }


    double var1 = org.apache.commons.math3.special.Erf.erf((-4.987930596591171d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.9999999999982615d));

  }

  public void test48() {}
//   public void test48() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test48"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     double var17 = var0.nextBeta(1.1265425086815434E43d, 1.1282937610745374d);
//     long var19 = var0.nextPoisson(31.402066659134473d);
//     long var22 = var0.nextLong((-9223372036854775808L), 2L);
//     double var25 = var0.nextGaussian(0.40394226160288377d, 0.9999999981643266d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var29 = var0.nextHypergeometric(1612820, 3, 1612900);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "55276708a0d9c266f7867dfbd7344d6808b24bbf1a1eb08435bf92128938e6655cd215a5c5f9ad1967e5a1bb4c6182836224"+ "'", var2.equals("55276708a0d9c266f7867dfbd7344d6808b24bbf1a1eb08435bf92128938e6655cd215a5c5f9ad1967e5a1bb4c6182836224"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-2.9585333928522687E43d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.9999999983898105d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 29L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == (-6903065488889305088L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0.8440025860325108d);
// 
//   }

  public void test49() {}
//   public void test49() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test49"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     double var16 = var0.nextWeibull(1.0d, 1.6298598478788293d);
//     double var19 = var0.nextCauchy((-1.1440883267692863E33d), 3.3030345912774096E43d);
//     var0.reSeedSecure();
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var24 = var0.nextF(3.7760951459250447d, 4.3062441011611504E86d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "a751a01c2e6b88a29208ff95a6c04dfea2b26c50ef6b724b6396063c3bbf6891f7bd45e43cdc6800ff8b479710a12e1e3df6"+ "'", var2.equals("a751a01c2e6b88a29208ff95a6c04dfea2b26c50ef6b724b6396063c3bbf6891f7bd45e43cdc6800ff8b479710a12e1e3df6"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 5.957133489844179E42d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1.7490414611891256d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 3.1464717321373367E43d);
// 
//   }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test50"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(2.305843E20f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.305843E20f);

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test51"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(0.06579561455862068d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.06584317950284949d);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test52"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(0);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test53"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.8917848940915326d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6280240339343796d);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test54"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    java.lang.String var2 = var1.name();
    java.lang.String var3 = var1.name();
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var5.getTiesStrategy();
    int var7 = var6.ordinal();
    java.lang.String var8 = var6.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var6);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    org.apache.commons.math3.stat.ranking.NaNStrategy var11 = var10.getNanStrategy();
    java.lang.String var12 = var11.toString();
    java.lang.String var13 = var11.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "MAXIMAL"+ "'", var2.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "MAXIMAL"+ "'", var3.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "MAXIMAL"+ "'", var12.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "MAXIMAL"+ "'", var13.equals("MAXIMAL"));

  }

  public void test55() {}
//   public void test55() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test55"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     double var17 = var0.nextGamma(0.9775852669347048d, 3.199763873047224E14d);
//     double var20 = var0.nextUniform(0.0d, 8.799063409660144E86d);
//     var0.reSeed();
//     org.apache.commons.math3.distribution.NormalDistribution var22 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var23 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var22);
//     double var25 = var22.probability(0.07181691598288088d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "959851d1b1dc7c592cd6236b9386c47005e2478529b7b24169b55f218a9c1fbc49636fafff2d3d436e1a671b6b6f1960f7ef"+ "'", var2.equals("959851d1b1dc7c592cd6236b9386c47005e2478529b7b24169b55f218a9c1fbc49636fafff2d3d436e1a671b6b6f1960f7ef"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-1.4960727933539617E43d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.2302936875868355E14d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 5.106597054040568E86d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == (-0.5565504460069642d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0.0d);
// 
//   }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test56"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(2.3841858E-7f, 0.8209031109473406d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.384186E-7f);

  }

  public void test57() {}
//   public void test57() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test57"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(100.36238681490227d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test58"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(1.4E-45f, 99.99999f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.4E-45f);

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test59"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(0.8739440070527092d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7668661862484337d);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test60"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double[] var2 = var0.sample(1);
    double var3 = var0.getMean();
    boolean var4 = var0.isSupportUpperBoundInclusive();
    boolean var5 = var0.isSupportUpperBoundInclusive();
    double var8 = var0.cumulativeProbability(1.3626999595542073d, 5.458802422386986E43d);
    double var9 = var0.getMean();
    double var10 = var0.getStandardDeviation();
    double var11 = var0.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.08648854529952615d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test61"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(1.021295736467202d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test62() {}
//   public void test62() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test62"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log((-3.2812801842882495E42d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test63"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    var3.reseedRandomGenerator(1L);
    boolean var6 = var3.isSupportConnected();
    boolean var7 = var3.isSupportLowerBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test64"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble((-90));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test65"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-3941415383162945536L), 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-3941415383162945536L));

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test66"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)25019000, (java.lang.Number)2.165822100505927E44d, false);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test67"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray((-66), 1.0f, 100.0f, 2068);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test68"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = var3.copy();
    double var6 = var3.addElementRolling(0.3088209685048367d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var3.getElement(4233);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test69"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-238.09832457991453d), 6.743438587337678E86d);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test70"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder((-1.1906467697349786E43d), 8.799063409660144E86d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.1906467697349786E43d));

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test71"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(2432902008176640000L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test72"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = var2.copy();
    var2.addElement(0.0018388436884212223d);
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.NoDataException var7 = new org.apache.commons.math3.exception.NoDataException(var6);
    boolean var8 = var2.equals((java.lang.Object)var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test73"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.NotPositiveException var7 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(short)1);
    java.lang.Object[] var8 = new java.lang.Object[] { (short)1};
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException(var5, var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var4, var8);
    java.lang.Object[] var11 = new java.lang.Object[] { var8};
    org.apache.commons.math3.exception.MathInternalError var12 = new org.apache.commons.math3.exception.MathInternalError(var3, var11);
    org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, var11);
    org.apache.commons.math3.exception.MaxCountExceededException var14 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, var1, var11);
    java.lang.Number var15 = var14.getMax();
    java.lang.Throwable[] var16 = var14.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test74"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    java.lang.String var2 = var1.name();
    java.lang.String var3 = var1.toString();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var5.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var8 = var7.getNanStrategy();
    java.lang.String var9 = var8.name();
    java.lang.String var10 = var8.name();
    org.apache.commons.math3.stat.ranking.NaNStrategy var11 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11);
    org.apache.commons.math3.stat.ranking.TiesStrategy var13 = var12.getTiesStrategy();
    int var14 = var13.ordinal();
    java.lang.String var15 = var13.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8, var13);
    double[] var18 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray(var18);
    var19.setContractionCriteria(50.000008f);
    var19.setExpansionMode(0);
    boolean var24 = var13.equals((java.lang.Object)var19);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var25 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var6, var13);
    org.apache.commons.math3.stat.ranking.NaturalRanking var26 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var13);
    org.apache.commons.math3.util.ResizableDoubleArray var27 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var27.addElement(0.02797455810085192d);
    var27.discardFrontElements(1);
    org.apache.commons.math3.util.ResizableDoubleArray var32 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var33 = var32.getInternalValues();
    var27.addElements(var33);
    double[] var35 = var26.rank(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "MAXIMAL"+ "'", var2.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "MAXIMAL"+ "'", var3.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "MAXIMAL"+ "'", var9.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "MAXIMAL"+ "'", var10.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "AVERAGE"+ "'", var15.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test75"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(0.027442915639507723d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.7896923425645504E-4d);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test76"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    java.lang.String var2 = var1.name();
    java.lang.String var3 = var1.name();
    boolean var5 = var1.equals((java.lang.Object)"bbc76c98706e096cbdb48c11be18b37feafe094ae0e5291b81fe65cbd0c42cc6f465c322de0f5afaf8fdd0237c92d0d9c2d6");
    int var6 = var1.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var8 = var7.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var9 = var7.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var10 = var7.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var11 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var10);
    double[] var12 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var13.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var15.setContractionCriteria(5.0f);
    var15.setElement(110, Double.NaN);
    var15.setElement(100, (-0.6120891811851691d));
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var13, var15);
    org.apache.commons.math3.stat.ranking.NaturalRanking var25 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var26 = var25.getNanStrategy();
    java.lang.String var27 = var26.name();
    java.lang.String var28 = var26.name();
    org.apache.commons.math3.stat.ranking.NaNStrategy var29 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var30 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var29);
    org.apache.commons.math3.stat.ranking.TiesStrategy var31 = var30.getTiesStrategy();
    int var32 = var31.ordinal();
    java.lang.String var33 = var31.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var34 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var26, var31);
    org.apache.commons.math3.stat.ranking.NaNStrategy var35 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var36 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var35);
    org.apache.commons.math3.stat.ranking.TiesStrategy var37 = var36.getTiesStrategy();
    int var38 = var37.ordinal();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var39 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var26, var37);
    double[] var41 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var42 = new org.apache.commons.math3.util.ResizableDoubleArray(var41);
    var42.setContractionCriteria(50.000008f);
    double[] var45 = var42.getInternalValues();
    double[] var46 = var42.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var47 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var47.addElement(0.02797455810085192d);
    var47.discardFrontElements(1);
    org.apache.commons.math3.util.ResizableDoubleArray var52 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var53 = var52.getInternalValues();
    var47.addElements(var53);
    double var55 = var39.mannWhitneyUTest(var46, var53);
    var13.addElements(var53);
    double var58 = var13.substituteMostRecentElement(4.9E-324d);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var59 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var61 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var62 = new org.apache.commons.math3.util.ResizableDoubleArray(var61);
    var62.setContractionCriteria(50.000008f);
    double[] var65 = var62.getInternalValues();
    double[] var67 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var68 = new org.apache.commons.math3.util.ResizableDoubleArray(var67);
    var68.setContractionCriteria(50.000008f);
    double[] var71 = var68.getInternalValues();
    double[] var72 = var68.getElements();
    double var73 = var59.mannWhitneyUTest(var65, var72);
    var13.addElements(var65);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var75 = var11.mannWhitneyU(var12, var65);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "MAXIMAL"+ "'", var2.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "MAXIMAL"+ "'", var3.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + "MAXIMAL"+ "'", var27.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + "MAXIMAL"+ "'", var28.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var33 + "' != '" + "AVERAGE"+ "'", var33.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 0.10247043485974927d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 1.0d);

  }

  public void test77() {}
//   public void test77() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test77"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     java.lang.String var4 = var0.nextHexString(110);
//     int var7 = var0.nextPascal(3, 0.0d);
//     int var10 = var0.nextSecureInt(47, 110);
//     var0.reSeedSecure(300L);
//     long var15 = var0.nextSecureLong(0L, 28798L);
//     double var18 = var0.nextGamma(3.6395368604275045d, 2.376313347579354E14d);
//     java.util.Collection var19 = null;
//     java.lang.Object[] var21 = var0.nextSample(var19, 478245873);
// 
//   }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test78"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(0.6572681123794027d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1102230246251565E-16d);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test79"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)0.06584317950284949d);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test80"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(0.19845492814580867d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.19978124149713752d);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test81"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(3.1920703896089355E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.018289216123327234d);

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test82"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("4f728e6622cc084ccd5444f2b997bd676f88e1715b6155232d2db95a6b332c41ea75a909ac1b4dffa9b06cf33caaf19a637f");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test83"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(3.7760951459250447d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0038247688401145d);

  }

  public void test84() {}
//   public void test84() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test84"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     double var5 = var0.nextGaussian(0.0d, 0.5d);
//     var0.reSeed(10L);
//     double var9 = var0.nextExponential(2.0000008411562833d);
//     var0.reSeed();
//     var0.reSeedSecure(115975288207988L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.7039456256636542d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-0.14494411636981122d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2.656500765412644d);
// 
//   }

  public void test85() {}
//   public void test85() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test85"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     double var5 = var0.nextGaussian(0.0d, 0.5d);
//     var0.reSeed(10L);
//     double var10 = var0.nextGamma(0.0376197072270027d, 11.672233456208478d);
//     int var13 = var0.nextSecureInt(127000, 1612773);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var16 = var0.nextUniform(0.9898371621797909d, 0.3557777882532073d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.39126308423839173d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.5549334343754149d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 7.913970955867624E-10d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1592177);
// 
//   }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test86"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(1.3629014047559318d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.081715665113474d);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test87"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var1 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var3 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var4.setContractionCriteria(50.000008f);
    double[] var7 = var4.getInternalValues();
    double[] var9 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(var9);
    var10.setContractionCriteria(50.000008f);
    double[] var13 = var10.getInternalValues();
    double[] var14 = var10.getElements();
    double var15 = var1.mannWhitneyUTest(var7, var14);
    org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    org.apache.commons.math3.util.ResizableDoubleArray var17 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var17.addElement(0.02797455810085192d);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var20 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var22 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var23 = new org.apache.commons.math3.util.ResizableDoubleArray(var22);
    var23.setContractionCriteria(50.000008f);
    double[] var26 = var23.getInternalValues();
    double[] var28 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var29 = new org.apache.commons.math3.util.ResizableDoubleArray(var28);
    var29.setContractionCriteria(50.000008f);
    double[] var32 = var29.getInternalValues();
    double[] var33 = var29.getElements();
    double var34 = var20.mannWhitneyU(var26, var33);
    var17.addElements(var26);
    var16.addElements(var26);
    double[] var38 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var39 = new org.apache.commons.math3.util.ResizableDoubleArray(var38);
    org.apache.commons.math3.util.ResizableDoubleArray var40 = var39.copy();
    var39.addElement(0.0018388436884212223d);
    double[] var43 = var39.getElements();
    double var44 = var0.mannWhitneyU(var26, var43);
    org.apache.commons.math3.util.ResizableDoubleArray var45 = new org.apache.commons.math3.util.ResizableDoubleArray(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 1.5d);

  }

  public void test88() {}
//   public void test88() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test88"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     boolean var14 = var6.isSupportLowerBoundInclusive();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "72c9e854255027451bd82d6ed126a91c4e5f128ab32d3454445b9c68745d379c91e4d357d05ffb1e9a4bc6ff809d9e2f4cb8"+ "'", var2.equals("72c9e854255027451bd82d6ed126a91c4e5f128ab32d3454445b9c68745d379c91e4d357d05ffb1e9a4bc6ff809d9e2f4cb8"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-2.532143254224199E43d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
// 
//   }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test89"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(6, 1496370343);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test90"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(1.3872175661331396d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1152738684267403d);

  }

  public void test91() {}
//   public void test91() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test91"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     double var17 = var0.nextGamma(0.9775852669347048d, 3.199763873047224E14d);
//     double var20 = var0.nextF(2.636818730233018d, 1.1282937610745374d);
//     var0.reSeed(6L);
//     var0.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "3e9ab4aed2a6637f92b00d2c821bb8e6261b6d60e820a21b6dd4776fdc85c8727f4a85656d29a0846092b4b8e4e5c5d7a229"+ "'", var2.equals("3e9ab4aed2a6637f92b00d2c821bb8e6261b6d60e820a21b6dd4776fdc85c8727f4a85656d29a0846092b4b8e4e5c5d7a229"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 5.95573570720202E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.2752953113385888E15d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 7.427714241928977d);
// 
//   }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test92"); }


    java.lang.Throwable var0 = null;
    org.apache.commons.math3.exception.MathInternalError var1 = new org.apache.commons.math3.exception.MathInternalError(var0);

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test93"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(69L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test94"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.math.BigInteger var2 = null;
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var6 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)100.0f, (java.lang.Number)var4, (java.lang.Number)0.5000672346092545d);
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    java.math.BigInteger var9 = null;
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var13 = new org.apache.commons.math3.exception.OutOfRangeException(var7, (java.lang.Number)100.0f, (java.lang.Number)var11, (java.lang.Number)0.5000672346092545d);
    java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, var11);
    java.math.BigInteger var16 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 10L);
    org.apache.commons.math3.exception.util.Localizable var17 = null;
    java.math.BigInteger var19 = null;
    java.math.BigInteger var21 = org.apache.commons.math3.util.ArithmeticUtils.pow(var19, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var23 = new org.apache.commons.math3.exception.OutOfRangeException(var17, (java.lang.Number)100.0f, (java.lang.Number)var21, (java.lang.Number)0.5000672346092545d);
    org.apache.commons.math3.exception.util.Localizable var24 = null;
    java.math.BigInteger var26 = null;
    java.math.BigInteger var28 = org.apache.commons.math3.util.ArithmeticUtils.pow(var26, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var30 = new org.apache.commons.math3.exception.OutOfRangeException(var24, (java.lang.Number)100.0f, (java.lang.Number)var28, (java.lang.Number)0.5000672346092545d);
    java.math.BigInteger var31 = org.apache.commons.math3.util.ArithmeticUtils.pow(var21, var28);
    java.math.BigInteger var33 = org.apache.commons.math3.util.ArithmeticUtils.pow(var21, 12700);
    java.math.BigInteger var35 = org.apache.commons.math3.util.ArithmeticUtils.pow(var33, 768793337);
    java.math.BigInteger var36 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, var33);
    java.math.BigInteger var38 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 111);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test95"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)1.1265425086815431E43d, (java.lang.Number)(-8.679894338181829E64d));

  }

  public void test96() {}
//   public void test96() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test96"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     double var16 = var0.nextWeibull(1.0d, 1.6298598478788293d);
//     double var19 = var0.nextWeibull(1.151569395337692d, 7.22597376812575E86d);
//     double var22 = var0.nextGaussian(1.9999999958199324d, 1.021295736467202d);
//     java.util.Collection var23 = null;
//     java.lang.Object[] var25 = var0.nextSample(var23, 657919);
// 
//   }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test97"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.distribution.NormalDistribution var7 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    double var8 = var7.getSupportLowerBound();
    double var10 = var7.probability(6.419286864170918E43d);
    double var12 = var7.cumulativeProbability((-3.4611764310781617E43d));
    double var14 = var7.cumulativeProbability((-1.854385601600511E39d));
    boolean var15 = var3.equals((java.lang.Object)var14);
    org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.098945418308171d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.4999724791450286d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test98"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    int var3 = var2.ordinal();
    java.lang.String var4 = var2.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var6 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var8 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
    var9.setContractionCriteria(50.000008f);
    double[] var12 = var9.getInternalValues();
    double[] var14 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    var15.setContractionCriteria(50.000008f);
    double[] var18 = var15.getInternalValues();
    double[] var19 = var15.getElements();
    double var20 = var6.mannWhitneyU(var12, var19);
    double[] var21 = var5.rank(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "AVERAGE"+ "'", var4.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test99"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test100"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    var3.reseedRandomGenerator(1L);
    boolean var6 = var3.isSupportConnected();
    double var7 = var3.getMean();
    double var8 = var3.getMean();
    var3.reseedRandomGenerator(0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test101"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(0.9999999985344893d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999999985344894d);

  }

  public void test102() {}
//   public void test102() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test102"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     double var16 = var0.nextWeibull(1.0d, 1.6298598478788293d);
//     double var19 = var0.nextWeibull(1.151569395337692d, 7.22597376812575E86d);
//     org.apache.commons.math3.distribution.NormalDistribution var23 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var23.reseedRandomGenerator(1L);
//     double var27 = var23.probability(0.0d);
//     double var28 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "4966a50857aa70ecdfd1e30519e2a1b0ba41027bb0f194079590e6c746bbdd6701d1d304948576f98fb145e05025c3111a01"+ "'", var2.equals("4966a50857aa70ecdfd1e30519e2a1b0ba41027bb0f194079590e6c746bbdd6701d1d304948576f98fb145e05025c3111a01"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.1918184733241577E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 2.901948501621551d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 9.190337322292875E86d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == (-4.991268808249555E43d));
// 
//   }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test103"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)2.0449601877417578E15d, (java.lang.Number)3.0126600184580075E213d, true);
    java.lang.Number var4 = var3.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 3.0126600184580075E213d+ "'", var4.equals(3.0126600184580075E213d));

  }

  public void test104() {}
//   public void test104() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test104"); }
// 
// 
//     org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     var0.setContractionCriteria(5.0f);
//     var0.setElement(110, Double.NaN);
//     var0.discardFrontElements(10);
//     org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     var8.setContractionCriteria(50.000008f);
//     org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var8);
//     org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
//     double var14 = var8.substituteMostRecentElement(6.136369304788742E42d);
//     org.apache.commons.math3.exception.util.Localizable var15 = null;
//     org.apache.commons.math3.exception.util.Localizable var16 = null;
//     java.math.BigInteger var18 = null;
//     java.math.BigInteger var20 = org.apache.commons.math3.util.ArithmeticUtils.pow(var18, 0L);
//     org.apache.commons.math3.exception.OutOfRangeException var22 = new org.apache.commons.math3.exception.OutOfRangeException(var16, (java.lang.Number)100.0f, (java.lang.Number)var20, (java.lang.Number)0.5000672346092545d);
//     org.apache.commons.math3.exception.util.Localizable var23 = null;
//     java.math.BigInteger var25 = null;
//     java.math.BigInteger var27 = org.apache.commons.math3.util.ArithmeticUtils.pow(var25, 0L);
//     org.apache.commons.math3.exception.OutOfRangeException var29 = new org.apache.commons.math3.exception.OutOfRangeException(var23, (java.lang.Number)100.0f, (java.lang.Number)var27, (java.lang.Number)0.5000672346092545d);
//     java.math.BigInteger var30 = org.apache.commons.math3.util.ArithmeticUtils.pow(var20, var27);
//     java.math.BigInteger var32 = org.apache.commons.math3.util.ArithmeticUtils.pow(var20, 10L);
//     org.apache.commons.math3.exception.NotStrictlyPositiveException var33 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var15, (java.lang.Number)var32);
//     org.apache.commons.math3.exception.util.Localizable var36 = null;
//     java.math.BigInteger var38 = null;
//     java.math.BigInteger var40 = org.apache.commons.math3.util.ArithmeticUtils.pow(var38, 0L);
//     org.apache.commons.math3.exception.OutOfRangeException var42 = new org.apache.commons.math3.exception.OutOfRangeException(var36, (java.lang.Number)100.0f, (java.lang.Number)var40, (java.lang.Number)0.5000672346092545d);
//     org.apache.commons.math3.exception.util.Localizable var43 = null;
//     java.math.BigInteger var45 = null;
//     java.math.BigInteger var47 = org.apache.commons.math3.util.ArithmeticUtils.pow(var45, 0L);
//     org.apache.commons.math3.exception.OutOfRangeException var49 = new org.apache.commons.math3.exception.OutOfRangeException(var43, (java.lang.Number)100.0f, (java.lang.Number)var47, (java.lang.Number)0.5000672346092545d);
//     java.math.BigInteger var50 = org.apache.commons.math3.util.ArithmeticUtils.pow(var40, var47);
//     java.math.BigInteger var52 = org.apache.commons.math3.util.ArithmeticUtils.pow(var40, 31L);
//     org.apache.commons.math3.exception.OutOfRangeException var53 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)8.799063409660144E86d, (java.lang.Number)0.99999994f, (java.lang.Number)var40);
//     java.math.BigInteger var54 = org.apache.commons.math3.util.ArithmeticUtils.pow(var32, var40);
//     java.math.BigInteger var56 = org.apache.commons.math3.util.ArithmeticUtils.pow(var54, 145);
//     boolean var57 = var8.equals((java.lang.Object)var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == false);
// 
//   }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test105"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.math.BigInteger var2 = null;
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var6 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)100.0f, (java.lang.Number)var4, (java.lang.Number)0.5000672346092545d);
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    java.math.BigInteger var9 = null;
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var13 = new org.apache.commons.math3.exception.OutOfRangeException(var7, (java.lang.Number)100.0f, (java.lang.Number)var11, (java.lang.Number)0.5000672346092545d);
    java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, var11);
    java.math.BigInteger var16 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 31L);
    org.apache.commons.math3.exception.util.Localizable var19 = null;
    java.math.BigInteger var21 = null;
    java.math.BigInteger var23 = org.apache.commons.math3.util.ArithmeticUtils.pow(var21, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var25 = new org.apache.commons.math3.exception.OutOfRangeException(var19, (java.lang.Number)100.0f, (java.lang.Number)var23, (java.lang.Number)0.5000672346092545d);
    org.apache.commons.math3.exception.util.Localizable var26 = null;
    java.math.BigInteger var28 = null;
    java.math.BigInteger var30 = org.apache.commons.math3.util.ArithmeticUtils.pow(var28, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var32 = new org.apache.commons.math3.exception.OutOfRangeException(var26, (java.lang.Number)100.0f, (java.lang.Number)var30, (java.lang.Number)0.5000672346092545d);
    java.math.BigInteger var33 = org.apache.commons.math3.util.ArithmeticUtils.pow(var23, var30);
    java.math.BigInteger var35 = org.apache.commons.math3.util.ArithmeticUtils.pow(var23, 31L);
    org.apache.commons.math3.exception.OutOfRangeException var36 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)8.799063409660144E86d, (java.lang.Number)0.99999994f, (java.lang.Number)var23);
    java.math.BigInteger var37 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, var23);
    org.apache.commons.math3.exception.util.Localizable var38 = null;
    org.apache.commons.math3.exception.util.Localizable var39 = null;
    java.math.BigInteger var41 = null;
    java.math.BigInteger var43 = org.apache.commons.math3.util.ArithmeticUtils.pow(var41, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var45 = new org.apache.commons.math3.exception.OutOfRangeException(var39, (java.lang.Number)100.0f, (java.lang.Number)var43, (java.lang.Number)0.5000672346092545d);
    org.apache.commons.math3.exception.util.Localizable var46 = null;
    java.math.BigInteger var48 = null;
    java.math.BigInteger var50 = org.apache.commons.math3.util.ArithmeticUtils.pow(var48, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var52 = new org.apache.commons.math3.exception.OutOfRangeException(var46, (java.lang.Number)100.0f, (java.lang.Number)var50, (java.lang.Number)0.5000672346092545d);
    java.math.BigInteger var53 = org.apache.commons.math3.util.ArithmeticUtils.pow(var43, var50);
    java.math.BigInteger var55 = org.apache.commons.math3.util.ArithmeticUtils.pow(var43, 10L);
    org.apache.commons.math3.exception.NotStrictlyPositiveException var56 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var38, (java.lang.Number)var55);
    org.apache.commons.math3.exception.util.Localizable var59 = null;
    java.math.BigInteger var61 = null;
    java.math.BigInteger var63 = org.apache.commons.math3.util.ArithmeticUtils.pow(var61, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var65 = new org.apache.commons.math3.exception.OutOfRangeException(var59, (java.lang.Number)100.0f, (java.lang.Number)var63, (java.lang.Number)0.5000672346092545d);
    org.apache.commons.math3.exception.util.Localizable var66 = null;
    java.math.BigInteger var68 = null;
    java.math.BigInteger var70 = org.apache.commons.math3.util.ArithmeticUtils.pow(var68, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var72 = new org.apache.commons.math3.exception.OutOfRangeException(var66, (java.lang.Number)100.0f, (java.lang.Number)var70, (java.lang.Number)0.5000672346092545d);
    java.math.BigInteger var73 = org.apache.commons.math3.util.ArithmeticUtils.pow(var63, var70);
    java.math.BigInteger var75 = org.apache.commons.math3.util.ArithmeticUtils.pow(var63, 31L);
    org.apache.commons.math3.exception.OutOfRangeException var76 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)8.799063409660144E86d, (java.lang.Number)0.99999994f, (java.lang.Number)var63);
    java.math.BigInteger var77 = org.apache.commons.math3.util.ArithmeticUtils.pow(var55, var63);
    java.math.BigInteger var79 = org.apache.commons.math3.util.ArithmeticUtils.pow(var77, 145);
    org.apache.commons.math3.exception.util.Localizable var80 = null;
    java.math.BigInteger var82 = null;
    java.math.BigInteger var84 = org.apache.commons.math3.util.ArithmeticUtils.pow(var82, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var86 = new org.apache.commons.math3.exception.OutOfRangeException(var80, (java.lang.Number)100.0f, (java.lang.Number)var84, (java.lang.Number)0.5000672346092545d);
    org.apache.commons.math3.exception.util.Localizable var87 = null;
    java.math.BigInteger var89 = null;
    java.math.BigInteger var91 = org.apache.commons.math3.util.ArithmeticUtils.pow(var89, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var93 = new org.apache.commons.math3.exception.OutOfRangeException(var87, (java.lang.Number)100.0f, (java.lang.Number)var91, (java.lang.Number)0.5000672346092545d);
    java.math.BigInteger var94 = org.apache.commons.math3.util.ArithmeticUtils.pow(var84, var91);
    java.math.BigInteger var96 = org.apache.commons.math3.util.ArithmeticUtils.pow(var84, 31L);
    java.math.BigInteger var97 = org.apache.commons.math3.util.ArithmeticUtils.pow(var77, var96);
    java.math.BigInteger var98 = org.apache.commons.math3.util.ArithmeticUtils.pow(var23, var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var96);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var97);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var98);

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test106"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb((-1.0f), 645781746);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.NEGATIVE_INFINITY);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test107"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(23333L, 23333L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 23333L);

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test108"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(7.312818360484666E-46d, 3.1596484740079465d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.434301530723388E-143d);

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test109"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(102, 1612922);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test110"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var2.setContractionCriteria(50.000008f);
    var2.setExpansionMode(0);
    var2.setContractionCriteria(5.0f);
    double[] var10 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var10);
    var11.setContractionCriteria(50.000008f);
    double[] var14 = var11.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var11);
    boolean var16 = var2.equals((java.lang.Object)var11);
    float var17 = var2.getContractionCriteria();
    double[] var18 = var2.getInternalValues();
    double var20 = var2.substituteMostRecentElement(0.9929760443723394d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 5.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test111"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(0.6933118728172234d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.15907136253762771d));

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test112"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(99.99999f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.6293945E-6f);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test113"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(1.1280340320127148E14d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test114() {}
//   public void test114() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test114"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     double var16 = var0.nextWeibull(1.0d, 1.6298598478788293d);
//     double var19 = var0.nextWeibull(1.151569395337692d, 7.22597376812575E86d);
//     double var22 = var0.nextGaussian(1.9999999958199324d, 1.021295736467202d);
//     long var25 = var0.nextSecureLong((-7910424700440438784L), 6L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "943d8e94033d752ac0189bb520d471a4d4e12467e19532c4b351391e1e7597d7d1e1e4721d8276581c52c65ad7b239a50973"+ "'", var2.equals("943d8e94033d752ac0189bb520d471a4d4e12467e19532c4b351391e1e7597d7d1e1e4721d8276581c52c65ad7b239a50973"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-1.7690799922998326E43d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 2.012472290565982d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 5.600112593788973E86d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 3.912173132723393d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == (-937694931342098688L));
// 
//   }

  public void test115() {}
//   public void test115() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test115"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     double var16 = var0.nextWeibull(1.0d, 1.6298598478788293d);
//     double var19 = var0.nextCauchy((-1.1440883267692863E33d), 3.3030345912774096E43d);
//     var0.reSeedSecure();
//     java.lang.String var22 = var0.nextSecureHexString(31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "6eb41f855eae254f4f3fe9702bc432d5abb1b7e5f49872c1b5f919264c093966ae49f73a3c0d827db2f92b81ce9ded7933c2"+ "'", var2.equals("6eb41f855eae254f4f3fe9702bc432d5abb1b7e5f49872c1b5f919264c093966ae49f73a3c0d827db2f92b81ce9ded7933c2"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 2.752038709078844E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.9611394445799705d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1.174518891015242E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var22 + "' != '" + "5eab3ffb848dff2a8c41787fab234f4"+ "'", var22.equals("5eab3ffb848dff2a8c41787fab234f4"));
// 
//   }

  public void test116() {}
//   public void test116() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test116"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     java.math.BigInteger var3 = null;
//     java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0L);
//     org.apache.commons.math3.exception.OutOfRangeException var7 = new org.apache.commons.math3.exception.OutOfRangeException(var1, (java.lang.Number)100.0f, (java.lang.Number)var5, (java.lang.Number)0.5000672346092545d);
//     org.apache.commons.math3.exception.util.Localizable var8 = null;
//     java.math.BigInteger var10 = null;
//     java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var10, 0L);
//     org.apache.commons.math3.exception.OutOfRangeException var14 = new org.apache.commons.math3.exception.OutOfRangeException(var8, (java.lang.Number)100.0f, (java.lang.Number)var12, (java.lang.Number)0.5000672346092545d);
//     java.math.BigInteger var15 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, var12);
//     java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 10L);
//     org.apache.commons.math3.exception.NotStrictlyPositiveException var18 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)var17);
//     org.apache.commons.math3.exception.util.Localizable var21 = null;
//     java.math.BigInteger var23 = null;
//     java.math.BigInteger var25 = org.apache.commons.math3.util.ArithmeticUtils.pow(var23, 0L);
//     org.apache.commons.math3.exception.OutOfRangeException var27 = new org.apache.commons.math3.exception.OutOfRangeException(var21, (java.lang.Number)100.0f, (java.lang.Number)var25, (java.lang.Number)0.5000672346092545d);
//     org.apache.commons.math3.exception.util.Localizable var28 = null;
//     java.math.BigInteger var30 = null;
//     java.math.BigInteger var32 = org.apache.commons.math3.util.ArithmeticUtils.pow(var30, 0L);
//     org.apache.commons.math3.exception.OutOfRangeException var34 = new org.apache.commons.math3.exception.OutOfRangeException(var28, (java.lang.Number)100.0f, (java.lang.Number)var32, (java.lang.Number)0.5000672346092545d);
//     java.math.BigInteger var35 = org.apache.commons.math3.util.ArithmeticUtils.pow(var25, var32);
//     java.math.BigInteger var37 = org.apache.commons.math3.util.ArithmeticUtils.pow(var25, 31L);
//     org.apache.commons.math3.exception.OutOfRangeException var38 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)8.799063409660144E86d, (java.lang.Number)0.99999994f, (java.lang.Number)var25);
//     java.math.BigInteger var39 = org.apache.commons.math3.util.ArithmeticUtils.pow(var17, var25);
//     java.math.BigInteger var41 = org.apache.commons.math3.util.ArithmeticUtils.pow(var17, 988L);
//     java.math.BigInteger var43 = org.apache.commons.math3.util.ArithmeticUtils.pow(var41, 10);
//     java.math.BigInteger var45 = org.apache.commons.math3.util.ArithmeticUtils.pow(var43, 27898L);
//     java.math.BigInteger var46 = null;
//     java.math.BigInteger var47 = org.apache.commons.math3.util.ArithmeticUtils.pow(var43, var46);
// 
//   }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test117"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc((-4.08494790682465E129d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0d);

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test118"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)10.0d);
    java.lang.Number var2 = var1.getMax();
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Object[] var6 = new java.lang.Object[] { '4'};
    org.apache.commons.math3.exception.MaxCountExceededException var7 = new org.apache.commons.math3.exception.MaxCountExceededException(var3, (java.lang.Number)Double.NaN, var6);
    org.apache.commons.math3.exception.util.ExceptionContext var8 = var7.getContext();
    var1.addSuppressed((java.lang.Throwable)var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 10.0d+ "'", var2.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test119"); }


    double var1 = org.apache.commons.math3.special.Erf.erf((-1.4960727933539617E43d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test120"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(102, 645781746);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test121"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var2.setContractionCriteria(50.000008f);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = var2.copy();
    int var6 = var5.start();
    int var7 = var5.getNumElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test122"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(102248832, 96);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 96);

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test123"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    var3.reseedRandomGenerator(1L);
    double var7 = var3.cumulativeProbability(0.0d);
    double var8 = var3.getStandardDeviation();
    double[] var10 = var3.sample(1612900);
    double var11 = var3.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.6881171418161356E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test124"); }


    double var2 = org.apache.commons.math3.util.FastMath.max((-0.14494411636981122d), 0.9694668376839274d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9694668376839274d);

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test125"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint((-2.5228617716135773E-11d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.0d));

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test126"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var3 = new java.lang.Object[] { '4'};
    org.apache.commons.math3.exception.MaxCountExceededException var4 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)Double.NaN, var3);
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
    java.lang.Number var6 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + Double.NaN+ "'", var6.equals(Double.NaN));

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test127"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(1.0f, 102399.99f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 102399.99f);

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test128"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var2.setContractionCriteria(50.000008f);
    var2.setExpansionMode(0);
    var2.setContractionCriteria(5.0f);
    double[] var10 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var10);
    var11.setContractionCriteria(50.000008f);
    double[] var14 = var11.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var11);
    boolean var16 = var2.equals((java.lang.Object)var11);
    org.apache.commons.math3.util.ResizableDoubleArray var17 = var11.copy();
    double[] var18 = var17.getInternalValues();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test129"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos((-0.1918949350704374d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9816445969084641d);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test130"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble(20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.43290200817664E18d);

  }

  public void test131() {}
//   public void test131() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test131"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     java.lang.String var4 = var0.nextHexString(110);
//     int var7 = var0.nextPascal(3, 0.0d);
//     int var10 = var0.nextSecureInt(47, 110);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var0.nextPascal(2, 1.7238281465865108d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2.122475728033859d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "f60ffbdeb13befecaeba3513c54e8a68a0ec9933eb5355e952bdd9d15281ad1167d868d0523e84e1f7767420d778b459c1cf6869618d82"+ "'", var4.equals("f60ffbdeb13befecaeba3513c54e8a68a0ec9933eb5355e952bdd9d15281ad1167d868d0523e84e1f7767420d778b459c1cf6869618d82"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 93);
// 
//   }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test132"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.9932436822052534d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.6999781549147914d);

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test133"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(2560, 70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 317.95231997325305d);

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test134"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(61, (-1820841394));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1820841455);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test135"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(5.830057245011164E41d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 138);

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test136"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    float var3 = var2.getExpansionFactor();
    org.apache.commons.math3.util.ResizableDoubleArray var4 = var2.copy();
    boolean var6 = var4.equals((java.lang.Object)"0cacf9027047923f7f13eb35204813f2c3e3ee02b22b321e3e8ef06f12077348c0303f1efcfa259b5f317aa65c0bb00136e9");
    int var7 = var4.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test137"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.math.BigInteger var1 = null;
    java.math.BigInteger var3 = org.apache.commons.math3.util.ArithmeticUtils.pow(var1, 0L);
    org.apache.commons.math3.exception.NumberIsTooLargeException var6 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)var1, (java.lang.Number)0.0d, false);
    boolean var7 = var6.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test138() {}
//   public void test138() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test138"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 49298L);
// 
//   }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test139"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(-937694931342098688L));

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test140"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-7910424700440438784L), 449542426);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test141"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var2.setContractionCriteria(50.000008f);
    var2.setExpansionMode(0);
    var2.setContractionCriteria(5.0f);
    double[] var10 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var10);
    var11.setContractionCriteria(50.000008f);
    double[] var14 = var11.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var11);
    boolean var16 = var2.equals((java.lang.Object)var11);
    org.apache.commons.math3.util.ResizableDoubleArray var17 = var11.copy();
    var17.setElement(10, 1.8630202480631338E86d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var17.setElement((-22), (-2.3251745304976303d));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test142"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(0.7258230469631404d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7258230469631404d);

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test143"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(62.57019563251673d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.016110443377414255d);

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test144"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(2.0038247688401145d, 6.389056068043896d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.003824768840115d);

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test145"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(9.431336800397727E41d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test146"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(5.713267795901074E43d, 31.4789883982983d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5.713267795901074E43d);

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test147"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Object[] var4 = new java.lang.Object[] { '4'};
    org.apache.commons.math3.exception.MaxCountExceededException var5 = new org.apache.commons.math3.exception.MaxCountExceededException(var1, (java.lang.Number)Double.NaN, var4);
    java.lang.Throwable[] var6 = var5.getSuppressed();
    org.apache.commons.math3.exception.NullArgumentException var7 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test148"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot((-6.935585632560808E42d), 1.9222222798755142E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6.935585632560808E42d);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test149"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    var3.reseedRandomGenerator(1L);
    double var7 = var3.probability(0.0d);
    double var8 = var3.getMean();
    double var10 = var3.density(5.95573570720202E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1.275063075929548E-45d);

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test150"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(282920086, 88);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test151"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)4.5194037630894135d, (java.lang.Number)(-5.705962099694664E43d), (java.lang.Number)5.600112593788973E86d);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test152"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var2.setContractionCriteria(50.000008f);
    var2.setExpansionMode(0);
    var2.setContractionCriteria(5.0f);
    float var9 = var2.getExpansionFactor();
    float var10 = var2.getExpansionFactor();
    float var11 = var2.getExpansionFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2.0f);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test153"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(2.320319334986273E-34d, (-1.8851541128986008E43d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.8851541128986008E43d);

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test154"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.addElement(0.02797455810085192d);
    var0.discardFrontElements(1);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var6 = var5.getInternalValues();
    var0.addElements(var6);
    int var8 = var0.start();
    int var9 = var0.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test155"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(986L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test156() {}
//   public void test156() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test156"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     double var17 = var0.nextBeta(1.1265425086815434E43d, 1.1282937610745374d);
//     long var19 = var0.nextPoisson(31.402066659134473d);
//     long var22 = var0.nextLong((-9223372036854775808L), 2L);
//     double var24 = var0.nextT(6.136369304788742E42d);
//     org.apache.commons.math3.distribution.IntegerDistribution var25 = null;
//     int var26 = var0.nextInversionDeviate(var25);
// 
//   }

  public void test157() {}
//   public void test157() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test157"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     java.lang.String var4 = var0.nextHexString(110);
//     int var7 = var0.nextPascal(3, 0.0d);
//     int var10 = var0.nextSecureInt(47, 110);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var0.nextSecureInt(127000, 4400);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.2802125186097344d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "5f3b2a693198bc2c83e8aede354348224b90137ca4ed87f4c2813ddcfdd88144df083354888851ffcc7e4902d837e71d905d877e768f20"+ "'", var4.equals("5f3b2a693198bc2c83e8aede354348224b90137ca4ed87f4c2813ddcfdd88144df083354888851ffcc7e4902d837e71d905d877e768f20"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 77);
// 
//   }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test158"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)3.3971810980760206E14d, (java.lang.Number)2L, true);

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test159"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(4270, 138);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 606.010788716111d);

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test160"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    java.lang.String var2 = var1.name();
    java.lang.String var3 = var1.toString();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = null;
    org.apache.commons.math3.random.RandomGenerator var6 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5, var6);
    org.apache.commons.math3.stat.ranking.TiesStrategy var8 = var7.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var9 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "MAXIMAL"+ "'", var2.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "MAXIMAL"+ "'", var3.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test161"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(8100, 34L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test162"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(1.7151785181287122d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test163() {}
//   public void test163() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test163"); }
// 
// 
//     org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     var0.setContractionCriteria(5.0f);
//     org.apache.commons.math3.random.RandomDataImpl var3 = new org.apache.commons.math3.random.RandomDataImpl();
//     boolean var4 = var0.equals((java.lang.Object)var3);
//     long var6 = var3.nextPoisson(1.8622531212727638d);
//     org.apache.commons.math3.distribution.IntegerDistribution var7 = null;
//     int var8 = var3.nextInversionDeviate(var7);
// 
//   }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test164"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(1.107148716958077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8030521961633448d);

  }

  public void test165() {}
//   public void test165() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test165"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(986.0897904647248d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test166"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    float var3 = var2.getExpansionFactor();
    org.apache.commons.math3.util.ResizableDoubleArray var4 = var2.copy();
    double[] var5 = var4.getInternalValues();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test167"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.lang.Object[] var5 = new java.lang.Object[] { '4'};
    org.apache.commons.math3.exception.MaxCountExceededException var6 = new org.apache.commons.math3.exception.MaxCountExceededException(var2, (java.lang.Number)Double.NaN, var5);
    java.lang.Throwable[] var7 = var6.getSuppressed();
    org.apache.commons.math3.exception.MathInternalError var8 = new org.apache.commons.math3.exception.MathInternalError(var1, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathArithmeticException var9 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.util.ExceptionContext var10 = var9.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var11 = var9.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test168"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getNumericalVariance();
    double[] var3 = var0.sample(12700);
    double var4 = var0.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test169"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(102400);
    double[] var2 = var1.getElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test170"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc((-1.3405768023430444d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.942021691256109d);

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test171"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(66);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test172"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(2.6525818441349044E44d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.46594407016519296d));

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test173"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.lang.Number var3 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var4 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var2, var3);
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
    java.lang.Throwable[] var6 = var4.getSuppressed();
    org.apache.commons.math3.exception.MaxCountExceededException var7 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)5.957132015917888E42d, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MathArithmeticException var8 = new org.apache.commons.math3.exception.MathArithmeticException();
    org.apache.commons.math3.exception.util.ExceptionContext var9 = var8.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var10 = var8.getContext();
    var7.addSuppressed((java.lang.Throwable)var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test174() {}
//   public void test174() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test174"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     double var17 = var0.nextGamma(0.9775852669347048d, 3.199763873047224E14d);
//     var0.reSeed();
//     var0.reSeedSecure(27900L);
//     java.util.Collection var21 = null;
//     java.lang.Object[] var23 = var0.nextSample(var21, 73);
// 
//   }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test175"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var2.setContractionCriteria(50.000008f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setContractionCriteria(0.99999994f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test176() {}
//   public void test176() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test176"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     double var16 = var0.nextWeibull(1.0d, 1.6298598478788293d);
//     double var19 = var0.nextCauchy((-1.1440883267692863E33d), 3.3030345912774096E43d);
//     double var22 = var0.nextUniform(335.0334109186577d, 7.22597376812575E86d);
//     long var25 = var0.nextSecureLong(34L, 5144L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var27 = var0.nextChiSquare(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "1d7153bb372db92c2df7adeb338d18fffae9024168b46e4a5d3a11c599f77a6c4e5eecff60a537513fbf4bd701cb22fec399"+ "'", var2.equals("1d7153bb372db92c2df7adeb338d18fffae9024168b46e4a5d3a11c599f77a6c4e5eecff60a537513fbf4bd701cb22fec399"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.2242843223184306E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 3.3070203337478086d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-2.86653588377106E43d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 4.581936263120472E86d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 108L);
// 
//   }

  public void test177() {}
//   public void test177() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test177"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     double var17 = var0.nextBeta(1.1265425086815434E43d, 1.1282937610745374d);
//     long var19 = var0.nextPoisson(31.402066659134473d);
//     long var22 = var0.nextLong((-9223372036854775808L), 2L);
//     double var24 = var0.nextExponential(8.033357312847968E-10d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "ebfa51799a3ac19284c1252d4ac844b5ff5426ad16ae2bc47a87d7e1b7be0e911d1e59f409933d9429775d279f7b6646f018"+ "'", var2.equals("ebfa51799a3ac19284c1252d4ac844b5ff5426ad16ae2bc47a87d7e1b7be0e911d1e59f409933d9429775d279f7b6646f018"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 3.023399727013109E42d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 20L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == (-8752834500164763648L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 5.588773992444916E-10d);
// 
//   }

  public void test178() {}
//   public void test178() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test178"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     double var5 = var0.nextGaussian(0.0d, 0.5d);
//     var0.reSeed(10L);
//     long var10 = var0.nextLong((-1L), 10L);
//     double var13 = var0.nextF(0.9999999999999971d, 0.5088599843857857d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var17 = var0.nextUniform(0.0d, 0.0d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.10224873602418594d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-0.3881683886663065d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 3L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 33440.02188934844d);
// 
//   }

  public void test179() {}
//   public void test179() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test179"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     double var16 = var6.cumulativeProbability(0.14423894632267276d, 5.694508929246172E14d);
//     double var18 = var6.probability(2.3977699460038757E-44d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "13b7b037db7fc9ef632bb1ddc9fa6e250d3045d82864cbf5aeed02cbf57c2b56a3849a0bc4d5c2b99795e849589a806461a4"+ "'", var2.equals("13b7b037db7fc9ef632bb1ddc9fa6e250d3045d82864cbf5aeed02cbf57c2b56a3849a0bc4d5c2b99795e849589a806461a4"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-3.2056161896608746E43d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 8.451195606992581E-30d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.0d);
// 
//   }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test180"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(0, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test181"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(0.0d, (-0.7997115369080445d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.7997115369080445d));

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test182"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.2122439117578808d, 4.246383128529704E21d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test183"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    var3.reseedRandomGenerator(1L);
    boolean var6 = var3.isSupportConnected();
    double var7 = var3.getNumericalMean();
    double var8 = var3.getNumericalMean();
    double var10 = var3.probability(1.5485965529242296d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);

  }

  public void test184() {}
//   public void test184() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test184"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     double var4 = var0.nextExponential(0.056182176564052d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var7 = var0.nextZipf((-90), 0.5076859704998449d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "b9d05ab6d3fa5e04c985feebaceb259af057ec74c5f0df5176f767ab8902d2fff87f10a1b00ef4b90a2eec9cf1a5f2ce5c94"+ "'", var2.equals("b9d05ab6d3fa5e04c985feebaceb259af057ec74c5f0df5176f767ab8902d2fff87f10a1b00ef4b90a2eec9cf1a5f2ce5c94"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.0785341521824615d);
// 
//   }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test185"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(1612900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1612900);

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test186"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(1.4472475295846865E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test187"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(5, 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test188"); }


    double[] var0 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    int var2 = var1.getExpansionMode();
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Throwable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    java.lang.Object[] var8 = new java.lang.Object[] { 0.056182176564052d};
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException(var5, var6, var8);
    org.apache.commons.math3.exception.MaxCountExceededException var10 = new org.apache.commons.math3.exception.MaxCountExceededException(var3, (java.lang.Number)0.4855570380544819d, var8);
    org.apache.commons.math3.exception.util.ExceptionContext var11 = var10.getContext();
    boolean var12 = var1.equals((java.lang.Object)var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test189"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var2.setContractionCriteria(50.000008f);
    double[] var5 = var2.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    int var7 = var2.start();
    var2.setElement(127, 0.13930833414080868d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test190"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    java.lang.String var2 = var1.name();
    java.lang.String var3 = var1.name();
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var5.getTiesStrategy();
    int var7 = var6.ordinal();
    java.lang.String var8 = var6.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var6);
    java.lang.String var10 = var1.name();
    java.lang.Object var11 = null;
    boolean var12 = var1.equals(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "MAXIMAL"+ "'", var2.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "MAXIMAL"+ "'", var3.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "MAXIMAL"+ "'", var10.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test191"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(1731844179L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1731844179L);

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test192"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, var1, (java.lang.Number)(-3.879737992297923E43d), (java.lang.Number)478245873);

  }

  public void test193() {}
//   public void test193() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test193"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     var0.reSeed(1L);
//     double var7 = var0.nextWeibull(6.389056068043896d, 6.770911672198755d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var0.nextPascal(1496370343, 6.750675483277958d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "9cb6e0da1d4498aa5e3c7bdfba262210ceaa1f19a422d993eb4160beaf222e7128dacd7dc2c3986701333b9354a9941a9acc"+ "'", var2.equals("9cb6e0da1d4498aa5e3c7bdfba262210ceaa1f19a422d993eb4160beaf222e7128dacd7dc2c3986701333b9354a9941a9acc"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 4.5194037630894135d);
// 
//   }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test194"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-1L), (java.lang.Number)(-0.5606386275277436d), false);
    java.lang.Number var4 = var3.getMax();
    java.lang.Number var5 = var3.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (-0.5606386275277436d)+ "'", var4.equals((-0.5606386275277436d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-1L)+ "'", var5.equals((-1L)));

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test195"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.NotPositiveException var7 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(short)1);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var9 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var7, var8, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.MathIllegalArgumentException var11 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var5, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.MaxCountExceededException var12 = new org.apache.commons.math3.exception.MaxCountExceededException(var3, (java.lang.Number)0.9640275797804917d, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.MaxCountExceededException var13 = new org.apache.commons.math3.exception.MaxCountExceededException(var1, (java.lang.Number)94L, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.MathIllegalStateException var14 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test196"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(6.236998198686383E86d, 1.7645501572145885E42d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.0d));

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test197"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(40L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 40L);

  }

  public void test198() {}
//   public void test198() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test198"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     var0.reSeed(1L);
//     var0.reSeed();
//     var0.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "ee1b61b6c1d8eaec73e41871b5547cad6bf9d7b0fa5d30cc74b8f00e8a049f669a439a5f5efe6423d749a9ca5d128ad59876"+ "'", var2.equals("ee1b61b6c1d8eaec73e41871b5547cad6bf9d7b0fa5d30cc74b8f00e8a049f669a439a5f5efe6423d749a9ca5d128ad59876"));
// 
//   }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test199"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(5.0f);
    var0.setElement(110, Double.NaN);
    var0.discardFrontElements(10);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var8.setContractionCriteria(50.000008f);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var8);
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var13 = var12.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var14 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var13, var14);
    org.apache.commons.math3.stat.ranking.NaNStrategy var16 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var16);
    org.apache.commons.math3.stat.ranking.TiesStrategy var18 = var17.getTiesStrategy();
    int var19 = var18.ordinal();
    java.lang.String var20 = var18.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var13, var18);
    org.apache.commons.math3.stat.ranking.TiesStrategy var22 = var21.getTiesStrategy();
    boolean var23 = var0.equals((java.lang.Object)var22);
    var0.setElement(44, 0.9999999985344894d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "AVERAGE"+ "'", var20.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test200"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(88, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 88);

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test201"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)7.180580376996924E86d);

  }

  public void test202() {}
//   public void test202() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test202"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     double var5 = var0.nextGaussian(0.0d, 0.5d);
//     var0.reSeed(10L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var0.nextHypergeometric(12192000, 1820841484, 22);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.3649570197472487d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.09978793059614181d);
// 
//   }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test203"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(5.458802422386986E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.8319036349418325E-44d);

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test204"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(5.0f);
    org.apache.commons.math3.random.RandomDataImpl var3 = new org.apache.commons.math3.random.RandomDataImpl();
    boolean var4 = var0.equals((java.lang.Object)var3);
    var0.addElement(Double.NaN);
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var8 = var7.getNanStrategy();
    java.lang.String var9 = var8.name();
    java.lang.String var10 = var8.name();
    org.apache.commons.math3.stat.ranking.NaNStrategy var11 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11);
    org.apache.commons.math3.stat.ranking.TiesStrategy var13 = var12.getTiesStrategy();
    int var14 = var13.ordinal();
    java.lang.String var15 = var13.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8, var13);
    double[] var18 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray(var18);
    var19.setContractionCriteria(50.000008f);
    var19.setExpansionMode(0);
    boolean var24 = var13.equals((java.lang.Object)var19);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var19);
    org.apache.commons.math3.util.ResizableDoubleArray var26 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var26.setContractionCriteria(5.0f);
    var26.setElement(110, Double.NaN);
    var26.discardFrontElements(10);
    org.apache.commons.math3.util.ResizableDoubleArray var34 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var34.setContractionCriteria(50.000008f);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var26, var34);
    int var38 = var34.getExpansionMode();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var19, var34);
    var19.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "MAXIMAL"+ "'", var9.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "MAXIMAL"+ "'", var10.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "AVERAGE"+ "'", var15.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test205"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("4de04da05c67f79dad942aa9033573f0378c05b45cfe3cbc08ae240bb74233d37809bff8d240934f64cf07e694b1c8cf3032");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test206"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.08949018759546412d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test207() {}
//   public void test207() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test207"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     double var5 = var0.nextGaussian(0.0d, 0.5d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var8 = var0.nextPascal((-105), 1.449681089050812d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.6753211262186825d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.17759524951565503d);
// 
//   }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test208"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(1.300371626015253E-10d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test209"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("9a1904393f321334f99904622fb97d5d618bc15b7f14b0d4fd9401b1c8d970f5f17f184a21982f955cc2af7c255164e6e5c8");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test210"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(1.2696572718964828E42d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5474250491067253E26d);

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test211"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(2.384186E-7f, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.3841858E-7f);

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test212"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = var4.getNanStrategy();
    java.lang.String var6 = var5.name();
    java.lang.String var7 = var5.name();
    org.apache.commons.math3.stat.ranking.NaNStrategy var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8);
    org.apache.commons.math3.stat.ranking.TiesStrategy var10 = var9.getTiesStrategy();
    int var11 = var10.ordinal();
    java.lang.String var12 = var10.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5, var10);
    org.apache.commons.math3.stat.ranking.NaNStrategy var14 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var14);
    org.apache.commons.math3.stat.ranking.TiesStrategy var16 = var15.getTiesStrategy();
    int var17 = var16.ordinal();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var18 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var5, var16);
    org.apache.commons.math3.distribution.NormalDistribution var21 = new org.apache.commons.math3.distribution.NormalDistribution(1.8246532949072747d, 0.9732473842406115d);
    boolean var22 = var21.isSupportConnected();
    boolean var23 = var16.equals((java.lang.Object)var22);
    org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "MAXIMAL"+ "'", var6.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "MAXIMAL"+ "'", var7.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "AVERAGE"+ "'", var12.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test213"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(2.3841858E-7f, 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.536743E-7f);

  }

  public void test214() {}
//   public void test214() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test214"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log10((-0.47598581837512266d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test215"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(5.0f);
    var0.setElement(110, Double.NaN);
    var0.discardFrontElements(10);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var8.setContractionCriteria(50.000008f);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var8);
    int var12 = var8.getExpansionMode();
    var8.setExpansionMode(0);
    var8.clear();
    int var16 = var8.getExpansionMode();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test216"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(32.94631867978203d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 33L);

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test217"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var3 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var1, var2);
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var3.getContext();
    java.lang.Throwable[] var5 = var3.getSuppressed();
    org.apache.commons.math3.exception.NullArgumentException var6 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test218"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(102400.016f, 1.449681089050812d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 102400.01f);

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test219"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(2.012472290565982d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.807724744398348d);

  }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test220"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var2 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MaxCountExceededException var3 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, var1, (java.lang.Object[])var2);
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var3.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var3.getContext();
    java.lang.Number var6 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test221"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("16e8daf416d3e89efc7e584b4b51ede017c9f5c652843396dd8119ae9b80d4722dc7f2339b81d87e84bdb890b1eb71a60e78");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test222"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)7.6293945E-6f);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test223"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.2523930260097898d, (java.lang.Number)6.389056068043896d, true);
    boolean var5 = var4.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test224"); }


    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(2, 10.0f, 10.0f, 1);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var4.substituteMostRecentElement(3.7760951459250447d);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException");
    } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
      // Expected exception.
    }

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test225"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getInternalValues();
    int var2 = var0.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test226"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(478245873, (-105));
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test227() {}
//   public void test227() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test227"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var2 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     double[] var4 = new double[] { 1.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
//     var5.setContractionCriteria(50.000008f);
//     double[] var8 = var5.getInternalValues();
//     double[] var10 = new double[] { 1.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var10);
//     var11.setContractionCriteria(50.000008f);
//     double[] var14 = var11.getInternalValues();
//     double[] var15 = var11.getElements();
//     double var16 = var2.mannWhitneyUTest(var8, var15);
//     double[] var17 = var1.rank(var15);
// 
//   }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test228"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(2951, 23333L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1347981273));

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test229"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(1.9480212129433703E13d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.94802121294337E13d);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test230"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, var1);
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var2.getContext();
    boolean var4 = var2.getBoundIsAllowed();
    boolean var5 = var2.getBoundIsAllowed();
    boolean var6 = var2.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test231() {}
//   public void test231() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test231"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     long var16 = var0.nextLong((-92L), 900L);
//     double var19 = var0.nextGaussian(0.0d, 2.128632798283777d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "9032aa42256e4fb089b1d1042c0a061268c4bd77ed9ec7a89a14b46214b0691598d4d8defcd8d1fbc45831bdbff6ca83e313"+ "'", var2.equals("9032aa42256e4fb089b1d1042c0a061268c4bd77ed9ec7a89a14b46214b0691598d4d8defcd8d1fbc45831bdbff6ca83e313"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 2.680759944678681E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 344L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1.7018254074221328d);
// 
//   }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test232"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(3941415383162945436L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3941415383162945436L);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test233"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0.4566344307670791d, (java.lang.Number)(-1.0087674787522005d), (java.lang.Number)110);
    java.lang.Number var5 = var4.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 110+ "'", var5.equals(110));

  }

  public void test234() {}
//   public void test234() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test234"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     double var17 = var0.nextBeta(1.1265425086815434E43d, 1.1282937610745374d);
//     long var19 = var0.nextPoisson(31.402066659134473d);
//     long var22 = var0.nextLong((-9223372036854775808L), 2L);
//     int var25 = var0.nextZipf(2068, 0.22669496104614656d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var28 = var0.nextLong((-48600L), (-9223372036854775808L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "0a7c69b6a8cd7bff7cb9fec4e2539cf9985a646ba8807f0726f154377363103d080a4412197c4023e6d805b6eb0f49aae4b4"+ "'", var2.equals("0a7c69b6a8cd7bff7cb9fec4e2539cf9985a646ba8807f0726f154377363103d080a4412197c4023e6d805b6eb0f49aae4b4"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 3.5787926431289973E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 24L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == (-597761935026407424L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1266);
// 
//   }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test235"); }


    double var1 = org.apache.commons.math3.special.Erf.erf((-0.3873298583330024d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.4161481948412105d));

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test236"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    var3.reseedRandomGenerator(1L);
    double var7 = var3.cumulativeProbability(0.0d);
    double var9 = var3.probability(6.770911672198755d);
    double var11 = var3.inverseCumulativeProbability(1.0d);
    double var13 = var3.density((-1.334647089527227d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1.4840955931403377E-44d);

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test237"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test238"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.5606386275277435d), 8.156532496556457E43d);

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test239"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(5.0f);
    org.apache.commons.math3.random.RandomDataImpl var3 = new org.apache.commons.math3.random.RandomDataImpl();
    boolean var4 = var0.equals((java.lang.Object)var3);
    var0.addElement(Double.NaN);
    double[] var7 = var0.getInternalValues();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test240"); }


    long var1 = org.apache.commons.math3.util.FastMath.round((-3.8937895592837686d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-4L));

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test241"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc((-2.485421078903705E43d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0d);

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test242"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(5.723700438986527E21d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 21.75767689603471d);

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test243"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    java.lang.String var2 = var1.name();
    java.lang.String var3 = var1.name();
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var5.getTiesStrategy();
    int var7 = var6.ordinal();
    java.lang.String var8 = var6.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var6);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    org.apache.commons.math3.stat.ranking.NaNStrategy var11 = var10.getNanStrategy();
    java.lang.String var12 = var11.toString();
    java.lang.String var13 = var11.name();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "MAXIMAL"+ "'", var2.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "MAXIMAL"+ "'", var3.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "MAXIMAL"+ "'", var12.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "MAXIMAL"+ "'", var13.equals("MAXIMAL"));

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test244"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm((-2153345741252449825L), 988L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test245"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double[] var2 = var0.sample(1);
    double var3 = var0.getMean();
    boolean var4 = var0.isSupportUpperBoundInclusive();
    double var5 = var0.getSupportUpperBound();
    boolean var6 = var0.isSupportUpperBoundInclusive();
    double var9 = var0.cumulativeProbability(2.4188678176733584E-44d, 3.1471375077713234E41d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.5d);

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test246"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.02797091068267617d);
    org.apache.commons.math3.exception.MathInternalError var2 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var1);

  }

  public void test247() {}
//   public void test247() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test247"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     boolean var9 = var6.isSupportConnected();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var6.inverseCumulativeProbability(6.389056068043896d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "949dc9c521093daa81e37c0a95a5089927fe920b3aeba1eb976c0728f77297ce667518ee1ac8938dded8bb3e917ba45a9e9c"+ "'", var2.equals("949dc9c521093daa81e37c0a95a5089927fe920b3aeba1eb976c0728f77297ce667518ee1ac8938dded8bb3e917ba45a9e9c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-2.551749506809913E43d));
// 
//   }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test248"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(-1.0535313540516738E43d));
    java.lang.Number var3 = var2.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));

  }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test249"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)317.95231997325305d);

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test250"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial((-22));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test251"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(100.5f, 3.0980013747482587d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100.49999f);

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test252"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("93f6afd1b20c7a763f749ec7ac33622cdd29bfa3b4a0baf866b1b829a788ed331ec736dde62d128f8b3d0d84dfc78dc0ef96");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test253"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(6.239608407802531E-31d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test254"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(3.199763873047224E14d, 1.8246532949072747d);
    double var3 = var2.getNumericalVariance();
    boolean var4 = var2.isSupportConnected();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 3.329359646615974d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test255"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.582913409847474d, 0.9542512052939294d, 4.951760157141521E27d, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.42024034733826643d);

  }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test256"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)1.9222222798755142E-4d);
    java.lang.Number var3 = var2.getMin();
    java.lang.Number var4 = var2.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 1.9222222798755142E-4d+ "'", var4.equals(1.9222222798755142E-4d));

  }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test257"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.math.BigInteger var3 = null;
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var7 = new org.apache.commons.math3.exception.OutOfRangeException(var1, (java.lang.Number)100.0f, (java.lang.Number)var5, (java.lang.Number)0.5000672346092545d);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    java.math.BigInteger var10 = null;
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var10, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var14 = new org.apache.commons.math3.exception.OutOfRangeException(var8, (java.lang.Number)100.0f, (java.lang.Number)var12, (java.lang.Number)0.5000672346092545d);
    java.math.BigInteger var15 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, var12);
    org.apache.commons.math3.exception.util.Localizable var16 = null;
    java.lang.Object[] var19 = new java.lang.Object[] { '4'};
    org.apache.commons.math3.exception.MaxCountExceededException var20 = new org.apache.commons.math3.exception.MaxCountExceededException(var16, (java.lang.Number)Double.NaN, var19);
    java.lang.Throwable[] var21 = var20.getSuppressed();
    org.apache.commons.math3.exception.MaxCountExceededException var22 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)var5, (java.lang.Object[])var21);
    org.apache.commons.math3.exception.MaxCountExceededException var23 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)var5);
    java.math.BigInteger var25 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 2432902008176640001L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test258"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(0.9999999989000916d, (-3.879737992297923E43d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.9999999989000916d));

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test259"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = var3.copy();
    double var6 = var3.addElementRolling(0.3088209685048367d);
    int var7 = var3.getNumElements();
    boolean var9 = var3.equals((java.lang.Object)1.3119152085309351d);
    double[] var11 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var11);
    var12.setContractionCriteria(50.000008f);
    var12.setExpansionMode(0);
    var12.setContractionCriteria(5.0f);
    double[] var20 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var21 = new org.apache.commons.math3.util.ResizableDoubleArray(var20);
    var21.setContractionCriteria(50.000008f);
    double[] var24 = var21.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var25 = new org.apache.commons.math3.util.ResizableDoubleArray(var21);
    boolean var26 = var12.equals((java.lang.Object)var21);
    double[] var27 = var21.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var3, var21);
    var21.setNumElements(70);
    org.apache.commons.math3.util.ResizableDoubleArray var31 = new org.apache.commons.math3.util.ResizableDoubleArray(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test260"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(0.020853712364473545d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.02085522412809187d);

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test261"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(84.43311380502826d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 85.0d);

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test262"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(891L, (-8615948696432275456L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-8615948696432274565L));

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test263"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Number var5 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var6 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MaxCountExceededException var7 = new org.apache.commons.math3.exception.MaxCountExceededException(var4, var5, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MathInternalError var8 = new org.apache.commons.math3.exception.MathInternalError(var3, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var2, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MaxCountExceededException var10 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)5281956653691830372L, (java.lang.Object[])var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test264"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(short)1);
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var3 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var4 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var1, var2, (java.lang.Object[])var3);
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var1.getContext();
    java.lang.String var6 = var1.toString();
    java.lang.Number var7 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "org.apache.commons.math3.exception.NotPositiveException: 1 is smaller than the minimum (0)"+ "'", var6.equals("org.apache.commons.math3.exception.NotPositiveException: 1 is smaller than the minimum (0)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 0+ "'", var7.equals(0));

  }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test265"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.5707963267948923d, 1.0159453334112069E43d, 136.80272263732638d);

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test266"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(0.02797455810085192d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.1672559658154289d);

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test267"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-27000L), 2560);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test268"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    var3.reseedRandomGenerator(1L);
    boolean var6 = var3.isSupportConnected();
    double var7 = var3.getMean();
    double var8 = var3.getStandardDeviation();
    boolean var9 = var3.isSupportUpperBoundInclusive();
    boolean var10 = var3.isSupportConnected();
    double var12 = var3.inverseCumulativeProbability(0.06578711824213442d);
    double var14 = var3.inverseCumulativeProbability(0.44822672346716985d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.6881171418161356E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-4.05347365262866E43d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == (-3.4983909703221E42d));

  }

  public void test269() {}
//   public void test269() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test269"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     double var17 = var0.nextGamma(0.9775852669347048d, 3.199763873047224E14d);
//     double var20 = var0.nextGaussian(1.8622531212727638d, 1.1265425086815434E43d);
//     double var23 = var0.nextCauchy(0.0d, 0.5274450245437947d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var27 = var0.nextHypergeometric(25019000, (-127), (-122));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "ce64c57f917210ab46926da403421180c6fe2e00f11f230ea02562bec56c45e859b5ad38526f11f75f5a93bfec44e0d7cb8e"+ "'", var2.equals("ce64c57f917210ab46926da403421180c6fe2e00f11f230ea02562bec56c45e859b5ad38526f11f75f5a93bfec44e0d7cb8e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-5.982588252942523E42d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 3.4467002680779444E14d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == (-1.4585151458180719E43d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.05929020109463829d);
// 
//   }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test270"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)2.7177862822969723E43d, (java.lang.Number)2.0000005f, true);

  }

  public void test271() {}
//   public void test271() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test271"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     java.lang.String var4 = var0.nextHexString(110);
//     int var7 = var0.nextPascal(3, 0.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var10 = var0.nextPermutation(88, 1612775);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.6744517979670706d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "a79410883f575636f3e63031f671916322879018d87000f3edee0187f5a45429131d6dd80e6f36ddd671c0f8394cf6c4569b50503d403d"+ "'", var4.equals("a79410883f575636f3e63031f671916322879018d87000f3edee0187f5a45429131d6dd80e6f36ddd671c0f8394cf6c4569b50503d403d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2147483647);
// 
//   }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test272"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(52037, 127000);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test273"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(100.5f, 50.000008f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100.5f);

  }

  public void test274() {}
//   public void test274() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test274"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     var0.reSeed(1L);
//     double var7 = var0.nextCauchy(8.799063409660144E86d, 0.02797091068267617d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var0.nextInt(287, 73);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "9c879b43f9863619c0beb00b1fb93bac82a60a4b7436af645fec7d362777474c464c7c8d975a3f422cf65c7eb4dca5fe4a09"+ "'", var2.equals("9c879b43f9863619c0beb00b1fb93bac82a60a4b7436af645fec7d362777474c464c7c8d975a3f422cf65c7eb4dca5fe4a09"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 8.799063409660144E86d);
// 
//   }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test275"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(12192000, 110);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1341120000);

  }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test276"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck((-5129524049062756352L), 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-5129524049062756352L));

  }

  public void test277() {}
//   public void test277() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test277"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     java.lang.String var4 = var0.nextHexString(110);
//     int var7 = var0.nextPascal(3, 0.0d);
//     int var10 = var0.nextSecureInt(47, 110);
//     var0.reSeedSecure(300L);
//     long var15 = var0.nextSecureLong(0L, 28798L);
//     var0.reSeed();
//     double var19 = var0.nextGaussian(0.9929760443723394d, 2.3602882503786575d);
//     double var22 = var0.nextGaussian(1.5485965529242296d, 1.3418720970618036E43d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var25 = var0.nextBinomial(52037, 3.8621646488805664E43d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.20910328778268172d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "b9dc79b55ea93c199477d68728938ab6c7a66027aa20ceb5cdbcfbd0cc753cd8447043d541e62c437b52009253814c782bd1df84f2664b"+ "'", var4.equals("b9dc79b55ea93c199477d68728938ab6c7a66027aa20ceb5cdbcfbd0cc753cd8447043d541e62c437b52009253814c782bd1df84f2664b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 28313L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 2.9623592166803494d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == (-1.1858735616498955E43d));
// 
//   }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test278"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(Float.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Float.POSITIVE_INFINITY);

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test279"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    double var5 = var3.density(0.21212719734331667d);
    double var7 = var3.density((-4.009723999311411E42d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.4840955931403377E-44d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.467676433654607E-44d);

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test280"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(1.1143184069654142d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.4034210167825495d));

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test281"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)0.117469904020025d);
    java.lang.Throwable[] var3 = var2.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test282"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(1.8630202480631338E86d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test283"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.0018388436884212223d, 3.1540754195491516E13d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test284"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(645781746);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test285() {}
//   public void test285() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test285"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     double var17 = var0.nextBeta(1.1265425086815434E43d, 1.1282937610745374d);
//     long var19 = var0.nextPoisson(31.402066659134473d);
//     long var22 = var0.nextSecureLong(0L, 6L);
//     int var25 = var0.nextInt(0, 2147483647);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("24dcc4fe61e45938938dec876c74d7fbf7a02d67ae5e204d6568234466fed6b360318daa83acc8877873d049d32182371b04", "fe0cc3ac9b9040eb5bba9b8059e56e5ff95d7d29636f4931b01b3ad9a907a85ff9b30fe53d3803d6c791ac88f2cc6715960e9160b6cbf1");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "cf5962440bdc33da2fd4d80b4f5be630b1d4c9dc4db27f28bbb05600fe357aa2514e7236bc8eee5424e8149ab86e2b857e12"+ "'", var2.equals("cf5962440bdc33da2fd4d80b4f5be630b1d4c9dc4db27f28bbb05600fe357aa2514e7236bc8eee5424e8149ab86e2b857e12"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.4434780927508542E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 42L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 234831139);
// 
//   }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test286"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(Double.POSITIVE_INFINITY, 4.111122573849115E13d);
    double var3 = var2.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == Double.POSITIVE_INFINITY);

  }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test287"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(229345007);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 229345007);

  }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test288"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(96, 2068);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test289() {}
//   public void test289() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test289"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     var0.reSeed(1L);
//     java.lang.String var6 = var0.nextHexString(10);
//     var0.reSeed();
//     var0.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "76b4481bcad573fba26ad34b471d7303c7f95d94355eb012946af8386880be3c17b94c59e8e0825f4d745a6c1991d12dae7d"+ "'", var2.equals("76b4481bcad573fba26ad34b471d7303c7f95d94355eb012946af8386880be3c17b94c59e8e0825f4d745a6c1991d12dae7d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "93042192d2"+ "'", var6.equals("93042192d2"));
// 
//   }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test290"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(1.531794703843822d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.06580021710817119d);

  }

  public void test291() {}
//   public void test291() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test291"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(318.15263962020936d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test292"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = var3.copy();
    double var6 = var3.addElementRolling(0.3088209685048367d);
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var7.addElement(0.02797455810085192d);
    var7.discardFrontElements(1);
    int var12 = var7.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var3, var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);

  }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test293"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var1 = null;
    org.apache.commons.math3.exception.MathIllegalArgumentException var2 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var1);
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var2.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test294"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(0.027073110299788997d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.5674618473532547d));

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test295"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = var3.copy();
    double var6 = var3.addElementRolling(0.3088209685048367d);
    org.apache.commons.math3.util.ResizableDoubleArray var7 = var3.copy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test296() {}
//   public void test296() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test296"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(1.1852318502836434d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test297() {}
//   public void test297() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test297"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     java.lang.String var4 = var0.nextHexString(110);
//     double var6 = var0.nextChiSquare(0.9865330122406505d);
//     double var8 = var0.nextExponential(0.07181691598288088d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var0.nextSecureInt(645781746, 110);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.6659568351925527d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "678568e4a05b458681c8e9b96f7693fd50a75f05bb98dbd6e8aa53b4a1e170713224673d4905fe33316ff631fd753bde1416014ef6e37f"+ "'", var4.equals("678568e4a05b458681c8e9b96f7693fd50a75f05bb98dbd6e8aa53b4a1e170713224673d4905fe33316ff631fd753bde1416014ef6e37f"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.38332436609927156d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.020975107256411163d);
// 
//   }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test298"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(8615948696432275456L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 8615948696432275456L);

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test299"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(4.953013069603387E43d, 2.6881171418161356E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0735567534837664d);

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test300"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(9.190337322292875E86d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test301"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.10247043485974927d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-4));

  }

  public void test302() {}
//   public void test302() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test302"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.5606386275277436d), 3.5671315446818194E43d);
//     double var4 = var2.probability(1.0713813143399866d);
//     double var5 = var2.getSupportUpperBound();
//     double var6 = var2.sample();
//     double var8 = var2.cumulativeProbability(0.05902633562621646d);
//     double var9 = var2.getStandardDeviation();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.0027790909639869E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 3.5671315446818194E43d);
// 
//   }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test303"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(3);
    int var2 = var1.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test304"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(0.323043422499125d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.32894357238223276d);

  }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test305"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(2.959565980661239E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.959565980661239E43d);

  }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test306"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("c803c0552e0412f3549ea5eac163e45d3d249e1e276da306a0f934606507dd50911cee484cfcfea951c3f383806e79a8e899");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test307"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(2.680759944678681E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 144);

  }

  public void test308() {}
//   public void test308() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test308"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     double var5 = var0.nextGaussian(0.0d, 0.5d);
//     java.lang.String var7 = var0.nextSecureHexString(3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.13247652004287813d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.10672066578914667d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + "062"+ "'", var7.equals("062"));
// 
//   }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test309"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(1.025953847986767d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 58.78282546484817d);

  }

  public void test310() {}
//   public void test310() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test310"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     double var16 = var0.nextWeibull(1.0d, 1.6298598478788293d);
//     double var19 = var0.nextWeibull(1.151569395337692d, 7.22597376812575E86d);
//     var0.reSeedSecure();
//     var0.reSeedSecure(0L);
//     double var24 = var0.nextChiSquare(0.9640275797804917d);
//     double var26 = var0.nextExponential(0.028514560146996132d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var29 = var0.nextInt(216770858, 108);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "027e9be1a3044571e57ca0f1fc913f651a446c1ebe0e9f57b8646e444c903a5e7c69c357930955dd0a8eed4a6f39dfad63cc"+ "'", var2.equals("027e9be1a3044571e57ca0f1fc913f651a446c1ebe0e9f57b8646e444c903a5e7c69c357930955dd0a8eed4a6f39dfad63cc"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.227533940177659E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.5030777133827709d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 6.773801002744091E86d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0.08370534731008843d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 0.015484978899497334d);
// 
//   }

  public void test311() {}
//   public void test311() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test311"); }
// 
// 
//     org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     var0.setContractionCriteria(5.0f);
//     var0.setElement(110, Double.NaN);
//     var0.discardFrontElements(10);
//     org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     var8.setContractionCriteria(50.000008f);
//     org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var8);
//     org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
//     var12.addElement((-4.9E-324d));
//     var12.addElement(7.913970955867624E-10d);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var18 = var17.getNanStrategy();
//     java.lang.String var19 = var18.name();
//     java.lang.String var20 = var18.name();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var21 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var21);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var23 = var22.getTiesStrategy();
//     int var24 = var23.ordinal();
//     java.lang.String var25 = var23.name();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var26 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var18, var23);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var27 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var28 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var27);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var29 = var28.getTiesStrategy();
//     int var30 = var29.ordinal();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var31 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var18, var29);
//     double[] var33 = new double[] { 1.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var34 = new org.apache.commons.math3.util.ResizableDoubleArray(var33);
//     org.apache.commons.math3.util.ResizableDoubleArray var35 = new org.apache.commons.math3.util.ResizableDoubleArray(var33);
//     double[] var36 = var35.getElements();
//     org.apache.commons.math3.util.ResizableDoubleArray var39 = new org.apache.commons.math3.util.ResizableDoubleArray(10, 50.0f);
//     var39.setElement(12700, 1.0806511876345213E86d);
//     org.apache.commons.math3.distribution.NormalDistribution var43 = new org.apache.commons.math3.distribution.NormalDistribution();
//     boolean var44 = var43.isSupportUpperBoundInclusive();
//     boolean var45 = var43.isSupportLowerBoundInclusive();
//     double var46 = var43.getMean();
//     double[] var48 = var43.sample(110);
//     var39.addElements(var48);
//     double var50 = var31.mannWhitneyUTest(var36, var48);
//     var12.addElements(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var19 + "' != '" + "MAXIMAL"+ "'", var19.equals("MAXIMAL"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var20 + "' != '" + "MAXIMAL"+ "'", var20.equals("MAXIMAL"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var25 + "' != '" + "AVERAGE"+ "'", var25.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 0.2612090664259398d);
// 
//   }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test312"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(216770858);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test313"); }


    long var1 = org.apache.commons.math3.util.FastMath.round((-5.794109633340552E-10d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0L);

  }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test314"); }


    double var2 = org.apache.commons.math3.util.FastMath.max((-0.810721850987725d), 7.399878698039668E42d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7.399878698039668E42d);

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test315"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(0L, 31L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test316"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(-7.707739625128683E41d), (java.lang.Number)1.188156673789677E14d, (java.lang.Number)100.49999f);

  }

  public void test317() {}
//   public void test317() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test317"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     java.lang.String var4 = var0.nextHexString(110);
//     double var7 = var0.nextGamma(0.9999999999999971d, 1.151569395337692d);
//     double var10 = var0.nextWeibull(0.15223793975554561d, 0.011377964632520712d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.7510386511223553d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "46130f2775cd3407c0e364c156939bbcdad1d1f47d02bcb81234009515ee2de9c5dcba5def07829118b135851b32cdadf0cf0e5aa0a200"+ "'", var4.equals("46130f2775cd3407c0e364c156939bbcdad1d1f47d02bcb81234009515ee2de9c5dcba5def07829118b135851b32cdadf0cf0e5aa0a200"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.7919079740719107d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 16.394210902476665d);
// 
//   }

  public void test318() {}
//   public void test318() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test318"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     long var16 = var0.nextLong(9944796L, 2432902008176640001L);
//     double var19 = var0.nextGamma(1.1918184733241577E43d, 2.434301530723388E-143d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "4cb6d7e2172b4260ec91a5714d4866642fc711e994bd703b8b1787e3f2e3b4d95002d52351ddbc518011e79fc483ffd75db2"+ "'", var2.equals("4cb6d7e2172b4260ec91a5714d4866642fc711e994bd703b8b1787e3f2e3b4d95002d52351ddbc518011e79fc483ffd75db2"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-8.229681396670382E42d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1552426974098593024L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 2.9012455339574085E-100d);
// 
//   }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test319"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    int var3 = var2.ordinal();
    java.lang.String var4 = var2.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var5.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var5.getNanStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "AVERAGE"+ "'", var4.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test320"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(0.9999999f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999999f);

  }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test321"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    java.math.BigInteger var8 = null;
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var12 = new org.apache.commons.math3.exception.OutOfRangeException(var6, (java.lang.Number)100.0f, (java.lang.Number)var10, (java.lang.Number)0.5000672346092545d);
    org.apache.commons.math3.exception.util.Localizable var13 = null;
    java.math.BigInteger var15 = null;
    java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var15, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var19 = new org.apache.commons.math3.exception.OutOfRangeException(var13, (java.lang.Number)100.0f, (java.lang.Number)var17, (java.lang.Number)0.5000672346092545d);
    java.math.BigInteger var20 = org.apache.commons.math3.util.ArithmeticUtils.pow(var10, var17);
    java.math.BigInteger var22 = org.apache.commons.math3.util.ArithmeticUtils.pow(var10, 31L);
    org.apache.commons.math3.exception.OutOfRangeException var23 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)8.799063409660144E86d, (java.lang.Number)0.99999994f, (java.lang.Number)var10);
    org.apache.commons.math3.exception.util.Localizable var24 = null;
    org.apache.commons.math3.exception.util.Localizable var25 = null;
    org.apache.commons.math3.exception.NotPositiveException var27 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(short)1);
    java.lang.Object[] var28 = new java.lang.Object[] { (short)1};
    org.apache.commons.math3.exception.MathIllegalStateException var29 = new org.apache.commons.math3.exception.MathIllegalStateException(var25, var28);
    org.apache.commons.math3.exception.MathIllegalStateException var30 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var23, var24, var28);
    org.apache.commons.math3.exception.MathInternalError var31 = new org.apache.commons.math3.exception.MathInternalError(var3, var28);
    org.apache.commons.math3.exception.MathIllegalArgumentException var32 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, var28);
    org.apache.commons.math3.exception.MaxCountExceededException var33 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)6.239608407802531E-31d, var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test322() {}
//   public void test322() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test322"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     double var17 = var0.nextGamma(0.9775852669347048d, 3.199763873047224E14d);
//     var0.reSeed();
//     org.apache.commons.math3.distribution.NormalDistribution var22 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var22.reseedRandomGenerator(1L);
//     double var26 = var22.probability(0.0d);
//     double var28 = var22.probability(1.432080595809531E43d);
//     double var29 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "7bbf6c809d0ac578d61f35357101b38a951a1c8ebbcf4d80324b92f44b2131a3b5b90ed102246516338e3c2737ba802a3bb9"+ "'", var2.equals("7bbf6c809d0ac578d61f35357101b38a951a1c8ebbcf4d80324b92f44b2131a3b5b90ed102246516338e3c2737ba802a3bb9"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-3.0499349125123786E43d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 3.193303976793424E14d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == (-3.1202400562606247E43d));
// 
//   }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test323"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var2.setContractionCriteria(50.000008f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setElement(1820841484, 21.75767689603471d);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test324"); }


    long var2 = org.apache.commons.math3.util.FastMath.max((-60L), (-90L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-60L));

  }

  public void test325() {}
//   public void test325() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test325"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     double var17 = var0.nextGamma(0.9775852669347048d, 3.199763873047224E14d);
//     double var20 = var0.nextF(2.636818730233018d, 1.1282937610745374d);
//     var0.reSeed(6L);
//     double var25 = var0.nextCauchy(0.0d, 0.8508952569561938d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "c3265141bbf333ae405f9d7f0c8f253ff7a3a0109c9c50bfa7c1c39a87e5de86ab6542c7c9b4ca5a984ef3172312d2a80bde"+ "'", var2.equals("c3265141bbf333ae405f9d7f0c8f253ff7a3a0109c9c50bfa7c1c39a87e5de86ab6542c7c9b4ca5a984ef3172312d2a80bde"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 4.653800584042538E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 9.110627787687669E14d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 14.326463606649524d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1.2660196586805188d);
// 
//   }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test326"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    float var3 = var2.getExpansionFactor();
    var2.contract();
    float var5 = var2.getContractionCriteria();
    int var6 = var2.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);

  }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test327"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(1.174518891015242E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test328"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(4.88929883633965E14d, 3.276074671525456E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.492425944633008E-29d);

  }

  public void test329() {}
//   public void test329() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test329"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     double var17 = var0.nextBeta(1.1265425086815434E43d, 1.1282937610745374d);
//     long var19 = var0.nextPoisson(31.402066659134473d);
//     long var22 = var0.nextLong((-9223372036854775808L), 2L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var24 = var0.nextPoisson(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "0705312d4da4935f1746021a6ec0bed7df2d45b18695461cb7da3f6e4f342acd973858478efcb74f3c277a12e1f5187e67c1"+ "'", var2.equals("0705312d4da4935f1746021a6ec0bed7df2d45b18695461cb7da3f6e4f342acd973858478efcb74f3c277a12e1f5187e67c1"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-1.21233687676764E43d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.9999999987445685d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 35L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == (-7936654981221779456L));
// 
//   }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test330"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    double var4 = var3.getSupportLowerBound();
    var3.reseedRandomGenerator((-4844103623415461888L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.NEGATIVE_INFINITY);

  }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test331"); }


    long var2 = org.apache.commons.math3.util.FastMath.min((-60L), 32L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-60L));

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test332"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(10.465631169907596d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.2350627768109224d);

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test333"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(41580239, 1612900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test334"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(8.799063409660144E86d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test335() {}
//   public void test335() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test335"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     double var5 = var0.nextGaussian(0.0d, 0.5d);
//     var0.reSeed(10L);
//     double var10 = var0.nextCauchy((-1.337558410913353d), 2.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.25733888612328215d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.025466596288185584d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-1.9269635607670348d));
// 
//   }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test336"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(1.0397156765373438E41d, 0.08142857470882658d, 0.0d, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException");
    } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
      // Expected exception.
    }

  }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test337"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.math.BigInteger var5 = null;
    java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var9 = new org.apache.commons.math3.exception.OutOfRangeException(var3, (java.lang.Number)100.0f, (java.lang.Number)var7, (java.lang.Number)0.5000672346092545d);
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    java.math.BigInteger var12 = null;
    java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var16 = new org.apache.commons.math3.exception.OutOfRangeException(var10, (java.lang.Number)100.0f, (java.lang.Number)var14, (java.lang.Number)0.5000672346092545d);
    java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, var14);
    java.math.BigInteger var19 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, 31L);
    org.apache.commons.math3.exception.OutOfRangeException var20 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)8.799063409660144E86d, (java.lang.Number)0.99999994f, (java.lang.Number)var7);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    org.apache.commons.math3.exception.util.Localizable var22 = null;
    org.apache.commons.math3.exception.util.Localizable var23 = null;
    org.apache.commons.math3.exception.util.Localizable var24 = null;
    java.lang.Number var25 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var26 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var24, var25);
    org.apache.commons.math3.exception.util.ExceptionContext var27 = var26.getContext();
    java.lang.Throwable[] var28 = var26.getSuppressed();
    org.apache.commons.math3.exception.MathInternalError var29 = new org.apache.commons.math3.exception.MathInternalError(var23, (java.lang.Object[])var28);
    org.apache.commons.math3.exception.MathInternalError var30 = new org.apache.commons.math3.exception.MathInternalError(var22, (java.lang.Object[])var28);
    org.apache.commons.math3.exception.MathIllegalStateException var31 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var20, var21, (java.lang.Object[])var28);
    org.apache.commons.math3.exception.MathInternalError var32 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test338() {}
//   public void test338() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test338"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     double var5 = var0.nextGaussian(0.0d, 0.5d);
//     var0.reSeed(10L);
//     double var10 = var0.nextF(1.3872175661331396d, 2.636818730233018d);
//     var0.reSeedSecure();
//     double var14 = var0.nextGaussian(0.0d, 10.0d);
//     int var17 = var0.nextBinomial(478245873, 0.1672559658154289d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.5523199061560513d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.3354103134776099d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5088599843857857d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 11.672233456208478d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 79973711);
// 
//   }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test339"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 44);

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test340"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    double var4 = var3.getSupportLowerBound();
    double var6 = var3.probability(4.605170185988092d);
    double var8 = var3.probability(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test341"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-2153345741252449825L), (java.lang.Number)645781745, true);

  }

  public void test342() {}
//   public void test342() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test342"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     boolean var9 = var6.isSupportConnected();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     double var12 = var6.probability(6.0d);
//     double var15 = var6.cumulativeProbability((-2.1317761108019555d), 0.9640275797804917d);
//     double var17 = var6.cumulativeProbability(0.02797455810085192d);
//     double var18 = var6.getNumericalMean();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "b91ea2c208f8d753ba4b3e54769b496a4cd64588d52b8060363929eda75fc7cb4da39257de731ca598551a1710491097dd1b"+ "'", var2.equals("b91ea2c208f8d753ba4b3e54769b496a4cd64588d52b8060363929eda75fc7cb4da39257de731ca598551a1710491097dd1b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-4.579303042451258E43d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 4.594468614421035E-44d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.0d);
// 
//   }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test343"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)3941415383162945436L, (java.lang.Number)0.18270418265156882d, false);

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test344"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter((-0.9999999999982615d), 8.699552196721514E86d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.9999999999982614d));

  }

  public void test345() {}
//   public void test345() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test345"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     double var4 = var0.nextExponential(0.056182176564052d);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var8 = var0.nextUniform(0.0d, (-0.9300733860920883d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "0d3cd939d83e555aad24beca49d28aa66e5ef4aa668cfbf4cbfbd2d590eeadc0a8bf2f8d2bb9380170b214f5c594a3f7d33b"+ "'", var2.equals("0d3cd939d83e555aad24beca49d28aa66e5ef4aa668cfbf4cbfbd2d590eeadc0a8bf2f8d2bb9380170b214f5c594a3f7d33b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.006294061719007045d);
// 
//   }

  public void test346() {}
//   public void test346() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test346"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.pow((-0.37349236086573334d), 309.16419358014696d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test347"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(1.9989920324989237d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2597093544151592d);

  }

  public void test348() {}
//   public void test348() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test348"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     java.lang.String var4 = var0.nextHexString(110);
//     double var7 = var0.nextGamma(0.9999999999999971d, 1.151569395337692d);
//     double var9 = var0.nextT(1.2982587902415216E14d);
//     var0.reSeedSecure(0L);
//     var0.reSeedSecure();
//     var0.reSeedSecure(27000L);
//     var0.reSeed();
//     var0.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.8360694669398832d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "0990762105ff0c08eb52be22ead63d657d336def33cb2cb34a0b2c29acbc4c9924a4b360a255799b0e06856662fea9e1a7b145d3dd3688"+ "'", var4.equals("0990762105ff0c08eb52be22ead63d657d336def33cb2cb34a0b2c29acbc4c9924a4b360a255799b0e06856662fea9e1a7b145d3dd3688"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.4265561439517398d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.3947446003188626d);
// 
//   }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test349"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(0.8739440070527092d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 14.3112613419244d);

  }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test350"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(10.0f, 216770858);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.POSITIVE_INFINITY);

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test351"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.math.BigInteger var5 = null;
    java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var9 = new org.apache.commons.math3.exception.OutOfRangeException(var3, (java.lang.Number)100.0f, (java.lang.Number)var7, (java.lang.Number)0.5000672346092545d);
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    java.math.BigInteger var12 = null;
    java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var16 = new org.apache.commons.math3.exception.OutOfRangeException(var10, (java.lang.Number)100.0f, (java.lang.Number)var14, (java.lang.Number)0.5000672346092545d);
    java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, var14);
    java.math.BigInteger var19 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, 31L);
    org.apache.commons.math3.exception.OutOfRangeException var20 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)8.799063409660144E86d, (java.lang.Number)0.99999994f, (java.lang.Number)var7);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    org.apache.commons.math3.exception.util.Localizable var22 = null;
    org.apache.commons.math3.exception.NotPositiveException var24 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(short)1);
    java.lang.Object[] var25 = new java.lang.Object[] { (short)1};
    org.apache.commons.math3.exception.MathIllegalStateException var26 = new org.apache.commons.math3.exception.MathIllegalStateException(var22, var25);
    org.apache.commons.math3.exception.MathIllegalStateException var27 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var20, var21, var25);
    org.apache.commons.math3.exception.MathIllegalArgumentException var28 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test352"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil((-0.21164073363140634d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.0d));

  }

  public void test353() {}
//   public void test353() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test353"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     java.lang.String var4 = var0.nextHexString(110);
//     int var7 = var0.nextPascal(3, 0.0d);
//     int var10 = var0.nextSecureInt(47, 110);
//     var0.reSeedSecure(300L);
//     long var15 = var0.nextSecureLong(0L, 28798L);
//     double var18 = var0.nextCauchy(8.156532496556457E43d, 0.14473363781667506d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.043469519371165166d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "192ecb5fbc6f07c4f46501e69c73df87dbc4d072e973abebd01d438bb8ba2c04ff97d5f83c0a69701611883a9a80e54162cc2b73c4c923"+ "'", var4.equals("192ecb5fbc6f07c4f46501e69c73df87dbc4d072e973abebd01d438bb8ba2c04ff97d5f83c0a69701611883a9a80e54162cc2b73c4c923"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 88);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 17873L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 8.156532496556457E43d);
// 
//   }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test354"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    java.lang.String var2 = var1.name();
    java.lang.String var3 = var1.name();
    boolean var5 = var1.equals((java.lang.Object)"bbc76c98706e096cbdb48c11be18b37feafe094ae0e5291b81fe65cbd0c42cc6f465c322de0f5afaf8fdd0237c92d0d9c2d6");
    int var6 = var1.ordinal();
    org.apache.commons.math3.random.RandomGenerator var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var7);
    java.lang.String var9 = var1.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var11 = var10.getNanStrategy();
    java.lang.String var12 = var11.name();
    java.lang.String var13 = var11.name();
    org.apache.commons.math3.stat.ranking.NaNStrategy var14 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var14);
    org.apache.commons.math3.stat.ranking.TiesStrategy var16 = var15.getTiesStrategy();
    int var17 = var16.ordinal();
    java.lang.String var18 = var16.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11, var16);
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var16);
    java.lang.Class var21 = var1.getDeclaringClass();
    org.apache.commons.math3.random.RandomGenerator var22 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "MAXIMAL"+ "'", var2.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "MAXIMAL"+ "'", var3.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "MAXIMAL"+ "'", var9.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "MAXIMAL"+ "'", var12.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "MAXIMAL"+ "'", var13.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + "AVERAGE"+ "'", var18.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test355"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(1.8382517352053591d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.218084974098134d);

  }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test356"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(0.010092770659726724d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.010092770659726726d);

  }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test357"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(0L, 14528100L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test358"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(0.056182176564052d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9366718398504545d);

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test359"); }


    double var2 = org.apache.commons.math3.util.FastMath.min((-0.0d), 0.027073110299788997d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.0d));

  }

  public void test360() {}
//   public void test360() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test360"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     var0.reSeed(1L);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var7 = var0.nextSecureHexString((-66));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "dbb90c6e3edcf60ae9efd38dabdb37470bf4459aa4ad93dc2abac9a864c3dd82b60369fd825d8543426c824738b7e1d9274c"+ "'", var2.equals("dbb90c6e3edcf60ae9efd38dabdb37470bf4459aa4ad93dc2abac9a864c3dd82b60369fd825d8543426c824738b7e1d9274c"));
// 
//   }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test361"); }


    double var2 = org.apache.commons.math3.special.Erf.erf((-2.1520997728497173d), (-3.0499349125123786E43d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.0023382114728576326d));

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test362"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    int var4 = var3.getNumElements();
    double var6 = var3.addElementRolling(1.2982587902415216E14d);
    float var7 = var3.getExpansionFactor();
    org.apache.commons.math3.util.ResizableDoubleArray var8 = var3.copy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test363"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(2.656500765412644d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2107681239502859d);

  }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test364"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(2.7573353102077896E-32d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-31.559510417601796d));

  }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test365"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(2559.9998f, 2.3841858E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.3841858E-7f);

  }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test366"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.6224688555315099d, 26.387081609342943d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 26.387081609342943d);

  }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test367"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(0.9732473842406115d, (-3.378211155916252E42d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-3.378211155916252E42d));

  }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test368"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(288, (-22));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 288);

  }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test369"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(29L, 27000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-26971L));

  }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test370"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution((-0.3781696985345623d), 200.0d, 3.072433293358163E86d);
    double var4 = var3.getStandardDeviation();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 200.0d);

  }

  public void test371() {}
//   public void test371() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test371"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     double var4 = var0.nextExponential(0.056182176564052d);
//     int var7 = var0.nextInt((-127), 2);
//     double var9 = var0.nextExponential(1.0244211201800262E14d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "3eab55ce68b50248a5a37f1c39655dccc6f9c94e1506d929bfb20e3755e6f8c876d7da2b65c547514dda0bbd3c69d8f0798f"+ "'", var2.equals("3eab55ce68b50248a5a37f1c39655dccc6f9c94e1506d929bfb20e3755e6f8c876d7da2b65c547514dda0bbd3c69d8f0798f"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.012416772504022816d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-42));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.4441480257138534E14d);
// 
//   }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test372"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(5.0f);
    org.apache.commons.math3.random.RandomDataImpl var3 = new org.apache.commons.math3.random.RandomDataImpl();
    boolean var4 = var0.equals((java.lang.Object)var3);
    var3.reSeedSecure(27900L);
    var3.reSeedSecure((-7910424700440438784L));
    var3.reSeedSecure();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test373"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.9932436822052534d, 1.492425944633008E-29d, 0.0d);

  }

  public void test374() {}
//   public void test374() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test374"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.pow((-5.327343066096964E43d), (-1.9269635607670348d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test375() {}
//   public void test375() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test375"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ((-3.0d), 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test376"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)110);
    java.lang.Number var2 = var1.getMin();
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var1.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0+ "'", var2.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test377() {}
//   public void test377() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test377"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     double var17 = var0.nextBeta(1.1265425086815434E43d, 1.1282937610745374d);
//     long var19 = var0.nextPoisson(31.402066659134473d);
//     long var22 = var0.nextSecureLong(0L, 6L);
//     int var25 = var0.nextInt(0, 2147483647);
//     long var28 = var0.nextSecureLong(29L, 75324600L);
//     java.lang.String var30 = var0.nextHexString(66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "29594cffc3dae54a8013d4b34a04dae1e083e04f6b8fdc1992207d3b117979ea4b7445a24f8fadf594c4056abb794fb21fe5"+ "'", var2.equals("29594cffc3dae54a8013d4b34a04dae1e083e04f6b8fdc1992207d3b117979ea4b7445a24f8fadf594c4056abb794fb21fe5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 2.185089419781954E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 35L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1221758388);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 60796841L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var30 + "' != '" + "208c629fb430c1d7d728f25edff5ae248311cf32573b3739cf23abbdf1eb889449"+ "'", var30.equals("208c629fb430c1d7d728f25edff5ae248311cf32573b3739cf23abbdf1eb889449"));
// 
//   }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test378"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(1.1548525561143932d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0625265399394557d);

  }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test379"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-11480));

  }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test380"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.323043422499125d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-2));

  }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test381"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    boolean var1 = var0.isSupportLowerBoundInclusive();
    var0.reseedRandomGenerator(0L);
    boolean var4 = var0.isSupportLowerBoundInclusive();
    double var5 = var0.getMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);

  }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test382"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp((-0.9999999f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.9999998f));

  }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test383"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    double var6 = var3.cumulativeProbability(1.4210854715202004E-14d, 2.0d);
    boolean var7 = var3.isSupportConnected();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var9 = var3.sample(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.9681911862806774E-44d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);

  }

  public void test384() {}
//   public void test384() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test384"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.0d, 6.0d, 3.456281063036932E-4d, (-1347981273));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test385"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck((-11480), 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-11480));

  }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test386"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(29L, (-937694931342098688L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-937694931342098659L));

  }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test387"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    java.lang.String var2 = var1.name();
    java.lang.String var3 = var1.toString();
    java.lang.String var4 = var1.toString();
    java.lang.Class var5 = var1.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var6.getNanStrategy();
    java.lang.String var8 = var7.name();
    java.lang.String var9 = var7.toString();
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var12 = var11.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var14 = var13.getNanStrategy();
    java.lang.String var15 = var14.name();
    java.lang.String var16 = var14.name();
    org.apache.commons.math3.stat.ranking.NaNStrategy var17 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var17);
    org.apache.commons.math3.stat.ranking.TiesStrategy var19 = var18.getTiesStrategy();
    int var20 = var19.ordinal();
    java.lang.String var21 = var19.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var14, var19);
    double[] var24 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var25 = new org.apache.commons.math3.util.ResizableDoubleArray(var24);
    var25.setContractionCriteria(50.000008f);
    var25.setExpansionMode(0);
    boolean var30 = var19.equals((java.lang.Object)var25);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var31 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var12, var19);
    org.apache.commons.math3.stat.ranking.NaturalRanking var32 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7, var19);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var33 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var19);
    java.lang.Class var34 = var19.getDeclaringClass();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "MAXIMAL"+ "'", var2.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "MAXIMAL"+ "'", var3.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "MAXIMAL"+ "'", var4.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "MAXIMAL"+ "'", var8.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "MAXIMAL"+ "'", var9.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "MAXIMAL"+ "'", var15.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + "MAXIMAL"+ "'", var16.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + "AVERAGE"+ "'", var21.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test388"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(0.5337063989568023d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5337063989568023d);

  }

  public void test389() {}
//   public void test389() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test389"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)2.0d, (java.lang.Number)(-1), (java.lang.Number)2.6881171418161356E43d);
//     java.lang.Number var5 = var4.getHi();
//     org.apache.commons.math3.exception.MathArithmeticException var6 = new org.apache.commons.math3.exception.MathArithmeticException();
//     org.apache.commons.math3.exception.util.ExceptionContext var7 = var6.getContext();
//     var4.addSuppressed((java.lang.Throwable)var6);
//     java.lang.Number var9 = var4.getHi();
//     java.lang.String var10 = var4.toString();
// 
//   }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test390"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    java.lang.String var2 = var1.name();
    java.lang.String var3 = var1.name();
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var5.getTiesStrategy();
    int var7 = var6.ordinal();
    java.lang.String var8 = var6.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var6);
    java.lang.String var10 = var1.toString();
    int var11 = var1.ordinal();
    java.lang.String var12 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "MAXIMAL"+ "'", var2.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "MAXIMAL"+ "'", var3.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "MAXIMAL"+ "'", var10.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "MAXIMAL"+ "'", var12.equals("MAXIMAL"));

  }

  public void test391() {}
//   public void test391() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test391"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     double var5 = var0.nextGaussian(0.0d, 0.5d);
//     var0.reSeed(10L);
//     long var10 = var0.nextLong((-1L), 10L);
//     double var13 = var0.nextF(0.9999999999999971d, 0.5088599843857857d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var15 = var0.nextSecureHexString((-1));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.11467134386590096d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.7047287994358293d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 3L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 33440.02188934844d);
// 
//   }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test392"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)42.77503722459932d, (java.lang.Number)(-7910424700440438784L), (java.lang.Number)4.504641947913808E14d);
    java.lang.Number var5 = var4.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 4.504641947913808E14d+ "'", var5.equals(4.504641947913808E14d));

  }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test393"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(1.151569395337692d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1L);

  }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test394"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(1820841484, 227);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1820841484);

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test395"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(110, (-2));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 112);

  }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test396"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("bbc76c98706e096cbdb48c11be18b37feafe094ae0e5291b81fe65cbd0c42cc6f465c322de0f5afaf8fdd0237c92d0d9c2d6");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test397"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    var3.reseedRandomGenerator(1L);
    boolean var6 = var3.isSupportConnected();
    double var7 = var3.getMean();
    double var8 = var3.sample();
    double var10 = var3.density(6.770911672198755d);
    boolean var11 = var3.isSupportUpperBoundInclusive();
    double var13 = var3.probability(7.483725781796605d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 3.5671315446818194E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1.4840955931403377E-44d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);

  }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test398"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.2334789518497913d, 0.0d, 0.11915249691498865d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test399() {}
//   public void test399() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test399"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh(0.017275917538634444d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test400() {}
//   public void test400() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test400"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     double var16 = var0.nextWeibull(1.0d, 1.6298598478788293d);
//     double var19 = var0.nextWeibull(1.151569395337692d, 7.22597376812575E86d);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("f3b2a3beec38f9e3e75c68bd7b37d7bd20a8e302694d1a82f7a958364a16566bc405669816d0f222b4bd0482077fb8ef107e", "82adb38d3e1e7d58c0c4fddf081dd3c420ff33cc646229e6704a620faa1e6198eb83962799cb2631d7a458478ff5438770e6");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "bcebe733013d988fb9ab494576582d99ea896b1baddb759db212af5da2a5cc3533a8cdec1c6adb1fbea9726409ea028b8e32"+ "'", var2.equals("bcebe733013d988fb9ab494576582d99ea896b1baddb759db212af5da2a5cc3533a8cdec1c6adb1fbea9726409ea028b8e32"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 5.242811082976652E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.8475321335967176d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 5.232947636438243E86d);
// 
//   }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test401"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    double var4 = var3.getSupportLowerBound();
    double var6 = var3.probability(6.419286864170918E43d);
    double var7 = var3.getSupportLowerBound();
    double var8 = var3.getNumericalVariance();
    double var9 = var3.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 7.22597376812575E86d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);

  }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test402"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(4.9999995f, Float.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-4.9999995f));

  }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test403"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.math.BigInteger var4 = null;
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var8 = new org.apache.commons.math3.exception.OutOfRangeException(var2, (java.lang.Number)100.0f, (java.lang.Number)var6, (java.lang.Number)0.5000672346092545d);
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    java.math.BigInteger var11 = null;
    java.math.BigInteger var13 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var15 = new org.apache.commons.math3.exception.OutOfRangeException(var9, (java.lang.Number)100.0f, (java.lang.Number)var13, (java.lang.Number)0.5000672346092545d);
    java.math.BigInteger var16 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, var13);
    java.math.BigInteger var18 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, 10L);
    org.apache.commons.math3.exception.NotStrictlyPositiveException var19 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var1, (java.lang.Number)var18);
    org.apache.commons.math3.exception.util.Localizable var22 = null;
    java.math.BigInteger var24 = null;
    java.math.BigInteger var26 = org.apache.commons.math3.util.ArithmeticUtils.pow(var24, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var28 = new org.apache.commons.math3.exception.OutOfRangeException(var22, (java.lang.Number)100.0f, (java.lang.Number)var26, (java.lang.Number)0.5000672346092545d);
    org.apache.commons.math3.exception.util.Localizable var29 = null;
    java.math.BigInteger var31 = null;
    java.math.BigInteger var33 = org.apache.commons.math3.util.ArithmeticUtils.pow(var31, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var35 = new org.apache.commons.math3.exception.OutOfRangeException(var29, (java.lang.Number)100.0f, (java.lang.Number)var33, (java.lang.Number)0.5000672346092545d);
    java.math.BigInteger var36 = org.apache.commons.math3.util.ArithmeticUtils.pow(var26, var33);
    java.math.BigInteger var38 = org.apache.commons.math3.util.ArithmeticUtils.pow(var26, 31L);
    org.apache.commons.math3.exception.OutOfRangeException var39 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)8.799063409660144E86d, (java.lang.Number)0.99999994f, (java.lang.Number)var26);
    java.math.BigInteger var40 = org.apache.commons.math3.util.ArithmeticUtils.pow(var18, var26);
    org.apache.commons.math3.exception.NotPositiveException var41 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);

  }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test404"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(0.47968781985228015d, 0.5075374788683407d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.02462879717982469d);

  }

  public void test405() {}
//   public void test405() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test405"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.math.BigInteger var2 = null;
//     java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 0L);
//     org.apache.commons.math3.exception.OutOfRangeException var6 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)100.0f, (java.lang.Number)var4, (java.lang.Number)0.5000672346092545d);
//     java.math.BigInteger var7 = null;
//     java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, var7);
// 
//   }

  public void test406() {}
//   public void test406() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test406"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     double var17 = var0.nextGamma(0.9775852669347048d, 3.199763873047224E14d);
//     double var20 = var0.nextF(2.636818730233018d, 1.1282937610745374d);
//     var0.reSeed(6L);
//     java.lang.String var24 = var0.nextSecureHexString(12827000);
//     java.util.Collection var25 = null;
//     java.lang.Object[] var27 = var0.nextSample(var25, 22927);
// 
//   }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test407"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double[] var2 = var0.sample(1);
    double var3 = var0.getSupportUpperBound();
    double var5 = var0.cumulativeProbability(1.9999999958199324d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.977249867826135d);

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test408"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(3941415383162945436L, 9453727L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3941415383172399163L);

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test409"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(0.0f, 50.000015f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test410"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble(102);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9.614466715036176E161d);

  }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test411"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0.46413974520156737d);
    java.lang.Number var2 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0+ "'", var2.equals(0));

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test412"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.0f, 0.1572992076586297d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.4E-45f);

  }

  public void test413() {}
//   public void test413() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test413"); }
// 
// 
//     org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     var0.setContractionCriteria(5.0f);
//     org.apache.commons.math3.random.RandomDataImpl var3 = new org.apache.commons.math3.random.RandomDataImpl();
//     boolean var4 = var0.equals((java.lang.Object)var3);
//     var3.reSeedSecure(27900L);
//     double var8 = var3.nextExponential(6.770911672198755d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var3.nextF(0.0d, 11.551986904995205d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 4.222090890690339d);
// 
//   }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test414"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(2560, 100.0f);

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test415"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var2 = var0.addElementRolling(4.629628685877713E42d);
    double[] var4 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    double[] var7 = var6.getElements();
    var0.addElements(var7);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var0.copy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var9.discardFrontElements(47);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test416"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    java.lang.String var2 = var1.name();
    java.lang.String var3 = var1.name();
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var5.getTiesStrategy();
    int var7 = var6.ordinal();
    java.lang.String var8 = var6.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var6);
    double[] var11 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var11);
    var12.setContractionCriteria(50.000008f);
    var12.setExpansionMode(0);
    boolean var17 = var6.equals((java.lang.Object)var12);
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var18.setContractionCriteria(5.0f);
    var18.setElement(110, Double.NaN);
    var18.discardFrontElements(10);
    int var26 = var18.getExpansionMode();
    double[] var28 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var29 = new org.apache.commons.math3.util.ResizableDoubleArray(var28);
    org.apache.commons.math3.util.ResizableDoubleArray var30 = new org.apache.commons.math3.util.ResizableDoubleArray(var28);
    double[] var31 = var30.getElements();
    var18.addElements(var31);
    var12.addElements(var31);
    float var34 = var12.getExpansionFactor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var12.setExpansionMode(145);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "MAXIMAL"+ "'", var2.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "MAXIMAL"+ "'", var3.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 2.0f);

  }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test417"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)1.3418720970618036E43d, (java.lang.Number)5.0f, true);
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.exception.NotPositiveException var10 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(short)1);
    java.lang.Object[] var11 = new java.lang.Object[] { (short)1};
    org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, var11);
    org.apache.commons.math3.exception.MathInternalError var13 = new org.apache.commons.math3.exception.MathInternalError(var7, var11);
    java.lang.Object[] var14 = new java.lang.Object[] { var11};
    org.apache.commons.math3.exception.MathInternalError var15 = new org.apache.commons.math3.exception.MathInternalError(var6, var14);
    org.apache.commons.math3.exception.MaxCountExceededException var16 = new org.apache.commons.math3.exception.MaxCountExceededException(var4, (java.lang.Number)7.446477798073399d, var14);
    java.lang.Number var17 = var16.getMax();
    var3.addSuppressed((java.lang.Throwable)var16);
    boolean var19 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + 7.446477798073399d+ "'", var17.equals(7.446477798073399d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);

  }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test418"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(-2.1520997728497173d));

  }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test419"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.22669496104614656d, 1.7802921927502E35d);
    double var5 = var2.cumulativeProbability(0.08142857470882658d, 0.8739440070527092d);
    double var6 = var2.getSupportLowerBound();
    double var7 = var2.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.7759327099232096E-36d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == Double.NEGATIVE_INFINITY);

  }

  public void test420() {}
//   public void test420() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test420"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     double var16 = var0.nextWeibull(1.0d, 1.6298598478788293d);
//     double var19 = var0.nextCauchy((-1.1440883267692863E33d), 3.3030345912774096E43d);
//     double var22 = var0.nextUniform(335.0334109186577d, 7.22597376812575E86d);
//     int var25 = var0.nextSecureInt(61, 145);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "a80467560b2e63cacdacb27da83b80f19fef5d4649b3a8f0dee877fefb2a96235a4598e7e574ce38a470e74a14ba1d46d011"+ "'", var2.equals("a80467560b2e63cacdacb27da83b80f19fef5d4649b3a8f0dee877fefb2a96235a4598e7e574ce38a470e74a14ba1d46d011"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-1.2676237684415437E43d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.3283282231412687d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-9.030768512096016E43d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 2.407107003947584E86d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 85);
// 
//   }

  public void test421() {}
//   public void test421() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test421"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(1.0713813143399866d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test422() {}
//   public void test422() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test422"); }
// 
// 
//     java.lang.Class var0 = null;
//     java.lang.Enum var2 = java.lang.Enum.<java.lang.Enum>valueOf(var0, "bbc76c98706e096cbdb48c11be18b37feafe094ae0e5291b81fe65cbd0c42cc6f465c322de0f5afaf8fdd0237c92d0d9c2d6");
// 
//   }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test423"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.027073110299788997d, (java.lang.Number)344L, false);

  }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test424"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    java.lang.String var2 = var1.toString();
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.NotPositiveException var5 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(short)1);
    java.lang.Object[] var6 = new java.lang.Object[] { (short)1};
    org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException(var3, var6);
    boolean var8 = var1.equals((java.lang.Object)var3);
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    int var10 = var1.ordinal();
    int var11 = var1.ordinal();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "MAXIMAL"+ "'", var2.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);

  }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test425"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(27898L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test426() {}
//   public void test426() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test426"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     double var17 = var0.nextGamma(0.9775852669347048d, 3.199763873047224E14d);
//     double var20 = var0.nextUniform(0.0d, 8.799063409660144E86d);
//     var0.reSeed();
//     org.apache.commons.math3.distribution.NormalDistribution var22 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var23 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var22);
//     double var24 = var22.getSupportUpperBound();
//     boolean var25 = var22.isSupportConnected();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "72aeab9f7b94594239eb440a25f89c8a4ab2b1396883b77fd780b898838e166bdb6e63a6a13df15a4393f43b42bcbd96cfba"+ "'", var2.equals("72aeab9f7b94594239eb440a25f89c8a4ab2b1396883b77fd780b898838e166bdb6e63a6a13df15a4393f43b42bcbd96cfba"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.783077950141816E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 3.334975982741754E14d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 5.444498104509835E86d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == (-0.1863888325704912d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == true);
// 
//   }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test427"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(22927, 768793337);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test428"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(101, 112);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-11));

  }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test429"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    java.lang.String var2 = var1.name();
    java.lang.String var3 = var1.toString();
    java.lang.String var4 = var1.toString();
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var5.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var7);
    org.apache.commons.math3.stat.ranking.NaNStrategy var9 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var9);
    org.apache.commons.math3.stat.ranking.TiesStrategy var11 = var10.getTiesStrategy();
    int var12 = var11.ordinal();
    java.lang.String var13 = var11.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var11);
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var11);
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var17 = var16.getNanStrategy();
    java.lang.String var18 = var17.name();
    java.lang.String var19 = var17.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var21 = var20.getNanStrategy();
    java.lang.String var22 = var21.name();
    java.lang.String var23 = var21.name();
    org.apache.commons.math3.stat.ranking.NaNStrategy var24 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var25 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var24);
    org.apache.commons.math3.stat.ranking.TiesStrategy var26 = var25.getTiesStrategy();
    int var27 = var26.ordinal();
    java.lang.String var28 = var26.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var29 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var21, var26);
    java.lang.String var30 = var21.name();
    org.apache.commons.math3.stat.ranking.NaNStrategy var31 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var32 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var31);
    org.apache.commons.math3.stat.ranking.TiesStrategy var33 = var32.getTiesStrategy();
    int var34 = var33.ordinal();
    java.lang.String var35 = var33.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var36 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var21, var33);
    org.apache.commons.math3.stat.ranking.TiesStrategy var37 = var36.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var38 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var37);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var39 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var17, var37);
    org.apache.commons.math3.stat.ranking.NaturalRanking var40 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "MAXIMAL"+ "'", var2.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "MAXIMAL"+ "'", var3.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "MAXIMAL"+ "'", var4.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "AVERAGE"+ "'", var13.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + "MAXIMAL"+ "'", var18.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "MAXIMAL"+ "'", var19.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + "MAXIMAL"+ "'", var22.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + "MAXIMAL"+ "'", var23.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + "AVERAGE"+ "'", var28.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + "MAXIMAL"+ "'", var30.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var35 + "' != '" + "AVERAGE"+ "'", var35.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test430"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.NotPositiveException var5 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(short)1);
    java.lang.Object[] var6 = new java.lang.Object[] { (short)1};
    org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException(var3, var6);
    org.apache.commons.math3.exception.MathArithmeticException var8 = new org.apache.commons.math3.exception.MathArithmeticException(var2, var6);
    org.apache.commons.math3.exception.MaxCountExceededException var9 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)(-2.400188641955425d), var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test431() {}
//   public void test431() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test431"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     double var4 = var0.nextExponential(0.056182176564052d);
//     int var7 = var0.nextInt((-127), 2);
//     long var10 = var0.nextSecureLong(322L, 14528100L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var0.nextBinomial(73, 4.88929883633965E14d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "72d3e3827d032a1185ece94acbe1d48d2463e8d2a06e66dce4eaef17dece40a0b420fa0bfa56433a0960323126bad9fc46f7"+ "'", var2.equals("72d3e3827d032a1185ece94acbe1d48d2463e8d2a06e66dce4eaef17dece40a0b420fa0bfa56433a0960323126bad9fc46f7"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.02285570471878901d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-81));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 2622628L);
// 
//   }

  public void test432() {}
//   public void test432() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test432"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     double var17 = var0.nextBeta(1.1265425086815434E43d, 1.1282937610745374d);
//     double var20 = var0.nextGamma(3.3030345912774096E43d, 1.8497873475441418d);
//     long var22 = var0.nextPoisson(0.010092770659726726d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "0a514c6d31fa2619bc6b8c99cb446e1de3df6a0155bc143f519796ab395b752c22b53f1146a32c15ca2fcd80d86ee9ab4541"+ "'", var2.equals("0a514c6d31fa2619bc6b8c99cb446e1de3df6a0155bc143f519796ab395b752c22b53f1146a32c15ca2fcd80d86ee9ab4541"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-3.0007221472519547E43d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.999999998383501d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 6.109911595445588E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0L);
// 
//   }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test433"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(3.1596484740079465d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.8677580919141257d);

  }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test434"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(1.1965196338861661d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.3655993905713525d);

  }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test435"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var1 = null;
    org.apache.commons.math3.exception.MathInternalError var2 = new org.apache.commons.math3.exception.MathInternalError(var0, var1);
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var2.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test436"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double[] var2 = var0.sample(1);
    double var3 = var0.getMean();
    boolean var4 = var0.isSupportUpperBoundInclusive();
    double var5 = var0.getSupportUpperBound();
    double var7 = var0.probability(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);

  }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test437"); }


    double var1 = org.apache.commons.math3.util.FastMath.acos(0.46795008060179255d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.083826533544118d);

  }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test438"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(-0.11419179453672551d));

  }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test439"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial((-1347981273));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test440"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh(0.5518281445502153d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6210060991179898d);

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test441"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = var3.copy();
    double var6 = var3.addElementRolling(0.3088209685048367d);
    var3.addElement((-29.20448759054539d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);

  }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test442"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(2.3267104437205868d, 3.874110573361593E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.3267104437205868d);

  }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test443"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(50.000008f);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = var0.copy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.discardMostRecentElements(1);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test444"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var5.getTiesStrategy();
    int var7 = var6.ordinal();
    java.lang.String var8 = var6.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var6);
    org.apache.commons.math3.stat.ranking.TiesStrategy var10 = var9.getTiesStrategy();
    java.lang.String var11 = var10.toString();
    java.lang.String var12 = var10.name();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "AVERAGE"+ "'", var11.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "AVERAGE"+ "'", var12.equals("AVERAGE"));

  }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test445"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    var3.reseedRandomGenerator(1L);
    boolean var6 = var3.isSupportConnected();
    double var7 = var3.getNumericalMean();
    double var8 = var3.getNumericalMean();
    double var9 = var3.getNumericalMean();
    double[] var11 = var3.sample(3);
    double var13 = var3.probability(0.7510386511223553d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);

  }

  public void test446() {}
//   public void test446() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test446"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     java.lang.String var4 = var0.nextHexString(110);
//     int var7 = var0.nextPascal(3, 0.0d);
//     int var10 = var0.nextSecureInt(47, 110);
//     var0.reSeedSecure(300L);
//     long var15 = var0.nextSecureLong(0L, 28798L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var17 = var0.nextSecureHexString(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.8878751466362659d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "5f1a1a0525544d886a53d00ed054d6f33ac89c6c7aaff3997428985bc756e4d7a6ede94d6ab8fb09ef29684810dfa44b62dd769bdddbc8"+ "'", var4.equals("5f1a1a0525544d886a53d00ed054d6f33ac89c6c7aaff3997428985bc756e4d7a6ede94d6ab8fb09ef29684810dfa44b62dd769bdddbc8"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 8421L);
// 
//   }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test447"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(0.12070025484573474d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test448"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble((-11480));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test449() {}
//   public void test449() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test449"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     double var5 = var0.nextGaussian(0.0d, 0.5d);
//     var0.reSeed(10L);
//     double var10 = var0.nextF(1.3872175661331396d, 2.636818730233018d);
//     double var14 = var0.nextUniform(0.9732473842406116d, 5.840802579076462E13d, true);
//     double var16 = var0.nextT(0.1916590679018214d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var19 = var0.nextInt(1612820, 102);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 4.918413327369408d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.2829960050633321d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5088599843857857d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 5.576893584435181E13d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == (-0.11749191567656628d));
// 
//   }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test450"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)2.0d, (java.lang.Number)50.0f, (java.lang.Number)436.05387683681073d);
    java.lang.Number var4 = var3.getLo();
    java.lang.Number var5 = var3.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 50.0f+ "'", var4.equals(50.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 50.0f+ "'", var5.equals(50.0f));

  }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test451"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(5.0f);
    org.apache.commons.math3.random.RandomDataImpl var3 = new org.apache.commons.math3.random.RandomDataImpl();
    boolean var4 = var0.equals((java.lang.Object)var3);
    var0.addElement(Double.NaN);
    var0.addElement(2.7573353102077896E-32d);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test452"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var5 = new double[] { 1.0d, 100.0d};
    var2.addElements(var5);
    int var7 = var2.getExpansionMode();
    boolean var9 = var2.equals((java.lang.Object)(-3.8937895592837686d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test453"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(657919, (-1.0f));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test454"); }


    int var2 = org.apache.commons.math3.util.FastMath.min((-122), 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-122));

  }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test455"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.NotPositiveException var3 = new org.apache.commons.math3.exception.NotPositiveException(var1, (java.lang.Number)(short)100);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var5 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test456"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(1.467676433654607E-44d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.5615786121201006E-46d);

  }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test457"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.5174537782658822d, 1.7018254074221328d);

  }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test458"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(27900L, (-9223372036854775808L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4L);

  }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test459"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh((-1.0535313540516738E43d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.NEGATIVE_INFINITY);

  }

  public void test460() {}
//   public void test460() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test460"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     java.lang.String var4 = var0.nextHexString(110);
//     double var7 = var0.nextGamma(0.9999999999999971d, 1.151569395337692d);
//     double var9 = var0.nextT(1.2982587902415216E14d);
//     var0.reSeedSecure(0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var14 = var0.nextLong(27000L, 33L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.4038218547126706d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "ab3c48db1606e0d505a790b6a2f1f2fe3829d4604a6aa3bbf7cd90b07ceb476c510cb24e2db918898c364a6d0d0f08f90ef0b098e3f1cf"+ "'", var4.equals("ab3c48db1606e0d505a790b6a2f1f2fe3829d4604a6aa3bbf7cd90b07ceb476c510cb24e2db918898c364a6d0d0f08f90ef0b098e3f1cf"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.10899272033900372d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1.1004260532391503d));
// 
//   }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test461"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    var3.reseedRandomGenerator(1L);
    boolean var6 = var3.isSupportConnected();
    double var7 = var3.getMean();
    double var8 = var3.sample();
    double var10 = var3.density(6.770911672198755d);
    double var11 = var3.getNumericalVariance();
    double var13 = var3.probability(0.028514560146996132d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 3.5671315446818194E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1.4840955931403377E-44d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 7.22597376812575E86d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);

  }

  public void test462() {}
//   public void test462() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test462"); }
// 
// 
//     org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     var0.setContractionCriteria(5.0f);
//     org.apache.commons.math3.random.RandomDataImpl var3 = new org.apache.commons.math3.random.RandomDataImpl();
//     boolean var4 = var0.equals((java.lang.Object)var3);
//     var3.reSeedSecure(27900L);
//     double var8 = var3.nextExponential(6.770911672198755d);
//     java.lang.String var10 = var3.nextHexString(127);
//     org.apache.commons.math3.distribution.IntegerDistribution var11 = null;
//     int var12 = var3.nextInversionDeviate(var11);
// 
//   }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test463"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.6945971187784026d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test464() {}
//   public void test464() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test464"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(2.8611609855390546E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test465"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(1612773, 0.0f, 2.0000002f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test466"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = var2.copy();
    var2.addElement(0.0018388436884212223d);
    double[] var6 = var2.getElements();
    double[] var7 = var2.getInternalValues();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test467"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(5.0f);
    org.apache.commons.math3.random.RandomDataImpl var3 = new org.apache.commons.math3.random.RandomDataImpl();
    boolean var4 = var0.equals((java.lang.Object)var3);
    float var5 = var0.getContractionCriteria();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.discardMostRecentElements((-1347981273));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 5.0f);

  }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test468"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    var3.reseedRandomGenerator(1L);
    double var7 = var3.cumulativeProbability(0.0d);
    double var8 = var3.getStandardDeviation();
    double var9 = var3.sample();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var12 = var3.cumulativeProbability(1.1243845260031315d, 0.5225787170494783d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.6881171418161356E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 3.5671315446818194E43d);

  }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test469"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(20, 102400);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test470"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(0L, 27000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 27000L);

  }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test471"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(227, 21792);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-21565));

  }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test472"); }


    int var1 = org.apache.commons.math3.util.FastMath.round((-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test473"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(2.7573353102077896E-32d, 0.06128730532108836d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.7573353102077896E-32d);

  }

  public void test474() {}
//   public void test474() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test474"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 1820841455);
// 
//   }

  public void test475() {}
//   public void test475() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test475"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     long var16 = var0.nextLong((-92L), 900L);
//     org.apache.commons.math3.distribution.IntegerDistribution var17 = null;
//     int var18 = var0.nextInversionDeviate(var17);
// 
//   }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test476"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(5.0f);
    var0.setElement(110, Double.NaN);
    var0.discardFrontElements(10);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var8.setContractionCriteria(50.000008f);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var8);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
    var12.setContractionCriteria(102400.0f);

  }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test477"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var2 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MathInternalError var3 = new org.apache.commons.math3.exception.MathInternalError(var1, (java.lang.Object[])var2);
    org.apache.commons.math3.exception.NullArgumentException var4 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test478"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    java.lang.String var2 = var1.name();
    java.lang.String var3 = var1.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = var4.getNanStrategy();
    java.lang.String var6 = var5.name();
    java.lang.String var7 = var5.name();
    org.apache.commons.math3.stat.ranking.NaNStrategy var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8);
    org.apache.commons.math3.stat.ranking.TiesStrategy var10 = var9.getTiesStrategy();
    int var11 = var10.ordinal();
    java.lang.String var12 = var10.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5, var10);
    double[] var15 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray(var15);
    var16.setContractionCriteria(50.000008f);
    var16.setExpansionMode(0);
    boolean var21 = var10.equals((java.lang.Object)var16);
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var10);
    int var23 = var1.ordinal();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "MAXIMAL"+ "'", var2.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "MAXIMAL"+ "'", var3.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "MAXIMAL"+ "'", var6.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "MAXIMAL"+ "'", var7.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "AVERAGE"+ "'", var12.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1);

  }

  public void test479() {}
//   public void test479() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test479"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     double var17 = var0.nextGamma(0.9775852669347048d, 3.199763873047224E14d);
//     var0.reSeed();
//     var0.reSeedSecure(27900L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var23 = var0.nextBinomial(115443000, (-2.1520997728497173d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "4050be66e20d3770b396a0e4ff320140b8c4d2757c6d30c0fbdbbe32e1b8e03358e09762f163a152e8d416b34ddc5cb560eb"+ "'", var2.equals("4050be66e20d3770b396a0e4ff320140b8c4d2757c6d30c0fbdbbe32e1b8e03358e09762f163a152e8d416b34ddc5cb560eb"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 4.0773197698827825E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 4.153075956502241E14d);
// 
//   }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test480"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(4.7896923425645504E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test481"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(Float.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Float.POSITIVE_INFINITY);

  }

  public void test482() {}
//   public void test482() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test482"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.22669496104614656d, 1.7802921927502E35d);
//     double var3 = var2.sample();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1.3000151704781529E34d));
// 
//   }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test483"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(4270, 282920086);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 282920086);

  }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test484"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    var3.reseedRandomGenerator(1L);
    boolean var6 = var3.isSupportConnected();
    double var7 = var3.getMean();
    double var8 = var3.sample();
    double var9 = var3.getSupportLowerBound();
    double[] var11 = var3.sample(41580239);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 3.5671315446818194E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test485"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(5281956653691830372L, 449542426);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test486"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(10722.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 10722.000000000002d);

  }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test487"); }


    long var2 = org.apache.commons.math3.util.FastMath.max((-26971L), 90000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 90000L);

  }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test488"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    float var3 = var2.getExpansionFactor();
    boolean var5 = var2.equals((java.lang.Object)1612900);
    boolean var7 = var2.equals((java.lang.Object)"430531212cfe726b7eec9179279f714843afdbcd364e446cac51c9a6d69a2b60e4d94e8af86ef67dd6e834c6d57a10ac0b94");
    double[] var8 = var2.getElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test489() {}
//   public void test489() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test489"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     java.lang.String var4 = var0.nextHexString(110);
//     double var6 = var0.nextChiSquare(0.9865330122406505d);
//     var0.reSeedSecure(28798L);
//     var0.reSeedSecure((-3941415383162945536L));
//     long var12 = var0.nextPoisson(2.225470140808926d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.178555839130503d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "97f9e24b5cecdb4826a786e3688dc77f58abaf14c9f36a1d4c5dc7cd79ebb0278a8236ad11405cfaa05b9eccfa9569d5a38fc1fff3ff9d"+ "'", var4.equals("97f9e24b5cecdb4826a786e3688dc77f58abaf14c9f36a1d4c5dc7cd79ebb0278a8236ad11405cfaa05b9eccfa9569d5a38fc1fff3ff9d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.6251128886814286d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1L);
// 
//   }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test490"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.addElement(0.02797455810085192d);
    var0.discardFrontElements(1);
    int var5 = var0.getNumElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setElement(645781745, 2.1104109613941144d);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);

  }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test491"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var3 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var2);
    java.lang.String var4 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "MAXIMAL"+ "'", var4.equals("MAXIMAL"));

  }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test492"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(1.1340120103131339E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test493() {}
//   public void test493() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test493"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ((-1.7637480459284904d), (-6.935585632560808E42d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test494"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.13194341175745541d, (java.lang.Number)(-4.9E-324d), true);

  }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test495"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)3.481840771213688d);
    java.lang.Number var3 = var2.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 3.481840771213688d+ "'", var3.equals(3.481840771213688d));

  }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test496"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.6210060991179898d, (java.lang.Number)4.605170185988091d, true);

  }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test497"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.math.BigInteger var3 = null;
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var7 = new org.apache.commons.math3.exception.OutOfRangeException(var1, (java.lang.Number)100.0f, (java.lang.Number)var5, (java.lang.Number)0.5000672346092545d);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    java.math.BigInteger var10 = null;
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var10, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var14 = new org.apache.commons.math3.exception.OutOfRangeException(var8, (java.lang.Number)100.0f, (java.lang.Number)var12, (java.lang.Number)0.5000672346092545d);
    java.math.BigInteger var15 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, var12);
    java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 10L);
    org.apache.commons.math3.exception.NotStrictlyPositiveException var18 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)var17);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.math.BigInteger var23 = null;
    java.math.BigInteger var25 = org.apache.commons.math3.util.ArithmeticUtils.pow(var23, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var27 = new org.apache.commons.math3.exception.OutOfRangeException(var21, (java.lang.Number)100.0f, (java.lang.Number)var25, (java.lang.Number)0.5000672346092545d);
    org.apache.commons.math3.exception.util.Localizable var28 = null;
    java.math.BigInteger var30 = null;
    java.math.BigInteger var32 = org.apache.commons.math3.util.ArithmeticUtils.pow(var30, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var34 = new org.apache.commons.math3.exception.OutOfRangeException(var28, (java.lang.Number)100.0f, (java.lang.Number)var32, (java.lang.Number)0.5000672346092545d);
    java.math.BigInteger var35 = org.apache.commons.math3.util.ArithmeticUtils.pow(var25, var32);
    java.math.BigInteger var37 = org.apache.commons.math3.util.ArithmeticUtils.pow(var25, 31L);
    org.apache.commons.math3.exception.OutOfRangeException var38 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)8.799063409660144E86d, (java.lang.Number)0.99999994f, (java.lang.Number)var25);
    java.math.BigInteger var39 = org.apache.commons.math3.util.ArithmeticUtils.pow(var17, var25);
    java.math.BigInteger var41 = org.apache.commons.math3.util.ArithmeticUtils.pow(var25, 48436L);
    java.math.BigInteger var43 = org.apache.commons.math3.util.ArithmeticUtils.pow(var41, 2432902008176730001L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);

  }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test498"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(20L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test499"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(100, 100.0f);
    var2.clear();
    var2.setNumElements(110);
    var2.addElement(2.1559381324233437E43d);
    var2.contract();

  }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test500"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    java.lang.String var3 = var2.name();
    java.lang.String var4 = var2.toString();
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var6.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var9 = var8.getNanStrategy();
    java.lang.String var10 = var9.name();
    java.lang.String var11 = var9.name();
    org.apache.commons.math3.stat.ranking.NaNStrategy var12 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12);
    org.apache.commons.math3.stat.ranking.TiesStrategy var14 = var13.getTiesStrategy();
    int var15 = var14.ordinal();
    java.lang.String var16 = var14.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var9, var14);
    double[] var19 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray(var19);
    var20.setContractionCriteria(50.000008f);
    var20.setExpansionMode(0);
    boolean var25 = var14.equals((java.lang.Object)var20);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var26 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var7, var14);
    org.apache.commons.math3.stat.ranking.NaturalRanking var27 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var14);
    org.apache.commons.math3.stat.ranking.NaturalRanking var28 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var14);
    org.apache.commons.math3.stat.ranking.NaNStrategy var29 = var28.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var30 = var28.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var31 = var28.getNanStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "MAXIMAL"+ "'", var3.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "MAXIMAL"+ "'", var4.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "MAXIMAL"+ "'", var10.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "MAXIMAL"+ "'", var11.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + "AVERAGE"+ "'", var16.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);

  }

}
