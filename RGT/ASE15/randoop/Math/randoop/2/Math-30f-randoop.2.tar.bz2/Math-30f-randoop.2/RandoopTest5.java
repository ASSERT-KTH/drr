
import junit.framework.*;

public class RandoopTest5 extends TestCase {

  public static boolean debug = false;

  public void test1() {}
//   public void test1() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test1"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     double var16 = var0.nextWeibull(1.0d, 1.6298598478788293d);
//     double var19 = var0.nextWeibull(1.151569395337692d, 7.22597376812575E86d);
//     var0.reSeedSecure();
//     double var22 = var0.nextT(1.1004260542535134d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var25 = var0.nextBeta((-3.379759874271399E43d), 0.8335894960500023d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "70c20df36af34113e06371941f4d124077d12e5b9c4ac5ceea49072058d7f0552bdef9ec3cfe6d06896bd666070d88b14820"+ "'", var2.equals("70c20df36af34113e06371941f4d124077d12e5b9c4ac5ceea49072058d7f0552bdef9ec3cfe6d06896bd666070d88b14820"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 2.0145440159382562E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.578178197244575d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 5.601831026063757E86d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == (-1.66272364517911d));
// 
//   }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test2"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.addElement(0.02797455810085192d);
    var0.discardFrontElements(1);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var6 = var5.getInternalValues();
    var0.addElements(var6);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test3"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)6.359453951695099E43d);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test4"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(200.0d, 1.0159453334112069E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.9686098594347242E-41d);

  }

  public void test5() {}
//   public void test5() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test5"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     java.lang.String var4 = var0.nextHexString(110);
//     double var7 = var0.nextGamma(0.9999999999999971d, 1.151569395337692d);
//     org.apache.commons.math3.distribution.NormalDistribution var11 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var11.reseedRandomGenerator(1L);
//     boolean var14 = var11.isSupportConnected();
//     double var15 = var11.getMean();
//     double var16 = var11.getStandardDeviation();
//     double var17 = var11.getStandardDeviation();
//     double var20 = var11.cumulativeProbability(0.5d, 3.899584967339712E86d);
//     double var21 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var11);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var24 = var0.nextExponential(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.9130512989187299d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "78ecf36ca07310373ddc1f009bd1dd4c1fcbf6c91e0793971575aa70bcc180e2299883e86cc59aa9e8a4d0d7e897ab54e1a8059f497405"+ "'", var4.equals("78ecf36ca07310373ddc1f009bd1dd4c1fcbf6c91e0793971575aa70bcc180e2299883e86cc59aa9e8a4d0d7e897ab54e1a8059f497405"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.4442427049315447d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 2.6881171418161356E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 2.6881171418161356E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == (-7.505413501507116E42d));
// 
//   }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test6"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(216770858, (-42));
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test7() {}
//   public void test7() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test7"); }
// 
// 
//     double var1 = org.apache.commons.math3.special.Gamma.logGamma((-6.712617880482323E42d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test8() {}
//   public void test8() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test8"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
//     java.lang.String var3 = var2.name();
//     java.lang.String var4 = var2.toString();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var6.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var9 = var8.getNanStrategy();
//     java.lang.String var10 = var9.name();
//     java.lang.String var11 = var9.name();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var12 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var14 = var13.getTiesStrategy();
//     int var15 = var14.ordinal();
//     java.lang.String var16 = var14.name();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var9, var14);
//     double[] var19 = new double[] { 1.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray(var19);
//     var20.setContractionCriteria(50.000008f);
//     var20.setExpansionMode(0);
//     boolean var25 = var14.equals((java.lang.Object)var20);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var26 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var7, var14);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var27 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var14);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var28 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var14);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var29 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var30 = var29.getNanStrategy();
//     java.lang.String var31 = var30.name();
//     java.lang.String var32 = var30.name();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var33 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var34 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var33);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var35 = var34.getTiesStrategy();
//     int var36 = var35.ordinal();
//     java.lang.String var37 = var35.name();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var38 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var30, var35);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var39 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var40 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var39);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var41 = var40.getTiesStrategy();
//     int var42 = var41.ordinal();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var43 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var30, var41);
//     double[] var45 = new double[] { 1.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var46 = new org.apache.commons.math3.util.ResizableDoubleArray(var45);
//     org.apache.commons.math3.util.ResizableDoubleArray var47 = new org.apache.commons.math3.util.ResizableDoubleArray(var45);
//     double[] var48 = var47.getElements();
//     org.apache.commons.math3.util.ResizableDoubleArray var51 = new org.apache.commons.math3.util.ResizableDoubleArray(10, 50.0f);
//     var51.setElement(12700, 1.0806511876345213E86d);
//     org.apache.commons.math3.distribution.NormalDistribution var55 = new org.apache.commons.math3.distribution.NormalDistribution();
//     boolean var56 = var55.isSupportUpperBoundInclusive();
//     boolean var57 = var55.isSupportLowerBoundInclusive();
//     double var58 = var55.getMean();
//     double[] var60 = var55.sample(110);
//     var51.addElements(var60);
//     double var62 = var43.mannWhitneyUTest(var48, var60);
//     double[] var63 = var28.rank(var60);
// 
//   }

  public void test9() {}
//   public void test9() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test9"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     double var17 = var0.nextGamma(0.9775852669347048d, 3.199763873047224E14d);
//     var0.reSeed(27900L);
//     double var23 = var0.nextUniform(0.18029079387572064d, 1.70638274610834d, false);
//     double var26 = var0.nextGamma(0.0018388436884212223d, 4.951760157141521E27d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var30 = var0.nextHypergeometric(54, 20, 102248832);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "a85d4eb1e0abe39fea14ce8173d7f24ba46d96871a16e83308faf56f67602ac8b1b94632331f000423e8363242f6b6ef3d67"+ "'", var2.equals("a85d4eb1e0abe39fea14ce8173d7f24ba46d96871a16e83308faf56f67602ac8b1b94632331f000423e8363242f6b6ef3d67"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-1.2604681077814124E42d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 9.723385603829782E14d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.8399341499662786d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 8.482444959569576E-82d);
// 
//   }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test10"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(100.49999f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test11"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    double var6 = var3.cumulativeProbability(1.4210854715202004E-14d, 2.0d);
    double var8 = var3.probability(2.5183972256671465d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.9681911862806774E-44d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test12"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(100, 100.0f);
    var2.clear();
    var2.setNumElements(110);
    var2.addElement(2.1559381324233437E43d);
    float var8 = var2.getContractionCriteria();
    float var9 = var2.getContractionCriteria();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 100.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 100.5f);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test13"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(287, 6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 287);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test14"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var2.setContractionCriteria(50.000008f);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = var2.copy();
    int var6 = var5.start();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var5.getElement(282920086);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);

  }

  public void test15() {}
//   public void test15() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test15"); }
// 
// 
//     org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     var0.setContractionCriteria(5.0f);
//     org.apache.commons.math3.random.RandomDataImpl var3 = new org.apache.commons.math3.random.RandomDataImpl();
//     boolean var4 = var0.equals((java.lang.Object)var3);
//     var3.reSeedSecure(27900L);
//     double var8 = var3.nextExponential(6.770911672198755d);
//     var3.reSeedSecure(0L);
//     double var13 = var3.nextBeta(2.3267104437205868d, 4.791816278040792E86d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var3.nextBinomial(1221758388, 11.551986904995205d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 7.906826348187748d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.0d);
// 
//   }

  public void test16() {}
//   public void test16() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test16"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     double var17 = var0.nextBeta(1.1265425086815434E43d, 1.1282937610745374d);
//     long var19 = var0.nextPoisson(31.402066659134473d);
//     double var23 = var0.nextUniform(0.0d, 0.40394226160288377d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var26 = var0.nextLong(60796841L, (-6890464530323402752L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "efe096f762e067afef0c8e3bcea5c6cbfd488dea2860219062958e6328757e333bc6e14b72c71fddd9c8731769ba41a4827d"+ "'", var2.equals("efe096f762e067afef0c8e3bcea5c6cbfd488dea2860219062958e6328757e333bc6e14b72c71fddd9c8731769ba41a4827d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 2.239619619955566E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 30L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.07780240958308948d);
// 
//   }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test17"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign((-1.4E-45f), 2560.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.4E-45f);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test18"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double[] var2 = var0.sample(1);
    double var3 = var0.getMean();
    boolean var4 = var0.isSupportUpperBoundInclusive();
    boolean var5 = var0.isSupportUpperBoundInclusive();
    double var8 = var0.cumulativeProbability(1.3626999595542073d, 5.458802422386986E43d);
    double var9 = var0.getMean();
    double var11 = var0.inverseCumulativeProbability(0.06578711824213442d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.08648854529952615d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-1.5079229954580489d));

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test19"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.math.BigInteger var3 = null;
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var7 = new org.apache.commons.math3.exception.OutOfRangeException(var1, (java.lang.Number)100.0f, (java.lang.Number)var5, (java.lang.Number)0.5000672346092545d);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    java.math.BigInteger var10 = null;
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var10, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var14 = new org.apache.commons.math3.exception.OutOfRangeException(var8, (java.lang.Number)100.0f, (java.lang.Number)var12, (java.lang.Number)0.5000672346092545d);
    java.math.BigInteger var15 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, var12);
    java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 12700);
    org.apache.commons.math3.exception.NumberIsTooLargeException var20 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)12700, (java.lang.Number)1221758388, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test20() {}
//   public void test20() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test20"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     double var4 = var0.nextExponential(0.056182176564052d);
//     double var7 = var0.nextGamma((-2.0537907646431078E43d), 5.840802579076462E13d);
//     double var10 = var0.nextF(0.03673319830899499d, 2.6881171418161356E43d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var0.nextHypergeometric(5, (-127), 367);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "6e2ce45bf562967d8f9808a9b2fac4debf65d35bc53ee83ed96179cab003c5beb404388fbd3cfd99187377c4ddb125c21390"+ "'", var2.equals("6e2ce45bf562967d8f9808a9b2fac4debf65d35bc53ee83ed96179cab003c5beb404388fbd3cfd99187377c4ddb125c21390"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.00426981431185486d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.0d);
// 
//   }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test21"); }


    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(2, 10.0f, 10.0f, 1);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    double[] var7 = var4.getElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test22"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    var3.reseedRandomGenerator(1L);
    double var7 = var3.cumulativeProbability(0.0d);
    double var9 = var3.cumulativeProbability(1.0d);
    double var10 = var3.sample();
    double var11 = var3.getSupportLowerBound();
    boolean var12 = var3.isSupportUpperBoundInclusive();
    var3.reseedRandomGenerator(2L);
    boolean var15 = var3.isSupportUpperBoundInclusive();
    double var16 = var3.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 3.5671315446818194E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 7.22597376812575E86d);

  }

  public void test23() {}
//   public void test23() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test23"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     boolean var9 = var6.isSupportConnected();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     double var12 = var6.probability(6.0d);
//     double var15 = var6.cumulativeProbability((-2.1317761108019555d), 0.9640275797804917d);
//     double var17 = var6.cumulativeProbability(0.02797455810085192d);
//     boolean var18 = var6.isSupportLowerBoundInclusive();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "04a8d3ecd9f48b35a464a5a57d7e71b57cb2c9384453a6f8ccafc4803ac21931290e427569557d4b1d026b6433a404763355"+ "'", var2.equals("04a8d3ecd9f48b35a464a5a57d7e71b57cb2c9384453a6f8ccafc4803ac21931290e427569557d4b1d026b6433a404763355"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.4247401641213489E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 4.594468614421035E-44d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
// 
//   }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test24"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(52037, 141);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-449867819));

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test25"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(2560, 102400.02f, 9.5367426E-7f, (-11));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test26"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(2560.0f, 0.051884571948430845d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2559.9998f);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test27"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(88, (-11));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test28"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-3941415383162945536L), (java.lang.Number)0.99999994f, false);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test29"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees((-2.1520997728497173d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-123.30623407535195d));

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test30"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    java.lang.String var2 = var1.name();
    java.lang.String var3 = var1.name();
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var5.getTiesStrategy();
    int var7 = var6.ordinal();
    java.lang.String var8 = var6.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var6);
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = var11.getTiesStrategy();
    int var13 = var12.ordinal();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var14 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var12);
    org.apache.commons.math3.distribution.NormalDistribution var17 = new org.apache.commons.math3.distribution.NormalDistribution(Double.POSITIVE_INFINITY, 4.111122573849115E13d);
    double var19 = var17.probability(0.0d);
    double var20 = var17.getSupportUpperBound();
    boolean var21 = var12.equals((java.lang.Object)var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "MAXIMAL"+ "'", var2.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "MAXIMAL"+ "'", var3.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);

  }

  public void test31() {}
//   public void test31() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test31"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     double var17 = var0.nextGamma(0.9775852669347048d, 3.199763873047224E14d);
//     double var20 = var0.nextF(2.636818730233018d, 1.1282937610745374d);
//     var0.reSeed(6L);
//     int var25 = var0.nextInt((-100), 2147483647);
//     org.apache.commons.math3.distribution.NormalDistribution var26 = new org.apache.commons.math3.distribution.NormalDistribution();
//     boolean var27 = var26.isSupportUpperBoundInclusive();
//     boolean var28 = var26.isSupportLowerBoundInclusive();
//     double var29 = var26.getMean();
//     double var30 = var26.getSupportUpperBound();
//     double var32 = var26.probability(3.874110573361593E-4d);
//     double var33 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var26);
//     var0.reSeedSecure(4583304L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "92b45b8c30272c191b2d04988fa6a0f917aea9b2d3fa78f8b0922495e7d1c2c39b88ad3aa2557228ba8675738baaaadd6562"+ "'", var2.equals("92b45b8c30272c191b2d04988fa6a0f917aea9b2d3fa78f8b0922495e7d1c2c39b88ad3aa2557228ba8675738baaaadd6562"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.3239760502464962E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 7.685235988300575E13d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1.5443149152023743d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1742979373);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == (-1.3405768023430444d));
// 
//   }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test32"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(75324600L, 4583304L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 70741296L);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test33"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(558800, (-11480));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 40);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test34"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-4.991268808249555E43d), 0.8030521961633448d);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test35"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray((-22));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test36"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("99c10116af27f87345193f27704f14c055c8f7ddc5429d591415231ee8baf23354e032df596f6e8302aa5fb96daf03f20b7c");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test37"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck((-2L), 2L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-4L));

  }

  public void test38() {}
//   public void test38() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test38"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(1.174518891015242E43d, (-1.735209471803884d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test39"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.5650934208572123d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.7596121595198884d);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test40"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble(1612775);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test41"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(12827000, 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 32.04097850604347d);

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test42"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    float var3 = var2.getExpansionFactor();
    org.apache.commons.math3.util.ResizableDoubleArray var4 = var2.copy();
    float var5 = var4.getExpansionFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2.0f);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test43"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(5.0f);
    org.apache.commons.math3.random.RandomDataImpl var3 = new org.apache.commons.math3.random.RandomDataImpl();
    boolean var4 = var0.equals((java.lang.Object)var3);
    float var5 = var0.getContractionCriteria();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setNumElements(1820841455);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 5.0f);

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test44"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(5.0f);
    var0.setElement(110, Double.NaN);
    var0.discardFrontElements(10);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var8.setContractionCriteria(50.000008f);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var8);
    int var12 = var8.getExpansionMode();
    double[] var13 = var8.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var13);
    var14.discardFrontElements(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test45"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(0.9915520923431179d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9957670873970067d);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test46"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-100), 40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test47"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(5.0f);
    var0.setElement(110, Double.NaN);
    var0.discardFrontElements(10);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var8.setContractionCriteria(50.000008f);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var8);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var12 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var14 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    var15.setContractionCriteria(50.000008f);
    double[] var18 = var15.getInternalValues();
    double[] var20 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var21 = new org.apache.commons.math3.util.ResizableDoubleArray(var20);
    var21.setContractionCriteria(50.000008f);
    double[] var24 = var21.getInternalValues();
    double[] var25 = var21.getElements();
    double var26 = var12.mannWhitneyU(var18, var25);
    var8.addElements(var25);
    var8.contract();
    double[] var30 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var31 = new org.apache.commons.math3.util.ResizableDoubleArray(var30);
    var31.setContractionCriteria(50.000008f);
    var31.setExpansionMode(0);
    var31.setContractionCriteria(5.0f);
    float var38 = var31.getExpansionFactor();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var8, var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 2.0f);

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test48"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("a18a6960667ebe830870bef0dd47c8668e7a7b64af443e11aff71cf15c6f5f62a57ec39698a54a0583a9a53b49df838fad26");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test49() {}
//   public void test49() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test49"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP((-1.6566833932460438E43d), 4.953013069603387E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test50"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(0, 768793337);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 768793337);

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test51"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    java.lang.String var2 = var1.name();
    java.lang.String var3 = var1.name();
    boolean var5 = var1.equals((java.lang.Object)"bbc76c98706e096cbdb48c11be18b37feafe094ae0e5291b81fe65cbd0c42cc6f465c322de0f5afaf8fdd0237c92d0d9c2d6");
    int var6 = var1.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var8 = var7.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var9 = var7.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var10 = var7.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var11 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var10);
    org.apache.commons.math3.stat.ranking.NaNStrategy var12 = null;
    org.apache.commons.math3.random.RandomGenerator var13 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12, var13);
    org.apache.commons.math3.stat.ranking.TiesStrategy var15 = var14.getTiesStrategy();
    java.lang.String var16 = var15.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "MAXIMAL"+ "'", var2.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "MAXIMAL"+ "'", var3.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + "RANDOM"+ "'", var16.equals("RANDOM"));

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test52"); }


    double var1 = org.apache.commons.math3.util.FastMath.acos(0.6969136111134943d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7997115369080446d);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test53"); }


    java.lang.Number var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, var1, true);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test54"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(2.003824768840115d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.5707963267948966d);

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test55"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(1.5706184237765743d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1624034649159922d);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test56"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(14528100L, (-937694931342098688L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 12L);

  }

  public void test57() {}
//   public void test57() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test57"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     double var17 = var0.nextGamma(0.9775852669347048d, 3.199763873047224E14d);
//     double var20 = var0.nextUniform(0.0d, 8.799063409660144E86d);
//     var0.reSeed();
//     org.apache.commons.math3.distribution.NormalDistribution var22 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var23 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var22);
//     java.lang.String var25 = var0.nextSecureHexString(61);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var28 = var0.nextWeibull(0.584554782675576d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "4576a0098c3c99571706e22558deb507471cb8ea6088f4a4303199a7a40f1b028373087f21287ebe7b4a6f5c536b487389cd"+ "'", var2.equals("4576a0098c3c99571706e22558deb507471cb8ea6088f4a4303199a7a40f1b028373087f21287ebe7b4a6f5c536b487389cd"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 4.381257645244331E42d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 2.345032089344719E14d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 3.7745173465874703E86d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.10747284982361241d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var25 + "' != '" + "d55921c3e5f39468a2919c2eb5ab77b5f7fa27f907388f112e8c76251f84c"+ "'", var25.equals("d55921c3e5f39468a2919c2eb5ab77b5f7fa27f907388f112e8c76251f84c"));
// 
//   }

  public void test58() {}
//   public void test58() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test58"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double[] var2 = var0.sample(1);
//     double var3 = var0.getMean();
//     boolean var4 = var0.isSupportUpperBoundInclusive();
//     boolean var5 = var0.isSupportUpperBoundInclusive();
//     double var6 = var0.sample();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.8828206249742314d);
// 
//   }

  public void test59() {}
//   public void test59() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test59"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     boolean var9 = var6.isSupportConnected();
//     double var10 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     double var12 = var6.probability(6.0d);
//     double var15 = var6.cumulativeProbability((-2.1317761108019555d), 0.9640275797804917d);
//     double var17 = var6.density(8.082748966275464E84d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var19 = var6.inverseCumulativeProbability((-1.5707963267948966d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "5c4a505cd8b5e8de19ee54508fe6aea492e3f3e2c8cb67a4c8f1dfc2d3111a93a81781cded6928f51b98b829db4dcfe13c18"+ "'", var2.equals("5c4a505cd8b5e8de19ee54508fe6aea492e3f3e2c8cb67a4c8f1dfc2d3111a93a81781cded6928f51b98b829db4dcfe13c18"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-1.6764037288358706E43d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 4.594468614421035E-44d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.0d);
// 
//   }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test60"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(7.585522823235727E41d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.10830024055666161d));

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test61"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("29594cffc3dae54a8013d4b34a04dae1e083e04f6b8fdc1992207d3b117979ea4b7445a24f8fadf594c4056abb794fb21fe5");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test62"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(50.00001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5);

  }

  public void test63() {}
//   public void test63() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test63"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     java.lang.String var4 = var0.nextHexString(110);
//     double var6 = var0.nextChiSquare(0.9865330122406505d);
//     var0.reSeedSecure(28798L);
//     var0.reSeedSecure((-3941415383162945536L));
//     double var12 = var0.nextExponential(1.5707963267948923d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.3594143937762845d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "bf6148a20bee0aa4035af882fc0c4e85fa9bf93c1c865e819c541485cbed34f25c7917e9ab5a95402d843b64b9621df5cb12fa214f63c1"+ "'", var4.equals("bf6148a20bee0aa4035af882fc0c4e85fa9bf93c1c865e819c541485cbed34f25c7917e9ab5a95402d843b64b9621df5cb12fa214f63c1"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.0471488845001047E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.6064236397171381d);
// 
//   }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test64"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.math.BigInteger var2 = null;
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var6 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)100.0f, (java.lang.Number)var4, (java.lang.Number)0.5000672346092545d);
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    java.math.BigInteger var9 = null;
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var13 = new org.apache.commons.math3.exception.OutOfRangeException(var7, (java.lang.Number)100.0f, (java.lang.Number)var11, (java.lang.Number)0.5000672346092545d);
    java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, var11);
    java.math.BigInteger var16 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 12700);
    java.math.BigInteger var18 = org.apache.commons.math3.util.ArithmeticUtils.pow(var16, 768793337);
    java.math.BigInteger var20 = org.apache.commons.math3.util.ArithmeticUtils.pow(var18, 3L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test65() {}
//   public void test65() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test65"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     double var4 = var0.nextExponential(0.056182176564052d);
//     double var7 = var0.nextWeibull(1.200541497195915d, 2.2682182275901375d);
//     double var9 = var0.nextT(4.605170185988092d);
//     var0.reSeed();
//     org.apache.commons.math3.random.RandomDataImpl var11 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var13 = var11.nextExponential(1.0d);
//     java.lang.String var15 = var11.nextHexString(110);
//     double var17 = var11.nextChiSquare(0.9865330122406505d);
//     var11.reSeedSecure(28798L);
//     org.apache.commons.math3.distribution.NormalDistribution var23 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var23.reseedRandomGenerator(1L);
//     boolean var26 = var23.isSupportConnected();
//     double var27 = var23.getMean();
//     double var28 = var23.sample();
//     double var29 = var23.getSupportUpperBound();
//     boolean var30 = var23.isSupportUpperBoundInclusive();
//     double var31 = var11.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var23);
//     org.apache.commons.math3.distribution.NormalDistribution var32 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var33 = var11.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var32);
//     double var34 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "fb26899ce085c6354408cf56389a83892ac16512e0a61ba5b66d983e93c4025641d60ea11095a40e84f43c4f81429cba0026"+ "'", var2.equals("fb26899ce085c6354408cf56389a83892ac16512e0a61ba5b66d983e93c4025641d60ea11095a40e84f43c4f81429cba0026"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.031799503726936205d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.8284693193649011d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2.1344990755146727d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.7154270933880528d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "4e94813d174eab07e3743acfe4156abc013f0fa526f7e6d09c27b4c00c736d30d6f0ae7168b2c427a0818eb46f96a316682cb378c9a9d1"+ "'", var15.equals("4e94813d174eab07e3743acfe4156abc013f0fa526f7e6d09c27b4c00c736d30d6f0ae7168b2c427a0818eb46f96a316682cb378c9a9d1"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.054564128746670465d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 3.5671315446818194E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 1.128305422162259E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 0.4887569671045242d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 0.7823770343821075d);
// 
//   }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test66"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck((-4), 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test67"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)0.07081992772102039d);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test68"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.8399341499662786d, 0.0d, 2.185089419781954E43d, 70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test69"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(4.815792779656395E42d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 98.28047458535075d);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test70"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(50.000008f);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = var0.copy();
    int var4 = var0.getExpansionMode();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);

  }

  public void test71() {}
//   public void test71() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test71"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(77.53179491216964d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test72"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var2.setContractionCriteria(5.0f);
    var2.setElement(110, Double.NaN);
    var2.setElement(100, (-0.6120891811851691d));
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var2);
    double[] var12 = var2.getInternalValues();
    var2.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test73"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)5.95573570720202E43d, true);
    boolean var4 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test74() {}
//   public void test74() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test74"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     double var5 = var0.nextGaussian(0.0d, 0.5d);
//     var0.reSeed(10L);
//     double var10 = var0.nextF(1.3872175661331396d, 2.636818730233018d);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var0.nextPascal((-121), 1.5707963267948606d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.2124136985472147d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.6838509408735647d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5088599843857857d);
// 
//   }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test75"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(0.06895849133460996d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.95103051506261d);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test76"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc((-101.37764823829899d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0d);

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test77"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var2.setContractionCriteria(50.000008f);
    var2.setExpansionMode(0);
    var2.setContractionCriteria(5.0f);
    double[] var10 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var10);
    var11.setContractionCriteria(50.000008f);
    double[] var14 = var11.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var11);
    boolean var16 = var2.equals((java.lang.Object)var11);
    double[] var17 = var11.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray(var17);
    float var19 = var18.getExpansionFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 2.0f);

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test78"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(2.0f, 50.000004f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0f);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test79"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var2.setContractionCriteria(50.000008f);
    var2.setExpansionMode(0);
    var2.setContractionCriteria(5.0f);
    double[] var10 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var10);
    var11.setContractionCriteria(50.000008f);
    double[] var14 = var11.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var11);
    boolean var16 = var2.equals((java.lang.Object)var11);
    org.apache.commons.math3.util.ResizableDoubleArray var17 = var11.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var18 = var11.copy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test80"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign((-1.0f), 2559.9998f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0f);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test81"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(70, 2432902008176640000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test82() {}
//   public void test82() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test82"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     java.lang.String var4 = var0.nextHexString(110);
//     long var7 = var0.nextSecureLong(0L, 27898L);
//     var0.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.9423186320005968d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "871634a143351baa170f565ef384579fd31a586d1ae4c0385f7aa812f4ea5622f70831b2acb6941a4bb6377d82fef8ce86ea7767b35ad2"+ "'", var4.equals("871634a143351baa170f565ef384579fd31a586d1ae4c0385f7aa812f4ea5622f70831b2acb6941a4bb6377d82fef8ce86ea7767b35ad2"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 14436L);
// 
//   }

  public void test83() {}
//   public void test83() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test83"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     java.lang.String var16 = var0.nextSecureHexString(2);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var18 = var0.nextPoisson((-6.23409514341469E42d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "46af73f31cf871074794d4db54688fc447a1d54afca0fd7a64b2742a54555975f1e825ebf9fbf53007f7c77069b1148677b0"+ "'", var2.equals("46af73f31cf871074794d4db54688fc447a1d54afca0fd7a64b2742a54555975f1e825ebf9fbf53007f7c77069b1148677b0"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-7.087250526561176E43d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + "66"+ "'", var16.equals("66"));
// 
//   }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test84"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(12700);
    var1.setExpansionFactor(2.0000005f);
    float var4 = var1.getExpansionFactor();
    double[] var5 = var1.getInternalValues();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.0000005f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test85"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    java.lang.Number var7 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var8 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var6, var7);
    org.apache.commons.math3.exception.util.ExceptionContext var9 = var8.getContext();
    java.lang.Throwable[] var10 = var8.getSuppressed();
    org.apache.commons.math3.exception.MathInternalError var11 = new org.apache.commons.math3.exception.MathInternalError(var5, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.MathInternalError var12 = new org.apache.commons.math3.exception.MathInternalError(var4, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.MathIllegalArgumentException var13 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.MaxCountExceededException var14 = new org.apache.commons.math3.exception.MaxCountExceededException(var1, (java.lang.Number)3.3170891650425603E43d, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.MathArithmeticException var15 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test86"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(6.0d, 0.11859337015859625d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.04826187808840879d));

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test87"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(1.7802921927502E35d, 0.18911663787600475d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.18911663787600475d);

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test88"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var3 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError(var2, (java.lang.Object[])var3);
    org.apache.commons.math3.exception.MathArithmeticException var5 = new org.apache.commons.math3.exception.MathArithmeticException(var1, (java.lang.Object[])var3);
    org.apache.commons.math3.exception.MathIllegalStateException var6 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test89"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin((-2.1568343228582852E42d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.9995620265286876d));

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test90"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    double var4 = var3.getSupportLowerBound();
    double var6 = var3.probability(6.419286864170918E43d);
    double var7 = var3.getSupportLowerBound();
    double var8 = var3.getMean();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var3.inverseCumulativeProbability(1.7705999455763922E43d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test91"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(88, (-4.9999995f));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test92() {}
//   public void test92() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test92"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh(0.6945971187784026d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test93"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(27900L, 344L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 27556L);

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test94"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var2 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var3.setContractionCriteria(50.000008f);
    double[] var6 = var3.getInternalValues();
    double[] var8 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
    var9.setContractionCriteria(50.000008f);
    double[] var12 = var9.getInternalValues();
    double[] var13 = var9.getElements();
    double var14 = var0.mannWhitneyUTest(var6, var13);
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var13);
    float var16 = var15.getContractionCriteria();
    double[] var18 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray(var18);
    org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray(var18);
    int var21 = var20.getNumElements();
    double var23 = var20.addElementRolling(1.2982587902415216E14d);
    var20.setNumElements(3);
    int var26 = var20.getNumElements();
    var20.contract();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var15, var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 3);

  }

  public void test95() {}
//   public void test95() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test95"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     double var4 = var0.nextExponential(0.056182176564052d);
//     double var7 = var0.nextGamma((-2.0537907646431078E43d), 5.840802579076462E13d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var0.nextInt(1742979373, 88);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "9ab7d8d040193d2801b5b406719578bdefa9262801a1e464b6f7c836a1e8afb8dbe9f19189237ded098d07a0d95e72e9fbcb"+ "'", var2.equals("9ab7d8d040193d2801b5b406719578bdefa9262801a1e464b6f7c836a1e8afb8dbe9f19189237ded098d07a0d95e72e9fbcb"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.10436092655476428d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == Double.NaN);
// 
//   }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test96"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(216770858);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 216770858);

  }

  public void test97() {}
//   public void test97() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test97"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     double var4 = var3.getSupportLowerBound();
//     double var6 = var3.density(1.9222222798755142E-4d);
//     double var7 = var3.sample();
//     var3.reseedRandomGenerator((-27000L));
//     double var10 = var3.getMean();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.4840955931403377E-44d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 4.593837350697045E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.0d);
// 
//   }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test98"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray((-449867819), 102400.01f, 10.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test99"); }


    double var1 = org.apache.commons.math3.special.Gamma.logGamma(6.991412387147916E14d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.3198117277287692E16d);

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test100"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var2.setContractionCriteria(5.0f);
    var2.setElement(110, Double.NaN);
    var2.setElement(100, (-0.6120891811851691d));
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var2);
    double[] var12 = var2.getInternalValues();
    var2.contract();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test101"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    float var3 = var2.getExpansionFactor();
    boolean var5 = var2.equals((java.lang.Object)1612900);
    boolean var7 = var2.equals((java.lang.Object)"430531212cfe726b7eec9179279f714843afdbcd364e446cac51c9a6d69a2b60e4d94e8af86ef67dd6e834c6d57a10ac0b94");
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test102"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    java.lang.String var3 = var2.name();
    java.lang.String var4 = var2.name();
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    int var8 = var7.ordinal();
    java.lang.String var9 = var7.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var12 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "MAXIMAL"+ "'", var3.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "MAXIMAL"+ "'", var4.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "AVERAGE"+ "'", var9.equals("AVERAGE"));

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test103"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var2.setContractionCriteria(50.000008f);
    var2.setExpansionMode(0);
    var2.setContractionCriteria(5.0f);
    double[] var10 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var10);
    var11.setContractionCriteria(50.000008f);
    double[] var14 = var11.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var11);
    boolean var16 = var2.equals((java.lang.Object)var11);
    org.apache.commons.math3.util.ResizableDoubleArray var17 = var11.copy();
    double var19 = var11.addElementRolling(0.5782731623958087d);
    int var20 = var11.getNumElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1);

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test104"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(2560.0f, 102400.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 102400.0f);

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test105"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var2.getNanStrategy();
    java.lang.String var4 = var3.name();
    java.lang.String var5 = var3.name();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    org.apache.commons.math3.stat.ranking.TiesStrategy var8 = var7.getTiesStrategy();
    int var9 = var8.ordinal();
    java.lang.String var10 = var8.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3, var8);
    double[] var13 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var13);
    var14.setContractionCriteria(50.000008f);
    var14.setExpansionMode(0);
    boolean var19 = var8.equals((java.lang.Object)var14);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var20 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var8);
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "MAXIMAL"+ "'", var4.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "MAXIMAL"+ "'", var5.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "AVERAGE"+ "'", var10.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test106"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(1.300371626015253E-10d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.300371626015253E-10d);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test107"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(0.1145357841865244d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test108"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double var4 = var2.substituteMostRecentElement(1.0159453334112069E43d);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var5 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var7 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    var8.setContractionCriteria(50.000008f);
    double[] var11 = var8.getInternalValues();
    double[] var13 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var13);
    var14.setContractionCriteria(50.000008f);
    double[] var17 = var14.getInternalValues();
    double[] var18 = var14.getElements();
    double var19 = var5.mannWhitneyUTest(var11, var18);
    org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray(var18);
    var2.addElements(var18);
    int var22 = var2.getExpansionMode();
    double var24 = var2.substituteMostRecentElement(7.585522823235727E41d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1.0d);

  }

  public void test109() {}
//   public void test109() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test109"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     var0.reSeed();
//     double var18 = var0.nextGamma(2.636818730233018d, 0.5d);
//     var0.reSeedSecure(0L);
//     int var23 = var0.nextZipf(47, 6.770911672198755d);
//     var0.reSeed();
//     java.util.Collection var25 = null;
//     java.lang.Object[] var27 = var0.nextSample(var25, 1221758388);
// 
//   }

  public void test110() {}
//   public void test110() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test110"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     double var5 = var0.nextCauchy(0.0d, 6.770911672198756d);
//     int var9 = var0.nextHypergeometric(10, 0, 3);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var0.nextPascal(47, 3.199763873047224E14d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "39a58e2350ef3ba397823505861d06a2ef08dc01bd3dbd0346bb814c910abc8f3dc4979ff010607bc57444a90705ed229320"+ "'", var2.equals("39a58e2350ef3ba397823505861d06a2ef08dc01bd3dbd0346bb814c910abc8f3dc4979ff010607bc57444a90705ed229320"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 14.182742842777838d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
// 
//   }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test111"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var5 = new double[] { 1.0d, 100.0d};
    var2.addElements(var5);
    double[] var7 = var2.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    float var9 = var8.getExpansionFactor();
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var10.setContractionCriteria(5.0f);
    var10.setElement(110, Double.NaN);
    var10.discardFrontElements(10);
    int var18 = var10.getExpansionMode();
    double[] var20 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var21 = new org.apache.commons.math3.util.ResizableDoubleArray(var20);
    org.apache.commons.math3.util.ResizableDoubleArray var22 = new org.apache.commons.math3.util.ResizableDoubleArray(var20);
    double[] var23 = var22.getElements();
    var10.addElements(var23);
    var8.addElements(var23);
    org.apache.commons.math3.util.ResizableDoubleArray var26 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test112"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog(1612900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.1441165762189273E7d);

  }

  public void test113() {}
//   public void test113() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test113"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(2.0d);
//     org.apache.commons.math3.distribution.IntegerDistribution var3 = null;
//     int var4 = var0.nextInversionDeviate(var3);
// 
//   }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test114"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(48436L, 100L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1210900L);

  }

  public void test115() {}
//   public void test115() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test115"); }
// 
// 
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var1 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     double[] var3 = new double[] { 1.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     var4.setContractionCriteria(50.000008f);
//     double[] var7 = var4.getInternalValues();
//     double[] var9 = new double[] { 1.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(var9);
//     var10.setContractionCriteria(50.000008f);
//     double[] var13 = var10.getInternalValues();
//     double[] var14 = var10.getElements();
//     double var15 = var1.mannWhitneyUTest(var7, var14);
//     org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
//     org.apache.commons.math3.util.ResizableDoubleArray var17 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     var17.addElement(0.02797455810085192d);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var20 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     double[] var22 = new double[] { 1.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var23 = new org.apache.commons.math3.util.ResizableDoubleArray(var22);
//     var23.setContractionCriteria(50.000008f);
//     double[] var26 = var23.getInternalValues();
//     double[] var28 = new double[] { 1.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var29 = new org.apache.commons.math3.util.ResizableDoubleArray(var28);
//     var29.setContractionCriteria(50.000008f);
//     double[] var32 = var29.getInternalValues();
//     double[] var33 = var29.getElements();
//     double var34 = var20.mannWhitneyU(var26, var33);
//     var17.addElements(var26);
//     var16.addElements(var26);
//     double[] var38 = new double[] { 1.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var39 = new org.apache.commons.math3.util.ResizableDoubleArray(var38);
//     org.apache.commons.math3.util.ResizableDoubleArray var40 = var39.copy();
//     var39.addElement(0.0018388436884212223d);
//     double[] var43 = var39.getElements();
//     double var44 = var0.mannWhitneyU(var26, var43);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var45 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var46 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     double[] var48 = new double[] { 1.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var49 = new org.apache.commons.math3.util.ResizableDoubleArray(var48);
//     var49.setContractionCriteria(50.000008f);
//     double[] var52 = var49.getInternalValues();
//     double[] var54 = new double[] { 1.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var55 = new org.apache.commons.math3.util.ResizableDoubleArray(var54);
//     var55.setContractionCriteria(50.000008f);
//     double[] var58 = var55.getInternalValues();
//     double[] var59 = var55.getElements();
//     double var60 = var46.mannWhitneyUTest(var52, var59);
//     org.apache.commons.math3.util.ResizableDoubleArray var61 = new org.apache.commons.math3.util.ResizableDoubleArray(var59);
//     org.apache.commons.math3.util.ResizableDoubleArray var62 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     var62.addElement(0.02797455810085192d);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var65 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     double[] var67 = new double[] { 1.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var68 = new org.apache.commons.math3.util.ResizableDoubleArray(var67);
//     var68.setContractionCriteria(50.000008f);
//     double[] var71 = var68.getInternalValues();
//     double[] var73 = new double[] { 1.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var74 = new org.apache.commons.math3.util.ResizableDoubleArray(var73);
//     var74.setContractionCriteria(50.000008f);
//     double[] var77 = var74.getInternalValues();
//     double[] var78 = var74.getElements();
//     double var79 = var65.mannWhitneyU(var71, var78);
//     var62.addElements(var71);
//     var61.addElements(var71);
//     double[] var83 = new double[] { 1.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var84 = new org.apache.commons.math3.util.ResizableDoubleArray(var83);
//     org.apache.commons.math3.util.ResizableDoubleArray var85 = var84.copy();
//     var84.addElement(0.0018388436884212223d);
//     double[] var88 = var84.getElements();
//     double var89 = var45.mannWhitneyU(var71, var88);
//     org.apache.commons.math3.distribution.NormalDistribution var90 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var91 = var90.getNumericalVariance();
//     double[] var93 = var90.sample(12700);
//     double var94 = var0.mannWhitneyU(var88, var93);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == 1.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var71);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var78);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var79 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var83);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var85);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var88);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var89 == 1.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var91 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var93);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var94 == 16983.0d);
// 
//   }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test116"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(2.690796273272773d, 7.450580596923828E-9d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.690796273272773d);

  }

  public void test117() {}
//   public void test117() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test117"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     double var15 = var6.probability(1.999999995819933d);
//     double var16 = var6.getNumericalVariance();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "8e0ec132d3deb0fe2e5ecad5efde1ebce78c6248900209b887195d79f189420fc49d4b4379d6e780586cdb8a4ec10dd8e16a"+ "'", var2.equals("8e0ec132d3deb0fe2e5ecad5efde1ebce78c6248900209b887195d79f189420fc49d4b4379d6e780586cdb8a4ec10dd8e16a"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-1.534830553654614E43d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 7.22597376812575E86d);
// 
//   }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test118"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm((-937694931342098688L), 34L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test119() {}
//   public void test119() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test119"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     java.lang.String var4 = var0.nextSecureHexString(101);
//     int var7 = var0.nextSecureInt(1612775, 645781745);
//     int var10 = var0.nextBinomial(47, 0.46795008060179255d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var12 = var0.nextPoisson(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "a103d0a88232d45f8d4e05f28226c3975817d3319976c87b4357b51edcb4fd4b75fc9326c6653b82f7f9fa509b9e80fe472b"+ "'", var2.equals("a103d0a88232d45f8d4e05f28226c3975817d3319976c87b4357b51edcb4fd4b75fc9326c6653b82f7f9fa509b9e80fe472b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "7c632feaa1fd6b9f2653478fe5e138d7270bf963ec338bba0f55e494b5444fe4f7c6540f955f2ea21d7cad25ff9b6fb35b571"+ "'", var4.equals("7c632feaa1fd6b9f2653478fe5e138d7270bf963ec338bba0f55e494b5444fe4f7c6540f955f2ea21d7cad25ff9b6fb35b571"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 397392517);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 22);
// 
//   }

  public void test120() {}
//   public void test120() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test120"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     double var16 = var0.nextWeibull(1.0d, 1.6298598478788293d);
//     double var19 = var0.nextCauchy((-1.1440883267692863E33d), 3.3030345912774096E43d);
//     var0.reSeedSecure();
//     double var24 = var0.nextUniform(0.0d, 2.4188678176733584E-44d, true);
//     double var26 = var0.nextT(1.218084974098134d);
//     org.apache.commons.math3.distribution.IntegerDistribution var27 = null;
//     int var28 = var0.nextInversionDeviate(var27);
// 
//   }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test121"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(20500L, 28798L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2L);

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test122"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(-5.329951075180856E43d));
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var1.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test123() {}
//   public void test123() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test123"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     var0.reSeed(1L);
//     var0.reSeedSecure(2700L);
//     int var9 = var0.nextBinomial(2, 0.9898371621797909d);
//     double var11 = var0.nextT(2.2161543004921728E14d);
//     double var14 = var0.nextGamma((-0.5717072278537213d), 7.312818360484666E-46d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var17 = var0.nextLong(0L, (-8615948696432275456L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "f20bb5bd859e8e4565c3f2de373f99e227380c75192cee70c3309ab751e817ffc950586ac8cd4f03f0a6dc866eeb3b61ebb0"+ "'", var2.equals("f20bb5bd859e8e4565c3f2de373f99e227380c75192cee70c3309ab751e817ffc950586ac8cd4f03f0a6dc866eeb3b61ebb0"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.4841229172256723d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.3734278558491942E-45d);
// 
//   }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test124"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(1.3662466260540767E86d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.319322741078956E-87d);

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test125"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.addElement(0.02797455810085192d);
    var0.discardFrontElements(1);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var6 = var5.getInternalValues();
    var0.addElements(var6);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.discardMostRecentElements(83);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test126"); }


    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(2, 10.0f, 10.0f, 1);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var4.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = var4.copy();
    double[] var9 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(var9);
    double[] var13 = new double[] { 1.0d, 100.0d};
    var10.addElements(var13);
    var7.addElements(var13);
    double[] var17 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray(var17);
    var18.setContractionCriteria(50.000008f);
    var18.setExpansionMode(0);
    var18.setContractionCriteria(5.0f);
    double[] var26 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var27 = new org.apache.commons.math3.util.ResizableDoubleArray(var26);
    var27.setContractionCriteria(50.000008f);
    double[] var30 = var27.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var31 = new org.apache.commons.math3.util.ResizableDoubleArray(var27);
    boolean var32 = var18.equals((java.lang.Object)var27);
    double[] var33 = var27.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var34 = new org.apache.commons.math3.util.ResizableDoubleArray(var33);
    var7.addElements(var33);
    double[] var36 = var7.getElements();
    var7.contract();
    var7.setNumElements(2068);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test127() {}
//   public void test127() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test127"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.5650934208572123d, 4.752533803998109E42d);
//     double var3 = var2.sample();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 4.517577986055557E42d);
// 
//   }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test128"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.math.BigInteger var3 = null;
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var7 = new org.apache.commons.math3.exception.OutOfRangeException(var1, (java.lang.Number)100.0f, (java.lang.Number)var5, (java.lang.Number)0.5000672346092545d);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    java.math.BigInteger var10 = null;
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var10, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var14 = new org.apache.commons.math3.exception.OutOfRangeException(var8, (java.lang.Number)100.0f, (java.lang.Number)var12, (java.lang.Number)0.5000672346092545d);
    java.math.BigInteger var15 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, var12);
    java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 12700);
    java.math.BigInteger var19 = org.apache.commons.math3.util.ArithmeticUtils.pow(var17, 768793337);
    org.apache.commons.math3.exception.util.Localizable var20 = null;
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.math.BigInteger var23 = null;
    java.math.BigInteger var25 = org.apache.commons.math3.util.ArithmeticUtils.pow(var23, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var27 = new org.apache.commons.math3.exception.OutOfRangeException(var21, (java.lang.Number)100.0f, (java.lang.Number)var25, (java.lang.Number)0.5000672346092545d);
    org.apache.commons.math3.exception.util.Localizable var28 = null;
    java.math.BigInteger var30 = null;
    java.math.BigInteger var32 = org.apache.commons.math3.util.ArithmeticUtils.pow(var30, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var34 = new org.apache.commons.math3.exception.OutOfRangeException(var28, (java.lang.Number)100.0f, (java.lang.Number)var32, (java.lang.Number)0.5000672346092545d);
    java.math.BigInteger var35 = org.apache.commons.math3.util.ArithmeticUtils.pow(var25, var32);
    java.math.BigInteger var37 = org.apache.commons.math3.util.ArithmeticUtils.pow(var25, 10L);
    org.apache.commons.math3.exception.NotStrictlyPositiveException var38 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var20, (java.lang.Number)var37);
    org.apache.commons.math3.exception.util.Localizable var41 = null;
    java.math.BigInteger var43 = null;
    java.math.BigInteger var45 = org.apache.commons.math3.util.ArithmeticUtils.pow(var43, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var47 = new org.apache.commons.math3.exception.OutOfRangeException(var41, (java.lang.Number)100.0f, (java.lang.Number)var45, (java.lang.Number)0.5000672346092545d);
    org.apache.commons.math3.exception.util.Localizable var48 = null;
    java.math.BigInteger var50 = null;
    java.math.BigInteger var52 = org.apache.commons.math3.util.ArithmeticUtils.pow(var50, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var54 = new org.apache.commons.math3.exception.OutOfRangeException(var48, (java.lang.Number)100.0f, (java.lang.Number)var52, (java.lang.Number)0.5000672346092545d);
    java.math.BigInteger var55 = org.apache.commons.math3.util.ArithmeticUtils.pow(var45, var52);
    java.math.BigInteger var57 = org.apache.commons.math3.util.ArithmeticUtils.pow(var45, 31L);
    org.apache.commons.math3.exception.OutOfRangeException var58 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)8.799063409660144E86d, (java.lang.Number)0.99999994f, (java.lang.Number)var45);
    java.math.BigInteger var59 = org.apache.commons.math3.util.ArithmeticUtils.pow(var37, var45);
    java.math.BigInteger var61 = org.apache.commons.math3.util.ArithmeticUtils.pow(var37, 988L);
    java.math.BigInteger var63 = org.apache.commons.math3.util.ArithmeticUtils.pow(var61, 10);
    java.math.BigInteger var65 = org.apache.commons.math3.util.ArithmeticUtils.pow(var63, 27898L);
    org.apache.commons.math3.exception.OutOfRangeException var67 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)768793337, (java.lang.Number)var65, (java.lang.Number)102400.016f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test129"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog((-22));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test130() {}
//   public void test130() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test130"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     double var16 = var0.nextWeibull(1.0d, 1.6298598478788293d);
//     double var19 = var0.nextWeibull(1.151569395337692d, 7.22597376812575E86d);
//     double var22 = var0.nextGaussian(2.4188678176733584E-44d, 0.9732473842406115d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var25 = var0.nextBeta(1.2048783586126193d, (-3.2812801842882495E42d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "a63288dc9387531d44db4a30f735c6b32ef1c8555482e31d9eb0f964e9976a64f4765962ed3dbd05a34ede07d34337d7a231"+ "'", var2.equals("a63288dc9387531d44db4a30f735c6b32ef1c8555482e31d9eb0f964e9976a64f4765962ed3dbd05a34ede07d34337d7a231"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-1.2860454852158744E43d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.24323159463281846d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 7.529697347322445E86d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == (-0.820485484004035d));
// 
//   }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test131"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    boolean var1 = var0.isSupportUpperBoundInclusive();
    boolean var2 = var0.isSupportLowerBoundInclusive();
    double var3 = var0.getMean();
    double var4 = var0.getSupportUpperBound();
    double var6 = var0.cumulativeProbability(0.8341186568683249d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.797892938616477d);

  }

  public void test132() {}
//   public void test132() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test132"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     double var17 = var0.nextGamma(0.9775852669347048d, 3.199763873047224E14d);
//     var0.reSeed(27900L);
//     double var23 = var0.nextUniform(0.18029079387572064d, 1.70638274610834d, false);
//     double var26 = var0.nextGamma(0.0018388436884212223d, 4.951760157141521E27d);
//     double var30 = var0.nextUniform(5.840802579076462E13d, 5.106597054040568E86d, false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "ae46207b4a8ecd4dc2e0d3e66c0d2e3bed577483ddd09f4595fa6bf37ad8d2fac7af2de280b18a53c72fc170ea3671cd23a3"+ "'", var2.equals("ae46207b4a8ecd4dc2e0d3e66c0d2e3bed577483ddd09f4595fa6bf37ad8d2fac7af2de280b18a53c72fc170ea3671cd23a3"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-3.9057880693172975E42d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 5.446553841882361E14d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.8399341499662786d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 8.482444959569576E-82d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1.9461608214586842E86d);
// 
//   }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test133"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(0.4471007338497455d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test134"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(3.199763873047224E14d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.19976387304722E14d);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test135"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(1.1669284392340007d, 6.743438587337678E86d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.166928439234001d);

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test136"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(11.712762449867773d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 61060.183360518626d);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test137"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)2.0d, (java.lang.Number)50.0f, (java.lang.Number)436.05387683681073d);
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var3.getContext();
    java.lang.Number var5 = var3.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 436.05387683681073d+ "'", var5.equals(436.05387683681073d));

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test138"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    var3.reseedRandomGenerator(1L);
    boolean var6 = var3.isSupportConnected();
    double var7 = var3.getMean();
    double var8 = var3.sample();
    double[] var10 = var3.sample(8100);
    double var11 = var3.getStandardDeviation();
    boolean var12 = var3.isSupportUpperBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 3.5671315446818194E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2.6881171418161356E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test139() {}
//   public void test139() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test139"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 1496370343);
// 
//   }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test140"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(1.293606294858882E100d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 231.20909037538902d);

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test141"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.lang.Object[] var3 = null;
    org.apache.commons.math3.exception.NullArgumentException var4 = new org.apache.commons.math3.exception.NullArgumentException(var2, var3);
    java.lang.Throwable[] var5 = var4.getSuppressed();
    org.apache.commons.math3.exception.NullArgumentException var6 = new org.apache.commons.math3.exception.NullArgumentException(var1, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.NullArgumentException var7 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test142"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(6.991412387147916E14d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6.991412387147916E14d);

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test143"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    java.lang.String var2 = var1.name();
    java.lang.String var3 = var1.name();
    boolean var5 = var1.equals((java.lang.Object)"bbc76c98706e096cbdb48c11be18b37feafe094ae0e5291b81fe65cbd0c42cc6f465c322de0f5afaf8fdd0237c92d0d9c2d6");
    int var6 = var1.ordinal();
    org.apache.commons.math3.random.RandomGenerator var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var7);
    java.lang.String var9 = var1.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var11 = var10.getNanStrategy();
    java.lang.String var12 = var11.name();
    java.lang.String var13 = var11.name();
    org.apache.commons.math3.stat.ranking.NaNStrategy var14 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var14);
    org.apache.commons.math3.stat.ranking.TiesStrategy var16 = var15.getTiesStrategy();
    int var17 = var16.ordinal();
    java.lang.String var18 = var16.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11, var16);
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var16);
    org.apache.commons.math3.random.RandomGenerator var21 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "MAXIMAL"+ "'", var2.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "MAXIMAL"+ "'", var3.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "MAXIMAL"+ "'", var9.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "MAXIMAL"+ "'", var12.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "MAXIMAL"+ "'", var13.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + "AVERAGE"+ "'", var18.equals("AVERAGE"));

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test144"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var5.getTiesStrategy();
    int var7 = var6.ordinal();
    java.lang.String var8 = var6.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var6);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var11 = var10.getNanStrategy();
    java.lang.String var12 = var11.name();
    java.lang.String var13 = var11.name();
    boolean var15 = var11.equals((java.lang.Object)"bbc76c98706e096cbdb48c11be18b37feafe094ae0e5291b81fe65cbd0c42cc6f465c322de0f5afaf8fdd0237c92d0d9c2d6");
    boolean var16 = var1.equals((java.lang.Object)var11);
    org.apache.commons.math3.random.RandomGenerator var17 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var17);
    java.lang.Class var19 = var1.getDeclaringClass();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "MAXIMAL"+ "'", var12.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "MAXIMAL"+ "'", var13.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test145"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp((-7.770157123792972E-15d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-7.77015712379297E-15d));

  }

  public void test146() {}
//   public void test146() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test146"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var2 = null;
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var3 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var2);
//     double[] var5 = new double[] { 1.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray(var5);
//     double[] var9 = new double[] { 1.0d, 100.0d};
//     var6.addElements(var9);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var11 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     double[] var13 = new double[] { 1.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var13);
//     var14.setContractionCriteria(50.000008f);
//     double[] var17 = var14.getInternalValues();
//     double[] var19 = new double[] { 1.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray(var19);
//     var20.setContractionCriteria(50.000008f);
//     double[] var23 = var20.getInternalValues();
//     double[] var24 = var20.getElements();
//     double var25 = var11.mannWhitneyU(var17, var24);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var26 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     double[] var28 = new double[] { 1.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var29 = new org.apache.commons.math3.util.ResizableDoubleArray(var28);
//     var29.setContractionCriteria(50.000008f);
//     double[] var32 = var29.getInternalValues();
//     double[] var34 = new double[] { 1.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var35 = new org.apache.commons.math3.util.ResizableDoubleArray(var34);
//     var35.setContractionCriteria(50.000008f);
//     double[] var38 = var35.getInternalValues();
//     double[] var39 = var35.getElements();
//     double var40 = var26.mannWhitneyU(var32, var39);
//     org.apache.commons.math3.util.ResizableDoubleArray var41 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     var41.addElement(0.02797455810085192d);
//     var41.discardFrontElements(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var46 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     double[] var47 = var46.getInternalValues();
//     var41.addElements(var47);
//     double var49 = var11.mannWhitneyUTest(var32, var47);
//     org.apache.commons.math3.util.ResizableDoubleArray var50 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     var50.addElement(0.02797455810085192d);
//     var50.discardFrontElements(1);
//     org.apache.commons.math3.util.ResizableDoubleArray var55 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     double[] var56 = var55.getInternalValues();
//     var50.addElements(var56);
//     double[] var59 = new double[] { 1.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var60 = new org.apache.commons.math3.util.ResizableDoubleArray(var59);
//     var60.setContractionCriteria(50.000008f);
//     var60.clear();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var64 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     double[] var66 = new double[] { 1.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var67 = new org.apache.commons.math3.util.ResizableDoubleArray(var66);
//     var67.setContractionCriteria(50.000008f);
//     double[] var70 = var67.getInternalValues();
//     double[] var72 = new double[] { 1.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var73 = new org.apache.commons.math3.util.ResizableDoubleArray(var72);
//     var73.setContractionCriteria(50.000008f);
//     double[] var76 = var73.getInternalValues();
//     double[] var77 = var73.getElements();
//     double var78 = var64.mannWhitneyUTest(var70, var77);
//     var60.addElements(var77);
//     double var80 = var11.mannWhitneyU(var56, var77);
//     double var81 = var3.mannWhitneyU(var9, var56);
// 
//   }

  public void test147() {}
//   public void test147() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test147"); }
// 
// 
//     org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     var0.setContractionCriteria(5.0f);
//     org.apache.commons.math3.random.RandomDataImpl var3 = new org.apache.commons.math3.random.RandomDataImpl();
//     boolean var4 = var0.equals((java.lang.Object)var3);
//     var3.reSeedSecure(27900L);
//     double var8 = var3.nextExponential(6.770911672198755d);
//     org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var12.reseedRandomGenerator(1L);
//     boolean var15 = var12.isSupportConnected();
//     double var16 = var12.getNumericalMean();
//     double var18 = var12.cumulativeProbability(1.107148716958077d);
//     boolean var19 = var12.isSupportConnected();
//     double var20 = var12.getStandardDeviation();
//     double var21 = var3.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 12.365641555008496d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 2.6881171418161356E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == (-2.155052297494426E43d));
// 
//   }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test148"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(1.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test149"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.0376197072270027d);
    java.lang.String var2 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "org.apache.commons.math3.exception.NotPositiveException: 0.038 is smaller than the minimum (0)"+ "'", var2.equals("org.apache.commons.math3.exception.NotPositiveException: 0.038 is smaller than the minimum (0)"));

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test150"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(2432902008176640001L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2432902008176640001L);

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test151"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(5.0f);
    org.apache.commons.math3.random.RandomDataImpl var3 = new org.apache.commons.math3.random.RandomDataImpl();
    boolean var4 = var0.equals((java.lang.Object)var3);
    var0.addElement(Double.NaN);
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var8 = var7.getNanStrategy();
    java.lang.String var9 = var8.name();
    java.lang.String var10 = var8.name();
    org.apache.commons.math3.stat.ranking.NaNStrategy var11 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11);
    org.apache.commons.math3.stat.ranking.TiesStrategy var13 = var12.getTiesStrategy();
    int var14 = var13.ordinal();
    java.lang.String var15 = var13.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8, var13);
    double[] var18 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray(var18);
    var19.setContractionCriteria(50.000008f);
    var19.setExpansionMode(0);
    boolean var24 = var13.equals((java.lang.Object)var19);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var19);
    int var26 = var0.start();
    int var27 = var0.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "MAXIMAL"+ "'", var9.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "MAXIMAL"+ "'", var10.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "AVERAGE"+ "'", var15.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test152"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(2.185089419781954E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test153"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.math.BigInteger var2 = null;
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var6 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)100.0f, (java.lang.Number)var4, (java.lang.Number)0.5000672346092545d);
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    java.math.BigInteger var9 = null;
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var13 = new org.apache.commons.math3.exception.OutOfRangeException(var7, (java.lang.Number)100.0f, (java.lang.Number)var11, (java.lang.Number)0.5000672346092545d);
    java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, var11);
    java.math.BigInteger var16 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 31L);
    java.math.BigInteger var18 = org.apache.commons.math3.util.ArithmeticUtils.pow(var16, 127);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test154"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    double var4 = var3.getSupportLowerBound();
    double var6 = var3.probability(6.419286864170918E43d);
    double var7 = var3.getSupportLowerBound();
    double var10 = var3.cumulativeProbability(0.0d, 0.2309697915176785d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 3.4278124973993203E-45d);

  }

  public void test155() {}
//   public void test155() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test155"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.0d, 0.03938626831925404d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test156"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)1.4472475295846865E43d);

  }

  public void test157() {}
//   public void test157() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test157"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     double var16 = var0.nextWeibull(1.0d, 1.6298598478788293d);
//     double var19 = var0.nextWeibull(1.151569395337692d, 7.22597376812575E86d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var21 = var0.nextChiSquare((-5.327343066096964E43d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "3150494b516fd9ea0d7512b2c957106a8d8a22be8010ec4f964ac79263e901e03835e4b7ebecc2afe6db453d8d593bf00203"+ "'", var2.equals("3150494b516fd9ea0d7512b2c957106a8d8a22be8010ec4f964ac79263e901e03835e4b7ebecc2afe6db453d8d593bf00203"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.876180711567576E41d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.6652340601783515d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 3.2847901383680696E86d);
// 
//   }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test158"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(1.0499768188068717d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test159"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    var3.reseedRandomGenerator(1L);
    double var7 = var3.probability(0.0d);
    double var8 = var3.getMean();
    double var10 = var3.density(1.8622531212727638d);
    double[] var12 = var3.sample(4233);
    boolean var13 = var3.isSupportConnected();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1.4840955931403377E-44d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test160"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    boolean var1 = var0.isSupportLowerBoundInclusive();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = var0.cumulativeProbability(1.2597093544151592d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test161"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(200.0d, (-5.582997880991177E43d), 4.791816278040792E86d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test162"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo((-3941415383162945436L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test163"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(40L, (-48436L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-48396L));

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test164"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent((-1.8639351044049079E43d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 143);

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test165"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(102400);
    int var2 = var1.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test166"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.math.BigInteger var3 = null;
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var7 = new org.apache.commons.math3.exception.OutOfRangeException(var1, (java.lang.Number)100.0f, (java.lang.Number)var5, (java.lang.Number)0.5000672346092545d);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    java.math.BigInteger var10 = null;
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var10, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var14 = new org.apache.commons.math3.exception.OutOfRangeException(var8, (java.lang.Number)100.0f, (java.lang.Number)var12, (java.lang.Number)0.5000672346092545d);
    java.math.BigInteger var15 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, var12);
    java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 10L);
    org.apache.commons.math3.exception.NotStrictlyPositiveException var18 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)var17);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.math.BigInteger var23 = null;
    java.math.BigInteger var25 = org.apache.commons.math3.util.ArithmeticUtils.pow(var23, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var27 = new org.apache.commons.math3.exception.OutOfRangeException(var21, (java.lang.Number)100.0f, (java.lang.Number)var25, (java.lang.Number)0.5000672346092545d);
    org.apache.commons.math3.exception.util.Localizable var28 = null;
    java.math.BigInteger var30 = null;
    java.math.BigInteger var32 = org.apache.commons.math3.util.ArithmeticUtils.pow(var30, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var34 = new org.apache.commons.math3.exception.OutOfRangeException(var28, (java.lang.Number)100.0f, (java.lang.Number)var32, (java.lang.Number)0.5000672346092545d);
    java.math.BigInteger var35 = org.apache.commons.math3.util.ArithmeticUtils.pow(var25, var32);
    java.math.BigInteger var37 = org.apache.commons.math3.util.ArithmeticUtils.pow(var25, 31L);
    org.apache.commons.math3.exception.OutOfRangeException var38 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)8.799063409660144E86d, (java.lang.Number)0.99999994f, (java.lang.Number)var25);
    java.math.BigInteger var39 = org.apache.commons.math3.util.ArithmeticUtils.pow(var17, var25);
    java.math.BigInteger var41 = org.apache.commons.math3.util.ArithmeticUtils.pow(var39, 145);
    org.apache.commons.math3.exception.util.Localizable var42 = null;
    java.math.BigInteger var44 = null;
    java.math.BigInteger var46 = org.apache.commons.math3.util.ArithmeticUtils.pow(var44, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var48 = new org.apache.commons.math3.exception.OutOfRangeException(var42, (java.lang.Number)100.0f, (java.lang.Number)var46, (java.lang.Number)0.5000672346092545d);
    org.apache.commons.math3.exception.util.Localizable var49 = null;
    java.math.BigInteger var51 = null;
    java.math.BigInteger var53 = org.apache.commons.math3.util.ArithmeticUtils.pow(var51, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var55 = new org.apache.commons.math3.exception.OutOfRangeException(var49, (java.lang.Number)100.0f, (java.lang.Number)var53, (java.lang.Number)0.5000672346092545d);
    java.math.BigInteger var56 = org.apache.commons.math3.util.ArithmeticUtils.pow(var46, var53);
    java.math.BigInteger var58 = org.apache.commons.math3.util.ArithmeticUtils.pow(var46, 31L);
    java.math.BigInteger var59 = org.apache.commons.math3.util.ArithmeticUtils.pow(var39, var58);
    java.math.BigInteger var61 = org.apache.commons.math3.util.ArithmeticUtils.pow(var39, 5281956653691830372L);
    org.apache.commons.math3.exception.util.Localizable var62 = null;
    org.apache.commons.math3.exception.util.Localizable var63 = null;
    java.math.BigInteger var65 = null;
    java.math.BigInteger var67 = org.apache.commons.math3.util.ArithmeticUtils.pow(var65, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var69 = new org.apache.commons.math3.exception.OutOfRangeException(var63, (java.lang.Number)100.0f, (java.lang.Number)var67, (java.lang.Number)0.5000672346092545d);
    org.apache.commons.math3.exception.util.Localizable var70 = null;
    java.math.BigInteger var72 = null;
    java.math.BigInteger var74 = org.apache.commons.math3.util.ArithmeticUtils.pow(var72, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var76 = new org.apache.commons.math3.exception.OutOfRangeException(var70, (java.lang.Number)100.0f, (java.lang.Number)var74, (java.lang.Number)0.5000672346092545d);
    java.math.BigInteger var77 = org.apache.commons.math3.util.ArithmeticUtils.pow(var67, var74);
    org.apache.commons.math3.exception.util.Localizable var78 = null;
    java.lang.Object[] var81 = new java.lang.Object[] { '4'};
    org.apache.commons.math3.exception.MaxCountExceededException var82 = new org.apache.commons.math3.exception.MaxCountExceededException(var78, (java.lang.Number)Double.NaN, var81);
    java.lang.Throwable[] var83 = var82.getSuppressed();
    org.apache.commons.math3.exception.MaxCountExceededException var84 = new org.apache.commons.math3.exception.MaxCountExceededException(var62, (java.lang.Number)var67, (java.lang.Object[])var83);
    org.apache.commons.math3.exception.MaxCountExceededException var85 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)var67);
    java.math.BigInteger var86 = org.apache.commons.math3.util.ArithmeticUtils.pow(var61, var67);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.math.BigInteger var88 = org.apache.commons.math3.util.ArithmeticUtils.pow(var67, (-2153345741252449825L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test167"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.6647615947356664d);
    java.lang.Number var2 = var1.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0.6647615947356664d+ "'", var2.equals(0.6647615947356664d));

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test168"); }


    int var2 = org.apache.commons.math3.util.FastMath.min((-1023), (-254));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1023));

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test169"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    var3.reseedRandomGenerator(1L);
    boolean var6 = var3.isSupportConnected();
    double var7 = var3.getMean();
    double var9 = var3.inverseCumulativeProbability(0.5474978282396834d);
    double var11 = var3.probability(1.8851541128986008E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 3.208055017124592E42d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);

  }

  public void test170() {}
//   public void test170() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test170"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     double var5 = var0.nextCauchy(0.0d, 6.770911672198756d);
//     double var8 = var0.nextCauchy(0.0d, 4.93982304811884d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "fd9041df2443f93c2863efbab27a17a46166a15545b2168e07f64d27e84883a642255386adc72e975faefe7041cb46a37a55"+ "'", var2.equals("fd9041df2443f93c2863efbab27a17a46166a15545b2168e07f64d27e84883a642255386adc72e975faefe7041cb46a37a55"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2.9234169031912605d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 42.00897176826769d);
// 
//   }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test171"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(2.0000008411562833d, 4.594468614421035E-44d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test172"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.4566344307670791d, 0.5845547826755761d, 1.0949470272168769d, 17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.4925054253167135d);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test173"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(97.34317384029565d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.600113006680233d);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test174"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(32.04097850604347d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 32.04097850604348d);

  }

  public void test175() {}
//   public void test175() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test175"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     var0.reSeed(1L);
//     double var7 = var0.nextWeibull(6.389056068043896d, 6.770911672198755d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var0.nextF(1.293606294858882E100d, 1.0949470272168769d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "32f604b5f6fe75c7651b99a3b810981c6b77e3b4c35b9d3a4355746268eee1ee67a40208ca69540533c315fba4332c114aae"+ "'", var2.equals("32f604b5f6fe75c7651b99a3b810981c6b77e3b4c35b9d3a4355746268eee1ee67a40208ca69540533c315fba4332c114aae"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 4.5194037630894135d);
// 
//   }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test176"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)1.4640953062334716d, (java.lang.Number)Double.NEGATIVE_INFINITY, (java.lang.Number)1.0d);
    java.lang.Number var5 = var4.getLo();
    java.lang.Number var6 = var4.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + Double.NEGATIVE_INFINITY+ "'", var5.equals(Double.NEGATIVE_INFINITY));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + Double.NEGATIVE_INFINITY+ "'", var6.equals(Double.NEGATIVE_INFINITY));

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test177"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)1.4210854715202004E-14d);
    java.lang.Number var2 = var1.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 1.4210854715202004E-14d+ "'", var2.equals(1.4210854715202004E-14d));

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test178"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var2.setContractionCriteria(50.000008f);
    var2.setExpansionMode(0);
    var2.setNumElements(1612900);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test179"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(1.8677580919141257d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0792304205399221d);

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test180"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(5.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.0000005f);

  }

  public void test181() {}
//   public void test181() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test181"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     java.lang.String var4 = var0.nextHexString(110);
//     int var7 = var0.nextPascal(3, 0.0d);
//     int var10 = var0.nextSecureInt(47, 110);
//     var0.reSeedSecure(300L);
//     long var15 = var0.nextSecureLong(0L, 28798L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var18 = var0.nextPascal(20, 1.151569395337692d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.25133777896122816d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "b7e5ecb51a71bf330afb00b13161011e798480809ba39dbb7a4f1f4fbe2616896900039839b618fe2423c4be95a3570785485c46d54988"+ "'", var4.equals("b7e5ecb51a71bf330afb00b13161011e798480809ba39dbb7a4f1f4fbe2616896900039839b618fe2423c4be95a3570785485c46d54988"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 101);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 5429L);
// 
//   }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test182"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(10.0f, 0.011377964632520712d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.999999f);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test183"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(1.2660196586805188d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1L);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test184"); }


    long var2 = org.apache.commons.math3.util.FastMath.min((-28788L), 49298L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-28788L));

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test185"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.lang.Object[] var3 = null;
    org.apache.commons.math3.exception.NullArgumentException var4 = new org.apache.commons.math3.exception.NullArgumentException(var2, var3);
    java.lang.Throwable[] var5 = var4.getSuppressed();
    org.apache.commons.math3.exception.NullArgumentException var6 = new org.apache.commons.math3.exception.NullArgumentException(var1, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MathIllegalArgumentException var7 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test186() {}
//   public void test186() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test186"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     double var4 = var0.nextExponential(0.056182176564052d);
//     var0.reSeedSecure();
//     var0.reSeed(90000L);
//     double var9 = var0.nextChiSquare(1.9801183504468223d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var0.nextBinomial((-11480), (-4.152257768472053E8d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "0c1c032212655cf49fc2d544226f8e1fb36cfd905d11f5d4bd2a9120a68f6965303d312d82eec4352400222e934a59463bbb"+ "'", var2.equals("0c1c032212655cf49fc2d544226f8e1fb36cfd905d11f5d4bd2a9120a68f6965303d312d82eec4352400222e934a59463bbb"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.03109311928320668d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.331630772785881d);
// 
//   }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test187"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(2951, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test188"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(7.353300445964136E86d, 7.759158747274979E42d, 6.239608407802531E-31d);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test189"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.5606386275277436d), 3.5671315446818194E43d);
    double var4 = var2.probability(1.0713813143399866d);
    double var5 = var2.getNumericalVariance();
    double var8 = var2.cumulativeProbability(2.690796273272773d, 1.2696572718964828E42d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.2724427457064103E87d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.014196646003407731d);

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test190"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(short)0, (java.lang.Number)10, false);
    java.lang.Number var4 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 10+ "'", var4.equals(10));

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test191"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(49298L, 27000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test192"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(1.3239760502464962E43d, (-3.4536536242642804E43d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test193"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.8370349259249118d, (java.lang.Number)1.2724427457064103E87d, false);

  }

  public void test194() {}
//   public void test194() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test194"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     java.lang.String var4 = var0.nextHexString(110);
//     var0.reSeed();
//     java.util.Collection var6 = null;
//     java.lang.Object[] var8 = var0.nextSample(var6, 1612775);
// 
//   }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test195"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)1.3418720970618036E43d, (java.lang.Number)5.0f, true);
    java.lang.Number var4 = var3.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 1.3418720970618036E43d+ "'", var4.equals(1.3418720970618036E43d));

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test196"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(2.7177862822969723E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.213239187201152E21d);

  }

  public void test197() {}
//   public void test197() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test197"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     double var17 = var0.nextBeta(1.1265425086815434E43d, 1.1282937610745374d);
//     long var19 = var0.nextPoisson(31.402066659134473d);
//     long var22 = var0.nextLong((-9223372036854775808L), 2L);
//     int var25 = var0.nextZipf(127000, 0.4349627593755754d);
//     java.lang.String var27 = var0.nextHexString(79973711);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "8dd960ecc50bdded21cb25f5c2876098a68bfb72f558b4d5997775d9f7c6f1dbe3e77b4c02b5beb8a89b55772e2f2c670081"+ "'", var2.equals("8dd960ecc50bdded21cb25f5c2876098a68bfb72f558b4d5997775d9f7c6f1dbe3e77b4c02b5beb8a89b55772e2f2c670081"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 2.5944989054673044E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 23L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == (-9083256709592569856L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 695);
// 
//   }

}
