
import junit.framework.*;

public class RandoopTest1 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test1"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(0.99999994f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test2"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(0.1672559658154289d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.1672559658154289d);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test3"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(0L, 100L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100L);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test4"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(50.000008f);
    double[] var3 = var0.getElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test5"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var2 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var3.setContractionCriteria(50.000008f);
    double[] var6 = var3.getInternalValues();
    double[] var8 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
    var9.setContractionCriteria(50.000008f);
    double[] var12 = var9.getInternalValues();
    double[] var13 = var9.getElements();
    double var14 = var0.mannWhitneyUTest(var6, var13);
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var13);
    float var16 = var15.getContractionCriteria();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var15.discardFrontElements((-127));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 2.5f);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test6"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    double var4 = var3.getSupportLowerBound();
    double var6 = var3.probability(4.605170185988092d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var9 = var3.cumulativeProbability(9.332621544395286E157d, 1.2038021664515672d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);

  }

  public void test7() {}
//   public void test7() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test7"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log1p(Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test8() {}
//   public void test8() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test8"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
//     double[] var4 = new double[] { 1.0d};
//     org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
//     double[] var8 = new double[] { 1.0d, 100.0d};
//     var5.addElements(var8);
//     double[] var10 = var5.getInternalValues();
//     org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var10);
//     double[] var12 = var1.rank(var10);
// 
//   }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test9"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(7.353300445964135E86d, 44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.293606294858882E100d);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test10"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(2.5f, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2560.0f);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test11"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.9898371621797909d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test12"); }


    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.math.BigInteger var4 = null;
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var8 = new org.apache.commons.math3.exception.OutOfRangeException(var2, (java.lang.Number)100.0f, (java.lang.Number)var6, (java.lang.Number)0.5000672346092545d);
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    java.math.BigInteger var11 = null;
    java.math.BigInteger var13 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var15 = new org.apache.commons.math3.exception.OutOfRangeException(var9, (java.lang.Number)100.0f, (java.lang.Number)var13, (java.lang.Number)0.5000672346092545d);
    java.math.BigInteger var16 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, var13);
    java.math.BigInteger var18 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, 31L);
    org.apache.commons.math3.exception.OutOfRangeException var19 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)8.799063409660144E86d, (java.lang.Number)0.99999994f, (java.lang.Number)var6);
    org.apache.commons.math3.exception.NumberIsTooSmallException var22 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)8.799063409660144E86d, (java.lang.Number)0.9915520923431179d, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test13"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.math.BigInteger var2 = null;
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var6 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)100.0f, (java.lang.Number)var4, (java.lang.Number)0.5000672346092545d);
    java.lang.Number var7 = var6.getArgument();
    org.apache.commons.math3.exception.util.ExceptionContext var8 = var6.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 100.0f+ "'", var7.equals(100.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test14() {}
//   public void test14() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test14"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     var0.reSeed();
//     double var18 = var0.nextGamma(2.636818730233018d, 0.5d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("21774d4d38a1b53818e994c30aec74ebe3d60902b843f3254b8614b9291d1b057058ed903266e384a3895df0b2e013cc0994", "a18a6960667ebe830870bef0dd47c8668e7a7b64af443e11aff71cf15c6f5f62a57ec39698a54a0583a9a53b49df838fad26");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "4ba6801018e2f5f9888fefcf2aea7b3c0d1d080fa58163f8a86e9a7e12815a75e7ea3ecdc246e722026ebd7d06079c9932b2"+ "'", var2.equals("4ba6801018e2f5f9888fefcf2aea7b3c0d1d080fa58163f8a86e9a7e12815a75e7ea3ecdc246e722026ebd7d06079c9932b2"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.1621687872450653E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.7495719988108077d);
// 
//   }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test15"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(3.846438844184768d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.440892098500626E-16d);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test16"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(90L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test17"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(31L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 31L);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test18"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var2.setContractionCriteria(50.000008f);
    var2.setExpansionMode(0);
    var2.setContractionCriteria(5.0f);
    float var9 = var2.getContractionCriteria();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 5.0f);

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test19"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(2, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test20"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(5.0f);
    org.apache.commons.math3.random.RandomDataImpl var3 = new org.apache.commons.math3.random.RandomDataImpl();
    boolean var4 = var0.equals((java.lang.Object)var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var3.nextUniform(1.177802006337712d, 7.73868401503849E-14d, true);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test21"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(0.0f, 101);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test22"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos((-0.7997115369080445d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6969136111134943d);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test23"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.42044027995299915d, (java.lang.Number)20500L, true);

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test24"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(0.08949018759546412d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 126.32054207990153d);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test25"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test26"); }


    long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6L);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test27"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(100, (-127));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test28"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(1.3418720970618036E43d, 1.3872175661331396d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6.722308758188109E59d);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test29"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    java.lang.String var2 = var1.name();
    java.lang.String var3 = var1.name();
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var5.getTiesStrategy();
    int var7 = var6.ordinal();
    java.lang.String var8 = var6.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var6);
    double[] var11 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var11);
    var12.setContractionCriteria(50.000008f);
    var12.setExpansionMode(0);
    boolean var17 = var6.equals((java.lang.Object)var12);
    int var18 = var6.ordinal();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "MAXIMAL"+ "'", var2.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "MAXIMAL"+ "'", var3.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 3);

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test30"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(28798L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test31"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(1.151569395337692d, (-8.215268400528853E42d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test32"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(90L, 10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10L);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test33"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(61, 0.0f, 50.000004f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test34() {}
//   public void test34() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test34"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.pow(Double.NaN, 5.957132015917888E42d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test35"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(0, 0.0f, 9.5367426E-7f, 66);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test36"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(0.4301636967280036d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.4054581033635218d);

  }

  public void test37() {}
//   public void test37() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test37"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     double var4 = var0.nextExponential(0.056182176564052d);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var8 = var0.nextPascal((-1), 1.3418720970618036E43d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "cfa2263ffcaee6b504cdb79b248ae2057deb0cedd9e8ab5cd242dfb77c6832b5ab27d7e0e69be1d13fa6275891d8645b48b9"+ "'", var2.equals("cfa2263ffcaee6b504cdb79b248ae2057deb0cedd9e8ab5cd242dfb77c6832b5ab27d7e0e69be1d13fa6275891d8645b48b9"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.005902160727803293d);
// 
//   }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test38"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(0.26912670790612897d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.26912670790612897d);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test39"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(2147483647, 0.0f, 50.00001f, 61);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test40"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(100, 44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4400);

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test41"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(127, 12700);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1612900);

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test42"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4E-45f);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test43"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(50.000008f, 1.4E-45f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.4E-45f);

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test44"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(7.73868401503849E-14d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.73868401503849E-14d);

  }

  public void test45() {}
//   public void test45() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test45"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     double var17 = var0.nextGamma(0.9775852669347048d, 3.199763873047224E14d);
//     double var20 = var0.nextUniform(0.0d, 8.799063409660144E86d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var23 = var0.nextPascal(0, 1.3872175661331396d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "b3f0ed5a8e662d9100e95e00c32b9844c2187f1a30d00cff48922329a1db9d5e74a7d16106751e3cbd2fc8cbbeac5ba2d559"+ "'", var2.equals("b3f0ed5a8e662d9100e95e00c32b9844c2187f1a30d00cff48922329a1db9d5e74a7d16106751e3cbd2fc8cbbeac5ba2d559"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-8.333782228065921E42d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.5680510880242644E14d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 2.722002363883969E86d);
// 
//   }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test46"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)1.177802006337712d);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test47"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    java.lang.String var2 = var1.name();
    java.lang.String var3 = var1.toString();
    java.lang.Class var4 = var1.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var6 = java.lang.Enum.<java.lang.Enum>valueOf(var4, "6474de8476fcb1c9ba24772b3f776ab731334643aa716b46585632c5a42801e0b84c40b2a2b3f0fe490aa60edb45ca0a9745");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "MAXIMAL"+ "'", var2.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "MAXIMAL"+ "'", var3.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test48"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(3.199763873047224E14d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 68397.35544481203d);

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test49"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)1.2696572718964828E42d, (java.lang.Number)0.04776815816685154d, false);

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test50"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(31.402066659134473d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.552713678800501E-15d);

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test51"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(9.5367426E-7f, 50.000008f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.5367426E-7f);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test52"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(50.00001f, 5.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5.0f);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test53"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    var3.reseedRandomGenerator(1L);
    boolean var6 = var3.isSupportConnected();
    double var7 = var3.getNumericalVariance();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var9 = var3.sample(768793337);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 7.22597376812575E86d);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test54"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(9.143324706424012E42d, 1.4407207406957656d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.003691241449857575d);

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test55"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    java.lang.String var2 = var1.name();
    java.lang.String var3 = var1.toString();
    java.lang.Class var4 = var1.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var6 = java.lang.Enum.<java.lang.Enum>valueOf(var4, "hi!");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "MAXIMAL"+ "'", var2.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "MAXIMAL"+ "'", var3.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test56() {}
//   public void test56() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test56"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     var0.reSeed();
//     double var18 = var0.nextGamma(2.636818730233018d, 0.5d);
//     java.util.Collection var19 = null;
//     java.lang.Object[] var21 = var0.nextSample(var19, 0);
// 
//   }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test57"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)4.9E-324d, (java.lang.Number)2.5f, true);

  }

  public void test58() {}
//   public void test58() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test58"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     double var4 = var0.nextChiSquare(1.4640953062334716d);
//     org.apache.commons.math3.distribution.IntegerDistribution var5 = null;
//     int var6 = var0.nextInversionDeviate(var5);
// 
//   }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test59"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    var3.reseedRandomGenerator(1L);
    boolean var6 = var3.isSupportConnected();
    double var7 = var3.getNumericalVariance();
    boolean var8 = var3.isSupportLowerBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 7.22597376812575E86d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test60"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(31.4789883982983d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test61"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(10, 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-90));

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test62"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(4400, (-90));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4400);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test63"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(1612900);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test64"); }


    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(2, 10.0f, 10.0f, 1);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.setExpansionMode(127);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test65"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var2.setContractionCriteria(50.000008f);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = var2.copy();
    var2.setNumElements(2);
    int var8 = var2.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test66"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-127), 1612900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1612773);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test67"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(4.629628685877713E42d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.629628685877712E42d);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test68"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(2L, 3L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test69"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(127000, 100.0f, 2.0000002f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test70"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(127, 127000);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 127000);

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test71"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(0.007338067193186545d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0L);

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test72"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(2.636818730233018d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.9222222798755142E-4d);

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test73"); }


    double var1 = org.apache.commons.math3.special.Erf.erf((-5.705962099694664E43d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test74"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(2.1317761108019555d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4600603106728007d);

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test75"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(50.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test76"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    var3.reseedRandomGenerator(1L);
    double var7 = var3.cumulativeProbability(0.0d);
    double var8 = var3.getSupportUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == Double.POSITIVE_INFINITY);

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test77"); }


    double var1 = org.apache.commons.math3.util.FastMath.acos(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5707963267948966d);

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test78"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(50.000004f, 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 50.000004f);

  }

  public void test79() {}
//   public void test79() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test79"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     java.lang.String var4 = var0.nextHexString(110);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var7 = var0.nextUniform(0.10561069428565839d, 4.9784122222889134E-60d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.1059651017061727d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "fdbf60dc96ad37d49b6039246ba1bfef74b3e432fa3ea113889d058a18f115f3c8db2eaec6916adb84cc6b8dd2c713c1a252d4c1b1eadc"+ "'", var4.equals("fdbf60dc96ad37d49b6039246ba1bfef74b3e432fa3ea113889d058a18f115f3c8db2eaec6916adb84cc6b8dd2c713c1a252d4c1b1eadc"));
// 
//   }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test80"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(1L, 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test81"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(0.383865505085317d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.006699716948569819d);

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test82"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)2.9681911862806774E-44d, var1, false);
    java.lang.Number var4 = var3.getArgument();
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var3.getContext();
    boolean var6 = var3.getBoundIsAllowed();
    java.lang.Number var7 = var3.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 2.9681911862806774E-44d+ "'", var4.equals(2.9681911862806774E-44d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test83"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(10L, 90L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100L);

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test84"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog(47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 136.80272263732638d);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test85"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(1.9999999958199324d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.107148716958077d);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test86"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(1.3057219004014247d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9172219321891584d);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test87"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh((-27.741692681648217d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test88"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    var3.reseedRandomGenerator(1L);
    double var7 = var3.cumulativeProbability(0.0d);
    double var9 = var3.probability(6.770911672198755d);
    double var10 = var3.sample();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 3.5671315446818194E43d);

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test89"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(1.0d, 2.1317761108019555d);
    boolean var3 = var2.isSupportUpperBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test90"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(short)0, (java.lang.Number)10, false);
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.exception.NotPositiveException var10 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(short)1);
    java.lang.Object[] var11 = new java.lang.Object[] { (short)1};
    org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, var11);
    org.apache.commons.math3.exception.MathInternalError var13 = new org.apache.commons.math3.exception.MathInternalError(var7, var11);
    java.lang.Object[] var14 = new java.lang.Object[] { var11};
    org.apache.commons.math3.exception.MathInternalError var15 = new org.apache.commons.math3.exception.MathInternalError(var6, var14);
    org.apache.commons.math3.exception.MathIllegalStateException var16 = new org.apache.commons.math3.exception.MathIllegalStateException(var5, var14);
    org.apache.commons.math3.exception.MathIllegalStateException var17 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test91() {}
//   public void test91() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test91"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Object[] var3 = new java.lang.Object[] { '4'};
//     org.apache.commons.math3.exception.MaxCountExceededException var4 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)Double.NaN, var3);
//     org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var4);
// 
//   }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test92"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)0.9775852669347048d);

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test93"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var5.getTiesStrategy();
    int var7 = var6.ordinal();
    java.lang.String var8 = var6.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var6);
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = var9.getNanStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test94"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(100, 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 102);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test95"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(1.3057219004014247d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test96() {}
//   public void test96() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test96"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.0d, 1.0d, 1.8031769674261714E43d, 110);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test97"); }


    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.math.BigInteger var4 = null;
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var8 = new org.apache.commons.math3.exception.OutOfRangeException(var2, (java.lang.Number)100.0f, (java.lang.Number)var6, (java.lang.Number)0.5000672346092545d);
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    java.math.BigInteger var11 = null;
    java.math.BigInteger var13 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var15 = new org.apache.commons.math3.exception.OutOfRangeException(var9, (java.lang.Number)100.0f, (java.lang.Number)var13, (java.lang.Number)0.5000672346092545d);
    java.math.BigInteger var16 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, var13);
    java.math.BigInteger var18 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, 31L);
    org.apache.commons.math3.exception.OutOfRangeException var19 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)8.799063409660144E86d, (java.lang.Number)0.99999994f, (java.lang.Number)var6);
    org.apache.commons.math3.exception.util.Localizable var20 = null;
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    org.apache.commons.math3.exception.NotPositiveException var23 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(short)1);
    java.lang.Object[] var24 = new java.lang.Object[] { (short)1};
    org.apache.commons.math3.exception.MathIllegalStateException var25 = new org.apache.commons.math3.exception.MathIllegalStateException(var21, var24);
    org.apache.commons.math3.exception.MathIllegalStateException var26 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var19, var20, var24);
    org.apache.commons.math3.exception.util.ExceptionContext var27 = var26.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test98"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(0L, 20500L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test99() {}
//   public void test99() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test99"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     java.lang.String var4 = var0.nextHexString(110);
//     double var6 = var0.nextChiSquare(0.9865330122406505d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var9 = var0.nextPermutation(4400, 768793337);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.027943884657122428d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "41daa23dddad94945df45b58a1843f749e37896762645b6b0eacd2baa09eb5cc0b2a318e81d6b07875d3e5f7934816605344e83a659035"+ "'", var4.equals("41daa23dddad94945df45b58a1843f749e37896762645b6b0eacd2baa09eb5cc0b2a318e81d6b07875d3e5f7934816605344e83a659035"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.04184734325753198d);
// 
//   }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test100"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(9.143324706424012E42d, 4.594468614421035E-44d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.0087674787522005d));

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test101"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(0.10898669456022518d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test102"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh(0.42044027995299915d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.44822672346716985d);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test103"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(3.072433293358163E86d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 287);

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test104"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.10561069428565839d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-4));

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test105"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(102400.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 102400.01f);

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test106"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)Double.NEGATIVE_INFINITY, (java.lang.Number)0.0018388436884212223d, (java.lang.Number)1.8622531212727638d);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test107"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(0.9999999985516554d, 1.8246532949072747d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-4.152257768472053E8d));

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test108"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution((-6.715388288934036E43d), 6.419286864170918E43d, 4.629628685877713E42d);

  }

  public void test109() {}
//   public void test109() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test109"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     var0.reSeed();
//     double var18 = var0.nextGamma(2.636818730233018d, 0.5d);
//     java.util.Collection var19 = null;
//     java.lang.Object[] var21 = var0.nextSample(var19, 3);
// 
//   }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test110"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(1612773, 47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1612820);

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test111"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(1.0f, 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0f);

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test112"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh(0.9640275797804917d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.999999995819933d);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test113"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var5 = new double[] { 1.0d, 100.0d};
    var2.addElements(var5);
    double[] var7 = var2.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var8.discardMostRecentElements(127000);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test114"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos((-0.47598581837512266d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 76.42898646301789d);

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test115"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(9.5367426E-7f, 102400.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 102400.0f);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test116"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(1.200541497195915d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.3618530048246771d);

  }

  public void test117() {}
//   public void test117() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test117"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(4.246383128529704E21d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test118"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(1.8031769674261714E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.1471375077713234E41d);

  }

  public void test119() {}
//   public void test119() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test119"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.0d, (-0.12829376107453735d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test120"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign((-0.6120891811851691d), 3.1471375077713234E41d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.6120891811851691d);

  }

  public void test121() {}
//   public void test121() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test121"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     org.apache.commons.math3.exception.NotPositiveException var4 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(short)1);
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy[] var6 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
//     org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var5, (java.lang.Object[])var6);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var8 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, (java.lang.Object[])var6);
//     org.apache.commons.math3.exception.MaxCountExceededException var9 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)0.9640275797804917d, (java.lang.Object[])var6);
//     java.lang.String var10 = var9.toString();
// 
//   }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test122"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(0.0d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test123"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.03674973340708589d, 7.73868401503849E-14d, 3.899584967339712E86d, 127);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.6635655058964316d);

  }

  public void test124() {}
//   public void test124() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test124"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     double var4 = var0.nextExponential(0.056182176564052d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var7 = var0.nextPermutation(0, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "1c4d34bf00e07b751e3381a31cd44340f9e96b61153dac5bd4dd48605a6371f7438bbe83d431a14f80524b8cf5b4c508177a"+ "'", var2.equals("1c4d34bf00e07b751e3381a31cd44340f9e96b61153dac5bd4dd48605a6371f7438bbe83d431a14f80524b8cf5b4c508177a"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.08089525274539591d);
// 
//   }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test125"); }


    double var1 = org.apache.commons.math3.util.FastMath.acos(0.3618530048246771d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.200541497195915d);

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test126"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(1.5707963267948966d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.5091784786580567d);

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test127"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(96, (-9223372036854775808L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test128"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(8.799063409660144E86d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test129"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(0.02744636141299663d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.027442916677309914d);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test130"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.NotPositiveException var5 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(short)1);
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var7 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var8 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var5, var6, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathIllegalArgumentException var9 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MaxCountExceededException var10 = new org.apache.commons.math3.exception.MaxCountExceededException(var1, (java.lang.Number)0.9640275797804917d, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathInternalError var11 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test131() {}
//   public void test131() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test131"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ((-1.3748933199434673E43d), 1.200541497195915d, 0.0d, (-254));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test132() {}
//   public void test132() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test132"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     var0.reSeed(1L);
//     java.lang.String var6 = var0.nextHexString(10);
//     double var9 = var0.nextUniform(8.451195606992581E-30d, 6.770911672198756d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var0.nextHypergeometric(10, 0, 1612773);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "8b02f8a8bd62be327fc7417a9020136b0973d8652760fcad05d1fa30881ead22ca91186f95348a26677d478280827a73d7eb"+ "'", var2.equals("8b02f8a8bd62be327fc7417a9020136b0973d8652760fcad05d1fa30881ead22ca91186f95348a26677d478280827a73d7eb"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "93042192d2"+ "'", var6.equals("93042192d2"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2.2682182275901375d);
// 
//   }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test133"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(0.6040929060689715d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5723313665990505d);

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test134"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(5.840802579076462E13d, 66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.3097516144514474E33d);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test135"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(5.0f);
    org.apache.commons.math3.random.RandomDataImpl var3 = new org.apache.commons.math3.random.RandomDataImpl();
    boolean var4 = var0.equals((java.lang.Object)var3);
    var0.addElement(Double.NaN);
    var0.addElement((-1.4422495703074083d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test136"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(0.9732473842406115d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1102230246251565E-16d);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test137"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(4.9E-324d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.9E-324d);

  }

  public void test138() {}
//   public void test138() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test138"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     double var4 = var0.nextChiSquare(1.4640953062334716d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("", "b118bfa34ca66ebe3a54d288a232c636d16e1003ec21d820ccd89dc9422aaa2ad1002f16de80de050a6a59b9537b90cf6993");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.18307372334506866d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.39163187138116023d);
// 
//   }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test139"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.random.RandomGenerator var1 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var2.getNanStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test140"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(1612773, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test141() {}
//   public void test141() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test141"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     double var16 = var0.nextWeibull(1.0d, 1.6298598478788293d);
//     double var19 = var0.nextCauchy((-1.1440883267692863E33d), 3.3030345912774096E43d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var22 = var0.nextF((-4.606940746839709E43d), 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "41251f68889def29d19e3a8f5c1e11c08d7fec2059234ec235118c9270f58078bb775f466d02cdd2a8b11451f1691a7adaf4"+ "'", var2.equals("41251f68889def29d19e3a8f5c1e11c08d7fec2059234ec235118c9270f58078bb775f466d02cdd2a8b11451f1691a7adaf4"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 7.68640933048443E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.10719714840998776d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-4.613741072779008E43d));
// 
//   }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test142"); }


    org.apache.commons.math3.exception.NoDataException var0 = new org.apache.commons.math3.exception.NoDataException();
    java.lang.String var1 = var0.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "org.apache.commons.math3.exception.NoDataException: no data"+ "'", var1.equals("org.apache.commons.math3.exception.NoDataException: no data"));

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test143"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(0.117469904020025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.13194341175745541d);

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test144"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(100, 2.5f, 1.4E-45f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test145"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var2.setContractionCriteria(50.000008f);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = var2.copy();
    int var6 = var2.getNumElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.discardFrontElements(287);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1);

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test146"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(5.957132015917888E42d, 1.5485965529242296d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5.957132015917886E42d);

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test147"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(47, 44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test148"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(768793337, 10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 645781745);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test149"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(47);

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test150"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(27898L, 2700L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 75324600L);

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test151"); }


    double var2 = org.apache.commons.math3.special.Erf.erf((-0.6120891811851691d), 1.259921049017114d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.538521790062942d);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test152"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)2147483647, (java.lang.Number)0.9775852669347048d, false);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test153"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.3618530048246771d);

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test154"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(0.99999994f, (-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.99999994f));

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test155"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test156"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)4.440892098500626E-16d, (java.lang.Number)8.156532496556457E43d, false);

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test157"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.math.BigInteger var2 = null;
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var6 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)100.0f, (java.lang.Number)var4, (java.lang.Number)0.5000672346092545d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, (-90));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test158"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(28798L, 300L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 28798L);

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test159"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(4.629628685877713E42d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test160() {}
//   public void test160() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test160"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     double var16 = var0.nextWeibull(1.0d, 1.6298598478788293d);
//     double var19 = var0.nextWeibull(1.151569395337692d, 7.22597376812575E86d);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var23 = var0.nextGaussian(0.6040929060689715d, (-0.5606386275277435d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "656f0b126f111fd28714895a53a8928175f9fa44ae98942389dab850ae1dd6d9ec9afa89847f8ec0245854f951e085f419ce"+ "'", var2.equals("656f0b126f111fd28714895a53a8928175f9fa44ae98942389dab850ae1dd6d9ec9afa89847f8ec0245854f951e085f419ce"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.7016942917406407E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 5.642914230263415d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 7.356620837367317E85d);
// 
//   }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test161"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1.3748933199434673E43d), (java.lang.Number)0L, false);
    java.lang.Number var4 = var3.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0L+ "'", var4.equals(0L));

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test162"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(101, 127000);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 12827000);

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test163"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(1612820, 1.4E-45f, 0.0f, 102);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test164"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor((-1.334647089527227d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-2.0d));

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test165"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(1.2038021664515672d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.8164078923374847d);

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test166"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.NotPositiveException var5 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(short)1);
    java.lang.Object[] var6 = new java.lang.Object[] { (short)1};
    org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException(var3, var6);
    org.apache.commons.math3.exception.MathInternalError var8 = new org.apache.commons.math3.exception.MathInternalError(var2, var6);
    java.lang.Object[] var9 = new java.lang.Object[] { var6};
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var1, var9);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var9);
    org.apache.commons.math3.exception.util.ExceptionContext var12 = var11.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test167"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(3.1471375077713234E41d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test168"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(2.0000002f, 5.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5.0f);

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test169"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var2.setContractionCriteria(50.000008f);
    double[] var5 = var2.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    int var7 = var6.getExpansionMode();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test170"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)102, (java.lang.Number)0.6598643964752995d, false);

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test171"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(100, 12827000);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test172"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.6647615947356664d, Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.6647615947356664d);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test173"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(1.0806511876345213E86d, 3.199763873047224E14d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.5707963267948966d);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test174"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2147483647);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test175"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    int var4 = var3.getNumElements();
    double var6 = var3.addElementRolling(1.2982587902415216E14d);
    var3.setNumElements(3);
    int var9 = var3.getNumElements();
    var3.contract();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var12 = var3.getElement(127);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 3);

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test176"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(0.99999994f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.99999994f);

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test177"); }


    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(2, 10.0f, 10.0f, 1);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.setNumElements((-4));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test178() {}
//   public void test178() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test178"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.RealDistribution var3 = null;
//     double var4 = var0.nextInversionDeviate(var3);
// 
//   }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test179"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    double var4 = var3.getSupportLowerBound();
    double var6 = var3.probability((-0.5606386275277436d));
    double var7 = var3.getSupportUpperBound();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var9 = var3.sample(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == Double.POSITIVE_INFINITY);

  }

  public void test180() {}
//   public void test180() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test180"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ((-2.1317761108019555d), (-0.11369802507452609d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test181"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil((-2.3251745304976303d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-2.0d));

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test182"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(0.4566344307670791d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.551115123125783E-17d);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test183"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.NotPositiveException var7 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(short)1);
    java.lang.Object[] var8 = new java.lang.Object[] { (short)1};
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException(var5, var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var4, var8);
    java.lang.Object[] var11 = new java.lang.Object[] { var8};
    org.apache.commons.math3.exception.MathInternalError var12 = new org.apache.commons.math3.exception.MathInternalError(var3, var11);
    org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, var11);
    org.apache.commons.math3.exception.MaxCountExceededException var14 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, var1, var11);
    org.apache.commons.math3.exception.util.ExceptionContext var15 = var14.getContext();
    java.lang.Number var16 = var14.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test184"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(0L, 27900L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 27900L);

  }

  public void test185() {}
//   public void test185() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test185"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     double var17 = var0.nextGamma(0.9775852669347048d, 3.199763873047224E14d);
//     double var20 = var0.nextGaussian(1.8622531212727638d, 1.1265425086815434E43d);
//     var0.reSeed(27898L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "b98c8292a3ad423ffa785d70739060595feb24795948873866d2bfbe7e1cb3912102ef7bf154ea1add8e55ae8e2d81b2f4e0"+ "'", var2.equals("b98c8292a3ad423ffa785d70739060595feb24795948873866d2bfbe7e1cb3912102ef7bf154ea1add8e55ae8e2d81b2f4e0"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-1.0046950756152003E43d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.2539861847696195E14d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == (-9.588492076026093E41d));
// 
//   }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test186"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(4.605170185988092d, 6.389056068043896d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.605170185988092d);

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test187"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    double var4 = var3.getSupportLowerBound();
    double var5 = var3.getMean();
    double var6 = var3.getNumericalMean();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var3.inverseCumulativeProbability(1.2696572718964828E42d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test188"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(4.3097516144514474E33d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test189"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.lang.Number var3 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var4 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var2, var3);
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
    java.lang.Throwable[] var6 = var4.getSuppressed();
    org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError(var1, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MathInternalError var8 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.util.ExceptionContext var9 = var8.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test190"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-2.0537907646431078E43d), (java.lang.Number)0.48536179913615923d, false);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test191"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.NEGATIVE_INFINITY);

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test192"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    java.lang.String var2 = var1.name();
    java.lang.String var3 = var1.toString();
    java.lang.String var4 = var1.name();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "MAXIMAL"+ "'", var2.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "MAXIMAL"+ "'", var3.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "MAXIMAL"+ "'", var4.equals("MAXIMAL"));

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test193"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.03673319830899499d, 0.14423894632267276d, 1.4840955931403377E-44d, (-127));
      fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException");
    } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
      // Expected exception.
    }

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test194"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.9898371621797909d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.690796273272773d);

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test195"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException(var0);

  }

  public void test196() {}
//   public void test196() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test196"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     double var5 = var0.nextGamma(6.770911672198755d, 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.9542512052939294d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
// 
//   }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test197"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    java.lang.String var2 = var1.name();
    java.lang.String var3 = var1.toString();
    java.lang.Class var4 = var1.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var6 = java.lang.Enum.<java.lang.Enum>valueOf(var4, "a1ac0dc85a0f366ca0fbb460420d8339ced8287adf9e4246b98cbabfa492da35228738e43517fbbf0417d89802205471f7c7");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "MAXIMAL"+ "'", var2.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "MAXIMAL"+ "'", var3.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test198"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(127000);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test199"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    var3.reseedRandomGenerator(1L);
    double var7 = var3.cumulativeProbability(0.0d);
    double var8 = var3.getStandardDeviation();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var10 = var3.sample((-4));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.6881171418161356E43d);

  }

  public void test200() {}
//   public void test200() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test200"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     double var5 = var0.nextGaussian(0.0d, 0.5d);
//     var0.reSeed(10L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var0.nextBeta((-2.137948842748066E43d), 0.5d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.9235159922720244d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.7124883616419874d);
// 
//   }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test201"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.0d, (-1.5428819133018126E43d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test202() {}
//   public void test202() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test202"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
//     java.lang.String var2 = var1.name();
//     java.lang.String var3 = var1.toString();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
//     double[] var5 = null;
//     double[] var6 = var4.rank(var5);
// 
//   }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test203"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(100L, 6L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 94L);

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test204"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(68397.35544481203d, 4.594468614421035E-44d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 68397.35544481203d);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test205"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(61, 66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 61);

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test206"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3418720970618036E43d, 0.0d, 1.3057219004014247d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test207"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(20500L, 28798L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 20500L);

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test208"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(2L, 90L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test209"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    var3.reseedRandomGenerator(1L);
    double var7 = var3.cumulativeProbability(0.0d);
    double var9 = var3.cumulativeProbability(1.0d);
    double var10 = var3.getNumericalMean();
    double var11 = var3.sample();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 3.5671315446818194E43d);

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test210"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(110, 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test211"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(102400.01f, 102400.01f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 102400.01f);

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test212"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("6cd6d3d4ec139a4c95523bc97de81a8e0283e3032b6664a5191cec5bf215afed76812dfa790aac7bc29aeaa9f1c179addc092d166a6726");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test213"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(3.276074671525456E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.723700438986527E21d);

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test214"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)10.0d);
    java.lang.Number var2 = var1.getMax();
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var1.getContext();
    java.lang.String var4 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 10.0d+ "'", var2.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (10) exceeded"+ "'", var4.equals("org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (10) exceeded"));

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test215"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(0.26912670790612897d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.3088209685048367d);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test216"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(6.770911672198755d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6.770911672198755d);

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test217"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(5.0f);
    var0.setElement(110, Double.NaN);
    var0.discardFrontElements(10);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var8.setContractionCriteria(50.000008f);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var8);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var12 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var14 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    var15.setContractionCriteria(50.000008f);
    double[] var18 = var15.getInternalValues();
    double[] var20 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var21 = new org.apache.commons.math3.util.ResizableDoubleArray(var20);
    var21.setContractionCriteria(50.000008f);
    double[] var24 = var21.getInternalValues();
    double[] var25 = var21.getElements();
    double var26 = var12.mannWhitneyU(var18, var25);
    var8.addElements(var25);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var8.discardMostRecentElements((-1));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.5d);

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test218"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    float var3 = var2.getExpansionFactor();
    var2.contract();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.discardMostRecentElements(102);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 2.0f);

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test219"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1.5485965529242296d, (java.lang.Number)6.770911672198755d, false);
    boolean var5 = var4.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test220() {}
//   public void test220() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test220"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     double var4 = var0.nextChiSquare(1.4640953062334716d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var7 = var0.nextBeta(0.0d, 2.6881171418161356E43d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.0457159864230192d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.19670981857776312d);
// 
//   }

  public void test221() {}
//   public void test221() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test221"); }
// 
// 
//     org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     var0.setContractionCriteria(5.0f);
//     org.apache.commons.math3.random.RandomDataImpl var3 = new org.apache.commons.math3.random.RandomDataImpl();
//     boolean var4 = var0.equals((java.lang.Object)var3);
//     double var6 = var3.nextT(0.007338067193186545d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.5804317627621424E42d);
// 
//   }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test222"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    double var4 = var3.getSupportLowerBound();
    double var6 = var3.density(1.9222222798755142E-4d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var9 = var3.cumulativeProbability(1.188156673789677E14d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.4840955931403377E-44d);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test223"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)900L, (java.lang.Number)0.6120891811851691d, (java.lang.Number)0.06535479195982165d);

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test224"); }


    double var2 = org.apache.commons.math3.util.FastMath.min((-0.18262511344517568d), 3.7760951459250447d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.18262511344517568d));

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test225"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint((-1.1440883267692863E33d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.1440883267692863E33d));

  }

  public void test226() {}
//   public void test226() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test226"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     var0.reSeed(1L);
//     double var7 = var0.nextWeibull(6.389056068043896d, 6.770911672198755d);
//     double var10 = var0.nextF(5.551115123125783E-17d, 1.107148716958077d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "0d57cc62b77ce34958fef4a13326feb40a3893ef3fbf0f1b1c5539df58e8f16e352b05f937b22389681c7582e168e8a2f1c9"+ "'", var2.equals("0d57cc62b77ce34958fef4a13326feb40a3893ef3fbf0f1b1c5539df58e8f16e352b05f937b22389681c7582e168e8a2f1c9"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 4.5194037630894135d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.0d);
// 
//   }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test227"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor((-0.4217216060310984d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test228"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(5.551115123125783E-17d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.450580596923828E-9d);

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test229"); }


    double var2 = org.apache.commons.math3.util.FastMath.min((-8.215268400528853E42d), 3.481840771213688d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-8.215268400528853E42d));

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test230"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(0.3088209685048367d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6759308372170155d);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test231"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos((-9.588492076026093E41d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.9064833280591146d));

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test232"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var2.setContractionCriteria(50.000008f);
    var2.clear();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var6 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var8 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
    var9.setContractionCriteria(50.000008f);
    double[] var12 = var9.getInternalValues();
    double[] var14 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    var15.setContractionCriteria(50.000008f);
    double[] var18 = var15.getInternalValues();
    double[] var19 = var15.getElements();
    double var20 = var6.mannWhitneyUTest(var12, var19);
    var2.addElements(var19);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var23 = var2.getElement(61);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test233"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    double var4 = var3.getSupportLowerBound();
    double var6 = var3.probability(6.419286864170918E43d);
    double var8 = var3.cumulativeProbability((-3.4611764310781617E43d));
    var3.reseedRandomGenerator(0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.098945418308171d);

  }

  public void test234() {}
//   public void test234() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test234"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(2.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var5 = var0.nextWeibull((-0.833026455507159d), 1.3418720970618036E43d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2.161989197186239d);
// 
//   }

  public void test235() {}
//   public void test235() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test235"); }
// 
// 
//     org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     var0.setContractionCriteria(5.0f);
//     org.apache.commons.math3.random.RandomDataImpl var3 = new org.apache.commons.math3.random.RandomDataImpl();
//     boolean var4 = var0.equals((java.lang.Object)var3);
//     long var6 = var3.nextPoisson(1.8622531212727638d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var9 = var3.nextBinomial(0, (-5.705962099694664E43d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 7L);
// 
//   }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test236"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.contract();
    double[] var2 = var0.getInternalValues();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.discardMostRecentElements(111);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test237"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, var1);
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.NotPositiveException var7 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(short)1);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var9 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var7, var8, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.MathIllegalArgumentException var11 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var5, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.MaxCountExceededException var12 = new org.apache.commons.math3.exception.MaxCountExceededException(var3, (java.lang.Number)0.9640275797804917d, (java.lang.Object[])var9);
    var2.addSuppressed((java.lang.Throwable)var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test238() {}
//   public void test238() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test238"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     double var4 = var0.nextExponential(0.056182176564052d);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var7 = var0.nextChiSquare((-2.791500647694174E42d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "ea1665ba7a569be5f75cd33339ea381003175a7c5e3c988538964ef5ab7397065457eda4ae797bd4fe8561b41d59ad2a2a5a"+ "'", var2.equals("ea1665ba7a569be5f75cd33339ea381003175a7c5e3c988538964ef5ab7397065457eda4ae797bd4fe8561b41d59ad2a2a5a"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.12605703601361593d);
// 
//   }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test239"); }


    long var1 = org.apache.commons.math3.util.FastMath.round((-2.3251745304976303d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-2L));

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test240"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)2.0d, (java.lang.Number)50.0f, (java.lang.Number)436.05387683681073d);
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test241"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh((-4.874405868194998E42d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test242"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(0.6598643964752995d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5782731623958087d);

  }

  public void test243() {}
//   public void test243() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test243"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.math.BigInteger var2 = null;
//     java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 0L);
//     org.apache.commons.math3.exception.OutOfRangeException var6 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)100.0f, (java.lang.Number)var4, (java.lang.Number)0.5000672346092545d);
//     java.lang.Number var7 = var6.getHi();
//     org.apache.commons.math3.exception.util.Localizable var8 = null;
//     java.lang.Object[] var9 = null;
//     org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var6, var8, var9);
// 
//   }

  public void test244() {}
//   public void test244() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test244"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     double var17 = var0.nextGamma(0.9775852669347048d, 3.199763873047224E14d);
//     double var20 = var0.nextUniform(0.0d, 8.799063409660144E86d);
//     org.apache.commons.math3.distribution.NormalDistribution var24 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var24.reseedRandomGenerator(1L);
//     boolean var27 = var24.isSupportConnected();
//     double var28 = var24.getMean();
//     double var29 = var24.sample();
//     double var30 = var24.getSupportUpperBound();
//     boolean var31 = var24.isSupportUpperBoundInclusive();
//     boolean var32 = var24.isSupportUpperBoundInclusive();
//     double var33 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var24);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var36 = var0.nextUniform(1.8031769674261714E43d, 4.951760157141521E27d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "8476d09f7607cf747529e3fec94d102132447761de3709a1033d4ea5bb4200f6a0e33a670c7b525fcd060e6e773b65086a5a"+ "'", var2.equals("8476d09f7607cf747529e3fec94d102132447761de3709a1033d4ea5bb4200f6a0e33a670c7b525fcd060e6e773b65086a5a"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.4211397542043522E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.196173765092397E14d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 4.7075926437638827E86d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 3.5671315446818194E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == (-3.744787687656061E41d));
// 
//   }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test245"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(1.0f, 61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.30584301E18f);

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test246"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(Double.POSITIVE_INFINITY, 4.111122573849115E13d);
    double var3 = var2.getMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == Double.POSITIVE_INFINITY);

  }

  public void test247() {}
//   public void test247() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test247"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var6 = var0.nextHypergeometric(110, 96, 127);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.6431573126962657d);
// 
//   }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test248"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(90L, 6L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 540L);

  }

  public void test249() {}
//   public void test249() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test249"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(6.419286864170918E43d, (-1.0046950756152003E43d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test250"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var5 = new double[] { 1.0d, 100.0d};
    var2.addElements(var5);
    double[] var7 = var2.getInternalValues();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setExpansionFactor(1.4E-45f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test251"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, var1);

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test252"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(7.353300445964135E86d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test253"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)1.9999999958199324d, var1, (java.lang.Number)1.0f);
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var3.getContext();
    java.lang.Number var5 = var3.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1.0f+ "'", var5.equals(1.0f));

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test254"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(0.9999999999999971d, 0.5274450245437947d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.2161543004921728E14d);

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test255"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(0.4566344307670791d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.4273372138374235d);

  }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test256"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(5.0f);
    org.apache.commons.math3.random.RandomDataImpl var3 = new org.apache.commons.math3.random.RandomDataImpl();
    boolean var4 = var0.equals((java.lang.Object)var3);
    var0.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test257"); }


    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(3, 2.0f, 2.5f);
    double[] var4 = var3.getInternalValues();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test258"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble(127);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.0126600184580075E213d);

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test259"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(10, 9.5367426E-7f, 50.000008f, 3);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test260"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(0.9865330122406505d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8341186568683249d);

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test261"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(7.73868401503849E-14d, (-4.192979513069657E43d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.0000000000000873d));

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test262"); }


    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.math.BigInteger var3 = null;
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var7 = new org.apache.commons.math3.exception.OutOfRangeException(var1, (java.lang.Number)100.0f, (java.lang.Number)var5, (java.lang.Number)0.5000672346092545d);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    java.math.BigInteger var10 = null;
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var10, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var14 = new org.apache.commons.math3.exception.OutOfRangeException(var8, (java.lang.Number)100.0f, (java.lang.Number)var12, (java.lang.Number)0.5000672346092545d);
    java.math.BigInteger var15 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, var12);
    java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 12700);
    java.math.BigInteger var19 = org.apache.commons.math3.util.ArithmeticUtils.pow(var17, 768793337);
    org.apache.commons.math3.exception.NumberIsTooSmallException var21 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)27898L, (java.lang.Number)var17, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test263() {}
//   public void test263() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test263"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     double var16 = var0.nextWeibull(1.0d, 1.6298598478788293d);
//     double var19 = var0.nextCauchy((-1.1440883267692863E33d), 3.3030345912774096E43d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var22 = var0.nextZipf(0, 3.3030345912774096E43d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "3a3d2c15b2fce65084e896994e8a334545202bb8108934d67ce78c807e2d2a0bdcab233a274d9a015814b7472e53c563ccd1"+ "'", var2.equals("3a3d2c15b2fce65084e896994e8a334545202bb8108934d67ce78c807e2d2a0bdcab233a274d9a015814b7472e53c563ccd1"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-1.5466976577735195E43d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.29514682399016445d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-7.614868981146033E42d));
// 
//   }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test264"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(1.9586146923852683d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.3781696985345623d));

  }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test265"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(3.5671315446818194E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.5671315446818194E43d);

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test266"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(3.7760951459250447d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.3119152085309351d);

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test267"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(2.4188678176733584E-44d, 1.1265425086815434E43d, 0.383865505085317d, (-90));
      fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException");
    } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
      // Expected exception.
    }

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test268"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-3.378211155916252E42d), (java.lang.Number)0.4566344307670791d, true);

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test269"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(101, 127);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test270"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.0f, 4.111122573849115E13d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.4E-45f);

  }

  public void test271() {}
//   public void test271() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test271"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(410.32277652693745d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test272"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(47, 1612820);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test273"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(0L, 20500L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test274"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var3 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MaxCountExceededException var4 = new org.apache.commons.math3.exception.MaxCountExceededException(var1, var2, (java.lang.Object[])var3);
    org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var3);
    org.apache.commons.math3.exception.util.ExceptionContext var6 = var5.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test275"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign((-2.0d), (-0.7997115369080445d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-2.0d));

  }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test276"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)2.1104109613941144d);

  }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test277"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(94L, 540L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 94L);

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test278"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(300L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 300L);

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test279"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    double var4 = var3.getSupportLowerBound();
    double var6 = var3.probability((-0.5606386275277436d));
    double var7 = var3.getSupportUpperBound();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var9 = var3.inverseCumulativeProbability((-1.0223787590678046d));
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == Double.POSITIVE_INFINITY);

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test280"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.6362189423446424d, 0.18029079387572064d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.08494423315824018d));

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test281"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(3.5671315446818194E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 100.97606796324061d);

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test282"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    java.lang.String var2 = var1.name();
    java.lang.String var3 = var1.name();
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var5.getTiesStrategy();
    int var7 = var6.ordinal();
    java.lang.String var8 = var6.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var6);
    org.apache.commons.math3.stat.ranking.TiesStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var10);
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "MAXIMAL"+ "'", var2.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "MAXIMAL"+ "'", var3.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test283"); }


    java.lang.Number var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)1.684024197549089d, var2);
    java.lang.String var4 = var3.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: null out of [1.684, null] range"+ "'", var4.equals("org.apache.commons.math3.exception.OutOfRangeException: null out of [1.684, null] range"));

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test284"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(0.9732473842406115d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9732473842406116d);

  }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test285"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(12700);
    float var2 = var1.getExpansionFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0f);

  }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test286"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(8.86277792391741E42d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test287() {}
//   public void test287() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test287"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     java.math.BigInteger var3 = null;
//     java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0L);
//     org.apache.commons.math3.exception.OutOfRangeException var7 = new org.apache.commons.math3.exception.OutOfRangeException(var1, (java.lang.Number)100.0f, (java.lang.Number)var5, (java.lang.Number)0.5000672346092545d);
//     org.apache.commons.math3.exception.util.Localizable var8 = null;
//     java.math.BigInteger var10 = null;
//     java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var10, 0L);
//     org.apache.commons.math3.exception.OutOfRangeException var14 = new org.apache.commons.math3.exception.OutOfRangeException(var8, (java.lang.Number)100.0f, (java.lang.Number)var12, (java.lang.Number)0.5000672346092545d);
//     java.math.BigInteger var15 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, var12);
//     java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 10L);
//     java.math.BigInteger var18 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, var5);
// 
//   }

  public void test288() {}
//   public void test288() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test288"); }
// 
// 
//     java.lang.Class var0 = null;
//     java.lang.Enum var2 = java.lang.Enum.<java.lang.Enum>valueOf(var0, "b205b1eb014e8092018c20ec1f6cb6348c478f65d15816ac73fd1588a967c9f25a20cf73ea6db24bd2b9671932018448609cc8c42ea6ae");
// 
//   }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test289"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(0.6040929060689715d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5434235565682811d);

  }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test290"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp((-0.99999994f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.9999999f));

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test291"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(-4.9E-324d), (java.lang.Number)2.688117141816136E43d, (java.lang.Number)(-5.705962099694664E43d));

  }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test292"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(0.26912670790612897d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.645632820750788d);

  }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test293"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(1612820);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1612820);

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test294"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd((-4), 66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2);

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test295"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(100L, 900L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test296"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)2.376313347579354E14d, (java.lang.Number)1.259921049017114d, (java.lang.Number)0.098945418308171d);

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test297"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(1.4E-45f, 0.99999994f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.4E-45f);

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test298"); }


    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(2, 10.0f, 10.0f, 1);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var7 = var5.substituteMostRecentElement(1.4840955931403377E-44d);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException");
    } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
      // Expected exception.
    }

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test299"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(0L, 5144L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test300"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(8.156532496556457E43d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test301"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test302"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(100, (-127));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 227);

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test303"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(0, (-4));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-4));

  }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test304"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(900L, 27900L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-27000L));

  }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test305"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(1.9222222798755142E-4d, 0.06535479195982165d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.9222222798755142E-4d);

  }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test306"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(0.4349627593755754d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.5707963267948966d);

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test307"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(0.5274450245437947d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5274450245437948d);

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test308"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    var3.reseedRandomGenerator(1L);
    boolean var6 = var3.isSupportConnected();
    double var7 = var3.getMean();
    double var10 = var3.cumulativeProbability(0.0d, 1.6298598478788293d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var12 = var3.sample(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 2.4188678176733584E-44d);

  }

  public void test309() {}
//   public void test309() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test309"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log1p((-1.4422495703074083d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test310() {}
//   public void test310() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test310"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     java.lang.String var4 = var0.nextHexString(110);
//     double var6 = var0.nextChiSquare(0.9865330122406505d);
//     var0.reSeedSecure(28798L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var0.nextChiSquare(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.20460262290186249d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "28d270f1e7c642916153714681896d5ab5e8a292130a913dbafd141f0d35e1d6d86ea81a2e2ecd6ac3b5e2abd1dea5ffcbcd93cae1851b"+ "'", var4.equals("28d270f1e7c642916153714681896d5ab5e8a292130a913dbafd141f0d35e1d6d86ea81a2e2ecd6ac3b5e2abd1dea5ffcbcd93cae1851b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 4.602731207240631d);
// 
//   }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test311"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor((-5.329951075180856E43d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-5.329951075180856E43d));

  }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test312"); }


    double var2 = org.apache.commons.math3.util.FastMath.max((-238.09832457991453d), 0.6360918665423811d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.6360918665423811d);

  }

  public void test313() {}
//   public void test313() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test313"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     double var16 = var0.nextWeibull(1.0d, 1.6298598478788293d);
//     double var19 = var0.nextWeibull(1.151569395337692d, 7.22597376812575E86d);
//     double var22 = var0.nextGaussian(2.4188678176733584E-44d, 0.9732473842406115d);
//     int var25 = var0.nextInt(66, 96);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var28 = var0.nextPermutation(0, 4400);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "8c5afd0e29ca0dd4b63cdff4be01de6f6e1130eabf843126aa588a969986a99133adae3eb2af21d718640a10a8d4eba0521d"+ "'", var2.equals("8c5afd0e29ca0dd4b63cdff4be01de6f6e1130eabf843126aa588a969986a99133adae3eb2af21d718640a10a8d4eba0521d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-2.239131313148551E43d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1.9927858592798702d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1.8739445286679463E87d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0.5176478285390262d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 73);
// 
//   }

  public void test314() {}
//   public void test314() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test314"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(2.1982960988904782E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test315"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(0.9999999985344892d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.1572992076586297d);

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test316"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.42044027995299915d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test317"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.26912670790612897d, 4.3062441011611504E86d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.3062441011611504E86d);

  }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test318"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(5.840802579076462E13d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0078125d);

  }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test319"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(2.636818730233018d, 1.4840955931403377E-44d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.636818730233018d);

  }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test320"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var5.getTiesStrategy();
    int var7 = var6.ordinal();
    java.lang.String var8 = var6.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var6);
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var10.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var12.setContractionCriteria(5.0f);
    var12.setElement(110, Double.NaN);
    var12.setElement(100, (-0.6120891811851691d));
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var10, var12);
    double[] var22 = var12.getElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var23 = var9.rank(var22);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test321"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.TiesStrategy var3 = var2.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = var2.getNanStrategy();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var5.addElement(0.02797455810085192d);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var8 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var10 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var10);
    var11.setContractionCriteria(50.000008f);
    double[] var14 = var11.getInternalValues();
    double[] var16 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var17 = new org.apache.commons.math3.util.ResizableDoubleArray(var16);
    var17.setContractionCriteria(50.000008f);
    double[] var20 = var17.getInternalValues();
    double[] var21 = var17.getElements();
    double var22 = var8.mannWhitneyU(var14, var21);
    var5.addElements(var14);
    double[] var24 = var2.rank(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test322"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var2.setContractionCriteria(5.0f);
    var2.setElement(110, Double.NaN);
    var2.setElement(100, (-0.6120891811851691d));
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var2);
    double[] var13 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var13);
    var14.setContractionCriteria(50.000008f);
    var14.setExpansionMode(0);
    var14.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var2, var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test323() {}
//   public void test323() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test323"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(2.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var5 = var0.nextGaussian(4.3062441011611504E86d, (-0.11419179453672551d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.5062823164979755d);
// 
//   }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test324"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.0d, 0.9775852669347048d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9775852669347048d);

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test325"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(1.1597528820798812E14d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1597528820798812E14d);

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test326"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(1.0d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test327"); }


    int var2 = org.apache.commons.math3.util.FastMath.max((-4), 1612820);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1612820);

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test328"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(2.4188678176733584E-44d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.4188678176733584E-44d);

  }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test329"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(1365503.475321342d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 20);

  }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test330"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(0.8623188722876839d, 0.9898371621797909d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.06895849133460996d);

  }

  public void test331() {}
//   public void test331() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test331"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.sqrt((-1.3748933199434673E43d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test332"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(2.1559381324233437E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.155938132423344E43d);

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test333"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.3618530048246771d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test334"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    var3.reseedRandomGenerator(1L);
    double var6 = var3.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 7.22597376812575E86d);

  }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test335"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(0.726763368376827d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.3191543449729769d));

  }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test336"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(0.0078125d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.19842513149602495d);

  }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test337"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(94L, (-90L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test338"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double var4 = var2.substituteMostRecentElement(1.0159453334112069E43d);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var5 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var7 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    var8.setContractionCriteria(50.000008f);
    double[] var11 = var8.getInternalValues();
    double[] var13 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var13);
    var14.setContractionCriteria(50.000008f);
    double[] var17 = var14.getInternalValues();
    double[] var18 = var14.getElements();
    double var19 = var5.mannWhitneyUTest(var11, var18);
    org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray(var18);
    var2.addElements(var18);
    int var22 = var2.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);

  }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test339"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(1.1265425086815434E43d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.1265425086815431E43d);

  }

  public void test340() {}
//   public void test340() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test340"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(1.7238281465865108d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test341"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.4273372138374235d, var2, false);

  }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test342"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog(17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 33.50507345013689d);

  }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test343"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    java.lang.String var2 = var1.name();
    java.lang.String var3 = var1.name();
    boolean var5 = var1.equals((java.lang.Object)"bbc76c98706e096cbdb48c11be18b37feafe094ae0e5291b81fe65cbd0c42cc6f465c322de0f5afaf8fdd0237c92d0d9c2d6");
    int var6 = var1.ordinal();
    org.apache.commons.math3.random.RandomGenerator var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = var9.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var12 = var11.getNanStrategy();
    java.lang.String var13 = var12.name();
    java.lang.String var14 = var12.name();
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15);
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    int var18 = var17.ordinal();
    java.lang.String var19 = var17.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12, var17);
    double[] var22 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var23 = new org.apache.commons.math3.util.ResizableDoubleArray(var22);
    var23.setContractionCriteria(50.000008f);
    var23.setExpansionMode(0);
    boolean var28 = var17.equals((java.lang.Object)var23);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var29 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var10, var17);
    org.apache.commons.math3.stat.ranking.NaturalRanking var30 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var17);
    int var31 = var1.ordinal();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "MAXIMAL"+ "'", var2.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "MAXIMAL"+ "'", var3.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "MAXIMAL"+ "'", var13.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "MAXIMAL"+ "'", var14.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "AVERAGE"+ "'", var19.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 1);

  }

  public void test344() {}
//   public void test344() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test344"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     double var16 = var0.nextBeta(7.22597376812575E86d, 0.9898371621797909d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var19 = var0.nextPermutation(0, 10);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "48ef964af5ffc090c23179cf429a5d2ff740bf998c6f987ef6d40d704c56bfc6a8ff948437b1ec726df5756a49220831ee1c"+ "'", var2.equals("48ef964af5ffc090c23179cf429a5d2ff740bf998c6f987ef6d40d704c56bfc6a8ff948437b1ec726df5756a49220831ee1c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 2.334125019107048E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1.0d);
// 
//   }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test345"); }


    long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2432902008176640000L);

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test346"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(0.0078125d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.007782140442054949d);

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test347"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)0.5000672346092545d);

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test348"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(768793337);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }

  }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test349"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign((-0.99999994f), 2560.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.99999994f);

  }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test350"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(3.5671315446818194E43d, 1.2982587902415216E14d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test351() {}
//   public void test351() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test351"); }
// 
// 
//     org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     var0.setContractionCriteria(5.0f);
//     org.apache.commons.math3.random.RandomDataImpl var3 = new org.apache.commons.math3.random.RandomDataImpl();
//     boolean var4 = var0.equals((java.lang.Object)var3);
//     double var7 = var3.nextGamma(0.42044027995299915d, (-3.378211155916252E42d));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var10 = var3.nextPermutation(0, 127);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-3.474522570666192E41d));
// 
//   }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test352"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    int var4 = var3.getNumElements();
    double var6 = var3.addElementRolling(1.2982587902415216E14d);
    var3.setNumElements(3);
    int var9 = var3.getNumElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setExpansionFactor(9.5367426E-7f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 3);

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test353"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var1.getNanStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test354"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Throwable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Object[] var5 = new java.lang.Object[] { 0.056182176564052d};
    org.apache.commons.math3.exception.MathIllegalStateException var6 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, var3, var5);
    org.apache.commons.math3.exception.MaxCountExceededException var7 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)0.4855570380544819d, var5);
    java.lang.Number var8 = var7.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 0.4855570380544819d+ "'", var8.equals(0.4855570380544819d));

  }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test355"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(33.50507345013689d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.2238155921557956d);

  }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test356"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(44, 3119L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test357"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(10.0f, 1.0713813143399866d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.999999f);

  }

  public void test358() {}
//   public void test358() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test358"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy var1 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var1);
//     org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     var3.setContractionCriteria(5.0f);
//     org.apache.commons.math3.random.RandomDataImpl var6 = new org.apache.commons.math3.random.RandomDataImpl();
//     boolean var7 = var3.equals((java.lang.Object)var6);
//     double[] var8 = var3.getElements();
//     double[] var9 = var2.rank(var8);
// 
//   }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test359"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray((-4));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test360"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    var3.reseedRandomGenerator(1L);
    boolean var6 = var3.isSupportConnected();
    double var7 = var3.getMean();
    double var8 = var3.sample();
    double var9 = var3.getSupportUpperBound();
    boolean var10 = var3.isSupportUpperBoundInclusive();
    boolean var11 = var3.isSupportUpperBoundInclusive();
    double var12 = var3.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 3.5671315446818194E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test361"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    float var3 = var2.getExpansionFactor();
    boolean var5 = var2.equals((java.lang.Object)1612900);
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var2.copy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test362"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(540L, 322L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 862L);

  }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test363"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(410.32277652693745d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 410.32277652693745d);

  }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test364"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(2.688117141816136E43d, 0.056182176564052d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.9366718398504545d));

  }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test365"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    double var4 = var3.getSupportLowerBound();
    double var6 = var3.probability((-0.5606386275277436d));
    double var7 = var3.getSupportUpperBound();
    boolean var8 = var3.isSupportConnected();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);

  }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test366"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);

  }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test367"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-2L), 94L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test368() {}
//   public void test368() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test368"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     double var17 = var0.nextGamma(0.9775852669347048d, 3.199763873047224E14d);
//     double var20 = var0.nextUniform(0.0d, 8.799063409660144E86d);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var24 = var0.nextPermutation((-4), 1612820);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "7c86e85ca9af57416170a2b7e2e8e07282ccc99ac36fc1808ffb425667b2aa11e1fb76d89297d9d83017ee53cc815a1d82b7"+ "'", var2.equals("7c86e85ca9af57416170a2b7e2e8e07282ccc99ac36fc1808ffb425667b2aa11e1fb76d89297d9d83017ee53cc815a1d82b7"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-1.9538712390823034E43d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 9.90149803485503E13d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 7.702350216052162E86d);
// 
//   }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test369"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(0, 1.0f, 2.5f, 2);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test370"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(0.027442916677309914d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.027822941883977482d);

  }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test371"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin((-4.888155648766879E43d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.9844545308417082d));

  }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test372"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm((-27000L), 540L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 27000L);

  }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test373"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(11.712762449867773d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6572681123794027d);

  }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test374"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.math.BigInteger var3 = null;
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var7 = new org.apache.commons.math3.exception.OutOfRangeException(var1, (java.lang.Number)100.0f, (java.lang.Number)var5, (java.lang.Number)0.5000672346092545d);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    java.math.BigInteger var10 = null;
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var10, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var14 = new org.apache.commons.math3.exception.OutOfRangeException(var8, (java.lang.Number)100.0f, (java.lang.Number)var12, (java.lang.Number)0.5000672346092545d);
    java.math.BigInteger var15 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, var12);
    org.apache.commons.math3.exception.util.Localizable var16 = null;
    java.lang.Object[] var19 = new java.lang.Object[] { '4'};
    org.apache.commons.math3.exception.MaxCountExceededException var20 = new org.apache.commons.math3.exception.MaxCountExceededException(var16, (java.lang.Number)Double.NaN, var19);
    java.lang.Throwable[] var21 = var20.getSuppressed();
    org.apache.commons.math3.exception.MaxCountExceededException var22 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)var5, (java.lang.Object[])var21);
    java.math.BigInteger var24 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 5144L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.math.BigInteger var26 = org.apache.commons.math3.util.ArithmeticUtils.pow(var24, (-254));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test375"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(2.688117141816136E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999999999999971d);

  }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test376"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)10.0d);
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var1.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test377"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(1.4E-45f, 2.0000005f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.4E-45f);

  }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test378"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(2, 1612773);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1612775);

  }

  public void test379() {}
//   public void test379() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test379"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     double var17 = var0.nextGamma(0.9775852669347048d, 3.199763873047224E14d);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var20 = var0.nextPoisson(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "91617c78c29fbad1dccd8b64da82a79a007c56d03fdcb49a342a9dfaf40cd3d471e69a8b92a8457d8cc1377d881710715fff"+ "'", var2.equals("91617c78c29fbad1dccd8b64da82a79a007c56d03fdcb49a342a9dfaf40cd3d471e69a8b92a8457d8cc1377d881710715fff"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-4.251014776663668E43d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 8.164263520840453E13d);
// 
//   }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test380"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(2.5091784786580567d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.874110573361593E-4d);

  }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test381"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(27898L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test382"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(100.97606796324061d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.308006198543624d);

  }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test383"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)1.3418720970618036E43d, (java.lang.Number)5.0f, true);
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.exception.NotPositiveException var10 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(short)1);
    java.lang.Object[] var11 = new java.lang.Object[] { (short)1};
    org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, var11);
    org.apache.commons.math3.exception.MathInternalError var13 = new org.apache.commons.math3.exception.MathInternalError(var7, var11);
    java.lang.Object[] var14 = new java.lang.Object[] { var11};
    org.apache.commons.math3.exception.MathInternalError var15 = new org.apache.commons.math3.exception.MathInternalError(var6, var14);
    org.apache.commons.math3.exception.MaxCountExceededException var16 = new org.apache.commons.math3.exception.MaxCountExceededException(var4, (java.lang.Number)7.446477798073399d, var14);
    java.lang.Number var17 = var16.getMax();
    var3.addSuppressed((java.lang.Throwable)var16);
    org.apache.commons.math3.exception.util.ExceptionContext var19 = var16.getContext();
    java.lang.Number var20 = var16.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + 7.446477798073399d+ "'", var17.equals(7.446477798073399d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + 7.446477798073399d+ "'", var20.equals(7.446477798073399d));

  }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test384"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan((-2.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.185039863261519d);

  }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test385"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.0d, 0.5088599843857857d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test386"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(227);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test387() {}
//   public void test387() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test387"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     double var5 = var0.nextGaussian(0.0d, 0.5d);
//     var0.reSeed(10L);
//     double var10 = var0.nextF(1.3872175661331396d, 2.636818730233018d);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var0.nextBinomial(110, 1.3057219004014247d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.7010436865460183d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.8090157524508511d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5088599843857857d);
// 
//   }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test388"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(61.385627560860215d, (-0.11369802507452609d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.626181665648831d);

  }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test389"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-1L), (java.lang.Number)(-2.1317761108019555d), false);
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    java.lang.Number var5 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-2.1317761108019555d)+ "'", var5.equals((-2.1317761108019555d)));

  }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test390"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.48536179913615923d, 3.5877964939570827E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test391"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(10, 61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test392"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.007782140442054949d, (-0.9844545308417082d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.007782140442054949d);

  }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test393"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1.0000000000000873d), (java.lang.Number)0.584554782675576d, false);

  }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test394"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(4.840511699713244E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.840511699713244E43d);

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test395"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(2.5091784786580567d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.509178478658057d);

  }

  public void test396() {}
//   public void test396() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test396"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     double var16 = var0.nextWeibull(1.0d, 1.6298598478788293d);
//     double var19 = var0.nextCauchy((-1.1440883267692863E33d), 3.3030345912774096E43d);
//     var0.reSeedSecure();
//     double var24 = var0.nextUniform(0.0d, 2.4188678176733584E-44d, true);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var27 = var0.nextWeibull((-2.485421078903705E43d), 3.3821920585064405E42d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "7c19d18a4d32a0abcbdcca45558d11a9845db2a14f152cc97919a9ac902689272719318fc201bf3d993dc8dd4f1b9e74813e"+ "'", var2.equals("7c19d18a4d32a0abcbdcca45558d11a9845db2a14f152cc97919a9ac902689272719318fc201bf3d993dc8dd4f1b9e74813e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 4.1307151274391104E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 3.7482848396932003d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 5.1838748217013384E42d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1.8525556812859337E-44d);
// 
//   }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test397"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(61, (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test398"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(1.107148716958077d, 6.722308758188109E59d, 1.025953847986767d, 90);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);

  }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test399"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-9223372036854775808L), 5144L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test400"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.6969136111134943d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test401"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(1.5804317627621424E42d, 0.19842513149602495d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.031004091573076348d);

  }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test402"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(2.622236500484369d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.5717072278537213d));

  }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test403"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(1.3057219004014247d, 0.3324193131412804d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.3324193131412804d);

  }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test404"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.1572992076586297d, 100.97606796324061d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.1572992076586297d);

  }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test405"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    int var4 = var3.start();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setExpansionFactor(50.000008f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);

  }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test406"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)0.5723313665990505d);

  }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test407"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(0L, 31L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 31L);

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test408"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)4.629628685877713E42d);

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test409"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)0.9999999989000916d);

  }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test410"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.contract();
    int var2 = var0.getNumElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setExpansionFactor(102400.01f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test411"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.3841858E-7f);

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test412"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(1612900, 127000);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test413"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(7.450580596923828E-9d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.300371626015253E-10d);

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test414"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    boolean var1 = var0.isSupportUpperBoundInclusive();
    boolean var2 = var0.isSupportLowerBoundInclusive();
    double var3 = var0.getMean();
    double var4 = var0.getSupportUpperBound();
    var0.reseedRandomGenerator(94L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.POSITIVE_INFINITY);

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test415"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2((-1.0087674787522005d), 1.2982587902415216E14d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-7.770157123792972E-15d));

  }

  public void test416() {}
//   public void test416() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test416"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     double var17 = var0.nextBeta(1.1265425086815434E43d, 1.1282937610745374d);
//     long var19 = var0.nextPoisson(31.402066659134473d);
//     long var22 = var0.nextSecureLong(0L, 6L);
//     int var25 = var0.nextInt(0, 2147483647);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var27 = var0.nextHexString((-4));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "86fbbcad8b104b9d4f3dfbf954ec2032b7126c3b6f2c3dfa93e3db57a829d59392292cc229ffe6e5f753112b383bd15958c4"+ "'", var2.equals("86fbbcad8b104b9d4f3dfbf954ec2032b7126c3b6f2c3dfa93e3db57a829d59392292cc229ffe6e5f753112b383bd15958c4"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 4.1626769735708227E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 32L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 6L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 60165221);
// 
//   }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test417"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)4.6310740263131307E86d, (java.lang.Number)1.5d, true);

  }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test418"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution((-4.152257768472053E8d), 2.1317761108019555d, (-1.2332046984549784E42d));

  }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test419"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(0.06895849133460996d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test420"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(4.594468614421035E-44d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test421"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(27000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test422"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, var1, (java.lang.Number)(-90), false);

  }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test423"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(0.8686804224492061d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9821292317769804d);

  }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test424"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1((-0.12829376107453735d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.12040504956944222d));

  }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test425"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd((-5129524049062756352L), 23333L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test426() {}
//   public void test426() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test426"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     long var4 = var0.nextPoisson(1.259921049017114d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var7 = var0.nextGaussian((-0.9844545308417082d), (-0.9366718398504545d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.007940277438495194d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1L);
// 
//   }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test427"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var2.getNanStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test428"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(1.567363659778374E-45d, 44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.7573353102077896E-32d);

  }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test429"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent((-5.705962099694664E43d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 145);

  }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test430"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(50.000004f, 3.2238155921557956d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 50.0f);

  }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test431"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(6.389056068043896d, 0.006699716948569819d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6.389056068043896d);

  }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test432"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(5.0f);
    var0.setElement(110, Double.NaN);
    var0.discardFrontElements(10);
    int var8 = var0.getNumElements();
    int var9 = var0.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 101);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 10);

  }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test433"); }


    org.apache.commons.math3.exception.MathIllegalStateException var0 = new org.apache.commons.math3.exception.MathIllegalStateException();
    org.apache.commons.math3.exception.util.ExceptionContext var1 = var0.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test434"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    var3.reseedRandomGenerator(1L);
    double var7 = var3.probability(0.0d);
    double var8 = var3.getMean();
    double var9 = var3.getSupportUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == Double.POSITIVE_INFINITY);

  }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test435"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(227, 101);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 22927);

  }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test436"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(9.774041714359758E41d, 1.0949470272168769d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.774041714359758E41d);

  }

  public void test437() {}
//   public void test437() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test437"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     var0.reSeed(1L);
//     var0.reSeed();
//     int[] var8 = var0.nextPermutation(1612773, 47);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var0.nextHypergeometric(96, 227, 145);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "a3ba67ef9386907d0e498ecd772efb0b3b6c8ed647ec4be60693e6bc0d3c5982064d83fe132c55c57ec530435c08a12ddc7d"+ "'", var2.equals("a3ba67ef9386907d0e498ecd772efb0b3b6c8ed647ec4be60693e6bc0d3c5982064d83fe132c55c57ec530435c08a12ddc7d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
// 
//   }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test438"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(1612820, 102);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1612922);

  }

  public void test439() {}
//   public void test439() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test439"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)50.000004f);
//     org.apache.commons.math3.exception.MathInternalError var3 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var2);
// 
//   }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test440"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.7853981633974483d));

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test441"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(287, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test442() {}
//   public void test442() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test442"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     double var17 = var0.nextGamma(0.9775852669347048d, 3.199763873047224E14d);
//     double var20 = var0.nextUniform(0.0d, 8.799063409660144E86d);
//     org.apache.commons.math3.distribution.NormalDistribution var24 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var24.reseedRandomGenerator(1L);
//     boolean var27 = var24.isSupportConnected();
//     double var28 = var24.getMean();
//     double var29 = var24.sample();
//     double var30 = var24.getSupportUpperBound();
//     boolean var31 = var24.isSupportUpperBoundInclusive();
//     boolean var32 = var24.isSupportUpperBoundInclusive();
//     double var33 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var24);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("4f728e6622cc084ccd5444f2b997bd676f88e1715b6155232d2db95a6b332c41ea75a909ac1b4dffa9b06cf33caaf19a637f", "80a8f6393075f09c90d5b5857b6b6cd6d6ab6c189537f07d15e6eee0c6db42f7b78b4fd8d7a2817deffb25e73429331d4ddf");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "ac16197232bc2d4ae7cc7c60b608189777f30ae6b8fcd0bf107fc344a267387aa545dd180cb8f4892f59fcb0659951bb6cbc"+ "'", var2.equals("ac16197232bc2d4ae7cc7c60b608189777f30ae6b8fcd0bf107fc344a267387aa545dd180cb8f4892f59fcb0659951bb6cbc"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 2.0238931281602708E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.1662706597765498E15d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 7.150868332029476E86d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 3.5671315446818194E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == (-8.409554725955988E42d));
// 
//   }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test443"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(0, 47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test444"); }


    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.math.BigInteger var4 = null;
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var8 = new org.apache.commons.math3.exception.OutOfRangeException(var2, (java.lang.Number)100.0f, (java.lang.Number)var6, (java.lang.Number)0.5000672346092545d);
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    java.math.BigInteger var11 = null;
    java.math.BigInteger var13 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, 0L);
    org.apache.commons.math3.exception.OutOfRangeException var15 = new org.apache.commons.math3.exception.OutOfRangeException(var9, (java.lang.Number)100.0f, (java.lang.Number)var13, (java.lang.Number)0.5000672346092545d);
    java.math.BigInteger var16 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, var13);
    java.math.BigInteger var18 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, 31L);
    org.apache.commons.math3.exception.OutOfRangeException var19 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)8.799063409660144E86d, (java.lang.Number)0.99999994f, (java.lang.Number)var6);
    org.apache.commons.math3.exception.util.Localizable var20 = null;
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    org.apache.commons.math3.exception.NotPositiveException var23 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(short)1);
    java.lang.Object[] var24 = new java.lang.Object[] { (short)1};
    org.apache.commons.math3.exception.MathIllegalStateException var25 = new org.apache.commons.math3.exception.MathIllegalStateException(var21, var24);
    org.apache.commons.math3.exception.MathIllegalStateException var26 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var19, var20, var24);
    org.apache.commons.math3.exception.util.ExceptionContext var27 = var19.getContext();
    java.lang.Number var28 = var19.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + 8.799063409660144E86d+ "'", var28.equals(8.799063409660144E86d));

  }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test445"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(8.451195606992581E-30d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test446"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(50.000004f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5);

  }

  public void test447() {}
//   public void test447() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test447"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(5.957132015917886E42d, 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test448"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(102, 0.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test449"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(28798L, 20500L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 49298L);

  }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test450"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    var3.reseedRandomGenerator(1L);
    boolean var6 = var3.isSupportConnected();
    double var7 = var3.getMean();
    double var8 = var3.sample();
    double var9 = var3.getSupportUpperBound();
    boolean var10 = var3.isSupportUpperBoundInclusive();
    double var11 = var3.getMean();
    double var12 = var3.sample();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 3.5671315446818194E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1.7552256037579106E43d);

  }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test451"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.addElement(0.02797455810085192d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setContractionCriteria(1.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test452"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test453"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.0d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test454"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    float var3 = var2.getExpansionFactor();
    org.apache.commons.math3.util.ResizableDoubleArray var4 = var2.copy();
    double var6 = var2.substituteMostRecentElement(1.0920559274043928d);
    float var7 = var2.getContractionCriteria();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.5f);

  }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test455"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1.0713813143399866d, (java.lang.Number)1.3057219004014247d, true);
    java.lang.Number var5 = var4.getMax();
    java.lang.Number var6 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1.3057219004014247d+ "'", var5.equals(1.3057219004014247d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 1.3057219004014247d+ "'", var6.equals(1.3057219004014247d));

  }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test456"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint((-2.485421078903705E43d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-2.485421078903705E43d));

  }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test457"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    boolean var1 = var0.isSupportLowerBoundInclusive();
    var0.reseedRandomGenerator((-1L));
    double var5 = var0.probability((-27.741692681648217d));
    double var8 = var0.cumulativeProbability(0.027442916677309914d, 0.6360918665423811d);
    double var10 = var0.probability(2.509178478658057d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.22669496104614656d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);

  }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test458"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.10561069428565839d, (java.lang.Number)1.3119152085309351d, (java.lang.Number)2.155938132423344E43d);

  }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test459"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(6L, 5144L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test460"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(90, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test461"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(0.99999994f, 2.3841858E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.99999994f);

  }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test462"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(1.3057219004014247d, 2.2682182275901375d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.1644372693914552d);

  }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test463"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(768793337, 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2);

  }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test464"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(287, 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5);

  }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test465"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(862L, 29L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 891L);

  }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test466"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0.9999999985516554d, (java.lang.Number)1.188156673789677E14d, (java.lang.Number)0);
    java.lang.Number var5 = var4.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.9999999985516554d+ "'", var5.equals(0.9999999985516554d));

  }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test467"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(0.5992832608839995d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 17.630573099254168d);

  }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test468"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
    var3.reseedRandomGenerator(1L);
    double var7 = var3.probability(0.0d);
    double var8 = var3.getMean();
    double var9 = var3.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);

  }

  public void test469() {}
//   public void test469() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test469"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     long var16 = var0.nextLong((-92L), 900L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var19 = var0.nextBinomial(0, 1.2539861847696195E14d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "fbdd3f8612677817fcafabbcabec320da2f9ec371a39e2165148f35130767c5ac8cfdf40bb1194096cb4bc168c6b2b7c20f1"+ "'", var2.equals("fbdd3f8612677817fcafabbcabec320da2f9ec371a39e2165148f35130767c5ac8cfdf40bb1194096cb4bc168c6b2b7c20f1"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-4.542348008552381E42d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 817L);
// 
//   }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test470"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(20500L, 3L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test471"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(6.109911595445588E43d, 11.712762449867773d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test472"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.TiesStrategy var3 = var2.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = var2.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var2.getTiesStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test473"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("bae1bc98575361bfe957fdbaba13a9143a0abb4dd59a3e50fc0d0bde01fba220e2a06e867ac7d70e4e2a8916aab06392eba6");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test474"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter((-0.12040504956944222d), 7.22597376812575E86d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.1204050495694422d));

  }

  public void test475() {}
//   public void test475() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test475"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     var0.reSeed();
//     double var17 = var0.nextGamma(0.9775852669347048d, 3.199763873047224E14d);
//     double var20 = var0.nextF(2.636818730233018d, 1.1282937610745374d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("93042192d2", "1f617ba4c318587fa5b51933e8f6ad7e0176ac65f788a7d26f04d08ea791fadc2e2e03b1175f6dfcd63f51e7315bd7bac0c8");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "c257307a20086193631e3f0abb43c46ba611e21c8d8073d347eea56fe3c78b58d980f119d3bd6ede0388932ca0ab45595a86"+ "'", var2.equals("c257307a20086193631e3f0abb43c46ba611e21c8d8073d347eea56fe3c78b58d980f119d3bd6ede0388932ca0ab45595a86"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-3.206139794820229E43d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 4.858315848379206E13d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 3.542796911453528d);
// 
//   }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test476"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(10L, 27000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10L);

  }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test477"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(5, 47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 47);

  }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test478"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(478245873, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 478245873);

  }

  public void test479() {}
//   public void test479() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test479"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     double var16 = var0.nextWeibull(1.0d, 1.6298598478788293d);
//     double var19 = var0.nextWeibull(1.151569395337692d, 7.22597376812575E86d);
//     double var22 = var0.nextGaussian(1.9999999958199324d, 1.021295736467202d);
//     double var26 = var0.nextUniform((-5.329951075180856E43d), 0.0d, true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "5f3c0a4ab7a774591336d4a4ea13c5228e4df3601b00dbeb5b2bb078abf150ef98ad09a63159bc1658958140024898ee9c55"+ "'", var2.equals("5f3c0a4ab7a774591336d4a4ea13c5228e4df3601b00dbeb5b2bb078abf150ef98ad09a63159bc1658958140024898ee9c55"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-5.376974961543461E42d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.35364893135754055d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1.3662466260540767E86d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1.7151785181287122d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == (-4.572950009664635E43d));
// 
//   }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test480"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(0.9542512052939294d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.762135834279852d);

  }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test481"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-0.4217216060310984d), (java.lang.Number)(-2.485421078903705E43d), false);

  }

  public void test482() {}
//   public void test482() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test482"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.0d);
//     java.lang.String var4 = var0.nextHexString(110);
//     double var6 = var0.nextChiSquare(0.9865330122406505d);
//     var0.reSeedSecure(28798L);
//     org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var12.reseedRandomGenerator(1L);
//     boolean var15 = var12.isSupportConnected();
//     double var16 = var12.getMean();
//     double var17 = var12.sample();
//     double var18 = var12.getSupportUpperBound();
//     boolean var19 = var12.isSupportUpperBoundInclusive();
//     double var20 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var12);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var23 = var0.nextPermutation(70, 12827000);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.504531515605875d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "50b4bb33c821d208a0897d3ea466165eaba398f4b6c90add2eb313969a8af7dd3c51b5dd36593b6ccb854a22cbc999b5e9ee7fa6aae86a"+ "'", var4.equals("50b4bb33c821d208a0897d3ea466165eaba398f4b6c90add2eb313969a8af7dd3c51b5dd36593b6ccb854a22cbc999b5e9ee7fa6aae86a"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.03919872745513547d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 3.5671315446818194E43d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 2.917036264668873E43d);
// 
//   }

  public void test483() {}
//   public void test483() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test483"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log10((-3.4611764310781617E43d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test484"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(Double.NEGATIVE_INFINITY, 1.177802006337712d, 1.8246532949072747d);

  }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test485"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(2.3841858E-7f, (-4.152257768472053E8d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.3841856E-7f);

  }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test486"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint((-5.329951075180856E43d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-5.329951075180856E43d));

  }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test487"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(9.332621544395286E157d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7760228659329313d);

  }

  public void test488() {}
//   public void test488() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test488"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     double var4 = var0.nextExponential(0.056182176564052d);
//     var0.reSeedSecure();
//     var0.reSeedSecure((-2L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "c3a7bb701cf47b85e5c2a6abcb95c6159c105b27e4e9c5f208101c11c89d592154d85a0364578f5a06a3c19e3f8fef6acb7f"+ "'", var2.equals("c3a7bb701cf47b85e5c2a6abcb95c6159c105b27e4e9c5f208101c11c89d592154d85a0364578f5a06a3c19e3f8fef6acb7f"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.01266092703436589d);
// 
//   }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test489"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(2.1982960988904782E43d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.1982960988904782E43d);

  }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test490"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(891L, (-27000L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 27L);

  }

  public void test491() {}
//   public void test491() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test491"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(100);
//     org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 2.6881171418161356E43d, 1.0d);
//     var6.reseedRandomGenerator(1L);
//     double var10 = var6.cumulativeProbability(0.0d);
//     double var12 = var6.cumulativeProbability(1.0d);
//     double var13 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var6);
//     double var16 = var0.nextWeibull(1.0d, 1.6298598478788293d);
//     double var19 = var0.nextCauchy((-1.1440883267692863E33d), 3.3030345912774096E43d);
//     var0.reSeedSecure();
//     double var24 = var0.nextUniform(0.0d, 2.4188678176733584E-44d, true);
//     double var28 = var0.nextUniform((-1.1980127630095007E43d), 1.2038021664515672d, true);
//     double var31 = var0.nextUniform(0.0d, 1.3872175661331396d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "3b3aa476017dd76f3b17e2c04a1a93f42e640ad2097791272e8699c0598ed868b6fbda5904b801599e4378d8fc45029a99ef"+ "'", var2.equals("3b3aa476017dd76f3b17e2c04a1a93f42e640ad2097791272e8699c0598ed868b6fbda5904b801599e4378d8fc45029a99ef"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-5.2432435475000995E42d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.46474439745601875d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1.1585384597896089E44d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 2.1347061858261838E-44d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == (-3.1199010195518257E42d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 0.3284090290722705d);
// 
//   }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test492"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    java.lang.String var2 = var1.name();
    java.lang.String var3 = var1.toString();
    java.lang.Class var4 = var1.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var6 = java.lang.Enum.<java.lang.Enum>valueOf(var4, "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "MAXIMAL"+ "'", var2.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "MAXIMAL"+ "'", var3.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test493() {}
//   public void test493() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test493"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(4.5194037630894135d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test494"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(100, 1612775);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100);

  }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test495"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.584554782675576d, 11.551986904995205d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.5845547826755761d);

  }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test496"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma((-0.8813735870195429d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 73.74865724833803d);

  }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test497"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var2.setContractionCriteria(50.000008f);
    var2.setExpansionMode(0);
    var2.setContractionCriteria(5.0f);
    int var9 = var2.start();
    org.apache.commons.math3.util.ResizableDoubleArray var10 = var2.copy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test498"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(short)100, (java.lang.Number)2.0000005f, false);

  }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test499"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-90), 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 8100);

  }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test500"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    boolean var1 = var0.isSupportUpperBoundInclusive();
    boolean var2 = var0.isSupportLowerBoundInclusive();
    double var4 = var0.density(1.567363659778374E-45d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.3989422804014327d);

  }

}
