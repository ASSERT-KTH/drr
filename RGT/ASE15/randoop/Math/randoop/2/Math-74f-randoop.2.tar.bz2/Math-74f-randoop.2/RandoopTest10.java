
import junit.framework.*;

public class RandoopTest10 extends TestCase {

  public static boolean debug = false;

  public void test1() {}
//   public void test1() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test1"); }
// 
// 
//     double[] var5 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var7 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var5, false);
//     double var8 = var7.getCurrentTime();
//     double[] var9 = var7.getInterpolatedState();
//     double[] var10 = var7.getInterpolatedDerivatives();
//     double[] var13 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var15 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var13, false);
//     double var16 = var15.getCurrentTime();
//     double[] var17 = var15.getInterpolatedState();
//     double[] var18 = var15.getInterpolatedDerivatives();
//     org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var19 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, Double.NaN, 1.0E-15d, var10, var18);
//     double var20 = var19.getCurrentStepStart();
//     int var21 = var19.getMaxEvaluations();
//     var19.setSafety(1.0E-6d);
//     var19.setMaxEvaluations(8);
//     double[] var31 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var33 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var31, false);
//     double[][] var34 = new double[][] { var31};
//     org.apache.commons.math.linear.BlockRealMatrix var35 = new org.apache.commons.math.linear.BlockRealMatrix(var34);
//     org.apache.commons.math.MaxIterationsExceededException var36 = new org.apache.commons.math.MaxIterationsExceededException(0, "", (java.lang.Object[])var34);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var38 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var34, false);
//     java.util.NoSuchElementException var39 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("org.apache.commons.math.MathRuntimeException: hi!", (java.lang.Object[])var34);
//     double[][] var40 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var34);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var41 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var40);
//     double[] var47 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var49 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var47, false);
//     double var50 = var49.getCurrentTime();
//     double[] var51 = var49.getInterpolatedState();
//     double[] var52 = var49.getInterpolatedDerivatives();
//     double[] var55 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var57 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var55, false);
//     double var58 = var57.getCurrentTime();
//     double[] var59 = var57.getInterpolatedState();
//     double[] var60 = var57.getInterpolatedDerivatives();
//     org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var61 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, Double.NaN, 1.0E-15d, var52, var60);
//     double var62 = var61.getCurrentStepStart();
//     double[] var65 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var67 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var65, false);
//     double var68 = var67.getCurrentTime();
//     double[] var69 = var67.getInterpolatedState();
//     org.apache.commons.math.linear.BigMatrix var70 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(var69);
//     double[][] var71 = new double[][] { var69};
//     org.apache.commons.math.linear.RealMatrix var72 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(var71);
//     org.apache.commons.math.linear.BlockRealMatrix var73 = new org.apache.commons.math.linear.BlockRealMatrix(var71);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var74 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var71);
//     double[][] var75 = var74.getDataRef();
//     org.apache.commons.math.linear.Array2DRowRealMatrix var76 = var61.updateHighOrderDerivativesPhase1(var74);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var77 = var41.add(var76);
//     double[] var80 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var82 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var80, false);
//     double[][] var83 = new double[][] { var80};
//     org.apache.commons.math.linear.BlockRealMatrix var84 = new org.apache.commons.math.linear.BlockRealMatrix(var83);
//     org.apache.commons.math.linear.BlockRealMatrix var85 = var84.transpose();
//     org.apache.commons.math.linear.BlockRealMatrix var86 = var84.transpose();
//     org.apache.commons.math.linear.RealMatrix var87 = var41.subtract((org.apache.commons.math.linear.RealMatrix)var84);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var88 = var19.updateHighOrderDerivativesPhase1(var41);
//     double[][] var89 = var88.getDataRef();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var62 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var68 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var70);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var71);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var72);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var75);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var83);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var85);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var86);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var87);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var88);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var89);
// 
//   }

  public void test2() {}
//   public void test2() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test2"); }
// 
// 
//     org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var0 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator();
//     double[] var3 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var5 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var3, false);
//     double[][] var6 = new double[][] { var3};
//     org.apache.commons.math.linear.BlockRealMatrix var7 = new org.apache.commons.math.linear.BlockRealMatrix(var6);
//     double[] var10 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var12 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var10, false);
//     double[] var13 = var12.getInterpolatedState();
//     double[] var14 = var7.operate(var13);
//     var0.reinitialize(var14, true);
//     org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var17 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator(var0);
//     org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var18 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator(var0);
//     boolean var19 = var0.isForward();
//     boolean var20 = var0.isForward();
//     double var21 = var0.getCurrentTime();
//     var0.storeTime(0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == Double.NaN);
// 
//   }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test3"); }


    double[] var2 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var4 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var2, false);
    double[][] var5 = new double[][] { var2};
    org.apache.commons.math.linear.BlockRealMatrix var6 = new org.apache.commons.math.linear.BlockRealMatrix(var5);
    org.apache.commons.math.linear.BlockRealMatrix var7 = var6.transpose();
    org.apache.commons.math.linear.RealMatrix var9 = var7.scalarMultiply(10.0d);
    org.apache.commons.math.linear.BlockRealMatrix var10 = var7.copy();
    org.apache.commons.math.linear.BlockRealMatrix var12 = var10.getRowMatrix(0);
    org.apache.commons.math.linear.BlockRealMatrix var13 = var12.copy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math.linear.RealVector var15 = var12.getRowVector(100);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test4"); }


    org.apache.commons.math.fraction.BigFractionField var0 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var1 = var0.getZero();
    org.apache.commons.math.linear.Array2DRowFieldMatrix var2 = new org.apache.commons.math.linear.Array2DRowFieldMatrix((org.apache.commons.math.Field)var0);
    int var3 = var2.getRowDimension();
    org.apache.commons.math.FieldElement var4 = var2.getTrace();
    int var5 = var2.getColumnDimension();
    org.apache.commons.math.FieldElement[][] var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSubMatrix(var6, 10, 10);
      fail("Expected exception of type Exception");
    } catch (Exception e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);

  }

  public void test5() {}
//   public void test5() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test5"); }
// 
// 
//     org.apache.commons.math.ode.events.CombinedEventsManager var0 = new org.apache.commons.math.ode.events.CombinedEventsManager();
//     java.util.Collection var1 = var0.getEventsHandlers();
//     boolean var2 = var0.isEmpty();
//     org.apache.commons.math.ode.events.CombinedEventsManager var3 = new org.apache.commons.math.ode.events.CombinedEventsManager();
//     double[] var7 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var9 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var7, false);
//     double[][] var10 = new double[][] { var7};
//     org.apache.commons.math.linear.BlockRealMatrix var11 = new org.apache.commons.math.linear.BlockRealMatrix(var10);
//     double[] var14 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var16 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var14, false);
//     double[] var17 = var16.getInterpolatedState();
//     double[] var18 = var11.operate(var17);
//     boolean var19 = var3.reset(1.0E-6d, var18);
//     boolean var20 = var3.stop();
//     double[] var23 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var25 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var23, false);
//     double var26 = var25.getCurrentTime();
//     double[] var27 = var25.getInterpolatedState();
//     double[] var28 = var25.getInterpolatedDerivatives();
//     boolean var29 = var3.evaluateStep((org.apache.commons.math.ode.sampling.StepInterpolator)var25);
//     boolean var30 = var0.evaluateStep((org.apache.commons.math.ode.sampling.StepInterpolator)var25);
//     var25.finalizeStep();
//     double[] var32 = var25.getInterpolatedDerivatives();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
// 
//   }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test6"); }


    double[] var2 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var4 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var2, false);
    double[][] var5 = new double[][] { var2};
    org.apache.commons.math.linear.BlockRealMatrix var6 = new org.apache.commons.math.linear.BlockRealMatrix(var5);
    boolean var7 = var6.isSquare();
    double[][] var8 = var6.getData();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setEntry((-1000), (-10), 1.0d);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test7() {}
//   public void test7() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test7"); }
// 
// 
//     double[] var2 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var4 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var2, false);
//     double var5 = var4.getCurrentTime();
//     double[] var6 = var4.getInterpolatedState();
//     org.apache.commons.math.linear.BigMatrix var7 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(var6);
//     double[][] var8 = new double[][] { var6};
//     org.apache.commons.math.linear.RealMatrix var9 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(var8);
//     org.apache.commons.math.linear.BlockRealMatrix var10 = new org.apache.commons.math.linear.BlockRealMatrix(var8);
//     org.apache.commons.math.linear.BlockRealMatrix var13 = var10.createMatrix(2, 8);
//     org.apache.commons.math.linear.BlockRealMatrix var14 = var13.transpose();
//     double[] var16 = var13.getRow(0);
//     org.apache.commons.math.linear.RealMatrixPreservingVisitor var17 = null;
//     double var18 = var13.walkInOptimizedOrder(var17);
// 
//   }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test8"); }


    org.apache.commons.math.fraction.BigFractionField var2 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var3 = var2.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var4 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var3);
    org.apache.commons.math.FieldElement[] var5 = new org.apache.commons.math.FieldElement[] { var3};
    org.apache.commons.math.linear.FieldMatrix var6 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createColumnFieldMatrix(var5);
    org.apache.commons.math.linear.FieldMatrix var7 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createRowFieldMatrix(var5);
    java.lang.IllegalStateException var8 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("0", (java.lang.Object[])var5);
    java.util.NoSuchElementException var9 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("-10", (java.lang.Object[])var5);
    org.apache.commons.math.ode.events.EventException var10 = new org.apache.commons.math.ode.events.EventException((java.lang.Throwable)var9);
    java.lang.String var11 = var10.getPattern();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + ""+ "'", var11.equals(""));

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test9"); }


    org.apache.commons.math.fraction.BigFractionField var0 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var1 = var0.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var2 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var1);
    org.apache.commons.math.fraction.BigFraction var4 = var1.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var6 = var1.pow(2147483647);
    org.apache.commons.math.fraction.BigFraction var8 = var6.pow(0L);
    org.apache.commons.math.fraction.BigFraction var10 = var6.divide(1);
    java.math.BigInteger var11 = var6.getNumerator();
    org.apache.commons.math.fraction.BigFractionField var12 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var13 = var12.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var14 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var13);
    org.apache.commons.math.fraction.BigFraction var16 = var13.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var18 = var13.pow(2147483647);
    org.apache.commons.math.fraction.BigFraction var20 = var18.pow(0L);
    org.apache.commons.math.fraction.BigFraction var22 = var18.divide(1);
    org.apache.commons.math.fraction.BigFraction var23 = var6.multiply(var22);
    org.apache.commons.math.fraction.BigFractionField var24 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var25 = var24.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var26 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var25);
    org.apache.commons.math.fraction.BigFraction var28 = var25.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var30 = var25.subtract(10L);
    double var31 = var30.percentageValue();
    org.apache.commons.math.fraction.BigFraction var33 = var30.multiply(1);
    org.apache.commons.math.fraction.BigFraction var35 = var33.multiply((-1L));
    java.math.BigInteger var36 = var33.getDenominator();
    org.apache.commons.math.fraction.BigFraction var37 = var6.add(var36);
    org.apache.commons.math.fraction.BigFraction var39 = var37.subtract(2147483647);
    java.math.BigInteger var40 = var39.getDenominator();
    org.apache.commons.math.fraction.BigFraction var41 = var39.reciprocal();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == (-1000.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test10"); }


    org.apache.commons.math.fraction.BigFractionField var0 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var1 = var0.getZero();
    org.apache.commons.math.fraction.BigFraction var2 = var0.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var5 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var0, 10, 10);
    int var6 = var5.getRowDimension();
    org.apache.commons.math.fraction.BigFractionField var7 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var8 = var7.getZero();
    org.apache.commons.math.fraction.BigFraction var9 = var7.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var12 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var7, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var13 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var14 = var13.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var15 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var14);
    var15.start(2147483647, 0, 100, (-10), 100, 0);
    org.apache.commons.math.FieldElement var23 = var12.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var15);
    org.apache.commons.math.FieldElement var26 = null;
    var15.visit(100, (-1), var26);
    org.apache.commons.math.FieldElement var28 = var5.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var15);
    int var29 = var5.getColumnDimension();
    java.lang.String var30 = var5.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + "BlockFieldMatrix{{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0}}"+ "'", var30.equals("BlockFieldMatrix{{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0}}"));

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test11"); }


    org.apache.commons.math.fraction.BigFractionField var0 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var1 = var0.getZero();
    org.apache.commons.math.fraction.BigFraction var2 = var0.getOne();
    org.apache.commons.math.fraction.BigFraction var3 = var2.abs();
    org.apache.commons.math.fraction.BigFraction var5 = var3.add(100L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test12() {}
//   public void test12() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test12"); }
// 
// 
//     double[] var5 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var7 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var5, false);
//     double var8 = var7.getCurrentTime();
//     double[] var9 = var7.getInterpolatedState();
//     double[] var10 = var7.getInterpolatedDerivatives();
//     double[] var13 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var15 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var13, false);
//     double var16 = var15.getCurrentTime();
//     double[] var17 = var15.getInterpolatedState();
//     double[] var18 = var15.getInterpolatedDerivatives();
//     org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var19 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, Double.NaN, 1.0E-15d, var10, var18);
//     var19.setMinReduction(0.0d);
//     var19.setSafety(1.0d);
//     double var24 = var19.getMaxGrowth();
//     org.apache.commons.math.ode.ODEIntegrator var25 = var19.getStarterIntegrator();
//     double[] var28 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var30 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var28, false);
//     double var31 = var30.getCurrentTime();
//     double[] var32 = var30.getInterpolatedState();
//     org.apache.commons.math.linear.BigMatrix var33 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(var32);
//     double[][] var34 = new double[][] { var32};
//     org.apache.commons.math.linear.RealMatrix var35 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(var34);
//     org.apache.commons.math.linear.BlockRealMatrix var36 = new org.apache.commons.math.linear.BlockRealMatrix(var34);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var37 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var34);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var38 = var19.updateHighOrderDerivativesPhase1(var37);
//     int var39 = var19.getMaxEvaluations();
//     double[] var44 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var46 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var44, false);
//     double[][] var47 = new double[][] { var44};
//     org.apache.commons.math.linear.BlockRealMatrix var48 = new org.apache.commons.math.linear.BlockRealMatrix(var47);
//     org.apache.commons.math.MaxIterationsExceededException var49 = new org.apache.commons.math.MaxIterationsExceededException(0, "", (java.lang.Object[])var47);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var51 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var47, false);
//     boolean var52 = var51.isSquare();
//     org.apache.commons.math.linear.Array2DRowRealMatrix var53 = var19.updateHighOrderDerivativesPhase1(var51);
//     double[] var54 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double[] var55 = var53.solve(var54);
//       fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException");
//     } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1.4142135623730951d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
// 
//   }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test13"); }


    org.apache.commons.math.fraction.BigFraction var1 = new org.apache.commons.math.fraction.BigFraction(0);
    org.apache.commons.math.fraction.BigFraction var3 = var1.subtract((-11));
    long var4 = var1.longValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0L);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test14"); }


    org.apache.commons.math.fraction.FractionConversionException var2 = new org.apache.commons.math.fraction.FractionConversionException(1.0d, 2147483646);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test15"); }


    org.apache.commons.math.fraction.BigFractionField var0 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var1 = var0.getZero();
    org.apache.commons.math.fraction.BigFraction var2 = var0.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var5 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var0, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var6 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var7 = var6.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var8 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var7);
    var8.start(2147483647, 0, 100, (-10), 100, 0);
    org.apache.commons.math.FieldElement var16 = var5.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var8);
    org.apache.commons.math.linear.FieldVector var18 = var5.getColumnVector(1);
    org.apache.commons.math.fraction.BigFractionField var19 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var20 = var19.getZero();
    org.apache.commons.math.fraction.BigFraction var21 = var19.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var24 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var19, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var25 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var26 = var25.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var27 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var26);
    var27.start(2147483647, 0, 100, (-10), 100, 0);
    org.apache.commons.math.FieldElement var35 = var24.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var27);
    org.apache.commons.math.fraction.BigFractionField var38 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var39 = var38.getZero();
    org.apache.commons.math.fraction.BigFraction var40 = var38.getOne();
    org.apache.commons.math.fraction.BigFraction var42 = var40.pow(100);
    var24.setEntry(10, (-1), (org.apache.commons.math.FieldElement)var42);
    org.apache.commons.math.fraction.BigFractionField var44 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var45 = var44.getZero();
    org.apache.commons.math.fraction.BigFraction var46 = var44.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var49 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var44, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var50 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var51 = var50.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var52 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var51);
    var52.start(2147483647, 0, 100, (-10), 100, 0);
    org.apache.commons.math.FieldElement var60 = var49.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var52);
    int var61 = var49.getColumnDimension();
    java.lang.String var62 = var49.toString();
    boolean var63 = var24.equals((java.lang.Object)var62);
    org.apache.commons.math.fraction.BigFraction var66 = new org.apache.commons.math.fraction.BigFraction(2147483647, 1);
    org.apache.commons.math.fraction.BigFraction var67 = var66.reduce();
    org.apache.commons.math.linear.FieldMatrix var68 = var24.scalarAdd((org.apache.commons.math.FieldElement)var67);
    org.apache.commons.math.FieldElement[][] var69 = var24.getData();
    org.apache.commons.math.FieldElement[][] var70 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var69);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var71 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var69);
    org.apache.commons.math.linear.FieldMatrix var72 = var5.add((org.apache.commons.math.linear.FieldMatrix)var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var62 + "' != '" + "BlockFieldMatrix{{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0}}"+ "'", var62.equals("BlockFieldMatrix{{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);

  }

  public void test16() {}
//   public void test16() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test16"); }
// 
// 
//     org.apache.commons.math.ode.events.CombinedEventsManager var0 = new org.apache.commons.math.ode.events.CombinedEventsManager();
//     org.apache.commons.math.ode.events.EventHandler var1 = null;
//     var0.addEventHandler(var1, 0.0d, Double.POSITIVE_INFINITY, 0);
//     java.util.Collection var6 = var0.getEventsStates();
//     org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var8 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator();
//     double[] var11 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var13 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var11, false);
//     double[][] var14 = new double[][] { var11};
//     org.apache.commons.math.linear.BlockRealMatrix var15 = new org.apache.commons.math.linear.BlockRealMatrix(var14);
//     double[] var18 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var20 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var18, false);
//     double[] var21 = var20.getInterpolatedState();
//     double[] var22 = var15.operate(var21);
//     var8.reinitialize(var22, true);
//     double[] var27 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var29 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var27, false);
//     double var30 = var29.getCurrentTime();
//     double[] var31 = var29.getInterpolatedState();
//     org.apache.commons.math.linear.BigMatrix var32 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(var31);
//     var8.reinitialize(var31, true);
//     boolean var35 = var0.reset(Double.NaN, var31);
//     org.apache.commons.math.FunctionEvaluationException var36 = new org.apache.commons.math.FunctionEvaluationException(var31);
//     double[] var37 = var36.getArgument();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
// 
//   }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test17"); }


    java.lang.Object[] var4 = new java.lang.Object[] { 0L};
    org.apache.commons.math.MaxEvaluationsExceededException var5 = new org.apache.commons.math.MaxEvaluationsExceededException(100, "", var4);
    org.apache.commons.math.MathException var6 = new org.apache.commons.math.MathException("matrix is singular", var4);
    org.apache.commons.math.MathRuntimeException var7 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable)var6);
    java.lang.Object[] var13 = new java.lang.Object[] { 0L};
    java.text.ParseException var14 = org.apache.commons.math.MathRuntimeException.createParseException((-1), "", var13);
    org.apache.commons.math.ode.events.EventException var15 = new org.apache.commons.math.ode.events.EventException("", var13);
    java.lang.Object[] var16 = var15.getArguments();
    org.apache.commons.math.ConvergenceException var17 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable)var7, "2147483647", var16);
    double[] var20 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var22 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var20, false);
    org.apache.commons.math.FunctionEvaluationException var23 = new org.apache.commons.math.FunctionEvaluationException(var20);
    org.apache.commons.math.fraction.FractionConversionException var26 = new org.apache.commons.math.fraction.FractionConversionException(0.0d, (-1));
    java.lang.Object[] var32 = new java.lang.Object[] { 0L};
    java.text.ParseException var33 = org.apache.commons.math.MathRuntimeException.createParseException((-1), "", var32);
    org.apache.commons.math.FunctionEvaluationException var34 = new org.apache.commons.math.FunctionEvaluationException(100.0d, "", var32);
    double[] var35 = var34.getArgument();
    org.apache.commons.math.FunctionEvaluationException var36 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable)var26, var35);
    org.apache.commons.math.FunctionEvaluationException var37 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable)var23, var35);
    var7.addSuppressed((java.lang.Throwable)var37);
    java.lang.Object[] var46 = new java.lang.Object[] { 0.0d};
    java.util.NoSuchElementException var47 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", var46);
    java.lang.IllegalArgumentException var48 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("", var46);
    org.apache.commons.math.MathRuntimeException var49 = new org.apache.commons.math.MathRuntimeException("", var46);
    org.apache.commons.math.linear.InvalidMatrixException var50 = new org.apache.commons.math.linear.InvalidMatrixException((java.lang.Throwable)var49);
    java.lang.Object[] var51 = var50.getArguments();
    java.lang.String var52 = var50.getPattern();
    java.lang.Throwable[] var53 = var50.getSuppressed();
    org.apache.commons.math.ode.DerivativeException var54 = new org.apache.commons.math.ode.DerivativeException("Array2DRowRealMatrix{{0.0},{0.0}}", (java.lang.Object[])var53);
    org.apache.commons.math.FunctionEvaluationException var55 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable)var37, 9.0d, "BlockRealMatrix{{0.2}}", (java.lang.Object[])var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var52 + "' != '" + ""+ "'", var52.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test18"); }


    org.apache.commons.math.fraction.BigFractionField var0 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var1 = var0.getZero();
    org.apache.commons.math.fraction.BigFraction var2 = var0.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var5 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var0, 10, 10);
    org.apache.commons.math.linear.FieldMatrix var6 = var5.transpose();
    org.apache.commons.math.fraction.BigFractionField var7 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var8 = var7.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var9 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var8);
    org.apache.commons.math.fraction.BigFraction var11 = var8.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var13 = var8.pow(2147483647);
    org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor var14 = new org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor((org.apache.commons.math.FieldElement)var13);
    org.apache.commons.math.FieldElement var15 = var5.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixChangingVisitor)var14);
    org.apache.commons.math.linear.FieldLUDecompositionImpl var16 = new org.apache.commons.math.linear.FieldLUDecompositionImpl((org.apache.commons.math.linear.FieldMatrix)var5);
    org.apache.commons.math.linear.FieldDecompositionSolver var17 = var16.getSolver();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test19() {}
//   public void test19() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test19"); }
// 
// 
//     double[] var2 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var4 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var2, false);
//     double[][] var5 = new double[][] { var2};
//     org.apache.commons.math.linear.BlockRealMatrix var6 = new org.apache.commons.math.linear.BlockRealMatrix(var5);
//     org.apache.commons.math.linear.RealMatrix var8 = var6.scalarAdd(1.4142135623730951d);
//     double[] var11 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var13 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var11, false);
//     double var14 = var13.getCurrentTime();
//     double[] var15 = var13.getInterpolatedState();
//     org.apache.commons.math.linear.BigMatrix var16 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(var15);
//     double[][] var17 = new double[][] { var15};
//     org.apache.commons.math.linear.RealMatrix var18 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(var17);
//     org.apache.commons.math.linear.BlockRealMatrix var19 = new org.apache.commons.math.linear.BlockRealMatrix(var17);
//     org.apache.commons.math.linear.BlockRealMatrix var22 = var19.createMatrix(2, 8);
//     org.apache.commons.math.linear.BlockRealMatrix var23 = var6.multiply((org.apache.commons.math.linear.RealMatrix)var22);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.apache.commons.math.linear.RealVector var25 = var22.getColumnVector(11);
//       fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
//     } catch (org.apache.commons.math.linear.MatrixIndexException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
// 
//   }

  public void test20() {}
//   public void test20() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test20"); }
// 
// 
//     double[] var2 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var4 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var2, false);
//     double var5 = var4.getCurrentTime();
//     double[] var6 = var4.getInterpolatedState();
//     org.apache.commons.math.linear.BigMatrix var7 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(var6);
//     double[][] var8 = new double[][] { var6};
//     org.apache.commons.math.linear.RealMatrix var9 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(var8);
//     org.apache.commons.math.linear.BlockRealMatrix var10 = new org.apache.commons.math.linear.BlockRealMatrix(var8);
//     org.apache.commons.math.linear.BlockRealMatrix var12 = var10.scalarAdd(10.0d);
//     org.apache.commons.math.linear.RealMatrix var14 = var10.scalarMultiply(1.0d);
//     org.apache.commons.math.linear.RealVector var16 = var10.getColumnVector(1);
//     double var17 = var10.getFrobeniusNorm();
//     org.apache.commons.math.linear.RealMatrixChangingVisitor var18 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var23 = var10.walkInOptimizedOrder(var18, 2, 8, 0, 100);
//       fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
//     } catch (org.apache.commons.math.linear.MatrixIndexException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.0d);
// 
//   }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test21"); }


    org.apache.commons.math.fraction.BigFractionField var1 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var2 = var1.getZero();
    org.apache.commons.math.fraction.BigFraction var3 = var1.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var6 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var1, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var7 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var8 = var7.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var9 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var8);
    var9.start(2147483647, 0, 100, (-10), 100, 0);
    org.apache.commons.math.FieldElement var17 = var6.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var9);
    org.apache.commons.math.fraction.BigFractionField var20 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var21 = var20.getZero();
    org.apache.commons.math.fraction.BigFraction var22 = var20.getOne();
    org.apache.commons.math.fraction.BigFraction var24 = var22.pow(100);
    var6.setEntry(10, (-1), (org.apache.commons.math.FieldElement)var24);
    org.apache.commons.math.fraction.BigFractionField var26 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var27 = var26.getZero();
    org.apache.commons.math.fraction.BigFraction var28 = var26.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var31 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var26, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var32 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var33 = var32.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var34 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var33);
    var34.start(2147483647, 0, 100, (-10), 100, 0);
    org.apache.commons.math.FieldElement var42 = var31.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var34);
    int var43 = var31.getColumnDimension();
    java.lang.String var44 = var31.toString();
    boolean var45 = var6.equals((java.lang.Object)var44);
    org.apache.commons.math.fraction.BigFraction var48 = new org.apache.commons.math.fraction.BigFraction(2147483647, 1);
    org.apache.commons.math.fraction.BigFraction var49 = var48.reduce();
    org.apache.commons.math.linear.FieldMatrix var50 = var6.scalarAdd((org.apache.commons.math.FieldElement)var49);
    org.apache.commons.math.FieldElement[][] var51 = var6.getData();
    org.apache.commons.math.FieldElement[][] var52 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var51);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var53 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var51);
    org.apache.commons.math.linear.FieldMatrix var54 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldMatrix(var51);
    org.apache.commons.math.linear.BlockFieldMatrix var55 = new org.apache.commons.math.linear.BlockFieldMatrix(var51);
    org.apache.commons.math.linear.BlockFieldMatrix var56 = new org.apache.commons.math.linear.BlockFieldMatrix(var51);
    org.apache.commons.math.MathRuntimeException var57 = new org.apache.commons.math.MathRuntimeException("org.apache.commons.math.linear.InvalidMatrixException: ", (java.lang.Object[])var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var44 + "' != '" + "BlockFieldMatrix{{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0}}"+ "'", var44.equals("BlockFieldMatrix{{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test22"); }


    org.apache.commons.math.analysis.solvers.BrentSolver var0 = new org.apache.commons.math.analysis.solvers.BrentSolver();
    var0.setRelativeAccuracy(100.0d);
    double var3 = var0.getRelativeAccuracy();
    var0.resetMaximalIterationCount();
    double var5 = var0.getFunctionValueAccuracy();
    var0.resetRelativeAccuracy();
    var0.resetRelativeAccuracy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var0.solve(0.0d, (-10.0d));
      fail("Expected exception of type Exception");
    } catch (Exception e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0E-15d);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test23"); }


    org.apache.commons.math.analysis.solvers.BrentSolver var0 = new org.apache.commons.math.analysis.solvers.BrentSolver();
    var0.setRelativeAccuracy(100.0d);
    double var3 = var0.getRelativeAccuracy();
    var0.resetMaximalIterationCount();
    double var5 = var0.getFunctionValueAccuracy();
    var0.resetMaximalIterationCount();
    var0.resetAbsoluteAccuracy();
    var0.resetRelativeAccuracy();
    var0.resetFunctionValueAccuracy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var0.getFunctionValue();
      fail("Expected exception of type Exception");
    } catch (Exception e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0E-15d);

  }

  public void test24() {}
//   public void test24() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test24"); }
// 
// 
//     double[] var2 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var4 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var2, false);
//     double var5 = var4.getCurrentTime();
//     double[] var6 = var4.getInterpolatedState();
//     org.apache.commons.math.linear.BigMatrix var7 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(var6);
//     double[][] var8 = new double[][] { var6};
//     org.apache.commons.math.linear.RealMatrix var9 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(var8);
//     org.apache.commons.math.linear.BlockRealMatrix var10 = new org.apache.commons.math.linear.BlockRealMatrix(var8);
//     int var11 = var10.getColumnDimension();
//     org.apache.commons.math.linear.RealMatrix var13 = var10.getRowMatrix(0);
//     org.apache.commons.math.ode.events.CombinedEventsManager var15 = new org.apache.commons.math.ode.events.CombinedEventsManager();
//     org.apache.commons.math.ode.events.EventHandler var16 = null;
//     var15.addEventHandler(var16, 0.0d, Double.POSITIVE_INFINITY, 0);
//     org.apache.commons.math.ode.events.EventHandler var21 = null;
//     var15.addEventHandler(var21, 10.0d, Double.POSITIVE_INFINITY, 2);
//     var15.clearEventsHandlers();
//     java.lang.Throwable var28 = null;
//     double[] var31 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var33 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var31, false);
//     double var34 = var33.getCurrentTime();
//     double[] var35 = var33.getInterpolatedState();
//     java.lang.Object[] var40 = new java.lang.Object[] { 0.0d};
//     java.util.NoSuchElementException var41 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", var40);
//     java.lang.IllegalArgumentException var42 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("", var40);
//     org.apache.commons.math.FunctionEvaluationException var43 = new org.apache.commons.math.FunctionEvaluationException(var28, var35, "org.apache.commons.math.FunctionEvaluationException: evaluation failed for argument = {-1; 0}", var40);
//     double[] var46 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var48 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var46, false);
//     double[] var49 = var48.getInterpolatedDerivatives();
//     org.apache.commons.math.FunctionEvaluationException var50 = new org.apache.commons.math.FunctionEvaluationException(var28, var49);
//     var15.stepAccepted(10.0d, var49);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var10.setRow(2147483646, var49);
//       fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
//     } catch (org.apache.commons.math.linear.MatrixIndexException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
// 
//   }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test25"); }


    java.lang.Object[] var1 = null;
    java.lang.IllegalStateException var2 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("hi!", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test26"); }


    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var4 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(0.0d, (-1.0d), 10.0d, 100.0d);
    var4.setMaxEvaluations(10);
    var4.setMaxGrowth(1.4142135623730951d);

  }

  public void test27() {}
//   public void test27() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test27"); }
// 
// 
//     org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var0 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator();
//     double[] var3 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var5 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var3, false);
//     double[][] var6 = new double[][] { var3};
//     org.apache.commons.math.linear.BlockRealMatrix var7 = new org.apache.commons.math.linear.BlockRealMatrix(var6);
//     double[] var10 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var12 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var10, false);
//     double[] var13 = var12.getInterpolatedState();
//     double[] var14 = var7.operate(var13);
//     var0.reinitialize(var14, true);
//     org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var17 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator(var0);
//     org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var18 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator(var0);
//     boolean var19 = var0.isForward();
//     boolean var20 = var0.isForward();
//     double[] var24 = new double[] { 1.0d, 0.0d, 1.0d};
//     org.apache.commons.math.linear.BigMatrix var25 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(var24);
//     var0.reinitialize(var24, false);
//     java.io.ObjectInputStream var29 = null;
//     org.apache.commons.math.linear.MatrixUtils.deserializeRealMatrix((java.lang.Object)var0, "BlockRealMatrix{{-1.0,0.0}}", var29);
// 
//   }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test28"); }


    double[] var2 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var4 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var2, false);
    double[][] var5 = new double[][] { var2};
    org.apache.commons.math.linear.BlockRealMatrix var6 = new org.apache.commons.math.linear.BlockRealMatrix(var5);
    org.apache.commons.math.linear.BigMatrix var7 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(var5);
    org.apache.commons.math.linear.BlockRealMatrix var8 = new org.apache.commons.math.linear.BlockRealMatrix(var5);
    double[][] var9 = var8.getData();
    org.apache.commons.math.linear.RealMatrixPreservingVisitor var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var15 = var8.walkInOptimizedOrder(var10, 100, 2, (-11), 25);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test29"); }


    double[] var2 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var4 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var2, false);
    double[][] var5 = new double[][] { var2};
    org.apache.commons.math.linear.BlockRealMatrix var6 = new org.apache.commons.math.linear.BlockRealMatrix(var5);
    org.apache.commons.math.linear.BlockRealMatrix var8 = var6.getColumnMatrix(1);
    double[] var11 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var13 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var11, false);
    double[][] var14 = new double[][] { var11};
    org.apache.commons.math.linear.BlockRealMatrix var15 = new org.apache.commons.math.linear.BlockRealMatrix(var14);
    org.apache.commons.math.linear.BlockRealMatrix var17 = var15.getColumnMatrix(1);
    org.apache.commons.math.linear.BlockRealMatrix var18 = var8.subtract(var17);
    org.apache.commons.math.linear.BlockRealMatrix var19 = var17.copy();
    java.lang.String var20 = var19.toString();
    org.apache.commons.math.linear.RealMatrix var22 = var19.scalarAdd(0.0d);
    java.lang.String var23 = var19.toString();
    double var24 = var19.getDeterminant();
    int var25 = var19.getRowDimension();
    org.apache.commons.math.ode.events.CombinedEventsManager var27 = new org.apache.commons.math.ode.events.CombinedEventsManager();
    org.apache.commons.math.ode.events.EventHandler var28 = null;
    var27.addEventHandler(var28, 0.0d, Double.POSITIVE_INFINITY, 0);
    org.apache.commons.math.ode.events.EventHandler var33 = null;
    var27.addEventHandler(var33, (-1.0d), (-1000.0d), 100);
    double[] var43 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var45 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var43, false);
    double[][] var46 = new double[][] { var43};
    org.apache.commons.math.linear.BlockRealMatrix var47 = new org.apache.commons.math.linear.BlockRealMatrix(var46);
    org.apache.commons.math.linear.BlockRealMatrix var49 = var47.getColumnMatrix(1);
    double[] var52 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var54 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var52, false);
    double[][] var55 = new double[][] { var52};
    org.apache.commons.math.linear.BlockRealMatrix var56 = new org.apache.commons.math.linear.BlockRealMatrix(var55);
    org.apache.commons.math.linear.BlockRealMatrix var58 = var56.getColumnMatrix(1);
    org.apache.commons.math.linear.BlockRealMatrix var59 = var49.subtract(var58);
    java.lang.String var60 = var49.toString();
    double[] var62 = var49.getRow(0);
    org.apache.commons.math.linear.RealMatrix var63 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(var62);
    java.lang.Object[] var69 = new java.lang.Object[] { 0L};
    java.text.ParseException var70 = org.apache.commons.math.MathRuntimeException.createParseException((-1), "", var69);
    org.apache.commons.math.FunctionEvaluationException var71 = new org.apache.commons.math.FunctionEvaluationException(100.0d, "", var69);
    double[] var72 = var71.getArgument();
    double[] var73 = var71.getArgument();
    org.apache.commons.math.linear.Array2DRowRealMatrix var74 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var73);
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var75 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(2.147483647E11d, Double.POSITIVE_INFINITY, var62, var73);
    boolean var76 = var27.reset(0.2d, var73);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var19.setColumn((-1000), var73);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "BlockRealMatrix{{0.0}}"+ "'", var20.equals("BlockRealMatrix{{0.0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + "BlockRealMatrix{{0.0}}"+ "'", var23.equals("BlockRealMatrix{{0.0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var60 + "' != '" + "BlockRealMatrix{{0.0}}"+ "'", var60.equals("BlockRealMatrix{{0.0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == false);

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test30"); }


    double[] var6 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var8 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var6, false);
    double[][] var9 = new double[][] { var6};
    org.apache.commons.math.linear.BlockRealMatrix var10 = new org.apache.commons.math.linear.BlockRealMatrix(var9);
    org.apache.commons.math.MaxIterationsExceededException var11 = new org.apache.commons.math.MaxIterationsExceededException(0, "", (java.lang.Object[])var9);
    org.apache.commons.math.linear.Array2DRowRealMatrix var13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var9, false);
    int var14 = var13.getRowDimension();
    double[][] var15 = var13.getData();
    java.lang.IllegalArgumentException var16 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("org.apache.commons.math.MathRuntimeException: hi!", (java.lang.Object[])var15);
    org.apache.commons.math.linear.BigMatrix var17 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(var15);
    org.apache.commons.math.ode.events.EventException var18 = new org.apache.commons.math.ode.events.EventException("", (java.lang.Object[])var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test31"); }


    org.apache.commons.math.fraction.BigFractionField var0 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var1 = var0.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var2 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var1);
    org.apache.commons.math.FieldElement[] var3 = new org.apache.commons.math.FieldElement[] { var1};
    org.apache.commons.math.linear.FieldMatrix var4 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createColumnFieldMatrix(var3);
    org.apache.commons.math.FieldElement[][] var5 = new org.apache.commons.math.FieldElement[][] { var3};
    org.apache.commons.math.linear.FieldMatrix var6 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldMatrix(var5);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var8 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var5, false);
    org.apache.commons.math.fraction.BigFractionField var10 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var11 = var10.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var12 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var11);
    org.apache.commons.math.fraction.BigFraction var14 = var11.subtract((-1L));
    org.apache.commons.math.FieldElement[] var15 = new org.apache.commons.math.FieldElement[] { var11};
    org.apache.commons.math.linear.FieldMatrix var16 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var15);
    java.io.EOFException var17 = org.apache.commons.math.MathRuntimeException.createEOFException("java.io.IOException: ", (java.lang.Object[])var15);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var18 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var15);
    org.apache.commons.math.linear.FieldMatrix var19 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createRowFieldMatrix(var15);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var20 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var15);
    org.apache.commons.math.FieldElement[] var21 = var8.operate(var15);
    org.apache.commons.math.FieldElement var22 = null;
    org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor var23 = new org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor(var22);
    var23.start(100, 2147483647, 1, 10, 100, 100);
    org.apache.commons.math.fraction.BigFractionField var33 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var34 = var33.getZero();
    org.apache.commons.math.FieldElement[][] var37 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>createBlocksLayout((org.apache.commons.math.Field)var33, 0, 0);
    org.apache.commons.math.fraction.BigFraction var38 = var33.getZero();
    org.apache.commons.math.FieldElement var39 = var23.visit((-1), 0, (org.apache.commons.math.FieldElement)var38);
    var23.start(2147483647, 0, (-1), 1, 0, (-1));
    org.apache.commons.math.FieldElement var47 = var8.walkInColumnOrder((org.apache.commons.math.linear.FieldMatrixChangingVisitor)var23);
    org.apache.commons.math.FieldElement[][] var48 = var8.getData();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math.linear.FieldMatrix var50 = var8.getRowMatrix((-1000));
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test32"); }


    org.apache.commons.math.linear.BlockRealMatrix var2 = new org.apache.commons.math.linear.BlockRealMatrix(1, 1);
    org.apache.commons.math.linear.RealMatrix var3 = var2.transpose();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test33() {}
//   public void test33() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test33"); }
// 
// 
//     org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var4 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(0.0d, (-1.0d), 10.0d, 100.0d);
//     int var5 = var4.getMaxEvaluations();
//     var4.setSafety(1.0d);
//     double var8 = var4.getMaxGrowth();
//     int var9 = var4.getEvaluations();
//     double var10 = var4.getSafety();
//     var4.setMaxEvaluations(2);
//     int var13 = var4.getOrder();
//     double var14 = var4.getCurrentStepStart();
//     double var15 = var4.getCurrentSignedStepsize();
//     java.util.Collection var16 = var4.getEventHandlers();
//     var4.setInitialStepSize(1.0E-15d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
// 
//   }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test34"); }


    double[] var2 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var4 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var2, false);
    double[][] var5 = new double[][] { var2};
    org.apache.commons.math.linear.BlockRealMatrix var6 = new org.apache.commons.math.linear.BlockRealMatrix(var5);
    double[] var9 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var11 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var9, false);
    double[] var12 = var11.getInterpolatedState();
    double[] var13 = var6.operate(var12);
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var15 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var13, false);
    org.apache.commons.math.ode.sampling.StepInterpolator var16 = var15.copy();
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var17 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var15);
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var18 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var15);
    var18.setInterpolatedTime((-1000.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test35"); }


    double[] var2 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var4 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var2, false);
    double[][] var5 = new double[][] { var2};
    org.apache.commons.math.linear.BlockRealMatrix var6 = new org.apache.commons.math.linear.BlockRealMatrix(var5);
    org.apache.commons.math.linear.BlockRealMatrix var8 = var6.getColumnMatrix(1);
    org.apache.commons.math.linear.BlockRealMatrix var11 = var8.createMatrix(1, 100);
    int var12 = var8.getColumnDimension();
    double var13 = var8.getTrace();
    org.apache.commons.math.linear.RealVector var15 = var8.getColumnVector(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test36"); }


    org.apache.commons.math.fraction.BigFractionField var0 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var1 = var0.getZero();
    org.apache.commons.math.fraction.BigFraction var2 = var0.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var5 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var0, 10, 10);
    org.apache.commons.math.linear.FieldMatrix var6 = var5.transpose();
    org.apache.commons.math.fraction.BigFractionField var7 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var8 = var7.getZero();
    org.apache.commons.math.fraction.BigFraction var9 = var7.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var12 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var7, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var13 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var14 = var13.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var15 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var14);
    var15.start(2147483647, 0, 100, (-10), 100, 0);
    org.apache.commons.math.FieldElement var23 = var12.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var15);
    org.apache.commons.math.fraction.BigFractionField var26 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var27 = var26.getZero();
    org.apache.commons.math.fraction.BigFraction var28 = var26.getOne();
    org.apache.commons.math.fraction.BigFraction var30 = var28.pow(100);
    var12.setEntry(10, (-1), (org.apache.commons.math.FieldElement)var30);
    org.apache.commons.math.fraction.BigFractionField var32 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var33 = var32.getZero();
    org.apache.commons.math.fraction.BigFraction var34 = var32.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var37 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var32, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var38 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var39 = var38.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var40 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var39);
    var40.start(2147483647, 0, 100, (-10), 100, 0);
    org.apache.commons.math.FieldElement var48 = var37.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var40);
    org.apache.commons.math.linear.FieldVector var50 = var37.getColumnVector(1);
    org.apache.commons.math.linear.BlockFieldMatrix var51 = var12.multiply(var37);
    int var52 = var37.getColumnDimension();
    org.apache.commons.math.fraction.BigFractionField var53 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var54 = var53.getZero();
    org.apache.commons.math.fraction.BigFraction var55 = var53.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var58 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var53, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var59 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var60 = var59.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var61 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var60);
    org.apache.commons.math.fraction.BigFraction var63 = var60.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var65 = var60.subtract(10L);
    double var66 = var65.percentageValue();
    org.apache.commons.math.fraction.BigFraction var68 = var65.multiply(1);
    org.apache.commons.math.fraction.BigFractionField var69 = var65.getField();
    org.apache.commons.math.linear.Array2DRowFieldMatrix var70 = new org.apache.commons.math.linear.Array2DRowFieldMatrix((org.apache.commons.math.Field)var69);
    boolean var71 = var70.isSquare();
    org.apache.commons.math.fraction.BigFractionField var72 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var73 = var72.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var74 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var73);
    org.apache.commons.math.FieldElement var75 = var70.walkInColumnOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var74);
    org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor var76 = new org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor(var75);
    org.apache.commons.math.FieldElement var77 = var58.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixChangingVisitor)var76);
    int var78 = var58.getRowDimension();
    org.apache.commons.math.linear.FieldMatrix var79 = var37.subtract((org.apache.commons.math.linear.FieldMatrix)var58);
    org.apache.commons.math.linear.BlockFieldMatrix var80 = var5.subtract(var37);
    org.apache.commons.math.fraction.BigFractionField var81 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var82 = var81.getZero();
    org.apache.commons.math.linear.Array2DRowFieldMatrix var83 = new org.apache.commons.math.linear.Array2DRowFieldMatrix((org.apache.commons.math.Field)var81);
    org.apache.commons.math.FieldElement var84 = null;
    org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor var85 = new org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor(var84);
    var85.start(100, 2147483647, 1, 10, 100, 100);
    org.apache.commons.math.FieldElement var93 = var83.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixChangingVisitor)var85);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math.FieldElement var98 = var37.walkInColumnOrder((org.apache.commons.math.linear.FieldMatrixChangingVisitor)var85, 8, 10, (-1000), 25);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == (-1000.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var93);

  }

  public void test37() {}
//   public void test37() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test37"); }
// 
// 
//     org.apache.commons.math.fraction.BigFractionField var0 = org.apache.commons.math.fraction.BigFractionField.getInstance();
//     org.apache.commons.math.fraction.BigFraction var1 = var0.getZero();
//     org.apache.commons.math.fraction.BigFraction var2 = var0.getOne();
//     org.apache.commons.math.linear.BlockFieldMatrix var5 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var0, 10, 10);
//     org.apache.commons.math.fraction.BigFractionField var6 = org.apache.commons.math.fraction.BigFractionField.getInstance();
//     org.apache.commons.math.fraction.BigFraction var7 = var6.getZero();
//     org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var8 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var7);
//     var8.start(2147483647, 0, 100, (-10), 100, 0);
//     org.apache.commons.math.FieldElement var16 = var5.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var8);
//     org.apache.commons.math.fraction.BigFractionField var19 = org.apache.commons.math.fraction.BigFractionField.getInstance();
//     org.apache.commons.math.fraction.BigFraction var20 = var19.getZero();
//     org.apache.commons.math.fraction.BigFraction var21 = var19.getOne();
//     org.apache.commons.math.fraction.BigFraction var23 = var21.pow(100);
//     var5.setEntry(10, (-1), (org.apache.commons.math.FieldElement)var23);
//     org.apache.commons.math.fraction.BigFractionField var25 = org.apache.commons.math.fraction.BigFractionField.getInstance();
//     org.apache.commons.math.fraction.BigFraction var26 = var25.getZero();
//     org.apache.commons.math.fraction.BigFraction var27 = var25.getOne();
//     org.apache.commons.math.linear.BlockFieldMatrix var30 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var25, 10, 10);
//     org.apache.commons.math.fraction.BigFractionField var31 = org.apache.commons.math.fraction.BigFractionField.getInstance();
//     org.apache.commons.math.fraction.BigFraction var32 = var31.getZero();
//     org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var33 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var32);
//     var33.start(2147483647, 0, 100, (-10), 100, 0);
//     org.apache.commons.math.FieldElement var41 = var30.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var33);
//     org.apache.commons.math.linear.FieldVector var43 = var30.getColumnVector(1);
//     org.apache.commons.math.linear.BlockFieldMatrix var44 = var5.multiply(var30);
//     org.apache.commons.math.linear.FieldVector var46 = var5.getRowVector(8);
//     org.apache.commons.math.Field var47 = var5.getField();
//     org.apache.commons.math.linear.FieldMatrixPreservingVisitor var48 = null;
//     org.apache.commons.math.FieldElement var49 = var5.walkInRowOrder(var48);
// 
//   }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test38"); }


    org.apache.commons.math.fraction.BigFractionField var0 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var1 = var0.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var2 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var1);
    org.apache.commons.math.fraction.BigFraction var4 = var1.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var6 = var1.pow(2147483647);
    org.apache.commons.math.fraction.BigFraction var8 = var6.pow(0L);
    org.apache.commons.math.fraction.BigFractionField var9 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var10 = var9.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var11 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var10);
    org.apache.commons.math.fraction.BigFraction var13 = var10.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var15 = var10.pow(2147483647);
    org.apache.commons.math.fraction.BigFraction var17 = var15.pow(0L);
    org.apache.commons.math.fraction.BigFraction var19 = var15.divide(1);
    java.math.BigInteger var20 = var15.getNumerator();
    org.apache.commons.math.fraction.BigFractionField var21 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var22 = var21.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var23 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var22);
    org.apache.commons.math.fraction.BigFraction var25 = var22.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var27 = var22.pow(2147483647);
    org.apache.commons.math.fraction.BigFraction var29 = var27.pow(0L);
    org.apache.commons.math.fraction.BigFraction var31 = var27.divide(1);
    org.apache.commons.math.fraction.BigFraction var32 = var15.multiply(var31);
    int var33 = var8.compareTo(var31);
    org.apache.commons.math.fraction.BigFraction var35 = var8.multiply(0);
    org.apache.commons.math.fraction.BigFractionField var36 = var8.getField();
    org.apache.commons.math.fraction.BigFraction var38 = var8.pow(0);
    org.apache.commons.math.fraction.BigFraction var40 = var38.pow(0L);
    java.math.BigDecimal var41 = var38.bigDecimalValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test39() {}
//   public void test39() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test39"); }
// 
// 
//     org.apache.commons.math.fraction.BigFractionField var3 = org.apache.commons.math.fraction.BigFractionField.getInstance();
//     org.apache.commons.math.fraction.BigFraction var4 = var3.getZero();
//     org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var5 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var4);
//     org.apache.commons.math.FieldElement[] var6 = new org.apache.commons.math.FieldElement[] { var4};
//     org.apache.commons.math.linear.FieldMatrix var7 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createColumnFieldMatrix(var6);
//     org.apache.commons.math.FieldElement[][] var8 = new org.apache.commons.math.FieldElement[][] { var6};
//     org.apache.commons.math.linear.FieldMatrix var9 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldMatrix(var8);
//     org.apache.commons.math.FunctionEvaluationException var10 = new org.apache.commons.math.FunctionEvaluationException(10.0d, "", (java.lang.Object[])var8);
//     java.util.ConcurrentModificationException var11 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("matrix is singular", (java.lang.Object[])var8);
//     org.apache.commons.math.linear.Array2DRowFieldMatrix var13 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var8, true);
//     org.apache.commons.math.fraction.BigFractionField var14 = org.apache.commons.math.fraction.BigFractionField.getInstance();
//     org.apache.commons.math.fraction.BigFraction var15 = var14.getZero();
//     org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var16 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var15);
//     org.apache.commons.math.fraction.BigFraction var18 = var15.subtract((-1L));
//     org.apache.commons.math.fraction.BigFraction var20 = var15.pow(2147483647);
//     org.apache.commons.math.fraction.BigFraction var22 = var20.pow(0L);
//     org.apache.commons.math.fraction.BigFractionField var23 = org.apache.commons.math.fraction.BigFractionField.getInstance();
//     org.apache.commons.math.fraction.BigFraction var24 = var23.getZero();
//     int var25 = var24.getDenominatorAsInt();
//     org.apache.commons.math.fraction.BigFraction var27 = var24.pow(0L);
//     org.apache.commons.math.fraction.BigFraction var28 = var20.multiply(var24);
//     org.apache.commons.math.fraction.BigFraction var29 = var28.negate();
//     org.apache.commons.math.linear.FieldMatrix var30 = var13.scalarAdd((org.apache.commons.math.FieldElement)var29);
//     double[] var33 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var35 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var33, false);
//     double var36 = var35.getCurrentTime();
//     double[] var37 = var35.getInterpolatedState();
//     org.apache.commons.math.linear.RealVector var38 = org.apache.commons.math.linear.MatrixUtils.createRealVector(var37);
//     boolean var39 = var29.equals((java.lang.Object)var37);
//     org.apache.commons.math.FieldElement var40 = null;
//     org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor var41 = new org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor(var40);
//     var41.start(100, 2147483647, 1, 10, 100, 100);
//     org.apache.commons.math.fraction.BigFractionField var51 = org.apache.commons.math.fraction.BigFractionField.getInstance();
//     org.apache.commons.math.fraction.BigFraction var52 = var51.getZero();
//     org.apache.commons.math.FieldElement[][] var55 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>createBlocksLayout((org.apache.commons.math.Field)var51, 0, 0);
//     org.apache.commons.math.fraction.BigFraction var56 = var51.getZero();
//     org.apache.commons.math.FieldElement var57 = var41.visit((-1), 0, (org.apache.commons.math.FieldElement)var56);
//     org.apache.commons.math.fraction.BigFractionField var60 = org.apache.commons.math.fraction.BigFractionField.getInstance();
//     org.apache.commons.math.fraction.BigFraction var61 = var60.getZero();
//     org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var62 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var61);
//     org.apache.commons.math.fraction.BigFraction var64 = var61.subtract((-1L));
//     org.apache.commons.math.fraction.BigFraction var66 = var61.subtract(10L);
//     org.apache.commons.math.FieldElement var67 = var41.visit(100, 0, (org.apache.commons.math.FieldElement)var66);
//     long var68 = var66.getNumeratorAsLong();
//     org.apache.commons.math.fraction.BigFractionField var69 = org.apache.commons.math.fraction.BigFractionField.getInstance();
//     org.apache.commons.math.fraction.BigFraction var70 = var69.getZero();
//     org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var71 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var70);
//     org.apache.commons.math.fraction.BigFraction var73 = var70.subtract((-1L));
//     org.apache.commons.math.fraction.BigFraction var75 = var70.pow(2147483647);
//     org.apache.commons.math.fraction.BigFractionField var76 = org.apache.commons.math.fraction.BigFractionField.getInstance();
//     org.apache.commons.math.fraction.BigFraction var77 = var76.getZero();
//     org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var78 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var77);
//     org.apache.commons.math.fraction.BigFraction var80 = var77.subtract((-1L));
//     org.apache.commons.math.fraction.BigFraction var82 = var77.pow(2147483647);
//     org.apache.commons.math.fraction.BigFraction var84 = var82.pow(0L);
//     org.apache.commons.math.fraction.BigFraction var86 = var82.divide(1);
//     java.math.BigInteger var87 = var82.getNumerator();
//     org.apache.commons.math.fraction.BigFraction var88 = var70.pow(var87);
//     org.apache.commons.math.fraction.BigFraction var89 = new org.apache.commons.math.fraction.BigFraction(var87);
//     org.apache.commons.math.fraction.BigFraction var90 = var66.pow(var87);
//     org.apache.commons.math.fraction.BigFraction var91 = var90.reciprocal();
//     org.apache.commons.math.fraction.BigFraction var92 = var90.abs();
//     org.apache.commons.math.fraction.BigFraction var93 = var29.divide(var92);
//     org.apache.commons.math.fraction.BigFraction var95 = var29.pow(0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var68 == (-10L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var70);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var75);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var82);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var84);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var86);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var87);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var88);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var90);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var91);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var92);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var93);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var95);
// 
//   }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test40"); }


    double[] var2 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var4 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var2, false);
    double[][] var5 = new double[][] { var2};
    org.apache.commons.math.linear.BlockRealMatrix var6 = new org.apache.commons.math.linear.BlockRealMatrix(var5);
    double[] var9 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var11 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var9, false);
    double[] var12 = var11.getInterpolatedState();
    double[] var13 = var6.operate(var12);
    org.apache.commons.math.linear.BlockRealMatrix var15 = var6.scalarAdd((-1.0d));
    org.apache.commons.math.linear.RealMatrix var17 = var6.scalarAdd(0.0d);
    double[] var20 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var22 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var20, false);
    double[][] var23 = new double[][] { var20};
    org.apache.commons.math.linear.BlockRealMatrix var24 = new org.apache.commons.math.linear.BlockRealMatrix(var23);
    org.apache.commons.math.linear.BlockRealMatrix var25 = var24.transpose();
    org.apache.commons.math.linear.BlockRealMatrix var26 = var6.add((org.apache.commons.math.linear.RealMatrix)var24);
    double[] var29 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var31 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var29, false);
    double[][] var32 = new double[][] { var29};
    org.apache.commons.math.linear.BlockRealMatrix var33 = new org.apache.commons.math.linear.BlockRealMatrix(var32);
    org.apache.commons.math.linear.RealMatrix var35 = var33.scalarMultiply(10.0d);
    org.apache.commons.math.linear.BlockRealMatrix var36 = var6.add(var33);
    org.apache.commons.math.linear.RealMatrix var38 = var33.scalarMultiply(0.0d);
    org.apache.commons.math.linear.BlockRealMatrix var39 = var33.copy();
    double var42 = var33.getEntry(0, 1);
    org.apache.commons.math.linear.RealMatrixPreservingVisitor var43 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var48 = var33.walkInOptimizedOrder(var43, 100, (-9), 0, 10);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0.0d);

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test41"); }


    org.apache.commons.math.analysis.solvers.BrentSolver var0 = new org.apache.commons.math.analysis.solvers.BrentSolver();
    var0.setRelativeAccuracy(100.0d);
    double var3 = var0.getRelativeAccuracy();
    var0.resetMaximalIterationCount();
    double var5 = var0.getFunctionValueAccuracy();
    var0.resetMaximalIterationCount();
    var0.resetAbsoluteAccuracy();
    var0.resetRelativeAccuracy();
    var0.resetMaximalIterationCount();
    var0.setMaximalIterationCount(10);
    double var12 = var0.getAbsoluteAccuracy();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0E-15d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1.0E-6d);

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test42"); }


    double[] var2 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var4 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var2, false);
    double[][] var5 = new double[][] { var2};
    org.apache.commons.math.linear.BlockRealMatrix var6 = new org.apache.commons.math.linear.BlockRealMatrix(var5);
    double[] var9 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var11 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var9, false);
    double[] var12 = var11.getInterpolatedState();
    double[] var13 = var6.operate(var12);
    org.apache.commons.math.linear.BlockRealMatrix var15 = var6.scalarAdd((-1.0d));
    org.apache.commons.math.linear.RealMatrix var17 = var6.scalarAdd(0.0d);
    org.apache.commons.math.fraction.BigFractionField var18 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var19 = var18.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var20 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var19);
    org.apache.commons.math.FieldElement[] var21 = new org.apache.commons.math.FieldElement[] { var19};
    org.apache.commons.math.linear.FieldMatrix var22 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createColumnFieldMatrix(var21);
    double[] var25 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var27 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var25, false);
    double[][] var28 = new double[][] { var25};
    org.apache.commons.math.linear.BlockRealMatrix var29 = new org.apache.commons.math.linear.BlockRealMatrix(var28);
    org.apache.commons.math.linear.RealMatrix var31 = var29.scalarMultiply(10.0d);
    org.apache.commons.math.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math.linear.AnyMatrix)var22, (org.apache.commons.math.linear.AnyMatrix)var31);
    org.apache.commons.math.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math.linear.AnyMatrix)var6, (org.apache.commons.math.linear.AnyMatrix)var31);
    double[][] var34 = var6.getData();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test43"); }


    double[] var4 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var6 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var4, false);
    double[][] var7 = new double[][] { var4};
    org.apache.commons.math.linear.BlockRealMatrix var8 = new org.apache.commons.math.linear.BlockRealMatrix(var7);
    org.apache.commons.math.MaxIterationsExceededException var9 = new org.apache.commons.math.MaxIterationsExceededException(0, "", (java.lang.Object[])var7);
    org.apache.commons.math.linear.Array2DRowRealMatrix var11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var7, false);
    int var12 = var11.getRowDimension();
    double[][] var13 = var11.getData();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var15 = var11.getColumn((-1000));
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test44"); }


    org.apache.commons.math.fraction.BigFractionField var3 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var4 = var3.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var5 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var4);
    org.apache.commons.math.fraction.BigFraction var7 = var4.subtract((-1L));
    org.apache.commons.math.FieldElement[] var8 = new org.apache.commons.math.FieldElement[] { var4};
    org.apache.commons.math.linear.FieldMatrix var9 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var8);
    org.apache.commons.math.FieldElement[][] var10 = new org.apache.commons.math.FieldElement[][] { var8};
    org.apache.commons.math.linear.Array2DRowFieldMatrix var11 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var10);
    org.apache.commons.math.fraction.BigFractionField var12 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var13 = var12.getZero();
    org.apache.commons.math.fraction.BigFraction var14 = var12.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var17 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var12, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var18 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var19 = var18.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var20 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var19);
    var20.start(2147483647, 0, 100, (-10), 100, 0);
    org.apache.commons.math.FieldElement var28 = var17.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var20);
    org.apache.commons.math.fraction.BigFractionField var31 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var32 = var31.getZero();
    org.apache.commons.math.fraction.BigFraction var33 = var31.getOne();
    org.apache.commons.math.fraction.BigFraction var35 = var33.pow(100);
    var17.setEntry(10, (-1), (org.apache.commons.math.FieldElement)var35);
    org.apache.commons.math.FieldElement[] var37 = new org.apache.commons.math.FieldElement[] { var35};
    org.apache.commons.math.FieldElement[] var38 = var11.operate(var37);
    org.apache.commons.math.linear.FieldMatrix var39 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var38);
    java.lang.ArrayIndexOutOfBoundsException var40 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("matrix is singular", (java.lang.Object[])var38);
    org.apache.commons.math.MaxIterationsExceededException var41 = new org.apache.commons.math.MaxIterationsExceededException(2, "org.apache.commons.math.MathRuntimeException: hi!", (java.lang.Object[])var38);
    java.lang.IllegalArgumentException var42 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((java.lang.Throwable)var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test45"); }


    org.apache.commons.math.fraction.BigFractionField var3 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var4 = var3.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var5 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var4);
    org.apache.commons.math.FieldElement[] var6 = new org.apache.commons.math.FieldElement[] { var4};
    org.apache.commons.math.linear.FieldMatrix var7 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createColumnFieldMatrix(var6);
    org.apache.commons.math.FieldElement[][] var8 = new org.apache.commons.math.FieldElement[][] { var6};
    org.apache.commons.math.linear.FieldMatrix var9 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldMatrix(var8);
    org.apache.commons.math.FunctionEvaluationException var10 = new org.apache.commons.math.FunctionEvaluationException(10.0d, "", (java.lang.Object[])var8);
    org.apache.commons.math.FieldElement[][] var11 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var8);
    org.apache.commons.math.ode.DerivativeException var12 = new org.apache.commons.math.ode.DerivativeException("Dormand-Prince 8 (5, 3)", (java.lang.Object[])var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test46() {}
//   public void test46() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test46"); }
// 
// 
//     double[] var2 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var4 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var2, false);
//     double[][] var5 = new double[][] { var2};
//     org.apache.commons.math.linear.BlockRealMatrix var6 = new org.apache.commons.math.linear.BlockRealMatrix(var5);
//     org.apache.commons.math.linear.BlockRealMatrix var8 = var6.getColumnMatrix(1);
//     double[] var11 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var13 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var11, false);
//     double[][] var14 = new double[][] { var11};
//     org.apache.commons.math.linear.BlockRealMatrix var15 = new org.apache.commons.math.linear.BlockRealMatrix(var14);
//     org.apache.commons.math.linear.BlockRealMatrix var17 = var15.getColumnMatrix(1);
//     org.apache.commons.math.linear.BlockRealMatrix var18 = var8.subtract(var17);
//     org.apache.commons.math.linear.RealMatrix var19 = var17.transpose();
//     double[][] var20 = var17.getData();
//     double[] var23 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var25 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var23, false);
//     double[][] var26 = new double[][] { var23};
//     org.apache.commons.math.linear.BlockRealMatrix var27 = new org.apache.commons.math.linear.BlockRealMatrix(var26);
//     org.apache.commons.math.linear.BlockRealMatrix var28 = var27.copy();
//     double[] var31 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var33 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var31, false);
//     double var34 = var33.getCurrentTime();
//     double[] var35 = var33.getInterpolatedState();
//     org.apache.commons.math.linear.RealVector var36 = org.apache.commons.math.linear.MatrixUtils.createRealVector(var35);
//     org.apache.commons.math.linear.RealVector var37 = var27.operate(var36);
//     org.apache.commons.math.linear.RealVector var38 = var17.preMultiply(var37);
//     double var39 = var17.getDeterminant();
//     org.apache.commons.math.fraction.BigFractionField var40 = org.apache.commons.math.fraction.BigFractionField.getInstance();
//     org.apache.commons.math.fraction.BigFraction var41 = var40.getZero();
//     org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var42 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var41);
//     org.apache.commons.math.FieldElement[] var43 = new org.apache.commons.math.FieldElement[] { var41};
//     org.apache.commons.math.linear.FieldMatrix var44 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createColumnFieldMatrix(var43);
//     org.apache.commons.math.FieldElement[][] var45 = new org.apache.commons.math.FieldElement[][] { var43};
//     org.apache.commons.math.linear.FieldMatrix var46 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldMatrix(var45);
//     org.apache.commons.math.linear.FieldLUDecompositionImpl var47 = new org.apache.commons.math.linear.FieldLUDecompositionImpl(var46);
//     int[] var48 = var47.getPivot();
//     org.apache.commons.math.linear.FieldMatrix var49 = var47.getU();
//     int[] var50 = var47.getPivot();
//     org.apache.commons.math.fraction.BigFractionField var51 = org.apache.commons.math.fraction.BigFractionField.getInstance();
//     org.apache.commons.math.fraction.BigFraction var52 = var51.getZero();
//     org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var53 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var52);
//     org.apache.commons.math.FieldElement[] var54 = new org.apache.commons.math.FieldElement[] { var52};
//     org.apache.commons.math.linear.FieldMatrix var55 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createColumnFieldMatrix(var54);
//     org.apache.commons.math.FieldElement[][] var56 = new org.apache.commons.math.FieldElement[][] { var54};
//     org.apache.commons.math.linear.FieldMatrix var57 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldMatrix(var56);
//     org.apache.commons.math.linear.FieldLUDecompositionImpl var58 = new org.apache.commons.math.linear.FieldLUDecompositionImpl(var57);
//     int[] var59 = var58.getPivot();
//     org.apache.commons.math.linear.FieldMatrix var60 = var58.getU();
//     org.apache.commons.math.FieldElement var61 = var58.getDeterminant();
//     org.apache.commons.math.linear.FieldMatrix var62 = var58.getU();
//     int[] var63 = var58.getPivot();
//     org.apache.commons.math.linear.RealMatrix var64 = var17.getSubMatrix(var50, var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
// 
//   }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test47"); }


    org.apache.commons.math.fraction.BigFractionField var1 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var2 = var1.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var3 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var2);
    org.apache.commons.math.fraction.BigFraction var5 = var2.subtract((-1L));
    org.apache.commons.math.FieldElement[] var6 = new org.apache.commons.math.FieldElement[] { var2};
    org.apache.commons.math.linear.FieldMatrix var7 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var6);
    java.io.EOFException var8 = org.apache.commons.math.MathRuntimeException.createEOFException("java.io.IOException: ", (java.lang.Object[])var6);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var9 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var6);
    org.apache.commons.math.FieldElement[][] var10 = var9.getDataRef();
    org.apache.commons.math.FieldElement var11 = var9.getTrace();
    org.apache.commons.math.fraction.BigFractionField var12 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var13 = var12.getZero();
    double var15 = var13.pow((-1.0d));
    org.apache.commons.math.fraction.BigFraction var16 = var13.abs();
    org.apache.commons.math.fraction.BigFractionField var17 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var18 = var17.getZero();
    org.apache.commons.math.fraction.BigFraction var19 = var17.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var22 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var17, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var23 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var24 = var23.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var25 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var24);
    var25.start(2147483647, 0, 100, (-10), 100, 0);
    org.apache.commons.math.FieldElement var33 = var22.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var25);
    org.apache.commons.math.fraction.BigFractionField var36 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var37 = var36.getZero();
    org.apache.commons.math.fraction.BigFraction var38 = var36.getOne();
    org.apache.commons.math.fraction.BigFraction var40 = var38.pow(100);
    var22.setEntry(10, (-1), (org.apache.commons.math.FieldElement)var40);
    org.apache.commons.math.fraction.BigFractionField var42 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var43 = var42.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var44 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var43);
    java.math.BigDecimal var45 = var43.bigDecimalValue();
    java.lang.String var46 = var43.toString();
    org.apache.commons.math.fraction.BigFractionField var47 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var48 = var47.getZero();
    java.math.BigInteger var49 = var48.getDenominator();
    org.apache.commons.math.fraction.BigFraction var50 = var43.pow(var49);
    org.apache.commons.math.fraction.BigFraction var51 = var40.add(var49);
    org.apache.commons.math.fraction.BigFraction var52 = var13.pow(var49);
    java.math.BigInteger var53 = var13.getNumerator();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var54 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var13);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math.FieldElement var59 = var9.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var54, 25, 0, 2, 100);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var46 + "' != '" + "0"+ "'", var46.equals("0"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test48"); }


    org.apache.commons.math.fraction.BigFraction var2 = new org.apache.commons.math.fraction.BigFraction(2147483647, 1);
    org.apache.commons.math.fraction.BigFraction var3 = var2.reduce();
    org.apache.commons.math.fraction.BigFractionField var4 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var5 = var4.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var6 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var5);
    org.apache.commons.math.fraction.BigFraction var8 = var5.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var10 = var5.pow(2147483647);
    org.apache.commons.math.fraction.BigFraction var12 = var10.pow(0L);
    org.apache.commons.math.fraction.BigFraction var14 = var10.divide(1);
    java.math.BigInteger var15 = var10.getNumerator();
    org.apache.commons.math.fraction.BigFractionField var16 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var17 = var16.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var18 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var17);
    org.apache.commons.math.fraction.BigFraction var20 = var17.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var22 = var17.pow(2147483647);
    org.apache.commons.math.fraction.BigFraction var24 = var22.pow(0L);
    org.apache.commons.math.fraction.BigFraction var26 = var22.divide(1);
    org.apache.commons.math.fraction.BigFraction var27 = var10.multiply(var26);
    java.math.BigInteger var28 = var10.getDenominator();
    org.apache.commons.math.fraction.BigFraction var29 = new org.apache.commons.math.fraction.BigFraction(var28);
    org.apache.commons.math.fraction.BigFraction var30 = var3.subtract(var28);
    long var31 = var3.getNumeratorAsLong();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 2147483647L);

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test49"); }


    org.apache.commons.math.fraction.BigFractionField var4 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var5 = var4.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var6 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var5);
    org.apache.commons.math.FieldElement[] var7 = new org.apache.commons.math.FieldElement[] { var5};
    org.apache.commons.math.linear.FieldMatrix var8 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createColumnFieldMatrix(var7);
    org.apache.commons.math.FieldElement[][] var9 = new org.apache.commons.math.FieldElement[][] { var7};
    org.apache.commons.math.linear.FieldMatrix var10 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldMatrix(var9);
    org.apache.commons.math.FunctionEvaluationException var11 = new org.apache.commons.math.FunctionEvaluationException(10.0d, "", (java.lang.Object[])var9);
    org.apache.commons.math.linear.BlockFieldMatrix var13 = new org.apache.commons.math.linear.BlockFieldMatrix(2147483647, 1, var9, false);
    org.apache.commons.math.linear.BlockFieldMatrix var14 = new org.apache.commons.math.linear.BlockFieldMatrix(var9);
    org.apache.commons.math.fraction.BigFractionField var15 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var16 = var15.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var17 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var16);
    org.apache.commons.math.fraction.BigFraction var19 = var16.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var21 = var16.subtract(10L);
    double var22 = var21.percentageValue();
    org.apache.commons.math.fraction.BigFraction var24 = var21.multiply(1);
    org.apache.commons.math.fraction.BigFractionField var25 = var21.getField();
    org.apache.commons.math.linear.Array2DRowFieldMatrix var26 = new org.apache.commons.math.linear.Array2DRowFieldMatrix((org.apache.commons.math.Field)var25);
    int var27 = var26.getRowDimension();
    org.apache.commons.math.fraction.BigFractionField var29 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var30 = var29.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var31 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var30);
    org.apache.commons.math.fraction.BigFraction var33 = var30.subtract((-1L));
    org.apache.commons.math.FieldElement[] var34 = new org.apache.commons.math.FieldElement[] { var30};
    org.apache.commons.math.linear.FieldMatrix var35 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var34);
    org.apache.commons.math.linear.FieldMatrix var36 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var34);
    org.apache.commons.math.linear.MatrixIndexException var37 = new org.apache.commons.math.linear.MatrixIndexException("java.io.IOException: ", (java.lang.Object[])var34);
    boolean var38 = var26.equals((java.lang.Object)var34);
    org.apache.commons.math.fraction.BigFractionField var39 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var40 = var39.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var41 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var40);
    org.apache.commons.math.fraction.BigFraction var43 = var40.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var45 = var40.subtract(10L);
    double var46 = var45.percentageValue();
    org.apache.commons.math.fraction.BigFraction var48 = var45.multiply(1);
    org.apache.commons.math.fraction.BigFractionField var49 = var45.getField();
    org.apache.commons.math.linear.Array2DRowFieldMatrix var50 = new org.apache.commons.math.linear.Array2DRowFieldMatrix((org.apache.commons.math.Field)var49);
    int var51 = var50.getRowDimension();
    org.apache.commons.math.FieldElement var52 = null;
    org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor var53 = new org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor(var52);
    org.apache.commons.math.FieldElement var54 = var50.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixChangingVisitor)var53);
    var53.start((-10), 8, (-10), (-10), (-1), 2147483647);
    org.apache.commons.math.FieldElement var62 = var26.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixChangingVisitor)var53);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math.FieldElement var67 = var14.walkInColumnOrder((org.apache.commons.math.linear.FieldMatrixChangingVisitor)var53, 11, 100, 0, 100);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == (-1000.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == (-1000.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var62);

  }

  public void test50() {}
//   public void test50() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test50"); }
// 
// 
//     double[] var5 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var7 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var5, false);
//     double var8 = var7.getCurrentTime();
//     double[] var9 = var7.getInterpolatedState();
//     double[] var10 = var7.getInterpolatedDerivatives();
//     double[] var13 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var15 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var13, false);
//     double var16 = var15.getCurrentTime();
//     double[] var17 = var15.getInterpolatedState();
//     double[] var18 = var15.getInterpolatedDerivatives();
//     org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var19 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, Double.NaN, 1.0E-15d, var10, var18);
//     org.apache.commons.math.ode.ODEIntegrator var20 = var19.getStarterIntegrator();
//     org.apache.commons.math.ode.events.CombinedEventsManager var21 = new org.apache.commons.math.ode.events.CombinedEventsManager();
//     double[] var25 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var27 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var25, false);
//     double[][] var28 = new double[][] { var25};
//     org.apache.commons.math.linear.BlockRealMatrix var29 = new org.apache.commons.math.linear.BlockRealMatrix(var28);
//     double[] var32 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var34 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var32, false);
//     double[] var35 = var34.getInterpolatedState();
//     double[] var36 = var29.operate(var35);
//     boolean var37 = var21.reset(1.0E-6d, var36);
//     var21.clearEventsHandlers();
//     double[] var42 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var44 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var42, false);
//     double var45 = var44.getCurrentTime();
//     double[] var46 = var44.getInterpolatedState();
//     double[] var47 = var44.getInterpolatedDerivatives();
//     var21.stepAccepted(100.0d, var47);
//     java.lang.Object[] var54 = new java.lang.Object[] { 0L};
//     java.text.ParseException var55 = org.apache.commons.math.MathRuntimeException.createParseException((-1), "", var54);
//     org.apache.commons.math.FunctionEvaluationException var56 = new org.apache.commons.math.FunctionEvaluationException(100.0d, "", var54);
//     double[] var57 = var56.getArgument();
//     double[] var58 = var56.getArgument();
//     double[] var61 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var63 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var61, false);
//     double[][] var64 = new double[][] { var61};
//     org.apache.commons.math.linear.BlockRealMatrix var65 = new org.apache.commons.math.linear.BlockRealMatrix(var64);
//     org.apache.commons.math.linear.BlockRealMatrix var67 = var65.getColumnMatrix(1);
//     double[] var70 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var72 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var70, false);
//     double[][] var73 = new double[][] { var70};
//     org.apache.commons.math.linear.BlockRealMatrix var74 = new org.apache.commons.math.linear.BlockRealMatrix(var73);
//     org.apache.commons.math.linear.BlockRealMatrix var76 = var74.getColumnMatrix(1);
//     org.apache.commons.math.linear.BlockRealMatrix var77 = var67.subtract(var76);
//     double[] var79 = var67.getRow(0);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var80 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var79);
//     var19.updateHighOrderDerivativesPhase2(var47, var58, var80);
//     var19.setMaxGrowth(0.0d);
//     double var84 = var19.getMinReduction();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var70);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var79);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var84 == 0.2d);
// 
//   }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test51"); }


    java.lang.Object[] var2 = null;
    org.apache.commons.math.MaxEvaluationsExceededException var3 = new org.apache.commons.math.MaxEvaluationsExceededException(100, "0", var2);
    org.apache.commons.math.fraction.BigFractionField var5 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var6 = var5.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var7 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var6);
    org.apache.commons.math.fraction.BigFraction var9 = var6.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var11 = var6.subtract(10L);
    double var12 = var11.percentageValue();
    org.apache.commons.math.fraction.BigFraction var14 = var11.multiply(1);
    org.apache.commons.math.fraction.BigFractionField var15 = var11.getField();
    org.apache.commons.math.linear.Array2DRowFieldMatrix var16 = new org.apache.commons.math.linear.Array2DRowFieldMatrix((org.apache.commons.math.Field)var15);
    int var17 = var16.getRowDimension();
    org.apache.commons.math.fraction.BigFractionField var19 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var20 = var19.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var21 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var20);
    org.apache.commons.math.fraction.BigFraction var23 = var20.subtract((-1L));
    org.apache.commons.math.FieldElement[] var24 = new org.apache.commons.math.FieldElement[] { var20};
    org.apache.commons.math.linear.FieldMatrix var25 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var24);
    org.apache.commons.math.linear.FieldMatrix var26 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var24);
    org.apache.commons.math.linear.MatrixIndexException var27 = new org.apache.commons.math.linear.MatrixIndexException("java.io.IOException: ", (java.lang.Object[])var24);
    boolean var28 = var16.equals((java.lang.Object)var24);
    org.apache.commons.math.linear.FieldMatrix var29 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createColumnFieldMatrix(var24);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var30 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var24);
    org.apache.commons.math.MathException var31 = new org.apache.commons.math.MathException((java.lang.Throwable)var3, "Dormand-Prince 8 (5, 3)", (java.lang.Object[])var24);
    java.lang.RuntimeException var32 = org.apache.commons.math.MathRuntimeException.createInternalError((java.lang.Throwable)var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-1000.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test52"); }


    org.apache.commons.math.fraction.BigFraction var2 = new org.apache.commons.math.fraction.BigFraction(2147483647L, 2147483647L);
    double var4 = var2.pow(1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test53"); }


    java.lang.Object[] var1 = null;
    java.lang.IllegalArgumentException var2 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("BlockRealMatrix{{0.2}}", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test54"); }


    double[] var2 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var4 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var2, false);
    double[][] var5 = new double[][] { var2};
    org.apache.commons.math.linear.BlockRealMatrix var6 = new org.apache.commons.math.linear.BlockRealMatrix(var5);
    org.apache.commons.math.linear.BlockRealMatrix var7 = var6.transpose();
    double[] var11 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var13 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var11, false);
    double[][] var14 = new double[][] { var11};
    org.apache.commons.math.linear.BlockRealMatrix var15 = new org.apache.commons.math.linear.BlockRealMatrix(var14);
    double[] var18 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var20 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var18, false);
    double[] var21 = var20.getInterpolatedState();
    double[] var22 = var15.operate(var21);
    org.apache.commons.math.linear.BlockRealMatrix var24 = var15.scalarAdd((-1.0d));
    org.apache.commons.math.linear.RealMatrix var26 = var15.scalarAdd(0.0d);
    org.apache.commons.math.fraction.BigFractionField var27 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var28 = var27.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var29 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var28);
    org.apache.commons.math.FieldElement[] var30 = new org.apache.commons.math.FieldElement[] { var28};
    org.apache.commons.math.linear.FieldMatrix var31 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createColumnFieldMatrix(var30);
    double[] var34 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var36 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var34, false);
    double[][] var37 = new double[][] { var34};
    org.apache.commons.math.linear.BlockRealMatrix var38 = new org.apache.commons.math.linear.BlockRealMatrix(var37);
    org.apache.commons.math.linear.RealMatrix var40 = var38.scalarMultiply(10.0d);
    org.apache.commons.math.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math.linear.AnyMatrix)var31, (org.apache.commons.math.linear.AnyMatrix)var40);
    org.apache.commons.math.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math.linear.AnyMatrix)var15, (org.apache.commons.math.linear.AnyMatrix)var40);
    var6.setRowMatrix(0, (org.apache.commons.math.linear.RealMatrix)var15);
    org.apache.commons.math.linear.RealMatrix var45 = var15.getRowMatrix(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var47 = var15.getRow(2147483647);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test55"); }


    org.apache.commons.math.fraction.BigFractionField var2 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var3 = var2.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var4 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var3);
    org.apache.commons.math.fraction.BigFraction var6 = var3.subtract((-1L));
    org.apache.commons.math.FieldElement[] var7 = new org.apache.commons.math.FieldElement[] { var3};
    org.apache.commons.math.linear.FieldMatrix var8 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var7);
    org.apache.commons.math.FieldElement[][] var9 = new org.apache.commons.math.FieldElement[][] { var7};
    org.apache.commons.math.linear.Array2DRowFieldMatrix var10 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var9);
    org.apache.commons.math.fraction.BigFractionField var11 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var12 = var11.getZero();
    org.apache.commons.math.fraction.BigFraction var13 = var11.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var16 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var11, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var17 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var18 = var17.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var19 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var18);
    var19.start(2147483647, 0, 100, (-10), 100, 0);
    org.apache.commons.math.FieldElement var27 = var16.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var19);
    org.apache.commons.math.fraction.BigFractionField var30 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var31 = var30.getZero();
    org.apache.commons.math.fraction.BigFraction var32 = var30.getOne();
    org.apache.commons.math.fraction.BigFraction var34 = var32.pow(100);
    var16.setEntry(10, (-1), (org.apache.commons.math.FieldElement)var34);
    org.apache.commons.math.FieldElement[] var36 = new org.apache.commons.math.FieldElement[] { var34};
    org.apache.commons.math.FieldElement[] var37 = var10.operate(var36);
    org.apache.commons.math.linear.FieldMatrix var38 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var36);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var39 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var36);
    org.apache.commons.math.fraction.BigFractionField var40 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var41 = var40.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var42 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var41);
    org.apache.commons.math.fraction.BigFraction var44 = var41.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var46 = var41.pow(2147483647);
    org.apache.commons.math.fraction.BigFractionField var47 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var48 = var47.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var49 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var48);
    org.apache.commons.math.fraction.BigFraction var51 = var48.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var53 = var48.pow(2147483647);
    org.apache.commons.math.fraction.BigFraction var55 = var53.pow(0L);
    org.apache.commons.math.fraction.BigFraction var57 = var53.divide(1);
    java.math.BigInteger var58 = var53.getNumerator();
    org.apache.commons.math.fraction.BigFraction var59 = var41.pow(var58);
    org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor var60 = new org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor((org.apache.commons.math.FieldElement)var59);
    org.apache.commons.math.FieldElement var61 = var39.walkInColumnOrder((org.apache.commons.math.linear.FieldMatrixChangingVisitor)var60);
    org.apache.commons.math.fraction.BigFractionField var62 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var63 = var62.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var64 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var63);
    org.apache.commons.math.FieldElement[] var65 = new org.apache.commons.math.FieldElement[] { var63};
    org.apache.commons.math.linear.FieldMatrix var66 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createColumnFieldMatrix(var65);
    org.apache.commons.math.linear.FieldVector var67 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var65);
    org.apache.commons.math.FieldElement[] var68 = var39.operate(var65);
    java.text.ParseException var69 = org.apache.commons.math.MathRuntimeException.createParseException(0, "BlockFieldMatrix{{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0}}", (java.lang.Object[])var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test56"); }


    double[] var4 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var6 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var4, false);
    double[][] var7 = new double[][] { var4};
    org.apache.commons.math.linear.BlockRealMatrix var8 = new org.apache.commons.math.linear.BlockRealMatrix(var7);
    double[] var11 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var13 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var11, false);
    double[] var14 = var13.getInterpolatedState();
    double[] var15 = var8.operate(var14);
    org.apache.commons.math.linear.BlockRealMatrix var17 = var8.scalarAdd((-1.0d));
    org.apache.commons.math.linear.RealMatrix var19 = var8.scalarAdd(0.0d);
    double[] var22 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var24 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var22, false);
    double[][] var25 = new double[][] { var22};
    org.apache.commons.math.linear.BlockRealMatrix var26 = new org.apache.commons.math.linear.BlockRealMatrix(var25);
    org.apache.commons.math.linear.BlockRealMatrix var27 = var26.transpose();
    org.apache.commons.math.linear.BlockRealMatrix var28 = var8.add((org.apache.commons.math.linear.RealMatrix)var26);
    org.apache.commons.math.fraction.BigFractionField var29 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var30 = var29.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var31 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var30);
    org.apache.commons.math.FieldElement[] var32 = new org.apache.commons.math.FieldElement[] { var30};
    org.apache.commons.math.linear.FieldMatrix var33 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createColumnFieldMatrix(var32);
    org.apache.commons.math.FieldElement[][] var34 = new org.apache.commons.math.FieldElement[][] { var32};
    org.apache.commons.math.linear.FieldMatrix var35 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldMatrix(var34);
    org.apache.commons.math.linear.FieldLUDecompositionImpl var36 = new org.apache.commons.math.linear.FieldLUDecompositionImpl(var35);
    int[] var37 = var36.getPivot();
    org.apache.commons.math.fraction.BigFractionField var38 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var39 = var38.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var40 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var39);
    org.apache.commons.math.FieldElement[] var41 = new org.apache.commons.math.FieldElement[] { var39};
    org.apache.commons.math.linear.FieldMatrix var42 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createColumnFieldMatrix(var41);
    org.apache.commons.math.FieldElement[][] var43 = new org.apache.commons.math.FieldElement[][] { var41};
    org.apache.commons.math.linear.FieldMatrix var44 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldMatrix(var43);
    org.apache.commons.math.linear.FieldLUDecompositionImpl var45 = new org.apache.commons.math.linear.FieldLUDecompositionImpl(var44);
    int[] var46 = var45.getPivot();
    org.apache.commons.math.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math.linear.AnyMatrix)var8, var37, var46);
    double[][] var48 = var8.getData();
    org.apache.commons.math.linear.BlockRealMatrix var50 = new org.apache.commons.math.linear.BlockRealMatrix(100, 2147483647, var48, false);
    org.apache.commons.math.linear.RealMatrixChangingVisitor var51 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var56 = var50.walkInRowOrder(var51, 2, 11, 0, (-11));
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test57"); }


    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var4 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(0.0d, (-1.0d), 10.0d, 100.0d);
    int var5 = var4.getMaxEvaluations();
    var4.setSafety(1.0d);
    double var8 = var4.getMaxGrowth();
    int var9 = var4.getEvaluations();
    double var10 = var4.getSafety();
    var4.setInitialStepSize(Double.POSITIVE_INFINITY);
    var4.setSafety(1.0E-6d);
    double var15 = var4.getSafety();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1.0E-6d);

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test58"); }


    java.lang.String[] var2 = new java.lang.String[] { "0"};
    org.apache.commons.math.linear.BigMatrix var3 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(var2);
    org.apache.commons.math.linear.BigMatrix var4 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(var2);
    java.lang.NullPointerException var5 = org.apache.commons.math.MathRuntimeException.createNullPointerException("Overflow trying to convert {0} to fraction ({1}/{2})", (java.lang.Object[])var2);
    org.apache.commons.math.linear.BigMatrix var6 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test59() {}
//   public void test59() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test59"); }
// 
// 
//     double[] var2 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var4 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var2, false);
//     double var5 = var4.getCurrentTime();
//     org.apache.commons.math.ode.sampling.StepInterpolator var6 = var4.copy();
//     var4.storeTime(Double.NaN);
//     java.io.ObjectInput var9 = null;
//     var4.readExternal(var9);
// 
//   }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test60"); }


    org.apache.commons.math.fraction.BigFractionField var0 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var1 = var0.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var2 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var1);
    org.apache.commons.math.fraction.BigFraction var4 = var1.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var6 = var1.subtract(10L);
    double var7 = var6.percentageValue();
    org.apache.commons.math.fraction.BigFraction var9 = var6.multiply(1);
    org.apache.commons.math.fraction.BigFractionField var10 = var6.getField();
    org.apache.commons.math.fraction.BigFractionField var11 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var12 = var11.getZero();
    org.apache.commons.math.fraction.BigFraction var13 = var11.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var16 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var11, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var17 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var18 = var17.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var19 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var18);
    var19.start(2147483647, 0, 100, (-10), 100, 0);
    org.apache.commons.math.FieldElement var27 = var16.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var19);
    org.apache.commons.math.fraction.BigFractionField var28 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var29 = var28.getZero();
    org.apache.commons.math.fraction.BigFraction var30 = var28.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var33 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var28, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var34 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var35 = var34.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var36 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var35);
    var36.start(2147483647, 0, 100, (-10), 100, 0);
    org.apache.commons.math.FieldElement var44 = var33.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var36);
    org.apache.commons.math.linear.BlockFieldMatrix var45 = var16.subtract(var33);
    org.apache.commons.math.fraction.BigFractionField var46 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var47 = var46.getZero();
    double var49 = var47.pow((-1.0d));
    org.apache.commons.math.fraction.BigFraction var50 = var47.abs();
    org.apache.commons.math.linear.FieldMatrix var51 = var45.scalarAdd((org.apache.commons.math.FieldElement)var50);
    org.apache.commons.math.linear.FieldMatrix var53 = var45.getColumnMatrix(0);
    org.apache.commons.math.fraction.BigFractionField var56 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var57 = var56.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var58 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var57);
    org.apache.commons.math.fraction.BigFraction var60 = var57.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var62 = var57.pow(2147483647);
    org.apache.commons.math.fraction.BigFraction var64 = var62.pow(0L);
    org.apache.commons.math.fraction.BigFraction var66 = var62.divide(1);
    org.apache.commons.math.fraction.BigFraction var68 = var66.divide((-1L));
    org.apache.commons.math.fraction.BigFractionField var69 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var70 = var69.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var71 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var70);
    org.apache.commons.math.fraction.BigFraction var73 = var70.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var75 = var70.subtract(10L);
    double var76 = var75.percentageValue();
    org.apache.commons.math.fraction.BigFraction var78 = var75.multiply(1);
    org.apache.commons.math.fraction.BigFractionField var79 = var75.getField();
    org.apache.commons.math.fraction.BigFraction var81 = var75.pow(10L);
    int var82 = var66.compareTo(var75);
    var45.multiplyEntry(0, 10, (org.apache.commons.math.FieldElement)var66);
    int var84 = var6.compareTo(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-1000.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == (-1000.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == (-1));

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test61"); }


    org.apache.commons.math.fraction.BigFractionField var0 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var1 = var0.getZero();
    org.apache.commons.math.fraction.BigFraction var2 = var0.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var5 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var0, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var6 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var7 = var6.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var8 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var7);
    var8.start(2147483647, 0, 100, (-10), 100, 0);
    org.apache.commons.math.FieldElement var16 = var5.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var8);
    org.apache.commons.math.fraction.BigFractionField var17 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var18 = var17.getZero();
    org.apache.commons.math.fraction.BigFraction var19 = var17.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var22 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var17, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var23 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var24 = var23.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var25 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var24);
    var25.start(2147483647, 0, 100, (-10), 100, 0);
    org.apache.commons.math.FieldElement var33 = var22.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var25);
    org.apache.commons.math.linear.BlockFieldMatrix var34 = var5.subtract(var22);
    org.apache.commons.math.fraction.BigFractionField var35 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var36 = var35.getZero();
    double var38 = var36.pow((-1.0d));
    org.apache.commons.math.fraction.BigFraction var39 = var36.abs();
    org.apache.commons.math.linear.FieldMatrix var40 = var34.scalarAdd((org.apache.commons.math.FieldElement)var39);
    org.apache.commons.math.Field var41 = var34.getField();
    org.apache.commons.math.linear.BlockFieldMatrix var44 = new org.apache.commons.math.linear.BlockFieldMatrix(var41, 2, 2);
    org.apache.commons.math.fraction.BigFractionField var45 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var46 = var45.getZero();
    double var48 = var46.pow((-1.0d));
    org.apache.commons.math.fraction.BigFraction var49 = var46.abs();
    int var50 = var46.getNumeratorAsInt();
    org.apache.commons.math.linear.FieldMatrix var51 = var44.scalarMultiply((org.apache.commons.math.FieldElement)var46);
    org.apache.commons.math.fraction.BigFractionField var52 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var53 = var52.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var54 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var53);
    org.apache.commons.math.fraction.BigFraction var56 = var53.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var58 = var53.subtract(10L);
    double var59 = var58.percentageValue();
    org.apache.commons.math.fraction.BigFraction var61 = var58.multiply(1);
    org.apache.commons.math.fraction.BigFractionField var62 = var58.getField();
    org.apache.commons.math.linear.Array2DRowFieldMatrix var63 = new org.apache.commons.math.linear.Array2DRowFieldMatrix((org.apache.commons.math.Field)var62);
    java.lang.String var64 = var63.toString();
    org.apache.commons.math.fraction.BigFractionField var65 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var66 = var65.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var67 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var66);
    org.apache.commons.math.fraction.BigFraction var69 = var66.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var71 = var66.pow(2147483647);
    org.apache.commons.math.fraction.BigFractionField var72 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var73 = var72.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var74 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var73);
    org.apache.commons.math.fraction.BigFraction var76 = var73.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var78 = var73.pow(2147483647);
    org.apache.commons.math.fraction.BigFraction var80 = var78.pow(0L);
    org.apache.commons.math.fraction.BigFraction var82 = var78.divide(1);
    java.math.BigInteger var83 = var78.getNumerator();
    org.apache.commons.math.fraction.BigFraction var84 = var66.pow(var83);
    org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor var85 = new org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor((org.apache.commons.math.FieldElement)var84);
    org.apache.commons.math.FieldElement var86 = var63.walkInColumnOrder((org.apache.commons.math.linear.FieldMatrixChangingVisitor)var85);
    org.apache.commons.math.FieldElement var89 = null;
    org.apache.commons.math.FieldElement var90 = var85.visit((-1), (-1000), var89);
    org.apache.commons.math.FieldElement var91 = var44.walkInColumnOrder((org.apache.commons.math.linear.FieldMatrixChangingVisitor)var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == (-1000.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var64 + "' != '" + "Array2DRowFieldMatrix{}"+ "'", var64.equals("Array2DRowFieldMatrix{}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test62"); }


    org.apache.commons.math.fraction.BigFraction var3 = new org.apache.commons.math.fraction.BigFraction((-0.1d), Double.POSITIVE_INFINITY, 11);
    java.math.BigInteger var4 = var3.getDenominator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test63"); }


    org.apache.commons.math.ode.events.EventHandler var0 = null;
    org.apache.commons.math.ode.events.EventState var4 = new org.apache.commons.math.ode.events.EventState(var0, 1.0E-15d, 10.0d, 100);
    org.apache.commons.math.ode.events.EventHandler var5 = var4.getEventHandler();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test64"); }


    org.apache.commons.math.fraction.BigFractionField var0 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var1 = var0.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var2 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var1);
    org.apache.commons.math.FieldElement[] var3 = new org.apache.commons.math.FieldElement[] { var1};
    org.apache.commons.math.linear.FieldMatrix var4 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createColumnFieldMatrix(var3);
    org.apache.commons.math.FieldElement[][] var5 = new org.apache.commons.math.FieldElement[][] { var3};
    org.apache.commons.math.linear.FieldMatrix var6 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldMatrix(var5);
    org.apache.commons.math.linear.FieldLUDecompositionImpl var7 = new org.apache.commons.math.linear.FieldLUDecompositionImpl(var6);
    int[] var8 = var7.getPivot();
    org.apache.commons.math.linear.FieldMatrix var9 = var7.getU();
    org.apache.commons.math.FieldElement var10 = var7.getDeterminant();
    org.apache.commons.math.linear.FieldMatrix var11 = var7.getP();
    org.apache.commons.math.FieldElement var12 = var7.getDeterminant();
    org.apache.commons.math.linear.FieldMatrix var13 = var7.getP();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test65"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var5 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(0, 1.0E-14d, Double.NaN, 10.0d, 2.147483647E9d);
      fail("Expected exception of type Exception");
    } catch (Exception e) {
      // Expected exception.
    }

  }

  public void test66() {}
//   public void test66() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test66"); }
// 
// 
//     org.apache.commons.math.fraction.BigFractionField var0 = org.apache.commons.math.fraction.BigFractionField.getInstance();
//     org.apache.commons.math.fraction.BigFraction var1 = var0.getZero();
//     org.apache.commons.math.fraction.BigFraction var2 = var0.getOne();
//     org.apache.commons.math.linear.BlockFieldMatrix var5 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var0, 10, 10);
//     org.apache.commons.math.fraction.BigFractionField var6 = org.apache.commons.math.fraction.BigFractionField.getInstance();
//     org.apache.commons.math.fraction.BigFraction var7 = var6.getZero();
//     org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var8 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var7);
//     var8.start(2147483647, 0, 100, (-10), 100, 0);
//     org.apache.commons.math.FieldElement var16 = var5.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var8);
//     org.apache.commons.math.fraction.BigFractionField var17 = org.apache.commons.math.fraction.BigFractionField.getInstance();
//     org.apache.commons.math.fraction.BigFraction var18 = var17.getZero();
//     org.apache.commons.math.fraction.BigFraction var19 = var17.getOne();
//     org.apache.commons.math.linear.BlockFieldMatrix var22 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var17, 10, 10);
//     org.apache.commons.math.fraction.BigFractionField var23 = org.apache.commons.math.fraction.BigFractionField.getInstance();
//     org.apache.commons.math.fraction.BigFraction var24 = var23.getZero();
//     org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var25 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var24);
//     var25.start(2147483647, 0, 100, (-10), 100, 0);
//     org.apache.commons.math.FieldElement var33 = var22.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var25);
//     org.apache.commons.math.linear.BlockFieldMatrix var34 = var5.subtract(var22);
//     org.apache.commons.math.fraction.BigFractionField var35 = org.apache.commons.math.fraction.BigFractionField.getInstance();
//     org.apache.commons.math.fraction.BigFraction var36 = var35.getZero();
//     double var38 = var36.pow((-1.0d));
//     org.apache.commons.math.fraction.BigFraction var39 = var36.abs();
//     org.apache.commons.math.linear.FieldMatrix var40 = var34.scalarAdd((org.apache.commons.math.FieldElement)var39);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var41 = org.apache.commons.math.linear.MatrixUtils.bigFractionMatrixToRealMatrix(var40);
//     org.apache.commons.math.linear.RealMatrixChangingVisitor var42 = null;
//     double var43 = var41.walkInColumnOrder(var42);
// 
//   }

  public void test67() {}
//   public void test67() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test67"); }
// 
// 
//     double[] var4 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var6 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var4, false);
//     double[][] var7 = new double[][] { var4};
//     org.apache.commons.math.linear.BlockRealMatrix var8 = new org.apache.commons.math.linear.BlockRealMatrix(var7);
//     org.apache.commons.math.MaxIterationsExceededException var9 = new org.apache.commons.math.MaxIterationsExceededException(0, "", (java.lang.Object[])var7);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var7, false);
//     double[] var16 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var18 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var16, false);
//     double[][] var19 = new double[][] { var16};
//     org.apache.commons.math.linear.BlockRealMatrix var20 = new org.apache.commons.math.linear.BlockRealMatrix(var19);
//     org.apache.commons.math.MaxIterationsExceededException var21 = new org.apache.commons.math.MaxIterationsExceededException(0, "", (java.lang.Object[])var19);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var23 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var19, false);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var24 = var11.subtract(var23);
//     org.apache.commons.math.linear.RealMatrix var27 = var24.createMatrix(10, 1);
//     double[] var31 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var33 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var31, false);
//     double var34 = var33.getCurrentTime();
//     double[] var35 = var33.getInterpolatedState();
//     org.apache.commons.math.linear.BigMatrix var36 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(var35);
//     double[][] var37 = new double[][] { var35};
//     org.apache.commons.math.linear.RealMatrix var38 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(var37);
//     org.apache.commons.math.linear.BlockRealMatrix var39 = new org.apache.commons.math.linear.BlockRealMatrix(var37);
//     org.apache.commons.math.ode.events.EventException var40 = new org.apache.commons.math.ode.events.EventException("BlockFieldMatrix{{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0}}", (java.lang.Object[])var37);
//     double[][] var41 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var37);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var24.setSubMatrix(var41, (-10), 100);
//       fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
//     } catch (org.apache.commons.math.linear.MatrixIndexException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
// 
//   }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test68"); }


    org.apache.commons.math.analysis.solvers.BrentSolver var0 = new org.apache.commons.math.analysis.solvers.BrentSolver();
    var0.setRelativeAccuracy(100.0d);
    double var3 = var0.getRelativeAccuracy();
    var0.resetMaximalIterationCount();
    double var5 = var0.getFunctionValueAccuracy();
    var0.resetMaximalIterationCount();
    var0.resetAbsoluteAccuracy();
    var0.resetMaximalIterationCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var11 = var0.solve(Double.POSITIVE_INFINITY, 1.0E-6d);
      fail("Expected exception of type Exception");
    } catch (Exception e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0E-15d);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test69"); }


    org.apache.commons.math.fraction.BigFractionField var0 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var1 = var0.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var2 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var1);
    org.apache.commons.math.fraction.BigFraction var4 = var1.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var6 = var1.subtract(10L);
    double var7 = var6.percentageValue();
    org.apache.commons.math.fraction.BigFraction var9 = var6.multiply(1);
    org.apache.commons.math.fraction.BigFractionField var10 = var6.getField();
    org.apache.commons.math.linear.Array2DRowFieldMatrix var11 = new org.apache.commons.math.linear.Array2DRowFieldMatrix((org.apache.commons.math.Field)var10);
    int var12 = var11.getRowDimension();
    org.apache.commons.math.FieldElement var13 = null;
    org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor var14 = new org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor(var13);
    org.apache.commons.math.FieldElement var15 = var11.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixChangingVisitor)var14);
    java.lang.String var16 = var11.toString();
    org.apache.commons.math.fraction.BigFractionField var17 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var18 = var17.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var19 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var18);
    org.apache.commons.math.fraction.BigFraction var21 = var18.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var23 = var18.subtract(10L);
    float var24 = var18.floatValue();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var25 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var18);
    org.apache.commons.math.fraction.BigFractionField var28 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var29 = var28.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var30 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var29);
    java.math.BigDecimal var31 = var29.bigDecimalValue();
    var25.visit(10, 0, (org.apache.commons.math.FieldElement)var29);
    var25.start(2147483647, (-1000), 2, (-10), 1, 10);
    org.apache.commons.math.FieldElement var40 = var11.walkInColumnOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var25);
    org.apache.commons.math.fraction.BigFractionField var43 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var44 = var43.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var45 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var44);
    org.apache.commons.math.fraction.BigFraction var47 = var44.subtract((-1L));
    long var48 = var44.getNumeratorAsLong();
    org.apache.commons.math.fraction.BigFraction var50 = var44.subtract(10);
    var25.visit(2147483647, 2, (org.apache.commons.math.FieldElement)var50);
    org.apache.commons.math.FieldElement var52 = var25.end();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-1000.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + "Array2DRowFieldMatrix{}"+ "'", var16.equals("Array2DRowFieldMatrix{}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);

  }

  public void test70() {}
//   public void test70() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test70"); }
// 
// 
//     org.apache.commons.math.ode.events.CombinedEventsManager var0 = new org.apache.commons.math.ode.events.CombinedEventsManager();
//     java.util.Collection var1 = var0.getEventsHandlers();
//     boolean var2 = var0.isEmpty();
//     org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var3 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator();
//     double[] var6 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var8 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var6, false);
//     double[][] var9 = new double[][] { var6};
//     org.apache.commons.math.linear.BlockRealMatrix var10 = new org.apache.commons.math.linear.BlockRealMatrix(var9);
//     double[] var13 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var15 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var13, false);
//     double[] var16 = var15.getInterpolatedState();
//     double[] var17 = var10.operate(var16);
//     var3.reinitialize(var17, true);
//     org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var20 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator(var3);
//     var3.setInterpolatedTime(0.0d);
//     boolean var23 = var0.evaluateStep((org.apache.commons.math.ode.sampling.StepInterpolator)var3);
//     var3.finalizeStep();
//     org.apache.commons.math.fraction.BigFractionField var27 = org.apache.commons.math.fraction.BigFractionField.getInstance();
//     org.apache.commons.math.fraction.BigFraction var28 = var27.getZero();
//     org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var29 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var28);
//     org.apache.commons.math.fraction.BigFraction var31 = var28.subtract((-1L));
//     org.apache.commons.math.fraction.BigFraction var33 = var28.subtract(10L);
//     double var34 = var33.percentageValue();
//     org.apache.commons.math.fraction.BigFraction var36 = var33.multiply(1);
//     org.apache.commons.math.fraction.BigFractionField var37 = var33.getField();
//     org.apache.commons.math.linear.Array2DRowFieldMatrix var38 = new org.apache.commons.math.linear.Array2DRowFieldMatrix((org.apache.commons.math.Field)var37);
//     org.apache.commons.math.fraction.BigFractionField var39 = org.apache.commons.math.fraction.BigFractionField.getInstance();
//     org.apache.commons.math.fraction.BigFraction var40 = var39.getZero();
//     org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var41 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var40);
//     org.apache.commons.math.FieldElement var42 = var38.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var41);
//     java.lang.Object[] var43 = new java.lang.Object[] { var42};
//     org.apache.commons.math.FunctionEvaluationException var44 = new org.apache.commons.math.FunctionEvaluationException((-10.0d), "Maximal number of iterations ({0}) exceeded", var43);
//     double[] var45 = var44.getArgument();
//     org.apache.commons.math.linear.BigMatrix var46 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(var45);
//     var3.reinitialize(var45, true);
//     java.io.ObjectOutput var49 = null;
//     var3.writeExternal(var49);
// 
//   }

  public void test71() {}
//   public void test71() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test71"); }
// 
// 
//     org.apache.commons.math.fraction.BigFractionField var0 = org.apache.commons.math.fraction.BigFractionField.getInstance();
//     org.apache.commons.math.fraction.BigFraction var1 = var0.getZero();
//     org.apache.commons.math.fraction.BigFraction var2 = var0.getOne();
//     org.apache.commons.math.linear.BlockFieldMatrix var5 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var0, 10, 10);
//     org.apache.commons.math.fraction.BigFractionField var6 = org.apache.commons.math.fraction.BigFractionField.getInstance();
//     org.apache.commons.math.fraction.BigFraction var7 = var6.getZero();
//     org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var8 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var7);
//     var8.start(2147483647, 0, 100, (-10), 100, 0);
//     org.apache.commons.math.FieldElement var16 = var5.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var8);
//     org.apache.commons.math.fraction.BigFractionField var17 = org.apache.commons.math.fraction.BigFractionField.getInstance();
//     org.apache.commons.math.fraction.BigFraction var18 = var17.getZero();
//     org.apache.commons.math.fraction.BigFraction var19 = var17.getOne();
//     org.apache.commons.math.linear.BlockFieldMatrix var22 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var17, 10, 10);
//     org.apache.commons.math.fraction.BigFractionField var23 = org.apache.commons.math.fraction.BigFractionField.getInstance();
//     org.apache.commons.math.fraction.BigFraction var24 = var23.getZero();
//     org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var25 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var24);
//     var25.start(2147483647, 0, 100, (-10), 100, 0);
//     org.apache.commons.math.FieldElement var33 = var22.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var25);
//     org.apache.commons.math.linear.BlockFieldMatrix var34 = var5.subtract(var22);
//     org.apache.commons.math.fraction.BigFractionField var35 = org.apache.commons.math.fraction.BigFractionField.getInstance();
//     org.apache.commons.math.fraction.BigFraction var36 = var35.getZero();
//     org.apache.commons.math.fraction.BigFraction var37 = var35.getOne();
//     org.apache.commons.math.linear.BlockFieldMatrix var40 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var35, 10, 10);
//     org.apache.commons.math.fraction.BigFractionField var41 = org.apache.commons.math.fraction.BigFractionField.getInstance();
//     org.apache.commons.math.fraction.BigFraction var42 = var41.getZero();
//     org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var43 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var42);
//     var43.start(2147483647, 0, 100, (-10), 100, 0);
//     org.apache.commons.math.FieldElement var51 = var40.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var43);
//     org.apache.commons.math.linear.BlockFieldMatrix var52 = var34.multiply(var40);
//     org.apache.commons.math.fraction.BigFractionField var53 = org.apache.commons.math.fraction.BigFractionField.getInstance();
//     org.apache.commons.math.fraction.BigFraction var54 = var53.getZero();
//     org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var55 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var54);
//     org.apache.commons.math.fraction.BigFraction var57 = var54.subtract((-1L));
//     org.apache.commons.math.fraction.BigFraction var59 = var54.subtract(10L);
//     double var60 = var59.percentageValue();
//     org.apache.commons.math.fraction.BigFraction var62 = var59.multiply(1);
//     org.apache.commons.math.fraction.BigFractionField var63 = var59.getField();
//     org.apache.commons.math.linear.Array2DRowFieldMatrix var64 = new org.apache.commons.math.linear.Array2DRowFieldMatrix((org.apache.commons.math.Field)var63);
//     int var65 = var64.getRowDimension();
//     org.apache.commons.math.FieldElement var66 = null;
//     org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor var67 = new org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor(var66);
//     org.apache.commons.math.FieldElement var68 = var64.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixChangingVisitor)var67);
//     org.apache.commons.math.FieldElement var69 = var52.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixChangingVisitor)var67);
//     org.apache.commons.math.fraction.BigFractionField var72 = org.apache.commons.math.fraction.BigFractionField.getInstance();
//     org.apache.commons.math.fraction.BigFraction var73 = var72.getZero();
//     org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var74 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var73);
//     org.apache.commons.math.fraction.BigFraction var76 = var73.subtract((-1L));
//     org.apache.commons.math.fraction.BigFraction var78 = var73.subtract(10L);
//     double var79 = var78.percentageValue();
//     int var80 = var78.getNumeratorAsInt();
//     org.apache.commons.math.fraction.BigFraction var82 = var78.add((-1));
//     org.apache.commons.math.FieldElement var83 = var67.visit(0, (-1), (org.apache.commons.math.FieldElement)var82);
//     org.apache.commons.math.fraction.BigFractionField var86 = org.apache.commons.math.fraction.BigFractionField.getInstance();
//     org.apache.commons.math.fraction.BigFraction var87 = var86.getZero();
//     org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var88 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var87);
//     org.apache.commons.math.FieldElement var89 = var67.visit(8, 1, (org.apache.commons.math.FieldElement)var87);
//     java.io.ObjectInputStream var91 = null;
//     org.apache.commons.math.linear.MatrixUtils.deserializeRealMatrix((java.lang.Object)8, "org.apache.commons.math.ode.events.EventException: ", var91);
// 
//   }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test72"); }


    double[] var2 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var4 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var2, false);
    double[][] var5 = new double[][] { var2};
    org.apache.commons.math.linear.BlockRealMatrix var6 = new org.apache.commons.math.linear.BlockRealMatrix(var5);
    org.apache.commons.math.linear.RealMatrix var8 = var6.scalarMultiply(10.0d);
    double[] var10 = var6.getRow(0);
    org.apache.commons.math.linear.Array2DRowRealMatrix var11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var10);
    org.apache.commons.math.analysis.solvers.BrentSolver var12 = new org.apache.commons.math.analysis.solvers.BrentSolver();
    var12.setRelativeAccuracy(100.0d);
    double var15 = var12.getRelativeAccuracy();
    var12.resetMaximalIterationCount();
    double var17 = var12.getFunctionValueAccuracy();
    var12.resetMaximalIterationCount();
    var12.resetAbsoluteAccuracy();
    var12.resetMaximalIterationCount();
    boolean var21 = var11.equals((java.lang.Object)var12);
    int var22 = var12.getMaximalIterationCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1.0E-15d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 100);

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test73"); }


    org.apache.commons.math.fraction.BigFractionField var0 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var1 = var0.getZero();
    double var3 = var1.pow((-1.0d));
    org.apache.commons.math.fraction.BigFraction var4 = var1.abs();
    java.math.BigDecimal var7 = var4.bigDecimalValue(2147483647, 1);
    int var8 = var4.getNumeratorAsInt();
    org.apache.commons.math.fraction.BigFractionField var9 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var10 = var9.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var11 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var10);
    java.math.BigDecimal var12 = var10.bigDecimalValue();
    java.lang.String var13 = var10.toString();
    java.lang.String var14 = var10.toString();
    int var15 = var4.compareTo(var10);
    long var16 = var4.getDenominatorAsLong();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "0"+ "'", var13.equals("0"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "0"+ "'", var14.equals("0"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1L);

  }

  public void test74() {}
//   public void test74() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test74"); }
// 
// 
//     org.apache.commons.math.ode.events.CombinedEventsManager var0 = new org.apache.commons.math.ode.events.CombinedEventsManager();
//     boolean var1 = var0.stop();
//     double[] var5 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var7 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var5, false);
//     double[][] var8 = new double[][] { var5};
//     org.apache.commons.math.linear.BlockRealMatrix var9 = new org.apache.commons.math.linear.BlockRealMatrix(var8);
//     org.apache.commons.math.linear.BlockRealMatrix var11 = var9.getColumnMatrix(1);
//     double[] var14 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var16 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var14, false);
//     double var17 = var16.getCurrentTime();
//     double[] var18 = var16.getInterpolatedState();
//     double[] var19 = var9.operate(var18);
//     org.apache.commons.math.FunctionEvaluationException var20 = new org.apache.commons.math.FunctionEvaluationException(var18);
//     boolean var21 = var0.reset(1.0E-15d, var18);
//     double[] var24 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var26 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var24, false);
//     org.apache.commons.math.FunctionEvaluationException var27 = new org.apache.commons.math.FunctionEvaluationException(var24);
//     org.apache.commons.math.fraction.FractionConversionException var30 = new org.apache.commons.math.fraction.FractionConversionException(0.0d, (-1));
//     java.lang.Object[] var36 = new java.lang.Object[] { 0L};
//     java.text.ParseException var37 = org.apache.commons.math.MathRuntimeException.createParseException((-1), "", var36);
//     org.apache.commons.math.FunctionEvaluationException var38 = new org.apache.commons.math.FunctionEvaluationException(100.0d, "", var36);
//     double[] var39 = var38.getArgument();
//     org.apache.commons.math.FunctionEvaluationException var40 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable)var30, var39);
//     org.apache.commons.math.FunctionEvaluationException var41 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable)var27, var39);
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var43 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var39, false);
//     boolean var44 = var0.evaluateStep((org.apache.commons.math.ode.sampling.StepInterpolator)var43);
//     java.util.Collection var45 = var0.getEventsStates();
//     double var46 = var0.getEventTime();
//     double var47 = var0.getEventTime();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == Double.NaN);
// 
//   }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test75"); }


    java.lang.Object[] var5 = new java.lang.Object[] { 0L};
    org.apache.commons.math.MaxEvaluationsExceededException var6 = new org.apache.commons.math.MaxEvaluationsExceededException(100, "", var5);
    org.apache.commons.math.ode.DerivativeException var7 = new org.apache.commons.math.ode.DerivativeException("2147483647", var5);
    org.apache.commons.math.linear.InvalidMatrixException var8 = new org.apache.commons.math.linear.InvalidMatrixException("0", var5);
    org.apache.commons.math.linear.InvalidMatrixException var9 = new org.apache.commons.math.linear.InvalidMatrixException((java.lang.Throwable)var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test76"); }


    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var4 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(0.0d, (-1.0d), 10.0d, 100.0d);
    int var5 = var4.getMaxEvaluations();
    var4.setSafety(1.0d);
    double var8 = var4.getMaxGrowth();
    var4.clearEventHandlers();
    var4.clearEventHandlers();
    int var11 = var4.getOrder();
    int var12 = var4.getOrder();
    int var13 = var4.getOrder();
    var4.clearEventHandlers();
    var4.setMinReduction(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 8);

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test77"); }


    org.apache.commons.math.fraction.BigFractionField var0 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var1 = var0.getZero();
    org.apache.commons.math.fraction.BigFraction var2 = var0.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var5 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var0, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var6 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var7 = var6.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var8 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var7);
    var8.start(2147483647, 0, 100, (-10), 100, 0);
    org.apache.commons.math.FieldElement var16 = var5.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var8);
    org.apache.commons.math.fraction.BigFractionField var17 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var18 = var17.getZero();
    org.apache.commons.math.fraction.BigFraction var19 = var17.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var22 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var17, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var23 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var24 = var23.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var25 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var24);
    var25.start(2147483647, 0, 100, (-10), 100, 0);
    org.apache.commons.math.FieldElement var33 = var22.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var25);
    org.apache.commons.math.linear.BlockFieldMatrix var34 = var5.subtract(var22);
    org.apache.commons.math.fraction.BigFractionField var35 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var36 = var35.getZero();
    double var38 = var36.pow((-1.0d));
    org.apache.commons.math.fraction.BigFraction var39 = var36.abs();
    org.apache.commons.math.linear.FieldMatrix var40 = var34.scalarAdd((org.apache.commons.math.FieldElement)var39);
    org.apache.commons.math.Field var41 = var34.getField();
    org.apache.commons.math.fraction.BigFractionField var42 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var43 = var42.getZero();
    org.apache.commons.math.fraction.BigFraction var44 = var42.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var47 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var42, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var48 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var49 = var48.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var50 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var49);
    org.apache.commons.math.fraction.BigFraction var52 = var49.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var54 = var49.subtract(10L);
    double var55 = var54.percentageValue();
    org.apache.commons.math.fraction.BigFraction var57 = var54.multiply(1);
    org.apache.commons.math.fraction.BigFractionField var58 = var54.getField();
    org.apache.commons.math.linear.Array2DRowFieldMatrix var59 = new org.apache.commons.math.linear.Array2DRowFieldMatrix((org.apache.commons.math.Field)var58);
    boolean var60 = var59.isSquare();
    org.apache.commons.math.fraction.BigFractionField var61 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var62 = var61.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var63 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var62);
    org.apache.commons.math.FieldElement var64 = var59.walkInColumnOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var63);
    org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor var65 = new org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor(var64);
    org.apache.commons.math.FieldElement var66 = var47.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixChangingVisitor)var65);
    org.apache.commons.math.linear.FieldMatrix var67 = var34.subtract((org.apache.commons.math.linear.FieldMatrix)var47);
    int var68 = var47.getRowDimension();
    java.lang.String var69 = var47.toString();
    org.apache.commons.math.Field var70 = var47.getField();
    int var71 = var47.getRowDimension();
    org.apache.commons.math.linear.FieldMatrix var72 = var47.transpose();
    org.apache.commons.math.FieldElement[] var74 = var47.getRow(0);
    org.apache.commons.math.fraction.BigFractionField var75 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var76 = var75.getZero();
    org.apache.commons.math.fraction.BigFraction var77 = var75.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var80 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var75, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var81 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var82 = var81.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var83 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var82);
    var83.start(2147483647, 0, 100, (-10), 100, 0);
    org.apache.commons.math.FieldElement var91 = var80.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var83);
    int var92 = var80.getColumnDimension();
    java.lang.String var93 = var80.toString();
    org.apache.commons.math.linear.BlockFieldMatrix var94 = var47.subtract(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == (-1000.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var69 + "' != '" + "BlockFieldMatrix{{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0}}"+ "'", var69.equals("BlockFieldMatrix{{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var93 + "' != '" + "BlockFieldMatrix{{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0}}"+ "'", var93.equals("BlockFieldMatrix{{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test78"); }


    org.apache.commons.math.fraction.BigFractionField var0 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var1 = var0.getZero();
    org.apache.commons.math.fraction.BigFraction var2 = var0.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var5 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var0, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var6 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var7 = var6.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var8 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var7);
    var8.start(2147483647, 0, 100, (-10), 100, 0);
    org.apache.commons.math.FieldElement var16 = var5.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var8);
    org.apache.commons.math.fraction.BigFractionField var17 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var18 = var17.getZero();
    org.apache.commons.math.fraction.BigFraction var19 = var17.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var22 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var17, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var23 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var24 = var23.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var25 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var24);
    var25.start(2147483647, 0, 100, (-10), 100, 0);
    org.apache.commons.math.FieldElement var33 = var22.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var25);
    org.apache.commons.math.linear.BlockFieldMatrix var34 = var5.subtract(var22);
    org.apache.commons.math.fraction.BigFractionField var35 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var36 = var35.getZero();
    org.apache.commons.math.fraction.BigFraction var37 = var35.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var40 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var35, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var41 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var42 = var41.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var43 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var42);
    var43.start(2147483647, 0, 100, (-10), 100, 0);
    org.apache.commons.math.FieldElement var51 = var40.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var43);
    org.apache.commons.math.linear.BlockFieldMatrix var52 = var34.multiply(var40);
    boolean var53 = var52.isSquare();
    org.apache.commons.math.fraction.BigFractionField var54 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var55 = var54.getZero();
    org.apache.commons.math.fraction.BigFraction var56 = var54.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var59 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var54, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var60 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var61 = var60.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var62 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var61);
    var62.start(2147483647, 0, 100, (-10), 100, 0);
    org.apache.commons.math.FieldElement var70 = var59.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var62);
    int var71 = var59.getColumnDimension();
    java.lang.String var72 = var59.toString();
    org.apache.commons.math.linear.BlockFieldMatrix var73 = var52.add(var59);
    org.apache.commons.math.FieldElement var74 = var73.getTrace();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var72 + "' != '" + "BlockFieldMatrix{{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0}}"+ "'", var72.equals("BlockFieldMatrix{{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test79"); }


    org.apache.commons.math.fraction.BigFractionField var0 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var1 = var0.getZero();
    org.apache.commons.math.fraction.BigFraction var2 = var0.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var5 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var0, 10, 10);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var6 = new org.apache.commons.math.linear.Array2DRowFieldMatrix((org.apache.commons.math.Field)var0);
    int var7 = var6.getColumnDimension();
    org.apache.commons.math.fraction.BigFractionField var9 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var10 = var9.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var11 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var10);
    org.apache.commons.math.fraction.BigFraction var13 = var10.subtract((-1L));
    org.apache.commons.math.FieldElement[] var14 = new org.apache.commons.math.FieldElement[] { var10};
    org.apache.commons.math.linear.FieldMatrix var15 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var14);
    org.apache.commons.math.linear.FieldMatrix var16 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var14);
    org.apache.commons.math.linear.FieldVector var17 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var14);
    org.apache.commons.math.linear.FieldMatrix var18 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createRowFieldMatrix(var14);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var19 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var14);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setRow(8, var14);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test80"); }


    org.apache.commons.math.fraction.BigFractionField var0 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var1 = var0.getZero();
    org.apache.commons.math.fraction.BigFraction var2 = var0.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var5 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var0, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var6 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var7 = var6.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var8 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var7);
    var8.start(2147483647, 0, 100, (-10), 100, 0);
    org.apache.commons.math.FieldElement var16 = var5.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var8);
    org.apache.commons.math.linear.FieldVector var18 = var5.getRowVector(2);
    org.apache.commons.math.Field var19 = var5.getField();
    org.apache.commons.math.FieldElement[] var21 = var5.getRow(1);
    int var22 = var5.getColumnDimension();
    org.apache.commons.math.linear.FieldMatrix var23 = var5.copy();
    int var24 = var5.getRowDimension();
    java.lang.Object[] var26 = null;
    org.apache.commons.math.MathRuntimeException var27 = new org.apache.commons.math.MathRuntimeException("hi!", var26);
    org.apache.commons.math.MathException var28 = new org.apache.commons.math.MathException((java.lang.Throwable)var27);
    java.lang.String var29 = var27.toString();
    org.apache.commons.math.ode.DerivativeException var30 = new org.apache.commons.math.ode.DerivativeException((java.lang.Throwable)var27);
    org.apache.commons.math.linear.InvalidMatrixException var31 = new org.apache.commons.math.linear.InvalidMatrixException((java.lang.Throwable)var30);
    boolean var32 = var5.equals((java.lang.Object)var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var29 + "' != '" + "org.apache.commons.math.MathRuntimeException: hi!"+ "'", var29.equals("org.apache.commons.math.MathRuntimeException: hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test81"); }


    double[] var4 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var6 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var4, false);
    double[][] var7 = new double[][] { var4};
    org.apache.commons.math.linear.BlockRealMatrix var8 = new org.apache.commons.math.linear.BlockRealMatrix(var7);
    org.apache.commons.math.MaxIterationsExceededException var9 = new org.apache.commons.math.MaxIterationsExceededException(0, "", (java.lang.Object[])var7);
    org.apache.commons.math.linear.Array2DRowRealMatrix var11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var7, false);
    boolean var12 = var11.isSquare();
    int var13 = var11.getColumnDimension();
    double[][] var14 = var11.getDataRef();
    org.apache.commons.math.linear.RealMatrix var15 = var11.copy();
    org.apache.commons.math.linear.RealMatrixChangingVisitor var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var21 = var11.walkInRowOrder(var16, 2147483646, (-1), (-10), (-9));
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test82"); }


    org.apache.commons.math.ode.events.EventHandler var0 = null;
    org.apache.commons.math.ode.events.EventState var4 = new org.apache.commons.math.ode.events.EventState(var0, 1.0E100d, 1.0d, 100);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test83"); }


    java.lang.Object[] var10 = new java.lang.Object[] { 0L};
    org.apache.commons.math.MaxEvaluationsExceededException var11 = new org.apache.commons.math.MaxEvaluationsExceededException(100, "", var10);
    org.apache.commons.math.MathException var12 = new org.apache.commons.math.MathException("matrix is singular", var10);
    java.lang.ArrayIndexOutOfBoundsException var13 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("hi!", var10);
    java.lang.ArithmeticException var14 = org.apache.commons.math.MathRuntimeException.createArithmeticException("Overflow trying to convert {0} to fraction ({1}/{2})", var10);
    java.text.ParseException var15 = org.apache.commons.math.MathRuntimeException.createParseException((-10), "Overflow trying to convert {0} to fraction ({1}/{2})", var10);
    org.apache.commons.math.MaxEvaluationsExceededException var16 = new org.apache.commons.math.MaxEvaluationsExceededException(0, "Array2DRowRealMatrix{{0.0,0.0}}", var10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math.ode.events.EventException var17 = new org.apache.commons.math.ode.events.EventException((java.lang.Throwable)var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test84"); }


    org.apache.commons.math.fraction.BigFractionField var0 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var1 = var0.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var2 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var1);
    org.apache.commons.math.fraction.BigFraction var4 = var1.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var6 = var1.subtract(10L);
    double var7 = var6.percentageValue();
    org.apache.commons.math.fraction.BigFraction var9 = var6.multiply(1);
    org.apache.commons.math.fraction.BigFractionField var10 = var6.getField();
    org.apache.commons.math.linear.Array2DRowFieldMatrix var11 = new org.apache.commons.math.linear.Array2DRowFieldMatrix((org.apache.commons.math.Field)var10);
    int var12 = var11.getRowDimension();
    org.apache.commons.math.FieldElement var13 = null;
    org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor var14 = new org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor(var13);
    org.apache.commons.math.FieldElement var15 = var11.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixChangingVisitor)var14);
    java.lang.String var16 = var11.toString();
    org.apache.commons.math.fraction.BigFractionField var18 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var19 = var18.getZero();
    org.apache.commons.math.fraction.BigFraction var20 = var18.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var23 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var18, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var24 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var25 = var24.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var26 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var25);
    var26.start(2147483647, 0, 100, (-10), 100, 0);
    org.apache.commons.math.FieldElement var34 = var23.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var26);
    org.apache.commons.math.fraction.BigFractionField var35 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var36 = var35.getZero();
    org.apache.commons.math.fraction.BigFraction var37 = var35.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var40 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var35, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var41 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var42 = var41.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var43 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var42);
    var43.start(2147483647, 0, 100, (-10), 100, 0);
    org.apache.commons.math.FieldElement var51 = var40.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var43);
    org.apache.commons.math.linear.BlockFieldMatrix var52 = var23.subtract(var40);
    org.apache.commons.math.fraction.BigFractionField var53 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var54 = var53.getZero();
    double var56 = var54.pow((-1.0d));
    org.apache.commons.math.fraction.BigFraction var57 = var54.abs();
    org.apache.commons.math.linear.FieldMatrix var58 = var52.scalarAdd((org.apache.commons.math.FieldElement)var57);
    org.apache.commons.math.linear.FieldVector var60 = var52.getRowVector(2);
    org.apache.commons.math.linear.FieldMatrix var61 = var52.copy();
    org.apache.commons.math.FieldElement[][] var62 = var52.getData();
    org.apache.commons.math.linear.Array2DRowFieldMatrix var63 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var62);
    java.util.NoSuchElementException var64 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", (java.lang.Object[])var62);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.setSubMatrix(var62, 0, (-10));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-1000.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + "Array2DRowFieldMatrix{}"+ "'", var16.equals("Array2DRowFieldMatrix{}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test85"); }


    org.apache.commons.math.MaxEvaluationsExceededException var1 = new org.apache.commons.math.MaxEvaluationsExceededException((-1));
    org.apache.commons.math.linear.InvalidMatrixException var2 = new org.apache.commons.math.linear.InvalidMatrixException((java.lang.Throwable)var1);
    java.lang.Object[] var4 = null;
    org.apache.commons.math.MathException var5 = new org.apache.commons.math.MathException((java.lang.Throwable)var2, "", var4);
    java.lang.Object[] var8 = null;
    org.apache.commons.math.ConvergenceException var9 = new org.apache.commons.math.ConvergenceException("Maximal number of iterations ({0}) exceeded", var8);
    java.lang.Object[] var10 = var9.getArguments();
    org.apache.commons.math.ConvergenceException var11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable)var5, "org.apache.commons.math.MathRuntimeException$10: internal error, please fill a bug report at https://issues.apache.org/jira/browse/MATH", var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test86"); }


    double[] var2 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var4 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var2, false);
    double[] var5 = var4.getInterpolatedDerivatives();
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var6 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var4);
    var4.shift();
    var4.shift();
    boolean var9 = var4.isForward();
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var10 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test87"); }


    org.apache.commons.math.fraction.BigFractionField var0 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var1 = var0.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var2 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var1);
    org.apache.commons.math.FieldElement[] var3 = new org.apache.commons.math.FieldElement[] { var1};
    org.apache.commons.math.linear.FieldMatrix var4 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createColumnFieldMatrix(var3);
    org.apache.commons.math.FieldElement[][] var5 = new org.apache.commons.math.FieldElement[][] { var3};
    org.apache.commons.math.linear.FieldMatrix var6 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldMatrix(var5);
    org.apache.commons.math.linear.FieldLUDecompositionImpl var7 = new org.apache.commons.math.linear.FieldLUDecompositionImpl(var6);
    int[] var8 = var7.getPivot();
    org.apache.commons.math.linear.FieldMatrix var9 = var7.getU();
    org.apache.commons.math.linear.FieldMatrix var10 = var7.getP();
    org.apache.commons.math.linear.FieldMatrix var11 = var7.getL();
    org.apache.commons.math.linear.FieldMatrix var12 = var7.getL();
    int[] var13 = var7.getPivot();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test88() {}
//   public void test88() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test88"); }
// 
// 
//     org.apache.commons.math.ode.events.CombinedEventsManager var0 = new org.apache.commons.math.ode.events.CombinedEventsManager();
//     java.util.Collection var1 = var0.getEventsHandlers();
//     boolean var2 = var0.isEmpty();
//     org.apache.commons.math.ode.events.CombinedEventsManager var3 = new org.apache.commons.math.ode.events.CombinedEventsManager();
//     double[] var7 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var9 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var7, false);
//     double[][] var10 = new double[][] { var7};
//     org.apache.commons.math.linear.BlockRealMatrix var11 = new org.apache.commons.math.linear.BlockRealMatrix(var10);
//     double[] var14 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var16 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var14, false);
//     double[] var17 = var16.getInterpolatedState();
//     double[] var18 = var11.operate(var17);
//     boolean var19 = var3.reset(1.0E-6d, var18);
//     boolean var20 = var3.stop();
//     double[] var23 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var25 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var23, false);
//     double var26 = var25.getCurrentTime();
//     double[] var27 = var25.getInterpolatedState();
//     double[] var28 = var25.getInterpolatedDerivatives();
//     boolean var29 = var3.evaluateStep((org.apache.commons.math.ode.sampling.StepInterpolator)var25);
//     boolean var30 = var0.evaluateStep((org.apache.commons.math.ode.sampling.StepInterpolator)var25);
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var31 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var25);
//     org.apache.commons.math.ode.sampling.StepInterpolator var32 = var25.copy();
//     var25.storeTime(100.0d);
//     var25.shift();
//     java.io.ObjectOutput var36 = null;
//     var25.writeExternal(var36);
// 
//   }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test89"); }


    org.apache.commons.math.fraction.BigFractionField var0 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var1 = var0.getZero();
    org.apache.commons.math.fraction.BigFraction var2 = var0.getOne();
    org.apache.commons.math.fraction.BigFraction var3 = var2.abs();
    org.apache.commons.math.fraction.BigFraction var5 = var3.subtract(8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test90"); }


    org.apache.commons.math.FunctionEvaluationException var1 = new org.apache.commons.math.FunctionEvaluationException(0.9d);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test91"); }


    java.lang.String[] var2 = new java.lang.String[] { "0"};
    org.apache.commons.math.linear.BigMatrix var3 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(var2);
    org.apache.commons.math.linear.BigMatrix var4 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(var2);
    org.apache.commons.math.linear.BigMatrix var5 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(var2);
    org.apache.commons.math.ode.events.EventException var6 = new org.apache.commons.math.ode.events.EventException("org.apache.commons.math.MathRuntimeException: hi!", (java.lang.Object[])var2);
    org.apache.commons.math.MathRuntimeException var7 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable)var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test92"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math.linear.Array2DRowRealMatrix var2 = new org.apache.commons.math.linear.Array2DRowRealMatrix(2147483646, 8);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test93"); }


    org.apache.commons.math.fraction.BigFractionField var0 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var1 = var0.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var2 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var1);
    org.apache.commons.math.fraction.BigFraction var4 = var1.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var6 = var1.subtract(10L);
    double var7 = var6.percentageValue();
    org.apache.commons.math.fraction.BigFraction var9 = var6.multiply(1);
    org.apache.commons.math.fraction.BigFractionField var10 = var6.getField();
    org.apache.commons.math.linear.Array2DRowFieldMatrix var11 = new org.apache.commons.math.linear.Array2DRowFieldMatrix((org.apache.commons.math.Field)var10);
    boolean var12 = var11.isSquare();
    org.apache.commons.math.fraction.BigFractionField var13 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var14 = var13.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var15 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var14);
    org.apache.commons.math.fraction.BigFraction var17 = var14.subtract((-1L));
    org.apache.commons.math.FieldElement[] var18 = new org.apache.commons.math.FieldElement[] { var14};
    org.apache.commons.math.linear.FieldMatrix var19 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var18);
    org.apache.commons.math.FieldElement[][] var20 = new org.apache.commons.math.FieldElement[][] { var18};
    org.apache.commons.math.linear.Array2DRowFieldMatrix var21 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var20);
    org.apache.commons.math.fraction.BigFractionField var23 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var24 = var23.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var25 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var24);
    org.apache.commons.math.fraction.BigFraction var27 = var24.subtract((-1L));
    org.apache.commons.math.FieldElement[] var28 = new org.apache.commons.math.FieldElement[] { var24};
    org.apache.commons.math.linear.FieldMatrix var29 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var28);
    java.io.EOFException var30 = org.apache.commons.math.MathRuntimeException.createEOFException("java.io.IOException: ", (java.lang.Object[])var28);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var31 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var28);
    org.apache.commons.math.fraction.BigFractionField var32 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var33 = var32.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var34 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var33);
    org.apache.commons.math.fraction.BigFraction var36 = var33.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var38 = var33.subtract(10L);
    double var39 = var38.percentageValue();
    org.apache.commons.math.fraction.BigFraction var41 = var38.multiply(1);
    org.apache.commons.math.fraction.BigFractionField var42 = var38.getField();
    org.apache.commons.math.linear.Array2DRowFieldMatrix var43 = new org.apache.commons.math.linear.Array2DRowFieldMatrix((org.apache.commons.math.Field)var42);
    int var44 = var43.getRowDimension();
    org.apache.commons.math.FieldElement var45 = null;
    org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor var46 = new org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor(var45);
    org.apache.commons.math.FieldElement var47 = var43.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixChangingVisitor)var46);
    org.apache.commons.math.FieldElement[][] var48 = var43.getDataRef();
    org.apache.commons.math.fraction.BigFractionField var49 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var50 = var49.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var51 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var50);
    org.apache.commons.math.fraction.BigFraction var53 = var50.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var55 = var50.subtract(10L);
    double var56 = var55.percentageValue();
    org.apache.commons.math.fraction.BigFraction var58 = var55.multiply(1);
    org.apache.commons.math.fraction.BigFractionField var59 = var55.getField();
    org.apache.commons.math.linear.Array2DRowFieldMatrix var60 = new org.apache.commons.math.linear.Array2DRowFieldMatrix((org.apache.commons.math.Field)var59);
    boolean var61 = var60.isSquare();
    org.apache.commons.math.fraction.BigFractionField var62 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var63 = var62.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var64 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var63);
    org.apache.commons.math.FieldElement var65 = var60.walkInColumnOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var64);
    boolean var66 = var43.equals((java.lang.Object)var64);
    org.apache.commons.math.FieldElement var67 = var31.walkInColumnOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var64);
    org.apache.commons.math.FieldElement var68 = var21.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var64);
    org.apache.commons.math.FieldElement var69 = var11.walkInColumnOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var64);
    double[] var72 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var74 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var72, false);
    double[][] var75 = new double[][] { var72};
    org.apache.commons.math.linear.BlockRealMatrix var76 = new org.apache.commons.math.linear.BlockRealMatrix(var75);
    double[] var79 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var81 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var79, false);
    double[] var82 = var81.getInterpolatedState();
    double[] var83 = var76.operate(var82);
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var85 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var83, false);
    double[] var86 = var85.getInterpolatedDerivatives();
    org.apache.commons.math.FunctionEvaluationException var87 = new org.apache.commons.math.FunctionEvaluationException(var86);
    boolean var88 = var11.equals((java.lang.Object)var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-1000.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == (-1000.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == (-1000.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == false);

  }

//  public void test94() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest10.test94"); }
//
//
//    // The following exception was thrown during execution.
//    // This behavior will recorded for regression testing.
//    try {
//      double[][] var2 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(2147483647, (-1000));
//      fail("Expected exception of type java.lang.OutOfMemoryError");
//    } catch (java.lang.OutOfMemoryError e) {
//      // Expected exception.
//    }
//
//  }
//
  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test95"); }


    org.apache.commons.math.fraction.BigFractionField var0 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var1 = var0.getZero();
    org.apache.commons.math.fraction.BigFraction var2 = var0.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var5 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var0, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var6 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var7 = var6.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var8 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var7);
    var8.start(2147483647, 0, 100, (-10), 100, 0);
    org.apache.commons.math.FieldElement var16 = var5.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var8);
    org.apache.commons.math.fraction.BigFractionField var17 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var18 = var17.getZero();
    org.apache.commons.math.fraction.BigFraction var19 = var17.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var22 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var17, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var23 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var24 = var23.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var25 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var24);
    var25.start(2147483647, 0, 100, (-10), 100, 0);
    org.apache.commons.math.FieldElement var33 = var22.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var25);
    org.apache.commons.math.linear.BlockFieldMatrix var34 = var5.subtract(var22);
    org.apache.commons.math.fraction.BigFractionField var35 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var36 = var35.getZero();
    org.apache.commons.math.fraction.BigFraction var37 = var35.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var40 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var35, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var41 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var42 = var41.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var43 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var42);
    var43.start(2147483647, 0, 100, (-10), 100, 0);
    org.apache.commons.math.FieldElement var51 = var40.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var43);
    org.apache.commons.math.linear.BlockFieldMatrix var52 = var34.multiply(var40);
    org.apache.commons.math.fraction.BigFractionField var53 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var54 = var53.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var55 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var54);
    org.apache.commons.math.fraction.BigFraction var57 = var54.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var59 = var54.subtract(10L);
    double var60 = var59.percentageValue();
    org.apache.commons.math.fraction.BigFraction var62 = var59.multiply(1);
    org.apache.commons.math.fraction.BigFractionField var63 = var59.getField();
    org.apache.commons.math.linear.Array2DRowFieldMatrix var64 = new org.apache.commons.math.linear.Array2DRowFieldMatrix((org.apache.commons.math.Field)var63);
    boolean var65 = var64.isSquare();
    org.apache.commons.math.fraction.BigFractionField var66 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var67 = var66.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var68 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var67);
    org.apache.commons.math.FieldElement var69 = var64.walkInColumnOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var68);
    org.apache.commons.math.FieldElement var70 = var68.end();
    org.apache.commons.math.FieldElement var71 = var52.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var68);
    org.apache.commons.math.FieldElement[][] var72 = var52.getData();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math.FieldElement[] var74 = var52.getRow(11);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == (-1000.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test96"); }


    org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var0 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator();
    double[] var3 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var5 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var3, false);
    double[][] var6 = new double[][] { var3};
    org.apache.commons.math.linear.BlockRealMatrix var7 = new org.apache.commons.math.linear.BlockRealMatrix(var6);
    double[] var10 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var12 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var10, false);
    double[] var13 = var12.getInterpolatedState();
    double[] var14 = var7.operate(var13);
    var0.reinitialize(var14, true);
    org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var17 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator(var0);
    var0.setInterpolatedTime(0.0d);
    double[] var25 = new double[] { 1.0d, 0.0d, 1.0d};
    org.apache.commons.math.linear.BigMatrix var26 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(var25);
    org.apache.commons.math.linear.RealVector var27 = org.apache.commons.math.linear.MatrixUtils.createRealVector(var25);
    double[] var32 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var34 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var32, false);
    double[][] var35 = new double[][] { var32};
    org.apache.commons.math.linear.BlockRealMatrix var36 = new org.apache.commons.math.linear.BlockRealMatrix(var35);
    org.apache.commons.math.MaxIterationsExceededException var37 = new org.apache.commons.math.MaxIterationsExceededException(0, "", (java.lang.Object[])var35);
    org.apache.commons.math.linear.Array2DRowRealMatrix var39 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var35, false);
    double[] var44 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var46 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var44, false);
    double[][] var47 = new double[][] { var44};
    org.apache.commons.math.linear.BlockRealMatrix var48 = new org.apache.commons.math.linear.BlockRealMatrix(var47);
    org.apache.commons.math.MaxIterationsExceededException var49 = new org.apache.commons.math.MaxIterationsExceededException(0, "", (java.lang.Object[])var47);
    org.apache.commons.math.linear.Array2DRowRealMatrix var51 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var47, false);
    org.apache.commons.math.linear.Array2DRowRealMatrix var52 = var39.subtract(var51);
    org.apache.commons.math.linear.RealMatrix var55 = var52.createMatrix(10, 1);
    int var56 = var52.getRowDimension();
    boolean var57 = var52.isSquare();
    var0.reinitialize(1.0E-6d, (-10.0d), var25, var52);
    double[][] var59 = var52.getData();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test97"); }


    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var4 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(0.0d, (-1.0d), 10.0d, 100.0d);
    int var5 = var4.getMaxEvaluations();
    var4.setSafety(1.0d);
    double var8 = var4.getMaxGrowth();
    var4.clearEventHandlers();
    var4.clearEventHandlers();
    double var11 = var4.getSafety();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1.0d);

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test98"); }


    org.apache.commons.math.fraction.BigFractionField var0 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var1 = var0.getZero();
    org.apache.commons.math.fraction.BigFraction var2 = var0.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var5 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var0, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var6 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var7 = var6.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var8 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var7);
    var8.start(2147483647, 0, 100, (-10), 100, 0);
    org.apache.commons.math.FieldElement var16 = var5.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var8);
    org.apache.commons.math.fraction.BigFractionField var17 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var18 = var17.getZero();
    org.apache.commons.math.fraction.BigFraction var19 = var17.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var22 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var17, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var23 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var24 = var23.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var25 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var24);
    var25.start(2147483647, 0, 100, (-10), 100, 0);
    org.apache.commons.math.FieldElement var33 = var22.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var25);
    org.apache.commons.math.linear.BlockFieldMatrix var34 = var5.subtract(var22);
    org.apache.commons.math.fraction.BigFractionField var35 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var36 = var35.getZero();
    double var38 = var36.pow((-1.0d));
    org.apache.commons.math.fraction.BigFraction var39 = var36.abs();
    org.apache.commons.math.linear.FieldMatrix var40 = var34.scalarAdd((org.apache.commons.math.FieldElement)var39);
    org.apache.commons.math.Field var41 = var34.getField();
    org.apache.commons.math.fraction.BigFractionField var42 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var43 = var42.getZero();
    org.apache.commons.math.fraction.BigFraction var44 = var42.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var47 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var42, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var48 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var49 = var48.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var50 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var49);
    org.apache.commons.math.fraction.BigFraction var52 = var49.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var54 = var49.subtract(10L);
    double var55 = var54.percentageValue();
    org.apache.commons.math.fraction.BigFraction var57 = var54.multiply(1);
    org.apache.commons.math.fraction.BigFractionField var58 = var54.getField();
    org.apache.commons.math.linear.Array2DRowFieldMatrix var59 = new org.apache.commons.math.linear.Array2DRowFieldMatrix((org.apache.commons.math.Field)var58);
    boolean var60 = var59.isSquare();
    org.apache.commons.math.fraction.BigFractionField var61 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var62 = var61.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var63 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var62);
    org.apache.commons.math.FieldElement var64 = var59.walkInColumnOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var63);
    org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor var65 = new org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor(var64);
    org.apache.commons.math.FieldElement var66 = var47.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixChangingVisitor)var65);
    org.apache.commons.math.linear.FieldMatrix var67 = var34.subtract((org.apache.commons.math.linear.FieldMatrix)var47);
    int var68 = var47.getRowDimension();
    boolean var69 = var47.isSquare();
    org.apache.commons.math.linear.FieldMatrix var71 = var47.getColumnMatrix(0);
    org.apache.commons.math.linear.FieldMatrix var72 = var47.copy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == (-1000.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);

  }

  public void test99() {}
//   public void test99() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test99"); }
// 
// 
//     org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var0 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator();
//     double[] var3 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var5 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var3, false);
//     double[][] var6 = new double[][] { var3};
//     org.apache.commons.math.linear.BlockRealMatrix var7 = new org.apache.commons.math.linear.BlockRealMatrix(var6);
//     double[] var10 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var12 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var10, false);
//     double[] var13 = var12.getInterpolatedState();
//     double[] var14 = var7.operate(var13);
//     var0.reinitialize(var14, true);
//     double[] var19 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var21 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var19, false);
//     double var22 = var21.getCurrentTime();
//     double[] var23 = var21.getInterpolatedState();
//     org.apache.commons.math.linear.BigMatrix var24 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(var23);
//     var0.reinitialize(var23, true);
//     double var27 = var0.getPreviousTime();
//     double[] var30 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var32 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var30, false);
//     double[][] var33 = new double[][] { var30};
//     org.apache.commons.math.linear.BlockRealMatrix var34 = new org.apache.commons.math.linear.BlockRealMatrix(var33);
//     org.apache.commons.math.linear.BlockRealMatrix var36 = var34.getColumnMatrix(1);
//     double[] var39 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var41 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var39, false);
//     double[][] var42 = new double[][] { var39};
//     org.apache.commons.math.linear.BlockRealMatrix var43 = new org.apache.commons.math.linear.BlockRealMatrix(var42);
//     org.apache.commons.math.linear.BlockRealMatrix var45 = var43.getColumnMatrix(1);
//     org.apache.commons.math.linear.BlockRealMatrix var46 = var36.subtract(var45);
//     boolean var47 = var46.isSingular();
//     org.apache.commons.math.linear.RealMatrix var49 = var46.scalarMultiply((-1.0d));
//     int var50 = var46.getRowDimension();
//     org.apache.commons.math.ode.events.CombinedEventsManager var51 = new org.apache.commons.math.ode.events.CombinedEventsManager();
//     double[] var55 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var57 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var55, false);
//     double[][] var58 = new double[][] { var55};
//     org.apache.commons.math.linear.BlockRealMatrix var59 = new org.apache.commons.math.linear.BlockRealMatrix(var58);
//     double[] var62 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var64 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var62, false);
//     double[] var65 = var64.getInterpolatedState();
//     double[] var66 = var59.operate(var65);
//     boolean var67 = var51.reset(1.0E-6d, var66);
//     double[] var68 = var46.preMultiply(var66);
//     var0.reinitialize(var68, true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var67 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
// 
//   }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test100"); }


    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var4 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(1.0E-15d, 100.0d, 0.0d, 1.0E-6d);

  }

  public void test101() {}
//   public void test101() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test101"); }
// 
// 
//     double[] var5 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var7 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var5, false);
//     double var8 = var7.getCurrentTime();
//     double[] var9 = var7.getInterpolatedState();
//     double[] var10 = var7.getInterpolatedDerivatives();
//     double[] var13 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var15 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var13, false);
//     double var16 = var15.getCurrentTime();
//     double[] var17 = var15.getInterpolatedState();
//     double[] var18 = var15.getInterpolatedDerivatives();
//     org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var19 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, Double.NaN, 1.0E-15d, var10, var18);
//     var19.setMinReduction(0.0d);
//     var19.setSafety(1.0d);
//     org.apache.commons.math.ode.ODEIntegrator var24 = var19.getStarterIntegrator();
//     var19.clearStepHandlers();
//     double[] var31 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var33 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var31, false);
//     double var34 = var33.getCurrentTime();
//     double[] var35 = var33.getInterpolatedState();
//     double[] var36 = var33.getInterpolatedDerivatives();
//     double[] var39 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var41 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var39, false);
//     double var42 = var41.getCurrentTime();
//     double[] var43 = var41.getInterpolatedState();
//     double[] var44 = var41.getInterpolatedDerivatives();
//     org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var45 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, Double.NaN, 1.0E-15d, var36, var44);
//     var45.setMinReduction(0.0d);
//     org.apache.commons.math.ode.ODEIntegrator var48 = var45.getStarterIntegrator();
//     double[] var53 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var55 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var53, false);
//     double[][] var56 = new double[][] { var53};
//     org.apache.commons.math.linear.BlockRealMatrix var57 = new org.apache.commons.math.linear.BlockRealMatrix(var56);
//     org.apache.commons.math.MaxIterationsExceededException var58 = new org.apache.commons.math.MaxIterationsExceededException(0, "", (java.lang.Object[])var56);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var60 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var56, false);
//     double[] var65 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var67 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var65, false);
//     double[][] var68 = new double[][] { var65};
//     org.apache.commons.math.linear.BlockRealMatrix var69 = new org.apache.commons.math.linear.BlockRealMatrix(var68);
//     org.apache.commons.math.MaxIterationsExceededException var70 = new org.apache.commons.math.MaxIterationsExceededException(0, "", (java.lang.Object[])var68);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var72 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var68, false);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var73 = var60.subtract(var72);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var74 = var45.updateHighOrderDerivativesPhase1(var60);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var75 = var19.updateHighOrderDerivativesPhase1(var74);
//     org.apache.commons.math.linear.RealMatrix var76 = var75.transpose();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var75.setEntry((-1), (-10), (-0.1d));
//       fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
//     } catch (org.apache.commons.math.linear.MatrixIndexException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var74);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var75);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
// 
//   }

  public void test102() {}
//   public void test102() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test102"); }
// 
// 
//     double[] var2 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var4 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var2, false);
//     double[][] var5 = new double[][] { var2};
//     org.apache.commons.math.linear.BlockRealMatrix var6 = new org.apache.commons.math.linear.BlockRealMatrix(var5);
//     org.apache.commons.math.linear.BlockRealMatrix var7 = var6.transpose();
//     double[] var11 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var13 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var11, false);
//     double[][] var14 = new double[][] { var11};
//     org.apache.commons.math.linear.BlockRealMatrix var15 = new org.apache.commons.math.linear.BlockRealMatrix(var14);
//     double[] var18 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var20 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var18, false);
//     double[] var21 = var20.getInterpolatedState();
//     double[] var22 = var15.operate(var21);
//     org.apache.commons.math.linear.BlockRealMatrix var24 = var15.scalarAdd((-1.0d));
//     org.apache.commons.math.linear.RealMatrix var26 = var15.scalarAdd(0.0d);
//     org.apache.commons.math.fraction.BigFractionField var27 = org.apache.commons.math.fraction.BigFractionField.getInstance();
//     org.apache.commons.math.fraction.BigFraction var28 = var27.getZero();
//     org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var29 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var28);
//     org.apache.commons.math.FieldElement[] var30 = new org.apache.commons.math.FieldElement[] { var28};
//     org.apache.commons.math.linear.FieldMatrix var31 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createColumnFieldMatrix(var30);
//     double[] var34 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var36 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var34, false);
//     double[][] var37 = new double[][] { var34};
//     org.apache.commons.math.linear.BlockRealMatrix var38 = new org.apache.commons.math.linear.BlockRealMatrix(var37);
//     org.apache.commons.math.linear.RealMatrix var40 = var38.scalarMultiply(10.0d);
//     org.apache.commons.math.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math.linear.AnyMatrix)var31, (org.apache.commons.math.linear.AnyMatrix)var40);
//     org.apache.commons.math.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math.linear.AnyMatrix)var15, (org.apache.commons.math.linear.AnyMatrix)var40);
//     var6.setRowMatrix(0, (org.apache.commons.math.linear.RealMatrix)var15);
//     int var44 = var6.getRowDimension();
//     org.apache.commons.math.linear.RealMatrixChangingVisitor var45 = null;
//     double var46 = var6.walkInRowOrder(var45);
// 
//   }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test103"); }


    org.apache.commons.math.linear.BlockRealMatrix var2 = new org.apache.commons.math.linear.BlockRealMatrix(10, 2);
    org.apache.commons.math.fraction.BigFractionField var3 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var4 = var3.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var5 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var4);
    org.apache.commons.math.fraction.BigFraction var7 = var4.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var9 = var4.pow(2147483647);
    org.apache.commons.math.fraction.BigFraction var11 = var9.pow(0L);
    org.apache.commons.math.fraction.BigFractionField var12 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var13 = var12.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var14 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var13);
    org.apache.commons.math.fraction.BigFraction var16 = var13.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var18 = var13.pow(2147483647);
    org.apache.commons.math.fraction.BigFraction var20 = var18.pow(0L);
    org.apache.commons.math.fraction.BigFraction var22 = var18.divide(1);
    java.math.BigInteger var23 = var18.getNumerator();
    org.apache.commons.math.fraction.BigFractionField var24 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var25 = var24.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var26 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var25);
    org.apache.commons.math.fraction.BigFraction var28 = var25.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var30 = var25.pow(2147483647);
    org.apache.commons.math.fraction.BigFraction var32 = var30.pow(0L);
    org.apache.commons.math.fraction.BigFraction var34 = var30.divide(1);
    org.apache.commons.math.fraction.BigFraction var35 = var18.multiply(var34);
    int var36 = var11.compareTo(var34);
    org.apache.commons.math.fraction.BigFraction var38 = var11.multiply(0);
    org.apache.commons.math.fraction.BigFractionField var39 = var38.getField();
    org.apache.commons.math.fraction.BigFraction var40 = var39.getZero();
    org.apache.commons.math.fraction.BigFraction var41 = var40.negate();
    boolean var42 = var2.equals((java.lang.Object)var40);
    org.apache.commons.math.fraction.BigFractionField var43 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var44 = var43.getZero();
    org.apache.commons.math.fraction.BigFraction var45 = var43.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var48 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var43, 10, 10);
    org.apache.commons.math.fraction.BigFraction var49 = var43.getOne();
    org.apache.commons.math.fraction.BigFraction var50 = var43.getZero();
    org.apache.commons.math.fraction.BigFractionField var51 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var52 = var51.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var53 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var52);
    org.apache.commons.math.fraction.BigFraction var55 = var52.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var57 = var52.pow(2147483647);
    org.apache.commons.math.fraction.BigFraction var59 = var57.pow(0L);
    org.apache.commons.math.fraction.BigFraction var61 = var57.divide(1);
    java.math.BigInteger var62 = var57.getNumerator();
    org.apache.commons.math.fraction.BigFractionField var63 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var64 = var63.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var65 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var64);
    org.apache.commons.math.fraction.BigFraction var67 = var64.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var69 = var64.pow(2147483647);
    org.apache.commons.math.fraction.BigFraction var71 = var69.pow(0L);
    org.apache.commons.math.fraction.BigFraction var73 = var69.divide(1);
    org.apache.commons.math.fraction.BigFraction var74 = var57.multiply(var73);
    org.apache.commons.math.fraction.BigFraction var76 = var73.divide(100L);
    org.apache.commons.math.fraction.BigFraction var77 = var50.subtract(var73);
    org.apache.commons.math.fraction.BigFraction var78 = var40.subtract(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);

  }

  public void test104() {}
//   public void test104() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test104"); }
// 
// 
//     double[] var2 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var4 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var2, false);
//     double[][] var5 = new double[][] { var2};
//     org.apache.commons.math.linear.BlockRealMatrix var6 = new org.apache.commons.math.linear.BlockRealMatrix(var5);
//     double[] var9 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var11 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var9, false);
//     double[] var12 = var11.getInterpolatedState();
//     double[] var13 = var6.operate(var12);
//     org.apache.commons.math.linear.BlockRealMatrix var15 = var6.scalarAdd((-1.0d));
//     org.apache.commons.math.linear.RealMatrix var17 = var6.scalarAdd(0.0d);
//     double[] var20 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var22 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var20, false);
//     double[][] var23 = new double[][] { var20};
//     org.apache.commons.math.linear.BlockRealMatrix var24 = new org.apache.commons.math.linear.BlockRealMatrix(var23);
//     org.apache.commons.math.linear.BlockRealMatrix var25 = var24.transpose();
//     org.apache.commons.math.linear.BlockRealMatrix var26 = var6.add((org.apache.commons.math.linear.RealMatrix)var24);
//     var26.setEntry(0, 0, 10.0d);
//     org.apache.commons.math.linear.RealMatrixPreservingVisitor var31 = null;
//     double var32 = var26.walkInOptimizedOrder(var31);
// 
//   }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test105"); }


    org.apache.commons.math.fraction.BigFractionField var0 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var1 = var0.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var2 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var1);
    org.apache.commons.math.fraction.BigFraction var4 = var1.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var6 = var1.pow(2147483647);
    org.apache.commons.math.fraction.BigFractionField var7 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var8 = var7.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var9 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var8);
    org.apache.commons.math.fraction.BigFraction var11 = var8.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var13 = var8.pow(2147483647);
    org.apache.commons.math.fraction.BigFraction var15 = var13.pow(0L);
    org.apache.commons.math.fraction.BigFraction var17 = var13.divide(1);
    java.math.BigInteger var18 = var13.getNumerator();
    org.apache.commons.math.fraction.BigFraction var19 = var1.pow(var18);
    org.apache.commons.math.fraction.BigFraction var20 = new org.apache.commons.math.fraction.BigFraction(var18);
    org.apache.commons.math.fraction.BigFraction var21 = new org.apache.commons.math.fraction.BigFraction(var18);
    org.apache.commons.math.fraction.BigFractionField var22 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var23 = var22.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var24 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var23);
    java.math.BigDecimal var25 = var23.bigDecimalValue();
    java.lang.String var26 = var23.toString();
    org.apache.commons.math.fraction.BigFractionField var27 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var28 = var27.getZero();
    java.math.BigInteger var29 = var28.getDenominator();
    org.apache.commons.math.fraction.BigFraction var30 = var23.pow(var29);
    org.apache.commons.math.fraction.BigFraction var31 = var21.subtract(var29);
    org.apache.commons.math.fraction.BigFractionField var32 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var33 = var32.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var34 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var33);
    org.apache.commons.math.fraction.BigFraction var36 = var33.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var38 = var33.pow(2147483647);
    org.apache.commons.math.fraction.BigFractionField var39 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var40 = var39.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var41 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var40);
    org.apache.commons.math.fraction.BigFraction var43 = var40.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var45 = var40.pow(2147483647);
    org.apache.commons.math.fraction.BigFraction var47 = var45.pow(0L);
    org.apache.commons.math.fraction.BigFraction var49 = var45.divide(1);
    java.math.BigInteger var50 = var45.getNumerator();
    org.apache.commons.math.fraction.BigFraction var51 = var33.pow(var50);
    org.apache.commons.math.fraction.BigFraction var52 = new org.apache.commons.math.fraction.BigFraction(var50);
    org.apache.commons.math.fraction.BigFraction var53 = var31.pow(var50);
    org.apache.commons.math.fraction.BigFraction var54 = new org.apache.commons.math.fraction.BigFraction(var50);
    org.apache.commons.math.fraction.BigFractionField var55 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var56 = var55.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var57 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var56);
    org.apache.commons.math.fraction.BigFraction var59 = var56.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var61 = var56.pow(2147483647);
    org.apache.commons.math.fraction.BigFractionField var62 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var63 = var62.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var64 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var63);
    org.apache.commons.math.fraction.BigFraction var66 = var63.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var68 = var63.pow(2147483647);
    org.apache.commons.math.fraction.BigFraction var70 = var68.pow(0L);
    org.apache.commons.math.fraction.BigFraction var72 = var68.divide(1);
    java.math.BigInteger var73 = var68.getNumerator();
    org.apache.commons.math.fraction.BigFraction var74 = var56.pow(var73);
    double var76 = var74.pow(2.147483647E11d);
    org.apache.commons.math.fraction.BigFraction var77 = var54.multiply(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + "0"+ "'", var26.equals("0"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);

  }

  public void test106() {}
//   public void test106() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test106"); }
// 
// 
//     double[] var2 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var4 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var2, false);
//     double var5 = var4.getCurrentTime();
//     double[] var6 = var4.getInterpolatedState();
//     org.apache.commons.math.linear.BigMatrix var7 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(var6);
//     double[][] var8 = new double[][] { var6};
//     org.apache.commons.math.linear.RealMatrix var9 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(var8);
//     org.apache.commons.math.linear.BlockRealMatrix var10 = new org.apache.commons.math.linear.BlockRealMatrix(var8);
//     int var11 = var10.getColumnDimension();
//     org.apache.commons.math.linear.RealMatrixPreservingVisitor var12 = null;
//     double var13 = var10.walkInRowOrder(var12);
// 
//   }

  public void test107() {}
//   public void test107() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test107"); }
// 
// 
//     double[] var2 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var4 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var2, false);
//     double[][] var5 = new double[][] { var2};
//     org.apache.commons.math.linear.BlockRealMatrix var6 = new org.apache.commons.math.linear.BlockRealMatrix(var5);
//     double[] var9 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var11 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var9, false);
//     double[] var12 = var11.getInterpolatedState();
//     double[] var13 = var6.operate(var12);
//     org.apache.commons.math.linear.BlockRealMatrix var15 = var6.scalarAdd((-1.0d));
//     java.lang.Object[] var20 = new java.lang.Object[] { 0L};
//     java.text.ParseException var21 = org.apache.commons.math.MathRuntimeException.createParseException((-1), "", var20);
//     org.apache.commons.math.ode.events.EventException var22 = new org.apache.commons.math.ode.events.EventException("", var20);
//     java.io.IOException var23 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable)var22);
//     java.lang.Object[] var29 = new java.lang.Object[] { 0L};
//     java.text.ParseException var30 = org.apache.commons.math.MathRuntimeException.createParseException((-1), "", var29);
//     org.apache.commons.math.FunctionEvaluationException var31 = new org.apache.commons.math.FunctionEvaluationException(100.0d, "", var29);
//     double[] var32 = var31.getArgument();
//     double[] var33 = var31.getArgument();
//     double[] var39 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var41 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var39, false);
//     double var42 = var41.getCurrentTime();
//     double[] var43 = var41.getInterpolatedState();
//     org.apache.commons.math.linear.BigMatrix var44 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(var43);
//     double[][] var45 = new double[][] { var43};
//     org.apache.commons.math.linear.RealMatrix var46 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(var45);
//     double[][] var47 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var45);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var48 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var45);
//     org.apache.commons.math.FunctionEvaluationException var49 = new org.apache.commons.math.FunctionEvaluationException(1.0E-6d, "org.apache.commons.math.FunctionEvaluationException: evaluation failed for argument = {-1; 0}", (java.lang.Object[])var45);
//     org.apache.commons.math.FunctionEvaluationException var50 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable)var23, var33, "a {0}x{1} matrix was provided instead of a square matrix", (java.lang.Object[])var45);
//     double[] var51 = var50.getArgument();
//     org.apache.commons.math.linear.RealVector var52 = org.apache.commons.math.linear.MatrixUtils.createRealVector(var51);
//     org.apache.commons.math.linear.RealMatrix var53 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var51);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.apache.commons.math.linear.BlockRealMatrix var54 = var15.multiply(var53);
//       fail("Expected exception of type Exception");
//     } catch (Exception e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
// 
//   }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test108"); }


    org.apache.commons.math.linear.BlockRealMatrix var2 = new org.apache.commons.math.linear.BlockRealMatrix(1, 2);
    boolean var3 = var2.isSquare();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.addToEntry(11, 0, 2.147483647E11d);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test109"); }


    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var4 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator((-100000.0d), 0.0d, 0.0d, 144.0d);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test110"); }


    org.apache.commons.math.fraction.BigFractionField var0 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var1 = var0.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var2 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var1);
    org.apache.commons.math.FieldElement[] var3 = new org.apache.commons.math.FieldElement[] { var1};
    org.apache.commons.math.linear.FieldMatrix var4 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createColumnFieldMatrix(var3);
    org.apache.commons.math.FieldElement[][] var5 = new org.apache.commons.math.FieldElement[][] { var3};
    org.apache.commons.math.linear.FieldMatrix var6 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldMatrix(var5);
    org.apache.commons.math.linear.FieldLUDecompositionImpl var7 = new org.apache.commons.math.linear.FieldLUDecompositionImpl(var6);
    int[] var8 = var7.getPivot();
    org.apache.commons.math.linear.FieldMatrix var9 = var7.getU();
    org.apache.commons.math.linear.FieldMatrix var10 = var7.getP();
    org.apache.commons.math.linear.FieldMatrix var11 = var7.getL();
    org.apache.commons.math.FieldElement var12 = var7.getDeterminant();
    org.apache.commons.math.linear.FieldDecompositionSolver var13 = var7.getSolver();
    org.apache.commons.math.linear.FieldMatrix var14 = var7.getL();
    int[] var15 = var7.getPivot();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test111"); }


    double[] var2 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var4 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var2, false);
    double[][] var5 = new double[][] { var2};
    org.apache.commons.math.linear.BlockRealMatrix var6 = new org.apache.commons.math.linear.BlockRealMatrix(var5);
    org.apache.commons.math.linear.BlockRealMatrix var7 = var6.transpose();
    org.apache.commons.math.linear.BlockRealMatrix var8 = var6.transpose();
    var8.multiplyEntry(1, 0, 1.0E-6d);
    org.apache.commons.math.linear.RealMatrix var14 = var8.scalarMultiply(1.0E-6d);
    boolean var15 = var8.isSquare();
    org.apache.commons.math.linear.BlockRealMatrix var17 = var8.scalarAdd(1.0E-15d);
    org.apache.commons.math.linear.RealMatrixPreservingVisitor var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var23 = var8.walkInOptimizedOrder(var18, (-1), (-11), 2, 11);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test112"); }


    org.apache.commons.math.fraction.BigFractionField var0 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var1 = var0.getZero();
    org.apache.commons.math.fraction.BigFraction var2 = var0.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var5 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var0, 10, 10);
    org.apache.commons.math.fraction.BigFraction var6 = var0.getOne();
    org.apache.commons.math.fraction.BigFraction var7 = var0.getZero();
    org.apache.commons.math.FieldElement[][] var10 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>createBlocksLayout((org.apache.commons.math.Field)var0, 0, 0);
    org.apache.commons.math.fraction.BigFraction var11 = var0.getZero();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test113"); }


    org.apache.commons.math.fraction.BigFractionField var0 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var1 = var0.getZero();
    org.apache.commons.math.fraction.BigFraction var2 = var0.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var5 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var0, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var6 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var7 = var6.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var8 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var7);
    var8.start(2147483647, 0, 100, (-10), 100, 0);
    org.apache.commons.math.FieldElement var16 = var5.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var8);
    org.apache.commons.math.fraction.BigFractionField var19 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var20 = var19.getZero();
    org.apache.commons.math.fraction.BigFraction var21 = var19.getOne();
    org.apache.commons.math.fraction.BigFraction var23 = var21.pow(100);
    var5.setEntry(10, (-1), (org.apache.commons.math.FieldElement)var23);
    org.apache.commons.math.fraction.BigFractionField var25 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var26 = var25.getZero();
    org.apache.commons.math.fraction.BigFraction var27 = var25.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var30 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var25, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var31 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var32 = var31.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var33 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var32);
    var33.start(2147483647, 0, 100, (-10), 100, 0);
    org.apache.commons.math.FieldElement var41 = var30.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var33);
    org.apache.commons.math.linear.FieldVector var43 = var30.getColumnVector(1);
    org.apache.commons.math.linear.BlockFieldMatrix var44 = var5.multiply(var30);
    int var45 = var30.getColumnDimension();
    org.apache.commons.math.fraction.BigFractionField var46 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var47 = var46.getZero();
    org.apache.commons.math.fraction.BigFraction var48 = var46.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var51 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var46, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var52 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var53 = var52.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var54 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var53);
    org.apache.commons.math.fraction.BigFraction var56 = var53.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var58 = var53.subtract(10L);
    double var59 = var58.percentageValue();
    org.apache.commons.math.fraction.BigFraction var61 = var58.multiply(1);
    org.apache.commons.math.fraction.BigFractionField var62 = var58.getField();
    org.apache.commons.math.linear.Array2DRowFieldMatrix var63 = new org.apache.commons.math.linear.Array2DRowFieldMatrix((org.apache.commons.math.Field)var62);
    boolean var64 = var63.isSquare();
    org.apache.commons.math.fraction.BigFractionField var65 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var66 = var65.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var67 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var66);
    org.apache.commons.math.FieldElement var68 = var63.walkInColumnOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var67);
    org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor var69 = new org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor(var68);
    org.apache.commons.math.FieldElement var70 = var51.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixChangingVisitor)var69);
    int var71 = var51.getRowDimension();
    org.apache.commons.math.linear.FieldMatrix var72 = var30.subtract((org.apache.commons.math.linear.FieldMatrix)var51);
    boolean var73 = var30.isSquare();
    int var74 = var30.getColumnDimension();
    org.apache.commons.math.fraction.BigFractionField var77 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var78 = var77.getZero();
    double var80 = var78.pow((-1.0d));
    org.apache.commons.math.fraction.BigFraction var81 = var78.abs();
    org.apache.commons.math.fraction.BigFraction var83 = var81.multiply(0L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var30.setEntry(25, 0, (org.apache.commons.math.FieldElement)var83);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == (-1000.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test114"); }


    org.apache.commons.math.fraction.BigFractionField var0 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.FieldElement[][] var3 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>createBlocksLayout((org.apache.commons.math.Field)var0, 0, 11);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math.linear.Array2DRowFieldMatrix var4 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var3);
      fail("Expected exception of type Exception");
    } catch (Exception e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test115"); }


    org.apache.commons.math.fraction.BigFractionField var0 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var1 = var0.getZero();
    org.apache.commons.math.fraction.BigFraction var2 = var0.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var5 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var0, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var6 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var7 = var6.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var8 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var7);
    var8.start(2147483647, 0, 100, (-10), 100, 0);
    org.apache.commons.math.FieldElement var16 = var5.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var8);
    org.apache.commons.math.fraction.BigFractionField var17 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var18 = var17.getZero();
    org.apache.commons.math.fraction.BigFraction var19 = var17.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var22 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var17, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var23 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var24 = var23.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var25 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var24);
    var25.start(2147483647, 0, 100, (-10), 100, 0);
    org.apache.commons.math.FieldElement var33 = var22.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var25);
    org.apache.commons.math.linear.BlockFieldMatrix var34 = var5.subtract(var22);
    org.apache.commons.math.fraction.BigFractionField var35 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var36 = var35.getZero();
    double var38 = var36.pow((-1.0d));
    org.apache.commons.math.fraction.BigFraction var39 = var36.abs();
    org.apache.commons.math.linear.FieldMatrix var40 = var34.scalarAdd((org.apache.commons.math.FieldElement)var39);
    org.apache.commons.math.Field var41 = var34.getField();
    org.apache.commons.math.linear.FieldVector var43 = var34.getRowVector(0);
    org.apache.commons.math.fraction.BigFractionField var44 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var45 = var44.getZero();
    org.apache.commons.math.fraction.BigFraction var46 = var44.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var49 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var44, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var50 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var51 = var50.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var52 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var51);
    var52.start(2147483647, 0, 100, (-10), 100, 0);
    org.apache.commons.math.FieldElement var60 = var49.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var52);
    org.apache.commons.math.fraction.BigFractionField var61 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var62 = var61.getZero();
    double var64 = var62.pow((-1.0d));
    org.apache.commons.math.fraction.BigFraction var65 = var62.abs();
    java.math.BigDecimal var68 = var65.bigDecimalValue(2147483647, 1);
    int var69 = var65.getNumeratorAsInt();
    org.apache.commons.math.linear.FieldMatrix var70 = var49.scalarMultiply((org.apache.commons.math.FieldElement)var65);
    org.apache.commons.math.fraction.BigFractionField var73 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var74 = var73.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var75 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var74);
    org.apache.commons.math.fraction.BigFraction var77 = var74.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var79 = var74.subtract(10L);
    var49.multiplyEntry(2, 1, (org.apache.commons.math.FieldElement)var79);
    org.apache.commons.math.linear.FieldMatrix var81 = var34.preMultiply((org.apache.commons.math.linear.FieldMatrix)var49);
    org.apache.commons.math.fraction.BigFractionField var82 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var83 = var82.getZero();
    double var85 = var83.pow((-1.0d));
    org.apache.commons.math.fraction.BigFraction var86 = var83.abs();
    java.math.BigDecimal var89 = var86.bigDecimalValue(2147483647, 1);
    int var90 = var86.getNumeratorAsInt();
    org.apache.commons.math.fraction.BigFraction var92 = var86.subtract(2147483647L);
    org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor var93 = new org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor((org.apache.commons.math.FieldElement)var86);
    org.apache.commons.math.FieldElement var94 = var49.walkInColumnOrder((org.apache.commons.math.linear.FieldMatrixChangingVisitor)var93);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test116"); }


    org.apache.commons.math.fraction.BigFractionField var0 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var1 = var0.getZero();
    org.apache.commons.math.FieldElement[][] var4 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>createBlocksLayout((org.apache.commons.math.Field)var0, 0, 0);
    org.apache.commons.math.fraction.BigFraction var5 = var0.getZero();
    org.apache.commons.math.fraction.BigFraction var6 = var0.getZero();
    org.apache.commons.math.fraction.BigFractionField var7 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var8 = var7.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var9 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var8);
    org.apache.commons.math.fraction.BigFraction var11 = var8.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var13 = var8.subtract(10L);
    double var14 = var13.percentageValue();
    org.apache.commons.math.fraction.BigFraction var16 = var13.multiply(1);
    long var17 = var13.longValue();
    int var18 = var6.compareTo(var13);
    org.apache.commons.math.fraction.BigFractionField var19 = var6.getField();
    org.apache.commons.math.fraction.BigFraction var20 = var19.getOne();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math.linear.FieldMatrix var22 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldIdentityMatrix((org.apache.commons.math.Field)var19, (-1000));
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == (-1000.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == (-10L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test117"); }


    org.apache.commons.math.fraction.BigFractionField var4 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var5 = var4.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var6 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var5);
    org.apache.commons.math.fraction.BigFraction var8 = var5.subtract((-1L));
    org.apache.commons.math.FieldElement[] var9 = new org.apache.commons.math.FieldElement[] { var5};
    org.apache.commons.math.linear.FieldMatrix var10 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var9);
    org.apache.commons.math.linear.FieldMatrix var11 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var9);
    org.apache.commons.math.linear.MatrixIndexException var12 = new org.apache.commons.math.linear.MatrixIndexException("java.io.IOException: ", (java.lang.Object[])var9);
    org.apache.commons.math.linear.FieldVector var13 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var9);
    java.io.EOFException var14 = org.apache.commons.math.MathRuntimeException.createEOFException("matrix is singular", (java.lang.Object[])var9);
    java.text.ParseException var15 = org.apache.commons.math.MathRuntimeException.createParseException(2, "Adams-Moulton", (java.lang.Object[])var9);
    org.apache.commons.math.FieldElement[][] var16 = new org.apache.commons.math.FieldElement[][] { var9};
    org.apache.commons.math.FieldElement[][] var17 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test118"); }


    org.apache.commons.math.fraction.BigFractionField var0 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var1 = var0.getZero();
    org.apache.commons.math.fraction.BigFraction var2 = var0.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var5 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var0, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var6 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var7 = var6.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var8 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var7);
    var8.start(2147483647, 0, 100, (-10), 100, 0);
    org.apache.commons.math.FieldElement var16 = var5.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var8);
    org.apache.commons.math.fraction.BigFractionField var17 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var18 = var17.getZero();
    org.apache.commons.math.fraction.BigFraction var19 = var17.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var22 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var17, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var23 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var24 = var23.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var25 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var24);
    var25.start(2147483647, 0, 100, (-10), 100, 0);
    org.apache.commons.math.FieldElement var33 = var22.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var25);
    org.apache.commons.math.linear.BlockFieldMatrix var34 = var5.subtract(var22);
    org.apache.commons.math.fraction.BigFractionField var35 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var36 = var35.getZero();
    double var38 = var36.pow((-1.0d));
    org.apache.commons.math.fraction.BigFraction var39 = var36.abs();
    org.apache.commons.math.linear.FieldMatrix var40 = var34.scalarAdd((org.apache.commons.math.FieldElement)var39);
    org.apache.commons.math.Field var41 = var34.getField();
    org.apache.commons.math.fraction.BigFractionField var42 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var43 = var42.getZero();
    org.apache.commons.math.fraction.BigFraction var44 = var42.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var47 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var42, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var48 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var49 = var48.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var50 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var49);
    org.apache.commons.math.fraction.BigFraction var52 = var49.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var54 = var49.subtract(10L);
    double var55 = var54.percentageValue();
    org.apache.commons.math.fraction.BigFraction var57 = var54.multiply(1);
    org.apache.commons.math.fraction.BigFractionField var58 = var54.getField();
    org.apache.commons.math.linear.Array2DRowFieldMatrix var59 = new org.apache.commons.math.linear.Array2DRowFieldMatrix((org.apache.commons.math.Field)var58);
    boolean var60 = var59.isSquare();
    org.apache.commons.math.fraction.BigFractionField var61 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var62 = var61.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var63 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var62);
    org.apache.commons.math.FieldElement var64 = var59.walkInColumnOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var63);
    org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor var65 = new org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor(var64);
    org.apache.commons.math.FieldElement var66 = var47.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixChangingVisitor)var65);
    org.apache.commons.math.linear.FieldMatrix var67 = var34.subtract((org.apache.commons.math.linear.FieldMatrix)var47);
    org.apache.commons.math.fraction.BigFractionField var68 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var69 = var68.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var70 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var69);
    org.apache.commons.math.fraction.BigFraction var72 = var69.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var74 = var69.pow(2147483647);
    org.apache.commons.math.fraction.BigFraction var76 = var74.pow(0L);
    org.apache.commons.math.fraction.BigFractionField var77 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var78 = var77.getZero();
    int var79 = var78.getDenominatorAsInt();
    org.apache.commons.math.fraction.BigFraction var81 = var78.pow(0L);
    org.apache.commons.math.fraction.BigFraction var82 = var74.multiply(var78);
    org.apache.commons.math.fraction.BigFraction var84 = new org.apache.commons.math.fraction.BigFraction(2147483647);
    int var85 = var74.compareTo(var84);
    long var86 = var84.longValue();
    org.apache.commons.math.linear.FieldMatrix var87 = var34.scalarMultiply((org.apache.commons.math.FieldElement)var84);
    org.apache.commons.math.linear.FieldMatrix var89 = var34.getColumnMatrix(0);
    org.apache.commons.math.fraction.BigFractionField var90 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var91 = var90.getZero();
    double var93 = var91.pow((-1.0d));
    org.apache.commons.math.fraction.BigFraction var94 = var91.abs();
    org.apache.commons.math.linear.FieldMatrix var95 = var34.scalarMultiply((org.apache.commons.math.FieldElement)var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == (-1000.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 2147483647L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var95);

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test119"); }


    org.apache.commons.math.fraction.BigFractionField var0 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var1 = var0.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var2 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var1);
    org.apache.commons.math.fraction.BigFraction var4 = var1.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var6 = var1.subtract(10L);
    double var7 = var6.percentageValue();
    org.apache.commons.math.fraction.BigFraction var9 = var6.multiply(1);
    org.apache.commons.math.fraction.BigFractionField var10 = var6.getField();
    org.apache.commons.math.linear.Array2DRowFieldMatrix var11 = new org.apache.commons.math.linear.Array2DRowFieldMatrix((org.apache.commons.math.Field)var10);
    int var12 = var11.getRowDimension();
    org.apache.commons.math.FieldElement var13 = null;
    org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor var14 = new org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor(var13);
    org.apache.commons.math.FieldElement var15 = var11.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixChangingVisitor)var14);
    int var16 = var11.getColumnDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-1000.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test120"); }


    double[] var2 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var4 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var2, false);
    double[][] var5 = new double[][] { var2};
    org.apache.commons.math.linear.BlockRealMatrix var6 = new org.apache.commons.math.linear.BlockRealMatrix(var5);
    org.apache.commons.math.linear.BlockRealMatrix var8 = var6.getColumnMatrix(1);
    double[] var11 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var13 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var11, false);
    double[][] var14 = new double[][] { var11};
    org.apache.commons.math.linear.BlockRealMatrix var15 = new org.apache.commons.math.linear.BlockRealMatrix(var14);
    org.apache.commons.math.linear.BlockRealMatrix var17 = var15.getColumnMatrix(1);
    org.apache.commons.math.linear.BlockRealMatrix var18 = var8.subtract(var17);
    double[] var20 = var8.getRow(0);
    org.apache.commons.math.linear.Array2DRowRealMatrix var21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var20);
    double[] var24 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var26 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var24, false);
    double[][] var27 = new double[][] { var24};
    org.apache.commons.math.linear.BlockRealMatrix var28 = new org.apache.commons.math.linear.BlockRealMatrix(var27);
    double[] var31 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var33 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var31, false);
    double[][] var34 = new double[][] { var31};
    org.apache.commons.math.linear.BlockRealMatrix var35 = new org.apache.commons.math.linear.BlockRealMatrix(var34);
    double[] var38 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var40 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var38, false);
    double[] var41 = var40.getInterpolatedState();
    double[] var42 = var35.operate(var41);
    org.apache.commons.math.linear.BlockRealMatrix var44 = var35.scalarAdd((-1.0d));
    org.apache.commons.math.linear.RealMatrix var46 = var35.scalarAdd(0.0d);
    org.apache.commons.math.linear.RealMatrix var47 = var35.transpose();
    org.apache.commons.math.linear.BlockRealMatrix var48 = var35.copy();
    org.apache.commons.math.linear.BlockRealMatrix var49 = var28.add(var35);
    org.apache.commons.math.linear.BlockRealMatrix var50 = var49.copy();
    org.apache.commons.math.linear.RealMatrix var51 = var21.multiply((org.apache.commons.math.linear.RealMatrix)var50);
    boolean var52 = var21.isSquare();
    double[] var58 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var60 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var58, false);
    double[][] var61 = new double[][] { var58};
    org.apache.commons.math.linear.BlockRealMatrix var62 = new org.apache.commons.math.linear.BlockRealMatrix(var61);
    org.apache.commons.math.MaxIterationsExceededException var63 = new org.apache.commons.math.MaxIterationsExceededException(0, "", (java.lang.Object[])var61);
    org.apache.commons.math.linear.Array2DRowRealMatrix var65 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var61, false);
    double[] var70 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var72 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var70, false);
    double[][] var73 = new double[][] { var70};
    org.apache.commons.math.linear.BlockRealMatrix var74 = new org.apache.commons.math.linear.BlockRealMatrix(var73);
    org.apache.commons.math.MaxIterationsExceededException var75 = new org.apache.commons.math.MaxIterationsExceededException(0, "", (java.lang.Object[])var73);
    org.apache.commons.math.linear.Array2DRowRealMatrix var77 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var73, false);
    org.apache.commons.math.linear.Array2DRowRealMatrix var78 = var65.subtract(var77);
    org.apache.commons.math.linear.RealMatrix var79 = var78.copy();
    double[][] var80 = var78.getDataRef();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var21.setRowMatrix(0, (org.apache.commons.math.linear.RealMatrix)var78);
      fail("Expected exception of type org.apache.commons.math.linear.InvalidMatrixException");
    } catch (org.apache.commons.math.linear.InvalidMatrixException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test121"); }


    org.apache.commons.math.analysis.solvers.BrentSolver var0 = new org.apache.commons.math.analysis.solvers.BrentSolver();
    var0.setRelativeAccuracy(100.0d);
    double var3 = var0.getRelativeAccuracy();
    var0.resetMaximalIterationCount();
    double var5 = var0.getFunctionValueAccuracy();
    var0.resetMaximalIterationCount();
    var0.resetAbsoluteAccuracy();
    var0.resetRelativeAccuracy();
    var0.setMaximalIterationCount(10);
    var0.setRelativeAccuracy(144.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0E-15d);

  }

  public void test122() {}
//   public void test122() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test122"); }
// 
// 
//     double[] var2 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var4 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var2, false);
//     double[][] var5 = new double[][] { var2};
//     org.apache.commons.math.linear.BlockRealMatrix var6 = new org.apache.commons.math.linear.BlockRealMatrix(var5);
//     org.apache.commons.math.linear.BlockRealMatrix var8 = var6.getColumnMatrix(1);
//     double[] var11 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var13 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var11, false);
//     double[][] var14 = new double[][] { var11};
//     org.apache.commons.math.linear.BlockRealMatrix var15 = new org.apache.commons.math.linear.BlockRealMatrix(var14);
//     org.apache.commons.math.linear.BlockRealMatrix var17 = var15.getColumnMatrix(1);
//     org.apache.commons.math.linear.BlockRealMatrix var18 = var8.subtract(var17);
//     org.apache.commons.math.linear.RealMatrix var19 = var17.transpose();
//     double[][] var20 = var17.getData();
//     org.apache.commons.math.linear.BlockRealMatrix var22 = var17.scalarAdd(144.0d);
//     org.apache.commons.math.linear.RealMatrixPreservingVisitor var23 = null;
//     double var24 = var22.walkInColumnOrder(var23);
// 
//   }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test123"); }


    org.apache.commons.math.fraction.BigFraction var2 = new org.apache.commons.math.fraction.BigFraction(0L, 1L);
    java.math.BigDecimal var5 = var2.bigDecimalValue(8, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test124() {}
//   public void test124() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test124"); }
// 
// 
//     org.apache.commons.math.linear.BlockRealMatrix var2 = new org.apache.commons.math.linear.BlockRealMatrix(1, 1);
//     int var3 = var2.getColumnDimension();
//     double[] var9 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var11 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var9, false);
//     double var12 = var11.getCurrentTime();
//     double[] var13 = var11.getInterpolatedState();
//     double[] var14 = var11.getInterpolatedDerivatives();
//     double[] var17 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var19 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var17, false);
//     double var20 = var19.getCurrentTime();
//     double[] var21 = var19.getInterpolatedState();
//     double[] var22 = var19.getInterpolatedDerivatives();
//     org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var23 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, Double.NaN, 1.0E-15d, var14, var22);
//     org.apache.commons.math.ode.ODEIntegrator var24 = var23.getStarterIntegrator();
//     org.apache.commons.math.ode.events.CombinedEventsManager var25 = new org.apache.commons.math.ode.events.CombinedEventsManager();
//     double[] var29 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var31 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var29, false);
//     double[][] var32 = new double[][] { var29};
//     org.apache.commons.math.linear.BlockRealMatrix var33 = new org.apache.commons.math.linear.BlockRealMatrix(var32);
//     double[] var36 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var38 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var36, false);
//     double[] var39 = var38.getInterpolatedState();
//     double[] var40 = var33.operate(var39);
//     boolean var41 = var25.reset(1.0E-6d, var40);
//     var25.clearEventsHandlers();
//     double[] var46 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var48 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var46, false);
//     double var49 = var48.getCurrentTime();
//     double[] var50 = var48.getInterpolatedState();
//     double[] var51 = var48.getInterpolatedDerivatives();
//     var25.stepAccepted(100.0d, var51);
//     java.lang.Object[] var58 = new java.lang.Object[] { 0L};
//     java.text.ParseException var59 = org.apache.commons.math.MathRuntimeException.createParseException((-1), "", var58);
//     org.apache.commons.math.FunctionEvaluationException var60 = new org.apache.commons.math.FunctionEvaluationException(100.0d, "", var58);
//     double[] var61 = var60.getArgument();
//     double[] var62 = var60.getArgument();
//     double[] var65 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var67 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var65, false);
//     double[][] var68 = new double[][] { var65};
//     org.apache.commons.math.linear.BlockRealMatrix var69 = new org.apache.commons.math.linear.BlockRealMatrix(var68);
//     org.apache.commons.math.linear.BlockRealMatrix var71 = var69.getColumnMatrix(1);
//     double[] var74 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var76 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var74, false);
//     double[][] var77 = new double[][] { var74};
//     org.apache.commons.math.linear.BlockRealMatrix var78 = new org.apache.commons.math.linear.BlockRealMatrix(var77);
//     org.apache.commons.math.linear.BlockRealMatrix var80 = var78.getColumnMatrix(1);
//     org.apache.commons.math.linear.BlockRealMatrix var81 = var71.subtract(var80);
//     double[] var83 = var71.getRow(0);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var84 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var83);
//     var23.updateHighOrderDerivativesPhase2(var51, var62, var84);
//     double[] var86 = var2.operate(var62);
//     org.apache.commons.math.linear.RealMatrixPreservingVisitor var87 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var92 = var2.walkInRowOrder(var87, 0, (-10), (-9), 2);
//       fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
//     } catch (org.apache.commons.math.linear.MatrixIndexException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var71);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var74);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var81);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var83);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var86);
// 
//   }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test125"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer var1 = org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer.getInstance((-10));
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test126"); }


    double[] var4 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var6 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var4, false);
    double[][] var7 = new double[][] { var4};
    org.apache.commons.math.linear.BlockRealMatrix var8 = new org.apache.commons.math.linear.BlockRealMatrix(var7);
    org.apache.commons.math.linear.BlockRealMatrix var9 = var8.transpose();
    double[] var13 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var15 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var13, false);
    double[] var16 = var15.getInterpolatedDerivatives();
    var8.setRow(0, var16);
    double[] var20 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var22 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var20, false);
    double[] var23 = var22.getInterpolatedDerivatives();
    org.apache.commons.math.linear.BigMatrix var24 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(var23);
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var25 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(1.0d, 0.2d, var16, var23);
    org.apache.commons.math.linear.BigMatrix var26 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test127"); }


    org.apache.commons.math.fraction.BigFractionField var0 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var1 = var0.getZero();
    org.apache.commons.math.fraction.BigFraction var2 = var0.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var5 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var0, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var6 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var7 = var6.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var8 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var7);
    var8.start(2147483647, 0, 100, (-10), 100, 0);
    org.apache.commons.math.FieldElement var16 = var5.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var8);
    org.apache.commons.math.fraction.BigFractionField var17 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var18 = var17.getZero();
    org.apache.commons.math.fraction.BigFraction var19 = var17.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var22 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var17, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var23 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var24 = var23.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var25 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var24);
    var25.start(2147483647, 0, 100, (-10), 100, 0);
    org.apache.commons.math.FieldElement var33 = var22.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var25);
    org.apache.commons.math.linear.BlockFieldMatrix var34 = var5.subtract(var22);
    org.apache.commons.math.fraction.BigFractionField var35 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var36 = var35.getZero();
    org.apache.commons.math.fraction.BigFraction var37 = var35.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var40 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var35, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var41 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var42 = var41.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var43 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var42);
    var43.start(2147483647, 0, 100, (-10), 100, 0);
    org.apache.commons.math.FieldElement var51 = var40.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var43);
    org.apache.commons.math.linear.BlockFieldMatrix var52 = var34.multiply(var40);
    org.apache.commons.math.fraction.BigFractionField var53 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var54 = var53.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var55 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var54);
    org.apache.commons.math.fraction.BigFraction var57 = var54.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var59 = var54.subtract(10L);
    double var60 = var59.percentageValue();
    org.apache.commons.math.fraction.BigFraction var62 = var59.multiply(1);
    org.apache.commons.math.fraction.BigFractionField var63 = var59.getField();
    org.apache.commons.math.linear.Array2DRowFieldMatrix var64 = new org.apache.commons.math.linear.Array2DRowFieldMatrix((org.apache.commons.math.Field)var63);
    boolean var65 = var64.isSquare();
    org.apache.commons.math.fraction.BigFractionField var66 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var67 = var66.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var68 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var67);
    org.apache.commons.math.FieldElement var69 = var64.walkInColumnOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var68);
    org.apache.commons.math.FieldElement var70 = var68.end();
    org.apache.commons.math.FieldElement var71 = var52.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var68);
    org.apache.commons.math.fraction.BigFractionField var72 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var73 = var72.getZero();
    org.apache.commons.math.fraction.BigFraction var74 = var72.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var77 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var72, 10, 10);
    int var78 = var77.getRowDimension();
    org.apache.commons.math.linear.BlockFieldMatrix var79 = var52.subtract(var77);
    org.apache.commons.math.fraction.BigFractionField var80 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var81 = var80.getZero();
    org.apache.commons.math.fraction.BigFraction var82 = var80.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var85 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var80, 10, 10);
    org.apache.commons.math.linear.FieldMatrix var87 = var85.getRowMatrix(0);
    org.apache.commons.math.fraction.BigFraction var90 = new org.apache.commons.math.fraction.BigFraction(10L, 1L);
    org.apache.commons.math.linear.FieldMatrix var91 = var85.scalarAdd((org.apache.commons.math.FieldElement)var90);
    org.apache.commons.math.linear.BlockFieldMatrix var92 = var79.multiply(var85);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math.FieldElement var95 = var85.getEntry(2147483646, (-9));
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == (-1000.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);

  }

  public void test128() {}
//   public void test128() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test128"); }
// 
// 
//     org.apache.commons.math.ode.events.EventHandler var0 = null;
//     org.apache.commons.math.ode.events.EventState var4 = new org.apache.commons.math.ode.events.EventState(var0, 0.0d, (-10.0d), 8);
//     double[] var6 = null;
//     boolean var7 = var4.reset(1.0d, var6);
//     double var8 = var4.getConvergence();
//     int var9 = var4.getMaxIterationCount();
//     org.apache.commons.math.ode.events.EventHandler var10 = var4.getEventHandler();
//     int var11 = var4.getMaxIterationCount();
//     double var12 = var4.getEventTime();
//     double var13 = var4.getMaxCheckInterval();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.0d);
// 
//   }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test129"); }


    org.apache.commons.math.ode.events.CombinedEventsManager var0 = new org.apache.commons.math.ode.events.CombinedEventsManager();
    boolean var1 = var0.isEmpty();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test130"); }


    org.apache.commons.math.FieldElement var0 = null;
    org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor var1 = new org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor(var0);
    var1.start(100, 2147483647, 1, 10, 100, 100);
    org.apache.commons.math.FieldElement var9 = var1.end();
    org.apache.commons.math.FieldElement var10 = var1.end();
    org.apache.commons.math.FieldElement var11 = var1.end();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test131"); }


    org.apache.commons.math.fraction.BigFractionField var1 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var2 = var1.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var3 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var2);
    org.apache.commons.math.fraction.BigFraction var5 = var2.subtract((-1L));
    org.apache.commons.math.FieldElement[] var6 = new org.apache.commons.math.FieldElement[] { var2};
    org.apache.commons.math.linear.FieldMatrix var7 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var6);
    org.apache.commons.math.linear.FieldMatrix var8 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createColumnFieldMatrix(var6);
    java.lang.ArithmeticException var9 = org.apache.commons.math.MathRuntimeException.createArithmeticException("java.io.IOException: ", (java.lang.Object[])var6);
    org.apache.commons.math.linear.FieldVector var10 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var6);
    org.apache.commons.math.linear.FieldMatrix var11 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var6);
    org.apache.commons.math.linear.FieldMatrix var12 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var6);
    org.apache.commons.math.linear.FieldMatrix var13 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createRowFieldMatrix(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test132() {}
//   public void test132() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test132"); }
// 
// 
//     org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var4 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(0.0d, (-1.0d), 10.0d, 100.0d);
//     int var5 = var4.getMaxEvaluations();
//     var4.setSafety(1.0d);
//     double var8 = var4.getMaxGrowth();
//     var4.clearEventHandlers();
//     double var10 = var4.getMaxGrowth();
//     java.util.Collection var11 = var4.getStepHandlers();
//     java.lang.Throwable var13 = null;
//     double[] var16 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var18 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var16, false);
//     double var19 = var18.getCurrentTime();
//     double[] var20 = var18.getInterpolatedState();
//     java.lang.Object[] var25 = new java.lang.Object[] { 0.0d};
//     java.util.NoSuchElementException var26 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", var25);
//     java.lang.IllegalArgumentException var27 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("", var25);
//     org.apache.commons.math.FunctionEvaluationException var28 = new org.apache.commons.math.FunctionEvaluationException(var13, var20, "org.apache.commons.math.FunctionEvaluationException: evaluation failed for argument = {-1; 0}", var25);
//     double[] var31 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var33 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var31, false);
//     double[] var34 = var33.getInterpolatedDerivatives();
//     org.apache.commons.math.FunctionEvaluationException var35 = new org.apache.commons.math.FunctionEvaluationException(var13, var34);
//     org.apache.commons.math.linear.RealMatrix var36 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var34);
//     org.apache.commons.math.linear.RealMatrix var37 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(var34);
//     java.lang.Object[] var42 = new java.lang.Object[] { 0L};
//     java.text.ParseException var43 = org.apache.commons.math.MathRuntimeException.createParseException((-1), "", var42);
//     org.apache.commons.math.ode.events.EventException var44 = new org.apache.commons.math.ode.events.EventException("", var42);
//     java.lang.Object[] var45 = var44.getArguments();
//     java.lang.Object[] var53 = new java.lang.Object[] { 0L};
//     java.text.ParseException var54 = org.apache.commons.math.MathRuntimeException.createParseException((-1), "", var53);
//     org.apache.commons.math.FunctionEvaluationException var55 = new org.apache.commons.math.FunctionEvaluationException(100.0d, "", var53);
//     double[] var56 = var55.getArgument();
//     double[] var57 = var55.getArgument();
//     org.apache.commons.math.linear.Array2DRowRealMatrix var58 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var57);
//     double[] var61 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var63 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var61, false);
//     double[][] var64 = new double[][] { var61};
//     org.apache.commons.math.linear.BlockRealMatrix var65 = new org.apache.commons.math.linear.BlockRealMatrix(var64);
//     org.apache.commons.math.linear.BlockRealMatrix var67 = var65.getColumnMatrix(1);
//     double[] var70 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var72 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var70, false);
//     double var73 = var72.getCurrentTime();
//     double[] var74 = var72.getInterpolatedState();
//     double[] var75 = var65.operate(var74);
//     org.apache.commons.math.FunctionEvaluationException var76 = new org.apache.commons.math.FunctionEvaluationException(var74);
//     org.apache.commons.math.linear.RealMatrix var77 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(var74);
//     org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var78 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator((-10.0d), 0.9d, var57, var74);
//     org.apache.commons.math.linear.RealMatrix var79 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(var74);
//     org.apache.commons.math.FunctionEvaluationException var80 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable)var44, var74);
//     var4.computeDerivatives(101000.0d, var34, var74);
// 
//   }

  public void test133() {}
//   public void test133() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test133"); }
// 
// 
//     double[] var5 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var7 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var5, false);
//     double var8 = var7.getCurrentTime();
//     double[] var9 = var7.getInterpolatedState();
//     double[] var10 = var7.getInterpolatedDerivatives();
//     double[] var13 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var15 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var13, false);
//     double var16 = var15.getCurrentTime();
//     double[] var17 = var15.getInterpolatedState();
//     double[] var18 = var15.getInterpolatedDerivatives();
//     org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var19 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, Double.NaN, 1.0E-15d, var10, var18);
//     double var20 = var19.getCurrentStepStart();
//     double[] var23 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var25 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var23, false);
//     double var26 = var25.getCurrentTime();
//     double[] var27 = var25.getInterpolatedState();
//     org.apache.commons.math.linear.BigMatrix var28 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(var27);
//     double[][] var29 = new double[][] { var27};
//     org.apache.commons.math.linear.RealMatrix var30 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(var29);
//     org.apache.commons.math.linear.BlockRealMatrix var31 = new org.apache.commons.math.linear.BlockRealMatrix(var29);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var32 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var29);
//     double[][] var33 = var32.getDataRef();
//     org.apache.commons.math.linear.Array2DRowRealMatrix var34 = var19.updateHighOrderDerivativesPhase1(var32);
//     double[] var40 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var42 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var40, false);
//     double var43 = var42.getCurrentTime();
//     double[] var44 = var42.getInterpolatedState();
//     double[] var45 = var42.getInterpolatedDerivatives();
//     double[] var48 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var50 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var48, false);
//     double var51 = var50.getCurrentTime();
//     double[] var52 = var50.getInterpolatedState();
//     double[] var53 = var50.getInterpolatedDerivatives();
//     org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var54 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, Double.NaN, 1.0E-15d, var45, var53);
//     var54.setMinReduction(0.0d);
//     org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var61 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(0.0d, (-1.0d), 10.0d, 100.0d);
//     int var62 = var61.getMaxEvaluations();
//     var61.setSafety(1.0d);
//     double var65 = var61.getMaxGrowth();
//     int var66 = var61.getEvaluations();
//     double var67 = var61.getSafety();
//     var54.setStarterIntegrator((org.apache.commons.math.ode.FirstOrderIntegrator)var61);
//     var54.setMaxEvaluations((-1));
//     var54.setSafety(0.0d);
//     double[] var77 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var79 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var77, false);
//     double[][] var80 = new double[][] { var77};
//     org.apache.commons.math.linear.BlockRealMatrix var81 = new org.apache.commons.math.linear.BlockRealMatrix(var80);
//     org.apache.commons.math.MaxIterationsExceededException var82 = new org.apache.commons.math.MaxIterationsExceededException(0, "", (java.lang.Object[])var80);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var84 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var80, false);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var85 = var54.updateHighOrderDerivativesPhase1(var84);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var86 = var34.add(var84);
//     org.apache.commons.math.linear.RealMatrix var87 = var86.copy();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var86.setEntry(0, (-1000), Double.NaN);
//       fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
//     } catch (org.apache.commons.math.linear.MatrixIndexException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var62 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == 10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var66 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var67 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var85);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var86);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var87);
// 
//   }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test134"); }


    java.lang.Object[] var4 = new java.lang.Object[] { 0L};
    java.text.ParseException var5 = org.apache.commons.math.MathRuntimeException.createParseException((-1), "", var4);
    org.apache.commons.math.ode.events.EventException var6 = new org.apache.commons.math.ode.events.EventException("", var4);
    java.io.IOException var7 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable)var6);
    java.lang.Object[] var14 = new java.lang.Object[] { 0L};
    org.apache.commons.math.MaxEvaluationsExceededException var15 = new org.apache.commons.math.MaxEvaluationsExceededException(100, "", var14);
    org.apache.commons.math.MathException var16 = new org.apache.commons.math.MathException("matrix is singular", var14);
    java.lang.ArrayIndexOutOfBoundsException var17 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("hi!", var14);
    org.apache.commons.math.ConvergenceException var18 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable)var6, "hi!", var14);
    double[] var25 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var27 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var25, false);
    double[][] var28 = new double[][] { var25};
    org.apache.commons.math.linear.BlockRealMatrix var29 = new org.apache.commons.math.linear.BlockRealMatrix(var28);
    org.apache.commons.math.MaxIterationsExceededException var30 = new org.apache.commons.math.MaxIterationsExceededException(0, "", (java.lang.Object[])var28);
    org.apache.commons.math.linear.Array2DRowRealMatrix var32 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var28, false);
    java.util.NoSuchElementException var33 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("org.apache.commons.math.MathRuntimeException: hi!", (java.lang.Object[])var28);
    double[][] var34 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var28);
    org.apache.commons.math.ConvergenceException var35 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable)var6, "hi!", (java.lang.Object[])var28);
    org.apache.commons.math.linear.BlockRealMatrix var36 = new org.apache.commons.math.linear.BlockRealMatrix(var28);
    org.apache.commons.math.linear.RealMatrix var38 = var36.scalarMultiply(1.4142135623730951d);
    double[] var42 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var44 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var42, false);
    double[][] var45 = new double[][] { var42};
    org.apache.commons.math.linear.BlockRealMatrix var46 = new org.apache.commons.math.linear.BlockRealMatrix(var45);
    org.apache.commons.math.linear.BlockRealMatrix var48 = var46.getColumnMatrix(1);
    double[] var51 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var53 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var51, false);
    double[][] var54 = new double[][] { var51};
    org.apache.commons.math.linear.BlockRealMatrix var55 = new org.apache.commons.math.linear.BlockRealMatrix(var54);
    org.apache.commons.math.linear.BlockRealMatrix var57 = var55.getColumnMatrix(1);
    org.apache.commons.math.linear.BlockRealMatrix var58 = var48.subtract(var57);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var36.setRowMatrix((-11), var57);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test135"); }


    org.apache.commons.math.fraction.BigFractionField var0 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var1 = var0.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var2 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var1);
    org.apache.commons.math.fraction.BigFraction var4 = var1.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var6 = var1.subtract(10L);
    float var7 = var1.floatValue();
    org.apache.commons.math.fraction.BigFraction var9 = var1.divide(100L);
    org.apache.commons.math.fraction.BigFraction var10 = var9.negate();
    float var11 = var10.floatValue();
    org.apache.commons.math.fraction.FractionConversionException var15 = new org.apache.commons.math.fraction.FractionConversionException(10.0d, 1L, (-1L));
    boolean var16 = var10.equals((java.lang.Object)var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test136"); }


    org.apache.commons.math.fraction.BigFractionField var0 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var1 = var0.getZero();
    org.apache.commons.math.fraction.BigFraction var2 = var0.getOne();
    org.apache.commons.math.fraction.BigFractionField var3 = var2.getField();
    org.apache.commons.math.fraction.BigFraction var5 = var2.multiply(2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test137"); }


    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var4 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(1.4142135623730951d, 100.0d, 1.0d, 1.4142135623730951d);
    var4.setMinReduction(2.0d);
    java.util.Collection var7 = var4.getStepHandlers();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test138"); }


    org.apache.commons.math.fraction.BigFractionField var0 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var1 = var0.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var2 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var1);
    org.apache.commons.math.fraction.BigFraction var4 = var1.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var6 = var1.subtract(10L);
    double var7 = var6.percentageValue();
    int var8 = var6.getNumeratorAsInt();
    org.apache.commons.math.fraction.BigFraction var10 = var6.multiply(1L);
    org.apache.commons.math.fraction.BigFraction var11 = var6.abs();
    org.apache.commons.math.fraction.BigFraction var13 = var11.subtract(0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-1000.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-10));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test139"); }


    org.apache.commons.math.fraction.BigFractionField var0 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var1 = var0.getZero();
    org.apache.commons.math.fraction.BigFraction var2 = var0.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var5 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var0, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var6 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var7 = var6.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var8 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var7);
    var8.start(2147483647, 0, 100, (-10), 100, 0);
    org.apache.commons.math.FieldElement var16 = var5.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var8);
    org.apache.commons.math.fraction.BigFractionField var17 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var18 = var17.getZero();
    org.apache.commons.math.fraction.BigFraction var19 = var17.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var22 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var17, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var23 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var24 = var23.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var25 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var24);
    var25.start(2147483647, 0, 100, (-10), 100, 0);
    org.apache.commons.math.FieldElement var33 = var22.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var25);
    org.apache.commons.math.linear.BlockFieldMatrix var34 = var5.subtract(var22);
    org.apache.commons.math.fraction.BigFractionField var35 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var36 = var35.getZero();
    org.apache.commons.math.fraction.BigFraction var37 = var35.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var40 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var35, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var41 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var42 = var41.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var43 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var42);
    var43.start(2147483647, 0, 100, (-10), 100, 0);
    org.apache.commons.math.FieldElement var51 = var40.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var43);
    org.apache.commons.math.linear.BlockFieldMatrix var52 = var34.multiply(var40);
    org.apache.commons.math.fraction.BigFractionField var53 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var54 = var53.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var55 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var54);
    org.apache.commons.math.fraction.BigFraction var57 = var54.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var59 = var54.subtract(10L);
    double var60 = var59.percentageValue();
    org.apache.commons.math.fraction.BigFraction var62 = var59.multiply(1);
    org.apache.commons.math.fraction.BigFractionField var63 = var59.getField();
    org.apache.commons.math.linear.Array2DRowFieldMatrix var64 = new org.apache.commons.math.linear.Array2DRowFieldMatrix((org.apache.commons.math.Field)var63);
    boolean var65 = var64.isSquare();
    org.apache.commons.math.fraction.BigFractionField var66 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var67 = var66.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var68 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var67);
    org.apache.commons.math.FieldElement var69 = var64.walkInColumnOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var68);
    org.apache.commons.math.FieldElement var70 = var68.end();
    org.apache.commons.math.FieldElement var71 = var52.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var68);
    org.apache.commons.math.fraction.BigFractionField var72 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var73 = var72.getZero();
    org.apache.commons.math.fraction.BigFraction var74 = var72.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var77 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var72, 10, 10);
    int var78 = var77.getRowDimension();
    org.apache.commons.math.linear.BlockFieldMatrix var79 = var52.subtract(var77);
    org.apache.commons.math.linear.FieldMatrix var80 = var79.transpose();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math.FieldElement[] var82 = var79.getRow(10);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == (-1000.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test140"); }


    org.apache.commons.math.ode.events.CombinedEventsManager var0 = new org.apache.commons.math.ode.events.CombinedEventsManager();
    double[] var4 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var6 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var4, false);
    double[][] var7 = new double[][] { var4};
    org.apache.commons.math.linear.BlockRealMatrix var8 = new org.apache.commons.math.linear.BlockRealMatrix(var7);
    double[] var11 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var13 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var11, false);
    double[] var14 = var13.getInterpolatedState();
    double[] var15 = var8.operate(var14);
    boolean var16 = var0.reset(1.0E-6d, var15);
    boolean var17 = var0.isEmpty();
    var0.clearEventsHandlers();
    java.util.Collection var19 = var0.getEventsHandlers();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test141() {}
//   public void test141() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test141"); }
// 
// 
//     java.lang.Object[] var6 = new java.lang.Object[] { 0L};
//     java.text.ParseException var7 = org.apache.commons.math.MathRuntimeException.createParseException((-1), "", var6);
//     org.apache.commons.math.ode.events.EventException var8 = new org.apache.commons.math.ode.events.EventException("", var6);
//     java.io.IOException var9 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable)var8);
//     java.lang.Object[] var16 = new java.lang.Object[] { 0L};
//     org.apache.commons.math.MaxEvaluationsExceededException var17 = new org.apache.commons.math.MaxEvaluationsExceededException(100, "", var16);
//     org.apache.commons.math.MathException var18 = new org.apache.commons.math.MathException("matrix is singular", var16);
//     java.lang.ArrayIndexOutOfBoundsException var19 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("hi!", var16);
//     org.apache.commons.math.ConvergenceException var20 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable)var8, "hi!", var16);
//     double[] var27 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var29 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var27, false);
//     double[][] var30 = new double[][] { var27};
//     org.apache.commons.math.linear.BlockRealMatrix var31 = new org.apache.commons.math.linear.BlockRealMatrix(var30);
//     org.apache.commons.math.MaxIterationsExceededException var32 = new org.apache.commons.math.MaxIterationsExceededException(0, "", (java.lang.Object[])var30);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var34 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var30, false);
//     java.util.NoSuchElementException var35 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("org.apache.commons.math.MathRuntimeException: hi!", (java.lang.Object[])var30);
//     double[][] var36 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var30);
//     org.apache.commons.math.ConvergenceException var37 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable)var8, "hi!", (java.lang.Object[])var30);
//     org.apache.commons.math.MathException var38 = new org.apache.commons.math.MathException("Maximal number of iterations ({0}) exceeded", (java.lang.Object[])var30);
//     java.lang.ArithmeticException var39 = org.apache.commons.math.MathRuntimeException.createArithmeticException("2147483647", (java.lang.Object[])var30);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var40 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var30);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var41 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var30);
//     org.apache.commons.math.linear.RealMatrixChangingVisitor var42 = null;
//     double var43 = var41.walkInColumnOrder(var42);
// 
//   }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test142"); }


    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var4 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator((-10.0d), (-10.0d), 1.0E-15d, 0.0d);

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test143"); }


    org.apache.commons.math.fraction.BigFractionField var0 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var1 = var0.getZero();
    org.apache.commons.math.fraction.BigFraction var2 = var0.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var5 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var0, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var6 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var7 = var6.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var8 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var7);
    var8.start(2147483647, 0, 100, (-10), 100, 0);
    org.apache.commons.math.FieldElement var16 = var5.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var8);
    org.apache.commons.math.fraction.BigFractionField var17 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var18 = var17.getZero();
    org.apache.commons.math.fraction.BigFraction var19 = var17.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var22 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var17, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var23 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var24 = var23.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var25 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var24);
    var25.start(2147483647, 0, 100, (-10), 100, 0);
    org.apache.commons.math.FieldElement var33 = var22.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var25);
    org.apache.commons.math.linear.BlockFieldMatrix var34 = var5.subtract(var22);
    org.apache.commons.math.fraction.BigFractionField var35 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var36 = var35.getZero();
    double var38 = var36.pow((-1.0d));
    org.apache.commons.math.fraction.BigFraction var39 = var36.abs();
    org.apache.commons.math.linear.FieldMatrix var40 = var34.scalarAdd((org.apache.commons.math.FieldElement)var39);
    org.apache.commons.math.Field var41 = var34.getField();
    org.apache.commons.math.linear.FieldVector var43 = var34.getRowVector(0);
    org.apache.commons.math.linear.FieldMatrix var44 = var34.transpose();
    int var45 = var34.getColumnDimension();
    org.apache.commons.math.linear.FieldMatrix var46 = var34.copy();
    org.apache.commons.math.linear.Array2DRowRealMatrix var47 = org.apache.commons.math.linear.MatrixUtils.bigFractionMatrixToRealMatrix(var46);
    org.apache.commons.math.linear.RealMatrixChangingVisitor var48 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var53 = var47.walkInRowOrder(var48, 1, 1, 0, 2147483647);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test144"); }


    double[] var2 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var4 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var2, false);
    double[][] var5 = new double[][] { var2};
    org.apache.commons.math.linear.BlockRealMatrix var6 = new org.apache.commons.math.linear.BlockRealMatrix(var5);
    double[] var9 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var11 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var9, false);
    double[] var12 = var11.getInterpolatedState();
    double[] var13 = var6.operate(var12);
    org.apache.commons.math.linear.BlockRealMatrix var15 = var6.scalarAdd((-1.0d));
    org.apache.commons.math.linear.RealMatrix var17 = var6.scalarAdd(0.0d);
    double[] var20 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var22 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var20, false);
    double[][] var23 = new double[][] { var20};
    org.apache.commons.math.linear.BlockRealMatrix var24 = new org.apache.commons.math.linear.BlockRealMatrix(var23);
    org.apache.commons.math.linear.BlockRealMatrix var25 = var24.transpose();
    org.apache.commons.math.linear.BlockRealMatrix var26 = var6.add((org.apache.commons.math.linear.RealMatrix)var24);
    double[] var28 = var6.getColumn(0);
    int var29 = var6.getColumnDimension();
    org.apache.commons.math.linear.BlockRealMatrix var30 = var6.transpose();
    org.apache.commons.math.linear.RealMatrixPreservingVisitor var31 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var36 = var30.walkInColumnOrder(var31, 0, 10, (-1000), (-10));
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test145() {}
//   public void test145() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test145"); }
// 
// 
//     double[] var2 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var4 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var2, false);
//     double[][] var5 = new double[][] { var2};
//     org.apache.commons.math.linear.BlockRealMatrix var6 = new org.apache.commons.math.linear.BlockRealMatrix(var5);
//     org.apache.commons.math.linear.BlockRealMatrix var8 = var6.getColumnMatrix(1);
//     double[] var11 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var13 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var11, false);
//     double[][] var14 = new double[][] { var11};
//     org.apache.commons.math.linear.BlockRealMatrix var15 = new org.apache.commons.math.linear.BlockRealMatrix(var14);
//     org.apache.commons.math.linear.BlockRealMatrix var17 = var15.getColumnMatrix(1);
//     org.apache.commons.math.linear.BlockRealMatrix var18 = var8.subtract(var17);
//     double[] var20 = var8.getRow(0);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var20);
//     double[] var24 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var26 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var24, false);
//     double var27 = var26.getCurrentTime();
//     double[] var28 = var26.getInterpolatedState();
//     org.apache.commons.math.linear.BigMatrix var29 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(var28);
//     double[][] var30 = new double[][] { var28};
//     org.apache.commons.math.linear.RealMatrix var31 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(var30);
//     org.apache.commons.math.linear.BlockRealMatrix var32 = new org.apache.commons.math.linear.BlockRealMatrix(var30);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var33 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var30);
//     double[] var38 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var40 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var38, false);
//     double[][] var41 = new double[][] { var38};
//     org.apache.commons.math.linear.BlockRealMatrix var42 = new org.apache.commons.math.linear.BlockRealMatrix(var41);
//     org.apache.commons.math.MaxIterationsExceededException var43 = new org.apache.commons.math.MaxIterationsExceededException(0, "", (java.lang.Object[])var41);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var45 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var41, false);
//     double[] var50 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var52 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var50, false);
//     double[][] var53 = new double[][] { var50};
//     org.apache.commons.math.linear.BlockRealMatrix var54 = new org.apache.commons.math.linear.BlockRealMatrix(var53);
//     org.apache.commons.math.MaxIterationsExceededException var55 = new org.apache.commons.math.MaxIterationsExceededException(0, "", (java.lang.Object[])var53);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var57 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var53, false);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var58 = var45.subtract(var57);
//     org.apache.commons.math.linear.RealMatrix var61 = var58.createMatrix(10, 1);
//     int var62 = var58.getRowDimension();
//     org.apache.commons.math.linear.RealMatrix var63 = var33.subtract((org.apache.commons.math.linear.RealMatrix)var58);
//     double[] var68 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var70 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var68, false);
//     double[][] var71 = new double[][] { var68};
//     org.apache.commons.math.linear.BlockRealMatrix var72 = new org.apache.commons.math.linear.BlockRealMatrix(var71);
//     org.apache.commons.math.MaxIterationsExceededException var73 = new org.apache.commons.math.MaxIterationsExceededException(0, "", (java.lang.Object[])var71);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var75 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var71, false);
//     double[] var80 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var82 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var80, false);
//     double[][] var83 = new double[][] { var80};
//     org.apache.commons.math.linear.BlockRealMatrix var84 = new org.apache.commons.math.linear.BlockRealMatrix(var83);
//     org.apache.commons.math.MaxIterationsExceededException var85 = new org.apache.commons.math.MaxIterationsExceededException(0, "", (java.lang.Object[])var83);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var87 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var83, false);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var88 = var75.subtract(var87);
//     org.apache.commons.math.linear.RealMatrix var89 = var88.copy();
//     org.apache.commons.math.linear.Array2DRowRealMatrix var90 = var33.add(var88);
//     org.apache.commons.math.linear.RealMatrix var91 = var21.multiply((org.apache.commons.math.linear.RealMatrix)var90);
//     double[][] var92 = var90.getDataRef();
//     double[][] var93 = var90.getData();
//     org.apache.commons.math.linear.RealMatrix var94 = var90.copy();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var62 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var71);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var83);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var88);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var89);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var90);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var91);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var92);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var93);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var94);
// 
//   }

  public void test146() {}
//   public void test146() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test146"); }
// 
// 
//     double[] var2 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var4 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var2, false);
//     double var5 = var4.getCurrentTime();
//     double[] var6 = var4.getInterpolatedState();
//     org.apache.commons.math.linear.BigMatrix var7 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(var6);
//     double[][] var8 = new double[][] { var6};
//     org.apache.commons.math.linear.RealMatrix var9 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(var8);
//     org.apache.commons.math.linear.BlockRealMatrix var10 = new org.apache.commons.math.linear.BlockRealMatrix(var8);
//     org.apache.commons.math.linear.BlockRealMatrix var13 = var10.createMatrix(2, 8);
//     double var14 = var13.getFrobeniusNorm();
//     double[] var17 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var19 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var17, false);
//     double var20 = var19.getCurrentTime();
//     double[] var21 = var19.getInterpolatedState();
//     org.apache.commons.math.linear.BigMatrix var22 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(var21);
//     double[][] var23 = new double[][] { var21};
//     org.apache.commons.math.linear.RealMatrix var24 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(var23);
//     org.apache.commons.math.linear.BlockRealMatrix var25 = new org.apache.commons.math.linear.BlockRealMatrix(var23);
//     org.apache.commons.math.linear.BlockRealMatrix var28 = var25.createMatrix(2, 8);
//     org.apache.commons.math.linear.BlockRealMatrix var30 = var28.getColumnMatrix(2);
//     org.apache.commons.math.fraction.BigFractionField var31 = org.apache.commons.math.fraction.BigFractionField.getInstance();
//     org.apache.commons.math.fraction.BigFraction var32 = var31.getZero();
//     org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var33 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var32);
//     org.apache.commons.math.FieldElement[] var34 = new org.apache.commons.math.FieldElement[] { var32};
//     org.apache.commons.math.linear.FieldMatrix var35 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createColumnFieldMatrix(var34);
//     org.apache.commons.math.FieldElement[][] var36 = new org.apache.commons.math.FieldElement[][] { var34};
//     org.apache.commons.math.linear.FieldMatrix var37 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldMatrix(var36);
//     org.apache.commons.math.linear.FieldLUDecompositionImpl var38 = new org.apache.commons.math.linear.FieldLUDecompositionImpl(var37);
//     int[] var39 = var38.getPivot();
//     double[] var42 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var44 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var42, false);
//     double[][] var45 = new double[][] { var42};
//     org.apache.commons.math.linear.BlockRealMatrix var46 = new org.apache.commons.math.linear.BlockRealMatrix(var45);
//     double[] var49 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var51 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var49, false);
//     double[] var52 = var51.getInterpolatedState();
//     double[] var53 = var46.operate(var52);
//     org.apache.commons.math.linear.BlockRealMatrix var55 = var46.scalarAdd((-1.0d));
//     org.apache.commons.math.linear.RealMatrix var57 = var46.scalarAdd(0.0d);
//     double[] var60 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var62 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var60, false);
//     double[][] var63 = new double[][] { var60};
//     org.apache.commons.math.linear.BlockRealMatrix var64 = new org.apache.commons.math.linear.BlockRealMatrix(var63);
//     org.apache.commons.math.linear.BlockRealMatrix var65 = var64.transpose();
//     org.apache.commons.math.linear.BlockRealMatrix var66 = var46.add((org.apache.commons.math.linear.RealMatrix)var64);
//     org.apache.commons.math.fraction.BigFractionField var67 = org.apache.commons.math.fraction.BigFractionField.getInstance();
//     org.apache.commons.math.fraction.BigFraction var68 = var67.getZero();
//     org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var69 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var68);
//     org.apache.commons.math.FieldElement[] var70 = new org.apache.commons.math.FieldElement[] { var68};
//     org.apache.commons.math.linear.FieldMatrix var71 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createColumnFieldMatrix(var70);
//     org.apache.commons.math.FieldElement[][] var72 = new org.apache.commons.math.FieldElement[][] { var70};
//     org.apache.commons.math.linear.FieldMatrix var73 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldMatrix(var72);
//     org.apache.commons.math.linear.FieldLUDecompositionImpl var74 = new org.apache.commons.math.linear.FieldLUDecompositionImpl(var73);
//     int[] var75 = var74.getPivot();
//     org.apache.commons.math.fraction.BigFractionField var76 = org.apache.commons.math.fraction.BigFractionField.getInstance();
//     org.apache.commons.math.fraction.BigFraction var77 = var76.getZero();
//     org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var78 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var77);
//     org.apache.commons.math.FieldElement[] var79 = new org.apache.commons.math.FieldElement[] { var77};
//     org.apache.commons.math.linear.FieldMatrix var80 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createColumnFieldMatrix(var79);
//     org.apache.commons.math.FieldElement[][] var81 = new org.apache.commons.math.FieldElement[][] { var79};
//     org.apache.commons.math.linear.FieldMatrix var82 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldMatrix(var81);
//     org.apache.commons.math.linear.FieldLUDecompositionImpl var83 = new org.apache.commons.math.linear.FieldLUDecompositionImpl(var82);
//     int[] var84 = var83.getPivot();
//     org.apache.commons.math.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math.linear.AnyMatrix)var46, var75, var84);
//     org.apache.commons.math.linear.RealMatrix var86 = var28.getSubMatrix(var39, var84);
//     org.apache.commons.math.linear.BlockRealMatrix var87 = var13.add((org.apache.commons.math.linear.RealMatrix)var28);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var87.luDecompose();
//       fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException");
//     } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var70);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var71);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var72);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var75);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var79);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var81);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var82);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var84);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var86);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var87);
// 
//   }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test147"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer var1 = org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer.getInstance((-9));
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }

  }

  public void test148() {}
//   public void test148() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test148"); }
// 
// 
//     double[] var4 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var6 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var4, false);
//     double[][] var7 = new double[][] { var4};
//     org.apache.commons.math.linear.BlockRealMatrix var8 = new org.apache.commons.math.linear.BlockRealMatrix(var7);
//     org.apache.commons.math.MaxIterationsExceededException var9 = new org.apache.commons.math.MaxIterationsExceededException(0, "", (java.lang.Object[])var7);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var7, false);
//     boolean var12 = var11.isSquare();
//     double var13 = var11.getNorm();
//     java.lang.Object[] var20 = new java.lang.Object[] { 0L};
//     java.text.ParseException var21 = org.apache.commons.math.MathRuntimeException.createParseException((-1), "", var20);
//     org.apache.commons.math.FunctionEvaluationException var22 = new org.apache.commons.math.FunctionEvaluationException(100.0d, "", var20);
//     double[] var23 = var22.getArgument();
//     double[] var24 = var22.getArgument();
//     org.apache.commons.math.linear.Array2DRowRealMatrix var25 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var24);
//     var11.setColumn(1, var24);
//     double[][] var27 = var11.getDataRef();
//     org.apache.commons.math.linear.RealMatrixChangingVisitor var28 = null;
//     double var29 = var11.walkInColumnOrder(var28);
// 
//   }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test149"); }


    org.apache.commons.math.fraction.BigFractionField var3 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var4 = var3.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var5 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var4);
    org.apache.commons.math.fraction.BigFraction var7 = var4.subtract((-1L));
    org.apache.commons.math.FieldElement[] var8 = new org.apache.commons.math.FieldElement[] { var4};
    org.apache.commons.math.linear.FieldMatrix var9 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var8);
    org.apache.commons.math.linear.FieldMatrix var10 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var8);
    org.apache.commons.math.linear.MatrixIndexException var11 = new org.apache.commons.math.linear.MatrixIndexException("java.io.IOException: ", (java.lang.Object[])var8);
    java.lang.Object[] var12 = var11.getArguments();
    org.apache.commons.math.FunctionEvaluationException var13 = new org.apache.commons.math.FunctionEvaluationException(1.0E-6d, "BlockRealMatrix{{0.0}}", var12);
    double[] var14 = var13.getArgument();
    org.apache.commons.math.FunctionEvaluationException var15 = new org.apache.commons.math.FunctionEvaluationException(var14);
    org.apache.commons.math.linear.BigMatrix var16 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test150() {}
//   public void test150() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test150"); }
// 
// 
//     org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var0 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator();
//     double[] var3 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var5 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var3, false);
//     double[][] var6 = new double[][] { var3};
//     org.apache.commons.math.linear.BlockRealMatrix var7 = new org.apache.commons.math.linear.BlockRealMatrix(var6);
//     double[] var10 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var12 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var10, false);
//     double[] var13 = var12.getInterpolatedState();
//     double[] var14 = var7.operate(var13);
//     var0.reinitialize(var14, true);
//     org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var17 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator(var0);
//     var17.storeTime(1.4142135623730951d);
//     double var20 = var17.getCurrentTime();
//     double var21 = var17.getPreviousTime();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1.4142135623730951d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == Double.NaN);
// 
//   }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test151"); }


    org.apache.commons.math.Field var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math.linear.Array2DRowFieldMatrix var3 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var0, 8, (-1000));
      fail("Expected exception of type Exception");
    } catch (Exception e) {
      // Expected exception.
    }

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test152"); }


    org.apache.commons.math.MaxIterationsExceededException var1 = new org.apache.commons.math.MaxIterationsExceededException(0);
    org.apache.commons.math.ode.DerivativeException var2 = new org.apache.commons.math.ode.DerivativeException((java.lang.Throwable)var1);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test153"); }


    java.lang.Object[] var6 = new java.lang.Object[] { 0L};
    org.apache.commons.math.MaxEvaluationsExceededException var7 = new org.apache.commons.math.MaxEvaluationsExceededException(100, "", var6);
    org.apache.commons.math.MathException var8 = new org.apache.commons.math.MathException("matrix is singular", var6);
    org.apache.commons.math.MathRuntimeException var9 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable)var8);
    java.lang.Object[] var15 = new java.lang.Object[] { 0L};
    java.text.ParseException var16 = org.apache.commons.math.MathRuntimeException.createParseException((-1), "", var15);
    org.apache.commons.math.ode.events.EventException var17 = new org.apache.commons.math.ode.events.EventException("", var15);
    java.lang.Object[] var18 = var17.getArguments();
    org.apache.commons.math.ConvergenceException var19 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable)var9, "2147483647", var18);
    org.apache.commons.math.FunctionEvaluationException var20 = new org.apache.commons.math.FunctionEvaluationException(0.0d, "hi!", var18);
    double[] var21 = var20.getArgument();
    double[] var24 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var26 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var24, false);
    org.apache.commons.math.FunctionEvaluationException var27 = new org.apache.commons.math.FunctionEvaluationException(var24);
    org.apache.commons.math.fraction.FractionConversionException var30 = new org.apache.commons.math.fraction.FractionConversionException(0.0d, (-1));
    java.lang.Object[] var36 = new java.lang.Object[] { 0L};
    java.text.ParseException var37 = org.apache.commons.math.MathRuntimeException.createParseException((-1), "", var36);
    org.apache.commons.math.FunctionEvaluationException var38 = new org.apache.commons.math.FunctionEvaluationException(100.0d, "", var36);
    double[] var39 = var38.getArgument();
    org.apache.commons.math.FunctionEvaluationException var40 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable)var30, var39);
    org.apache.commons.math.FunctionEvaluationException var41 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable)var27, var39);
    double[] var42 = var41.getArgument();
    org.apache.commons.math.FunctionEvaluationException var43 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable)var20, var42);
    java.lang.String var44 = var20.getPattern();
    org.apache.commons.math.fraction.BigFractionField var48 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var49 = var48.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var50 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var49);
    org.apache.commons.math.fraction.BigFraction var52 = var49.subtract((-1L));
    org.apache.commons.math.FieldElement[] var53 = new org.apache.commons.math.FieldElement[] { var49};
    org.apache.commons.math.linear.FieldMatrix var54 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var53);
    org.apache.commons.math.FieldElement[][] var55 = new org.apache.commons.math.FieldElement[][] { var53};
    org.apache.commons.math.linear.Array2DRowFieldMatrix var56 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var55);
    org.apache.commons.math.linear.FieldMatrix var57 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldMatrix(var55);
    org.apache.commons.math.MathException var58 = new org.apache.commons.math.MathException("org.apache.commons.math.linear.NonSquareMatrixException: a 100x1 matrix was provided instead of a square matrix", (java.lang.Object[])var55);
    org.apache.commons.math.FunctionEvaluationException var59 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable)var20, 1.0E100d, "BlockFieldMatrix{{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0}}", (java.lang.Object[])var55);
    org.apache.commons.math.linear.FieldMatrix var60 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldMatrix(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var44 + "' != '" + "hi!"+ "'", var44.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);

  }

  public void test154() {}
//   public void test154() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test154"); }
// 
// 
//     double[] var2 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var4 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var2, false);
//     double[][] var5 = new double[][] { var2};
//     org.apache.commons.math.linear.BlockRealMatrix var6 = new org.apache.commons.math.linear.BlockRealMatrix(var5);
//     org.apache.commons.math.linear.BlockRealMatrix var8 = var6.getColumnMatrix(1);
//     double[] var11 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var13 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var11, false);
//     double var14 = var13.getCurrentTime();
//     double[] var15 = var13.getInterpolatedState();
//     double[] var16 = var6.operate(var15);
//     double var17 = var6.getFrobeniusNorm();
//     double[] var20 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var22 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var20, false);
//     org.apache.commons.math.FunctionEvaluationException var23 = new org.apache.commons.math.FunctionEvaluationException(var20);
//     org.apache.commons.math.fraction.FractionConversionException var26 = new org.apache.commons.math.fraction.FractionConversionException(0.0d, (-1));
//     java.lang.Object[] var32 = new java.lang.Object[] { 0L};
//     java.text.ParseException var33 = org.apache.commons.math.MathRuntimeException.createParseException((-1), "", var32);
//     org.apache.commons.math.FunctionEvaluationException var34 = new org.apache.commons.math.FunctionEvaluationException(100.0d, "", var32);
//     double[] var35 = var34.getArgument();
//     org.apache.commons.math.FunctionEvaluationException var36 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable)var26, var35);
//     org.apache.commons.math.FunctionEvaluationException var37 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable)var23, var35);
//     org.apache.commons.math.linear.RealVector var38 = org.apache.commons.math.linear.MatrixUtils.createRealVector(var35);
//     org.apache.commons.math.linear.RealVector var39 = var6.preMultiply(var38);
//     org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var40 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator();
//     double[] var43 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var45 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var43, false);
//     double[][] var46 = new double[][] { var43};
//     org.apache.commons.math.linear.BlockRealMatrix var47 = new org.apache.commons.math.linear.BlockRealMatrix(var46);
//     double[] var50 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var52 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var50, false);
//     double[] var53 = var52.getInterpolatedState();
//     double[] var54 = var47.operate(var53);
//     var40.reinitialize(var54, true);
//     org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var57 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator(var40);
//     double[] var62 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var64 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var62, false);
//     double[] var69 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var71 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var69, false);
//     double[][] var72 = new double[][] { var69};
//     org.apache.commons.math.linear.BlockRealMatrix var73 = new org.apache.commons.math.linear.BlockRealMatrix(var72);
//     org.apache.commons.math.MaxIterationsExceededException var74 = new org.apache.commons.math.MaxIterationsExceededException(0, "", (java.lang.Object[])var72);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var76 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var72, false);
//     double[] var81 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var83 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var81, false);
//     double[][] var84 = new double[][] { var81};
//     org.apache.commons.math.linear.BlockRealMatrix var85 = new org.apache.commons.math.linear.BlockRealMatrix(var84);
//     org.apache.commons.math.MaxIterationsExceededException var86 = new org.apache.commons.math.MaxIterationsExceededException(0, "", (java.lang.Object[])var84);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var88 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var84, false);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var89 = var76.subtract(var88);
//     org.apache.commons.math.linear.RealMatrix var92 = var89.createMatrix(10, 1);
//     int var93 = var89.getRowDimension();
//     java.lang.String var94 = var89.toString();
//     var40.reinitialize(100.0d, 1.0d, var62, var89);
//     org.apache.commons.math.linear.RealMatrix var96 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var62);
//     org.apache.commons.math.linear.BlockRealMatrix var97 = var6.subtract(var96);
//     double var98 = var97.getFrobeniusNorm();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var72);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var81);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var84);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var89);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var92);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var93 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var94 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0}}"+ "'", var94.equals("Array2DRowRealMatrix{{0.0,0.0}}"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var96);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var97);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var98 == 0.0d);
// 
//   }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test155"); }


    org.apache.commons.math.fraction.BigFractionField var0 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var1 = var0.getZero();
    org.apache.commons.math.fraction.BigFraction var2 = var0.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var5 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var0, 10, 10);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var6 = new org.apache.commons.math.linear.Array2DRowFieldMatrix((org.apache.commons.math.Field)var0);
    int var7 = var6.getColumnDimension();
    java.lang.Object[] var12 = new java.lang.Object[] { 0L};
    java.text.ParseException var13 = org.apache.commons.math.MathRuntimeException.createParseException((-1), "", var12);
    org.apache.commons.math.ode.events.EventException var14 = new org.apache.commons.math.ode.events.EventException("", var12);
    java.io.IOException var15 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable)var14);
    org.apache.commons.math.fraction.BigFractionField var18 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var19 = var18.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var20 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var19);
    org.apache.commons.math.fraction.BigFraction var22 = var19.subtract((-1L));
    org.apache.commons.math.FieldElement[] var23 = new org.apache.commons.math.FieldElement[] { var19};
    org.apache.commons.math.linear.FieldMatrix var24 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var23);
    org.apache.commons.math.linear.FieldMatrix var25 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var23);
    org.apache.commons.math.linear.MatrixIndexException var26 = new org.apache.commons.math.linear.MatrixIndexException("java.io.IOException: ", (java.lang.Object[])var23);
    org.apache.commons.math.MathRuntimeException var27 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable)var14, "matrix is singular", (java.lang.Object[])var23);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math.FieldElement[] var28 = var6.preMultiply(var23);
      fail("Expected exception of type Exception");
    } catch (Exception e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test156() {}
//   public void test156() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test156"); }
// 
// 
//     org.apache.commons.math.fraction.BigFractionField var0 = org.apache.commons.math.fraction.BigFractionField.getInstance();
//     org.apache.commons.math.fraction.BigFraction var1 = var0.getZero();
//     org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var2 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var1);
//     org.apache.commons.math.fraction.BigFraction var4 = var1.subtract((-1L));
//     org.apache.commons.math.FieldElement[] var5 = new org.apache.commons.math.FieldElement[] { var1};
//     org.apache.commons.math.linear.FieldMatrix var6 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var5);
//     org.apache.commons.math.FieldElement[][] var7 = new org.apache.commons.math.FieldElement[][] { var5};
//     org.apache.commons.math.linear.Array2DRowFieldMatrix var8 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var7);
//     org.apache.commons.math.fraction.BigFractionField var10 = org.apache.commons.math.fraction.BigFractionField.getInstance();
//     org.apache.commons.math.fraction.BigFraction var11 = var10.getZero();
//     org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var12 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var11);
//     org.apache.commons.math.fraction.BigFraction var14 = var11.subtract((-1L));
//     org.apache.commons.math.FieldElement[] var15 = new org.apache.commons.math.FieldElement[] { var11};
//     org.apache.commons.math.linear.FieldMatrix var16 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var15);
//     java.io.EOFException var17 = org.apache.commons.math.MathRuntimeException.createEOFException("java.io.IOException: ", (java.lang.Object[])var15);
//     org.apache.commons.math.linear.Array2DRowFieldMatrix var18 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var15);
//     org.apache.commons.math.fraction.BigFractionField var19 = org.apache.commons.math.fraction.BigFractionField.getInstance();
//     org.apache.commons.math.fraction.BigFraction var20 = var19.getZero();
//     org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var21 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var20);
//     org.apache.commons.math.fraction.BigFraction var23 = var20.subtract((-1L));
//     org.apache.commons.math.fraction.BigFraction var25 = var20.subtract(10L);
//     double var26 = var25.percentageValue();
//     org.apache.commons.math.fraction.BigFraction var28 = var25.multiply(1);
//     org.apache.commons.math.fraction.BigFractionField var29 = var25.getField();
//     org.apache.commons.math.linear.Array2DRowFieldMatrix var30 = new org.apache.commons.math.linear.Array2DRowFieldMatrix((org.apache.commons.math.Field)var29);
//     int var31 = var30.getRowDimension();
//     org.apache.commons.math.FieldElement var32 = null;
//     org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor var33 = new org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor(var32);
//     org.apache.commons.math.FieldElement var34 = var30.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixChangingVisitor)var33);
//     org.apache.commons.math.FieldElement[][] var35 = var30.getDataRef();
//     org.apache.commons.math.fraction.BigFractionField var36 = org.apache.commons.math.fraction.BigFractionField.getInstance();
//     org.apache.commons.math.fraction.BigFraction var37 = var36.getZero();
//     org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var38 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var37);
//     org.apache.commons.math.fraction.BigFraction var40 = var37.subtract((-1L));
//     org.apache.commons.math.fraction.BigFraction var42 = var37.subtract(10L);
//     double var43 = var42.percentageValue();
//     org.apache.commons.math.fraction.BigFraction var45 = var42.multiply(1);
//     org.apache.commons.math.fraction.BigFractionField var46 = var42.getField();
//     org.apache.commons.math.linear.Array2DRowFieldMatrix var47 = new org.apache.commons.math.linear.Array2DRowFieldMatrix((org.apache.commons.math.Field)var46);
//     boolean var48 = var47.isSquare();
//     org.apache.commons.math.fraction.BigFractionField var49 = org.apache.commons.math.fraction.BigFractionField.getInstance();
//     org.apache.commons.math.fraction.BigFraction var50 = var49.getZero();
//     org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var51 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var50);
//     org.apache.commons.math.FieldElement var52 = var47.walkInColumnOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var51);
//     boolean var53 = var30.equals((java.lang.Object)var51);
//     org.apache.commons.math.FieldElement var54 = var18.walkInColumnOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var51);
//     org.apache.commons.math.FieldElement var55 = var8.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var51);
//     org.apache.commons.math.linear.FieldMatrix var58 = var8.createMatrix(100, 1);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var59 = org.apache.commons.math.linear.MatrixUtils.bigFractionMatrixToRealMatrix((org.apache.commons.math.linear.FieldMatrix)var8);
//     org.apache.commons.math.linear.FieldMatrixPreservingVisitor var60 = null;
//     org.apache.commons.math.FieldElement var61 = var8.walkInOptimizedOrder(var60);
// 
//   }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test157"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var5 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(2147483647, 1.0d, (-99900.0d), 2.147483647E11d, 1.0E100d);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test158"); }


    org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var5 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(25, (-1.0d), 10.0d, 0.0d, Double.POSITIVE_INFINITY);

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test159"); }


    org.apache.commons.math.fraction.BigFractionField var0 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var1 = var0.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var2 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var1);
    org.apache.commons.math.fraction.BigFraction var4 = var1.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var6 = var1.subtract(10L);
    double var7 = var6.percentageValue();
    int var8 = var6.getNumeratorAsInt();
    org.apache.commons.math.fraction.BigFraction var10 = var6.add((-1));
    org.apache.commons.math.fraction.BigFraction var12 = var10.divide(2147483647);
    org.apache.commons.math.fraction.BigFractionField var13 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var14 = var13.getZero();
    org.apache.commons.math.fraction.BigFraction var15 = var13.getOne();
    org.apache.commons.math.fraction.BigFraction var17 = var15.pow(100);
    org.apache.commons.math.fraction.BigFraction var18 = var10.divide(var17);
    org.apache.commons.math.fraction.BigFraction var20 = var10.add((-10L));
    org.apache.commons.math.fraction.BigFraction var21 = var20.reciprocal();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-1000.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-10));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test160"); }


    double[] var2 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var4 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var2, false);
    double[][] var5 = new double[][] { var2};
    org.apache.commons.math.linear.BlockRealMatrix var6 = new org.apache.commons.math.linear.BlockRealMatrix(var5);
    org.apache.commons.math.linear.BlockRealMatrix var7 = var6.transpose();
    org.apache.commons.math.linear.BlockRealMatrix var8 = var6.transpose();
    var8.multiplyEntry(1, 0, 1.0E-6d);
    org.apache.commons.math.linear.RealMatrix var14 = var8.scalarMultiply(1.0E-6d);
    org.apache.commons.math.linear.BlockRealMatrix var15 = var8.transpose();
    org.apache.commons.math.linear.RealVector var17 = var15.getColumnVector(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test161"); }


    org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var0 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator();
    var0.setInterpolatedTime(100.0d);
    org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var3 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator(var0);

  }

  public void test162() {}
//   public void test162() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test162"); }
// 
// 
//     org.apache.commons.math.linear.SingularMatrixException var0 = new org.apache.commons.math.linear.SingularMatrixException();
//     org.apache.commons.math.ConvergenceException var1 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable)var0);
//     org.apache.commons.math.ode.IntegratorException var2 = new org.apache.commons.math.ode.IntegratorException((java.lang.Throwable)var0);
//     org.apache.commons.math.MathException var3 = new org.apache.commons.math.MathException((java.lang.Throwable)var2);
//     java.lang.Object[] var4 = var2.getArguments();
//     org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var5 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator();
//     double[] var8 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var10 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var8, false);
//     double[][] var11 = new double[][] { var8};
//     org.apache.commons.math.linear.BlockRealMatrix var12 = new org.apache.commons.math.linear.BlockRealMatrix(var11);
//     double[] var15 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var17 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var15, false);
//     double[] var18 = var17.getInterpolatedState();
//     double[] var19 = var12.operate(var18);
//     var5.reinitialize(var19, true);
//     double[] var24 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var26 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var24, false);
//     double var27 = var26.getCurrentTime();
//     double[] var28 = var26.getInterpolatedState();
//     org.apache.commons.math.linear.BigMatrix var29 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(var28);
//     var5.reinitialize(var28, true);
//     double[] var38 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var40 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var38, false);
//     double[][] var41 = new double[][] { var38};
//     org.apache.commons.math.linear.BlockRealMatrix var42 = new org.apache.commons.math.linear.BlockRealMatrix(var41);
//     org.apache.commons.math.MaxIterationsExceededException var43 = new org.apache.commons.math.MaxIterationsExceededException(0, "", (java.lang.Object[])var41);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var45 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var41, false);
//     java.util.NoSuchElementException var46 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("org.apache.commons.math.MathRuntimeException: hi!", (java.lang.Object[])var41);
//     double[][] var47 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var41);
//     double[][] var48 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var41);
//     org.apache.commons.math.FunctionEvaluationException var49 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable)var2, var28, "2147483647", (java.lang.Object[])var48);
//     org.apache.commons.math.linear.BlockRealMatrix var50 = new org.apache.commons.math.linear.BlockRealMatrix(var48);
//     double[][] var51 = var50.getData();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
// 
//   }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test163"); }


    double[] var2 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var4 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var2, false);
    double[][] var5 = new double[][] { var2};
    org.apache.commons.math.linear.BlockRealMatrix var6 = new org.apache.commons.math.linear.BlockRealMatrix(var5);
    double[] var9 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var11 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var9, false);
    double[] var12 = var11.getInterpolatedState();
    double[] var13 = var6.operate(var12);
    org.apache.commons.math.linear.BlockRealMatrix var15 = var6.scalarAdd((-1.0d));
    org.apache.commons.math.linear.RealMatrix var17 = var6.scalarAdd(0.0d);
    org.apache.commons.math.linear.RealMatrix var18 = var6.transpose();
    org.apache.commons.math.linear.RealMatrixPreservingVisitor var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var24 = var6.walkInOptimizedOrder(var19, 0, (-1000), (-11), 0);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test164"); }


    double[] var6 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var8 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var6, false);
    double[][] var9 = new double[][] { var6};
    org.apache.commons.math.linear.BlockRealMatrix var10 = new org.apache.commons.math.linear.BlockRealMatrix(var9);
    org.apache.commons.math.MaxIterationsExceededException var11 = new org.apache.commons.math.MaxIterationsExceededException(0, "", (java.lang.Object[])var9);
    org.apache.commons.math.linear.Array2DRowRealMatrix var13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var9, false);
    java.text.ParseException var14 = org.apache.commons.math.MathRuntimeException.createParseException(0, "", (java.lang.Object[])var9);
    org.apache.commons.math.linear.BigMatrix var15 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(var9);
    org.apache.commons.math.linear.Array2DRowRealMatrix var16 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var9);
    double[] var19 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var21 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var19, false);
    double[][] var22 = new double[][] { var19};
    org.apache.commons.math.linear.BlockRealMatrix var23 = new org.apache.commons.math.linear.BlockRealMatrix(var22);
    org.apache.commons.math.linear.BlockRealMatrix var25 = var23.getColumnMatrix(1);
    org.apache.commons.math.linear.RealMatrix var27 = var23.scalarMultiply(10.0d);
    org.apache.commons.math.linear.RealMatrix var28 = var16.subtract((org.apache.commons.math.linear.RealMatrix)var23);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var16.multiplyEntry((-9), 0, Double.NaN);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test165"); }


    org.apache.commons.math.fraction.BigFractionField var0 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var1 = var0.getZero();
    org.apache.commons.math.fraction.BigFraction var2 = var0.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var5 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var0, 10, 10);
    org.apache.commons.math.linear.FieldMatrix var6 = var5.transpose();
    org.apache.commons.math.fraction.BigFraction var8 = new org.apache.commons.math.fraction.BigFraction(0);
    org.apache.commons.math.linear.FieldMatrix var9 = var5.scalarAdd((org.apache.commons.math.FieldElement)var8);
    org.apache.commons.math.fraction.BigFractionField var10 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var11 = var10.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var12 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var11);
    org.apache.commons.math.FieldElement[] var13 = new org.apache.commons.math.FieldElement[] { var11};
    org.apache.commons.math.linear.FieldMatrix var14 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createColumnFieldMatrix(var13);
    org.apache.commons.math.FieldElement[][] var15 = new org.apache.commons.math.FieldElement[][] { var13};
    org.apache.commons.math.linear.FieldMatrix var16 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldMatrix(var15);
    org.apache.commons.math.linear.FieldLUDecompositionImpl var17 = new org.apache.commons.math.linear.FieldLUDecompositionImpl(var16);
    int[] var18 = var17.getPivot();
    org.apache.commons.math.linear.FieldMatrix var19 = var17.getU();
    int[] var20 = var17.getPivot();
    org.apache.commons.math.fraction.BigFractionField var21 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var22 = var21.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var23 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var22);
    org.apache.commons.math.FieldElement[] var24 = new org.apache.commons.math.FieldElement[] { var22};
    org.apache.commons.math.linear.FieldMatrix var25 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createColumnFieldMatrix(var24);
    org.apache.commons.math.FieldElement[][] var26 = new org.apache.commons.math.FieldElement[][] { var24};
    org.apache.commons.math.linear.FieldMatrix var27 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldMatrix(var26);
    org.apache.commons.math.linear.FieldLUDecompositionImpl var28 = new org.apache.commons.math.linear.FieldLUDecompositionImpl(var27);
    int[] var29 = var28.getPivot();
    org.apache.commons.math.linear.FieldMatrix var30 = var28.getU();
    int[] var31 = var28.getPivot();
    org.apache.commons.math.fraction.BigFractionField var32 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var33 = var32.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var34 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var33);
    org.apache.commons.math.FieldElement[] var35 = new org.apache.commons.math.FieldElement[] { var33};
    org.apache.commons.math.linear.FieldMatrix var36 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createColumnFieldMatrix(var35);
    org.apache.commons.math.FieldElement[][] var37 = new org.apache.commons.math.FieldElement[][] { var35};
    org.apache.commons.math.FieldElement[][] var38 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var37);
    var5.copySubMatrix(var20, var31, var37);
    int var40 = var5.getRowDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 10);

  }

  public void test166() {}
//   public void test166() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test166"); }
// 
// 
//     double[] var5 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var7 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var5, false);
//     double var8 = var7.getCurrentTime();
//     double[] var9 = var7.getInterpolatedState();
//     double[] var10 = var7.getInterpolatedDerivatives();
//     double[] var13 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var15 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var13, false);
//     double var16 = var15.getCurrentTime();
//     double[] var17 = var15.getInterpolatedState();
//     double[] var18 = var15.getInterpolatedDerivatives();
//     org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var19 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, Double.NaN, 1.0E-15d, var10, var18);
//     double var20 = var19.getCurrentStepStart();
//     double[] var23 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var25 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var23, false);
//     double var26 = var25.getCurrentTime();
//     double[] var27 = var25.getInterpolatedState();
//     org.apache.commons.math.linear.BigMatrix var28 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(var27);
//     double[][] var29 = new double[][] { var27};
//     org.apache.commons.math.linear.RealMatrix var30 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(var29);
//     org.apache.commons.math.linear.BlockRealMatrix var31 = new org.apache.commons.math.linear.BlockRealMatrix(var29);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var32 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var29);
//     double[][] var33 = var32.getDataRef();
//     org.apache.commons.math.linear.Array2DRowRealMatrix var34 = var19.updateHighOrderDerivativesPhase1(var32);
//     double[] var40 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var42 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var40, false);
//     double var43 = var42.getCurrentTime();
//     double[] var44 = var42.getInterpolatedState();
//     double[] var45 = var42.getInterpolatedDerivatives();
//     double[] var48 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var50 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var48, false);
//     double var51 = var50.getCurrentTime();
//     double[] var52 = var50.getInterpolatedState();
//     double[] var53 = var50.getInterpolatedDerivatives();
//     org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var54 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, Double.NaN, 1.0E-15d, var45, var53);
//     var54.setMinReduction(0.0d);
//     org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var61 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(0.0d, (-1.0d), 10.0d, 100.0d);
//     int var62 = var61.getMaxEvaluations();
//     var61.setSafety(1.0d);
//     double var65 = var61.getMaxGrowth();
//     int var66 = var61.getEvaluations();
//     double var67 = var61.getSafety();
//     var54.setStarterIntegrator((org.apache.commons.math.ode.FirstOrderIntegrator)var61);
//     var54.setMaxEvaluations((-1));
//     var54.setSafety(0.0d);
//     double[] var77 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var79 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var77, false);
//     double[][] var80 = new double[][] { var77};
//     org.apache.commons.math.linear.BlockRealMatrix var81 = new org.apache.commons.math.linear.BlockRealMatrix(var80);
//     org.apache.commons.math.MaxIterationsExceededException var82 = new org.apache.commons.math.MaxIterationsExceededException(0, "", (java.lang.Object[])var80);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var84 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var80, false);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var85 = var54.updateHighOrderDerivativesPhase1(var84);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var86 = var34.add(var84);
//     double[][] var87 = var34.getDataRef();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var62 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == 10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var66 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var67 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var85);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var86);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var87);
// 
//   }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test167"); }


    org.apache.commons.math.fraction.BigFractionField var0 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var1 = var0.getZero();
    org.apache.commons.math.fraction.BigFraction var2 = var0.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var5 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var0, 10, 10);
    org.apache.commons.math.linear.FieldMatrix var7 = var5.getRowMatrix(0);
    double[] var10 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var12 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var10, false);
    double[][] var13 = new double[][] { var10};
    org.apache.commons.math.linear.BlockRealMatrix var14 = new org.apache.commons.math.linear.BlockRealMatrix(var13);
    double[] var17 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var19 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var17, false);
    double[] var20 = var19.getInterpolatedState();
    double[] var21 = var14.operate(var20);
    org.apache.commons.math.linear.BlockRealMatrix var23 = var14.scalarAdd((-1.0d));
    org.apache.commons.math.linear.RealMatrix var25 = var14.scalarAdd(0.0d);
    double[] var28 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var30 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var28, false);
    double[][] var31 = new double[][] { var28};
    org.apache.commons.math.linear.BlockRealMatrix var32 = new org.apache.commons.math.linear.BlockRealMatrix(var31);
    org.apache.commons.math.linear.BlockRealMatrix var33 = var32.transpose();
    org.apache.commons.math.linear.BlockRealMatrix var34 = var14.add((org.apache.commons.math.linear.RealMatrix)var32);
    boolean var35 = var5.equals((java.lang.Object)var32);
    org.apache.commons.math.linear.RealVector var37 = var32.getColumnVector(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math.linear.AnyMatrix)var32, 10, 10, 2147483646, 25);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test168() {}
//   public void test168() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test168"); }
// 
// 
//     double[] var2 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var4 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var2, false);
//     var4.setInterpolatedTime(0.2d);
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var7 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var4);
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var8 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var4);
//     double var9 = var8.getCurrentTime();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == Double.NaN);
// 
//   }

  public void test169() {}
//   public void test169() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test169"); }
// 
// 
//     org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var4 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 1.0d, 0.9d, 0.2d);
//     double var5 = var4.getMinReduction();
//     org.apache.commons.math.ode.FirstOrderDifferentialEquations var6 = null;
//     double[] var10 = new double[] { 100.0d, (-1.0d)};
//     org.apache.commons.math.ode.events.CombinedEventsManager var12 = new org.apache.commons.math.ode.events.CombinedEventsManager();
//     double[] var16 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var18 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var16, false);
//     double[][] var19 = new double[][] { var16};
//     org.apache.commons.math.linear.BlockRealMatrix var20 = new org.apache.commons.math.linear.BlockRealMatrix(var19);
//     double[] var23 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var25 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var23, false);
//     double[] var26 = var25.getInterpolatedState();
//     double[] var27 = var20.operate(var26);
//     boolean var28 = var12.reset(1.0E-6d, var27);
//     org.apache.commons.math.ode.events.EventHandler var30 = null;
//     org.apache.commons.math.ode.events.EventState var34 = new org.apache.commons.math.ode.events.EventState(var30, 0.0d, (-10.0d), 8);
//     double[] var36 = null;
//     boolean var37 = var34.reset(1.0d, var36);
//     double[] var42 = new double[] { 100.0d, 100.0d, (-1.0d)};
//     org.apache.commons.math.linear.BigMatrix var43 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(var42);
//     boolean var44 = var34.reset(10.0d, var42);
//     boolean var45 = var12.reset((-1.0d), var42);
//     double var46 = var4.integrate(var6, 2.147483647E11d, var10, (-99900.0d), var42);
// 
//   }

  public void test170() {}
//   public void test170() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test170"); }
// 
// 
//     double[] var5 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var7 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var5, false);
//     double var8 = var7.getCurrentTime();
//     double[] var9 = var7.getInterpolatedState();
//     double[] var10 = var7.getInterpolatedDerivatives();
//     double[] var13 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var15 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var13, false);
//     double var16 = var15.getCurrentTime();
//     double[] var17 = var15.getInterpolatedState();
//     double[] var18 = var15.getInterpolatedDerivatives();
//     org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var19 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, Double.NaN, 1.0E-15d, var10, var18);
//     var19.setMinReduction(0.0d);
//     var19.setSafety(1.0d);
//     org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var28 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(0.0d, (-1.0d), 10.0d, 100.0d);
//     int var29 = var28.getMaxEvaluations();
//     var19.setStarterIntegrator((org.apache.commons.math.ode.FirstOrderIntegrator)var28);
//     double var31 = var19.getMaxGrowth();
//     var19.clearStepHandlers();
//     java.util.Collection var33 = var19.getStepHandlers();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 1.4142135623730951d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
// 
//   }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test171"); }


    double[] var2 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var4 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var2, false);
    double[][] var5 = new double[][] { var2};
    org.apache.commons.math.linear.BlockRealMatrix var6 = new org.apache.commons.math.linear.BlockRealMatrix(var5);
    org.apache.commons.math.linear.BlockRealMatrix var8 = var6.getColumnMatrix(1);
    double[] var11 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var13 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var11, false);
    double[][] var14 = new double[][] { var11};
    org.apache.commons.math.linear.BlockRealMatrix var15 = new org.apache.commons.math.linear.BlockRealMatrix(var14);
    org.apache.commons.math.linear.BlockRealMatrix var17 = var15.getColumnMatrix(1);
    org.apache.commons.math.linear.BlockRealMatrix var18 = var8.subtract(var17);
    int var19 = var8.getRowDimension();
    org.apache.commons.math.fraction.BigFractionField var20 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var21 = var20.getZero();
    org.apache.commons.math.fraction.BigFraction var22 = var20.getOne();
    org.apache.commons.math.fraction.BigFractionField var23 = var22.getField();
    org.apache.commons.math.fraction.BigFraction var24 = var23.getZero();
    org.apache.commons.math.linear.FieldMatrix var26 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldIdentityMatrix((org.apache.commons.math.Field)var23, 1);
    org.apache.commons.math.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math.linear.AnyMatrix)var8, (org.apache.commons.math.linear.AnyMatrix)var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test172() {}
//   public void test172() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test172"); }
// 
// 
//     org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var0 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator();
//     double[] var3 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var5 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var3, false);
//     double[][] var6 = new double[][] { var3};
//     org.apache.commons.math.linear.BlockRealMatrix var7 = new org.apache.commons.math.linear.BlockRealMatrix(var6);
//     double[] var10 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var12 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var10, false);
//     double[] var13 = var12.getInterpolatedState();
//     double[] var14 = var7.operate(var13);
//     var0.reinitialize(var14, true);
//     org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var17 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator(var0);
//     var17.finalizeStep();
//     double var19 = var17.getPreviousTime();
//     org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var20 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator(var17);
//     org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var21 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator(var20);
//     double[] var22 = var20.getInterpolatedStateVariation();
// 
//   }

  public void test173() {}
//   public void test173() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test173"); }
// 
// 
//     org.apache.commons.math.fraction.BigFractionField var0 = org.apache.commons.math.fraction.BigFractionField.getInstance();
//     org.apache.commons.math.fraction.BigFraction var1 = var0.getZero();
//     org.apache.commons.math.fraction.BigFraction var2 = var0.getOne();
//     org.apache.commons.math.linear.BlockFieldMatrix var5 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var0, 10, 10);
//     org.apache.commons.math.FieldElement[] var6 = null;
//     org.apache.commons.math.FieldElement[] var7 = var5.preMultiply(var6);
// 
//   }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test174"); }


    org.apache.commons.math.fraction.BigFractionField var0 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var1 = var0.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var2 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var1);
    org.apache.commons.math.fraction.BigFraction var4 = var1.subtract((-1L));
    org.apache.commons.math.FieldElement[] var5 = new org.apache.commons.math.FieldElement[] { var1};
    org.apache.commons.math.linear.FieldMatrix var6 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var5);
    org.apache.commons.math.FieldElement[][] var7 = new org.apache.commons.math.FieldElement[][] { var5};
    org.apache.commons.math.linear.Array2DRowFieldMatrix var8 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var7);
    org.apache.commons.math.fraction.BigFractionField var10 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var11 = var10.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var12 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var11);
    org.apache.commons.math.fraction.BigFraction var14 = var11.subtract((-1L));
    org.apache.commons.math.FieldElement[] var15 = new org.apache.commons.math.FieldElement[] { var11};
    org.apache.commons.math.linear.FieldMatrix var16 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var15);
    java.io.EOFException var17 = org.apache.commons.math.MathRuntimeException.createEOFException("java.io.IOException: ", (java.lang.Object[])var15);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var18 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var15);
    org.apache.commons.math.fraction.BigFractionField var19 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var20 = var19.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var21 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var20);
    org.apache.commons.math.fraction.BigFraction var23 = var20.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var25 = var20.subtract(10L);
    double var26 = var25.percentageValue();
    org.apache.commons.math.fraction.BigFraction var28 = var25.multiply(1);
    org.apache.commons.math.fraction.BigFractionField var29 = var25.getField();
    org.apache.commons.math.linear.Array2DRowFieldMatrix var30 = new org.apache.commons.math.linear.Array2DRowFieldMatrix((org.apache.commons.math.Field)var29);
    int var31 = var30.getRowDimension();
    org.apache.commons.math.FieldElement var32 = null;
    org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor var33 = new org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor(var32);
    org.apache.commons.math.FieldElement var34 = var30.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixChangingVisitor)var33);
    org.apache.commons.math.FieldElement[][] var35 = var30.getDataRef();
    org.apache.commons.math.fraction.BigFractionField var36 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var37 = var36.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var38 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var37);
    org.apache.commons.math.fraction.BigFraction var40 = var37.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var42 = var37.subtract(10L);
    double var43 = var42.percentageValue();
    org.apache.commons.math.fraction.BigFraction var45 = var42.multiply(1);
    org.apache.commons.math.fraction.BigFractionField var46 = var42.getField();
    org.apache.commons.math.linear.Array2DRowFieldMatrix var47 = new org.apache.commons.math.linear.Array2DRowFieldMatrix((org.apache.commons.math.Field)var46);
    boolean var48 = var47.isSquare();
    org.apache.commons.math.fraction.BigFractionField var49 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var50 = var49.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var51 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var50);
    org.apache.commons.math.FieldElement var52 = var47.walkInColumnOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var51);
    boolean var53 = var30.equals((java.lang.Object)var51);
    org.apache.commons.math.FieldElement var54 = var18.walkInColumnOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var51);
    org.apache.commons.math.FieldElement var55 = var8.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var51);
    org.apache.commons.math.linear.FieldMatrix var58 = var8.createMatrix(100, 1);
    org.apache.commons.math.linear.Array2DRowRealMatrix var59 = org.apache.commons.math.linear.MatrixUtils.bigFractionMatrixToRealMatrix((org.apache.commons.math.linear.FieldMatrix)var8);
    org.apache.commons.math.fraction.BigFractionField var61 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var62 = var61.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var63 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var62);
    org.apache.commons.math.fraction.BigFraction var65 = var62.subtract((-1L));
    org.apache.commons.math.FieldElement[] var66 = new org.apache.commons.math.FieldElement[] { var62};
    org.apache.commons.math.linear.FieldMatrix var67 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var66);
    java.io.EOFException var68 = org.apache.commons.math.MathRuntimeException.createEOFException("java.io.IOException: ", (java.lang.Object[])var66);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var69 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var66);
    org.apache.commons.math.FieldElement[][] var70 = var69.getDataRef();
    org.apache.commons.math.linear.FieldMatrix var71 = var8.subtract((org.apache.commons.math.linear.FieldMatrix)var69);
    org.apache.commons.math.FieldElement[][] var72 = var69.getData();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math.linear.FieldVector var74 = var69.getColumnVector(11);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == (-1000.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == (-1000.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test175"); }


    org.apache.commons.math.fraction.BigFractionField var0 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var1 = var0.getZero();
    org.apache.commons.math.fraction.BigFraction var2 = var0.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var5 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var0, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var6 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var7 = var6.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var8 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var7);
    var8.start(2147483647, 0, 100, (-10), 100, 0);
    org.apache.commons.math.FieldElement var16 = var5.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var8);
    org.apache.commons.math.fraction.BigFractionField var17 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var18 = var17.getZero();
    org.apache.commons.math.fraction.BigFraction var19 = var17.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var22 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var17, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var23 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var24 = var23.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var25 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var24);
    var25.start(2147483647, 0, 100, (-10), 100, 0);
    org.apache.commons.math.FieldElement var33 = var22.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var25);
    org.apache.commons.math.linear.BlockFieldMatrix var34 = var5.subtract(var22);
    org.apache.commons.math.fraction.BigFractionField var35 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var36 = var35.getZero();
    double var38 = var36.pow((-1.0d));
    org.apache.commons.math.fraction.BigFraction var39 = var36.abs();
    org.apache.commons.math.linear.FieldMatrix var40 = var34.scalarAdd((org.apache.commons.math.FieldElement)var39);
    org.apache.commons.math.fraction.BigFractionField var41 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var42 = var41.getZero();
    org.apache.commons.math.fraction.BigFraction var43 = var41.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var46 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var41, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var47 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var48 = var47.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var49 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var48);
    var49.start(2147483647, 0, 100, (-10), 100, 0);
    org.apache.commons.math.FieldElement var57 = var46.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var49);
    org.apache.commons.math.fraction.BigFractionField var60 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var61 = var60.getZero();
    org.apache.commons.math.fraction.BigFraction var62 = var60.getOne();
    org.apache.commons.math.fraction.BigFraction var64 = var62.pow(100);
    var46.setEntry(10, (-1), (org.apache.commons.math.FieldElement)var64);
    org.apache.commons.math.linear.FieldMatrix var66 = var34.subtract((org.apache.commons.math.linear.FieldMatrix)var46);
    java.lang.String var67 = var34.toString();
    org.apache.commons.math.fraction.BigFractionField var70 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var71 = var70.getZero();
    org.apache.commons.math.fraction.BigFraction var72 = var70.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var75 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var70, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var76 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var77 = var76.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var78 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var77);
    var78.start(2147483647, 0, 100, (-10), 100, 0);
    org.apache.commons.math.FieldElement var86 = var75.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var78);
    org.apache.commons.math.fraction.BigFractionField var89 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var90 = var89.getZero();
    org.apache.commons.math.fraction.BigFraction var91 = var89.getOne();
    org.apache.commons.math.fraction.BigFraction var93 = var91.pow(100);
    var75.setEntry(10, (-1), (org.apache.commons.math.FieldElement)var93);
    org.apache.commons.math.fraction.BigFraction var96 = var93.subtract(11);
    var34.addToEntry(0, 0, (org.apache.commons.math.FieldElement)var93);
    org.apache.commons.math.FieldElement var98 = var34.getTrace();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var67 + "' != '" + "BlockFieldMatrix{{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0}}"+ "'", var67.equals("BlockFieldMatrix{{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var93);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var96);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var98);

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test176"); }


    double[] var2 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var4 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var2, false);
    double[][] var5 = new double[][] { var2};
    org.apache.commons.math.linear.BlockRealMatrix var6 = new org.apache.commons.math.linear.BlockRealMatrix(var5);
    org.apache.commons.math.linear.BlockRealMatrix var8 = var6.getColumnMatrix(1);
    org.apache.commons.math.linear.BlockRealMatrix var9 = var8.transpose();
    org.apache.commons.math.linear.BlockRealMatrix var10 = var9.transpose();
    double var11 = var10.getNorm();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test177"); }


    org.apache.commons.math.fraction.BigFractionField var0 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var1 = var0.getZero();
    org.apache.commons.math.FieldElement[][] var4 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>createBlocksLayout((org.apache.commons.math.Field)var0, 0, 0);
    org.apache.commons.math.fraction.BigFraction var5 = var0.getZero();
    org.apache.commons.math.fraction.BigFraction var6 = var0.getZero();
    org.apache.commons.math.fraction.BigFractionField var7 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var8 = var7.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var9 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var8);
    org.apache.commons.math.fraction.BigFraction var11 = var8.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var13 = var8.subtract(10L);
    double var14 = var13.percentageValue();
    org.apache.commons.math.fraction.BigFraction var16 = var13.multiply(1);
    long var17 = var13.longValue();
    int var18 = var6.compareTo(var13);
    org.apache.commons.math.fraction.BigFractionField var19 = var6.getField();
    org.apache.commons.math.fraction.BigFraction var20 = var19.getOne();
    org.apache.commons.math.fraction.BigFraction var21 = var19.getOne();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == (-1000.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == (-10L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test178"); }


    java.lang.Object[] var1 = null;
    java.io.EOFException var2 = org.apache.commons.math.MathRuntimeException.createEOFException("matrix is singular", var1);
    org.apache.commons.math.ode.events.EventException var3 = new org.apache.commons.math.ode.events.EventException((java.lang.Throwable)var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test179"); }


    org.apache.commons.math.fraction.BigFraction var2 = new org.apache.commons.math.fraction.BigFraction(0L, 100L);
    org.apache.commons.math.fraction.BigFractionField var3 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var4 = var3.getZero();
    org.apache.commons.math.fraction.BigFraction var5 = var3.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var8 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var3, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var9 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var10 = var9.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var11 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var10);
    var11.start(2147483647, 0, 100, (-10), 100, 0);
    org.apache.commons.math.FieldElement var19 = var8.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var11);
    org.apache.commons.math.fraction.BigFractionField var22 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var23 = var22.getZero();
    org.apache.commons.math.fraction.BigFraction var24 = var22.getOne();
    org.apache.commons.math.fraction.BigFraction var26 = var24.pow(100);
    var8.setEntry(10, (-1), (org.apache.commons.math.FieldElement)var26);
    org.apache.commons.math.fraction.BigFractionField var28 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var29 = var28.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var30 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var29);
    java.math.BigDecimal var31 = var29.bigDecimalValue();
    java.lang.String var32 = var29.toString();
    org.apache.commons.math.fraction.BigFractionField var33 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var34 = var33.getZero();
    java.math.BigInteger var35 = var34.getDenominator();
    org.apache.commons.math.fraction.BigFraction var36 = var29.pow(var35);
    org.apache.commons.math.fraction.BigFraction var37 = var26.add(var35);
    org.apache.commons.math.fraction.BigFraction var38 = var2.multiply(var26);
    java.lang.String var39 = var2.toString();
    org.apache.commons.math.fraction.BigFraction var41 = var2.add(0L);
    org.apache.commons.math.fraction.BigFractionField var42 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var43 = var42.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var44 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var43);
    org.apache.commons.math.fraction.BigFraction var46 = var43.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var48 = var43.pow(2147483647);
    org.apache.commons.math.fraction.BigFraction var50 = var48.pow(0L);
    org.apache.commons.math.fraction.BigFraction var52 = var48.divide(1);
    double var53 = var52.doubleValue();
    java.math.BigInteger var54 = var52.getDenominator();
    org.apache.commons.math.fraction.BigFraction var55 = var2.add(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var32 + "' != '" + "0"+ "'", var32.equals("0"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var39 + "' != '" + "0"+ "'", var39.equals("0"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test180"); }


    double[] var2 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var4 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var2, false);
    double[][] var5 = new double[][] { var2};
    org.apache.commons.math.linear.BlockRealMatrix var6 = new org.apache.commons.math.linear.BlockRealMatrix(var5);
    double[] var9 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var11 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var9, false);
    double[] var12 = var11.getInterpolatedState();
    double[] var13 = var6.operate(var12);
    org.apache.commons.math.linear.BlockRealMatrix var15 = var6.scalarAdd((-1.0d));
    org.apache.commons.math.linear.RealMatrix var17 = var6.scalarAdd(0.0d);
    double[] var20 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var22 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var20, false);
    double[][] var23 = new double[][] { var20};
    org.apache.commons.math.linear.BlockRealMatrix var24 = new org.apache.commons.math.linear.BlockRealMatrix(var23);
    org.apache.commons.math.linear.BlockRealMatrix var25 = var24.transpose();
    org.apache.commons.math.linear.BlockRealMatrix var26 = var6.add((org.apache.commons.math.linear.RealMatrix)var24);
    boolean var27 = var6.isSquare();
    int var28 = var6.getRowDimension();
    double[] var31 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var33 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var31, false);
    double[][] var34 = new double[][] { var31};
    org.apache.commons.math.linear.BlockRealMatrix var35 = new org.apache.commons.math.linear.BlockRealMatrix(var34);
    double[] var38 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var40 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var38, false);
    double[] var41 = var40.getInterpolatedState();
    double[] var42 = var35.operate(var41);
    org.apache.commons.math.linear.BlockRealMatrix var44 = var35.scalarAdd((-1.0d));
    org.apache.commons.math.linear.RealMatrix var46 = var35.scalarAdd(0.0d);
    double[] var49 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var51 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var49, false);
    double[][] var52 = new double[][] { var49};
    org.apache.commons.math.linear.BlockRealMatrix var53 = new org.apache.commons.math.linear.BlockRealMatrix(var52);
    org.apache.commons.math.linear.BlockRealMatrix var54 = var53.transpose();
    org.apache.commons.math.linear.BlockRealMatrix var55 = var35.add((org.apache.commons.math.linear.RealMatrix)var53);
    boolean var56 = var35.isSquare();
    int var57 = var35.getRowDimension();
    org.apache.commons.math.linear.BlockRealMatrix var58 = var35.transpose();
    org.apache.commons.math.linear.BlockRealMatrix var59 = var6.subtract((org.apache.commons.math.linear.RealMatrix)var35);
    org.apache.commons.math.linear.RealMatrixChangingVisitor var60 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var65 = var35.walkInOptimizedOrder(var60, 0, 10, 0, 2);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);

  }

  public void test181() {}
//   public void test181() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test181"); }
// 
// 
//     double[] var2 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var4 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var2, false);
//     double[][] var5 = new double[][] { var2};
//     org.apache.commons.math.linear.BlockRealMatrix var6 = new org.apache.commons.math.linear.BlockRealMatrix(var5);
//     org.apache.commons.math.linear.BlockRealMatrix var8 = var6.getColumnMatrix(1);
//     double[] var11 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var13 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var11, false);
//     double[][] var14 = new double[][] { var11};
//     org.apache.commons.math.linear.BlockRealMatrix var15 = new org.apache.commons.math.linear.BlockRealMatrix(var14);
//     org.apache.commons.math.linear.BlockRealMatrix var17 = var15.getColumnMatrix(1);
//     org.apache.commons.math.linear.BlockRealMatrix var18 = var8.subtract(var17);
//     org.apache.commons.math.linear.RealMatrix var19 = var17.transpose();
//     double[] var22 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var24 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var22, false);
//     double[][] var25 = new double[][] { var22};
//     org.apache.commons.math.linear.BlockRealMatrix var26 = new org.apache.commons.math.linear.BlockRealMatrix(var25);
//     org.apache.commons.math.linear.RealMatrix var28 = var26.scalarMultiply(10.0d);
//     org.apache.commons.math.FunctionEvaluationException var30 = new org.apache.commons.math.FunctionEvaluationException(Double.NaN);
//     boolean var31 = var26.equals((java.lang.Object)Double.NaN);
//     boolean var33 = var26.equals((java.lang.Object)10.0d);
//     org.apache.commons.math.linear.BlockRealMatrix var34 = var26.copy();
//     org.apache.commons.math.linear.RealMatrix var35 = var34.transpose();
//     org.apache.commons.math.linear.BlockRealMatrix var36 = var17.multiply((org.apache.commons.math.linear.RealMatrix)var34);
//     org.apache.commons.math.linear.RealMatrixChangingVisitor var37 = null;
//     double var38 = var34.walkInColumnOrder(var37);
// 
//   }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test182"); }


    org.apache.commons.math.fraction.BigFractionField var0 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var1 = var0.getZero();
    org.apache.commons.math.fraction.BigFraction var2 = var0.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var5 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var0, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var6 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var7 = var6.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var8 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var7);
    var8.start(2147483647, 0, 100, (-10), 100, 0);
    org.apache.commons.math.FieldElement var16 = var5.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var8);
    org.apache.commons.math.fraction.BigFractionField var17 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var18 = var17.getZero();
    org.apache.commons.math.fraction.BigFraction var19 = var17.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var22 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var17, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var23 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var24 = var23.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var25 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var24);
    var25.start(2147483647, 0, 100, (-10), 100, 0);
    org.apache.commons.math.FieldElement var33 = var22.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var25);
    org.apache.commons.math.linear.BlockFieldMatrix var34 = var5.subtract(var22);
    int var35 = var5.getColumnDimension();
    org.apache.commons.math.linear.FieldMatrix var36 = var5.copy();
    org.apache.commons.math.linear.FieldMatrix var37 = var5.transpose();
    org.apache.commons.math.fraction.BigFractionField var40 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var41 = var40.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var42 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var41);
    org.apache.commons.math.fraction.BigFraction var44 = var41.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var46 = var41.subtract(10L);
    double var47 = var46.percentageValue();
    org.apache.commons.math.fraction.BigFraction var49 = var46.multiply(1);
    org.apache.commons.math.fraction.BigFractionField var50 = var46.getField();
    org.apache.commons.math.linear.Array2DRowFieldMatrix var51 = new org.apache.commons.math.linear.Array2DRowFieldMatrix((org.apache.commons.math.Field)var50);
    int var52 = var51.getRowDimension();
    org.apache.commons.math.FieldElement var53 = null;
    org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor var54 = new org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor(var53);
    org.apache.commons.math.FieldElement var55 = var51.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixChangingVisitor)var54);
    org.apache.commons.math.FieldElement[][] var56 = var51.getDataRef();
    org.apache.commons.math.fraction.BigFractionField var57 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var58 = var57.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var59 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var58);
    org.apache.commons.math.fraction.BigFraction var61 = var58.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var63 = var58.pow(2147483647);
    org.apache.commons.math.fraction.BigFraction var65 = var63.pow(0L);
    org.apache.commons.math.fraction.BigFractionField var66 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var67 = var66.getZero();
    int var68 = var67.getDenominatorAsInt();
    org.apache.commons.math.fraction.BigFraction var70 = var67.pow(0L);
    org.apache.commons.math.fraction.BigFraction var71 = var63.multiply(var67);
    org.apache.commons.math.fraction.BigFraction var72 = var71.negate();
    org.apache.commons.math.fraction.BigFraction var74 = var72.add(0L);
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var75 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var72);
    org.apache.commons.math.FieldElement var76 = var51.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var75);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.multiplyEntry(11, (-9), var76);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == (-1000.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);

  }

  public void test183() {}
//   public void test183() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test183"); }
// 
// 
//     double[] var2 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var4 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var2, false);
//     double[][] var5 = new double[][] { var2};
//     org.apache.commons.math.linear.BlockRealMatrix var6 = new org.apache.commons.math.linear.BlockRealMatrix(var5);
//     org.apache.commons.math.linear.BlockRealMatrix var8 = var6.getColumnMatrix(1);
//     double[] var11 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var13 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var11, false);
//     double var14 = var13.getCurrentTime();
//     double[] var15 = var13.getInterpolatedState();
//     double[] var16 = var6.operate(var15);
//     double var17 = var6.getFrobeniusNorm();
//     int var18 = var6.getRowDimension();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var21 = var6.getEntry((-11), 0);
//       fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
//     } catch (org.apache.commons.math.linear.MatrixIndexException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1);
// 
//   }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test184"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math.linear.RealMatrix var2 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(0, 8);
      fail("Expected exception of type Exception");
    } catch (Exception e) {
      // Expected exception.
    }

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test185"); }


    org.apache.commons.math.fraction.BigFractionField var1 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var2 = var1.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var3 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var2);
    org.apache.commons.math.fraction.BigFraction var5 = var2.subtract((-1L));
    org.apache.commons.math.FieldElement[] var6 = new org.apache.commons.math.FieldElement[] { var2};
    org.apache.commons.math.linear.FieldMatrix var7 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var6);
    java.io.EOFException var8 = org.apache.commons.math.MathRuntimeException.createEOFException("java.io.IOException: ", (java.lang.Object[])var6);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var9 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var6);
    org.apache.commons.math.fraction.BigFractionField var11 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var12 = var11.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var13 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var12);
    org.apache.commons.math.fraction.BigFraction var15 = var12.subtract((-1L));
    org.apache.commons.math.FieldElement[] var16 = new org.apache.commons.math.FieldElement[] { var12};
    org.apache.commons.math.linear.FieldMatrix var17 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var16);
    org.apache.commons.math.linear.FieldMatrix var18 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createColumnFieldMatrix(var16);
    java.lang.ArithmeticException var19 = org.apache.commons.math.MathRuntimeException.createArithmeticException("java.io.IOException: ", (java.lang.Object[])var16);
    org.apache.commons.math.linear.FieldVector var20 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var16);
    org.apache.commons.math.linear.FieldMatrix var21 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var16);
    org.apache.commons.math.linear.FieldMatrix var22 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var16);
    org.apache.commons.math.linear.FieldMatrix var23 = var9.multiply(var22);
    org.apache.commons.math.fraction.BigFractionField var25 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var26 = var25.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var27 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var26);
    org.apache.commons.math.fraction.BigFraction var29 = var26.subtract((-1L));
    org.apache.commons.math.FieldElement[] var30 = new org.apache.commons.math.FieldElement[] { var26};
    org.apache.commons.math.linear.FieldMatrix var31 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var30);
    java.io.EOFException var32 = org.apache.commons.math.MathRuntimeException.createEOFException("java.io.IOException: ", (java.lang.Object[])var30);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var33 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var30);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var34 = var9.multiply(var33);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math.linear.FieldMatrix var37 = var33.createMatrix(2147483646, 25);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test186() {}
//   public void test186() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test186"); }
// 
// 
//     org.apache.commons.math.ode.events.CombinedEventsManager var0 = new org.apache.commons.math.ode.events.CombinedEventsManager();
//     boolean var1 = var0.stop();
//     double[] var5 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var7 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var5, false);
//     double[][] var8 = new double[][] { var5};
//     org.apache.commons.math.linear.BlockRealMatrix var9 = new org.apache.commons.math.linear.BlockRealMatrix(var8);
//     org.apache.commons.math.linear.BlockRealMatrix var11 = var9.getColumnMatrix(1);
//     double[] var14 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var16 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var14, false);
//     double var17 = var16.getCurrentTime();
//     double[] var18 = var16.getInterpolatedState();
//     double[] var19 = var9.operate(var18);
//     org.apache.commons.math.FunctionEvaluationException var20 = new org.apache.commons.math.FunctionEvaluationException(var18);
//     boolean var21 = var0.reset(1.0E-15d, var18);
//     double[] var25 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var27 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var25, false);
//     double[][] var28 = new double[][] { var25};
//     org.apache.commons.math.linear.BlockRealMatrix var29 = new org.apache.commons.math.linear.BlockRealMatrix(var28);
//     org.apache.commons.math.linear.BlockRealMatrix var31 = var29.getColumnMatrix(1);
//     double[] var34 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var36 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var34, false);
//     double[][] var37 = new double[][] { var34};
//     org.apache.commons.math.linear.BlockRealMatrix var38 = new org.apache.commons.math.linear.BlockRealMatrix(var37);
//     org.apache.commons.math.linear.BlockRealMatrix var40 = var38.getColumnMatrix(1);
//     org.apache.commons.math.linear.BlockRealMatrix var41 = var31.subtract(var40);
//     org.apache.commons.math.linear.BlockRealMatrix var42 = var40.copy();
//     double[] var46 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var48 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var46, false);
//     double[][] var49 = new double[][] { var46};
//     org.apache.commons.math.linear.BlockRealMatrix var50 = new org.apache.commons.math.linear.BlockRealMatrix(var49);
//     org.apache.commons.math.linear.BlockRealMatrix var52 = var50.getColumnMatrix(1);
//     double[] var55 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var57 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var55, false);
//     double[][] var58 = new double[][] { var55};
//     org.apache.commons.math.linear.BlockRealMatrix var59 = new org.apache.commons.math.linear.BlockRealMatrix(var58);
//     org.apache.commons.math.linear.BlockRealMatrix var61 = var59.getColumnMatrix(1);
//     org.apache.commons.math.linear.BlockRealMatrix var62 = var52.subtract(var61);
//     org.apache.commons.math.linear.BlockRealMatrix var63 = var61.copy();
//     java.lang.String var64 = var63.toString();
//     org.apache.commons.math.linear.RealVector var66 = var63.getColumnVector(0);
//     var42.setRowVector(0, var66);
//     double[] var70 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var72 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var70, false);
//     double[][] var73 = new double[][] { var70};
//     org.apache.commons.math.linear.BlockRealMatrix var74 = new org.apache.commons.math.linear.BlockRealMatrix(var73);
//     double var75 = var74.getFrobeniusNorm();
//     double[] var77 = var74.getColumn(0);
//     double[] var78 = var42.preMultiply(var77);
//     var0.stepAccepted(10.0d, var77);
//     double var80 = var0.getEventTime();
//     double var81 = var0.getEventTime();
//     boolean var82 = var0.stop();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var64 + "' != '" + "BlockRealMatrix{{0.0}}"+ "'", var64.equals("BlockRealMatrix{{0.0}}"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var70);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var75 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var78);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var80 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var81 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var82 == false);
// 
//   }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test187"); }


    org.apache.commons.math.analysis.solvers.BrentSolver var0 = new org.apache.commons.math.analysis.solvers.BrentSolver();
    var0.setRelativeAccuracy(100.0d);
    double var3 = var0.getRelativeAccuracy();
    var0.resetMaximalIterationCount();
    double var5 = var0.getFunctionValueAccuracy();
    var0.resetMaximalIterationCount();
    var0.resetAbsoluteAccuracy();
    var0.resetRelativeAccuracy();
    var0.resetMaximalIterationCount();
    org.apache.commons.math.analysis.UnivariateRealFunction var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var14 = var0.solve(var10, 100.0d, 2.147483647E11d, 1.0d);
      fail("Expected exception of type Exception");
    } catch (Exception e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0E-15d);

  }

  public void test188() {}
//   public void test188() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test188"); }
// 
// 
//     double[] var2 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var4 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var2, false);
//     double[][] var5 = new double[][] { var2};
//     org.apache.commons.math.linear.BlockRealMatrix var6 = new org.apache.commons.math.linear.BlockRealMatrix(var5);
//     org.apache.commons.math.linear.BlockRealMatrix var8 = var6.getColumnMatrix(1);
//     double[] var11 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var13 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var11, false);
//     double[][] var14 = new double[][] { var11};
//     org.apache.commons.math.linear.BlockRealMatrix var15 = new org.apache.commons.math.linear.BlockRealMatrix(var14);
//     org.apache.commons.math.linear.BlockRealMatrix var17 = var15.getColumnMatrix(1);
//     org.apache.commons.math.linear.BlockRealMatrix var18 = var8.subtract(var17);
//     org.apache.commons.math.linear.BlockRealMatrix var19 = var17.copy();
//     boolean var20 = var19.isSingular();
//     org.apache.commons.math.linear.RealMatrix var22 = var19.scalarMultiply(0.2d);
//     double[] var25 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var27 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var25, false);
//     double var28 = var27.getCurrentTime();
//     double[] var29 = var27.getInterpolatedState();
//     org.apache.commons.math.linear.BigMatrix var30 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(var29);
//     double[][] var31 = new double[][] { var29};
//     org.apache.commons.math.linear.RealMatrix var32 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(var31);
//     org.apache.commons.math.linear.BlockRealMatrix var33 = new org.apache.commons.math.linear.BlockRealMatrix(var31);
//     org.apache.commons.math.linear.BlockRealMatrix var36 = var33.createMatrix(2, 8);
//     org.apache.commons.math.linear.BlockRealMatrix var38 = var36.getColumnMatrix(2);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.apache.commons.math.linear.BlockRealMatrix var39 = var19.add(var36);
//       fail("Expected exception of type Exception");
//     } catch (Exception e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
// 
//   }

  public void test189() {}
//   public void test189() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test189"); }
// 
// 
//     double[] var2 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var4 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var2, false);
//     double[][] var5 = new double[][] { var2};
//     org.apache.commons.math.linear.BlockRealMatrix var6 = new org.apache.commons.math.linear.BlockRealMatrix(var5);
//     org.apache.commons.math.linear.RealMatrix var8 = var6.scalarMultiply(10.0d);
//     org.apache.commons.math.FunctionEvaluationException var10 = new org.apache.commons.math.FunctionEvaluationException(Double.NaN);
//     boolean var11 = var6.equals((java.lang.Object)Double.NaN);
//     boolean var13 = var6.equals((java.lang.Object)10.0d);
//     org.apache.commons.math.linear.BlockRealMatrix var14 = var6.copy();
//     org.apache.commons.math.ode.events.CombinedEventsManager var19 = new org.apache.commons.math.ode.events.CombinedEventsManager();
//     double[] var23 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var25 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var23, false);
//     double[][] var26 = new double[][] { var23};
//     org.apache.commons.math.linear.BlockRealMatrix var27 = new org.apache.commons.math.linear.BlockRealMatrix(var26);
//     double[] var30 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var32 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var30, false);
//     double[] var33 = var32.getInterpolatedState();
//     double[] var34 = var27.operate(var33);
//     boolean var35 = var19.reset(1.0E-6d, var34);
//     org.apache.commons.math.ode.events.EventHandler var37 = null;
//     org.apache.commons.math.ode.events.EventState var41 = new org.apache.commons.math.ode.events.EventState(var37, 0.0d, (-10.0d), 8);
//     double[] var43 = null;
//     boolean var44 = var41.reset(1.0d, var43);
//     double[] var49 = new double[] { 100.0d, 100.0d, (-1.0d)};
//     org.apache.commons.math.linear.BigMatrix var50 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(var49);
//     boolean var51 = var41.reset(10.0d, var49);
//     boolean var52 = var19.reset((-1.0d), var49);
//     java.lang.Throwable var56 = null;
//     double[] var59 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var61 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var59, false);
//     double var62 = var61.getCurrentTime();
//     double[] var63 = var61.getInterpolatedState();
//     java.lang.Object[] var68 = new java.lang.Object[] { 0.0d};
//     java.util.NoSuchElementException var69 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", var68);
//     java.lang.IllegalArgumentException var70 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("", var68);
//     org.apache.commons.math.FunctionEvaluationException var71 = new org.apache.commons.math.FunctionEvaluationException(var56, var63, "org.apache.commons.math.FunctionEvaluationException: evaluation failed for argument = {-1; 0}", var68);
//     org.apache.commons.math.linear.InvalidMatrixException var72 = new org.apache.commons.math.linear.InvalidMatrixException("org.apache.commons.math.linear.NonSquareMatrixException: a 100x1 matrix was provided instead of a square matrix", var68);
//     org.apache.commons.math.ode.DerivativeException var73 = new org.apache.commons.math.ode.DerivativeException("org.apache.commons.math.FunctionEvaluationException: evaluation failed for argument = {-1; 0}", var68);
//     org.apache.commons.math.FunctionEvaluationException var74 = new org.apache.commons.math.FunctionEvaluationException(var49, "org.apache.commons.math.linear.NonSquareMatrixException: a 100x1 matrix was provided instead of a square matrix", var68);
//     double[] var80 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var82 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var80, false);
//     double var83 = var82.getCurrentTime();
//     double[] var84 = var82.getInterpolatedState();
//     org.apache.commons.math.linear.BigMatrix var85 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(var84);
//     double[][] var86 = new double[][] { var84};
//     org.apache.commons.math.linear.RealMatrix var87 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(var86);
//     org.apache.commons.math.linear.BlockRealMatrix var88 = new org.apache.commons.math.linear.BlockRealMatrix(var86);
//     org.apache.commons.math.ode.events.EventException var89 = new org.apache.commons.math.ode.events.EventException("BlockFieldMatrix{{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0}}", (java.lang.Object[])var86);
//     org.apache.commons.math.FunctionEvaluationException var90 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable)var74, 0.9d, "", (java.lang.Object[])var86);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var6.copySubMatrix((-1000), 2147483646, (-10), 10, var86);
//       fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
//     } catch (org.apache.commons.math.linear.MatrixIndexException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var62 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var70);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var83 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var84);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var85);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var86);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var87);
// 
//   }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test190"); }


    double[] var2 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var4 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var2, false);
    double[][] var5 = new double[][] { var2};
    org.apache.commons.math.linear.BlockRealMatrix var6 = new org.apache.commons.math.linear.BlockRealMatrix(var5);
    org.apache.commons.math.linear.BigMatrix var7 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(var5);
    double[][] var8 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var5);
    org.apache.commons.math.linear.BlockRealMatrix var9 = new org.apache.commons.math.linear.BlockRealMatrix(var8);
    org.apache.commons.math.linear.BlockRealMatrix var10 = new org.apache.commons.math.linear.BlockRealMatrix(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test191() {}
//   public void test191() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test191"); }
// 
// 
//     double[] var5 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var7 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var5, false);
//     double var8 = var7.getCurrentTime();
//     double[] var9 = var7.getInterpolatedState();
//     double[] var10 = var7.getInterpolatedDerivatives();
//     double[] var13 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var15 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var13, false);
//     double var16 = var15.getCurrentTime();
//     double[] var17 = var15.getInterpolatedState();
//     double[] var18 = var15.getInterpolatedDerivatives();
//     org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var19 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, Double.NaN, 1.0E-15d, var10, var18);
//     double var20 = var19.getCurrentStepStart();
//     var19.setMinReduction(1.0d);
//     var19.setSafety(Double.NaN);
//     org.apache.commons.math.ode.FirstOrderIntegrator var25 = null;
//     var19.setStarterIntegrator(var25);
//     var19.setMaxEvaluations(25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == Double.NaN);
// 
//   }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test192"); }


    java.lang.String[] var3 = new java.lang.String[] { "0"};
    org.apache.commons.math.linear.BigMatrix var4 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(var3);
    java.util.NoSuchElementException var5 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("BlockFieldMatrix{{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0}}", (java.lang.Object[])var3);
    org.apache.commons.math.ode.events.EventException var6 = new org.apache.commons.math.ode.events.EventException("java.io.IOException: ", (java.lang.Object[])var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test193"); }


    double[] var4 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var6 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var4, false);
    double[][] var7 = new double[][] { var4};
    org.apache.commons.math.linear.BlockRealMatrix var8 = new org.apache.commons.math.linear.BlockRealMatrix(var7);
    org.apache.commons.math.MaxIterationsExceededException var9 = new org.apache.commons.math.MaxIterationsExceededException(0, "", (java.lang.Object[])var7);
    org.apache.commons.math.linear.Array2DRowRealMatrix var11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var7, false);
    double[] var16 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var18 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var16, false);
    double[][] var19 = new double[][] { var16};
    org.apache.commons.math.linear.BlockRealMatrix var20 = new org.apache.commons.math.linear.BlockRealMatrix(var19);
    org.apache.commons.math.MaxIterationsExceededException var21 = new org.apache.commons.math.MaxIterationsExceededException(0, "", (java.lang.Object[])var19);
    org.apache.commons.math.linear.Array2DRowRealMatrix var23 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var19, false);
    org.apache.commons.math.linear.Array2DRowRealMatrix var24 = var11.subtract(var23);
    int var25 = var23.getRowDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1);

  }

  public void test194() {}
//   public void test194() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test194"); }
// 
// 
//     double[] var5 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var7 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var5, false);
//     double var8 = var7.getCurrentTime();
//     double[] var9 = var7.getInterpolatedState();
//     double[] var10 = var7.getInterpolatedDerivatives();
//     double[] var13 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var15 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var13, false);
//     double var16 = var15.getCurrentTime();
//     double[] var17 = var15.getInterpolatedState();
//     double[] var18 = var15.getInterpolatedDerivatives();
//     org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var19 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, Double.NaN, 1.0E-15d, var10, var18);
//     double[] var24 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var26 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var24, false);
//     double[][] var27 = new double[][] { var24};
//     org.apache.commons.math.linear.BlockRealMatrix var28 = new org.apache.commons.math.linear.BlockRealMatrix(var27);
//     org.apache.commons.math.MaxIterationsExceededException var29 = new org.apache.commons.math.MaxIterationsExceededException(0, "", (java.lang.Object[])var27);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var31 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var27, false);
//     double[] var36 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var38 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var36, false);
//     double[][] var39 = new double[][] { var36};
//     org.apache.commons.math.linear.BlockRealMatrix var40 = new org.apache.commons.math.linear.BlockRealMatrix(var39);
//     org.apache.commons.math.MaxIterationsExceededException var41 = new org.apache.commons.math.MaxIterationsExceededException(0, "", (java.lang.Object[])var39);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var43 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var39, false);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var44 = var31.subtract(var43);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var45 = var19.updateHighOrderDerivativesPhase1(var31);
//     org.apache.commons.math.linear.RealMatrix var46 = var31.copy();
//     double[] var52 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var54 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var52, false);
//     double[][] var55 = new double[][] { var52};
//     org.apache.commons.math.linear.BlockRealMatrix var56 = new org.apache.commons.math.linear.BlockRealMatrix(var55);
//     org.apache.commons.math.MaxIterationsExceededException var57 = new org.apache.commons.math.MaxIterationsExceededException(0, "", (java.lang.Object[])var55);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var59 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var55, false);
//     java.util.NoSuchElementException var60 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("org.apache.commons.math.MathRuntimeException: hi!", (java.lang.Object[])var55);
//     double[][] var61 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var55);
//     double[][] var62 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var55);
//     org.apache.commons.math.linear.BlockRealMatrix var63 = new org.apache.commons.math.linear.BlockRealMatrix(var62);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var31.setSubMatrix(var62, 1, 10);
//       fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
//     } catch (org.apache.commons.math.linear.MatrixIndexException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
// 
//   }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test195"); }


    org.apache.commons.math.fraction.BigFractionField var0 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var1 = var0.getZero();
    org.apache.commons.math.fraction.BigFraction var2 = var0.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var5 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var0, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var6 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var7 = var6.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var8 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var7);
    var8.start(2147483647, 0, 100, (-10), 100, 0);
    org.apache.commons.math.FieldElement var16 = var5.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var8);
    org.apache.commons.math.fraction.BigFractionField var19 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var20 = var19.getZero();
    org.apache.commons.math.fraction.BigFraction var21 = var19.getOne();
    org.apache.commons.math.fraction.BigFraction var23 = var21.pow(100);
    var5.setEntry(10, (-1), (org.apache.commons.math.FieldElement)var23);
    org.apache.commons.math.fraction.BigFractionField var25 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var26 = var25.getZero();
    org.apache.commons.math.fraction.BigFraction var27 = var25.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var30 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var25, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var31 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var32 = var31.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var33 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var32);
    var33.start(2147483647, 0, 100, (-10), 100, 0);
    org.apache.commons.math.FieldElement var41 = var30.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var33);
    org.apache.commons.math.linear.FieldVector var43 = var30.getColumnVector(1);
    org.apache.commons.math.linear.BlockFieldMatrix var44 = var5.multiply(var30);
    int var45 = var30.getColumnDimension();
    org.apache.commons.math.FieldElement[] var47 = var30.getRow(1);
    org.apache.commons.math.linear.FieldMatrix var48 = var30.copy();
    org.apache.commons.math.fraction.BigFractionField var52 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var53 = var52.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var54 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var53);
    org.apache.commons.math.fraction.BigFraction var56 = var53.subtract((-1L));
    org.apache.commons.math.FieldElement[] var57 = new org.apache.commons.math.FieldElement[] { var53};
    org.apache.commons.math.linear.FieldMatrix var58 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var57);
    org.apache.commons.math.linear.FieldMatrix var59 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createColumnFieldMatrix(var57);
    org.apache.commons.math.linear.FieldMatrix var60 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createColumnFieldMatrix(var57);
    org.apache.commons.math.ode.events.EventException var61 = new org.apache.commons.math.ode.events.EventException("org.apache.commons.math.linear.NonSquareMatrixException: a 100x1 matrix was provided instead of a square matrix", (java.lang.Object[])var57);
    org.apache.commons.math.ConvergenceException var62 = new org.apache.commons.math.ConvergenceException("Array2DRowFieldMatrix{}", (java.lang.Object[])var57);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var30.setColumn(25, var57);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test196"); }


    double[] var2 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var4 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var2, false);
    double[][] var5 = new double[][] { var2};
    org.apache.commons.math.linear.BlockRealMatrix var6 = new org.apache.commons.math.linear.BlockRealMatrix(var5);
    org.apache.commons.math.linear.BlockRealMatrix var7 = var6.transpose();
    double[] var11 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var13 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var11, false);
    double[] var14 = var13.getInterpolatedDerivatives();
    var6.setRow(0, var14);
    int var16 = var6.getColumnDimension();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var19 = var6.getEntry((-10), 0);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 2);

  }

  public void test197() {}
//   public void test197() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test197"); }
// 
// 
//     double[] var5 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var7 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var5, false);
//     double var8 = var7.getCurrentTime();
//     double[] var9 = var7.getInterpolatedState();
//     double[] var10 = var7.getInterpolatedDerivatives();
//     double[] var13 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var15 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var13, false);
//     double var16 = var15.getCurrentTime();
//     double[] var17 = var15.getInterpolatedState();
//     double[] var18 = var15.getInterpolatedDerivatives();
//     org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var19 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, Double.NaN, 1.0E-15d, var10, var18);
//     var19.setMinReduction(0.0d);
//     var19.setSafety(1.0d);
//     double var24 = var19.getMaxGrowth();
//     org.apache.commons.math.ode.ODEIntegrator var25 = var19.getStarterIntegrator();
//     double var26 = var19.getCurrentSignedStepsize();
//     var19.setMinReduction((-1000.0d));
//     java.lang.String var29 = var19.getName();
//     var19.setMaxGrowth(0.0d);
//     org.apache.commons.math.ode.sampling.StepHandler var32 = null;
//     var19.addStepHandler(var32);
//     var19.setMinReduction((-99900.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1.4142135623730951d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var29 + "' != '" + "Adams-Moulton"+ "'", var29.equals("Adams-Moulton"));
// 
//   }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test198"); }


    org.apache.commons.math.FieldElement var0 = null;
    org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor var1 = new org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor(var0);
    var1.start(100, 2147483647, 1, 10, 100, 100);
    var1.start(8, 2147483647, 8, 2, 10, 10);
    org.apache.commons.math.FieldElement var18 = null;
    org.apache.commons.math.FieldElement var19 = var1.visit(0, 25, var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test199"); }


    double[] var2 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var4 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var2, false);
    double[][] var5 = new double[][] { var2};
    org.apache.commons.math.linear.BlockRealMatrix var6 = new org.apache.commons.math.linear.BlockRealMatrix(var5);
    org.apache.commons.math.linear.BlockRealMatrix var7 = var6.copy();
    org.apache.commons.math.linear.BlockRealMatrix var8 = var6.copy();
    double[] var11 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var13 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var11, false);
    double[][] var14 = new double[][] { var11};
    org.apache.commons.math.linear.BlockRealMatrix var15 = new org.apache.commons.math.linear.BlockRealMatrix(var14);
    double[] var18 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var20 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var18, false);
    double[][] var21 = new double[][] { var18};
    org.apache.commons.math.linear.BlockRealMatrix var22 = new org.apache.commons.math.linear.BlockRealMatrix(var21);
    double[] var25 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var27 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var25, false);
    double[] var28 = var27.getInterpolatedState();
    double[] var29 = var22.operate(var28);
    org.apache.commons.math.linear.BlockRealMatrix var31 = var22.scalarAdd((-1.0d));
    org.apache.commons.math.linear.RealMatrix var33 = var22.scalarAdd(0.0d);
    org.apache.commons.math.linear.RealMatrix var34 = var22.transpose();
    org.apache.commons.math.linear.BlockRealMatrix var35 = var22.copy();
    org.apache.commons.math.linear.BlockRealMatrix var36 = var15.add(var22);
    org.apache.commons.math.linear.BlockRealMatrix var37 = var6.add((org.apache.commons.math.linear.RealMatrix)var22);
    double[] var39 = var22.getColumn(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test200"); }


    org.apache.commons.math.fraction.BigFractionField var0 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var1 = var0.getZero();
    org.apache.commons.math.fraction.BigFraction var2 = var0.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var5 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var0, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var6 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var7 = var6.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var8 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var7);
    var8.start(2147483647, 0, 100, (-10), 100, 0);
    org.apache.commons.math.FieldElement var16 = var5.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var8);
    org.apache.commons.math.fraction.BigFractionField var19 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var20 = var19.getZero();
    org.apache.commons.math.fraction.BigFraction var21 = var19.getOne();
    org.apache.commons.math.fraction.BigFraction var23 = var21.pow(100);
    var5.setEntry(10, (-1), (org.apache.commons.math.FieldElement)var23);
    org.apache.commons.math.fraction.BigFractionField var25 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var26 = var25.getZero();
    org.apache.commons.math.fraction.BigFraction var27 = var25.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var30 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var25, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var31 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var32 = var31.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var33 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var32);
    var33.start(2147483647, 0, 100, (-10), 100, 0);
    org.apache.commons.math.FieldElement var41 = var30.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var33);
    org.apache.commons.math.linear.FieldVector var43 = var30.getColumnVector(1);
    org.apache.commons.math.linear.BlockFieldMatrix var44 = var5.multiply(var30);
    org.apache.commons.math.linear.FieldVector var46 = var5.getRowVector(8);
    org.apache.commons.math.Field var47 = var5.getField();
    int var48 = var5.getRowDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 10);

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test201"); }


    org.apache.commons.math.fraction.BigFractionField var0 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var1 = var0.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var2 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var1);
    org.apache.commons.math.fraction.BigFraction var4 = var1.subtract((-1L));
    org.apache.commons.math.FieldElement[] var5 = new org.apache.commons.math.FieldElement[] { var1};
    org.apache.commons.math.linear.FieldMatrix var6 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var5);
    org.apache.commons.math.FieldElement[][] var7 = new org.apache.commons.math.FieldElement[][] { var5};
    org.apache.commons.math.linear.Array2DRowFieldMatrix var8 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var7);
    org.apache.commons.math.fraction.BigFractionField var10 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var11 = var10.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var12 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var11);
    org.apache.commons.math.fraction.BigFraction var14 = var11.subtract((-1L));
    org.apache.commons.math.FieldElement[] var15 = new org.apache.commons.math.FieldElement[] { var11};
    org.apache.commons.math.linear.FieldMatrix var16 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var15);
    java.io.EOFException var17 = org.apache.commons.math.MathRuntimeException.createEOFException("java.io.IOException: ", (java.lang.Object[])var15);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var18 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var15);
    org.apache.commons.math.fraction.BigFractionField var19 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var20 = var19.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var21 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var20);
    org.apache.commons.math.fraction.BigFraction var23 = var20.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var25 = var20.subtract(10L);
    double var26 = var25.percentageValue();
    org.apache.commons.math.fraction.BigFraction var28 = var25.multiply(1);
    org.apache.commons.math.fraction.BigFractionField var29 = var25.getField();
    org.apache.commons.math.linear.Array2DRowFieldMatrix var30 = new org.apache.commons.math.linear.Array2DRowFieldMatrix((org.apache.commons.math.Field)var29);
    int var31 = var30.getRowDimension();
    org.apache.commons.math.FieldElement var32 = null;
    org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor var33 = new org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor(var32);
    org.apache.commons.math.FieldElement var34 = var30.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixChangingVisitor)var33);
    org.apache.commons.math.FieldElement[][] var35 = var30.getDataRef();
    org.apache.commons.math.fraction.BigFractionField var36 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var37 = var36.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var38 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var37);
    org.apache.commons.math.fraction.BigFraction var40 = var37.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var42 = var37.subtract(10L);
    double var43 = var42.percentageValue();
    org.apache.commons.math.fraction.BigFraction var45 = var42.multiply(1);
    org.apache.commons.math.fraction.BigFractionField var46 = var42.getField();
    org.apache.commons.math.linear.Array2DRowFieldMatrix var47 = new org.apache.commons.math.linear.Array2DRowFieldMatrix((org.apache.commons.math.Field)var46);
    boolean var48 = var47.isSquare();
    org.apache.commons.math.fraction.BigFractionField var49 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var50 = var49.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var51 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var50);
    org.apache.commons.math.FieldElement var52 = var47.walkInColumnOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var51);
    boolean var53 = var30.equals((java.lang.Object)var51);
    org.apache.commons.math.FieldElement var54 = var18.walkInColumnOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var51);
    org.apache.commons.math.FieldElement var55 = var8.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var51);
    int var56 = var8.getRowDimension();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math.linear.FieldMatrix var58 = var8.getColumnMatrix(2);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == (-1000.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == (-1000.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 1);

  }

  public void test202() {}
//   public void test202() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test202"); }
// 
// 
//     double[] var5 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var7 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var5, false);
//     double[][] var8 = new double[][] { var5};
//     org.apache.commons.math.linear.BlockRealMatrix var9 = new org.apache.commons.math.linear.BlockRealMatrix(var8);
//     org.apache.commons.math.MaxIterationsExceededException var10 = new org.apache.commons.math.MaxIterationsExceededException(0, "", (java.lang.Object[])var8);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var8, false);
//     java.util.NoSuchElementException var13 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("org.apache.commons.math.MathRuntimeException: hi!", (java.lang.Object[])var8);
//     double[][] var14 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var8);
//     double[][] var15 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var8);
//     org.apache.commons.math.linear.BlockRealMatrix var16 = new org.apache.commons.math.linear.BlockRealMatrix(var15);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var18 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var15, false);
//     org.apache.commons.math.linear.RealMatrixChangingVisitor var19 = null;
//     double var20 = var18.walkInRowOrder(var19);
// 
//   }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test203"); }


    org.apache.commons.math.fraction.BigFractionField var0 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var1 = var0.getZero();
    org.apache.commons.math.fraction.BigFraction var2 = var0.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var5 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var0, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var6 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var7 = var6.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var8 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var7);
    var8.start(2147483647, 0, 100, (-10), 100, 0);
    org.apache.commons.math.FieldElement var16 = var5.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var8);
    int var17 = var5.getColumnDimension();
    java.lang.String var18 = var5.toString();
    boolean var19 = var5.isSquare();
    int var20 = var5.getColumnDimension();
    org.apache.commons.math.fraction.BigFraction var23 = new org.apache.commons.math.fraction.BigFraction(2147483647, 1);
    org.apache.commons.math.fraction.BigFraction var24 = var23.reduce();
    org.apache.commons.math.fraction.BigFractionField var25 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var26 = var25.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var27 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var26);
    org.apache.commons.math.fraction.BigFraction var29 = var26.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var31 = var26.pow(2147483647);
    org.apache.commons.math.fraction.BigFraction var33 = var31.pow(0L);
    org.apache.commons.math.fraction.BigFraction var35 = var31.divide(1);
    java.math.BigInteger var36 = var31.getNumerator();
    org.apache.commons.math.fraction.BigFractionField var37 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var38 = var37.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var39 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var38);
    org.apache.commons.math.fraction.BigFraction var41 = var38.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var43 = var38.pow(2147483647);
    org.apache.commons.math.fraction.BigFraction var45 = var43.pow(0L);
    org.apache.commons.math.fraction.BigFraction var47 = var43.divide(1);
    org.apache.commons.math.fraction.BigFraction var48 = var31.multiply(var47);
    java.math.BigInteger var49 = var31.getDenominator();
    org.apache.commons.math.fraction.BigFraction var50 = new org.apache.commons.math.fraction.BigFraction(var49);
    org.apache.commons.math.fraction.BigFraction var51 = var24.subtract(var49);
    org.apache.commons.math.linear.FieldMatrix var52 = var5.scalarAdd((org.apache.commons.math.FieldElement)var51);
    org.apache.commons.math.fraction.BigFractionField var53 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var54 = var53.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var55 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var54);
    org.apache.commons.math.fraction.BigFraction var57 = var54.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var59 = var54.subtract(10L);
    float var60 = var54.floatValue();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var61 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var54);
    double var62 = var54.doubleValue();
    org.apache.commons.math.fraction.BigFraction var63 = var51.multiply(var54);
    org.apache.commons.math.fraction.BigFraction var64 = var63.abs();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + "BlockFieldMatrix{{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0}}"+ "'", var18.equals("BlockFieldMatrix{{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);

  }

  public void test204() {}
//   public void test204() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test204"); }
// 
// 
//     double[] var2 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var4 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var2, false);
//     double var5 = var4.getCurrentTime();
//     double[] var6 = var4.getInterpolatedState();
//     var4.storeTime(1.0d);
//     var4.shift();
//     var4.storeTime(Double.NaN);
//     double[] var12 = var4.getInterpolatedState();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
// 
//   }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test205"); }


    org.apache.commons.math.MaxEvaluationsExceededException var1 = new org.apache.commons.math.MaxEvaluationsExceededException((-1000));
    java.lang.Object[] var3 = null;
    org.apache.commons.math.MathRuntimeException var4 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable)var1, "hi!", var3);
    org.apache.commons.math.linear.InvalidMatrixException var5 = new org.apache.commons.math.linear.InvalidMatrixException((java.lang.Throwable)var1);
    java.lang.String var6 = var1.getPattern();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "Maximal number of evaluations ({0}) exceeded"+ "'", var6.equals("Maximal number of evaluations ({0}) exceeded"));

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test206"); }


    double[] var2 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var4 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var2, false);
    double[][] var5 = new double[][] { var2};
    org.apache.commons.math.linear.BlockRealMatrix var6 = new org.apache.commons.math.linear.BlockRealMatrix(var5);
    org.apache.commons.math.linear.RealMatrix var8 = var6.scalarMultiply(10.0d);
    org.apache.commons.math.FunctionEvaluationException var10 = new org.apache.commons.math.FunctionEvaluationException(Double.NaN);
    boolean var11 = var6.equals((java.lang.Object)Double.NaN);
    org.apache.commons.math.linear.RealMatrix var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math.linear.RealMatrix var13 = var6.solve(var12);
      fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException");
    } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test207"); }


    org.apache.commons.math.fraction.BigFractionField var1 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var2 = var1.getZero();
    double var4 = var2.pow((-1.0d));
    org.apache.commons.math.fraction.BigFraction var5 = var2.abs();
    org.apache.commons.math.FieldElement[] var6 = new org.apache.commons.math.FieldElement[] { var5};
    org.apache.commons.math.linear.FieldMatrix var7 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var6);
    org.apache.commons.math.ode.IntegratorException var8 = new org.apache.commons.math.ode.IntegratorException("2147483647", (java.lang.Object[])var6);
    org.apache.commons.math.fraction.BigFractionField var11 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var12 = var11.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var13 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var12);
    org.apache.commons.math.fraction.BigFraction var15 = var12.subtract((-1L));
    org.apache.commons.math.FieldElement[] var16 = new org.apache.commons.math.FieldElement[] { var12};
    org.apache.commons.math.linear.FieldMatrix var17 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var16);
    org.apache.commons.math.linear.FieldMatrix var18 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createColumnFieldMatrix(var16);
    org.apache.commons.math.linear.FieldMatrix var19 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createColumnFieldMatrix(var16);
    org.apache.commons.math.linear.FieldMatrix var20 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createColumnFieldMatrix(var16);
    org.apache.commons.math.linear.FieldMatrix var21 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createRowFieldMatrix(var16);
    java.lang.IllegalStateException var22 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("Maximal number of iterations ({0}) exceeded", (java.lang.Object[])var16);
    org.apache.commons.math.MathException var23 = new org.apache.commons.math.MathException((java.lang.Throwable)var8, "org.apache.commons.math.FunctionEvaluationException: ", (java.lang.Object[])var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test208() {}
//   public void test208() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test208"); }
// 
// 
//     double[] var4 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var6 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var4, false);
//     double[][] var7 = new double[][] { var4};
//     org.apache.commons.math.linear.BlockRealMatrix var8 = new org.apache.commons.math.linear.BlockRealMatrix(var7);
//     org.apache.commons.math.MaxIterationsExceededException var9 = new org.apache.commons.math.MaxIterationsExceededException(0, "", (java.lang.Object[])var7);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var7, false);
//     double[] var16 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var18 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var16, false);
//     double[][] var19 = new double[][] { var16};
//     org.apache.commons.math.linear.BlockRealMatrix var20 = new org.apache.commons.math.linear.BlockRealMatrix(var19);
//     org.apache.commons.math.MaxIterationsExceededException var21 = new org.apache.commons.math.MaxIterationsExceededException(0, "", (java.lang.Object[])var19);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var23 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var19, false);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var24 = var11.subtract(var23);
//     org.apache.commons.math.linear.RealMatrix var25 = var24.copy();
//     double[][] var26 = var24.getDataRef();
//     double[] var29 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var31 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var29, false);
//     double var32 = var31.getCurrentTime();
//     double[] var33 = var31.getInterpolatedState();
//     org.apache.commons.math.linear.BigMatrix var34 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(var33);
//     double[][] var35 = new double[][] { var33};
//     org.apache.commons.math.linear.RealMatrix var36 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(var35);
//     double[][] var37 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var35);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var38 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var35);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var39 = var24.subtract(var38);
//     org.apache.commons.math.linear.RealMatrixChangingVisitor var40 = null;
//     double var41 = var38.walkInOptimizedOrder(var40);
// 
//   }

  public void test209() {}
//   public void test209() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test209"); }
// 
// 
//     double[] var5 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var7 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var5, false);
//     double var8 = var7.getCurrentTime();
//     double[] var9 = var7.getInterpolatedState();
//     double[] var10 = var7.getInterpolatedDerivatives();
//     double[] var13 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var15 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var13, false);
//     double var16 = var15.getCurrentTime();
//     double[] var17 = var15.getInterpolatedState();
//     double[] var18 = var15.getInterpolatedDerivatives();
//     org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var19 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, Double.NaN, 1.0E-15d, var10, var18);
//     var19.setMinReduction(0.0d);
//     var19.setSafety(1.0d);
//     org.apache.commons.math.ode.ODEIntegrator var24 = var19.getStarterIntegrator();
//     var19.clearStepHandlers();
//     int var26 = var19.getMaxEvaluations();
//     org.apache.commons.math.ode.events.EventHandler var27 = null;
//     var19.addEventHandler(var27, 1.0E100d, 101000.0d, (-1000));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 2147483647);
// 
//   }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test210"); }


    org.apache.commons.math.fraction.BigFractionField var0 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var1 = var0.getZero();
    org.apache.commons.math.fraction.BigFraction var2 = var0.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var5 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var0, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var6 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var7 = var6.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var8 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var7);
    var8.start(2147483647, 0, 100, (-10), 100, 0);
    org.apache.commons.math.FieldElement var16 = var5.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var8);
    org.apache.commons.math.fraction.BigFractionField var17 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var18 = var17.getZero();
    org.apache.commons.math.fraction.BigFraction var19 = var17.getOne();
    org.apache.commons.math.linear.BlockFieldMatrix var22 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var17, 10, 10);
    org.apache.commons.math.fraction.BigFractionField var23 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var24 = var23.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var25 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var24);
    var25.start(2147483647, 0, 100, (-10), 100, 0);
    org.apache.commons.math.FieldElement var33 = var22.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var25);
    org.apache.commons.math.linear.BlockFieldMatrix var34 = var5.subtract(var22);
    int var35 = var5.getColumnDimension();
    org.apache.commons.math.fraction.BigFractionField var36 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var37 = var36.getZero();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var38 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var37);
    org.apache.commons.math.fraction.BigFraction var40 = var37.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var42 = var37.subtract(10L);
    double var43 = var42.percentageValue();
    int var44 = var42.getNumeratorAsInt();
    org.apache.commons.math.fraction.BigFraction var46 = var42.add((-1));
    org.apache.commons.math.fraction.BigFraction var48 = var46.divide(2147483647);
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var49 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var48);
    org.apache.commons.math.linear.FieldMatrix var50 = var5.scalarAdd((org.apache.commons.math.FieldElement)var48);
    java.lang.String var51 = var48.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == (-1000.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == (-10));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var51 + "' != '" + "-11 / 2147483647"+ "'", var51.equals("-11 / 2147483647"));

  }

}
