
import junit.framework.*;

public class RandoopTest12 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test1"); }


    java.lang.Object[] var2 = new java.lang.Object[] { 0.0d};
    org.apache.commons.math.linear.MatrixIndexException var3 = new org.apache.commons.math.linear.MatrixIndexException("hi!", var2);
    org.apache.commons.math.fraction.BigFraction var9 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(2, 100);
    org.apache.commons.math.fraction.BigFraction var12 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(2, 100);
    org.apache.commons.math.fraction.BigFraction var13 = var9.divide(var12);
    org.apache.commons.math.FieldElement[] var14 = new org.apache.commons.math.FieldElement[] { var12};
    org.apache.commons.math.linear.FieldVector var15 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var14);
    org.apache.commons.math.linear.FieldMatrix var16 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var14);
    org.apache.commons.math.ode.IntegratorException var17 = new org.apache.commons.math.ode.IntegratorException("hi!", (java.lang.Object[])var14);
    org.apache.commons.math.FunctionEvaluationException var18 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable)var3, 10.0d, "1 / 5", (java.lang.Object[])var14);
    org.apache.commons.math.FieldElement[][] var19 = new org.apache.commons.math.FieldElement[][] { var14};
    org.apache.commons.math.linear.FieldMatrix var20 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldMatrix(var19);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var21 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var19);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var23 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var19, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math.FieldElement[] var25 = var23.getRow(1);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test2"); }


    org.apache.commons.math.fraction.BigFraction var2 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(2, 100);
    org.apache.commons.math.fraction.BigFraction var5 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(2, 100);
    org.apache.commons.math.fraction.BigFraction var6 = var2.divide(var5);
    org.apache.commons.math.FieldElement[] var7 = new org.apache.commons.math.FieldElement[] { var5};
    org.apache.commons.math.linear.FieldVector var8 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var7);
    org.apache.commons.math.linear.FieldMatrix var9 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createRowFieldMatrix(var7);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var10 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var7);
    org.apache.commons.math.fraction.BigFraction var13 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(2, 100);
    org.apache.commons.math.fraction.BigFraction var16 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(2, 100);
    org.apache.commons.math.fraction.BigFraction var17 = var13.divide(var16);
    org.apache.commons.math.FieldElement[] var18 = new org.apache.commons.math.FieldElement[] { var16};
    org.apache.commons.math.linear.FieldVector var19 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var18);
    org.apache.commons.math.linear.FieldMatrix var20 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createRowFieldMatrix(var18);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var21 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var18);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var22 = var10.add(var21);
    int var23 = var10.getRowDimension();
    org.apache.commons.math.Field var24 = var10.getField();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test3() {}
//   public void test3() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest12.test3"); }
// 
// 
//     org.apache.commons.math.ode.events.EventHandler var1 = null;
//     org.apache.commons.math.ode.events.EventState var5 = new org.apache.commons.math.ode.events.EventState(var1, 0.0d, 100.0d, 10);
//     double[] var9 = new double[] { 1.0d, 1.0d};
//     boolean var10 = var5.reset((-1.0d), var9);
//     double[][] var11 = new double[][] { var9};
//     double[][] var12 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var11);
//     org.apache.commons.math.linear.BigMatrix var13 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(var12);
//     java.lang.IllegalArgumentException var14 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", (java.lang.Object[])var12);
//     org.apache.commons.math.linear.BlockRealMatrix var15 = new org.apache.commons.math.linear.BlockRealMatrix(var12);
//     java.lang.Object var16 = null;
//     boolean var17 = var15.equals(var16);
//     int var18 = var15.getRowDimension();
//     org.apache.commons.math.ode.events.EventHandler var20 = null;
//     org.apache.commons.math.ode.events.EventState var24 = new org.apache.commons.math.ode.events.EventState(var20, 0.0d, 100.0d, 10);
//     double[] var28 = new double[] { 1.0d, 1.0d};
//     boolean var29 = var24.reset((-1.0d), var28);
//     double[][] var30 = new double[][] { var28};
//     double[][] var31 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var30);
//     org.apache.commons.math.linear.BigMatrix var32 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(var31);
//     java.lang.IllegalArgumentException var33 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", (java.lang.Object[])var31);
//     org.apache.commons.math.linear.BlockRealMatrix var34 = new org.apache.commons.math.linear.BlockRealMatrix(var31);
//     org.apache.commons.math.linear.BlockRealMatrix var35 = var15.subtract(var34);
//     org.apache.commons.math.ode.events.EventHandler var37 = null;
//     org.apache.commons.math.ode.events.EventState var41 = new org.apache.commons.math.ode.events.EventState(var37, 0.0d, 100.0d, 10);
//     double[] var45 = new double[] { 1.0d, 1.0d};
//     boolean var46 = var41.reset((-1.0d), var45);
//     double[][] var47 = new double[][] { var45};
//     double[][] var48 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var47);
//     org.apache.commons.math.linear.BigMatrix var49 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(var48);
//     java.lang.IllegalArgumentException var50 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", (java.lang.Object[])var48);
//     org.apache.commons.math.linear.BlockRealMatrix var51 = new org.apache.commons.math.linear.BlockRealMatrix(var48);
//     java.lang.Object var52 = null;
//     boolean var53 = var51.equals(var52);
//     int var54 = var51.getRowDimension();
//     org.apache.commons.math.ode.events.EventHandler var56 = null;
//     org.apache.commons.math.ode.events.EventState var60 = new org.apache.commons.math.ode.events.EventState(var56, 0.0d, 100.0d, 10);
//     double[] var64 = new double[] { 1.0d, 1.0d};
//     boolean var65 = var60.reset((-1.0d), var64);
//     double[][] var66 = new double[][] { var64};
//     double[][] var67 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var66);
//     org.apache.commons.math.linear.BigMatrix var68 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(var67);
//     java.lang.IllegalArgumentException var69 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", (java.lang.Object[])var67);
//     org.apache.commons.math.linear.BlockRealMatrix var70 = new org.apache.commons.math.linear.BlockRealMatrix(var67);
//     org.apache.commons.math.linear.BlockRealMatrix var71 = var51.subtract(var70);
//     org.apache.commons.math.linear.BlockRealMatrix var72 = var15.subtract(var51);
//     org.apache.commons.math.linear.BlockRealMatrix var73 = var51.transpose();
//     double[] var77 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.linear.RealMatrix var78 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(var77);
//     var51.setRow(0, var77);
//     var51.addToEntry(0, 0, (-1.0d));
//     org.apache.commons.math.linear.RealMatrixPreservingVisitor var84 = null;
//     double var85 = var51.walkInRowOrder(var84);
// 
//   }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test4"); }


    org.apache.commons.math.ode.events.EventHandler var1 = null;
    org.apache.commons.math.ode.events.EventState var5 = new org.apache.commons.math.ode.events.EventState(var1, 0.0d, 100.0d, 10);
    double[] var9 = new double[] { 1.0d, 1.0d};
    boolean var10 = var5.reset((-1.0d), var9);
    double[][] var11 = new double[][] { var9};
    double[][] var12 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var11);
    org.apache.commons.math.linear.BigMatrix var13 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(var12);
    java.lang.IllegalArgumentException var14 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", (java.lang.Object[])var12);
    org.apache.commons.math.linear.BlockRealMatrix var15 = new org.apache.commons.math.linear.BlockRealMatrix(var12);
    java.lang.Object var16 = null;
    boolean var17 = var15.equals(var16);
    int var18 = var15.getRowDimension();
    org.apache.commons.math.ode.events.EventHandler var20 = null;
    org.apache.commons.math.ode.events.EventState var24 = new org.apache.commons.math.ode.events.EventState(var20, 0.0d, 100.0d, 10);
    double[] var28 = new double[] { 1.0d, 1.0d};
    boolean var29 = var24.reset((-1.0d), var28);
    double[][] var30 = new double[][] { var28};
    double[][] var31 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var30);
    org.apache.commons.math.linear.BigMatrix var32 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(var31);
    java.lang.IllegalArgumentException var33 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", (java.lang.Object[])var31);
    org.apache.commons.math.linear.BlockRealMatrix var34 = new org.apache.commons.math.linear.BlockRealMatrix(var31);
    java.lang.Object var35 = null;
    boolean var36 = var34.equals(var35);
    int var37 = var34.getRowDimension();
    org.apache.commons.math.linear.BlockRealMatrix var38 = var15.subtract((org.apache.commons.math.linear.RealMatrix)var34);
    org.apache.commons.math.linear.BlockRealMatrix var40 = var34.scalarAdd(100.0d);
    java.lang.Object[] var47 = new java.lang.Object[] { 0.0d};
    org.apache.commons.math.linear.MatrixIndexException var48 = new org.apache.commons.math.linear.MatrixIndexException("hi!", var47);
    java.lang.IllegalArgumentException var49 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((java.lang.Throwable)var48);
    java.lang.Object[] var51 = null;
    org.apache.commons.math.ConvergenceException var52 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable)var48, "hi!", var51);
    org.apache.commons.math.ode.events.EventHandler var54 = null;
    org.apache.commons.math.ode.events.EventState var58 = new org.apache.commons.math.ode.events.EventState(var54, 0.0d, 100.0d, 10);
    double[] var62 = new double[] { 1.0d, 1.0d};
    boolean var63 = var58.reset((-1.0d), var62);
    double[][] var64 = new double[][] { var62};
    double[][] var65 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var64);
    org.apache.commons.math.MathRuntimeException var66 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable)var48, "BlockRealMatrix{{-2.0,0.0}}", (java.lang.Object[])var65);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var40.copySubMatrix(2, 2, 2, (-1), var65);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test5"); }


    org.apache.commons.math.fraction.BigFraction var2 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(2, 100);
    org.apache.commons.math.fraction.BigFraction var5 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(2, 100);
    org.apache.commons.math.fraction.BigFraction var6 = var2.divide(var5);
    org.apache.commons.math.FieldElement[] var7 = new org.apache.commons.math.FieldElement[] { var5};
    org.apache.commons.math.linear.FieldVector var8 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var7);
    org.apache.commons.math.linear.FieldMatrix var9 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createRowFieldMatrix(var7);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var10 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var7);
    org.apache.commons.math.fraction.BigFraction var13 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(2, 100);
    org.apache.commons.math.fraction.BigFraction var16 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(2, 100);
    org.apache.commons.math.fraction.BigFraction var17 = var13.divide(var16);
    org.apache.commons.math.FieldElement[] var18 = new org.apache.commons.math.FieldElement[] { var16};
    org.apache.commons.math.linear.FieldVector var19 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var18);
    org.apache.commons.math.linear.FieldMatrix var20 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createRowFieldMatrix(var18);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var21 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var18);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var22 = var10.add(var21);
    org.apache.commons.math.linear.FieldMatrix var23 = var10.transpose();
    org.apache.commons.math.fraction.BigFraction var26 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(2, 100);
    org.apache.commons.math.fraction.BigFraction var29 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(2, 100);
    org.apache.commons.math.fraction.BigFraction var30 = var26.divide(var29);
    org.apache.commons.math.FieldElement[] var31 = new org.apache.commons.math.FieldElement[] { var29};
    org.apache.commons.math.linear.FieldVector var32 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var31);
    org.apache.commons.math.linear.FieldMatrix var33 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createRowFieldMatrix(var31);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var34 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var31);
    org.apache.commons.math.FieldElement[] var35 = var10.operate(var31);
    org.apache.commons.math.FieldElement[][] var36 = var10.getData();
    boolean var37 = var10.isSquare();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test6"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math.linear.Array2DRowRealMatrix var2 = new org.apache.commons.math.linear.Array2DRowRealMatrix(10, (-1));
      fail("Expected exception of type Exception");
    } catch (Exception e) {
      // Expected exception.
    }

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test7"); }


    java.lang.Object[] var2 = new java.lang.Object[] { 0.0d};
    org.apache.commons.math.linear.MatrixIndexException var3 = new org.apache.commons.math.linear.MatrixIndexException("hi!", var2);
    java.lang.IllegalArgumentException var4 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((java.lang.Throwable)var3);
    double[] var7 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.linear.RealMatrix var8 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(var7);
    org.apache.commons.math.FunctionEvaluationException var9 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable)var4, var7);
    org.apache.commons.math.linear.Array2DRowRealMatrix var10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var7);
    int var11 = var10.getColumnDimension();
    org.apache.commons.math.ode.events.EventHandler var13 = null;
    org.apache.commons.math.ode.events.EventState var17 = new org.apache.commons.math.ode.events.EventState(var13, 0.0d, 100.0d, 10);
    double[] var21 = new double[] { 1.0d, 1.0d};
    boolean var22 = var17.reset((-1.0d), var21);
    double[][] var23 = new double[][] { var21};
    double[][] var24 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var23);
    java.lang.NullPointerException var25 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[])var23);
    org.apache.commons.math.linear.Array2DRowRealMatrix var27 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var23, false);
    org.apache.commons.math.linear.RealMatrix var29 = var27.scalarAdd(100.0d);
    java.lang.Object[] var32 = new java.lang.Object[] { 0.0d};
    org.apache.commons.math.linear.MatrixIndexException var33 = new org.apache.commons.math.linear.MatrixIndexException("hi!", var32);
    java.lang.IllegalArgumentException var34 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((java.lang.Throwable)var33);
    double[] var37 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.linear.RealMatrix var38 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(var37);
    org.apache.commons.math.FunctionEvaluationException var39 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable)var34, var37);
    org.apache.commons.math.linear.Array2DRowRealMatrix var40 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var37);
    org.apache.commons.math.linear.Array2DRowRealMatrix var41 = var27.multiply(var40);
    org.apache.commons.math.linear.RealMatrix var42 = var10.subtract((org.apache.commons.math.linear.RealMatrix)var40);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math.linear.RealMatrix var43 = var40.inverse();
      fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException");
    } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test8"); }


    org.apache.commons.math.ode.events.EventHandler var3 = null;
    org.apache.commons.math.ode.events.EventState var7 = new org.apache.commons.math.ode.events.EventState(var3, 0.0d, 100.0d, 10);
    double[] var11 = new double[] { 1.0d, 1.0d};
    boolean var12 = var7.reset((-1.0d), var11);
    double[][] var13 = new double[][] { var11};
    double[][] var14 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var13);
    java.lang.NullPointerException var15 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[])var13);
    org.apache.commons.math.linear.Array2DRowRealMatrix var17 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var13, false);
    org.apache.commons.math.linear.BigMatrix var18 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(var13);
    java.text.ParseException var19 = org.apache.commons.math.MathRuntimeException.createParseException(0, "", (java.lang.Object[])var13);
    org.apache.commons.math.linear.Array2DRowRealMatrix var20 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var13);
    org.apache.commons.math.linear.RealMatrix var23 = var20.createMatrix(100, 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test9"); }


    java.lang.Object[] var2 = null;
    java.lang.IllegalStateException var3 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("", var2);
    java.lang.Object[] var7 = new java.lang.Object[] { 0.0d};
    org.apache.commons.math.linear.MatrixIndexException var8 = new org.apache.commons.math.linear.MatrixIndexException("hi!", var7);
    org.apache.commons.math.MathException var9 = new org.apache.commons.math.MathException((java.lang.Throwable)var3, "", var7);
    org.apache.commons.math.ode.events.EventException var10 = new org.apache.commons.math.ode.events.EventException("", var7);
    org.apache.commons.math.ode.events.EventHandler var11 = null;
    org.apache.commons.math.ode.events.EventState var15 = new org.apache.commons.math.ode.events.EventState(var11, 0.0d, 100.0d, 10);
    double[] var19 = new double[] { 1.0d, 1.0d};
    boolean var20 = var15.reset((-1.0d), var19);
    java.lang.Object[] var22 = null;
    org.apache.commons.math.FunctionEvaluationException var23 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable)var10, var19, "", var22);
    org.apache.commons.math.linear.RealMatrix var24 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(var19);
    org.apache.commons.math.FunctionEvaluationException var25 = new org.apache.commons.math.FunctionEvaluationException(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test10"); }


    org.apache.commons.math.fraction.BigFraction var2 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(2, 100);
    org.apache.commons.math.fraction.BigFraction var4 = var2.multiply((-1));
    java.lang.String var5 = var2.toString();
    int var6 = var2.intValue();
    org.apache.commons.math.fraction.BigFraction var7 = var2.abs();
    org.apache.commons.math.fraction.BigFraction var10 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(2, 100);
    org.apache.commons.math.fraction.BigFraction var12 = var10.multiply((-1));
    long var13 = var12.getDenominatorAsLong();
    org.apache.commons.math.fraction.BigFraction var14 = var12.reduce();
    org.apache.commons.math.fraction.BigFraction var16 = var12.multiply(100L);
    int var17 = var16.getDenominatorAsInt();
    org.apache.commons.math.fraction.BigFraction var18 = var7.multiply(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "1 / 50"+ "'", var5.equals("1 / 50"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 50L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test11() {}
//   public void test11() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest12.test11"); }
// 
// 
//     org.apache.commons.math.ode.events.EventHandler var1 = null;
//     org.apache.commons.math.ode.events.EventState var5 = new org.apache.commons.math.ode.events.EventState(var1, 0.0d, 100.0d, 10);
//     double[] var9 = new double[] { 1.0d, 1.0d};
//     boolean var10 = var5.reset((-1.0d), var9);
//     double[][] var11 = new double[][] { var9};
//     double[][] var12 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var11);
//     java.lang.NullPointerException var13 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[])var11);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var15 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var11, false);
//     boolean var17 = var15.equals((java.lang.Object)100L);
//     boolean var18 = var15.isSquare();
//     org.apache.commons.math.ode.events.EventHandler var20 = null;
//     org.apache.commons.math.ode.events.EventState var24 = new org.apache.commons.math.ode.events.EventState(var20, 0.0d, 100.0d, 10);
//     double[] var28 = new double[] { 1.0d, 1.0d};
//     boolean var29 = var24.reset((-1.0d), var28);
//     double[][] var30 = new double[][] { var28};
//     double[][] var31 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var30);
//     java.lang.NullPointerException var32 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[])var30);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var34 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var30, false);
//     boolean var36 = var34.equals((java.lang.Object)100L);
//     org.apache.commons.math.ode.events.EventHandler var38 = null;
//     org.apache.commons.math.ode.events.EventState var42 = new org.apache.commons.math.ode.events.EventState(var38, 0.0d, 100.0d, 10);
//     double[] var46 = new double[] { 1.0d, 1.0d};
//     boolean var47 = var42.reset((-1.0d), var46);
//     double[][] var48 = new double[][] { var46};
//     double[][] var49 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var48);
//     java.lang.NullPointerException var50 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[])var48);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var52 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var48, false);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var53 = var34.subtract(var52);
//     org.apache.commons.math.ode.events.EventHandler var55 = null;
//     org.apache.commons.math.ode.events.EventState var59 = new org.apache.commons.math.ode.events.EventState(var55, 0.0d, 100.0d, 10);
//     double[] var63 = new double[] { 1.0d, 1.0d};
//     boolean var64 = var59.reset((-1.0d), var63);
//     double[][] var65 = new double[][] { var63};
//     double[][] var66 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var65);
//     java.lang.NullPointerException var67 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[])var65);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var69 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var65, false);
//     boolean var71 = var69.equals((java.lang.Object)100L);
//     org.apache.commons.math.ode.events.EventHandler var73 = null;
//     org.apache.commons.math.ode.events.EventState var77 = new org.apache.commons.math.ode.events.EventState(var73, 0.0d, 100.0d, 10);
//     double[] var81 = new double[] { 1.0d, 1.0d};
//     boolean var82 = var77.reset((-1.0d), var81);
//     double[][] var83 = new double[][] { var81};
//     double[][] var84 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var83);
//     java.lang.NullPointerException var85 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[])var83);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var87 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var83, false);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var88 = var69.subtract(var87);
//     boolean var89 = var69.isSquare();
//     org.apache.commons.math.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math.linear.AnyMatrix)var34, (org.apache.commons.math.linear.AnyMatrix)var69);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var91 = var15.subtract(var69);
//     org.apache.commons.math.linear.RealMatrixChangingVisitor var92 = null;
//     double var93 = var69.walkInColumnOrder(var92);
// 
//   }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test12"); }


    org.apache.commons.math.ode.events.EventHandler var1 = null;
    org.apache.commons.math.ode.events.EventState var5 = new org.apache.commons.math.ode.events.EventState(var1, 0.0d, 100.0d, 10);
    double[] var9 = new double[] { 1.0d, 1.0d};
    boolean var10 = var5.reset((-1.0d), var9);
    double[][] var11 = new double[][] { var9};
    double[][] var12 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var11);
    java.lang.NullPointerException var13 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[])var11);
    org.apache.commons.math.linear.Array2DRowRealMatrix var15 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var11, false);
    boolean var17 = var15.equals((java.lang.Object)100L);
    boolean var18 = var15.isSquare();
    org.apache.commons.math.ode.events.EventHandler var20 = null;
    org.apache.commons.math.ode.events.EventState var24 = new org.apache.commons.math.ode.events.EventState(var20, 0.0d, 100.0d, 10);
    double[] var28 = new double[] { 1.0d, 1.0d};
    boolean var29 = var24.reset((-1.0d), var28);
    double[][] var30 = new double[][] { var28};
    double[][] var31 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var30);
    java.lang.NullPointerException var32 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[])var30);
    org.apache.commons.math.linear.Array2DRowRealMatrix var34 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var30, false);
    boolean var36 = var34.equals((java.lang.Object)100L);
    org.apache.commons.math.ode.events.EventHandler var38 = null;
    org.apache.commons.math.ode.events.EventState var42 = new org.apache.commons.math.ode.events.EventState(var38, 0.0d, 100.0d, 10);
    double[] var46 = new double[] { 1.0d, 1.0d};
    boolean var47 = var42.reset((-1.0d), var46);
    double[][] var48 = new double[][] { var46};
    double[][] var49 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var48);
    java.lang.NullPointerException var50 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[])var48);
    org.apache.commons.math.linear.Array2DRowRealMatrix var52 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var48, false);
    org.apache.commons.math.linear.Array2DRowRealMatrix var53 = var34.subtract(var52);
    org.apache.commons.math.ode.events.EventHandler var55 = null;
    org.apache.commons.math.ode.events.EventState var59 = new org.apache.commons.math.ode.events.EventState(var55, 0.0d, 100.0d, 10);
    double[] var63 = new double[] { 1.0d, 1.0d};
    boolean var64 = var59.reset((-1.0d), var63);
    double[][] var65 = new double[][] { var63};
    double[][] var66 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var65);
    java.lang.NullPointerException var67 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[])var65);
    org.apache.commons.math.linear.Array2DRowRealMatrix var69 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var65, false);
    boolean var71 = var69.equals((java.lang.Object)100L);
    org.apache.commons.math.ode.events.EventHandler var73 = null;
    org.apache.commons.math.ode.events.EventState var77 = new org.apache.commons.math.ode.events.EventState(var73, 0.0d, 100.0d, 10);
    double[] var81 = new double[] { 1.0d, 1.0d};
    boolean var82 = var77.reset((-1.0d), var81);
    double[][] var83 = new double[][] { var81};
    double[][] var84 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var83);
    java.lang.NullPointerException var85 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[])var83);
    org.apache.commons.math.linear.Array2DRowRealMatrix var87 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var83, false);
    org.apache.commons.math.linear.Array2DRowRealMatrix var88 = var69.subtract(var87);
    boolean var89 = var69.isSquare();
    org.apache.commons.math.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math.linear.AnyMatrix)var34, (org.apache.commons.math.linear.AnyMatrix)var69);
    org.apache.commons.math.linear.Array2DRowRealMatrix var91 = var15.subtract(var69);
    org.apache.commons.math.linear.RealMatrix var92 = var15.copy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test13"); }


    org.apache.commons.math.ode.events.EventHandler var1 = null;
    org.apache.commons.math.ode.events.EventState var5 = new org.apache.commons.math.ode.events.EventState(var1, 0.0d, 100.0d, 10);
    double[] var9 = new double[] { 1.0d, 1.0d};
    boolean var10 = var5.reset((-1.0d), var9);
    double[][] var11 = new double[][] { var9};
    double[][] var12 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var11);
    org.apache.commons.math.linear.BigMatrix var13 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(var12);
    java.lang.IllegalArgumentException var14 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", (java.lang.Object[])var12);
    org.apache.commons.math.linear.BlockRealMatrix var15 = new org.apache.commons.math.linear.BlockRealMatrix(var12);
    java.lang.Object var16 = null;
    boolean var17 = var15.equals(var16);
    int var18 = var15.getRowDimension();
    org.apache.commons.math.ode.events.EventHandler var20 = null;
    org.apache.commons.math.ode.events.EventState var24 = new org.apache.commons.math.ode.events.EventState(var20, 0.0d, 100.0d, 10);
    double[] var28 = new double[] { 1.0d, 1.0d};
    boolean var29 = var24.reset((-1.0d), var28);
    double[][] var30 = new double[][] { var28};
    double[][] var31 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var30);
    org.apache.commons.math.linear.BigMatrix var32 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(var31);
    java.lang.IllegalArgumentException var33 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", (java.lang.Object[])var31);
    org.apache.commons.math.linear.BlockRealMatrix var34 = new org.apache.commons.math.linear.BlockRealMatrix(var31);
    java.lang.Object var35 = null;
    boolean var36 = var34.equals(var35);
    int var37 = var34.getRowDimension();
    org.apache.commons.math.linear.BlockRealMatrix var38 = var15.subtract((org.apache.commons.math.linear.RealMatrix)var34);
    org.apache.commons.math.linear.BlockRealMatrix var39 = var38.copy();
    java.lang.Object[] var42 = null;
    java.lang.IllegalStateException var43 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("", var42);
    java.lang.Object[] var47 = new java.lang.Object[] { 0.0d};
    org.apache.commons.math.linear.MatrixIndexException var48 = new org.apache.commons.math.linear.MatrixIndexException("hi!", var47);
    org.apache.commons.math.MathException var49 = new org.apache.commons.math.MathException((java.lang.Throwable)var43, "", var47);
    java.lang.ArrayIndexOutOfBoundsException var50 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("hi!", var47);
    java.lang.String var51 = var50.toString();
    boolean var52 = var38.equals((java.lang.Object)var51);
    org.apache.commons.math.linear.RealMatrix var54 = var38.scalarAdd(0.02d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var51 + "' != '" + "org.apache.commons.math.MathRuntimeException$2: hi!"+ "'", var51.equals("org.apache.commons.math.MathRuntimeException$2: hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);

  }

  public void test14() {}
//   public void test14() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest12.test14"); }
// 
// 
//     org.apache.commons.math.ode.events.EventHandler var4 = null;
//     org.apache.commons.math.ode.events.EventState var8 = new org.apache.commons.math.ode.events.EventState(var4, 0.0d, 100.0d, 10);
//     double[] var12 = new double[] { 1.0d, 1.0d};
//     boolean var13 = var8.reset((-1.0d), var12);
//     double[][] var14 = new double[][] { var12};
//     double[][] var15 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var14);
//     java.lang.NullPointerException var16 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[])var14);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var18 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var14, false);
//     boolean var20 = var18.equals((java.lang.Object)100L);
//     org.apache.commons.math.ode.events.EventHandler var22 = null;
//     org.apache.commons.math.ode.events.EventState var26 = new org.apache.commons.math.ode.events.EventState(var22, 0.0d, 100.0d, 10);
//     double[] var30 = new double[] { 1.0d, 1.0d};
//     boolean var31 = var26.reset((-1.0d), var30);
//     double[][] var32 = new double[][] { var30};
//     double[][] var33 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var32);
//     java.lang.NullPointerException var34 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[])var32);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var36 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var32, false);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var37 = var18.subtract(var36);
//     org.apache.commons.math.ode.events.EventHandler var39 = null;
//     org.apache.commons.math.ode.events.EventState var43 = new org.apache.commons.math.ode.events.EventState(var39, 0.0d, 100.0d, 10);
//     double[] var47 = new double[] { 1.0d, 1.0d};
//     boolean var48 = var43.reset((-1.0d), var47);
//     double[][] var49 = new double[][] { var47};
//     double[][] var50 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var49);
//     java.lang.NullPointerException var51 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[])var49);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var53 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var49, false);
//     boolean var55 = var53.equals((java.lang.Object)100L);
//     org.apache.commons.math.ode.events.EventHandler var57 = null;
//     org.apache.commons.math.ode.events.EventState var61 = new org.apache.commons.math.ode.events.EventState(var57, 0.0d, 100.0d, 10);
//     double[] var65 = new double[] { 1.0d, 1.0d};
//     boolean var66 = var61.reset((-1.0d), var65);
//     double[][] var67 = new double[][] { var65};
//     double[][] var68 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var67);
//     java.lang.NullPointerException var69 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[])var67);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var71 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var67, false);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var72 = var53.subtract(var71);
//     boolean var73 = var53.isSquare();
//     org.apache.commons.math.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math.linear.AnyMatrix)var18, (org.apache.commons.math.linear.AnyMatrix)var53);
//     java.lang.Object[] var77 = new java.lang.Object[] { 0.0d};
//     org.apache.commons.math.linear.MatrixIndexException var78 = new org.apache.commons.math.linear.MatrixIndexException("hi!", var77);
//     java.lang.IllegalArgumentException var79 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((java.lang.Throwable)var78);
//     double[] var82 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.linear.RealMatrix var83 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(var82);
//     org.apache.commons.math.FunctionEvaluationException var84 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable)var79, var82);
//     double[] var85 = var53.operate(var82);
//     double[] var86 = null;
//     org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var87 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator((-1), 0.0d, (-0.02d), var85, var86);
// 
//   }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test15"); }


    org.apache.commons.math.fraction.BigFraction var2 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(2, 100);
    org.apache.commons.math.fraction.BigFraction var4 = var2.multiply((-1));
    long var5 = var4.getDenominatorAsLong();
    org.apache.commons.math.fraction.BigFraction var6 = var4.reduce();
    long var7 = var6.getNumeratorAsLong();
    java.math.BigDecimal var10 = var6.bigDecimalValue(100, 0);
    long var11 = var6.getNumeratorAsLong();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 50L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-1L));

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test16"); }


    org.apache.commons.math.fraction.FractionConversionException var2 = new org.apache.commons.math.fraction.FractionConversionException((-1.0d), (-1));
    java.lang.String var3 = var2.getPattern();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "Unable to convert {0} to fraction after {1} iterations"+ "'", var3.equals("Unable to convert {0} to fraction after {1} iterations"));

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test17"); }


    org.apache.commons.math.ode.events.EventHandler var1 = null;
    org.apache.commons.math.ode.events.EventState var5 = new org.apache.commons.math.ode.events.EventState(var1, 0.0d, 100.0d, 10);
    double[] var9 = new double[] { 1.0d, 1.0d};
    boolean var10 = var5.reset((-1.0d), var9);
    double[][] var11 = new double[][] { var9};
    double[][] var12 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var11);
    java.lang.NullPointerException var13 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[])var11);
    org.apache.commons.math.linear.Array2DRowRealMatrix var15 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var11, false);
    org.apache.commons.math.linear.RealMatrix var17 = var15.scalarAdd(100.0d);
    java.lang.Object[] var20 = new java.lang.Object[] { 0.0d};
    org.apache.commons.math.linear.MatrixIndexException var21 = new org.apache.commons.math.linear.MatrixIndexException("hi!", var20);
    java.lang.IllegalArgumentException var22 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((java.lang.Throwable)var21);
    double[] var25 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.linear.RealMatrix var26 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(var25);
    org.apache.commons.math.FunctionEvaluationException var27 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable)var22, var25);
    org.apache.commons.math.linear.Array2DRowRealMatrix var28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var25);
    org.apache.commons.math.linear.Array2DRowRealMatrix var29 = var15.multiply(var28);
    double var30 = var28.getFrobeniusNorm();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var28.addToEntry(2, 0, 2.0E-4d);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 1.0d);

  }

  public void test18() {}
//   public void test18() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest12.test18"); }
// 
// 
//     org.apache.commons.math.fraction.BigFraction var2 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(2, 100);
//     org.apache.commons.math.fraction.BigFraction var5 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(2, 100);
//     org.apache.commons.math.fraction.BigFraction var6 = var2.divide(var5);
//     org.apache.commons.math.FieldElement[] var7 = new org.apache.commons.math.FieldElement[] { var5};
//     org.apache.commons.math.linear.FieldVector var8 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var7);
//     org.apache.commons.math.linear.FieldMatrix var9 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createRowFieldMatrix(var7);
//     org.apache.commons.math.linear.Array2DRowFieldMatrix var10 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var7);
//     org.apache.commons.math.fraction.BigFraction var13 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(2, 100);
//     org.apache.commons.math.fraction.BigFraction var16 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(2, 100);
//     org.apache.commons.math.fraction.BigFraction var17 = var13.divide(var16);
//     org.apache.commons.math.FieldElement[] var18 = new org.apache.commons.math.FieldElement[] { var16};
//     org.apache.commons.math.linear.FieldVector var19 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var18);
//     org.apache.commons.math.linear.FieldMatrix var20 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createRowFieldMatrix(var18);
//     org.apache.commons.math.linear.Array2DRowFieldMatrix var21 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var18);
//     org.apache.commons.math.linear.Array2DRowFieldMatrix var22 = var10.add(var21);
//     int var23 = var10.getRowDimension();
//     int[] var24 = null;
//     int[] var25 = new int[] { };
//     org.apache.commons.math.linear.FieldMatrix var26 = var10.getSubMatrix(var24, var25);
// 
//   }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test19"); }


    org.apache.commons.math.ode.events.EventHandler var2 = null;
    org.apache.commons.math.ode.events.EventState var6 = new org.apache.commons.math.ode.events.EventState(var2, 0.0d, 100.0d, 10);
    double[] var10 = new double[] { 1.0d, 1.0d};
    boolean var11 = var6.reset((-1.0d), var10);
    org.apache.commons.math.ode.events.EventHandler var12 = var6.getEventHandler();
    double[] var15 = new double[] { 0.0d};
    boolean var16 = var6.reset(0.0d, var15);
    org.apache.commons.math.ode.events.EventHandler var20 = null;
    org.apache.commons.math.ode.events.EventState var24 = new org.apache.commons.math.ode.events.EventState(var20, 0.0d, 100.0d, 10);
    double[] var28 = new double[] { 1.0d, 1.0d};
    boolean var29 = var24.reset((-1.0d), var28);
    org.apache.commons.math.ode.events.EventHandler var30 = var24.getEventHandler();
    org.apache.commons.math.ode.events.EventHandler var32 = null;
    org.apache.commons.math.ode.events.EventState var36 = new org.apache.commons.math.ode.events.EventState(var32, 0.0d, 100.0d, 10);
    double[] var40 = new double[] { 1.0d, 1.0d};
    boolean var41 = var36.reset((-1.0d), var40);
    org.apache.commons.math.ode.events.EventHandler var42 = var36.getEventHandler();
    double[] var45 = new double[] { 0.0d};
    boolean var46 = var36.reset(0.0d, var45);
    boolean var47 = var24.reset(10.0d, var45);
    org.apache.commons.math.ode.events.EventHandler var48 = null;
    org.apache.commons.math.ode.events.EventState var52 = new org.apache.commons.math.ode.events.EventState(var48, 0.0d, 100.0d, 10);
    double[] var56 = new double[] { 1.0d, 1.0d};
    boolean var57 = var52.reset((-1.0d), var56);
    org.apache.commons.math.ode.events.EventHandler var58 = var52.getEventHandler();
    org.apache.commons.math.ode.events.EventHandler var60 = null;
    org.apache.commons.math.ode.events.EventState var64 = new org.apache.commons.math.ode.events.EventState(var60, 0.0d, 100.0d, 10);
    double[] var68 = new double[] { 1.0d, 1.0d};
    boolean var69 = var64.reset((-1.0d), var68);
    org.apache.commons.math.ode.events.EventHandler var70 = var64.getEventHandler();
    double[] var73 = new double[] { 0.0d};
    boolean var74 = var64.reset(0.0d, var73);
    boolean var75 = var52.reset(10.0d, var73);
    org.apache.commons.math.linear.RealMatrix var76 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(var73);
    org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var77 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(2, (-0.02d), 10.0d, var45, var73);
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var78 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(1.0d, 1.0d, var15, var73);
    var78.setSafety((-1.0d));
    double var81 = var78.getMinReduction();
    var78.clearStepHandlers();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0.2d);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test20"); }


    org.apache.commons.math.fraction.BigFraction var2 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(2, 100);
    org.apache.commons.math.fraction.BigFraction var5 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(2, 100);
    org.apache.commons.math.fraction.BigFraction var6 = var2.divide(var5);
    org.apache.commons.math.FieldElement[] var7 = new org.apache.commons.math.FieldElement[] { var5};
    org.apache.commons.math.linear.FieldVector var8 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var7);
    org.apache.commons.math.linear.FieldMatrix var9 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createRowFieldMatrix(var7);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var10 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var7);
    org.apache.commons.math.fraction.BigFraction var13 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(2, 100);
    org.apache.commons.math.fraction.BigFraction var16 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(2, 100);
    org.apache.commons.math.fraction.BigFraction var17 = var13.divide(var16);
    org.apache.commons.math.FieldElement[] var18 = new org.apache.commons.math.FieldElement[] { var16};
    org.apache.commons.math.linear.FieldVector var19 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var18);
    org.apache.commons.math.linear.FieldMatrix var20 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createRowFieldMatrix(var18);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var21 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var18);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var22 = var10.add(var21);
    org.apache.commons.math.fraction.BigFraction var25 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(2, 100);
    org.apache.commons.math.fraction.BigFraction var28 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(2, 100);
    org.apache.commons.math.fraction.BigFraction var29 = var25.divide(var28);
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var30 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var29);
    org.apache.commons.math.FieldElement var31 = var22.walkInColumnOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var30);
    org.apache.commons.math.fraction.BigFraction var34 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(2, 100);
    org.apache.commons.math.fraction.BigFraction var37 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(2, 100);
    org.apache.commons.math.fraction.BigFraction var38 = var34.divide(var37);
    org.apache.commons.math.FieldElement[] var39 = new org.apache.commons.math.FieldElement[] { var37};
    org.apache.commons.math.linear.FieldVector var40 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var39);
    org.apache.commons.math.linear.FieldMatrix var41 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var39);
    org.apache.commons.math.linear.FieldMatrix var42 = var22.multiply(var41);
    int var43 = var22.getRowDimension();
    org.apache.commons.math.fraction.BigFraction var46 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(2, 100);
    org.apache.commons.math.fraction.BigFraction var48 = var46.multiply((-1));
    long var49 = var48.getDenominatorAsLong();
    org.apache.commons.math.fraction.BigFraction var50 = var48.reduce();
    org.apache.commons.math.fraction.BigFraction var52 = var50.subtract(0);
    org.apache.commons.math.fraction.BigFractionField var53 = var50.getField();
    org.apache.commons.math.fraction.BigFraction var56 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(2, 100);
    org.apache.commons.math.fraction.BigFraction var58 = var56.multiply((-1));
    long var59 = var58.getDenominatorAsLong();
    org.apache.commons.math.fraction.BigFraction var60 = var58.reduce();
    org.apache.commons.math.fraction.BigFraction var62 = var60.subtract(0);
    org.apache.commons.math.fraction.BigFraction var65 = new org.apache.commons.math.fraction.BigFraction(2, 10);
    long var66 = var65.longValue();
    org.apache.commons.math.fraction.BigFraction var67 = var60.multiply(var65);
    org.apache.commons.math.fraction.BigFraction var70 = new org.apache.commons.math.fraction.BigFraction(2, 10);
    java.math.BigInteger var71 = var70.getNumerator();
    org.apache.commons.math.fraction.BigFraction var72 = var65.pow(var71);
    org.apache.commons.math.fraction.BigFraction var73 = var50.subtract(var71);
    org.apache.commons.math.fraction.BigFraction var74 = var50.abs();
    org.apache.commons.math.linear.FieldMatrix var75 = var22.scalarAdd((org.apache.commons.math.FieldElement)var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 50L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 50L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);

  }

  public void test21() {}
//   public void test21() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest12.test21"); }
// 
// 
//     java.lang.Object[] var2 = null;
//     java.lang.IllegalStateException var3 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("", var2);
//     java.lang.Object[] var7 = new java.lang.Object[] { 0.0d};
//     org.apache.commons.math.linear.MatrixIndexException var8 = new org.apache.commons.math.linear.MatrixIndexException("hi!", var7);
//     org.apache.commons.math.MathException var9 = new org.apache.commons.math.MathException((java.lang.Throwable)var3, "", var7);
//     org.apache.commons.math.ode.events.EventException var10 = new org.apache.commons.math.ode.events.EventException("", var7);
//     org.apache.commons.math.ode.events.EventHandler var11 = null;
//     org.apache.commons.math.ode.events.EventState var15 = new org.apache.commons.math.ode.events.EventState(var11, 0.0d, 100.0d, 10);
//     double[] var19 = new double[] { 1.0d, 1.0d};
//     boolean var20 = var15.reset((-1.0d), var19);
//     java.lang.Object[] var22 = null;
//     org.apache.commons.math.FunctionEvaluationException var23 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable)var10, var19, "", var22);
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var25 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var19, false);
//     double[] var26 = var25.getInterpolatedDerivatives();
//     double var27 = var25.getCurrentTime();
//     var25.shift();
//     var25.setInterpolatedTime(0.0d);
//     java.io.ObjectInput var31 = null;
//     var25.readExternal(var31);
// 
//   }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test22"); }


    org.apache.commons.math.fraction.BigFraction var2 = new org.apache.commons.math.fraction.BigFraction(2, 10);
    java.math.BigInteger var3 = var2.getNumerator();
    org.apache.commons.math.fraction.BigFraction var6 = new org.apache.commons.math.fraction.BigFraction(2, 10);
    java.math.BigInteger var7 = var6.getNumerator();
    org.apache.commons.math.fraction.BigFraction var8 = var2.add(var7);
    org.apache.commons.math.fraction.BigFraction var10 = var2.multiply(2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test23"); }


    java.lang.Object[] var2 = null;
    java.lang.IllegalStateException var3 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("", var2);
    java.lang.Object[] var7 = new java.lang.Object[] { 0.0d};
    org.apache.commons.math.linear.MatrixIndexException var8 = new org.apache.commons.math.linear.MatrixIndexException("hi!", var7);
    org.apache.commons.math.MathException var9 = new org.apache.commons.math.MathException((java.lang.Throwable)var3, "", var7);
    org.apache.commons.math.ode.events.EventException var10 = new org.apache.commons.math.ode.events.EventException("", var7);
    java.lang.String var11 = var10.getPattern();
    org.apache.commons.math.ode.events.EventHandler var16 = null;
    org.apache.commons.math.ode.events.EventState var20 = new org.apache.commons.math.ode.events.EventState(var16, 0.0d, 100.0d, 10);
    double[] var24 = new double[] { 1.0d, 1.0d};
    boolean var25 = var20.reset((-1.0d), var24);
    org.apache.commons.math.ode.events.EventHandler var26 = var20.getEventHandler();
    double[] var29 = new double[] { 0.0d};
    boolean var30 = var20.reset(0.0d, var29);
    java.lang.Object[] var31 = new java.lang.Object[] { var29};
    org.apache.commons.math.linear.MatrixIndexException var32 = new org.apache.commons.math.linear.MatrixIndexException("", var31);
    org.apache.commons.math.MaxEvaluationsExceededException var33 = new org.apache.commons.math.MaxEvaluationsExceededException(10, "", var31);
    org.apache.commons.math.MathRuntimeException var34 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable)var10, "1 / 5", var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + ""+ "'", var11.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test24"); }


    java.lang.Object[] var4 = null;
    java.lang.IllegalStateException var5 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("", var4);
    java.lang.Object[] var9 = new java.lang.Object[] { 0.0d};
    org.apache.commons.math.linear.MatrixIndexException var10 = new org.apache.commons.math.linear.MatrixIndexException("hi!", var9);
    org.apache.commons.math.MathException var11 = new org.apache.commons.math.MathException((java.lang.Throwable)var5, "", var9);
    org.apache.commons.math.ode.events.EventException var12 = new org.apache.commons.math.ode.events.EventException("", var9);
    org.apache.commons.math.ode.events.EventHandler var13 = null;
    org.apache.commons.math.ode.events.EventState var17 = new org.apache.commons.math.ode.events.EventState(var13, 0.0d, 100.0d, 10);
    double[] var21 = new double[] { 1.0d, 1.0d};
    boolean var22 = var17.reset((-1.0d), var21);
    java.lang.Object[] var24 = null;
    org.apache.commons.math.FunctionEvaluationException var25 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable)var12, var21, "", var24);
    java.lang.Object[] var29 = new java.lang.Object[] { 0.0d};
    org.apache.commons.math.linear.MatrixIndexException var30 = new org.apache.commons.math.linear.MatrixIndexException("hi!", var29);
    java.lang.IllegalArgumentException var31 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((java.lang.Throwable)var30);
    java.lang.Object[] var33 = null;
    org.apache.commons.math.ConvergenceException var34 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable)var30, "hi!", var33);
    java.lang.Object[] var35 = var30.getArguments();
    org.apache.commons.math.ConvergenceException var36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable)var25, "1 / 5", var35);
    java.lang.NullPointerException var37 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", var35);
    java.lang.IllegalStateException var38 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("1 / 5", var35);
    org.apache.commons.math.ode.DerivativeException var39 = new org.apache.commons.math.ode.DerivativeException((java.lang.Throwable)var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test25"); }


    org.apache.commons.math.ode.events.EventHandler var1 = null;
    org.apache.commons.math.ode.events.EventState var5 = new org.apache.commons.math.ode.events.EventState(var1, 0.0d, 100.0d, 10);
    double[] var9 = new double[] { 1.0d, 1.0d};
    boolean var10 = var5.reset((-1.0d), var9);
    double[][] var11 = new double[][] { var9};
    double[][] var12 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var11);
    java.lang.NullPointerException var13 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[])var11);
    org.apache.commons.math.linear.Array2DRowRealMatrix var15 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var11, false);
    boolean var17 = var15.equals((java.lang.Object)100L);
    org.apache.commons.math.ode.events.EventHandler var19 = null;
    org.apache.commons.math.ode.events.EventState var23 = new org.apache.commons.math.ode.events.EventState(var19, 0.0d, 100.0d, 10);
    double[] var27 = new double[] { 1.0d, 1.0d};
    boolean var28 = var23.reset((-1.0d), var27);
    double[][] var29 = new double[][] { var27};
    double[][] var30 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var29);
    java.lang.NullPointerException var31 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[])var29);
    org.apache.commons.math.linear.Array2DRowRealMatrix var33 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var29, false);
    org.apache.commons.math.linear.Array2DRowRealMatrix var34 = var15.subtract(var33);
    org.apache.commons.math.ode.events.EventHandler var36 = null;
    org.apache.commons.math.ode.events.EventState var40 = new org.apache.commons.math.ode.events.EventState(var36, 0.0d, 100.0d, 10);
    double[] var44 = new double[] { 1.0d, 1.0d};
    boolean var45 = var40.reset((-1.0d), var44);
    double[][] var46 = new double[][] { var44};
    double[][] var47 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var46);
    java.lang.NullPointerException var48 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[])var46);
    org.apache.commons.math.linear.Array2DRowRealMatrix var50 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var46, false);
    boolean var52 = var50.equals((java.lang.Object)100L);
    org.apache.commons.math.ode.events.EventHandler var54 = null;
    org.apache.commons.math.ode.events.EventState var58 = new org.apache.commons.math.ode.events.EventState(var54, 0.0d, 100.0d, 10);
    double[] var62 = new double[] { 1.0d, 1.0d};
    boolean var63 = var58.reset((-1.0d), var62);
    double[][] var64 = new double[][] { var62};
    double[][] var65 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var64);
    java.lang.NullPointerException var66 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[])var64);
    org.apache.commons.math.linear.Array2DRowRealMatrix var68 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var64, false);
    org.apache.commons.math.linear.Array2DRowRealMatrix var69 = var50.subtract(var68);
    boolean var70 = var50.isSquare();
    org.apache.commons.math.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math.linear.AnyMatrix)var15, (org.apache.commons.math.linear.AnyMatrix)var50);
    int var72 = var50.getColumnDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 2);

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test26"); }


    org.apache.commons.math.ode.events.EventHandler var1 = null;
    org.apache.commons.math.ode.events.EventState var5 = new org.apache.commons.math.ode.events.EventState(var1, 0.0d, 100.0d, 10);
    double[] var9 = new double[] { 1.0d, 1.0d};
    boolean var10 = var5.reset((-1.0d), var9);
    double[][] var11 = new double[][] { var9};
    double[][] var12 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var11);
    java.lang.NullPointerException var13 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[])var11);
    org.apache.commons.math.linear.Array2DRowRealMatrix var15 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var11, false);
    org.apache.commons.math.linear.RealMatrix var17 = var15.scalarAdd(100.0d);
    java.lang.Object[] var20 = new java.lang.Object[] { 0.0d};
    org.apache.commons.math.linear.MatrixIndexException var21 = new org.apache.commons.math.linear.MatrixIndexException("hi!", var20);
    java.lang.IllegalArgumentException var22 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((java.lang.Throwable)var21);
    double[] var25 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.linear.RealMatrix var26 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(var25);
    org.apache.commons.math.FunctionEvaluationException var27 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable)var22, var25);
    org.apache.commons.math.linear.Array2DRowRealMatrix var28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var25);
    int var29 = var28.getColumnDimension();
    org.apache.commons.math.ode.events.EventHandler var31 = null;
    org.apache.commons.math.ode.events.EventState var35 = new org.apache.commons.math.ode.events.EventState(var31, 0.0d, 100.0d, 10);
    double[] var39 = new double[] { 1.0d, 1.0d};
    boolean var40 = var35.reset((-1.0d), var39);
    double[][] var41 = new double[][] { var39};
    double[][] var42 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var41);
    java.lang.NullPointerException var43 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[])var41);
    org.apache.commons.math.linear.Array2DRowRealMatrix var45 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var41, false);
    org.apache.commons.math.linear.RealMatrix var47 = var45.scalarAdd(100.0d);
    java.lang.Object[] var50 = new java.lang.Object[] { 0.0d};
    org.apache.commons.math.linear.MatrixIndexException var51 = new org.apache.commons.math.linear.MatrixIndexException("hi!", var50);
    java.lang.IllegalArgumentException var52 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((java.lang.Throwable)var51);
    double[] var55 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.linear.RealMatrix var56 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(var55);
    org.apache.commons.math.FunctionEvaluationException var57 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable)var52, var55);
    org.apache.commons.math.linear.Array2DRowRealMatrix var58 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var55);
    org.apache.commons.math.linear.Array2DRowRealMatrix var59 = var45.multiply(var58);
    org.apache.commons.math.linear.RealMatrix var60 = var28.subtract((org.apache.commons.math.linear.RealMatrix)var58);
    org.apache.commons.math.linear.Array2DRowRealMatrix var61 = var15.multiply(var58);
    double[][] var62 = var58.getData();
    org.apache.commons.math.linear.Array2DRowRealMatrix var65 = new org.apache.commons.math.linear.Array2DRowRealMatrix(2, 2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math.linear.RealMatrix var66 = var58.subtract((org.apache.commons.math.linear.RealMatrix)var65);
      fail("Expected exception of type Exception");
    } catch (Exception e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);

  }

  public void test27() {}
//   public void test27() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest12.test27"); }
// 
// 
//     org.apache.commons.math.ode.events.EventHandler var1 = null;
//     org.apache.commons.math.ode.events.EventState var5 = new org.apache.commons.math.ode.events.EventState(var1, 0.0d, 100.0d, 10);
//     double[] var9 = new double[] { 1.0d, 1.0d};
//     boolean var10 = var5.reset((-1.0d), var9);
//     double[][] var11 = new double[][] { var9};
//     double[][] var12 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var11);
//     org.apache.commons.math.linear.BigMatrix var13 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(var12);
//     java.lang.IllegalArgumentException var14 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", (java.lang.Object[])var12);
//     org.apache.commons.math.linear.BlockRealMatrix var15 = new org.apache.commons.math.linear.BlockRealMatrix(var12);
//     java.lang.Object[] var18 = new java.lang.Object[] { 0.0d};
//     org.apache.commons.math.linear.MatrixIndexException var19 = new org.apache.commons.math.linear.MatrixIndexException("hi!", var18);
//     java.lang.IllegalArgumentException var20 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((java.lang.Throwable)var19);
//     double[] var23 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.linear.RealMatrix var24 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(var23);
//     org.apache.commons.math.FunctionEvaluationException var25 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable)var20, var23);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var23);
//     int var27 = var26.getColumnDimension();
//     org.apache.commons.math.ode.events.EventHandler var29 = null;
//     org.apache.commons.math.ode.events.EventState var33 = new org.apache.commons.math.ode.events.EventState(var29, 0.0d, 100.0d, 10);
//     double[] var37 = new double[] { 1.0d, 1.0d};
//     boolean var38 = var33.reset((-1.0d), var37);
//     double[][] var39 = new double[][] { var37};
//     double[][] var40 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var39);
//     java.lang.NullPointerException var41 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[])var39);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var43 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var39, false);
//     org.apache.commons.math.linear.RealMatrix var45 = var43.scalarAdd(100.0d);
//     java.lang.Object[] var48 = new java.lang.Object[] { 0.0d};
//     org.apache.commons.math.linear.MatrixIndexException var49 = new org.apache.commons.math.linear.MatrixIndexException("hi!", var48);
//     java.lang.IllegalArgumentException var50 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((java.lang.Throwable)var49);
//     double[] var53 = new double[] { (-1.0d), 0.0d};
//     org.apache.commons.math.linear.RealMatrix var54 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(var53);
//     org.apache.commons.math.FunctionEvaluationException var55 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable)var50, var53);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var56 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var53);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var57 = var43.multiply(var56);
//     org.apache.commons.math.linear.RealMatrix var58 = var26.subtract((org.apache.commons.math.linear.RealMatrix)var56);
//     double[] var60 = var26.getColumn(0);
//     org.apache.commons.math.linear.BlockRealMatrix var61 = var15.multiply((org.apache.commons.math.linear.RealMatrix)var26);
//     org.apache.commons.math.linear.BlockRealMatrix var62 = var61.copy();
//     org.apache.commons.math.linear.RealMatrixPreservingVisitor var63 = null;
//     double var64 = var61.walkInRowOrder(var63);
// 
//   }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test28"); }


    org.apache.commons.math.ode.events.EventHandler var1 = null;
    org.apache.commons.math.ode.events.EventState var5 = new org.apache.commons.math.ode.events.EventState(var1, 0.0d, 100.0d, 10);
    double[] var9 = new double[] { 1.0d, 1.0d};
    boolean var10 = var5.reset((-1.0d), var9);
    double[][] var11 = new double[][] { var9};
    double[][] var12 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var11);
    org.apache.commons.math.linear.BigMatrix var13 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(var12);
    java.lang.IllegalArgumentException var14 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", (java.lang.Object[])var12);
    org.apache.commons.math.linear.BlockRealMatrix var15 = new org.apache.commons.math.linear.BlockRealMatrix(var12);
    java.lang.Object var16 = null;
    boolean var17 = var15.equals(var16);
    int var18 = var15.getRowDimension();
    org.apache.commons.math.ode.events.EventHandler var20 = null;
    org.apache.commons.math.ode.events.EventState var24 = new org.apache.commons.math.ode.events.EventState(var20, 0.0d, 100.0d, 10);
    double[] var28 = new double[] { 1.0d, 1.0d};
    boolean var29 = var24.reset((-1.0d), var28);
    double[][] var30 = new double[][] { var28};
    double[][] var31 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var30);
    org.apache.commons.math.linear.BigMatrix var32 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(var31);
    java.lang.IllegalArgumentException var33 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", (java.lang.Object[])var31);
    org.apache.commons.math.linear.BlockRealMatrix var34 = new org.apache.commons.math.linear.BlockRealMatrix(var31);
    java.lang.Object var35 = null;
    boolean var36 = var34.equals(var35);
    int var37 = var34.getRowDimension();
    org.apache.commons.math.linear.BlockRealMatrix var38 = var15.subtract((org.apache.commons.math.linear.RealMatrix)var34);
    org.apache.commons.math.linear.BlockRealMatrix var39 = var38.copy();
    boolean var40 = var39.isSquare();
    org.apache.commons.math.linear.BlockRealMatrix var43 = var39.createMatrix(1, 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test29"); }


    org.apache.commons.math.ode.events.EventHandler var1 = null;
    org.apache.commons.math.ode.events.EventState var5 = new org.apache.commons.math.ode.events.EventState(var1, 0.0d, 100.0d, 10);
    double[] var9 = new double[] { 1.0d, 1.0d};
    boolean var10 = var5.reset((-1.0d), var9);
    double[][] var11 = new double[][] { var9};
    double[][] var12 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var11);
    org.apache.commons.math.linear.BigMatrix var13 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(var12);
    java.lang.IllegalArgumentException var14 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", (java.lang.Object[])var12);
    org.apache.commons.math.linear.BlockRealMatrix var15 = new org.apache.commons.math.linear.BlockRealMatrix(var12);
    java.lang.Object var16 = null;
    boolean var17 = var15.equals(var16);
    int var18 = var15.getRowDimension();
    org.apache.commons.math.ode.events.EventHandler var20 = null;
    org.apache.commons.math.ode.events.EventState var24 = new org.apache.commons.math.ode.events.EventState(var20, 0.0d, 100.0d, 10);
    double[] var28 = new double[] { 1.0d, 1.0d};
    boolean var29 = var24.reset((-1.0d), var28);
    double[][] var30 = new double[][] { var28};
    double[][] var31 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var30);
    org.apache.commons.math.linear.BigMatrix var32 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(var31);
    java.lang.IllegalArgumentException var33 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", (java.lang.Object[])var31);
    org.apache.commons.math.linear.BlockRealMatrix var34 = new org.apache.commons.math.linear.BlockRealMatrix(var31);
    java.lang.Object var35 = null;
    boolean var36 = var34.equals(var35);
    int var37 = var34.getRowDimension();
    org.apache.commons.math.linear.BlockRealMatrix var38 = var15.subtract((org.apache.commons.math.linear.RealMatrix)var34);
    org.apache.commons.math.linear.BlockRealMatrix var39 = var38.copy();
    org.apache.commons.math.linear.BlockRealMatrix var41 = var39.scalarAdd(10.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math.linear.RealVector var43 = var39.getColumnVector(10);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test30() {}
//   public void test30() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest12.test30"); }
// 
// 
//     org.apache.commons.math.fraction.BigFraction var2 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(2, 100);
//     org.apache.commons.math.fraction.BigFraction var5 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(2, 100);
//     org.apache.commons.math.fraction.BigFraction var6 = var2.divide(var5);
//     org.apache.commons.math.FieldElement[] var7 = new org.apache.commons.math.FieldElement[] { var5};
//     org.apache.commons.math.linear.FieldVector var8 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var7);
//     org.apache.commons.math.linear.FieldMatrix var9 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createRowFieldMatrix(var7);
//     org.apache.commons.math.linear.Array2DRowFieldMatrix var10 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var7);
//     org.apache.commons.math.fraction.BigFraction var13 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(2, 100);
//     org.apache.commons.math.fraction.BigFraction var16 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(2, 100);
//     org.apache.commons.math.fraction.BigFraction var17 = var13.divide(var16);
//     org.apache.commons.math.FieldElement[] var18 = new org.apache.commons.math.FieldElement[] { var16};
//     org.apache.commons.math.linear.FieldVector var19 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var18);
//     org.apache.commons.math.linear.FieldMatrix var20 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createRowFieldMatrix(var18);
//     org.apache.commons.math.linear.Array2DRowFieldMatrix var21 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var18);
//     org.apache.commons.math.linear.Array2DRowFieldMatrix var22 = var10.add(var21);
//     org.apache.commons.math.fraction.BigFraction var25 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(2, 100);
//     org.apache.commons.math.fraction.BigFraction var28 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(2, 100);
//     org.apache.commons.math.fraction.BigFraction var29 = var25.divide(var28);
//     org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var30 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var29);
//     org.apache.commons.math.FieldElement var31 = var22.walkInColumnOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var30);
//     org.apache.commons.math.linear.FieldMatrix var32 = null;
//     org.apache.commons.math.linear.FieldMatrix var33 = var22.multiply(var32);
// 
//   }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test31"); }


    org.apache.commons.math.ode.events.EventHandler var3 = null;
    org.apache.commons.math.ode.events.EventState var7 = new org.apache.commons.math.ode.events.EventState(var3, 0.0d, 100.0d, 10);
    double[] var11 = new double[] { 1.0d, 1.0d};
    boolean var12 = var7.reset((-1.0d), var11);
    org.apache.commons.math.ode.events.EventHandler var13 = var7.getEventHandler();
    org.apache.commons.math.ode.events.EventHandler var15 = null;
    org.apache.commons.math.ode.events.EventState var19 = new org.apache.commons.math.ode.events.EventState(var15, 0.0d, 100.0d, 10);
    double[] var23 = new double[] { 1.0d, 1.0d};
    boolean var24 = var19.reset((-1.0d), var23);
    org.apache.commons.math.ode.events.EventHandler var25 = var19.getEventHandler();
    double[] var28 = new double[] { 0.0d};
    boolean var29 = var19.reset(0.0d, var28);
    boolean var30 = var7.reset(10.0d, var28);
    org.apache.commons.math.ode.events.EventHandler var31 = null;
    org.apache.commons.math.ode.events.EventState var35 = new org.apache.commons.math.ode.events.EventState(var31, 0.0d, 100.0d, 10);
    double[] var39 = new double[] { 1.0d, 1.0d};
    boolean var40 = var35.reset((-1.0d), var39);
    org.apache.commons.math.ode.events.EventHandler var41 = var35.getEventHandler();
    org.apache.commons.math.ode.events.EventHandler var43 = null;
    org.apache.commons.math.ode.events.EventState var47 = new org.apache.commons.math.ode.events.EventState(var43, 0.0d, 100.0d, 10);
    double[] var51 = new double[] { 1.0d, 1.0d};
    boolean var52 = var47.reset((-1.0d), var51);
    org.apache.commons.math.ode.events.EventHandler var53 = var47.getEventHandler();
    double[] var56 = new double[] { 0.0d};
    boolean var57 = var47.reset(0.0d, var56);
    boolean var58 = var35.reset(10.0d, var56);
    org.apache.commons.math.linear.RealMatrix var59 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(var56);
    org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var60 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(2, (-0.02d), 10.0d, var28, var56);
    int var61 = var60.getEvaluations();
    var60.clearStepHandlers();
    org.apache.commons.math.ode.events.EventHandler var63 = null;
    var60.addEventHandler(var63, 1.2599210498948732d, 1.2599210498948732d, 2);
    org.apache.commons.math.ode.events.EventHandler var69 = null;
    org.apache.commons.math.ode.events.EventState var73 = new org.apache.commons.math.ode.events.EventState(var69, 0.0d, 100.0d, 10);
    double[] var77 = new double[] { 1.0d, 1.0d};
    boolean var78 = var73.reset((-1.0d), var77);
    double[][] var79 = new double[][] { var77};
    double[][] var80 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var79);
    java.lang.NullPointerException var81 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[])var79);
    org.apache.commons.math.linear.Array2DRowRealMatrix var83 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var79, false);
    org.apache.commons.math.linear.RealMatrix var85 = var83.scalarAdd(100.0d);
    java.lang.Object[] var88 = new java.lang.Object[] { 0.0d};
    org.apache.commons.math.linear.MatrixIndexException var89 = new org.apache.commons.math.linear.MatrixIndexException("hi!", var88);
    java.lang.IllegalArgumentException var90 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((java.lang.Throwable)var89);
    double[] var93 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.linear.RealMatrix var94 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(var93);
    org.apache.commons.math.FunctionEvaluationException var95 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable)var90, var93);
    org.apache.commons.math.linear.Array2DRowRealMatrix var96 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var93);
    org.apache.commons.math.linear.Array2DRowRealMatrix var97 = var83.multiply(var96);
    org.apache.commons.math.linear.Array2DRowRealMatrix var98 = var60.updateHighOrderDerivativesPhase1(var96);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var93);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var97);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var98);

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test32"); }


    org.apache.commons.math.ode.events.EventHandler var1 = null;
    org.apache.commons.math.ode.events.EventState var5 = new org.apache.commons.math.ode.events.EventState(var1, 0.0d, 100.0d, 10);
    double[] var9 = new double[] { 1.0d, 1.0d};
    boolean var10 = var5.reset((-1.0d), var9);
    double[][] var11 = new double[][] { var9};
    double[][] var12 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var11);
    java.lang.NullPointerException var13 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[])var11);
    org.apache.commons.math.linear.Array2DRowRealMatrix var15 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var11, false);
    org.apache.commons.math.linear.RealMatrix var17 = var15.scalarAdd(100.0d);
    java.lang.Object[] var20 = new java.lang.Object[] { 0.0d};
    org.apache.commons.math.linear.MatrixIndexException var21 = new org.apache.commons.math.linear.MatrixIndexException("hi!", var20);
    java.lang.IllegalArgumentException var22 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((java.lang.Throwable)var21);
    double[] var25 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.linear.RealMatrix var26 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(var25);
    org.apache.commons.math.FunctionEvaluationException var27 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable)var22, var25);
    org.apache.commons.math.linear.Array2DRowRealMatrix var28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var25);
    int var29 = var28.getColumnDimension();
    org.apache.commons.math.ode.events.EventHandler var31 = null;
    org.apache.commons.math.ode.events.EventState var35 = new org.apache.commons.math.ode.events.EventState(var31, 0.0d, 100.0d, 10);
    double[] var39 = new double[] { 1.0d, 1.0d};
    boolean var40 = var35.reset((-1.0d), var39);
    double[][] var41 = new double[][] { var39};
    double[][] var42 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var41);
    java.lang.NullPointerException var43 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[])var41);
    org.apache.commons.math.linear.Array2DRowRealMatrix var45 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var41, false);
    org.apache.commons.math.linear.RealMatrix var47 = var45.scalarAdd(100.0d);
    java.lang.Object[] var50 = new java.lang.Object[] { 0.0d};
    org.apache.commons.math.linear.MatrixIndexException var51 = new org.apache.commons.math.linear.MatrixIndexException("hi!", var50);
    java.lang.IllegalArgumentException var52 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((java.lang.Throwable)var51);
    double[] var55 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.linear.RealMatrix var56 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(var55);
    org.apache.commons.math.FunctionEvaluationException var57 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable)var52, var55);
    org.apache.commons.math.linear.Array2DRowRealMatrix var58 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var55);
    org.apache.commons.math.linear.Array2DRowRealMatrix var59 = var45.multiply(var58);
    org.apache.commons.math.linear.RealMatrix var60 = var28.subtract((org.apache.commons.math.linear.RealMatrix)var58);
    org.apache.commons.math.linear.Array2DRowRealMatrix var61 = var15.multiply(var58);
    org.apache.commons.math.ode.events.EventHandler var63 = null;
    org.apache.commons.math.ode.events.EventState var67 = new org.apache.commons.math.ode.events.EventState(var63, 0.0d, 100.0d, 10);
    double[] var71 = new double[] { 1.0d, 1.0d};
    boolean var72 = var67.reset((-1.0d), var71);
    double[][] var73 = new double[][] { var71};
    double[][] var74 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var73);
    java.lang.NullPointerException var75 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[])var73);
    org.apache.commons.math.linear.Array2DRowRealMatrix var77 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var73, false);
    boolean var79 = var77.equals((java.lang.Object)100L);
    org.apache.commons.math.linear.RealMatrix var80 = var61.multiply((org.apache.commons.math.linear.RealMatrix)var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test33"); }


    org.apache.commons.math.fraction.BigFraction var2 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(2, 100);
    org.apache.commons.math.fraction.BigFraction var4 = var2.multiply((-1));
    double var5 = var2.doubleValue();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var6 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var2);
    var6.start((-1), 10, 2, 1, 10, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.02d);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test34"); }


    org.apache.commons.math.ode.events.EventHandler var0 = null;
    org.apache.commons.math.ode.events.EventState var4 = new org.apache.commons.math.ode.events.EventState(var0, 0.0d, 100.0d, 10);
    double[] var8 = new double[] { 1.0d, 1.0d};
    boolean var9 = var4.reset((-1.0d), var8);
    org.apache.commons.math.ode.events.EventHandler var10 = var4.getEventHandler();
    org.apache.commons.math.ode.events.EventHandler var12 = null;
    org.apache.commons.math.ode.events.EventState var16 = new org.apache.commons.math.ode.events.EventState(var12, 0.0d, 100.0d, 10);
    double[] var20 = new double[] { 1.0d, 1.0d};
    boolean var21 = var16.reset((-1.0d), var20);
    org.apache.commons.math.ode.events.EventHandler var22 = var16.getEventHandler();
    double[] var25 = new double[] { 0.0d};
    boolean var26 = var16.reset(0.0d, var25);
    boolean var27 = var4.reset(10.0d, var25);
    int var28 = var4.getMaxIterationCount();
    boolean var29 = var4.stop();
    boolean var30 = var4.stop();
    org.apache.commons.math.ode.events.EventHandler var31 = var4.getEventHandler();
    boolean var32 = var4.stop();
    boolean var33 = var4.stop();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test35"); }


    org.apache.commons.math.ode.events.EventHandler var1 = null;
    org.apache.commons.math.ode.events.EventState var5 = new org.apache.commons.math.ode.events.EventState(var1, 0.0d, 100.0d, 10);
    double[] var9 = new double[] { 1.0d, 1.0d};
    boolean var10 = var5.reset((-1.0d), var9);
    double[][] var11 = new double[][] { var9};
    double[][] var12 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var11);
    java.lang.NullPointerException var13 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[])var11);
    org.apache.commons.math.linear.Array2DRowRealMatrix var15 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var11, false);
    org.apache.commons.math.linear.BigMatrix var16 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(var11);
    org.apache.commons.math.ode.events.EventHandler var18 = null;
    org.apache.commons.math.ode.events.EventState var22 = new org.apache.commons.math.ode.events.EventState(var18, 0.0d, 100.0d, 10);
    double[] var26 = new double[] { 1.0d, 1.0d};
    boolean var27 = var22.reset((-1.0d), var26);
    double[][] var28 = new double[][] { var26};
    double[][] var29 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var28);
    java.lang.NullPointerException var30 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[])var28);
    org.apache.commons.math.linear.Array2DRowRealMatrix var32 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var28, false);
    boolean var34 = var32.equals((java.lang.Object)100L);
    org.apache.commons.math.ode.events.EventHandler var36 = null;
    org.apache.commons.math.ode.events.EventState var40 = new org.apache.commons.math.ode.events.EventState(var36, 0.0d, 100.0d, 10);
    double[] var44 = new double[] { 1.0d, 1.0d};
    boolean var45 = var40.reset((-1.0d), var44);
    double[][] var46 = new double[][] { var44};
    double[][] var47 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var46);
    java.lang.NullPointerException var48 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[])var46);
    org.apache.commons.math.linear.Array2DRowRealMatrix var50 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var46, false);
    org.apache.commons.math.linear.Array2DRowRealMatrix var51 = var32.subtract(var50);
    org.apache.commons.math.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math.linear.AnyMatrix)var16, (org.apache.commons.math.linear.AnyMatrix)var50);
    java.lang.Object[] var56 = new java.lang.Object[] { 0.0d};
    org.apache.commons.math.linear.MatrixIndexException var57 = new org.apache.commons.math.linear.MatrixIndexException("hi!", var56);
    java.lang.IllegalArgumentException var58 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((java.lang.Throwable)var57);
    double[] var61 = new double[] { (-1.0d), 0.0d};
    org.apache.commons.math.linear.RealMatrix var62 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(var61);
    org.apache.commons.math.FunctionEvaluationException var63 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable)var58, var61);
    org.apache.commons.math.linear.Array2DRowRealMatrix var64 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var61);
    org.apache.commons.math.linear.BigMatrix var65 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(var61);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var50.setColumn(0, var61);
      fail("Expected exception of type org.apache.commons.math.linear.InvalidMatrixException");
    } catch (org.apache.commons.math.linear.InvalidMatrixException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test36"); }


    org.apache.commons.math.ode.events.EventHandler var2 = null;
    org.apache.commons.math.ode.events.EventState var6 = new org.apache.commons.math.ode.events.EventState(var2, 0.0d, 100.0d, 10);
    double[] var10 = new double[] { 1.0d, 1.0d};
    boolean var11 = var6.reset((-1.0d), var10);
    org.apache.commons.math.ode.events.EventHandler var12 = var6.getEventHandler();
    double[] var15 = new double[] { 0.0d};
    boolean var16 = var6.reset(0.0d, var15);
    org.apache.commons.math.ode.events.EventHandler var20 = null;
    org.apache.commons.math.ode.events.EventState var24 = new org.apache.commons.math.ode.events.EventState(var20, 0.0d, 100.0d, 10);
    double[] var28 = new double[] { 1.0d, 1.0d};
    boolean var29 = var24.reset((-1.0d), var28);
    org.apache.commons.math.ode.events.EventHandler var30 = var24.getEventHandler();
    org.apache.commons.math.ode.events.EventHandler var32 = null;
    org.apache.commons.math.ode.events.EventState var36 = new org.apache.commons.math.ode.events.EventState(var32, 0.0d, 100.0d, 10);
    double[] var40 = new double[] { 1.0d, 1.0d};
    boolean var41 = var36.reset((-1.0d), var40);
    org.apache.commons.math.ode.events.EventHandler var42 = var36.getEventHandler();
    double[] var45 = new double[] { 0.0d};
    boolean var46 = var36.reset(0.0d, var45);
    boolean var47 = var24.reset(10.0d, var45);
    org.apache.commons.math.ode.events.EventHandler var48 = null;
    org.apache.commons.math.ode.events.EventState var52 = new org.apache.commons.math.ode.events.EventState(var48, 0.0d, 100.0d, 10);
    double[] var56 = new double[] { 1.0d, 1.0d};
    boolean var57 = var52.reset((-1.0d), var56);
    org.apache.commons.math.ode.events.EventHandler var58 = var52.getEventHandler();
    org.apache.commons.math.ode.events.EventHandler var60 = null;
    org.apache.commons.math.ode.events.EventState var64 = new org.apache.commons.math.ode.events.EventState(var60, 0.0d, 100.0d, 10);
    double[] var68 = new double[] { 1.0d, 1.0d};
    boolean var69 = var64.reset((-1.0d), var68);
    org.apache.commons.math.ode.events.EventHandler var70 = var64.getEventHandler();
    double[] var73 = new double[] { 0.0d};
    boolean var74 = var64.reset(0.0d, var73);
    boolean var75 = var52.reset(10.0d, var73);
    org.apache.commons.math.linear.RealMatrix var76 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(var73);
    org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var77 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(2, (-0.02d), 10.0d, var45, var73);
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var78 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(1.0d, 1.0d, var15, var73);
    var78.setSafety((-1.0d));
    double var81 = var78.getMinReduction();
    java.lang.String var82 = var78.getName();
    var78.setMinReduction(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var82 + "' != '" + "Dormand-Prince 8 (5, 3)"+ "'", var82.equals("Dormand-Prince 8 (5, 3)"));

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest12.test37"); }


    org.apache.commons.math.ode.events.EventHandler var0 = null;
    org.apache.commons.math.ode.events.EventState var4 = new org.apache.commons.math.ode.events.EventState(var0, 0.0d, 100.0d, 10);
    double[] var8 = new double[] { 1.0d, 1.0d};
    boolean var9 = var4.reset((-1.0d), var8);
    org.apache.commons.math.ode.events.EventHandler var10 = var4.getEventHandler();
    org.apache.commons.math.ode.events.EventHandler var12 = null;
    org.apache.commons.math.ode.events.EventState var16 = new org.apache.commons.math.ode.events.EventState(var12, 0.0d, 100.0d, 10);
    double[] var20 = new double[] { 1.0d, 1.0d};
    boolean var21 = var16.reset((-1.0d), var20);
    org.apache.commons.math.ode.events.EventHandler var22 = var16.getEventHandler();
    double[] var25 = new double[] { 0.0d};
    boolean var26 = var16.reset(0.0d, var25);
    boolean var27 = var4.reset(10.0d, var25);
    org.apache.commons.math.linear.RealMatrix var28 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(var25);
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var30 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var25, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

}
