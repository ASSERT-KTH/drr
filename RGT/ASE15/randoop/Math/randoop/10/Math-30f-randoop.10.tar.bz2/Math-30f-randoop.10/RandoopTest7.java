
import junit.framework.*;

public class RandoopTest7 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test1"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter((-10.0f), 79.78575355161972d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-9.999999f));

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test2"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(206, (-394));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 206);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test3"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos((-4.440892098500626E-16d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test4"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(447, 31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 13857);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test5"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    int var3 = var2.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var6.getNanStrategy();
    java.lang.Class var8 = var7.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.TiesStrategy var10 = var9.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var10);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var12 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var14 = var13.getNumElements();
    double[] var15 = var13.getInternalValues();
    double[] var18 = new double[] { 10.0d, 100.0d};
    double var19 = var12.mannWhitneyU(var15, var18);
    double[] var20 = var11.rank(var18);
    org.apache.commons.math3.util.ResizableDoubleArray var21 = new org.apache.commons.math3.util.ResizableDoubleArray(var20);
    org.apache.commons.math3.util.ResizableDoubleArray var22 = new org.apache.commons.math3.util.ResizableDoubleArray(var20);
    boolean var24 = var22.equals((java.lang.Object)3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test6"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians((-0.5961722400471148d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.010405168497812147d));

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test7"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getMean();
    double var4 = var0.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
    double var5 = var0.getSupportUpperBound();
    double var7 = var0.density(29.9749466411613d);
    double var9 = var0.density(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.5230558330643571d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 3.123726322776123E-196d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.3989422804014327d);

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test8"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(0.9060315826437655d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9518569129043322d);

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test9"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    int var3 = var2.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var6.getNanStrategy();
    int var8 = var7.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.TiesStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.NaNStrategy var12 = var11.getNanStrategy();
    java.lang.Class var13 = var12.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12);
    org.apache.commons.math3.stat.ranking.TiesStrategy var15 = var14.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7, var15);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var17 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var15);
    org.apache.commons.math3.stat.ranking.TiesStrategy var18 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var18);
    org.apache.commons.math3.stat.ranking.NaNStrategy var20 = var19.getNanStrategy();
    java.lang.Class var21 = var20.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20);
    org.apache.commons.math3.stat.ranking.TiesStrategy var23 = var22.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var23);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var25 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var23);
    org.apache.commons.math3.random.RandomGenerator var26 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var27 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var26);
    org.apache.commons.math3.stat.ranking.NaNStrategy var28 = var27.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var29 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var30 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var28, var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test10"); }


    double var1 = org.apache.commons.math3.special.Gamma.logGamma(0.9999791546489307d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2032620566593266E-5d);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test11"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(0.9907234974617702d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 56.76427506899936d);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test12"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var2 = var1.getNumElements();
    double[] var3 = var1.getInternalValues();
    double[] var6 = new double[] { 10.0d, 100.0d};
    double var7 = var0.mannWhitneyU(var3, var6);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    double var10 = var8.substituteMostRecentElement(2.9690791410915276d);
    double[] var11 = var8.getElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var8.setNumElements(1037420971);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test13"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getNumericalMean();
    double var2 = var0.getStandardDeviation();
    boolean var3 = var0.isSupportLowerBoundInclusive();
    double var4 = var0.getSupportLowerBound();
    double var5 = var0.getSupportLowerBound();
    var0.reseedRandomGenerator(0L);
    double var9 = var0.density(115.65804595436055d);
    double var10 = var0.getStandardDeviation();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1.0d);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test14"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var1 = null;
    org.apache.commons.math3.exception.MathArithmeticException var2 = new org.apache.commons.math3.exception.MathArithmeticException(var0, var1);
    java.lang.Throwable[] var3 = var2.getSuppressed();
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var2.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test15"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(21.05069186828042d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.3873924239356105E9d);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test16"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(0.9989387098899101d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 57.23497206893519d);

  }

  public void test17() {}
//   public void test17() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test17"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure(10L);
//     long var10 = var1.nextSecureLong(10L, 10000000000L);
//     java.lang.String var12 = var1.nextHexString(66475);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1893278121L);
// 
//   }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test18"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("16351b");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test19() {}
//   public void test19() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test19"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure(10L);
//     long var10 = var1.nextSecureLong(10L, 10000000000L);
//     double var13 = var1.nextUniform(0.9999943487368532d, 44.5140274520795d);
//     var1.reSeed(6966596131L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("99fdf095b2091ca7d1e2a711d09cf4c68b280156a8abaa3a5fa84026ddc0a1d37064c5980ec0d76793eb24682a2019fa2c29586ed7e0b4cb92476b00b55d86cb1e281503d9ffb994d05644e63462f6c4c18c6efa0e878754de83e1f7f18b68b314b9e8d8ed2be4d3c9ea449fcc045dae81239893b9f7e2ded54c3ecace23408f73404e3d5b6b9172ca2a51217cab5766cb2b143eb46d6047678cb0bb6ccf7b1c8b608073a08bfdf20442e767202d58ff2e0a23c29786883714abd1308d3a8d3980daf121c71ee771930506ff815bfa92eb4085eefe31df6ed25a0cdd49a1b1eaf697d95174645d49e325f52e06d2fd36632107417e3b7975157c", "7c6cd26be7640dfa4acf19ee5fac6a598cb6a2a1609ecb8a6eac89e62a69e2798f1e703433abd7f6798174bdade40550883051a3df83bb2d40500f148fd6c6f1965c05cedab947e3f643eab469cc067ebaa5145669977ee6b1da874d478ee9d9fec7457e6c614808cdef312d6635ac1b8d74bfd62faf1dd6ecf3c94e6d40eb9002926b508850d0bb550ca2fcd98af42dacf6975d79ecf595d881d50d0e095e95fc340e456ec0eb8e7149f0bf3e9adb7b86262b5e2d6c6217b0cd062ebaf303c2a92605e678fce7a3d8fcc7279ee9d96cbcf9015cbed7645e24c8826cb2fa6924a5e16e76e5453326e30054e81c10ec026291a187092e05b92802");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5581838676L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 10.866389558360387d);
// 
//   }

  public void test20() {}
//   public void test20() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test20"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     double var7 = var1.nextExponential(24.0d);
//     long var10 = var1.nextLong(0L, 10000000000L);
//     double var12 = var1.nextT(0.0010774392745906561d);
//     double var15 = var1.nextBeta(1.4615016373309029E48d, 1.82442736154459d);
//     double var18 = var1.nextGamma(31.19644594989976d, 0.6227605565158021d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var21 = var1.nextF(1.7912222223977756d, (-0.0010738361330276734d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 71.78366778374973d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 3042885533L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-1.3407807929942597E154d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.9999999981887272d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 20.932881529278863d);
// 
//   }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test21"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(0.0d, 1.290984120044901d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test22"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(1966771617, 124952017);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 124952017);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test23"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var2 = var0.addElementRolling(Double.NaN);
    var0.setNumElements(0);
    var0.contract();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var6 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var7 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var10 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var11 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var13 = var12.getNumElements();
    double[] var14 = var12.getInternalValues();
    double[] var17 = new double[] { 10.0d, 100.0d};
    double var18 = var11.mannWhitneyU(var14, var17);
    org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    double var20 = var7.mannWhitneyU(var10, var14);
    double[] var24 = new double[] { 100.0d, 1.0d, 100.0d};
    double var25 = var6.mannWhitneyU(var10, var24);
    var0.addElements(var24);
    double[] var27 = var0.getInternalValues();
    var0.addElement(0.13463348377254322d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test24() {}
//   public void test24() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test24"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure(10L);
//     long var10 = var1.nextSecureLong(10L, 10000000000L);
//     double var12 = var1.nextChiSquare(0.001736111111111111d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var14 = var1.nextHexString((-1023));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 7336976811L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1.902230568658181E-9d);
// 
//   }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test25"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(3685573673L, 6813564118L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test26"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(0L, 4298531835L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test27"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(0.6381781975339198d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.011138310761409658d);

  }

  public void test28() {}
//   public void test28() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test28"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy var1 = null;
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var2 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var1);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var3 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var5 = var4.getNanStrategy();
//     int var6 = var5.ordinal();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var7 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var9 = var8.getNanStrategy();
//     java.lang.Class var10 = var9.getDeclaringClass();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var9);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var12 = var11.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var13 = var11.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var14 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var14);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var16 = var15.getNanStrategy();
//     int var17 = var16.ordinal();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var16);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var19 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var19);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var21 = var20.getNanStrategy();
//     java.lang.Class var22 = var21.getDeclaringClass();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var21);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var24 = var23.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var25 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var16, var24);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var26 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var13, var24);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var27 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5, var24);
//     java.lang.String var28 = var24.name();
//     java.lang.String var29 = var24.name();
//     java.lang.String var30 = var24.toString();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var31 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var24);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var32 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var33 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var32);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var34 = var33.getNanStrategy();
//     java.lang.String var35 = var34.name();
//     org.apache.commons.math3.random.RandomGenerator var36 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var37 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var36);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var38 = var37.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var39 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var38);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var40 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var34, var38);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var41 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var42 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var41);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var43 = var42.getNanStrategy();
//     int var44 = var43.ordinal();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var45 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var43);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var46 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var47 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var46);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var48 = var47.getNanStrategy();
//     java.lang.Class var49 = var48.getDeclaringClass();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var50 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var48);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var51 = var50.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var52 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var43, var51);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var53 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     org.apache.commons.math3.util.ResizableDoubleArray var54 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     int var55 = var54.getNumElements();
//     double[] var56 = var54.getInternalValues();
//     double[] var59 = new double[] { 10.0d, 100.0d};
//     double var60 = var53.mannWhitneyU(var56, var59);
//     double[] var61 = var52.rank(var59);
//     double[] var62 = var40.rank(var61);
//     double[] var63 = var31.rank(var61);
//     org.apache.commons.math3.util.ResizableDoubleArray var64 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     int var65 = var64.getNumElements();
//     double[] var66 = var64.getInternalValues();
//     var64.clear();
//     double[] var68 = var64.getInternalValues();
//     double var69 = var2.mannWhitneyU(var61, var68);
// 
//   }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test29"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(95455, (-1096480911));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1096480911));

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test30"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.0d, 1.3407807929942259E154d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.3407807929942259E154d);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test31"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)5);

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test32"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, var1, (java.lang.Number)12.368444582022025d, (java.lang.Number)2.882619330995207E-19d);
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test33"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(1.3021540485344858d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0797637222694514d);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test34"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(85119429, (-47515));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test35() {}
//   public void test35() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test35"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextBeta(572.2646479502633d, 0.07637989519631011d);
//     double var8 = var1.nextGamma(4.937302184657956d, 97.98819663162894d);
//     var1.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var1.nextHypergeometric(1222826114, (-1023), 10230);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 387.2365955990128d);
// 
//   }

  public void test36() {}
//   public void test36() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test36"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextWeibull(100.0d, 100.0d);
//     var1.reSeedSecure();
//     double var9 = var1.nextGamma(1.065175436767987d, 2.6498507619080125d);
//     int var12 = var1.nextZipf(3, 0.949950589504148d);
//     var1.reSeedSecure();
//     double var16 = var1.nextCauchy(0.0d, 0.5637033385775058d);
//     double var18 = var1.nextExponential(1.9117361753569404d);
//     double var20 = var1.nextChiSquare(4.477465921704087d);
//     int var23 = var1.nextSecureInt((-2147483648), (-1079733669));
//     int var26 = var1.nextInt(3, 16938270);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 99.08343765999427d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2.6605288489275627d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == (-3.2553434679543276d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.7801539173233952d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 4.085393069481363d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == (-1523011736));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 13588520);
// 
//   }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test37"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.5458066324533806d), 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test38() {}
//   public void test38() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test38"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure();
//     int var9 = var1.nextInt((-15), 500);
//     double var12 = var1.nextBeta(98.00138274241472d, 0.9984187364052811d);
//     double var15 = var1.nextUniform(4.61512051684126d, 57.348154628338996d);
//     double var17 = var1.nextChiSquare(6.667362175119546d);
//     var1.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-12));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.9860696035868222d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 28.11269684646181d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 9.828351851281225d);
// 
//   }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test39"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs((-1.5578270843725532d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5578270843725532d);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test40"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.3718501355904625d, (-1.2966581127618215d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.3489235651917768d);

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test41"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.discardFrontElements(0);
    int var3 = var0.getExpansionMode();
    int var4 = var0.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test42"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var2 = var0.density(100.0d);
    double var5 = var0.cumulativeProbability((-2.450405938642638d), 0.6139648708421599d);
    double[] var7 = var0.sample(100);
    double var8 = var0.getStandardDeviation();
    boolean var9 = var0.isSupportUpperBoundInclusive();
    var0.reseedRandomGenerator(1L);
    boolean var12 = var0.isSupportUpperBoundInclusive();
    double var13 = var0.getMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.723245967437971d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test43"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh((-0.49062916172540627d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.5105512298259982d));

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test44"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(0, 53);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test45"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var2 = var0.density(100.0d);
    double var5 = var0.cumulativeProbability((-2.450405938642638d), 0.6139648708421599d);
    double[] var7 = var0.sample(100);
    double var8 = var0.getStandardDeviation();
    boolean var9 = var0.isSupportUpperBoundInclusive();
    var0.reseedRandomGenerator(1L);
    boolean var12 = var0.isSupportLowerBoundInclusive();
    double var13 = var0.getNumericalMean();
    double var14 = var0.getSupportLowerBound();
    boolean var15 = var0.isSupportLowerBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.723245967437971d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test46"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getNumericalMean();
    double var3 = var0.cumulativeProbability(2.5242623302161973d);
    boolean var4 = var0.isSupportLowerBoundInclusive();
    double var5 = var0.getNumericalMean();
    var0.reseedRandomGenerator(6L);
    double var9 = var0.probability(0.49667587767028903d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9942029313130951d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test47"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(-0.057824611452708244d));

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test48"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 9617852649L);
    java.math.BigInteger var5 = null;
    java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 0L);
    java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, 9617852649L);
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, var7);
    org.apache.commons.math3.exception.util.Localizable var11 = null;
    java.math.BigInteger var12 = null;
    java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, 0L);
    java.math.BigInteger var16 = org.apache.commons.math3.util.ArithmeticUtils.pow(var14, 9617852649L);
    java.math.BigInteger var17 = null;
    java.math.BigInteger var19 = org.apache.commons.math3.util.ArithmeticUtils.pow(var17, 0L);
    java.math.BigInteger var21 = org.apache.commons.math3.util.ArithmeticUtils.pow(var19, 9617852649L);
    java.math.BigInteger var22 = org.apache.commons.math3.util.ArithmeticUtils.pow(var16, var19);
    java.math.BigInteger var24 = org.apache.commons.math3.util.ArithmeticUtils.pow(var16, 2147483647);
    java.math.BigInteger var26 = org.apache.commons.math3.util.ArithmeticUtils.pow(var24, 6949188755L);
    java.lang.Number var27 = null;
    org.apache.commons.math3.exception.OutOfRangeException var29 = new org.apache.commons.math3.exception.OutOfRangeException(var11, (java.lang.Number)var26, var27, (java.lang.Number)9.332621544395286E157d);
    java.math.BigInteger var31 = org.apache.commons.math3.util.ArithmeticUtils.pow(var26, 0L);
    java.math.BigInteger var33 = org.apache.commons.math3.util.ArithmeticUtils.pow(var26, 208);
    java.math.BigInteger var34 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, var33);
    java.math.BigInteger var35 = null;
    java.math.BigInteger var37 = org.apache.commons.math3.util.ArithmeticUtils.pow(var35, 0L);
    java.math.BigInteger var39 = org.apache.commons.math3.util.ArithmeticUtils.pow(var37, 9617852649L);
    java.math.BigInteger var40 = null;
    java.math.BigInteger var42 = org.apache.commons.math3.util.ArithmeticUtils.pow(var40, 0L);
    java.math.BigInteger var44 = org.apache.commons.math3.util.ArithmeticUtils.pow(var42, 9617852649L);
    java.math.BigInteger var45 = org.apache.commons.math3.util.ArithmeticUtils.pow(var39, var42);
    org.apache.commons.math3.exception.util.Localizable var46 = null;
    java.math.BigInteger var47 = null;
    java.math.BigInteger var49 = org.apache.commons.math3.util.ArithmeticUtils.pow(var47, 0L);
    java.math.BigInteger var51 = org.apache.commons.math3.util.ArithmeticUtils.pow(var49, 9617852649L);
    java.math.BigInteger var52 = null;
    java.math.BigInteger var54 = org.apache.commons.math3.util.ArithmeticUtils.pow(var52, 0L);
    java.math.BigInteger var56 = org.apache.commons.math3.util.ArithmeticUtils.pow(var54, 9617852649L);
    java.math.BigInteger var57 = org.apache.commons.math3.util.ArithmeticUtils.pow(var51, var54);
    java.math.BigInteger var59 = org.apache.commons.math3.util.ArithmeticUtils.pow(var51, 2147483647);
    java.math.BigInteger var61 = org.apache.commons.math3.util.ArithmeticUtils.pow(var59, 6949188755L);
    java.lang.Number var62 = null;
    org.apache.commons.math3.exception.OutOfRangeException var64 = new org.apache.commons.math3.exception.OutOfRangeException(var46, (java.lang.Number)var61, var62, (java.lang.Number)9.332621544395286E157d);
    java.math.BigInteger var66 = org.apache.commons.math3.util.ArithmeticUtils.pow(var61, 0L);
    java.math.BigInteger var67 = org.apache.commons.math3.util.ArithmeticUtils.pow(var39, var66);
    java.math.BigInteger var68 = org.apache.commons.math3.util.ArithmeticUtils.pow(var33, var39);
    java.math.BigInteger var70 = org.apache.commons.math3.util.ArithmeticUtils.pow(var39, 2584899307L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test49"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot((-0.014785035766438845d), 1.600747998428365E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.014785044431934973d);

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test50"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(0.9854805897010366d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1102230246251565E-16d);

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test51"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(0.20139848231326574d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.19873989202858397d);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test52"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp((-1.2676506E30f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5111573E23f);

  }

  public void test53() {}
//   public void test53() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test53"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextInt((-1023), 0);
//     java.lang.String var6 = var1.nextSecureHexString(6);
//     int var9 = var1.nextZipf(208, 13.753533396481055d);
//     org.apache.commons.math3.distribution.IntegerDistribution var10 = null;
//     int var11 = var1.nextInversionDeviate(var10);
// 
//   }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test54"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-0.5745141880897972d), var1, true);
    java.lang.Number var4 = var3.getMin();
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var3.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test55() {}
//   public void test55() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test55"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeedSecure(0L);
//     long var6 = var1.nextSecureLong(3628800L, 10000000000L);
//     var1.reSeed((-2502316609L));
//     double var11 = var1.nextGaussian(1.7427271998994087d, 0.8266429039966963d);
//     double var13 = var1.nextChiSquare(0.5552592332346065d);
//     double var17 = var1.nextUniform((-1.2966581127618215d), (-0.21799941329709718d), true);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var20 = var1.nextSecureLong(14066561462L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 4521767795L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.0242563501897255d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.3719042446880644E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-0.9808173801816362d));
// 
//   }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test56"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    int var3 = var2.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var6.getNanStrategy();
    int var8 = var7.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.TiesStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.NaNStrategy var12 = var11.getNanStrategy();
    java.lang.Class var13 = var12.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12);
    org.apache.commons.math3.stat.ranking.TiesStrategy var15 = var14.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7, var15);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var17 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var15);
    org.apache.commons.math3.stat.ranking.TiesStrategy var18 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var18);
    org.apache.commons.math3.stat.ranking.NaNStrategy var20 = var19.getNanStrategy();
    java.lang.Class var21 = var20.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20);
    org.apache.commons.math3.stat.ranking.TiesStrategy var23 = var22.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var23);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var25 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var23);
    java.lang.Class var26 = var23.getDeclaringClass();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test57() {}
//   public void test57() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test57"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     double var7 = var1.nextChiSquare(0.6139648708421599d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var1.nextGaussian(1.661452088092057d, (-0.8061852905228414d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.1364851515981533d);
// 
//   }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test58"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    java.lang.Class var3 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var4.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var4.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.NaNStrategy var9 = var8.getNanStrategy();
    int var10 = var9.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var9);
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12);
    org.apache.commons.math3.stat.ranking.NaNStrategy var14 = var13.getNanStrategy();
    java.lang.Class var15 = var14.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var14);
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var9, var17);
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var17);
    org.apache.commons.math3.stat.ranking.NaNStrategy var20 = var19.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var21 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20, var21);
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test59"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, var1, (java.lang.Number)(-47515), (java.lang.Number)680824567L);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test60"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs((-6.796450769705151E-10d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6.796450769705151E-10d);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test61"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(99.99999f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test62"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(6.785121971699368E-66d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6.785121971699368E-66d);

  }

  public void test63() {}
//   public void test63() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test63"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure();
//     int var9 = var1.nextInt((-15), 500);
//     var1.reSeed(4448708814L);
//     int var14 = var1.nextInt(1073741824, 2147483647);
//     var1.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 214);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1222826114);
// 
//   }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test64"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(0.3933387805917712d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.38384345294639866d);

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test65"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)0.9999646015047479d);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test66"); }


    double[] var0 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(50);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var3);
    var1.contract();
    var1.addElement((-0.8307376748471434d));
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    float var9 = var1.getContractionCriteria();
    var1.addElement(0.08856762996018992d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 2.5f);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test67"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(9.536743E-7f, 448);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.POSITIVE_INFINITY);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test68"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(16.636486299878868d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.6793228537521016E7d);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test69"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(4.085393069481363d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.085393069481363d);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test70"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("f06cf625b72dddcbd66d2fe88fa94e8ac2178d95574ebe9e7cc4cb71f23889ee59aa33628193cfc85c7687cbf246e342329e3332b3ca4c3aa49c1df3c2150f5e06c1a1a627abbcf0ecbb497f55206750dd4fae2c5bddbfd53fba75f55011619b216dfd34da63d77f920090abe73fef9644f1ce1d400708c7803d5d733a8f4d19d03c155bd2d41dffdc3b2c42f791b69158bdc15ed114e0640154006f444c8d84b2a140c9f7af67df3d7c6948572e38e15af2c5191af83da79b30283def2a8ba7b38a531163b18b17bb5ddfa8aa91cfcaf693b726a6c72f2eb779c205d97564a84f2374ffa3a5a9a0ee0cd095dcf0e5ef1807046318d6ac772226");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test71() {}
//   public void test71() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test71"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure();
//     var1.reSeed();
//     double var10 = var1.nextBeta(31.984371183438952d, 3.141592653589793d);
//     var1.reSeed();
//     var1.reSeedSecure(0L);
//     var1.reSeed(194432926L);
//     double var17 = var1.nextChiSquare(7.5114088567829365d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.8546260963462944d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 7.218609418982603d);
// 
//   }

  public void test72() {}
//   public void test72() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test72"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(1.2588883301765685d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test73"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var3 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var6 = var5.getNumElements();
    double[] var7 = var5.getInternalValues();
    double[] var10 = new double[] { 10.0d, 100.0d};
    double var11 = var4.mannWhitneyU(var7, var10);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    double var13 = var0.mannWhitneyU(var3, var7);
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var17 = var16.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var19 = var18.getNumElements();
    double[] var20 = var18.getInternalValues();
    int var21 = var18.getNumElements();
    double[] var22 = var18.getElements();
    var16.addElements(var22);
    float var24 = var16.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var14, var16);
    org.apache.commons.math3.util.ResizableDoubleArray var26 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    org.apache.commons.math3.util.ResizableDoubleArray var27 = var14.copy();
    var27.contract();
    double var30 = var27.substituteMostRecentElement(0.3542123153443012d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 100.0d);

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test74"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(15.029829123697283d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.8055800200502138d));

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test75"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1.1518684333646754d, (java.lang.Number)43.26302966078136d, false);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test76"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb((-9.999999f), 295);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.NEGATIVE_INFINITY);

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test77"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.start();
    double var3 = var0.addElementRolling(4.937302184657956d);
    int var4 = var0.start();
    var0.contract();
    double[] var6 = var0.getInternalValues();
    var0.setExpansionMode(0);
    double[] var9 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var12 = var11.getNumElements();
    int var13 = var11.start();
    int var14 = var11.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var15 = var11.copy();
    var15.addElement(1.5690509993150914d);
    var15.contract();
    double[] var19 = var15.getElements();
    var10.addElements(var19);
    int var21 = var10.getNumElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1);

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test78"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 9617852649L);
    java.math.BigInteger var5 = null;
    java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 0L);
    java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, 9617852649L);
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, var7);
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 5002023);
    java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 907096051);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test79"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(31.984371183438952d, 0.3083894584059538d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test80"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(4.190850860146929d, (-0.41069097435491886d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-4.190850860146929d));

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test81"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.557261806044007d, (-0.10747463203439028d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.5675310714016952d);

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test82"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh((-0.010213363591270954d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.010213718741669662d));

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test83"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 9617852649L);
    java.math.BigInteger var5 = null;
    java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 0L);
    java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, 9617852649L);
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, var7);
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 2147483647);
    java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, 6949188755L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.math.BigInteger var16 = org.apache.commons.math3.util.ArithmeticUtils.pow(var14, (-8507354146L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test84() {}
//   public void test84() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test84"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     double var7 = var1.nextExponential(24.0d);
//     double var9 = var1.nextT(1.5855819012757701d);
//     double var12 = var1.nextGamma(0.7834476479380598d, 0.9999646015047479d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("2b49ebf09025683dcfd66bdbfc3bd01b9312e923f6cc796c9f82550775cb57cb4aa85a33d824464bf7c6902c25d7511b25ba64c1c78dbe60899554f1e09e28e24c9b0457f1e8773be1c6c6c5593f4598a69bcddf1d94106ed3069b21527274a9aafa4bf2c1e02b36320ba2b036ddc730782b1a3ea002289cf822a80d02c90fe6c2380819e2bdc0444542a94e99e31a0dfff9de67298bd2981cd08e6a64aa426b5d8f1695482ffc240c9ae12c74285304382ca09d1e63da5ad69b2b8499b7a679a5b6f4e61dbfec2587e7a19b7a34b32c2bddefaf1c7b3242bfa93c838f7a32c", "cdf99099a98b4c416a406749c049d2d6291e0920abdddf0fd62ae8178a45a22b5f594b70fcfe74c7970d5beb977e2bf060548386d8a9c71c9e5c5fed0f4dd6de43d8d23431af8b92f11107e719dcb5c8bbc0164dfad010d739fd4e2ae5e849d390918c23de617824178c34963a446666e85d9fb53c45344900c33bacb928e2b7cfbabe0295671890aaa34ad759bb6d71b2f032d3f262f5738891aa401b5f48b40b8f608ac3ebe3f03a90e1207ae9dd38132eef99ded58acdd03ad5588fcf2f4ff0cdbb2fb07d9af9207e8235df41d9e849eb738fcff22d79923e48005ccaa7170caacb76a2924709e58cf8996bda31d15fe893ec016a918e9c04");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 45.649047272959955d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-0.745192055311082d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.08833499874805252d);
// 
//   }

  public void test85() {}
//   public void test85() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test85"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh((-5.2969878277335525d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test86"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)100.0d);
    java.lang.Number var2 = var1.getMax();
    java.lang.Number var3 = var1.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 100.0d+ "'", var2.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 100.0d+ "'", var3.equals(100.0d));

  }

  public void test87() {}
//   public void test87() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test87"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure(10L);
//     long var10 = var1.nextSecureLong(10L, 10000000000L);
//     int var13 = var1.nextSecureInt(0, 10);
//     int var16 = var1.nextPascal(506, 0.3063909472492726d);
//     java.lang.String var18 = var1.nextSecureHexString(3570);
//     double var21 = var1.nextGaussian(0.1665864075690343d, 0.013335078676722052d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 29762051L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1182);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var18 + "' != '" + "e189ae8dc0d064c10d1f4d65c511b8ac6c566f9ad1d93d37225237ec854f9649a8930a97948cefe7e1df424771a254d24abb3ae079cf93ad7b4664599edba95b0a8c080a744a00cc3478f8905723897997fbce21d392865aed7029a167a86c5e6b874eed851b58ccde0ca786524c7690eb8ceb642781f2e8dc1a60648e8541dd0b1b003f52f60812d321a41f0b6b2aae95bcdcbbb4e0759bf102a11bd7a66ac061622113ab2dfcc2723d7b130e481a5eb44bc3ff5d3d1138b215a7e805bbd5499781012d3a2fda8463122c1571d5e2dac2110dd68f5bc53c8107773953adb44c8b9102c7778f495de0588c94d8e6542555fc8c006090f8d7f0909a5528cd799cc48334bc8feda89c99496fd0c20a514c97ea951b6791283bfac23cbbba747d4fc19a5e0580e0ca86077451ebbd96666a1f0cb432e4a3ff7dd057a749966122aff76342fe0e5b80571bd2005ce1dbf0dbcdf861d1bb0d236984b0ca263b5f520c20b69be61922b0b9d74c93cd648d1f2f12e4e08d8d6dc1b0657b3324771b802132964d65a9455294baba4f2e632a2726ba339e4ea48f1c9a7229f3119341ba5186e5e88199eaac119a54806c00187e95207f78e9837663f995856908cbd17787f4587314fbc9e309f440a843781d0e79d8fe1ee8eedad841b0724ae17b8c65b5b4b40ae18d7fbfef07c3eedf8ba5ff87deba48243724f6b884c787f5c329cd2aa41a5fc3440e3e6c0264a2b64028f11de871bac3f71437d45afde5ef1007f34114b2090b9df65510aa19f6e0a1bf85be184bbfa2cd4c2e50a5081c72949cb1fde2b0fd3b45af170c89f67166ee67dad2f103386a54f63b64a4c1a7d7c43a81655e0ad6e37646245fa36117de57ada023ef265f87d4ea9fcae319af1a858f9f7bd44fa0c3b5dc081325963aa29aaa7c1e215d2b641940608a531ccb2989ed4c066efc4fdf6f3fa20e3ea9e95aa218df77ad7ecee0d67e5960b29e06214c17cef60233aeac807502bc9bd19852f77d86fae0af9444fc392805d70297facc39037504689ad0a99b0313ee15b72de339860a87185eb817058ac9e0db653222a6d3840d4e27ad977a6e738ed394dad987bf3a302bd9ce378aa3b6919a645708ea46b316753075f5fd01f15c5bf0c5271ae396ec322b9b9289a21cc165bbd6a7f8ba9e6d2dcc35595662c078e8e1a91e3a615f0187f379440b3ff33dfad044db541c7ccfbb3e845d8bc85d3f272594464a52c106760f31f3377c5d3eae6d117dde17f42c10880932beb91550d9c3124128db6dc07e4d8b9d03ac2541ec2ad5fd22e8cd549c79182b2985c219f37eb61174c9b73cb7de5d57bf5279dfa1e697f00e2a8172a2c719d85d1c1ef0512d22ace2450e3568156b31523995d6e471165eb421339129cf6d54713314279e1dc2fe68f575d1edcd8bcf10888da016dd84bd671cdf333a44428413fb84345f64e087752a0b9a2d1ae00524494f358f7f373215857816062b2a26ffb2a45048a4449bf37500417c1b680ea1e8a1f13faec0e1d13a726fa9a911c2550ab0fdd481e7d7dece2a0220823eedb5b410a4f00e80717bc6d56faea3c6638ec8cfa9c4ca3c99115b87fad1248748de576b65f46b0f8d3f04e6affeade6f28303c168fd668384d6481da119c0456d958d90c38fde5c8c79c0032c1fb17f22e123d621899fd9da3ce42b3e7a5121fba68313937875baa82bad3dffd41468ee24c79a71f1114fd0d3a64f3f3836878ea0663f8567aded5eec8ad45ab494a2bac00347a0a2e4d3292438ec1b55426550bb4ce8d3c6310b4b4a7b8edea8f4dd369b498c4d292aef5e30fa3f88bfc29cd95744e59f7d4949cc931be5dc78caf5500112fdcc35cda055f96f2d64334b9edf2047cc3d283eaf6f9cf5a33b7d9076c97168ab0846168dc2054850492b1e7a5a10ead9a48fdd343cca0a1c1279733fb0d86c982e47233493028e998b301a99bef6f236db7853b82c9f77961ee955530011333ed97d9c7ec9762551e31086646921748395199c7e2fe4b7b3c5ea332b01e84191eef8f4296945a5246f18258508ea37aea3d28ad2d9447a8e58fe57fb512b2451861e869ff4f22718cd78ae90e1f77e35407951a54d271ee9df890e365009f9216488fa69d2dc10bb67a4fba28db0a5d3b49f9b24418f89e96e9e79279162551afc8baf9979a5decf2e423f66e7332d39e2ff84dec86c4b8ead36571867fd6ca762e073e6f638e385957ef8c0dfbd49bd4f78e990088154fa0730b8d99c8724bcc34c9efd84139e8349b1822abcc3c96b8e5e8efe4f9bde5ed1856fb733be30b5583c0807b3677e87fd3b06a2d92f9c948fa6658279bd2f8e3d1457de69d86de0aa238aa8d335614c33f6cc8fc9f42dcd9fcd20b0fc1b31d71da17c3ec4b46aad07d5b555d151a12fa4dfa00b822fe9eebb095f2d0eeb4d9c5322516beab9893a35a81039059381ad0e1f1b0d22a0814b39118d518755c426cfc63e4f498102b450c28288ff0f1d84489dc9f330b82cf1f1"+ "'", var18.equals("e189ae8dc0d064c10d1f4d65c511b8ac6c566f9ad1d93d37225237ec854f9649a8930a97948cefe7e1df424771a254d24abb3ae079cf93ad7b4664599edba95b0a8c080a744a00cc3478f8905723897997fbce21d392865aed7029a167a86c5e6b874eed851b58ccde0ca786524c7690eb8ceb642781f2e8dc1a60648e8541dd0b1b003f52f60812d321a41f0b6b2aae95bcdcbbb4e0759bf102a11bd7a66ac061622113ab2dfcc2723d7b130e481a5eb44bc3ff5d3d1138b215a7e805bbd5499781012d3a2fda8463122c1571d5e2dac2110dd68f5bc53c8107773953adb44c8b9102c7778f495de0588c94d8e6542555fc8c006090f8d7f0909a5528cd799cc48334bc8feda89c99496fd0c20a514c97ea951b6791283bfac23cbbba747d4fc19a5e0580e0ca86077451ebbd96666a1f0cb432e4a3ff7dd057a749966122aff76342fe0e5b80571bd2005ce1dbf0dbcdf861d1bb0d236984b0ca263b5f520c20b69be61922b0b9d74c93cd648d1f2f12e4e08d8d6dc1b0657b3324771b802132964d65a9455294baba4f2e632a2726ba339e4ea48f1c9a7229f3119341ba5186e5e88199eaac119a54806c00187e95207f78e9837663f995856908cbd17787f4587314fbc9e309f440a843781d0e79d8fe1ee8eedad841b0724ae17b8c65b5b4b40ae18d7fbfef07c3eedf8ba5ff87deba48243724f6b884c787f5c329cd2aa41a5fc3440e3e6c0264a2b64028f11de871bac3f71437d45afde5ef1007f34114b2090b9df65510aa19f6e0a1bf85be184bbfa2cd4c2e50a5081c72949cb1fde2b0fd3b45af170c89f67166ee67dad2f103386a54f63b64a4c1a7d7c43a81655e0ad6e37646245fa36117de57ada023ef265f87d4ea9fcae319af1a858f9f7bd44fa0c3b5dc081325963aa29aaa7c1e215d2b641940608a531ccb2989ed4c066efc4fdf6f3fa20e3ea9e95aa218df77ad7ecee0d67e5960b29e06214c17cef60233aeac807502bc9bd19852f77d86fae0af9444fc392805d70297facc39037504689ad0a99b0313ee15b72de339860a87185eb817058ac9e0db653222a6d3840d4e27ad977a6e738ed394dad987bf3a302bd9ce378aa3b6919a645708ea46b316753075f5fd01f15c5bf0c5271ae396ec322b9b9289a21cc165bbd6a7f8ba9e6d2dcc35595662c078e8e1a91e3a615f0187f379440b3ff33dfad044db541c7ccfbb3e845d8bc85d3f272594464a52c106760f31f3377c5d3eae6d117dde17f42c10880932beb91550d9c3124128db6dc07e4d8b9d03ac2541ec2ad5fd22e8cd549c79182b2985c219f37eb61174c9b73cb7de5d57bf5279dfa1e697f00e2a8172a2c719d85d1c1ef0512d22ace2450e3568156b31523995d6e471165eb421339129cf6d54713314279e1dc2fe68f575d1edcd8bcf10888da016dd84bd671cdf333a44428413fb84345f64e087752a0b9a2d1ae00524494f358f7f373215857816062b2a26ffb2a45048a4449bf37500417c1b680ea1e8a1f13faec0e1d13a726fa9a911c2550ab0fdd481e7d7dece2a0220823eedb5b410a4f00e80717bc6d56faea3c6638ec8cfa9c4ca3c99115b87fad1248748de576b65f46b0f8d3f04e6affeade6f28303c168fd668384d6481da119c0456d958d90c38fde5c8c79c0032c1fb17f22e123d621899fd9da3ce42b3e7a5121fba68313937875baa82bad3dffd41468ee24c79a71f1114fd0d3a64f3f3836878ea0663f8567aded5eec8ad45ab494a2bac00347a0a2e4d3292438ec1b55426550bb4ce8d3c6310b4b4a7b8edea8f4dd369b498c4d292aef5e30fa3f88bfc29cd95744e59f7d4949cc931be5dc78caf5500112fdcc35cda055f96f2d64334b9edf2047cc3d283eaf6f9cf5a33b7d9076c97168ab0846168dc2054850492b1e7a5a10ead9a48fdd343cca0a1c1279733fb0d86c982e47233493028e998b301a99bef6f236db7853b82c9f77961ee955530011333ed97d9c7ec9762551e31086646921748395199c7e2fe4b7b3c5ea332b01e84191eef8f4296945a5246f18258508ea37aea3d28ad2d9447a8e58fe57fb512b2451861e869ff4f22718cd78ae90e1f77e35407951a54d271ee9df890e365009f9216488fa69d2dc10bb67a4fba28db0a5d3b49f9b24418f89e96e9e79279162551afc8baf9979a5decf2e423f66e7332d39e2ff84dec86c4b8ead36571867fd6ca762e073e6f638e385957ef8c0dfbd49bd4f78e990088154fa0730b8d99c8724bcc34c9efd84139e8349b1822abcc3c96b8e5e8efe4f9bde5ed1856fb733be30b5583c0807b3677e87fd3b06a2d92f9c948fa6658279bd2f8e3d1457de69d86de0aa238aa8d335614c33f6cc8fc9f42dcd9fcd20b0fc1b31d71da17c3ec4b46aad07d5b555d151a12fa4dfa00b822fe9eebb095f2d0eeb4d9c5322516beab9893a35a81039059381ad0e1f1b0d22a0814b39118d518755c426cfc63e4f498102b450c28288ff0f1d84489dc9f330b82cf1f1"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.17346380858314236d);
// 
//   }

  public void test88() {}
//   public void test88() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test88"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeedSecure(0L);
//     java.lang.String var5 = var1.nextSecureHexString(371);
//     java.util.Collection var6 = null;
//     java.lang.Object[] var8 = var1.nextSample(var6, 264);
// 
//   }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test89"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.05388929638978884d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9985483232309089d);

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test90"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.getNumElements();
    int var2 = var0.start();
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var4 = var3.getNumElements();
    double[] var5 = var3.getInternalValues();
    int var6 = var3.getNumElements();
    double[] var7 = var3.getElements();
    var0.addElements(var7);
    var0.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(10, 99.99999f);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var12);
    float var14 = var12.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var16 = var15.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var17 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var18 = var17.getNumElements();
    double[] var19 = var17.getInternalValues();
    int var20 = var17.getNumElements();
    double[] var21 = var17.getElements();
    var15.addElements(var21);
    int var23 = var15.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var12, var15);
    double[] var25 = var15.getInternalValues();
    float var26 = var15.getContractionCriteria();
    var15.addElement(1.570446610624454d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 2.5f);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test91"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(1.327000036267693d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0948065260771824d);

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test92"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.9803662966187536d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5567183010255731d);

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test93"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var5 = var3.addElementRolling(Double.NaN);
    double[] var6 = var3.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var7);
    double[] var9 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var11 = var10.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var13 = var12.getNumElements();
    double[] var14 = var12.getInternalValues();
    int var15 = var12.getNumElements();
    double[] var16 = var12.getElements();
    var10.addElements(var16);
    var0.addElements(var16);
    boolean var20 = var0.equals((java.lang.Object)' ');
    int var21 = var0.start();
    double[] var22 = var0.getElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var24 = var0.substituteMostRecentElement((-17.413124803099183d));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException");
    } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test94"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.9706840563893051d);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test95"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(4.5E-44f, 0.8346648684178298d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.6E-44f);

  }

  public void test96() {}
//   public void test96() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test96"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeedSecure(0L);
//     long var6 = var1.nextSecureLong(3628800L, 10000000000L);
//     java.lang.String var8 = var1.nextHexString(500);
//     double var12 = var1.nextUniform((-0.5063656411097588d), 2.889407504491d, true);
//     int var15 = var1.nextBinomial(211, 0.9995622214897429d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 5019308559L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "dc793000758ac3ccbafae4b0049145c52597fce9b8bdb37b1e0eeee863a419403c1848685d4c2127c94938914aa9d01f256a0cf7051cbf5d8f64b42838289d63c0367857f9d73c93f000967524aa4baa582ef89773b59dc995fa63dd02e5d3a90fda91c39e7f48e48309a8754bdc5774b2b96bc23a124d011ccd91d7e950f0efa28a4a392157a58e44dbcf8bce07af831f480dc75be079606356eb7613bdacba139b806fbd9a6fa7847fa7b4ed9faab1928560669208ecd700a7edb7745cc17c4faeda6a2e8b7090e3c38f344aa960a75fc16088c853565a4fb26e5e96163bb3b62ef4a7cc1da7643153c444fc27345181c62c2d880a43975413"+ "'", var8.equals("dc793000758ac3ccbafae4b0049145c52597fce9b8bdb37b1e0eeee863a419403c1848685d4c2127c94938914aa9d01f256a0cf7051cbf5d8f64b42838289d63c0367857f9d73c93f000967524aa4baa582ef89773b59dc995fa63dd02e5d3a90fda91c39e7f48e48309a8754bdc5774b2b96bc23a124d011ccd91d7e950f0efa28a4a392157a58e44dbcf8bce07af831f480dc75be079606356eb7613bdacba139b806fbd9a6fa7847fa7b4ed9faab1928560669208ecd700a7edb7745cc17c4faeda6a2e8b7090e3c38f344aa960a75fc16088c853565a4fb26e5e96163bb3b62ef4a7cc1da7643153c444fc27345181c62c2d880a43975413"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 2.4630494161277046d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 211);
// 
//   }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test97"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(53.282201899041596d, 4.6624508263893025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 53.282201899041596d);

  }

  public void test98() {}
//   public void test98() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test98"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(1.81673506295471d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test99"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var1.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3, var4);
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var5.getTiesStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test100() {}
//   public void test100() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test100"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextSecureHexString(6);
//     org.apache.commons.math3.distribution.NormalDistribution var4 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var5 = var4.getNumericalMean();
//     double var6 = var4.getStandardDeviation();
//     boolean var7 = var4.isSupportLowerBoundInclusive();
//     boolean var8 = var4.isSupportUpperBoundInclusive();
//     double var9 = var4.getStandardDeviation();
//     double var10 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var4);
//     org.apache.commons.math3.distribution.NormalDistribution var11 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var12 = var11.getMean();
//     double var15 = var11.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
//     double var16 = var11.getSupportUpperBound();
//     double var17 = var11.getSupportUpperBound();
//     double var18 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var11);
//     double var20 = var11.density(5.451930926365849E-198d);
//     double var21 = var11.getSupportUpperBound();
//     double var24 = var11.cumulativeProbability(0.23074612792124255d, 0.74492045144808d);
//     double var25 = var11.getSupportUpperBound();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "8313a6"+ "'", var3.equals("8313a6"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.6430133779704894d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.5230558330643571d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.3598857409121632d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.3989422804014327d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0.1805961123312282d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == Double.POSITIVE_INFINITY);
// 
//   }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test101"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.6931471805599453d, (-53.264544310831205d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.008564199618796E8d);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test102"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var3 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var6 = var5.getNumElements();
    double[] var7 = var5.getInternalValues();
    double[] var10 = new double[] { 10.0d, 100.0d};
    double var11 = var4.mannWhitneyU(var7, var10);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    double var13 = var0.mannWhitneyU(var3, var7);
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var14.setContractionCriteria(16.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var17 = var14.copy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var14.discardFrontElements(341);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test103() {}
//   public void test103() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test103"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextBeta(572.2646479502633d, 0.07637989519631011d);
//     double var7 = var1.nextExponential(209.99999999999997d);
//     double var10 = var1.nextGaussian(0.6387763808612118d, 9.999999999999996d);
//     org.apache.commons.math3.distribution.NormalDistribution var11 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var12 = var11.getMean();
//     double var15 = var11.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
//     double var18 = var11.cumulativeProbability((-19.894922083922054d), 0.7853981633974483d);
//     double var19 = var11.sample();
//     double var20 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var11);
//     double var23 = var1.nextUniform(34.812727742759826d, 44.34227194424954d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var26 = var1.nextSecureInt((-65), (-241));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.9999513052296443d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.6669305442054003d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-17.183860895307635d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.5230558330643571d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.7838899213734127d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-0.9708852889418969d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == (-0.056086149172492564d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 35.65471589093708d);
// 
//   }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test104"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var2 = var0.addElementRolling(Double.NaN);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(10, 99.99999f);
    float var6 = var5.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var5);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.discardFrontElements(3615);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 100.49999f);

  }

  public void test105() {}
//   public void test105() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test105"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure();
//     double var8 = var1.nextExponential(44.5140274520795d);
//     java.lang.String var10 = var1.nextHexString(20988);
//     double var13 = var1.nextUniform((-0.6000588730884987d), (-0.3075645091247644d));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var16 = var1.nextWeibull(0.3970870780962367d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 43.756692991140994d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-0.43510329127035574d));
// 
//   }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test106"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(6673, (-394));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test107"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)4.255299853532773d, (java.lang.Number)(-1.5578270843725532d), true);

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test108"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(10198509466L, (-8454645887L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-8454645887L));

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test109"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("a11281a700b21f39cdc06aab4243fbbd69f51986b3152aa17f90c5db02b2ad5d350b2d6da718fde7f1868c5802732036c8b377d038919658ea5b1507bbc1781faadcf439a71ef889241096042e");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test110"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(1.81673506295471d, 0.9999999978823586d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-3.5468946170791027E-9d));

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test111"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(-0.8061852905228415d));
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var1.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test112"); }


    double var1 = org.apache.commons.math3.special.Erf.erf((-0.017486934199702348d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.01972988114117372d));

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test113"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(99.85091339688786d, (-11));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.04875532880707415d);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test114"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(-0.05782461145270825d), (java.lang.Number)(-1L), (java.lang.Number)100.0d);
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var3.getContext();
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var7 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalArgumentException var8 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var6, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var5, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.util.ExceptionContext var10 = var9.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test115"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(0.9135022946042973d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8188694798606977d);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test116"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)0.1043085576747377d);

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test117"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(0.9291735671723016d, (-0.006693634914056834d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.8187234198022598d));

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test118"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var1.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3, var4);
    org.apache.commons.math3.random.RandomGenerator var6 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    org.apache.commons.math3.stat.ranking.TiesStrategy var8 = var7.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var9 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var3, var8);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var10 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var13 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var14 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var16 = var15.getNumElements();
    double[] var17 = var15.getInternalValues();
    double[] var20 = new double[] { 10.0d, 100.0d};
    double var21 = var14.mannWhitneyU(var17, var20);
    org.apache.commons.math3.util.ResizableDoubleArray var22 = new org.apache.commons.math3.util.ResizableDoubleArray(var17);
    double var23 = var10.mannWhitneyU(var13, var17);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var24 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var25 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var26 = var25.getNumElements();
    double[] var27 = var25.getInternalValues();
    double[] var30 = new double[] { 10.0d, 100.0d};
    double var31 = var24.mannWhitneyU(var27, var30);
    org.apache.commons.math3.util.ResizableDoubleArray var32 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var33 = var32.getNumElements();
    double[] var34 = var32.getInternalValues();
    double var35 = var10.mannWhitneyUTest(var27, var34);
    org.apache.commons.math3.util.ResizableDoubleArray var36 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var36.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var39 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var41 = var39.addElementRolling(Double.NaN);
    double[] var42 = var39.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var43 = new org.apache.commons.math3.util.ResizableDoubleArray(var42);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var36, var43);
    double[] var45 = var36.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var46 = new org.apache.commons.math3.util.ResizableDoubleArray(var45);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var47 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var48 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var49 = var48.getNumElements();
    double[] var50 = var48.getInternalValues();
    double[] var53 = new double[] { 10.0d, 100.0d};
    double var54 = var47.mannWhitneyU(var50, var53);
    var46.addElements(var53);
    var46.setContractionCriteria(2.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var58 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var60 = var58.addElementRolling(Double.NaN);
    double[] var61 = var58.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var62 = new org.apache.commons.math3.util.ResizableDoubleArray(var61);
    org.apache.commons.math3.util.ResizableDoubleArray var63 = new org.apache.commons.math3.util.ResizableDoubleArray(var61);
    var46.addElements(var61);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var65 = var9.mannWhitneyUTest(var34, var61);
      fail("Expected exception of type org.apache.commons.math3.exception.NoDataException");
    } catch (org.apache.commons.math3.exception.NoDataException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test119"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var3 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var6 = var5.getNumElements();
    double[] var7 = var5.getInternalValues();
    double[] var10 = new double[] { 10.0d, 100.0d};
    double var11 = var4.mannWhitneyU(var7, var10);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    double var13 = var0.mannWhitneyU(var3, var7);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var14 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var16 = var15.getNumElements();
    double[] var17 = var15.getInternalValues();
    double[] var20 = new double[] { 10.0d, 100.0d};
    double var21 = var14.mannWhitneyU(var17, var20);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var22 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var23 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var24 = var23.getNumElements();
    double[] var25 = var23.getInternalValues();
    double[] var28 = new double[] { 10.0d, 100.0d};
    double var29 = var22.mannWhitneyU(var25, var28);
    double var30 = var0.mannWhitneyUTest(var17, var28);
    org.apache.commons.math3.stat.ranking.TiesStrategy var31 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var32 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var31);
    org.apache.commons.math3.stat.ranking.NaNStrategy var33 = var32.getNanStrategy();
    int var34 = var33.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var35 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var33);
    org.apache.commons.math3.stat.ranking.TiesStrategy var36 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var37 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var36);
    org.apache.commons.math3.stat.ranking.NaNStrategy var38 = var37.getNanStrategy();
    java.lang.Class var39 = var38.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var40 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var38);
    org.apache.commons.math3.stat.ranking.TiesStrategy var41 = var40.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var42 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var33, var41);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var43 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var44 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var45 = var44.getNumElements();
    double[] var46 = var44.getInternalValues();
    double[] var49 = new double[] { 10.0d, 100.0d};
    double var50 = var43.mannWhitneyU(var46, var49);
    double[] var51 = var42.rank(var49);
    org.apache.commons.math3.util.ResizableDoubleArray var52 = new org.apache.commons.math3.util.ResizableDoubleArray(var51);
    org.apache.commons.math3.util.ResizableDoubleArray var53 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var55 = var53.addElementRolling(Double.NaN);
    var53.setNumElements(0);
    var53.contract();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var59 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var60 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var63 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var64 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var65 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var66 = var65.getNumElements();
    double[] var67 = var65.getInternalValues();
    double[] var70 = new double[] { 10.0d, 100.0d};
    double var71 = var64.mannWhitneyU(var67, var70);
    org.apache.commons.math3.util.ResizableDoubleArray var72 = new org.apache.commons.math3.util.ResizableDoubleArray(var67);
    double var73 = var60.mannWhitneyU(var63, var67);
    double[] var77 = new double[] { 100.0d, 1.0d, 100.0d};
    double var78 = var59.mannWhitneyU(var63, var77);
    var53.addElements(var77);
    org.apache.commons.math3.util.ResizableDoubleArray var81 = new org.apache.commons.math3.util.ResizableDoubleArray(50);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var53, var81);
    var53.clear();
    double[] var84 = var53.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var85 = new org.apache.commons.math3.util.ResizableDoubleArray(var84);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var86 = var0.mannWhitneyU(var51, var84);
      fail("Expected exception of type org.apache.commons.math3.exception.NoDataException");
    } catch (org.apache.commons.math3.exception.NoDataException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.024588566448858762d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test120"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign((-1.3670189956165777d), 1.7874209719136303d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.3670189956165777d);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test121"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getMean();
    double var4 = var0.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
    double var5 = var0.getSupportUpperBound();
    double var7 = var0.probability(Double.NEGATIVE_INFINITY);
    double var9 = var0.probability(Double.POSITIVE_INFINITY);
    double var11 = var0.density(99.59410039019672d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.5230558330643571d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test122"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)1619796881L);

  }

  public void test123() {}
//   public void test123() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test123"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var5 = var1.nextUniform(0.999987895021552d, 15.322095332102348d, false);
//     double var8 = var1.nextGamma(1.4713540043352986d, 4.787491742782046d);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var9.getMean();
//     double var13 = var9.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
//     double var14 = var9.getNumericalVariance();
//     double var15 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     double var18 = var1.nextGamma(99.69065826232949d, 2.786677745713106d);
//     double var22 = var1.nextUniform((-0.17393496569430167d), 69.70042867197392d, true);
//     long var25 = var1.nextLong((-10681828717L), (-4448708814L));
//     double var28 = var1.nextGamma(3.123616354820892d, 0.4705756905309871d);
//     var1.reSeedSecure();
//     double var32 = var1.nextF(2.464750698815533d, 1.1580069074881836d);
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var36 = var1.nextPermutation(97, 736063294);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 5.731006604837108d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 12.790601493516066d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.5230558330643571d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.28939553371382715d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 275.1007603578035d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 58.61775495358169d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == (-5847618924L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1.2780116234881067d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 2.0842748518967564d);
// 
//   }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test124"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(3.6278346133805086d, 0.7853981633974483d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.7853981633974483d);

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test125"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh((-0.016386819051824476d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0001342669238122d);

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test126"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(1.0016685869732043d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.6409316147955457d);

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test127"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.getNumElements();
    double[] var2 = var0.getInternalValues();
    int var3 = var0.getNumElements();
    double[] var4 = var0.getElements();
    var0.setExpansionMode(0);
    var0.discardFrontElements(0);
    var0.contract();
    int var10 = var0.getNumElements();
    float var11 = var0.getExpansionFactor();
    org.apache.commons.math3.util.ResizableDoubleArray var12 = var0.copy();
    var12.setNumElements(102300);
    int var15 = var12.getExpansionMode();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test128"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var5 = var3.addElementRolling(Double.NaN);
    double[] var6 = var3.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var7);
    double[] var9 = var0.getElements();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var10 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var13 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var14 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var16 = var15.getNumElements();
    double[] var17 = var15.getInternalValues();
    double[] var20 = new double[] { 10.0d, 100.0d};
    double var21 = var14.mannWhitneyU(var17, var20);
    org.apache.commons.math3.util.ResizableDoubleArray var22 = new org.apache.commons.math3.util.ResizableDoubleArray(var17);
    double var23 = var10.mannWhitneyU(var13, var17);
    org.apache.commons.math3.util.ResizableDoubleArray var24 = new org.apache.commons.math3.util.ResizableDoubleArray(var13);
    org.apache.commons.math3.util.ResizableDoubleArray var25 = new org.apache.commons.math3.util.ResizableDoubleArray(var24);
    double var27 = var24.substituteMostRecentElement(0.3742437696541317d);
    org.apache.commons.math3.util.ResizableDoubleArray var28 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var28.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var31 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var33 = var31.addElementRolling(Double.NaN);
    double[] var34 = var31.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var35 = new org.apache.commons.math3.util.ResizableDoubleArray(var34);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var28, var35);
    double[] var37 = var28.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var38 = new org.apache.commons.math3.util.ResizableDoubleArray(var37);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var39 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var40 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var41 = var40.getNumElements();
    double[] var42 = var40.getInternalValues();
    double[] var45 = new double[] { 10.0d, 100.0d};
    double var46 = var39.mannWhitneyU(var42, var45);
    var38.addElements(var45);
    var24.addElements(var45);
    var0.addElements(var45);
    org.apache.commons.math3.util.ResizableDoubleArray var50 = new org.apache.commons.math3.util.ResizableDoubleArray(var45);
    float var51 = var50.getContractionCriteria();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 2.5f);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test129"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(10400, 1.0000002f);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test130"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)31.98437118343895d, (java.lang.Number)10L, false);
    java.lang.String var4 = var3.toString();
    org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    org.apache.commons.math3.exception.MathInternalError var6 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    org.apache.commons.math3.exception.util.ExceptionContext var7 = var6.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var8 = var6.getContext();
    java.lang.Throwable[] var9 = var6.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: 31.984 is smaller than, or equal to, the minimum (10)"+ "'", var4.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: 31.984 is smaller than, or equal to, the minimum (10)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test131"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.getNumElements();
    double[] var2 = var0.getInternalValues();
    int var3 = var0.getNumElements();
    double[] var4 = var0.getElements();
    var0.setExpansionMode(0);
    var0.discardFrontElements(0);
    var0.contract();
    int var10 = var0.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var11 = var0.copy();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test132"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var1 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var4 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var5 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var7 = var6.getNumElements();
    double[] var8 = var6.getInternalValues();
    double[] var11 = new double[] { 10.0d, 100.0d};
    double var12 = var5.mannWhitneyU(var8, var11);
    org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
    double var14 = var1.mannWhitneyU(var4, var8);
    double[] var18 = new double[] { 100.0d, 1.0d, 100.0d};
    double var19 = var0.mannWhitneyU(var4, var18);
    org.apache.commons.math3.stat.ranking.TiesStrategy var20 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20);
    org.apache.commons.math3.stat.ranking.NaNStrategy var22 = var21.getNanStrategy();
    int var23 = var22.ordinal();
    org.apache.commons.math3.stat.ranking.TiesStrategy var24 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var25 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var24);
    org.apache.commons.math3.stat.ranking.NaNStrategy var26 = var25.getNanStrategy();
    java.lang.Class var27 = var26.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var28 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var26);
    org.apache.commons.math3.stat.ranking.TiesStrategy var29 = var28.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var30 = var28.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var31 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var32 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var31);
    org.apache.commons.math3.stat.ranking.NaNStrategy var33 = var32.getNanStrategy();
    int var34 = var33.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var35 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var33);
    org.apache.commons.math3.stat.ranking.TiesStrategy var36 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var37 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var36);
    org.apache.commons.math3.stat.ranking.NaNStrategy var38 = var37.getNanStrategy();
    java.lang.Class var39 = var38.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var40 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var38);
    org.apache.commons.math3.stat.ranking.TiesStrategy var41 = var40.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var42 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var33, var41);
    org.apache.commons.math3.stat.ranking.NaturalRanking var43 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var30, var41);
    org.apache.commons.math3.stat.ranking.NaturalRanking var44 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var22, var41);
    org.apache.commons.math3.util.ResizableDoubleArray var45 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var46 = var45.getNumElements();
    int var47 = var45.start();
    org.apache.commons.math3.util.ResizableDoubleArray var48 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var49 = var48.getNumElements();
    double[] var50 = var48.getInternalValues();
    int var51 = var48.getNumElements();
    double[] var52 = var48.getElements();
    var45.addElements(var52);
    var45.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var57 = new org.apache.commons.math3.util.ResizableDoubleArray(10, 99.99999f);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var45, var57);
    var57.setElement(825, (-0.06991186090907374d));
    double[] var62 = var57.getElements();
    double[] var63 = var44.rank(var62);
    org.apache.commons.math3.util.ResizableDoubleArray var64 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var65 = var64.getNumElements();
    double[] var66 = var64.getInternalValues();
    int var67 = var64.getNumElements();
    double[] var68 = var64.getInternalValues();
    var64.setContractionCriteria(7.5557864E22f);
    double[] var71 = var64.getElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var72 = var0.mannWhitneyUTest(var62, var71);
      fail("Expected exception of type org.apache.commons.math3.exception.NoDataException");
    } catch (org.apache.commons.math3.exception.NoDataException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);

  }

  public void test133() {}
//   public void test133() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test133"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure();
//     var1.reSeed();
//     double var9 = var1.nextChiSquare(1.1580069074881836d);
//     org.apache.commons.math3.distribution.NormalDistribution var10 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var11 = var10.getNumericalMean();
//     double var12 = var10.getStandardDeviation();
//     boolean var13 = var10.isSupportLowerBoundInclusive();
//     double var14 = var10.getSupportLowerBound();
//     double var15 = var10.getSupportLowerBound();
//     var10.reseedRandomGenerator(0L);
//     double var18 = var10.sample();
//     double var19 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.363940073594261d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-0.043481143175376734d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.4223516039811579d);
// 
//   }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test134"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(1.907349E-6f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.907349E-6f);

  }

  public void test135() {}
//   public void test135() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test135"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure(10L);
//     long var10 = var1.nextSecureLong(10L, 10000000000L);
//     double var12 = var1.nextChiSquare(0.001736111111111111d);
//     double var15 = var1.nextBeta(0.36792469441508013d, 0.23074612792124255d);
//     var1.reSeed((-6197319789L));
//     int var20 = var1.nextBinomial(5, 0.9738617129853937d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var23 = var1.nextLong(6949188755L, 1L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 7940810615L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1.3814397810752436E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.2425876100181316d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 5);
// 
//   }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test136"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    int var3 = var2.ordinal();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var5.getNanStrategy();
    java.lang.Class var7 = var6.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    org.apache.commons.math3.stat.ranking.TiesStrategy var9 = var8.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = var8.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var11 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11);
    org.apache.commons.math3.stat.ranking.NaNStrategy var13 = var12.getNanStrategy();
    int var14 = var13.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var13);
    org.apache.commons.math3.stat.ranking.TiesStrategy var16 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var16);
    org.apache.commons.math3.stat.ranking.NaNStrategy var18 = var17.getNanStrategy();
    java.lang.Class var19 = var18.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var18);
    org.apache.commons.math3.stat.ranking.TiesStrategy var21 = var20.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var13, var21);
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10, var21);
    org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var21);
    java.lang.String var25 = var21.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var26 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var21);
    org.apache.commons.math3.stat.ranking.TiesStrategy var27 = var26.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var28 = var26.getNanStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + "AVERAGE"+ "'", var25.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test137() {}
//   public void test137() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test137"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextBeta(572.2646479502633d, 0.07637989519631011d);
//     double var8 = var1.nextGamma(4.937302184657956d, 97.98819663162894d);
//     int var11 = var1.nextInt(0, 128);
//     double var13 = var1.nextExponential(99.47657714901254d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.9984022310880419d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 769.9825773345563d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 220.25023195585388d);
// 
//   }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test138"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.getNumElements();
    int var2 = var0.start();
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var4 = var3.getNumElements();
    double[] var5 = var3.getInternalValues();
    int var6 = var3.getNumElements();
    double[] var7 = var3.getElements();
    var0.addElements(var7);
    var0.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(10, 99.99999f);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var12);
    var12.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var16 = var15.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var17 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var18 = var17.getNumElements();
    double[] var19 = var17.getInternalValues();
    int var20 = var17.getNumElements();
    double[] var21 = var17.getElements();
    var15.addElements(var21);
    float var23 = var15.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var12, var15);
    org.apache.commons.math3.exception.MaxCountExceededException var26 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)363.7393755555636d);
    boolean var27 = var15.equals((java.lang.Object)var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test139"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(119.31703692887734d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.923048941477225d);

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test140"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)100.0d);
    java.lang.String var2 = var1.toString();
    java.lang.Number var3 = var1.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (100) exceeded"+ "'", var2.equals("org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (100) exceeded"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 100.0d+ "'", var3.equals(100.0d));

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test141"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var2 = var0.density(100.0d);
    double var5 = var0.cumulativeProbability((-2.450405938642638d), 0.6139648708421599d);
    double var6 = var0.getMean();
    boolean var7 = var0.isSupportUpperBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.723245967437971d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test142"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("a11281a700b21f39cdc06aab4243fbbd69f51986b3152aa17f90c5db02b2ad5d350b2d6da718fde7f1868c5802732036c8b377d038919658ea5b1507bbc1781faadcf439a71ef889241096042e");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test143() {}
//   public void test143() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test143"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     double var8 = var1.nextWeibull(0.7853981633974483d, 4.787491742782046d);
//     double var11 = var1.nextWeibull(1.315149049454551d, 1.3973342048086457d);
//     double var15 = var1.nextUniform((-0.2554932247505838d), 1.1125191124373863d, false);
//     double var17 = var1.nextT(0.9997768398506297d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var20 = var1.nextLong(8494943427L, 7172474253L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 22.948203905246878d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.1149672978152912d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.9395820428512986d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-0.48348094171217576d));
// 
//   }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test144"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(5.381455886543763d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 108.66693211478379d);

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test145"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(1.7207593775533681E-6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.377222780096887E11d);

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test146"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(112, (-124951999));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 124952111);

  }

  public void test147() {}
//   public void test147() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test147"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure();
//     var1.reSeed();
//     double var9 = var1.nextChiSquare(1.1580069074881836d);
//     var1.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.9873325804729485d);
// 
//   }

  public void test148() {}
//   public void test148() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test148"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getMean();
//     double var4 = var0.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
//     boolean var5 = var0.isSupportConnected();
//     double var6 = var0.getNumericalVariance();
//     double var7 = var0.sample();
//     double var8 = var0.getMean();
//     boolean var9 = var0.isSupportConnected();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.5230558330643571d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-0.663094503832795d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == true);
// 
//   }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test149"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    int var3 = var2.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    java.lang.String var5 = var2.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    java.lang.String var7 = var2.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var9 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var9);
    org.apache.commons.math3.stat.ranking.NaNStrategy var11 = var10.getNanStrategy();
    int var12 = var11.ordinal();
    org.apache.commons.math3.stat.ranking.TiesStrategy var13 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var13);
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = var14.getNanStrategy();
    java.lang.Class var16 = var15.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15);
    org.apache.commons.math3.stat.ranking.TiesStrategy var18 = var17.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var19 = var17.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var20 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20);
    org.apache.commons.math3.stat.ranking.NaNStrategy var22 = var21.getNanStrategy();
    int var23 = var22.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var22);
    org.apache.commons.math3.stat.ranking.TiesStrategy var25 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var26 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var25);
    org.apache.commons.math3.stat.ranking.NaNStrategy var27 = var26.getNanStrategy();
    java.lang.Class var28 = var27.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var29 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var27);
    org.apache.commons.math3.stat.ranking.TiesStrategy var30 = var29.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var31 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var22, var30);
    org.apache.commons.math3.stat.ranking.NaturalRanking var32 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var19, var30);
    org.apache.commons.math3.stat.ranking.NaturalRanking var33 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11, var30);
    org.apache.commons.math3.stat.ranking.NaturalRanking var34 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var30);
    org.apache.commons.math3.stat.ranking.NaNStrategy var35 = var34.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var36 = var34.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var37 = var34.getNanStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "MAXIMAL"+ "'", var5.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "MAXIMAL"+ "'", var7.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test150() {}
//   public void test150() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test150"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(9.758686158750079d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test151"); }


    long var2 = org.apache.commons.math3.util.FastMath.min((-10681828717L), 6398462632L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-10681828717L));

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test152"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(15.999999f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 15.999999f);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test153"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(32.53142185860535d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8981287075350308d);

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test154"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-663925499), 7193097162L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 764351993);

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test155"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(0.9899600594521918d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9966420902133644d);

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test156"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var3 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var6 = var5.getNumElements();
    double[] var7 = var5.getInternalValues();
    double[] var10 = new double[] { 10.0d, 100.0d};
    double var11 = var4.mannWhitneyU(var7, var10);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    double var13 = var0.mannWhitneyU(var3, var7);
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    var15.addElement(1832.5694791909018d);
    int var18 = var15.getExpansionMode();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test157"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    int var3 = var2.ordinal();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var5.getNanStrategy();
    java.lang.Class var7 = var6.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    org.apache.commons.math3.stat.ranking.TiesStrategy var9 = var8.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = var8.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var11 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11);
    org.apache.commons.math3.stat.ranking.NaNStrategy var13 = var12.getNanStrategy();
    int var14 = var13.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var13);
    org.apache.commons.math3.stat.ranking.TiesStrategy var16 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var16);
    org.apache.commons.math3.stat.ranking.NaNStrategy var18 = var17.getNanStrategy();
    java.lang.Class var19 = var18.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var18);
    org.apache.commons.math3.stat.ranking.TiesStrategy var21 = var20.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var13, var21);
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10, var21);
    org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var21);
    org.apache.commons.math3.util.ResizableDoubleArray var25 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var26 = var25.getNumElements();
    int var27 = var25.start();
    org.apache.commons.math3.util.ResizableDoubleArray var28 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var29 = var28.getNumElements();
    double[] var30 = var28.getInternalValues();
    int var31 = var28.getNumElements();
    double[] var32 = var28.getElements();
    var25.addElements(var32);
    var25.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var37 = new org.apache.commons.math3.util.ResizableDoubleArray(10, 99.99999f);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var25, var37);
    var37.setElement(825, (-0.06991186090907374d));
    double[] var42 = var37.getElements();
    double[] var43 = var24.rank(var42);
    org.apache.commons.math3.stat.ranking.TiesStrategy var44 = var24.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var45 = var24.getTiesStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test158"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var3 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var6 = var5.getNumElements();
    double[] var7 = var5.getInternalValues();
    double[] var10 = new double[] { 10.0d, 100.0d};
    double var11 = var4.mannWhitneyU(var7, var10);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    double var13 = var0.mannWhitneyU(var3, var7);
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var14.discardFrontElements(1078421185);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 24.0d);

  }

  public void test159() {}
//   public void test159() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test159"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var2 = var0.density(100.0d);
//     double var5 = var0.cumulativeProbability((-2.450405938642638d), 0.6139648708421599d);
//     double[] var7 = var0.sample(100);
//     double var8 = var0.getStandardDeviation();
//     double var9 = var0.sample();
//     double var10 = var0.getSupportUpperBound();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var0.inverseCumulativeProbability(8.037850951474781E118d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.723245967437971d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.7575599901521025d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == Double.POSITIVE_INFINITY);
// 
//   }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test160"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.8524481817025479d, (java.lang.Number)5.735758181354605d, false);

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test161"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(3659212668L, 5694993326L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test162"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getMean();
    double var4 = var0.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
    double var5 = var0.getNumericalVariance();
    var0.reseedRandomGenerator(100L);
    double var8 = var0.getNumericalMean();
    double var9 = var0.sample();
    double var10 = var0.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.5230558330643571d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.4705756905309871d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1.0d);

  }

  public void test163() {}
//   public void test163() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test163"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.5607966601082315d);
//     java.lang.String var4 = var0.nextHexString(506);
//     double var7 = var0.nextCauchy(0.3063909472492726d, 1.5607966601082315d);
//     double var10 = var0.nextUniform((-0.6932391748384723d), 0.14049621499892223d);
//     long var13 = var0.nextSecureLong((-2L), 664646591L);
//     double var15 = var0.nextChiSquare(0.9783618610526693d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.3347073545163447d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "59805dee2248e1fe4e4aa8191b68369121dfe3bde9ab8cdeb00b11f2a5303df1cdbcc180b56bfcc59e074f4ccc6f42889e70d149460e9cb7f35b946259c975f6a5c1c9eef089e2e7fd139fdb65e1dcc5da578f36ce8dab10df4100b43ce87d7c38d803976d2c56b7d9640d0ee9b7e61c8c6c584a39df171f4fb8b10265e01aeab9c3653424e08cc53b8cc0373b60c1265b846de5efcf2eba78f5a174f75e697b0ee8890fed1bf3caa493a88c38c68b61d0f290e7bde337a1aaadc799a318aeab7e5f4e61659f02a5e18e8837a821e1ac94f2ace74121e0eb7d05dfef23dcd8aef20d073d45c6d821fc21a94457e9f693dead9883800e690c7e98ee6864"+ "'", var4.equals("59805dee2248e1fe4e4aa8191b68369121dfe3bde9ab8cdeb00b11f2a5303df1cdbcc180b56bfcc59e074f4ccc6f42889e70d149460e9cb7f35b946259c975f6a5c1c9eef089e2e7fd139fdb65e1dcc5da578f36ce8dab10df4100b43ce87d7c38d803976d2c56b7d9640d0ee9b7e61c8c6c584a39df171f4fb8b10265e01aeab9c3653424e08cc53b8cc0373b60c1265b846de5efcf2eba78f5a174f75e697b0ee8890fed1bf3caa493a88c38c68b61d0f290e7bde337a1aaadc799a318aeab7e5f4e61659f02a5e18e8837a821e1ac94f2ace74121e0eb7d05dfef23dcd8aef20d073d45c6d821fc21a94457e9f693dead9883800e690c7e98ee6864"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2.5135940888759336d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.6834980788972117d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 11708906L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.834942319862084E-4d);
// 
//   }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test164"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(36L, 7080423162L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test165"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.0d, 47.77929504193063d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 47.77929504193063d);

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test166"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(0.25265756713375326d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test167"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)5.344724688687484d);

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test168"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(0.9606790970999405d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test169"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Object[] var2 = null;
    org.apache.commons.math3.exception.MathArithmeticException var3 = new org.apache.commons.math3.exception.MathArithmeticException(var1, var2);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.MaxCountExceededException var7 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(short)100);
    java.lang.Number var8 = var7.getMax();
    java.lang.Number var9 = var7.getMax();
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    org.apache.commons.math3.exception.util.Localizable var11 = null;
    org.apache.commons.math3.exception.util.Localizable var12 = null;
    org.apache.commons.math3.exception.MathInternalError var13 = new org.apache.commons.math3.exception.MathInternalError();
    java.lang.Throwable[] var14 = var13.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var15 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var12, (java.lang.Object[])var14);
    org.apache.commons.math3.exception.NullArgumentException var16 = new org.apache.commons.math3.exception.NullArgumentException(var11, (java.lang.Object[])var14);
    org.apache.commons.math3.exception.MathIllegalStateException var17 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var7, var10, (java.lang.Object[])var14);
    java.lang.Throwable[] var18 = var17.getSuppressed();
    var5.addSuppressed((java.lang.Throwable)var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (short)100+ "'", var8.equals((short)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + (short)100+ "'", var9.equals((short)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test170"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.25265756713375326d, (-0.5516014643091351d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.135817067652569d);

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test171"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getSupportLowerBound();
    double var2 = var0.getNumericalMean();
    double var4 = var0.density(1.0464211895232356d);
    boolean var5 = var0.isSupportConnected();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.23074612792124255d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test172"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var3 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var6 = var5.getNumElements();
    double[] var7 = var5.getInternalValues();
    double[] var10 = new double[] { 10.0d, 100.0d};
    double var11 = var4.mannWhitneyU(var7, var10);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    double var13 = var0.mannWhitneyU(var3, var7);
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var17 = var16.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var19 = var18.getNumElements();
    double[] var20 = var18.getInternalValues();
    int var21 = var18.getNumElements();
    double[] var22 = var18.getElements();
    var16.addElements(var22);
    float var24 = var16.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var14, var16);
    org.apache.commons.math3.util.ResizableDoubleArray var26 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    double[] var27 = var26.getElements();
    var26.addElement(100.0d);
    var26.clear();
    double var32 = var26.addElementRolling((-2.369613507099535d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test173"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(0.22196580398609947d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.22014762327966106d);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test174"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    int var3 = var2.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var6.getNanStrategy();
    java.lang.Class var8 = var7.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.TiesStrategy var10 = var9.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var10);
    int var12 = var2.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var15 = var14.getTiesStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test175"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var2 = var0.addElementRolling(Double.NaN);
    double[] var3 = var0.getElements();
    int var4 = var0.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    var5.addElement(7.950137129262085E-8d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.discardFrontElements(5488);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test176"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(128, 0.0f, 0.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test177"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    java.lang.Class var3 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var4.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var4.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var7);
    int var9 = var6.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    org.apache.commons.math3.stat.ranking.TiesStrategy var11 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var12 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var6, var11);
    org.apache.commons.math3.stat.ranking.TiesStrategy var13 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var13);
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = var14.getNanStrategy();
    int var16 = var15.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15);
    java.lang.String var18 = var15.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15);
    java.lang.String var20 = var15.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15);
    org.apache.commons.math3.stat.ranking.TiesStrategy var22 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var22);
    org.apache.commons.math3.stat.ranking.NaNStrategy var24 = var23.getNanStrategy();
    int var25 = var24.ordinal();
    org.apache.commons.math3.stat.ranking.TiesStrategy var26 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var27 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var26);
    org.apache.commons.math3.stat.ranking.NaNStrategy var28 = var27.getNanStrategy();
    java.lang.Class var29 = var28.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var30 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var28);
    org.apache.commons.math3.stat.ranking.TiesStrategy var31 = var30.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var32 = var30.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var33 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var34 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var33);
    org.apache.commons.math3.stat.ranking.NaNStrategy var35 = var34.getNanStrategy();
    int var36 = var35.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var37 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var35);
    org.apache.commons.math3.stat.ranking.TiesStrategy var38 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var39 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var38);
    org.apache.commons.math3.stat.ranking.NaNStrategy var40 = var39.getNanStrategy();
    java.lang.Class var41 = var40.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var42 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var40);
    org.apache.commons.math3.stat.ranking.TiesStrategy var43 = var42.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var44 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var35, var43);
    org.apache.commons.math3.stat.ranking.NaturalRanking var45 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var32, var43);
    org.apache.commons.math3.stat.ranking.NaturalRanking var46 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var24, var43);
    org.apache.commons.math3.stat.ranking.NaturalRanking var47 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15, var43);
    boolean var49 = var43.equals((java.lang.Object)(-3.06588826647091E-5d));
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var50 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var6, var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + "MAXIMAL"+ "'", var18.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "MAXIMAL"+ "'", var20.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test178"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    java.lang.Object[] var7 = new java.lang.Object[] { 'a'};
    org.apache.commons.math3.exception.MathIllegalStateException var8 = new org.apache.commons.math3.exception.MathIllegalStateException(var5, var7);
    org.apache.commons.math3.exception.MathIllegalArgumentException var9 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var4, var7);
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var3, var7);
    org.apache.commons.math3.exception.MathArithmeticException var11 = new org.apache.commons.math3.exception.MathArithmeticException(var2, var7);
    org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, var7);
    org.apache.commons.math3.exception.MathIllegalArgumentException var13 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test179"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)0.8925913538795224d);

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test180"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.start();
    double var3 = var0.addElementRolling(4.937302184657956d);
    int var4 = var0.start();
    var0.contract();
    double[] var6 = var0.getInternalValues();
    var0.setExpansionMode(0);
    int var9 = var0.getExpansionMode();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test181"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)506, (java.lang.Number)12.340615030870834d, false);
    boolean var4 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test182"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.9985619410825101d, (java.lang.Number)29.54554454270477d, true);
    boolean var4 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test183() {}
//   public void test183() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test183"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(3.2188758248682006d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test184"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)2.786677745713106d, (java.lang.Number)1619796881L, true);

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test185"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var3 = var2.getNumElements();
    double[] var4 = var2.getInternalValues();
    int var5 = var2.getNumElements();
    double[] var6 = var2.getElements();
    var0.addElements(var6);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = var0.copy();
    var8.contract();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var8.discardMostRecentElements((-7574));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test186"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p((-0.5648310933604662d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.8320210321335785d));

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test187"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(43.81860364444665d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.8026233131450846d);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test188"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(1.4690188987035586d, 572.2646479502633d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.002567021529663084d);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test189"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(101794, 210);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test190"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)30.0d);
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var2.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test191() {}
//   public void test191() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test191"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeedSecure(0L);
//     long var6 = var1.nextSecureLong(3628800L, 10000000000L);
//     double var9 = var1.nextGamma(2.6498507619080125d, (-0.05788914687716099d));
//     org.apache.commons.math3.distribution.NormalDistribution var10 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var12 = var10.density(100.0d);
//     double var15 = var10.cumulativeProbability((-2.450405938642638d), 0.6139648708421599d);
//     double[] var17 = var10.sample(100);
//     double var18 = var10.getStandardDeviation();
//     boolean var19 = var10.isSupportUpperBoundInclusive();
//     var10.reseedRandomGenerator(1L);
//     boolean var22 = var10.isSupportLowerBoundInclusive();
//     double var23 = var10.getMean();
//     double var24 = var10.getSupportUpperBound();
//     double var25 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var10);
//     double[] var27 = var10.sample(214);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 7202896795L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-0.1064506032641524d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.723245967437971d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0.6471746481487741d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
// 
//   }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test192"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(-22));

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test193"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(0, 2.0f, 2.3841858E-7f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test194"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.getNumElements();
    double[] var2 = var0.getInternalValues();
    int var3 = var0.getNumElements();
    double[] var4 = var0.getInternalValues();
    var0.setContractionCriteria(7.5557864E22f);
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    var0.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test195"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)2.1991384700657077d);
    java.lang.Number var2 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0+ "'", var2.equals(0));

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test196"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(323293105, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 323293105);

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test197"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var7 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MaxCountExceededException var8 = new org.apache.commons.math3.exception.MaxCountExceededException(var5, (java.lang.Number)4.158638853279167d, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathIllegalArgumentException var9 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var4, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var3, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathIllegalArgumentException var11 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.NullArgumentException var12 = new org.apache.commons.math3.exception.NullArgumentException(var1, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test198() {}
//   public void test198() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test198"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeedSecure(0L);
//     long var6 = var1.nextSecureLong(3628800L, 10000000000L);
//     double var9 = var1.nextGamma(2.6498507619080125d, (-0.05788914687716099d));
//     org.apache.commons.math3.distribution.NormalDistribution var10 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var12 = var10.density(100.0d);
//     double var15 = var10.cumulativeProbability((-2.450405938642638d), 0.6139648708421599d);
//     double[] var17 = var10.sample(100);
//     double var18 = var10.getStandardDeviation();
//     boolean var19 = var10.isSupportUpperBoundInclusive();
//     var10.reseedRandomGenerator(1L);
//     boolean var22 = var10.isSupportLowerBoundInclusive();
//     double var23 = var10.getMean();
//     double var24 = var10.getSupportUpperBound();
//     double var25 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var10);
//     double var28 = var1.nextGamma(119.31703692887734d, 0.022957956056843462d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var31 = var1.nextSecureInt(85119429, 85119429);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2923606666L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-0.06991910812026675d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.723245967437971d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1.6293539540169057d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 2.8594483273837334d);
// 
//   }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test199"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm((-19), 1193);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 22667);

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test200"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(10230, 330);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10230);

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test201"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(0.565520528803286d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5120619428277815d);

  }

  public void test202() {}
//   public void test202() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test202"); }
// 
// 
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     double[] var3 = new double[] { 0.0d, 100.0d};
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     int var6 = var5.getNumElements();
//     double[] var7 = var5.getInternalValues();
//     double[] var10 = new double[] { 10.0d, 100.0d};
//     double var11 = var4.mannWhitneyU(var7, var10);
//     org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
//     double var13 = var0.mannWhitneyU(var3, var7);
//     org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
//     org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     int var17 = var16.getNumElements();
//     org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     int var19 = var18.getNumElements();
//     double[] var20 = var18.getInternalValues();
//     int var21 = var18.getNumElements();
//     double[] var22 = var18.getElements();
//     var16.addElements(var22);
//     float var24 = var16.getContractionCriteria();
//     org.apache.commons.math3.util.ResizableDoubleArray.copy(var14, var16);
//     double var27 = var16.addElementRolling(3.4965075614664802d);
//     float var28 = var16.getExpansionFactor();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var29 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     double[] var32 = new double[] { 0.0d, 100.0d};
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var33 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     org.apache.commons.math3.util.ResizableDoubleArray var34 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     int var35 = var34.getNumElements();
//     double[] var36 = var34.getInternalValues();
//     double[] var39 = new double[] { 10.0d, 100.0d};
//     double var40 = var33.mannWhitneyU(var36, var39);
//     org.apache.commons.math3.util.ResizableDoubleArray var41 = new org.apache.commons.math3.util.ResizableDoubleArray(var36);
//     double var42 = var29.mannWhitneyU(var32, var36);
//     org.apache.commons.math3.util.ResizableDoubleArray var43 = new org.apache.commons.math3.util.ResizableDoubleArray(var32);
//     org.apache.commons.math3.util.ResizableDoubleArray var44 = new org.apache.commons.math3.util.ResizableDoubleArray(var43);
//     double var46 = var43.substituteMostRecentElement(0.3742437696541317d);
//     org.apache.commons.math3.util.ResizableDoubleArray.copy(var16, var43);
//     org.apache.commons.math3.random.RandomGenerator var48 = null;
//     org.apache.commons.math3.random.RandomDataImpl var49 = new org.apache.commons.math3.random.RandomDataImpl(var48);
//     var49.reSeedSecure(0L);
//     long var54 = var49.nextSecureLong(3628800L, 10000000000L);
//     double var57 = var49.nextGamma(2.6498507619080125d, (-0.05788914687716099d));
//     org.apache.commons.math3.distribution.NormalDistribution var58 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var60 = var58.density(100.0d);
//     double var63 = var58.cumulativeProbability((-2.450405938642638d), 0.6139648708421599d);
//     double[] var65 = var58.sample(100);
//     double var66 = var58.getStandardDeviation();
//     boolean var67 = var58.isSupportUpperBoundInclusive();
//     var58.reseedRandomGenerator(1L);
//     boolean var70 = var58.isSupportLowerBoundInclusive();
//     double var71 = var58.getMean();
//     double var72 = var58.getSupportUpperBound();
//     double var73 = var49.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var58);
//     boolean var74 = var43.equals((java.lang.Object)var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 32.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 24.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 2.5f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 2.0f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 32.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 24.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == 6556930827L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == (-0.09094274887733673d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == 0.723245967437971d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var66 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var67 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var70 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var71 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var72 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var73 == (-0.33295515891979d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var74 == false);
// 
//   }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test203"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.9E-324d);

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test204"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.start();
    double var3 = var0.addElementRolling(4.937302184657956d);
    int var4 = var0.start();
    var0.contract();
    double[] var6 = var0.getInternalValues();
    var0.setExpansionMode(0);
    double[] var9 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    var10.contract();
    int var12 = var10.getExpansionMode();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test205"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(4350422056L, 29L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 126162239624L);

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test206"); }


    double[] var0 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(50);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var3);
    var1.contract();
    var1.addElement((-0.8307376748471434d));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.discardFrontElements(54);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test207() {}
//   public void test207() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test207"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextPascal(100, 0.0d);
//     var0.reSeedSecure(3520920158L);
//     int var8 = var0.nextInt((-1078420975), 124952017);
//     var0.reSeedSecure(2L);
//     double var12 = var0.nextChiSquare(1.6286532113855836d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var0.nextF(0.0d, 1.9117361753569404d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 92043723);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1.2775178490056947d);
// 
//   }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test208"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.3742437696541317d, var1, false);

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test209"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var2 = var1.getNumElements();
    double[] var3 = var1.getInternalValues();
    double[] var6 = new double[] { 10.0d, 100.0d};
    double var7 = var0.mannWhitneyU(var3, var6);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    int var9 = var8.getNumElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var11 = var8.getElement(16);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 16);

  }

  public void test210() {}
//   public void test210() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test210"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure(10L);
//     long var10 = var1.nextSecureLong(10L, 10000000000L);
//     int var13 = var1.nextSecureInt(0, 10);
//     int var16 = var1.nextPascal(506, 0.3063909472492726d);
//     double var20 = var1.nextUniform(0.8712503618849591d, 119.31703692887734d, true);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var24 = var1.nextHypergeometric(0, (-1865625573), (-241));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1969861790L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1187);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 112.45401569609729d);
// 
//   }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test211"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    java.lang.Class var3 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var4.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var4.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var7);
    java.lang.Class var9 = var6.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var11 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("MAXIMAL");
    java.lang.String var12 = var11.toString();
    org.apache.commons.math3.random.RandomGenerator var13 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11, var13);
    org.apache.commons.math3.stat.ranking.TiesStrategy var15 = var14.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var16 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var6, var15);
    org.apache.commons.math3.random.RandomGenerator var17 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var17);
    org.apache.commons.math3.stat.ranking.TiesStrategy var19 = var18.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var20 = var18.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var21 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20, var21);
    org.apache.commons.math3.random.RandomGenerator var23 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var23);
    org.apache.commons.math3.stat.ranking.TiesStrategy var25 = var24.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var26 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var20, var25);
    org.apache.commons.math3.stat.ranking.NaturalRanking var27 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var25);
    boolean var29 = var6.equals((java.lang.Object)0.8925913538795224d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "MAXIMAL"+ "'", var12.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test212"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(6398462632L, 4448708814L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10847171446L);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test213"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh((-21.679179376956384d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test214"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(7565329404133651603L, 5116033641L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7565329409249685244L);

  }

  public void test215() {}
//   public void test215() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test215"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     org.apache.commons.math3.exception.util.Localizable var3 = null;
//     org.apache.commons.math3.exception.util.Localizable var4 = null;
//     java.lang.Object[] var6 = new java.lang.Object[] { 'a'};
//     org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException(var4, var6);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var8 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, var6);
//     org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, var6);
//     org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, var6);
//     org.apache.commons.math3.exception.MathInternalError var11 = new org.apache.commons.math3.exception.MathInternalError(var0, var6);
//     org.apache.commons.math3.exception.util.ExceptionContext var12 = var11.getContext();
//     org.apache.commons.math3.exception.util.Localizable var13 = null;
//     org.apache.commons.math3.exception.util.Localizable var14 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy[] var15 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
//     org.apache.commons.math3.exception.MathIllegalArgumentException var16 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var14, (java.lang.Object[])var15);
//     java.lang.Throwable[] var17 = var16.getSuppressed();
//     org.apache.commons.math3.exception.MathIllegalStateException var18 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var11, var13, (java.lang.Object[])var17);
// 
//   }

  public void test216() {}
//   public void test216() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test216"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(91.16099711112008d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test217"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1.5690509993150914d, (java.lang.Number)2.4999998f, false);
    java.lang.Number var5 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 2.4999998f+ "'", var5.equals(2.4999998f));

  }

  public void test218() {}
//   public void test218() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test218"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var5 = var1.nextUniform(0.999987895021552d, 15.322095332102348d, false);
//     double var8 = var1.nextGamma(1.4713540043352986d, 4.787491742782046d);
//     int var11 = var1.nextBinomial(6, 9.865876450377004E-10d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var1.nextUniform(7.8492444081989055d, 0.4496655332118419d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 3.7673189560729528d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 10.679994014753348d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0);
// 
//   }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test219"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.MathInternalError var3 = new org.apache.commons.math3.exception.MathInternalError();
    java.lang.Throwable[] var4 = var3.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var5 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.MaxCountExceededException var6 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)9.437944169387807d, (java.lang.Object[])var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test220"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var2 = var0.density(100.0d);
    double var5 = var0.cumulativeProbability((-2.450405938642638d), 0.6139648708421599d);
    double var7 = var0.cumulativeProbability(0.6139648708421599d);
    boolean var8 = var0.isSupportLowerBoundInclusive();
    double var9 = var0.getSupportLowerBound();
    double var10 = var0.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.723245967437971d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.7303807294278502d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == Double.NEGATIVE_INFINITY);

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test221"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 9617852649L);
    java.math.BigInteger var5 = null;
    java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 0L);
    java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, 9617852649L);
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, var7);
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test222"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(3803035455L, (-5));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test223() {}
//   public void test223() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test223"); }
// 
// 
//     double var1 = org.apache.commons.math3.special.Gamma.logGamma((-6.495379117362055d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test224"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(9.0071987E15f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9.0071993E15f);

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test225"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    var0.reseedRandomGenerator(10L);
    double var4 = var0.density(1832.5694791909018d);
    double var6 = var0.cumulativeProbability(1.7145135182272309d);
    double var8 = var0.density(0.31331432837255024d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.9567827717396936d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.37983380872469885d);

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test226"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(0.8925913538795224d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9447705297475797d);

  }

  public void test227() {}
//   public void test227() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test227"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure();
//     int var9 = var1.nextInt((-15), 500);
//     org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution(1.7456204716704575d, 2.3136520775570846d);
//     double var13 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var12);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double[] var15 = var12.sample(268848753);
//       fail("Expected exception of type java.lang.OutOfMemoryError");
//     } catch (java.lang.OutOfMemoryError e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 194);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.487240063962978d);
// 
//   }

  public void test228() {}
//   public void test228() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test228"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeedSecure(0L);
//     long var6 = var1.nextSecureLong(3628800L, 10000000000L);
//     java.lang.String var8 = var1.nextHexString(500);
//     double var10 = var1.nextT(0.9584128699015102d);
//     var1.reSeed();
//     double var14 = var1.nextGaussian((-0.18001456817244066d), 9.298415193461524d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2800418217L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "5ff95037a9437e1aa1c1317d0b8584c4119896c32f70da14c7a591abc692b2b2e851272a5e46e632b15fead91caf23d141d742854f674ca42662648bf250c42d9923afe761bf75443637a717ff62c4d7cc9b2b048f910f3318828e3450eb22d07eebaf1f6d524261806e536b51b8df3f0498c383b7792f01ab4464c31a8334dfb3ebcf5e600abd8385daf5f13f1eb2c4d82b7ca4fa27450457054677f7646fdb7b42355acbbd3d0e6b04cf8a0811e48a53caff491fd46620a0af94a95a6d16946a64f8b75552e3a51727ff77a76e86549a9b8dcf47ef1b7d8bab97560fd8ae31160a2b7c7ae0a760d0afbf16d299b1d3300d32286a3571e0df52"+ "'", var8.equals("5ff95037a9437e1aa1c1317d0b8584c4119896c32f70da14c7a591abc692b2b2e851272a5e46e632b15fead91caf23d141d742854f674ca42662648bf250c42d9923afe761bf75443637a717ff62c4d7cc9b2b048f910f3318828e3450eb22d07eebaf1f6d524261806e536b51b8df3f0498c383b7792f01ab4464c31a8334dfb3ebcf5e600abd8385daf5f13f1eb2c4d82b7ca4fa27450457054677f7646fdb7b42355acbbd3d0e6b04cf8a0811e48a53caff491fd46620a0af94a95a6d16946a64f8b75552e3a51727ff77a76e86549a9b8dcf47ef1b7d8bab97560fd8ae31160a2b7c7ae0a760d0afbf16d299b1d3300d32286a3571e0df52"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.221903799035383d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-0.42972328521602565d));
// 
//   }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test229"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(7969628972L, (-856701739L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 8826330711L);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test230"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(5.960465E-8f, 100.49998f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5.960465E-8f);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test231"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(0.9997768398506297d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8413503899127969d);

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test232"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog((-124951999), (-17));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test233"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(96.04035976807448d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.126232353399055E41d);

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test234"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 9617852649L);
    java.math.BigInteger var5 = null;
    java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 0L);
    java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, 9617852649L);
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, var9);
    java.math.BigInteger var11 = null;
    java.math.BigInteger var13 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, 0L);
    java.math.BigInteger var15 = org.apache.commons.math3.util.ArithmeticUtils.pow(var13, 9617852649L);
    java.math.BigInteger var16 = null;
    java.math.BigInteger var18 = org.apache.commons.math3.util.ArithmeticUtils.pow(var16, 0L);
    java.math.BigInteger var20 = org.apache.commons.math3.util.ArithmeticUtils.pow(var18, 9617852649L);
    java.math.BigInteger var21 = org.apache.commons.math3.util.ArithmeticUtils.pow(var15, var18);
    java.math.BigInteger var23 = org.apache.commons.math3.util.ArithmeticUtils.pow(var15, 5002023);
    java.math.BigInteger var25 = org.apache.commons.math3.util.ArithmeticUtils.pow(var15, 0);
    java.math.BigInteger var26 = null;
    java.math.BigInteger var28 = org.apache.commons.math3.util.ArithmeticUtils.pow(var26, 0L);
    java.math.BigInteger var30 = org.apache.commons.math3.util.ArithmeticUtils.pow(var28, 9617852649L);
    java.math.BigInteger var31 = null;
    java.math.BigInteger var33 = org.apache.commons.math3.util.ArithmeticUtils.pow(var31, 0L);
    java.math.BigInteger var35 = org.apache.commons.math3.util.ArithmeticUtils.pow(var33, 9617852649L);
    java.math.BigInteger var36 = org.apache.commons.math3.util.ArithmeticUtils.pow(var30, var33);
    java.math.BigInteger var38 = org.apache.commons.math3.util.ArithmeticUtils.pow(var30, 2147483647);
    java.math.BigInteger var40 = org.apache.commons.math3.util.ArithmeticUtils.pow(var38, 6949188755L);
    java.math.BigInteger var41 = org.apache.commons.math3.util.ArithmeticUtils.pow(var25, var38);
    java.math.BigInteger var42 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, var41);
    java.math.BigInteger var43 = null;
    java.math.BigInteger var45 = org.apache.commons.math3.util.ArithmeticUtils.pow(var43, 0L);
    java.math.BigInteger var47 = org.apache.commons.math3.util.ArithmeticUtils.pow(var45, 9617852649L);
    java.math.BigInteger var48 = null;
    java.math.BigInteger var50 = org.apache.commons.math3.util.ArithmeticUtils.pow(var48, 0L);
    java.math.BigInteger var52 = org.apache.commons.math3.util.ArithmeticUtils.pow(var50, 9617852649L);
    java.math.BigInteger var53 = org.apache.commons.math3.util.ArithmeticUtils.pow(var47, var50);
    org.apache.commons.math3.exception.util.Localizable var54 = null;
    java.math.BigInteger var55 = null;
    java.math.BigInteger var57 = org.apache.commons.math3.util.ArithmeticUtils.pow(var55, 0L);
    java.math.BigInteger var59 = org.apache.commons.math3.util.ArithmeticUtils.pow(var57, 9617852649L);
    java.math.BigInteger var60 = null;
    java.math.BigInteger var62 = org.apache.commons.math3.util.ArithmeticUtils.pow(var60, 0L);
    java.math.BigInteger var64 = org.apache.commons.math3.util.ArithmeticUtils.pow(var62, 9617852649L);
    java.math.BigInteger var65 = org.apache.commons.math3.util.ArithmeticUtils.pow(var59, var62);
    java.math.BigInteger var67 = org.apache.commons.math3.util.ArithmeticUtils.pow(var59, 2147483647);
    java.math.BigInteger var69 = org.apache.commons.math3.util.ArithmeticUtils.pow(var67, 6949188755L);
    java.lang.Number var70 = null;
    org.apache.commons.math3.exception.OutOfRangeException var72 = new org.apache.commons.math3.exception.OutOfRangeException(var54, (java.lang.Number)var69, var70, (java.lang.Number)9.332621544395286E157d);
    java.math.BigInteger var74 = org.apache.commons.math3.util.ArithmeticUtils.pow(var69, 0L);
    java.math.BigInteger var75 = org.apache.commons.math3.util.ArithmeticUtils.pow(var47, var74);
    java.math.BigInteger var76 = null;
    java.math.BigInteger var78 = org.apache.commons.math3.util.ArithmeticUtils.pow(var76, 0L);
    java.math.BigInteger var80 = org.apache.commons.math3.util.ArithmeticUtils.pow(var78, 9617852649L);
    java.math.BigInteger var81 = null;
    java.math.BigInteger var83 = org.apache.commons.math3.util.ArithmeticUtils.pow(var81, 0L);
    java.math.BigInteger var85 = org.apache.commons.math3.util.ArithmeticUtils.pow(var83, 9617852649L);
    java.math.BigInteger var86 = org.apache.commons.math3.util.ArithmeticUtils.pow(var80, var83);
    java.math.BigInteger var88 = org.apache.commons.math3.util.ArithmeticUtils.pow(var80, 2147483647);
    java.math.BigInteger var89 = org.apache.commons.math3.util.ArithmeticUtils.pow(var75, var88);
    java.math.BigInteger var90 = org.apache.commons.math3.util.ArithmeticUtils.pow(var42, var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test235"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)12.107341960671128d);
    java.lang.Throwable[] var2 = var1.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test236"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    java.lang.Object[] var8 = new java.lang.Object[] { 'a'};
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException(var6, var8);
    org.apache.commons.math3.exception.MathIllegalArgumentException var10 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var5, var8);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException(var4, var8);
    org.apache.commons.math3.exception.MathArithmeticException var12 = new org.apache.commons.math3.exception.MathArithmeticException(var3, var8);
    org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, var8);
    org.apache.commons.math3.exception.NullArgumentException var14 = new org.apache.commons.math3.exception.NullArgumentException(var1, var8);
    org.apache.commons.math3.exception.MathArithmeticException var15 = new org.apache.commons.math3.exception.MathArithmeticException(var0, var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test237"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog((-241), 97);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test238"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm((-7), 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 700);

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test239"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(1209);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1209);

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test240"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(1.9865549713026993d, 1.9663350948551348d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.9865549713026993d);

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test241"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(2.151922915279175d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.766361821620427d);

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test242"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var3 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var6 = var5.getNumElements();
    double[] var7 = var5.getInternalValues();
    double[] var10 = new double[] { 10.0d, 100.0d};
    double var11 = var4.mannWhitneyU(var7, var10);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    double var13 = var0.mannWhitneyU(var3, var7);
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var17 = var16.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var19 = var18.getNumElements();
    double[] var20 = var18.getInternalValues();
    int var21 = var18.getNumElements();
    double[] var22 = var18.getElements();
    var16.addElements(var22);
    float var24 = var16.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var14, var16);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var14.setElement((-5), 0.0d);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2.5f);

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test243"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(10, 99.99999f);
    int var3 = var2.start();
    var2.addElement(0.0d);
    var2.setElement(394, 100.0d);
    int var9 = var2.getExpansionMode();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setNumElements((-2141825230));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test244"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient((-1079733723), 448);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test245() {}
//   public void test245() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test245"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ((-0.10720322305192957d), 0.40522203508786114d, 265.1311544829649d, 109);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test246() {}
//   public void test246() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test246"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure(10L);
//     long var10 = var1.nextSecureLong(10L, 10000000000L);
//     int var13 = var1.nextSecureInt(0, 10);
//     int var16 = var1.nextPascal(506, 0.3063909472492726d);
//     double var18 = var1.nextChiSquare(0.8546260963462944d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 2340484561L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1161);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.7702952051223313d);
// 
//   }

  public void test247() {}
//   public void test247() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test247"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var5 = var1.nextUniform(0.999987895021552d, 15.322095332102348d, false);
//     double var8 = var1.nextGamma(1.4713540043352986d, 4.787491742782046d);
//     double var11 = var1.nextCauchy(0.0d, 0.3347073545163447d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 7.8783448655998d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 4.780989662021378d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.21179056725289996d);
// 
//   }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test248"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("4079b478d2bd8352d8a4ab65b3b0cefcbdf9f931e5efec62893688bdd3ec7bc2fc7c9b931beacfcde85256cf26e26fefae365ec7e044ff8f8dac85288c70e9ed1a582d0295739bf97edeb82c16577a04bddac03b5c7dbdbe4fa4f55b07c9ea54f8414b24479dea808dbae92571f4bf6ed55c19e141af6e5debac4b679dcb5ef2f9e0ba93b7f28bc41af062ac03823827f3c7202a530c7b53e2c0110364038c3c3ee4186585bf7d68500defbc8b1999467fdcaae2318a972be2f62aec276af177508e3003842e85c06b9100cd902ea9e2d5700b0e8b9287c3372188ecf714ea104b7a76fea6e529c97783d49e3012077f80dba50c030e48580787");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test249"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(1967051285, 1161);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1161);

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test250"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    java.lang.Class var3 = var2.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var5 = java.lang.Enum.<java.lang.Enum>valueOf(var3, "a3996fca1b7852cff8fae31c257f2d9cd46cffe73d11ae03222c86d6b1abe57fc6903a15ab31b03d83175ce55aff6a3b0f428c68ca2d3d01a6f34fc5adab8068ae18f59ffbcd08b3a0e77c1e5797d63f215c7f830621498581c28f08e14e2610ad9f91a74611f8307f523f7d2041533b4c9779ba640cdcfc1d0005159c14d081fa683653fd3f2adf45d5f365a5cebcdbf97b55795e897a4fac8c9c10c02037d95f04f0c0158a8ffb85facd1648dd08c796af3050ab8d58b4447f6476c0fede31f5847b64d6c6287675a5e8380f341d8eb96135dacf3efd85175fb0d75e693e002aef56d0c9e6f843cf8b6905e40ed6920f72cdfafdbb0c84c01e115c60193aff8f747b9c50165200a7cc2efea937009f994183e2f982e7fed4a027ac9ab55b253128aea6a39a9b3e7787c7ef8a0a413b62f89dd30d8c54cd45b3ac4c936af3a1d5fa41896d414d084cddfc53e39fa905a81519ef0508a4e9c0e468f843fe9dcfcbcc00512b59db12d1834b1e20766e4f758d1d3bd0da0fea44949c3b6d0dbf10f1aa36e6acc63533782dad776a1a5a0de4b1170bece7397e79d69814289ecef09b81c9a3fe9d073cfbfb86f78567baf0488e4d4ce56376c1c7f60b82f01b3a30c65ce6e735b5ec4a57e1580daac208b7aa04bc812df1b317f29ce789215aa6de6465bb42b512b9faf6c985dcde48d46e3e83908fe8cf19c867f431ef212fe1ffbd80a47a24e638fe3a917a7f2216e04d835013f6ac2f3dda5d1eaeec62230bcf5d774ef2a3cf6af2858adcfb1a4add324e1a7e845c6b214a7425aa1d087cd59007c62cc0611e27af344a1e59b4a5062d76926a7ee13c7de46691707617e1c2c8ddc44477eed700069e4868ac5ee5fd8e56021cdebfc8624e8f77db96e4dda9d45b2380dcf86a0c8303887fb0ff65ed14d9adf6068db27e99946f8f079384de280f589e6211d58016f3fd11d34b284e697e02423dd51c467d7e30ab0c3f201d82911767f64173162c55397b5b9a7870dd628dbf2e652958643df3a9de8ded6f1c57b700e98932280deab4b6edecb0c7dd28fbf5fd5202a902856c415a991f3aaede8f0b88f697fbd73188f2c368f972bc3141d79d7b5aa3e7beafaeb6395fbe812f161658fbf592e389bb6e2659d58950c7a04a6539c7106c044c8c0bbf6ebb7259877c2a5999d8b2eff662a4d37da15c8561fd98e17536129199d2fc0451470053ad33b69f54b2668e01d43cecca729709992b9e8a9fe8527dac011f9da8f21912402106335b546dda930de8c759b3777208a0264848730aa0ec829b1f93eea2c834d421d949bce750f811d2e8a5edc852bd708aa5d7db64564a87c1ef77bb04fe12dc4f17a92c32fdcacd57f2c7ae6e27796c52693a0677e3e5ecf7de8bb2af401d1dffaaef3d0b45d3e395947aab896c20b5d31de64de5c684080a7a1a960780e55457376c9481e7992ee1cc9547978b80e5b75f03300334244e7e625d77a3f9cfba521bc5e418bd5f76afa5cb9bc7a1fcc3bb022073d9f7f8b9d851a168b3d83abea448d86e1d40d64c6f0b68cb53c23012a9aa67d7876c6b4dbc94063fdc0ac462e7d3259b02815436ba277fdbda322f400c4a2251faebbbd15381eadac3ed8b770eb469802e782eef0d445c3983b23318835faf69796fd865d17e4a0a1a6fa3c40678bef2b8b53e2a71a8bc4acecfe944b8329bf48b902480492e107f174e19417f572f8a7d58f63b675328663705a4987c34a6116489b19e2b0a91bf2466922ec77defea3c3dc3675b52efc7a3493f3e014a7bcff80c2677555f9284986c57f500073c269e672f4d0ebf2f296f8e193ea6b6fe8ed41a593455788849d74289b41c39fb8c96366fe4052d04702d19a8bc69a45c92f03206317b6242a3f4235f3075dab48ab2ad7e42c4291ff9fddfc9e450932a6d5b0dd774187275fd50bf6f7688c790c1ad19367c9749791327a9018a6896e46418b533f7f0d42b94a5fa920daba231a8149951bc08211c17c3912a628c9f1d4b206bee80f8a0e348ccca2dbb6926d9d07dc44346a6490bedf61e03f99510eaf22677aceae36e804b82a92eea08fd97a2769cd4bb8f9d289103f457516fbb8e9e9827feb522f04087dcff4f206fddedbd31f5cc78b6b6084087ab08ceefa4536b0dbf848833443f119b979f64f747b0d819e58bbe30b14d5fe04ff84d122df86ce316dc87337f8b9b0136028159e3a6d581dba8b844fc0c8b47423c7abc8b8aeb2a0eb66bbc68c93e9995b8b24a9bbaf74c9370d3d01f9f9f25882197bc7530f2b9336e6d77c1f7b2548c84c90613d97035d3d45a170bcbe5de587e3060a6b9c62d5bd97a6af3f1421275689c8b769b0baad8740f628b31b3a9f98d70ed10934e62b6f409d5d23e09b81cfcf8811c3cf4d0814326c011300a3494442d781710b36e868161851ec5f2e3767c132452cebb3bbe4c3bdcf00bd466a183050f18feefd018153bd0df5ee2678bc5a6e178b6260983d0d30196b885e9144d75f04f847527d5");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test251"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    var1.reSeed();
    double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setSecureAlgorithm("org.apache.commons.math3.exception.NumberIsTooLargeException: -5 is larger than, or equal to, the maximum (1.987)", "ae680aafce4678b563633337dcf0d94be00b43d269864cbbf08aaca8a573f7fc2cdc43b");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test252"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(54.52604484490294d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.384175298901221d);

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test253"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(0.9999999f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.9604645E-8f);

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test254"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(2.6605288489275627d, 0.3971622936791505d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.6605288489275623d);

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test255"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(1.3648793247295046d, 99.85091339688786d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.01366832090256127d);

  }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test256"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(1663.1795900889629d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test257"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.313946227505687d, 4.484958451919815d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.484958451919815d);

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test258"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getMean();
    double var4 = var0.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
    double var5 = var0.getSupportUpperBound();
    double var7 = var0.probability(Double.NEGATIVE_INFINITY);
    double var9 = var0.probability(Double.POSITIVE_INFINITY);
    double var10 = var0.getNumericalMean();
    var0.reseedRandomGenerator(664646591L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.5230558330643571d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test259"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var2 = var0.addElementRolling(Double.NaN);
    double[] var3 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setNumElements(613865270);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test260"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)31);

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test261"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getMean();
    double var3 = var0.probability(2.483316528028045d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test262"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    java.lang.Class var3 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var4.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var4.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.NaNStrategy var9 = var8.getNanStrategy();
    int var10 = var9.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var9);
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12);
    org.apache.commons.math3.stat.ranking.NaNStrategy var14 = var13.getNanStrategy();
    java.lang.Class var15 = var14.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var14);
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var9, var17);
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var17);
    org.apache.commons.math3.stat.ranking.NaNStrategy var20 = var19.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var21 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var21);
    org.apache.commons.math3.stat.ranking.NaNStrategy var23 = var22.getNanStrategy();
    java.lang.Class var24 = var23.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var25 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var23);
    org.apache.commons.math3.stat.ranking.TiesStrategy var26 = var25.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var27 = var25.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var28 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var29 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var28);
    org.apache.commons.math3.stat.ranking.NaNStrategy var30 = var29.getNanStrategy();
    int var31 = var30.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var32 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var30);
    org.apache.commons.math3.stat.ranking.TiesStrategy var33 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var34 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var33);
    org.apache.commons.math3.stat.ranking.NaNStrategy var35 = var34.getNanStrategy();
    java.lang.Class var36 = var35.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var37 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var35);
    org.apache.commons.math3.stat.ranking.TiesStrategy var38 = var37.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var39 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var30, var38);
    org.apache.commons.math3.stat.ranking.NaturalRanking var40 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var27, var38);
    java.lang.String var41 = var38.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var42 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var20, var38);
    java.lang.String var43 = var20.name();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var41 + "' != '" + "AVERAGE"+ "'", var41.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var43 + "' != '" + "MAXIMAL"+ "'", var43.equals("MAXIMAL"));

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test263"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.039720900659592454d, (-9.959280125179879d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.03972090065959245d);

  }

  public void test264() {}
//   public void test264() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test264"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextBeta(572.2646479502633d, 0.07637989519631011d);
//     double var8 = var1.nextGamma(4.937302184657956d, 97.98819663162894d);
//     var1.reSeed();
//     java.util.Collection var10 = null;
//     java.lang.Object[] var12 = var1.nextSample(var10, (-1438535053));
// 
//   }

  public void test265() {}
//   public void test265() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test265"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Throwable var2 = null;
//     org.apache.commons.math3.exception.util.Localizable var3 = null;
//     org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError();
//     java.lang.Throwable[] var5 = var4.getSuppressed();
//     org.apache.commons.math3.exception.MathIllegalStateException var6 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, var3, (java.lang.Object[])var5);
//     org.apache.commons.math3.exception.MaxCountExceededException var7 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)(short)(-1), (java.lang.Object[])var5);
//     org.apache.commons.math3.exception.util.ExceptionContext var8 = var7.getContext();
//     java.lang.String var9 = var7.toString();
// 
//   }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test266"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Object[] var5 = new java.lang.Object[] { 'a'};
    org.apache.commons.math3.exception.MathIllegalStateException var6 = new org.apache.commons.math3.exception.MathIllegalStateException(var3, var5);
    org.apache.commons.math3.exception.MathIllegalArgumentException var7 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, var5);
    org.apache.commons.math3.exception.MathIllegalArgumentException var8 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, var5);
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var0, var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test267"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    var1.reSeed();
    double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
    var1.reSeedSecure(10L);
    var1.reSeedSecure();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test268"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(1.2330506708687499d, 0.8925913538795224d, 200.94444231998796d);
    boolean var4 = var3.isSupportConnected();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test269"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    java.lang.Class var3 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var4.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var4.getTiesStrategy();
    int var7 = var6.ordinal();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 3);

  }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test270"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(9.857440630569243d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.3019916496153634d);

  }

  public void test271() {}
//   public void test271() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test271"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP((-0.2813585913101566d), 0.8835772395603834d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test272"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var2 = var0.addElementRolling(Double.NaN);
    double[] var3 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var6.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var11 = var9.addElementRolling(Double.NaN);
    double[] var12 = var9.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray(var12);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var6, var13);
    double[] var15 = var6.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray(var15);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var17 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var19 = var18.getNumElements();
    double[] var20 = var18.getInternalValues();
    double[] var23 = new double[] { 10.0d, 100.0d};
    double var24 = var17.mannWhitneyU(var20, var23);
    var16.addElements(var23);
    var5.addElements(var23);
    var5.discardFrontElements(0);
    var5.addElement(9.185979303078355E-72d);
    var5.setElement(2, 363.7393755555636d);
    double[] var34 = var5.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var35 = new org.apache.commons.math3.util.ResizableDoubleArray(var5);
    var5.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test273"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getNumericalMean();
    double var3 = var0.cumulativeProbability(2.5242623302161973d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var6 = var0.cumulativeProbability(1.3676737152612983d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9942029313130951d);

  }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test274"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.0017936994010819291d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999983913216606d);

  }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test275"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(2.676950074612442d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.2359525151849855d);

  }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test276"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(183);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test277"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(323293105, 1078421185);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1401714290);

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test278"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.start();
    double var3 = var0.addElementRolling(4.937302184657956d);
    int var4 = var0.start();
    var0.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var0.copy();
    var0.setElement(101794, 2.5242623302161973d);
    int var10 = var0.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);

  }

  public void test279() {}
//   public void test279() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test279"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ((-0.6932391748384723d), 99.43619666475817d, 12.368444582022025d, (-343670429));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test280"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.getNumElements();
    double[] var2 = var0.getInternalValues();
    int var3 = var0.getNumElements();
    var0.setNumElements(300);
    double var7 = var0.substituteMostRecentElement(2.2924316695611777d);
    float var8 = var0.getExpansionFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.0f);

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test281"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-124.8212095970895d));
    java.lang.Number var2 = var1.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + (-124.8212095970895d)+ "'", var2.equals((-124.8212095970895d)));

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test282"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(44.0d, 6.5895866800733485d, 0.5985964988634461d);
    double var5 = var3.cumulativeProbability(572.2646479502633d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test283"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(0.017341002062646303d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.13168523859053566d);

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test284"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(1.0000004f, (-1.2676504E30f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.2676504E30f));

  }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test285"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.0000000000000004d);

  }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test286"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(0.8925913538795224d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4414481171135787d);

  }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test287"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0.9593544142434495d);

  }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test288"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.getNumElements();
    int var2 = var0.start();
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var4 = var3.getNumElements();
    double[] var5 = var3.getInternalValues();
    int var6 = var3.getNumElements();
    double[] var7 = var3.getElements();
    var0.addElements(var7);
    var0.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(10, 99.99999f);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var12);
    var12.setElement(825, (-0.06991186090907374d));
    double[] var17 = var12.getElements();
    var12.addElement((-0.2658092704850752d));
    var12.addElement((-0.0930249421650573d));
    var12.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test289"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(0.5805372892796278d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.41164415614413374d);

  }

  public void test290() {}
//   public void test290() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test290"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure(10L);
//     long var10 = var1.nextSecureLong(10L, 10000000000L);
//     double var13 = var1.nextUniform(0.9999943487368532d, 44.5140274520795d);
//     double var16 = var1.nextGaussian((-0.8887853505857057d), 2.882619330995207E-19d);
//     double var20 = var1.nextUniform(0.28278970417533067d, 0.47213820417373314d, false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 2357860793L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 24.773719961825176d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == (-0.8887853505857057d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.3542794217077332d);
// 
//   }

  public void test291() {}
//   public void test291() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test291"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(210.0d, 0.9984187364052811d);
//     double var4 = var2.probability((-0.010152952316618155d));
//     double var5 = var2.sample();
//     double var6 = var2.sample();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 211.48978878059862d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 211.01885291175253d);
// 
//   }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test292"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(0.8948278522683608d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9459534091425227d);

  }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test293"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(0.5f, 800.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.5f);

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test294"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(-5.2969878277335525d), (java.lang.Number)2.0107520380478325d, (java.lang.Number)0.5040503723628342d);
    java.lang.Number var4 = var3.getHi();
    java.lang.Number var5 = var3.getLo();
    java.lang.Number var6 = var3.getArgument();
    java.lang.Number var7 = var3.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0.5040503723628342d+ "'", var4.equals(0.5040503723628342d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 2.0107520380478325d+ "'", var5.equals(2.0107520380478325d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (-5.2969878277335525d)+ "'", var6.equals((-5.2969878277335525d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 2.0107520380478325d+ "'", var7.equals(2.0107520380478325d));

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test295"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getMean();
    double var4 = var0.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
    double var5 = var0.getNumericalVariance();
    var0.reseedRandomGenerator(100L);
    double var9 = var0.cumulativeProbability(1.0383512298650577d);
    double var10 = var0.getStandardDeviation();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.5230558330643571d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.8504467169183425d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1.0d);

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test296"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var4 = var1.nextSecureInt(1000, (-241));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test297"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(50);
    double[] var2 = var1.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var3.substituteMostRecentElement(8.112963841460668E31d);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException");
    } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test298"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 9617852649L);
    java.math.BigInteger var5 = null;
    java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 0L);
    java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, 9617852649L);
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, var7);
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 2147483647);
    org.apache.commons.math3.exception.OutOfRangeException var15 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)var12, (java.lang.Number)(-0.057760248426621384d), (java.lang.Number)0.6227605565158021d);
    java.lang.Number var16 = var15.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test299"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var2 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)4.898979485566356d);
    java.lang.Number var3 = var2.getMax();
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    java.lang.Object[] var8 = null;
    org.apache.commons.math3.exception.MathArithmeticException var9 = new org.apache.commons.math3.exception.MathArithmeticException(var7, var8);
    java.lang.Throwable[] var10 = var9.getSuppressed();
    org.apache.commons.math3.exception.MathInternalError var11 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.NullArgumentException var12 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var2, var4, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.MathIllegalStateException var14 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 4.898979485566356d+ "'", var3.equals(4.898979485566356d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test300"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(3.714269324833091d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 41.028597552059324d);

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test301"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    java.lang.Class var3 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var4.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    java.lang.Class var7 = var5.getDeclaringClass();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test302"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(99L, 4816542093L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4816542093L);

  }

  public void test303() {}
//   public void test303() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test303"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure();
//     int var9 = var1.nextInt((-15), 500);
//     double var12 = var1.nextBeta(98.00138274241472d, 0.9984187364052811d);
//     double var15 = var1.nextUniform(4.61512051684126d, 57.348154628338996d);
//     int var18 = var1.nextSecureInt(0, 2147483647);
//     double var20 = var1.nextExponential(0.9942029313130951d);
//     org.apache.commons.math3.random.RandomGenerator var21 = null;
//     org.apache.commons.math3.random.RandomDataImpl var22 = new org.apache.commons.math3.random.RandomDataImpl(var21);
//     var22.reSeed();
//     double var26 = var22.nextGamma(0.0d, 29.9749466411613d);
//     double var29 = var22.nextWeibull(0.7853981633974483d, 4.787491742782046d);
//     double var31 = var22.nextExponential(0.3971622936791505d);
//     org.apache.commons.math3.distribution.NormalDistribution var32 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var33 = var32.getNumericalMean();
//     double var34 = var32.getStandardDeviation();
//     boolean var35 = var32.isSupportLowerBoundInclusive();
//     double var36 = var32.getSupportLowerBound();
//     double var37 = var32.getSupportLowerBound();
//     double var38 = var32.getMean();
//     boolean var39 = var32.isSupportConnected();
//     double var40 = var22.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var32);
//     double var41 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var32);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var43 = var1.nextExponential((-21.679179376956384d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 414);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.9976161367103712d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 55.857921726202974d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 532146145);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.3007913651659425d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 2.765442378943446d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 0.6017704958326527d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 1.1567116225650014d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == (-0.4130101978699978d));
// 
//   }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test304"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(100.4467786738112d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.202248230583609E43d);

  }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test305"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(1.907349E-6f, 1.9073489E-6f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.9073489E-6f);

  }

  public void test306() {}
//   public void test306() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test306"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.5607966601082315d);
//     org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var5 = var3.density(100.0d);
//     double var8 = var3.cumulativeProbability((-2.450405938642638d), 0.6139648708421599d);
//     double[] var10 = var3.sample(100);
//     double var11 = var3.getStandardDeviation();
//     double var13 = var3.cumulativeProbability((-0.004920366423301847d));
//     double var14 = var3.getNumericalVariance();
//     double var15 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var3);
//     java.lang.String var17 = var0.nextHexString(101794);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var20 = var0.nextPascal(736063294, 99.85091339688786d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2.8814224428430815d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.723245967437971d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.4980370657191222d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-0.6786742304579982d));
// 
//   }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test307"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Throwable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError();
    java.lang.Throwable[] var5 = var4.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var6 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, var3, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.NullArgumentException var7 = new org.apache.commons.math3.exception.NullArgumentException(var1, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MathArithmeticException var8 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.util.ExceptionContext var9 = var8.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test308"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(2.273737E-13f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.273737E-13f);

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test309"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)3773985329L, var2, (java.lang.Number)0.09149003776674126d);
    java.lang.Number var5 = var4.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test310"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("5bef577f35ddf8ecdc84f1c9a5c01fd7b876182ec9e497785283677666c7f2d71ddb02d473b817a3e43845521c1dcb72f4651c559cd05c84ecddd4f161a3177255105194d40ab022fcfe502d4ff9a56804b9d2c8eec47592d7fa06b234d7d9dd48c9e10488ffaf3a3a7427992434bb4ef306ee91e5f702e654866fa24aca43cc34bf5124232227ee34524a041e2b406fcd7a9f93269d95ba2a3630dac6aceb4209d09fade406d8a3923b2089388358be2456590ff8515bc2f40");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test311() {}
//   public void test311() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test311"); }
// 
// 
//     org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     var0.discardFrontElements(0);
//     org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     int var4 = var3.getNumElements();
//     double[] var5 = var3.getInternalValues();
//     int var6 = var3.getNumElements();
//     double[] var7 = var3.getElements();
//     var3.setExpansionMode(0);
//     var3.addElement(0.0d);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var12 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var14 = var13.getNanStrategy();
//     int var15 = var14.ordinal();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var14);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var17 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var17);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var19 = var18.getNanStrategy();
//     java.lang.Class var20 = var19.getDeclaringClass();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var19);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var22 = var21.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var14, var22);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var24 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
//     org.apache.commons.math3.util.ResizableDoubleArray var25 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     int var26 = var25.getNumElements();
//     double[] var27 = var25.getInternalValues();
//     double[] var30 = new double[] { 10.0d, 100.0d};
//     double var31 = var24.mannWhitneyU(var27, var30);
//     double[] var32 = var23.rank(var30);
//     var3.addElements(var30);
//     org.apache.commons.math3.util.ResizableDoubleArray var34 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     int var35 = var34.start();
//     double var37 = var34.addElementRolling(4.937302184657956d);
//     int var38 = var34.start();
//     var34.contract();
//     double[] var40 = var34.getInternalValues();
//     var34.setExpansionMode(0);
//     org.apache.commons.math3.util.ResizableDoubleArray.copy(var3, var34);
//     var34.clear();
//     boolean var45 = var0.equals((java.lang.Object)var34);
//     org.apache.commons.math3.random.RandomGenerator var46 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var47 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var46);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var48 = var47.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var49 = var47.getNanStrategy();
//     org.apache.commons.math3.random.RandomGenerator var50 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var51 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var49, var50);
//     org.apache.commons.math3.random.RandomGenerator var52 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var53 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var49, var52);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var54 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy var55 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var56 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var55);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var57 = var56.getNanStrategy();
//     int var58 = var57.ordinal();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var59 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var57);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var60 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var61 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var60);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var62 = var61.getNanStrategy();
//     java.lang.Class var63 = var62.getDeclaringClass();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var64 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var62);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var65 = var64.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var66 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var57, var65);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var67 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var54, var65);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var68 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var49, var65);
//     org.apache.commons.math3.distribution.NormalDistribution var69 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var70 = var69.getMean();
//     double var73 = var69.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
//     double var74 = var69.getSupportUpperBound();
//     double[] var76 = var69.sample(371);
//     org.apache.commons.math3.random.RandomGenerator var77 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var78 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var77);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var79 = var78.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var80 = var78.getNanStrategy();
//     org.apache.commons.math3.random.RandomGenerator var81 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var82 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var80, var81);
//     org.apache.commons.math3.util.ResizableDoubleArray var83 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     int var84 = var83.start();
//     double var86 = var83.addElementRolling(4.937302184657956d);
//     int var87 = var83.start();
//     var83.contract();
//     double[] var89 = var83.getInternalValues();
//     double[] var90 = var82.rank(var89);
//     double var91 = var68.mannWhitneyUTest(var76, var89);
//     var0.addElements(var89);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 32.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var70 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var73 == 0.5230558330643571d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var74 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var79);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var84 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var86 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var87 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var89);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var90);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var91 == 0.9369108120974312d);
// 
//   }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test312"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.13035934721721523d, 0.004409706426562607d, 0.0d);
    double var4 = var3.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.13035934721721523d);

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test313"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-1079733669), 16938270);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1062795399));

  }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test314"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(0.5919185321270688d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.22773806267296712d));

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test315"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(7612302794L, 7208084573L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 404218221L);

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test316"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Object[] var3 = new java.lang.Object[] { 'a'};
    org.apache.commons.math3.exception.MathIllegalStateException var4 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, var3);
    org.apache.commons.math3.exception.MathIllegalArgumentException var5 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var3);
    org.apache.commons.math3.exception.MathArithmeticException var6 = new org.apache.commons.math3.exception.MathArithmeticException();
    var5.addSuppressed((java.lang.Throwable)var6);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    java.lang.Number var10 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var12 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var8, (java.lang.Number)100L, var10, true);
    var6.addSuppressed((java.lang.Throwable)var12);
    org.apache.commons.math3.exception.util.ExceptionContext var14 = var6.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test317"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)2.2758399662530553d, (java.lang.Number)99, false);

  }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test318"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh((-12.844009081315292d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 189257.14043550452d);

  }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test319"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)1.3209627005516584d, (java.lang.Number)441.3272391075624d, false);

  }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test320"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Object[] var6 = new java.lang.Object[] { 'a'};
    org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException(var4, var6);
    org.apache.commons.math3.exception.MathIllegalArgumentException var8 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, var6);
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, var6);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var1, var6);
    org.apache.commons.math3.exception.MathInternalError var11 = new org.apache.commons.math3.exception.MathInternalError(var0, var6);
    org.apache.commons.math3.exception.util.ExceptionContext var12 = var11.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test321() {}
//   public void test321() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test321"); }
// 
// 
//     org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     int var1 = var0.start();
//     double var3 = var0.addElementRolling(4.937302184657956d);
//     int var4 = var0.start();
//     var0.contract();
//     org.apache.commons.math3.util.ResizableDoubleArray var6 = var0.copy();
//     var0.setNumElements(5);
//     org.apache.commons.math3.random.RandomGenerator var9 = null;
//     org.apache.commons.math3.random.RandomDataImpl var10 = new org.apache.commons.math3.random.RandomDataImpl(var9);
//     var10.reSeedSecure(0L);
//     long var15 = var10.nextSecureLong(3628800L, 10000000000L);
//     var10.reSeed((-2502316609L));
//     double var20 = var10.nextGaussian(1.7427271998994087d, 0.8266429039966963d);
//     double var22 = var10.nextChiSquare(0.5552592332346065d);
//     boolean var23 = var0.equals((java.lang.Object)var10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var26 = var10.nextF((-0.10165690958607404d), 0.8524481817025479d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 7516468565L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1.0242563501897255d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1.3719042446880644E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == false);
// 
//   }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test322"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, (-0.5788982422751958d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test323"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble(141);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.8981437590762873E243d);

  }

  public void test324() {}
//   public void test324() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test324"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure();
//     var1.reSeed();
//     double var10 = var1.nextBeta(31.984371183438952d, 3.141592653589793d);
//     double var13 = var1.nextCauchy(0.9400207386800911d, 1.978735975787224d);
//     int var16 = var1.nextInt((-15), 3);
//     long var18 = var1.nextPoisson(32.53142185860535d);
//     int var21 = var1.nextSecureInt(211, 268848753);
//     int var24 = var1.nextBinomial(71, 0.9685908209500688d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.9484645767878693d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 2.3630394756202127d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 40L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 208479565);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 69);
// 
//   }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test325"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var5 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(byte)(-1), (java.lang.Number)(short)1, true);
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    org.apache.commons.math3.exception.util.Localizable var11 = null;
    java.lang.Object[] var13 = new java.lang.Object[] { 'a'};
    org.apache.commons.math3.exception.MathIllegalStateException var14 = new org.apache.commons.math3.exception.MathIllegalStateException(var11, var13);
    org.apache.commons.math3.exception.MathIllegalArgumentException var15 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var10, var13);
    org.apache.commons.math3.exception.MathIllegalStateException var16 = new org.apache.commons.math3.exception.MathIllegalStateException(var9, var13);
    org.apache.commons.math3.exception.MathInternalError var17 = new org.apache.commons.math3.exception.MathInternalError(var8, var13);
    org.apache.commons.math3.exception.NullArgumentException var18 = new org.apache.commons.math3.exception.NullArgumentException(var7, var13);
    org.apache.commons.math3.exception.MathIllegalStateException var19 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var5, var6, var13);
    org.apache.commons.math3.exception.MathIllegalStateException var20 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, var13);
    org.apache.commons.math3.exception.NullArgumentException var21 = new org.apache.commons.math3.exception.NullArgumentException(var0, var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test326"); }


    double[] var0 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    double var3 = var1.addElementRolling((-0.05782461145270825d));
    boolean var5 = var1.equals((java.lang.Object)0.723245967437971d);
    int var6 = var1.start();
    int var7 = var1.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);

  }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test327"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var2 = var0.density(100.0d);
    double var5 = var0.cumulativeProbability((-2.450405938642638d), 0.6139648708421599d);
    double[] var7 = var0.sample(100);
    double var8 = var0.getStandardDeviation();
    double var10 = var0.cumulativeProbability((-0.004920366423301847d));
    boolean var11 = var0.isSupportUpperBoundInclusive();
    double var12 = var0.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.723245967437971d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.4980370657191222d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == Double.NEGATIVE_INFINITY);

  }

  public void test328() {}
//   public void test328() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test328"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var5 = var3.density(100.0d);
//     double var8 = var3.cumulativeProbability((-2.450405938642638d), 0.6139648708421599d);
//     double[] var10 = var3.sample(100);
//     double var11 = var3.getStandardDeviation();
//     boolean var12 = var3.isSupportUpperBoundInclusive();
//     var3.reseedRandomGenerator(1L);
//     double var15 = var3.getNumericalVariance();
//     double var16 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.723245967437971d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.6679010935103903d);
// 
//   }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test329"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.4705756905309871d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-2));

  }

  public void test330() {}
//   public void test330() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test330"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextWeibull(100.0d, 100.0d);
//     var1.reSeedSecure();
//     double var9 = var1.nextGamma(1.065175436767987d, 2.6498507619080125d);
//     int var12 = var1.nextZipf(3, 0.949950589504148d);
//     var1.reSeedSecure();
//     double var16 = var1.nextCauchy(0.0d, 0.5637033385775058d);
//     double var18 = var1.nextT(4.6624508263893025d);
//     int[] var21 = var1.nextPermutation(5488, 5215);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 100.12125595034477d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 4.624546720014361d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == (-0.8856973633063626d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.19293462643708276d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
// 
//   }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test331"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(1.6793228537521016E7d, (-2.9378153224114745d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.6793228537521016E7d));

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test332"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.getNumElements();
    double[] var2 = var0.getInternalValues();
    java.lang.Object var3 = null;
    boolean var4 = var0.equals(var3);
    var0.clear();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var0.copy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.discardFrontElements(139);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test333() {}
//   public void test333() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test333"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure();
//     int var9 = var1.nextInt((-15), 500);
//     double var12 = var1.nextBeta(98.00138274241472d, 0.9984187364052811d);
//     double var15 = var1.nextUniform(4.61512051684126d, 57.348154628338996d);
//     int var18 = var1.nextSecureInt(0, 2147483647);
//     double var22 = var1.nextUniform((-4.399025741313411d), (-0.038658806152633805d), true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 99);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.9877576668933492d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 42.91732089360531d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 747877476);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == (-4.046747684402512d));
// 
//   }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test334"); }


    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)32.53142185860535d, (java.lang.Number)1.088851945553895d, var2);
    java.lang.Number var4 = var3.getLo();
    java.lang.Number var5 = var3.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 1.088851945553895d+ "'", var4.equals(1.088851945553895d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test335"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp((-0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4E-45f);

  }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test336"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.getNumElements();
    int var2 = var0.start();
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var4 = var3.getNumElements();
    double[] var5 = var3.getInternalValues();
    int var6 = var3.getNumElements();
    double[] var7 = var3.getElements();
    var0.addElements(var7);
    var0.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(10, 99.99999f);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var12);
    float var14 = var12.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var16 = var15.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var17 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var18 = var17.getNumElements();
    double[] var19 = var17.getInternalValues();
    int var20 = var17.getNumElements();
    double[] var21 = var17.getElements();
    var15.addElements(var21);
    int var23 = var15.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var12, var15);
    var12.contract();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var27 = var12.getElement((-61));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);

  }

  public void test337() {}
//   public void test337() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test337"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh(0.8504467169183425d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test338"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.start();
    double var3 = var0.addElementRolling(4.937302184657956d);
    int var4 = var0.start();
    var0.contract();
    double[] var6 = var0.getInternalValues();
    var0.setExpansionMode(0);
    double[] var9 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    int var11 = var10.getNumElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);

  }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test339"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(496.2674961884226d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6.900263283840034d);

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test340"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(2.8016503008403646d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.9427738885758148d));

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test341"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getMean();
    double var4 = var0.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
    double var5 = var0.getNumericalVariance();
    var0.reseedRandomGenerator(100L);
    double var9 = var0.cumulativeProbability(1.0383512298650577d);
    boolean var10 = var0.isSupportLowerBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.5230558330643571d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.8504467169183425d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test342() {}
//   public void test342() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test342"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeedSecure(0L);
//     long var6 = var1.nextSecureLong(3628800L, 10000000000L);
//     java.lang.String var8 = var1.nextHexString(500);
//     double var11 = var1.nextGamma(0.723245967437971d, 4.089618308475393d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var1.nextBeta((-0.013030125303900976d), 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 7421784192L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "e3ea344f1c054687e42d3cca3af341bbcdfe9cae09eda000f1ffabcf9afa5eeab6ed111c45731c5c6d6f660ae6afab0dbab1a581624683334c2e424090f6ecb163f425363cb3a7f0069cffb8bacb135eb1851f9e71df132d7debb303332e9bbdcbbc87e3eaa2445c89e6b6873d1ce88e4dc74fb210219c29009e911487977bbc3052863fe41e7bb782577c9e08b24e145c418483d01170d766c1cac4d13986c5f68929d9ebaee05153566fd807de18be9dd565351f6ddc9bfeaec26a4f67fb6dc1db087dda81d8a61cbb9e2e7149da3bc235648961a830dc8be619a2c621578c2f0cbc0457a910d8c374addf2e2e6845db6199e20a47d79ea005"+ "'", var8.equals("e3ea344f1c054687e42d3cca3af341bbcdfe9cae09eda000f1ffabcf9afa5eeab6ed111c45731c5c6d6f660ae6afab0dbab1a581624683334c2e424090f6ecb163f425363cb3a7f0069cffb8bacb135eb1851f9e71df132d7debb303332e9bbdcbbc87e3eaa2445c89e6b6873d1ce88e4dc74fb210219c29009e911487977bbc3052863fe41e7bb782577c9e08b24e145c418483d01170d766c1cac4d13986c5f68929d9ebaee05153566fd807de18be9dd565351f6ddc9bfeaec26a4f67fb6dc1db087dda81d8a61cbb9e2e7149da3bc235648961a830dc8be619a2c621578c2f0cbc0457a910d8c374addf2e2e6845db6199e20a47d79ea005"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2.771464632292908d);
// 
//   }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test343"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(0.9459534091425227d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7379455838526907d);

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test344"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.9584128699015102d, 1.9983491555909598d, 16.045151625500697d, 447);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.12642123594597032d);

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test345"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    java.lang.Object[] var8 = new java.lang.Object[] { 'a'};
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException(var6, var8);
    org.apache.commons.math3.exception.MathIllegalArgumentException var10 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var5, var8);
    org.apache.commons.math3.exception.MathIllegalArgumentException var11 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var4, var8);
    org.apache.commons.math3.exception.MathArithmeticException var12 = new org.apache.commons.math3.exception.MathArithmeticException(var3, var8);
    org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, var8);
    org.apache.commons.math3.exception.MathArithmeticException var14 = new org.apache.commons.math3.exception.MathArithmeticException(var1, var8);
    org.apache.commons.math3.exception.MathInternalError var15 = new org.apache.commons.math3.exception.MathInternalError(var0, var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test346() {}
//   public void test346() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test346"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.5607966601082315d);
//     java.lang.String var4 = var0.nextHexString(506);
//     var0.reSeed();
//     long var8 = var0.nextSecureLong(1L, 3363459797L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var0.nextPascal((-2147483648), 2.889407504491d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2.2225788385396856d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "68530ff81bf28b81043b7aff4081a271e16f732d7216c2fec9ab8ecda1f85355ea2191eed1747ad10f4cd116ab5971e384bcdb75dab209a2a964a942762902b3fd982dafe86a48c198b699d3c1d17561179c0aea1d7b64572a718d9f2adc2db06972c925c79d363c8535e837a4ac0f50d8f76c293b45a371de3d857fc402555fd614661cb56e7ad9eda81dba07b998ef2a68ddae3d001bbfb2575aa6b2eb2bb941e5852d0d801fd5a9d1dbba1210ddfd5ea35a8c5b2e886276645a0b819ab40df0194e21e75ca9cf258c0f129aef6b5b2487f0c3e0af9ae5f94400c1fba3da31f6bcdab96b4924b775fe71bb52118a010b2068d673621c0e106cd338f8"+ "'", var4.equals("68530ff81bf28b81043b7aff4081a271e16f732d7216c2fec9ab8ecda1f85355ea2191eed1747ad10f4cd116ab5971e384bcdb75dab209a2a964a942762902b3fd982dafe86a48c198b699d3c1d17561179c0aea1d7b64572a718d9f2adc2db06972c925c79d363c8535e837a4ac0f50d8f76c293b45a371de3d857fc402555fd614661cb56e7ad9eda81dba07b998ef2a68ddae3d001bbfb2575aa6b2eb2bb941e5852d0d801fd5a9d1dbba1210ddfd5ea35a8c5b2e886276645a0b819ab40df0194e21e75ca9cf258c0f129aef6b5b2487f0c3e0af9ae5f94400c1fba3da31f6bcdab96b4924b775fe71bb52118a010b2068d673621c0e106cd338f8"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1345597926L);
// 
//   }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test347"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(31, 1037420971);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1037421002);

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test348"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    int var3 = var2.ordinal();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var5.getNanStrategy();
    java.lang.Class var7 = var6.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    org.apache.commons.math3.stat.ranking.TiesStrategy var9 = var8.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = var8.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var11 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11);
    org.apache.commons.math3.stat.ranking.NaNStrategy var13 = var12.getNanStrategy();
    int var14 = var13.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var13);
    org.apache.commons.math3.stat.ranking.TiesStrategy var16 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var16);
    org.apache.commons.math3.stat.ranking.NaNStrategy var18 = var17.getNanStrategy();
    java.lang.Class var19 = var18.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var18);
    org.apache.commons.math3.stat.ranking.TiesStrategy var21 = var20.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var13, var21);
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10, var21);
    org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var21);
    java.lang.String var25 = var21.name();
    java.lang.String var26 = var21.name();
    java.lang.String var27 = var21.toString();
    org.apache.commons.math3.stat.ranking.NaturalRanking var28 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var21);
    org.apache.commons.math3.stat.ranking.TiesStrategy var29 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var30 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var29);
    org.apache.commons.math3.stat.ranking.NaNStrategy var31 = var30.getNanStrategy();
    java.lang.String var32 = var31.name();
    org.apache.commons.math3.random.RandomGenerator var33 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var34 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var33);
    org.apache.commons.math3.stat.ranking.TiesStrategy var35 = var34.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var36 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var35);
    org.apache.commons.math3.stat.ranking.NaturalRanking var37 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var31, var35);
    org.apache.commons.math3.stat.ranking.TiesStrategy var38 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var39 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var38);
    org.apache.commons.math3.stat.ranking.NaNStrategy var40 = var39.getNanStrategy();
    int var41 = var40.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var42 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var40);
    org.apache.commons.math3.stat.ranking.TiesStrategy var43 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var44 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var43);
    org.apache.commons.math3.stat.ranking.NaNStrategy var45 = var44.getNanStrategy();
    java.lang.Class var46 = var45.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var47 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var45);
    org.apache.commons.math3.stat.ranking.TiesStrategy var48 = var47.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var49 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var40, var48);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var50 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var51 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var52 = var51.getNumElements();
    double[] var53 = var51.getInternalValues();
    double[] var56 = new double[] { 10.0d, 100.0d};
    double var57 = var50.mannWhitneyU(var53, var56);
    double[] var58 = var49.rank(var56);
    double[] var59 = var37.rank(var58);
    double[] var60 = var28.rank(var58);
    org.apache.commons.math3.util.ResizableDoubleArray var61 = new org.apache.commons.math3.util.ResizableDoubleArray(var58);
    org.apache.commons.math3.util.ResizableDoubleArray var62 = new org.apache.commons.math3.util.ResizableDoubleArray(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + "AVERAGE"+ "'", var25.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + "AVERAGE"+ "'", var26.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + "AVERAGE"+ "'", var27.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var32 + "' != '" + "MAXIMAL"+ "'", var32.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);

  }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test349"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(5.759088728348268d, 7.38420064243972d);

  }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test350"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.42960132384540173d, 0.8413447340368079d, (-2.9378153224114745d));
    double var5 = var3.inverseCumulativeProbability(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == Double.NEGATIVE_INFINITY);

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test351"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(62.9298715199793d, 37.422148975532345d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0753380186560843E67d);

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test352"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin((-0.05388929638978884d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.053863217252038034d));

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test353"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var2 = var0.density(100.0d);
    double var5 = var0.cumulativeProbability((-2.450405938642638d), 0.6139648708421599d);
    double[] var7 = var0.sample(100);
    double var8 = var0.getStandardDeviation();
    boolean var9 = var0.isSupportConnected();
    double var10 = var0.getNumericalMean();
    double var11 = var0.getSupportLowerBound();
    var0.reseedRandomGenerator(1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.723245967437971d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == Double.NEGATIVE_INFINITY);

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test354"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos((-1.444675884103861d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.12578635551912187d);

  }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test355"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(866883357L, 99L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9535716927L);

  }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test356"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)1.8830951902909365E-9d);

  }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test357"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var2 = var0.addElementRolling(Double.NaN);
    var0.setNumElements(0);
    var0.contract();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var6 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var7 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var10 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var11 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var13 = var12.getNumElements();
    double[] var14 = var12.getInternalValues();
    double[] var17 = new double[] { 10.0d, 100.0d};
    double var18 = var11.mannWhitneyU(var14, var17);
    org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    double var20 = var7.mannWhitneyU(var10, var14);
    double[] var24 = new double[] { 100.0d, 1.0d, 100.0d};
    double var25 = var6.mannWhitneyU(var10, var24);
    var0.addElements(var24);
    var0.setContractionCriteria(16.0f);
    var0.setNumElements(7);
    float var31 = var0.getContractionCriteria();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 16.0f);

  }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test358"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(-1.6318581766994622d));

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test359"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(9.0071993E15f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2147483647);

  }

  public void test360() {}
//   public void test360() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test360"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     int var5 = var1.nextInt(207, 432);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 350);
// 
//   }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test361"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var2.getNanStrategy();
    java.lang.Class var4 = var3.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3);
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var5.getTiesStrategy();
    java.lang.String var7 = var6.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var6);
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    org.apache.commons.math3.stat.ranking.TiesStrategy var10 = var9.getTiesStrategy();
    java.lang.String var11 = var10.toString();
    boolean var13 = var10.equals((java.lang.Object)(-6.495379117362055d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "AVERAGE"+ "'", var7.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "AVERAGE"+ "'", var11.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test362"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(10400, 10230);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10400);

  }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test363"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(0L, 14066561462L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 14066561462L);

  }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test364"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(210.0d, 0.9984187364052811d);
    double var4 = var2.cumulativeProbability(0.6210214343458166d);
    var2.reseedRandomGenerator(4286580654L);
    double var7 = var2.getNumericalVariance();
    double[] var9 = var2.sample(380);
    double var11 = var2.probability(1.7726091170384544d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.9968399732051182d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);

  }

  public void test365() {}
//   public void test365() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test365"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextWeibull(100.0d, 100.0d);
//     var1.reSeedSecure();
//     double var9 = var1.nextGamma(1.065175436767987d, 2.6498507619080125d);
//     int var12 = var1.nextZipf(3, 0.949950589504148d);
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var1.nextPascal(0, 3.218301537424697d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 98.26487890031721d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.931723911265498d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1);
// 
//   }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test366"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(0.6263485952500932d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.202653614370511d);

  }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test367"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(4.477465921704087d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4L);

  }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test368"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-2.450405938642638d), 9.185979303078355E-72d);
    double var3 = var2.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-2.450405938642638d));

  }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test369"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    int var3 = var2.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var6.getNanStrategy();
    java.lang.Class var8 = var7.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.TiesStrategy var10 = var9.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var10);
    int var12 = var2.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.NaNStrategy var14 = var13.getNanStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test370() {}
//   public void test370() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test370"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextWeibull(100.0d, 100.0d);
//     int var8 = var1.nextPascal(2147483647, 0.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var1.nextUniform(305.69796895140877d, 0.0d, true);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 99.94564549403442d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2147483647);
// 
//   }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test371"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(1.4055443918089456d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.14784456663731504d);

  }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test372"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(0.3989422804014327d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.39908993417905747d));

  }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test373"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var1.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3, var4);
    org.apache.commons.math3.random.RandomGenerator var6 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3, var6);
    org.apache.commons.math3.stat.ranking.NaNStrategy var8 = var7.getNanStrategy();
    java.lang.String var9 = var8.name();
    int var10 = var8.ordinal();
    org.apache.commons.math3.stat.ranking.TiesStrategy var11 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11);
    org.apache.commons.math3.stat.ranking.NaNStrategy var13 = var12.getNanStrategy();
    java.lang.String var14 = var13.name();
    java.lang.String var15 = var13.toString();
    int var16 = var13.ordinal();
    int var17 = var13.ordinal();
    org.apache.commons.math3.stat.ranking.TiesStrategy var18 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var18);
    org.apache.commons.math3.stat.ranking.NaNStrategy var20 = var19.getNanStrategy();
    java.lang.String var21 = var20.name();
    java.lang.String var22 = var20.toString();
    int var23 = var20.ordinal();
    int var24 = var20.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var25 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20);
    org.apache.commons.math3.stat.ranking.TiesStrategy var26 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var27 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var26);
    org.apache.commons.math3.stat.ranking.NaNStrategy var28 = var27.getNanStrategy();
    java.lang.Class var29 = var28.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var30 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var28);
    org.apache.commons.math3.stat.ranking.TiesStrategy var31 = var30.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var32 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20, var31);
    boolean var33 = var13.equals((java.lang.Object)var31);
    boolean var35 = var31.equals((java.lang.Object)37.422148975532345d);
    org.apache.commons.math3.stat.ranking.NaturalRanking var36 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8, var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "MAXIMAL"+ "'", var9.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "MAXIMAL"+ "'", var14.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "MAXIMAL"+ "'", var15.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + "MAXIMAL"+ "'", var21.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + "MAXIMAL"+ "'", var22.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);

  }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test374"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble((-663925499));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test375() {}
//   public void test375() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test375"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ((-0.17393496569430167d), 1.3648793247295046d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test376"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray((-1), 1.2676505E30f, 0.0f, 396970);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test377"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(0, 71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 71);

  }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test378"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    java.math.BigInteger var2 = null;
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 0L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 907096051);
    org.apache.commons.math3.exception.OutOfRangeException var8 = new org.apache.commons.math3.exception.OutOfRangeException(var0, var1, (java.lang.Number)var4, (java.lang.Number)0.10639189316204843d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test379"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var2 = var0.density(100.0d);
    double var5 = var0.cumulativeProbability((-2.450405938642638d), 0.6139648708421599d);
    double[] var7 = var0.sample(100);
    double var8 = var0.getStandardDeviation();
    boolean var9 = var0.isSupportUpperBoundInclusive();
    var0.reseedRandomGenerator(1L);
    boolean var12 = var0.isSupportLowerBoundInclusive();
    double var13 = var0.getNumericalMean();
    double var14 = var0.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.723245967437971d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0d);

  }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test380"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.9999791546489307d, (java.lang.Number)208, (java.lang.Number)(-0.2813585913101566d));

  }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test381"); }


    double[] var0 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(50);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var3);
    var1.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var1.copy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setExpansionMode(875500725);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test382"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(1193, 0.0f, 100.49999f, 341);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test383"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(800.0f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 800.0f);

  }

  public void test384() {}
//   public void test384() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test384"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextWeibull(100.0d, 100.0d);
//     int var8 = var1.nextPascal(2147483647, 0.0d);
//     double var11 = var1.nextUniform(0.3083894584059538d, 4.484958451919815d);
//     long var14 = var1.nextLong((-9223372036854775808L), 9732464866L);
//     var1.reSeed(10000000000L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("0b2ad92292e6aba52622ac6c26b75199b7adf5f3963a92da7438c1cb18d3dacea67ae72de08362ee2d655c17cc122d7a6a1db5a7556c304ffdd53d3dad40e01210138fb0ab1c766182a2cd646fd71a259fcbfec7a10d0ba45e973956f3314280a78ca29542598a53e1d4ceb44d5f2e430f008887d79dffb3b8d3307d1c3a654d51ce06ba18fe03d951a7c4555f7db7d9750b46416ea7d0cfc301aa8d073714f70d1eb6dda40eea1c757c4fc8f7369edd3b45a5a2b6588f7df03", "c9a799ebc5eb133d278b3e8ab7fbad74dc66fc756bcec0a211566f48c835adc108e0b17b1aad782f91fcbb126d5cb0cee0675f2b694c9bbd915e1de1213f856d975fdbb67920c8c940bb9cf24099e34c82737431bbeddb6c8873f91c77a4a5b5c12982866675cceaa1ceae431108fc89c10b56667ee2c60efddfe752cba3980028cd9dbf3e45a7607428a392831be67863a84a99a9b13d5849a4cae436b673d3b73a4e31a9d0aad74f3f9ab5bd38818c61d1a4da76378887ac4");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 97.85119180969994d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 4.263329287754682d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-2127841452227386880L));
// 
//   }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test385"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getMean();
    double var4 = var0.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
    double var5 = var0.getMean();
    boolean var6 = var0.isSupportLowerBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.5230558330643571d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test386"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var2 = var0.addElementRolling(Double.NaN);
    var0.setNumElements(0);
    var0.contract();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var6 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var7 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var10 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var11 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var13 = var12.getNumElements();
    double[] var14 = var12.getInternalValues();
    double[] var17 = new double[] { 10.0d, 100.0d};
    double var18 = var11.mannWhitneyU(var14, var17);
    org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    double var20 = var7.mannWhitneyU(var10, var14);
    double[] var24 = new double[] { 100.0d, 1.0d, 100.0d};
    double var25 = var6.mannWhitneyU(var10, var24);
    var0.addElements(var24);
    org.apache.commons.math3.util.ResizableDoubleArray var28 = new org.apache.commons.math3.util.ResizableDoubleArray(50);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var28);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.discardMostRecentElements(18);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 4.0d);

  }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test387"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3);

  }

  public void test388() {}
//   public void test388() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test388"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure();
//     int var9 = var1.nextInt((-15), 500);
//     double var12 = var1.nextBeta(98.00138274241472d, 0.9984187364052811d);
//     double var15 = var1.nextUniform(4.61512051684126d, 57.348154628338996d);
//     double var17 = var1.nextExponential(0.9400207386800911d);
//     double var20 = var1.nextF(1.9983491555909598d, 0.23074612792124255d);
//     double var22 = var1.nextChiSquare(1.1125191124373863d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 258);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.961889919351893d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 53.43353651919507d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.24172945231851603d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 25.395720338457d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1.5593998386492163d);
// 
//   }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test389"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(0.7838899213734127d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6648402391036184d);

  }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test390"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getNumericalMean();
    double var2 = var0.getStandardDeviation();
    boolean var3 = var0.isSupportConnected();
    boolean var4 = var0.isSupportLowerBoundInclusive();
    boolean var5 = var0.isSupportLowerBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test391"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.getNumElements();
    int var2 = var0.start();
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var4 = var3.getNumElements();
    double[] var5 = var3.getInternalValues();
    int var6 = var3.getNumElements();
    double[] var7 = var3.getElements();
    var0.addElements(var7);
    var0.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(10, 99.99999f);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var12);
    float var14 = var12.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var16 = var15.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var17 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var18 = var17.getNumElements();
    double[] var19 = var17.getInternalValues();
    int var20 = var17.getNumElements();
    double[] var21 = var17.getElements();
    var15.addElements(var21);
    int var23 = var15.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var12, var15);
    double[] var25 = var15.getInternalValues();
    float var26 = var15.getContractionCriteria();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var15.setElement((-1023), 0.0d);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 2.5f);

  }

  public void test392() {}
//   public void test392() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test392"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure(10L);
//     long var10 = var1.nextSecureLong(10L, 10000000000L);
//     double var12 = var1.nextChiSquare(0.001736111111111111d);
//     double var15 = var1.nextBeta(0.36792469441508013d, 0.23074612792124255d);
//     var1.reSeed((-6197319789L));
//     int var20 = var1.nextBinomial(5, 0.9738617129853937d);
//     var1.reSeedSecure();
//     java.lang.String var23 = var1.nextSecureHexString(380);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("", "215bfa");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 59245247L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1.0882207044809582E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.9999465399897942d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var23 + "' != '" + "638d83cc1a1b586029049f043b2a2bf828ce322533bfe6a458b3eed716f9fc0109ffe5efd7f5c286a625561b7d7a0ece33e7dafa3652c87cf86782fcb38859002e64a4851e45104366921f21a496b90f8def63de0d7b712d214bf5cb72b83b2029d2f21b089a80a8137ba67bc6a13d72e2913090a50d1d6e50d7ec57923eef50cb121effb76f58b7a1b04f7eaa73c02255245e59896dc409aca242713f42e6d2bc8d09c7dfbfd9c7c215c889cf5d5da0bb1e078d50382f72dd44426df297"+ "'", var23.equals("638d83cc1a1b586029049f043b2a2bf828ce322533bfe6a458b3eed716f9fc0109ffe5efd7f5c286a625561b7d7a0ece33e7dafa3652c87cf86782fcb38859002e64a4851e45104366921f21a496b90f8def63de0d7b712d214bf5cb72b83b2029d2f21b089a80a8137ba67bc6a13d72e2913090a50d1d6e50d7ec57923eef50cb121effb76f58b7a1b04f7eaa73c02255245e59896dc409aca242713f42e6d2bc8d09c7dfbfd9c7c215c889cf5d5da0bb1e078d50382f72dd44426df297"));
// 
//   }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test393"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var3 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var6 = var5.getNumElements();
    double[] var7 = var5.getInternalValues();
    double[] var10 = new double[] { 10.0d, 100.0d};
    double var11 = var4.mannWhitneyU(var7, var10);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    double var13 = var0.mannWhitneyU(var3, var7);
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    var15.addElement(1832.5694791909018d);
    float var18 = var15.getExpansionFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 2.0f);

  }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test394"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(4.5E-44f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test395"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var3 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var6 = var5.getNumElements();
    double[] var7 = var5.getInternalValues();
    double[] var10 = new double[] { 10.0d, 100.0d};
    double var11 = var4.mannWhitneyU(var7, var10);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    double var13 = var0.mannWhitneyU(var3, var7);
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var14.contract();
    java.lang.Object var16 = null;
    boolean var17 = var14.equals(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);

  }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test396"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog(7550);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 59871.620059927176d);

  }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test397"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var1 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var4 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var5 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var7 = var6.getNumElements();
    double[] var8 = var6.getInternalValues();
    double[] var11 = new double[] { 10.0d, 100.0d};
    double var12 = var5.mannWhitneyU(var8, var11);
    org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
    double var14 = var1.mannWhitneyU(var4, var8);
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray(var15);
    org.apache.commons.math3.util.ResizableDoubleArray var17 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var18 = var17.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var20 = var19.getNumElements();
    double[] var21 = var19.getInternalValues();
    int var22 = var19.getNumElements();
    double[] var23 = var19.getElements();
    var17.addElements(var23);
    float var25 = var17.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var15, var17);
    double var28 = var17.addElementRolling(3.4965075614664802d);
    org.apache.commons.math3.util.ResizableDoubleArray var29 = var17.copy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var17);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test398"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter((-2.3841858E-7f), 0.3227349192519079d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-2.3841856E-7f));

  }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test399"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)1.8172460516973112d, (java.lang.Number)0.43343553720412786d, true);
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);

  }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test400"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var2 = var0.density(100.0d);
    double var5 = var0.cumulativeProbability((-2.450405938642638d), 0.6139648708421599d);
    double[] var7 = var0.sample(100);
    double var8 = var0.getStandardDeviation();
    double var10 = var0.cumulativeProbability((-0.004920366423301847d));
    double var11 = var0.getNumericalMean();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var13 = var0.inverseCumulativeProbability((-0.5788982422751958d));
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.723245967437971d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.4980370657191222d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);

  }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test401"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var2 = var0.addElementRolling(Double.NaN);
    var0.setNumElements(0);
    var0.contract();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var6 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var7 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var10 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var11 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var13 = var12.getNumElements();
    double[] var14 = var12.getInternalValues();
    double[] var17 = new double[] { 10.0d, 100.0d};
    double var18 = var11.mannWhitneyU(var14, var17);
    org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    double var20 = var7.mannWhitneyU(var10, var14);
    double[] var24 = new double[] { 100.0d, 1.0d, 100.0d};
    double var25 = var6.mannWhitneyU(var10, var24);
    var0.addElements(var24);
    org.apache.commons.math3.util.ResizableDoubleArray var28 = new org.apache.commons.math3.util.ResizableDoubleArray(50);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var28);
    var0.clear();
    double[] var31 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var32 = new org.apache.commons.math3.util.ResizableDoubleArray(var31);
    double[] var33 = var32.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var34 = new org.apache.commons.math3.util.ResizableDoubleArray(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test402"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(393769108042894612L, 1772309183L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 393769106270585429L);

  }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test403"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb((-1.2676505E30f), 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.2676505E30f));

  }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test404"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)3.4339872044851463d, (java.lang.Number)8.037850951474781E118d, false);
    java.lang.Number var4 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 8.037850951474781E118d+ "'", var4.equals(8.037850951474781E118d));

  }

  public void test405() {}
//   public void test405() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test405"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeedSecure(0L);
//     java.lang.String var5 = var1.nextSecureHexString(371);
//     long var8 = var1.nextSecureLong(0L, 8179512108L);
//     long var11 = var1.nextSecureLong(3520920158L, 4448708814L);
//     java.lang.String var13 = var1.nextSecureHexString(71);
//     double var16 = var1.nextGamma(0.8356459384186922d, 18.16824270994235d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var19 = var1.nextLong((-4075010858L), (-9617852649L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + "6ded6a029c5f8cf4d750d1a130aeacf52a49a45ce6d0a60bc41c9759e2865541a381a9618516d940b0d5e674fa12a9004f98e3b7726d5860879dc3b4c4874f511a0ee82c6fb0bc2fa642b83ccacaaca4fffb646ae5f147349c67385627255a014fcdf930516e1b4409a278bb97353e54151178e409eae4f5dba68e5edc8677b43324194e8a921ae196ef6dfbbb442784751fc2a8d38d1cbe2af4003ad71a14b03f466c6ebff643efa473a8f77b1dcfd03df8b5ffed135780efe"+ "'", var5.equals("6ded6a029c5f8cf4d750d1a130aeacf52a49a45ce6d0a60bc41c9759e2865541a381a9618516d940b0d5e674fa12a9004f98e3b7726d5860879dc3b4c4874f511a0ee82c6fb0bc2fa642b83ccacaaca4fffb646ae5f147349c67385627255a014fcdf930516e1b4409a278bb97353e54151178e409eae4f5dba68e5edc8677b43324194e8a921ae196ef6dfbbb442784751fc2a8d38d1cbe2af4003ad71a14b03f466c6ebff643efa473a8f77b1dcfd03df8b5ffed135780efe"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 3363175075L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 4248635873L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "202922505484f45bbeaec1bbd3141e6667968d3f69469c53e8fee1d84983c23fb57aed6"+ "'", var13.equals("202922505484f45bbeaec1bbd3141e6667968d3f69469c53e8fee1d84983c23fb57aed6"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 4.242795458562066d);
// 
//   }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test406"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(4448708824L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test407"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(109);

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test408"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var2 = var0.addElementRolling(Double.NaN);
    double[] var3 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var6.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var11 = var9.addElementRolling(Double.NaN);
    double[] var12 = var9.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray(var12);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var6, var13);
    double[] var15 = var6.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray(var15);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var17 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var19 = var18.getNumElements();
    double[] var20 = var18.getInternalValues();
    double[] var23 = new double[] { 10.0d, 100.0d};
    double var24 = var17.mannWhitneyU(var20, var23);
    var16.addElements(var23);
    var5.addElements(var23);
    var5.discardFrontElements(0);
    int var29 = var5.getNumElements();
    double var31 = var5.addElementRolling(6.686619075346716d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 10.0d);

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test409"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var2 = var0.addElementRolling(Double.NaN);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(10, 99.99999f);
    float var6 = var5.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var5);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var8.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var13 = var11.addElementRolling(Double.NaN);
    double[] var14 = var11.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var8, var15);
    double[] var17 = var8.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var19 = var18.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var21 = var20.getNumElements();
    double[] var22 = var20.getInternalValues();
    int var23 = var20.getNumElements();
    double[] var24 = var20.getElements();
    var18.addElements(var24);
    var8.addElements(var24);
    boolean var28 = var8.equals((java.lang.Object)' ');
    int var29 = var8.start();
    org.apache.commons.math3.util.ResizableDoubleArray var32 = new org.apache.commons.math3.util.ResizableDoubleArray(10, 99.99999f);
    int var33 = var32.start();
    var32.addElement(0.0d);
    var32.clear();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var8, var32);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var5, var32);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var32.setContractionCriteria(0.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 100.49999f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0);

  }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test410"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)7.976890346664758d, (java.lang.Number)(-0.6000588730884987d), false);

  }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test411"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)1.229653923770267d, (java.lang.Number)233.8496495617364d, (java.lang.Number)(-53.264544310831205d));

  }

  public void test412() {}
//   public void test412() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test412"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextBeta(572.2646479502633d, 0.07637989519631011d);
//     double var7 = var1.nextExponential(209.99999999999997d);
//     double var10 = var1.nextUniform(1.3648793247295046d, 200.94444231998796d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var1.nextSecureInt(1222826114, 208479565);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 73.90534415104486d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 171.4017378951919d);
// 
//   }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test413"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    java.lang.Class var3 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var5.getNanStrategy();
    java.lang.Class var7 = var6.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    java.lang.Class var9 = var6.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.TiesStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.NaNStrategy var12 = var11.getNanStrategy();
    java.lang.Class var13 = var12.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12);
    org.apache.commons.math3.stat.ranking.TiesStrategy var15 = var14.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var16 = var14.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var17);
    org.apache.commons.math3.stat.ranking.NaNStrategy var19 = var18.getNanStrategy();
    int var20 = var19.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var19);
    org.apache.commons.math3.stat.ranking.TiesStrategy var22 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var22);
    org.apache.commons.math3.stat.ranking.NaNStrategy var24 = var23.getNanStrategy();
    java.lang.Class var25 = var24.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var26 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var24);
    org.apache.commons.math3.stat.ranking.TiesStrategy var27 = var26.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var28 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var19, var27);
    org.apache.commons.math3.stat.ranking.NaturalRanking var29 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var16, var27);
    org.apache.commons.math3.stat.ranking.TiesStrategy var30 = var29.getTiesStrategy();
    java.lang.Class var31 = var30.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var32 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var30);
    java.lang.Class var33 = var6.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.TiesStrategy var34 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var35 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var34);
    org.apache.commons.math3.stat.ranking.NaNStrategy var36 = var35.getNanStrategy();
    int var37 = var36.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var38 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var36);
    java.lang.String var39 = var36.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var40 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var36);
    java.lang.String var41 = var36.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var42 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var36);
    org.apache.commons.math3.stat.ranking.TiesStrategy var43 = var42.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var44 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var43);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var45 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var6, var43);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var46 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var43);
    java.lang.String var47 = var43.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var39 + "' != '" + "MAXIMAL"+ "'", var39.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var41 + "' != '" + "MAXIMAL"+ "'", var41.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var47 + "' != '" + "AVERAGE"+ "'", var47.equals("AVERAGE"));

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test414"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.0010908414609777095d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test415"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(29L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test416"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp((-0.5374527069121192d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1102230246251565E-16d);

  }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test417"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(99);

  }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test418"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(9395211210L, (-6275290550L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3119920660L);

  }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test419"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(8206473141L, 7969628972L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7969628972L);

  }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test420"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var3 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var6 = var5.getNumElements();
    double[] var7 = var5.getInternalValues();
    double[] var10 = new double[] { 10.0d, 100.0d};
    double var11 = var4.mannWhitneyU(var7, var10);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    double var13 = var0.mannWhitneyU(var3, var7);
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    double var17 = var14.substituteMostRecentElement(0.3742437696541317d);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var18 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var21 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var22 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var23 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var24 = var23.getNumElements();
    double[] var25 = var23.getInternalValues();
    double[] var28 = new double[] { 10.0d, 100.0d};
    double var29 = var22.mannWhitneyU(var25, var28);
    org.apache.commons.math3.util.ResizableDoubleArray var30 = new org.apache.commons.math3.util.ResizableDoubleArray(var25);
    double var31 = var18.mannWhitneyU(var21, var25);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var32 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var33 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var34 = var33.getNumElements();
    double[] var35 = var33.getInternalValues();
    double[] var38 = new double[] { 10.0d, 100.0d};
    double var39 = var32.mannWhitneyU(var35, var38);
    org.apache.commons.math3.util.ResizableDoubleArray var40 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var41 = var40.getNumElements();
    double[] var42 = var40.getInternalValues();
    double var43 = var18.mannWhitneyUTest(var35, var42);
    var14.addElements(var42);
    var14.addElement(0.0d);
    float var47 = var14.getContractionCriteria();
    int var48 = var14.start();
    int var49 = var14.getExpansionMode();
    var14.setNumElements(3615);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0);

  }

  public void test421() {}
//   public void test421() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test421"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextBeta(572.2646479502633d, 0.07637989519631011d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var8 = var1.nextWeibull((-1.161278971931107d), (-0.7951515095609888d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.9999999987738578d);
// 
//   }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test422"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getMean();
    double var4 = var0.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
    double var6 = var0.probability(1.0016685869732043d);
    boolean var7 = var0.isSupportConnected();
    double var10 = var0.cumulativeProbability(9.868080801062987d, 245.83154396222974d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.5230558330643571d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 2.862472890668283E-23d);

  }

  public void test423() {}
//   public void test423() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test423"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure(10L);
//     long var10 = var1.nextSecureLong(10L, 10000000000L);
//     double var13 = var1.nextUniform(0.9999943487368532d, 44.5140274520795d);
//     double var15 = var1.nextChiSquare(51.55677237552102d);
//     org.apache.commons.math3.distribution.NormalDistribution var16 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var17 = var16.getMean();
//     double var20 = var16.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
//     double var21 = var16.getSupportUpperBound();
//     double var22 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var16);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var24 = var1.nextSecureHexString((-22));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 7013001053L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 4.403446227510372d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 36.9113079950124d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.5230558330643571d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0.319280340304815d);
// 
//   }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test424"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.getNumElements();
    int var2 = var0.start();
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var4 = var3.getNumElements();
    double[] var5 = var3.getInternalValues();
    int var6 = var3.getNumElements();
    double[] var7 = var3.getElements();
    var0.addElements(var7);
    var0.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(10, 99.99999f);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var12);
    var12.setElement(825, (-0.06991186090907374d));
    double[] var17 = var12.getElements();
    var12.addElement((-0.2658092704850752d));
    var12.setContractionCriteria(100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test425"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(2.002865034964586d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9642294390779256d);

  }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test426"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    int var3 = var2.ordinal();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var5.getNanStrategy();
    java.lang.Class var7 = var6.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    org.apache.commons.math3.stat.ranking.TiesStrategy var9 = var8.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = var8.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var11 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11);
    org.apache.commons.math3.stat.ranking.NaNStrategy var13 = var12.getNanStrategy();
    int var14 = var13.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var13);
    org.apache.commons.math3.stat.ranking.TiesStrategy var16 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var16);
    org.apache.commons.math3.stat.ranking.NaNStrategy var18 = var17.getNanStrategy();
    java.lang.Class var19 = var18.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var18);
    org.apache.commons.math3.stat.ranking.TiesStrategy var21 = var20.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var13, var21);
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10, var21);
    org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var21);
    java.lang.String var25 = var21.name();
    java.lang.String var26 = var21.name();
    java.lang.Class var27 = var21.getDeclaringClass();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + "AVERAGE"+ "'", var25.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + "AVERAGE"+ "'", var26.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test427"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)10.0d, (java.lang.Number)1.6286532113855836d, (java.lang.Number)(-57.29577951308232d));
    java.lang.Number var5 = var4.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1.6286532113855836d+ "'", var5.equals(1.6286532113855836d));

  }

  public void test428() {}
//   public void test428() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test428"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var5 = var1.nextUniform(0.999987895021552d, 15.322095332102348d, false);
//     double var8 = var1.nextGamma(1.4713540043352986d, 4.787491742782046d);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var10 = var9.getMean();
//     double var13 = var9.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
//     double var14 = var9.getNumericalVariance();
//     double var15 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     double var18 = var1.nextGamma(99.69065826232949d, 2.786677745713106d);
//     org.apache.commons.math3.distribution.NormalDistribution var19 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var20 = var19.getMean();
//     double var23 = var19.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
//     double var24 = var19.getNumericalVariance();
//     var19.reseedRandomGenerator(100L);
//     double var27 = var19.sample();
//     double var29 = var19.probability(1.8525291623715519d);
//     double var30 = var19.sample();
//     var19.reseedRandomGenerator(1376175684L);
//     double var33 = var19.getMean();
//     double var34 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2.4236364819939364d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 9.959244533660112d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.5230558330643571d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.44732225364808026d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 280.2662024186379d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.5230558330643571d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 0.4705756905309871d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1.1991675114038487d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == (-0.1435739240703158d));
// 
//   }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test429"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(9716646581L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9716646581L);

  }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test430"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    java.lang.Class var3 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = var4.getNanStrategy();
    java.lang.String var6 = var5.name();
    java.lang.String var7 = var5.name();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "MAXIMAL"+ "'", var6.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "MAXIMAL"+ "'", var7.equals("MAXIMAL"));

  }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test431"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)10, (java.lang.Number)3.7621956910836314d, (java.lang.Number)0.7172507104665835d);
    java.lang.Throwable[] var5 = var4.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var6 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test432"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(7.38420064243972d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.14500658122397694d);

  }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test433"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(27.29897400744619d, 0.22185953721826301d, 0.0d, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException");
    } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
      // Expected exception.
    }

  }

  public void test434() {}
//   public void test434() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test434"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeedSecure(0L);
//     java.lang.String var5 = var1.nextSecureHexString(371);
//     long var8 = var1.nextSecureLong(0L, 8179512108L);
//     var1.reSeed(1L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var1.nextSecureInt(124952111, 80);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + "50e6f3dcfaeee60999880ec5f3bad7d40df77a0df95af37ffa22129fa4c972eef7fe68f379f1ff55381553590e3cd7bfef620d746304d8e5dd48f203464d448e5f741a8fc85cbb22ebf84c42da7fbec519a4c28e6c2a86d88edbd7740dcc800a7573beb2283afa26f8717dc809c016a04634b7359c35bb481d5e7bf559ce7863dc2ad22b7f987e689730b6fdaa10ebcbb9f875d33420f8065435a6da2cf0b2f211a31e7db789d52f1a5d00906f8f0b7600da1fd1a4e860b88c5"+ "'", var5.equals("50e6f3dcfaeee60999880ec5f3bad7d40df77a0df95af37ffa22129fa4c972eef7fe68f379f1ff55381553590e3cd7bfef620d746304d8e5dd48f203464d448e5f741a8fc85cbb22ebf84c42da7fbec519a4c28e6c2a86d88edbd7740dcc800a7573beb2283afa26f8717dc809c016a04634b7359c35bb481d5e7bf559ce7863dc2ad22b7f987e689730b6fdaa10ebcbb9f875d33420f8065435a6da2cf0b2f211a31e7db789d52f1a5d00906f8f0b7600da1fd1a4e860b88c5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 6996728727L);
// 
//   }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test435"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var2 = var0.density(100.0d);
    double var5 = var0.cumulativeProbability((-2.450405938642638d), 0.6139648708421599d);
    double var7 = var0.cumulativeProbability(0.6139648708421599d);
    boolean var8 = var0.isSupportLowerBoundInclusive();
    double var10 = var0.probability(9.437944169387807d);
    boolean var11 = var0.isSupportUpperBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.723245967437971d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.7303807294278502d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test436"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(55.56032093099914d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 56.0d);

  }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test437"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(98.00138274241472d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.7104468003622868d);

  }

  public void test438() {}
//   public void test438() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test438"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure();
//     var1.reSeed();
//     double var10 = var1.nextBeta(31.984371183438952d, 3.141592653589793d);
//     var1.reSeed();
//     var1.reSeed(7237275917L);
//     org.apache.commons.math3.distribution.IntegerDistribution var14 = null;
//     int var15 = var1.nextInversionDeviate(var14);
// 
//   }

  public void test439() {}
//   public void test439() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test439"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextInt((-1023), 0);
//     java.lang.String var6 = var1.nextSecureHexString(6);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var9 = var1.nextLong(35241726707532550L, (-5154125899424117313L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-895));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "c3e19b"+ "'", var6.equals("c3e19b"));
// 
//   }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test440"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians((-0.2492647519380979d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.004350490630486726d));

  }

  public void test441() {}
//   public void test441() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test441"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy[] var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
//     org.apache.commons.math3.exception.MathInternalError var2 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var1);
//     org.apache.commons.math3.exception.util.Localizable var3 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var7 = new org.apache.commons.math3.exception.OutOfRangeException(var3, (java.lang.Number)24.0d, (java.lang.Number)0.723245967437971d, (java.lang.Number)825);
//     var2.addSuppressed((java.lang.Throwable)var7);
//     java.lang.Number var9 = var7.getArgument();
//     java.lang.Throwable[] var10 = var7.getSuppressed();
//     org.apache.commons.math3.exception.util.Localizable var11 = null;
//     org.apache.commons.math3.exception.util.Localizable var12 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var17 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)Double.NaN, (java.lang.Number)0.6139648708421599d, true);
//     java.lang.Number var18 = var17.getMax();
//     org.apache.commons.math3.exception.util.Localizable var19 = null;
//     org.apache.commons.math3.exception.util.Localizable var20 = null;
//     org.apache.commons.math3.exception.util.Localizable var21 = null;
//     org.apache.commons.math3.exception.NotPositiveException var23 = new org.apache.commons.math3.exception.NotPositiveException(var21, (java.lang.Number)0);
//     java.lang.Object[] var24 = new java.lang.Object[] { 0};
//     org.apache.commons.math3.exception.NullArgumentException var25 = new org.apache.commons.math3.exception.NullArgumentException(var20, var24);
//     org.apache.commons.math3.exception.MathIllegalStateException var26 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var17, var19, var24);
//     org.apache.commons.math3.exception.MaxCountExceededException var27 = new org.apache.commons.math3.exception.MaxCountExceededException(var12, (java.lang.Number)0.015627018980860316d, var24);
//     org.apache.commons.math3.exception.MathIllegalStateException var28 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var7, var11, var24);
// 
//   }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test442"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(3570);
    double[] var2 = var1.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    int var4 = var1.getNumElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);

  }

  public void test443() {}
//   public void test443() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test443"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ((-0.39908993417905747d), 98.99381948862766d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test444"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(432, 95455);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 432);

  }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test445"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(28.11269684646181d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.3711743967663654d);

  }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test446"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(0.9309003631188053d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5367921838187197d);

  }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test447"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)22667, (java.lang.Number)(-0.13233995263633305d), false);

  }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test448"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(44.93692582882734d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5779118328206412d);

  }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test449"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(0.9097224269009427d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8160761123400065d);

  }

  public void test450() {}
//   public void test450() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test450"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log((-1.3407807929942293E154d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test451"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-100000L), 8680198150961916721L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test452"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    java.lang.Class var3 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var4.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var4.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.NaNStrategy var9 = var8.getNanStrategy();
    int var10 = var9.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var9);
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12);
    org.apache.commons.math3.stat.ranking.NaNStrategy var14 = var13.getNanStrategy();
    java.lang.Class var15 = var14.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var14);
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var9, var17);
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var17);
    org.apache.commons.math3.stat.ranking.NaNStrategy var20 = var19.getNanStrategy();
    java.lang.Class var21 = var20.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.TiesStrategy var22 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var22);
    org.apache.commons.math3.stat.ranking.NaNStrategy var24 = var23.getNanStrategy();
    int var25 = var24.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var26 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var24);
    java.lang.String var27 = var24.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var28 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var24);
    java.lang.String var29 = var24.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var30 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var24);
    org.apache.commons.math3.stat.ranking.TiesStrategy var31 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var32 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var31);
    org.apache.commons.math3.stat.ranking.NaNStrategy var33 = var32.getNanStrategy();
    int var34 = var33.ordinal();
    org.apache.commons.math3.stat.ranking.TiesStrategy var35 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var36 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var35);
    org.apache.commons.math3.stat.ranking.NaNStrategy var37 = var36.getNanStrategy();
    java.lang.Class var38 = var37.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var39 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var37);
    org.apache.commons.math3.stat.ranking.TiesStrategy var40 = var39.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var41 = var39.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var42 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var43 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var42);
    org.apache.commons.math3.stat.ranking.NaNStrategy var44 = var43.getNanStrategy();
    int var45 = var44.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var46 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var44);
    org.apache.commons.math3.stat.ranking.TiesStrategy var47 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var48 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var47);
    org.apache.commons.math3.stat.ranking.NaNStrategy var49 = var48.getNanStrategy();
    java.lang.Class var50 = var49.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var51 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var49);
    org.apache.commons.math3.stat.ranking.TiesStrategy var52 = var51.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var53 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var44, var52);
    org.apache.commons.math3.stat.ranking.NaturalRanking var54 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var41, var52);
    org.apache.commons.math3.stat.ranking.NaturalRanking var55 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var33, var52);
    org.apache.commons.math3.stat.ranking.NaturalRanking var56 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var24, var52);
    java.lang.String var57 = var52.name();
    java.lang.Object var58 = null;
    boolean var59 = var52.equals(var58);
    org.apache.commons.math3.stat.ranking.NaturalRanking var60 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20, var52);
    org.apache.commons.math3.util.ResizableDoubleArray var61 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var62 = var61.getNumElements();
    double[] var63 = var61.getInternalValues();
    var61.clear();
    double[] var65 = var61.getInternalValues();
    double[] var66 = var60.rank(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + "MAXIMAL"+ "'", var27.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var29 + "' != '" + "MAXIMAL"+ "'", var29.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var57 + "' != '" + "AVERAGE"+ "'", var57.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test453"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 9617852649L);
    java.math.BigInteger var5 = null;
    java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 0L);
    java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, 9617852649L);
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, var7);
    org.apache.commons.math3.exception.util.Localizable var11 = null;
    java.math.BigInteger var12 = null;
    java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, 0L);
    java.math.BigInteger var16 = org.apache.commons.math3.util.ArithmeticUtils.pow(var14, 9617852649L);
    java.math.BigInteger var17 = null;
    java.math.BigInteger var19 = org.apache.commons.math3.util.ArithmeticUtils.pow(var17, 0L);
    java.math.BigInteger var21 = org.apache.commons.math3.util.ArithmeticUtils.pow(var19, 9617852649L);
    java.math.BigInteger var22 = org.apache.commons.math3.util.ArithmeticUtils.pow(var16, var19);
    java.math.BigInteger var24 = org.apache.commons.math3.util.ArithmeticUtils.pow(var16, 2147483647);
    java.math.BigInteger var26 = org.apache.commons.math3.util.ArithmeticUtils.pow(var24, 6949188755L);
    java.lang.Number var27 = null;
    org.apache.commons.math3.exception.OutOfRangeException var29 = new org.apache.commons.math3.exception.OutOfRangeException(var11, (java.lang.Number)var26, var27, (java.lang.Number)9.332621544395286E157d);
    java.math.BigInteger var31 = org.apache.commons.math3.util.ArithmeticUtils.pow(var26, 0L);
    java.math.BigInteger var33 = org.apache.commons.math3.util.ArithmeticUtils.pow(var26, 208);
    java.math.BigInteger var34 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, var33);
    java.math.BigInteger var36 = org.apache.commons.math3.util.ArithmeticUtils.pow(var34, 445);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test454"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(0.9939513433989471d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.15982526750760595d);

  }

  public void test455() {}
//   public void test455() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test455"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure(10L);
//     long var10 = var1.nextSecureLong(10L, 10000000000L);
//     double var13 = var1.nextUniform(0.9999943487368532d, 44.5140274520795d);
//     double var16 = var1.nextGaussian((-0.8887853505857057d), 2.882619330995207E-19d);
//     java.util.Collection var17 = null;
//     java.lang.Object[] var19 = var1.nextSample(var17, (-19));
// 
//   }

  public void test456() {}
//   public void test456() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test456"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure(10L);
//     long var10 = var1.nextSecureLong(10L, 10000000000L);
//     double var12 = var1.nextChiSquare(0.001736111111111111d);
//     double var15 = var1.nextBeta(0.36792469441508013d, 0.23074612792124255d);
//     var1.reSeed((-6197319789L));
//     int var20 = var1.nextBinomial(5, 0.9738617129853937d);
//     var1.reSeedSecure();
//     double var24 = var1.nextCauchy(1.247735391779353d, 0.7962747911335563d);
//     java.lang.String var26 = var1.nextHexString(448);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 2654698212L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1.8281910871990467E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.9333545471359435d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == (-0.19165200315250552d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var26 + "' != '" + "22d796e7209a5e3f3d3f81d469bb88162b39ab1f40536fbfece9171356be917356eaa8150c79a4a625b6b3a63f5f0685edfd86473c7152f7c99c131aa978543d60ad608e855c085de4816e77bd13037d55f418c21693d3b4e4479d5e78aaed224920e0f6fbdb4c73cb85212209838d79109df435f3a01778cafa07d224d1bdaadde1b5d06bdb555a110a6602259bc9146f6e685bc08034b24b7cbd7412977f1061f2f98bb6be888d67890bbe3c8f38afeccf4a98a5527c1708fca9e60cab9e75721d7d9352f4940e4ab79ec4e1c92f0a85f24d87ada5e5e3b086355121d3f30c"+ "'", var26.equals("22d796e7209a5e3f3d3f81d469bb88162b39ab1f40536fbfece9171356be917356eaa8150c79a4a625b6b3a63f5f0685edfd86473c7152f7c99c131aa978543d60ad608e855c085de4816e77bd13037d55f418c21693d3b4e4479d5e78aaed224920e0f6fbdb4c73cb85212209838d79109df435f3a01778cafa07d224d1bdaadde1b5d06bdb555a110a6602259bc9146f6e685bc08034b24b7cbd7412977f1061f2f98bb6be888d67890bbe3c8f38afeccf4a98a5527c1708fca9e60cab9e75721d7d9352f4940e4ab79ec4e1c92f0a85f24d87ada5e5e3b086355121d3f30c"));
// 
//   }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test457"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(byte)(-1), (java.lang.Number)(short)1, true);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    java.lang.Object[] var12 = new java.lang.Object[] { 'a'};
    org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException(var10, var12);
    org.apache.commons.math3.exception.MathIllegalArgumentException var14 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var9, var12);
    org.apache.commons.math3.exception.MathIllegalStateException var15 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, var12);
    org.apache.commons.math3.exception.MathInternalError var16 = new org.apache.commons.math3.exception.MathInternalError(var7, var12);
    org.apache.commons.math3.exception.NullArgumentException var17 = new org.apache.commons.math3.exception.NullArgumentException(var6, var12);
    org.apache.commons.math3.exception.MathIllegalStateException var18 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var5, var12);
    org.apache.commons.math3.exception.MathIllegalStateException var19 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var12);
    org.apache.commons.math3.exception.util.ExceptionContext var20 = var19.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test458"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("8313a6");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test459"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(0.0d, 0.040818294823711264d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.04603294642349148d);

  }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test460"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("d5fc14aa2ed998444ddec040203959cb024aac091c2a54abadd4616d3dc46e3785360e806b57bd4a5d222ee95055e024fadd104b99f1b09738ce4d8450f09171eaf68e4a1fa3de00fd4fbb8330eb15eb0a03d83e4df9b4b2c202db1cdbc53ff708ec302699a43295890658cb0e27da4721b37db8f36e397b284daa98c5c1e68830d44a7f7388785a0bfb77f9886208d093c121d14578e3641efadf355062c309368e3cc2a2c11a6d345633223ad729d257a9f3995aee84d4403460fd88803c32db5421e1023ed22b701885a536a975131f3f828e4ca527bdec2d41493287f414b5e4574fa20ea99c0f9924566f05ccfaa5f38b1a800d57402811");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test461() {}
//   public void test461() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test461"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     double var7 = var1.nextExponential(24.0d);
//     double var9 = var1.nextT(1.5855819012757701d);
//     double var12 = var1.nextGaussian((-0.7323676290027762d), 13.753533396481055d);
//     var1.reSeed(4286580654L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var18 = var1.nextUniform(9.140183681189434d, 5.7915442060674405d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 58.45754390898804d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-0.43170242175601065d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-13.379744284653812d));
// 
//   }

  public void test462() {}
//   public void test462() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test462"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeedSecure(0L);
//     java.lang.String var5 = var1.nextSecureHexString(371);
//     long var8 = var1.nextSecureLong(0L, 8179512108L);
//     int var11 = var1.nextInt((-347), 5306065);
//     double var14 = var1.nextBeta(1.0203639016802208d, 56.76427506899936d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + "b8607be1a35d751cf6691cad040a600718a4a0c6155ef55a63634da80a47fc0f72d44bcf52ddac64bea0861627de2a3cbee16e9384613db3eb5bd09016d753ca3200894d74c737fb259693bedfff6dc1a3b0b612371e6186b0be16dbe5777cc05d241aee76df37ea7da9cd2278810b420fc91da6484fb0099b503850de02bf56ce53d8d869bd54013c037d753e74aab1d6243657ab5afe3458a5f8f083e009dd5db85bf0d697e9b141d0ef4bae0092523dba4823fdf5a44d954"+ "'", var5.equals("b8607be1a35d751cf6691cad040a600718a4a0c6155ef55a63634da80a47fc0f72d44bcf52ddac64bea0861627de2a3cbee16e9384613db3eb5bd09016d753ca3200894d74c737fb259693bedfff6dc1a3b0b612371e6186b0be16dbe5777cc05d241aee76df37ea7da9cd2278810b420fc91da6484fb0099b503850de02bf56ce53d8d869bd54013c037d753e74aab1d6243657ab5afe3458a5f8f083e009dd5db85bf0d697e9b141d0ef4bae0092523dba4823fdf5a44d954"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 680957701L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 50379);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.004664322861773212d);
// 
//   }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test463"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(59417.14438144365d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 59417.14438144366d);

  }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test464"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-117), var2, true);

  }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test465"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(0.0d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test466"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)0.968953569826736d, (java.lang.Number)9.384115567626118d, false);

  }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test467"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("RANDOM");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test468() {}
//   public void test468() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test468"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(1.5607966601082315d);
//     org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var5 = var3.density(100.0d);
//     double var8 = var3.cumulativeProbability((-2.450405938642638d), 0.6139648708421599d);
//     double[] var10 = var3.sample(100);
//     double var11 = var3.getStandardDeviation();
//     double var13 = var3.cumulativeProbability((-0.004920366423301847d));
//     double var14 = var3.getNumericalVariance();
//     double var15 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var3);
//     double var17 = var3.cumulativeProbability(3.4965075614664802d);
//     double var19 = var3.inverseCumulativeProbability(0.0d);
//     boolean var20 = var3.isSupportConnected();
//     double var22 = var3.inverseCumulativeProbability(0.0d);
//     double var23 = var3.getNumericalMean();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.8485834571828708d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.723245967437971d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.4980370657191222d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.3681246612055853d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.9997643044330278d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.0d);
// 
//   }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test469"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.getNumElements();
    double[] var2 = var0.getInternalValues();
    int var3 = var0.getNumElements();
    var0.setNumElements(300);
    double var7 = var0.substituteMostRecentElement(2.2924316695611777d);
    float var8 = var0.getContractionCriteria();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.5f);

  }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test470"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    java.lang.Class var3 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = var4.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var6 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5, var6);
    org.apache.commons.math3.stat.ranking.TiesStrategy var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8);
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = var9.getNanStrategy();
    int var11 = var10.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    java.lang.String var13 = var10.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    java.lang.String var15 = var10.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var17);
    org.apache.commons.math3.stat.ranking.NaNStrategy var19 = var18.getNanStrategy();
    int var20 = var19.ordinal();
    org.apache.commons.math3.stat.ranking.TiesStrategy var21 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var21);
    org.apache.commons.math3.stat.ranking.NaNStrategy var23 = var22.getNanStrategy();
    java.lang.Class var24 = var23.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var25 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var23);
    org.apache.commons.math3.stat.ranking.TiesStrategy var26 = var25.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var27 = var25.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var28 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var29 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var28);
    org.apache.commons.math3.stat.ranking.NaNStrategy var30 = var29.getNanStrategy();
    int var31 = var30.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var32 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var30);
    org.apache.commons.math3.stat.ranking.TiesStrategy var33 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var34 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var33);
    org.apache.commons.math3.stat.ranking.NaNStrategy var35 = var34.getNanStrategy();
    java.lang.Class var36 = var35.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var37 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var35);
    org.apache.commons.math3.stat.ranking.TiesStrategy var38 = var37.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var39 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var30, var38);
    org.apache.commons.math3.stat.ranking.NaturalRanking var40 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var27, var38);
    org.apache.commons.math3.stat.ranking.NaturalRanking var41 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var19, var38);
    org.apache.commons.math3.stat.ranking.NaturalRanking var42 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10, var38);
    org.apache.commons.math3.stat.ranking.TiesStrategy var43 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var44 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var43);
    org.apache.commons.math3.stat.ranking.NaNStrategy var45 = var44.getNanStrategy();
    int var46 = var45.ordinal();
    org.apache.commons.math3.stat.ranking.TiesStrategy var47 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var48 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var47);
    org.apache.commons.math3.stat.ranking.NaNStrategy var49 = var48.getNanStrategy();
    java.lang.Class var50 = var49.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var51 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var49);
    org.apache.commons.math3.stat.ranking.TiesStrategy var52 = var51.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var53 = var51.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var54 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var55 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var54);
    org.apache.commons.math3.stat.ranking.NaNStrategy var56 = var55.getNanStrategy();
    int var57 = var56.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var58 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var56);
    org.apache.commons.math3.stat.ranking.TiesStrategy var59 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var60 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var59);
    org.apache.commons.math3.stat.ranking.NaNStrategy var61 = var60.getNanStrategy();
    java.lang.Class var62 = var61.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var63 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var61);
    org.apache.commons.math3.stat.ranking.TiesStrategy var64 = var63.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var65 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var56, var64);
    org.apache.commons.math3.stat.ranking.NaturalRanking var66 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var53, var64);
    org.apache.commons.math3.stat.ranking.NaturalRanking var67 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var45, var64);
    java.lang.String var68 = var64.name();
    java.lang.String var69 = var64.name();
    boolean var70 = var38.equals((java.lang.Object)var64);
    boolean var72 = var64.equals((java.lang.Object)(-1.9999999999999998d));
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var73 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var5, var64);
    org.apache.commons.math3.stat.ranking.NaturalRanking var74 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.random.RandomGenerator var75 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var76 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var75);
    org.apache.commons.math3.stat.ranking.TiesStrategy var77 = var76.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var78 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var5, var77);
    org.apache.commons.math3.stat.ranking.TiesStrategy var79 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var80 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var79);
    org.apache.commons.math3.stat.ranking.NaNStrategy var81 = var80.getNanStrategy();
    java.lang.Class var82 = var81.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var83 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var81);
    org.apache.commons.math3.stat.ranking.TiesStrategy var84 = var83.getTiesStrategy();
    java.lang.String var85 = var84.name();
    int var86 = var84.ordinal();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var87 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var5, var84);
    java.lang.String var88 = var84.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "MAXIMAL"+ "'", var13.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "MAXIMAL"+ "'", var15.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var68 + "' != '" + "AVERAGE"+ "'", var68.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var69 + "' != '" + "AVERAGE"+ "'", var69.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var85 + "' != '" + "AVERAGE"+ "'", var85.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var88 + "' != '" + "AVERAGE"+ "'", var88.equals("AVERAGE"));

  }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test471"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 6.976869420649166E-32d);

  }

  public void test472() {}
//   public void test472() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test472"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextSecureHexString(6);
//     org.apache.commons.math3.distribution.NormalDistribution var4 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var5 = var4.getNumericalMean();
//     double var6 = var4.getStandardDeviation();
//     boolean var7 = var4.isSupportLowerBoundInclusive();
//     boolean var8 = var4.isSupportUpperBoundInclusive();
//     double var9 = var4.getStandardDeviation();
//     double var10 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var4);
//     org.apache.commons.math3.distribution.NormalDistribution var11 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var12 = var11.getMean();
//     double var15 = var11.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
//     double var16 = var11.getSupportUpperBound();
//     double var17 = var11.getSupportUpperBound();
//     double var18 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var11);
//     double var20 = var11.density(5.451930926365849E-198d);
//     double var21 = var11.sample();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "f78e4e"+ "'", var3.equals("f78e4e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-1.71439848273613d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.5230558330643571d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1.03237465011739d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.3989422804014327d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.012041503522437479d);
// 
//   }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test473"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(1.1726633012133396d, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.1726633012133396d);

  }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test474"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(7324388407L, 100L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7324388307L);

  }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test475"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(4.624546720014361d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6.147907255472729E-11d);

  }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test476"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma((-3.2553434679543276d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 18.83337792546274d);

  }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test477"); }


    long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 120L);

  }

  public void test478() {}
//   public void test478() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test478"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeedSecure(0L);
//     long var6 = var1.nextSecureLong(3628800L, 10000000000L);
//     java.lang.String var8 = var1.nextHexString(500);
//     double var10 = var1.nextT(0.9584128699015102d);
//     var1.reSeed(0L);
//     var1.reSeed();
//     long var15 = var1.nextPoisson(78.6315718091685d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var17 = var1.nextSecureHexString((-65));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3992215914L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "cbfb32788b03beb6b407337bf9f17857d0f8dd57367c30e925816b2df66abbe13db4d7bbab5ba7e2cda63541497b88980379484d7798f0e74c07fe0861c5df15b893867197b2c4982adb3836fdbfff7a811a579af6aaed8419f2d8dc76cc6f520d36817aa89b6f973ef2a6f9a135950bd47d5a2990fb218dd29a8651a0cb9990938b5c816c01797bb1d5a3a9f4a30aa8d53921f4b7aa5aa1338bbcda5aad5f3eb91d242c676ce84494c80a808caa955bd7c708dde5cfb717e85e8758fca5d7410fbf893815b6388b1e2033a4fc7a54a5902be167c4f7444a3e390692d4d6976d56b814315384e6de6cea31dc466758d51bb489ca2b0914b6adc1"+ "'", var8.equals("cbfb32788b03beb6b407337bf9f17857d0f8dd57367c30e925816b2df66abbe13db4d7bbab5ba7e2cda63541497b88980379484d7798f0e74c07fe0861c5df15b893867197b2c4982adb3836fdbfff7a811a579af6aaed8419f2d8dc76cc6f520d36817aa89b6f973ef2a6f9a135950bd47d5a2990fb218dd29a8651a0cb9990938b5c816c01797bb1d5a3a9f4a30aa8d53921f4b7aa5aa1338bbcda5aad5f3eb91d242c676ce84494c80a808caa955bd7c708dde5cfb717e85e8758fca5d7410fbf893815b6388b1e2033a4fc7a54a5902be167c4f7444a3e390692d4d6976d56b814315384e6de6cea31dc466758d51bb489ca2b0914b6adc1"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.6710370917756251d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 86L);
// 
//   }

  public void test479() {}
//   public void test479() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test479"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextBeta(572.2646479502633d, 0.07637989519631011d);
//     double var8 = var1.nextGamma(4.937302184657956d, 97.98819663162894d);
//     var1.reSeed();
//     int var12 = var1.nextInt((-65), 825);
//     var1.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.9999999982809208d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 128.08767952512338d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 530);
// 
//   }

  public void test480() {}
//   public void test480() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test480"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure();
//     var1.reSeed();
//     double var10 = var1.nextBeta(31.984371183438952d, 3.141592653589793d);
//     var1.reSeed();
//     var1.reSeedSecure(0L);
//     java.lang.String var15 = var1.nextHexString(317);
//     long var18 = var1.nextLong(0L, 3659212668L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.8860707256739782d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "91fdd680c056064567107957319528cf926a1431a6f50b753622185e8cfb7ccbb8c5d5966378494298b3126750579d630aca3619df21e3307dc26f2c6ace0c824a90922c3205c9f25d0355dfbd4ce3a3618851766d453adf17c62330df7a29ad66f4cac6494d9038da22a98be04f4167d2f94e6b9748c29e1510a058333a5fb3ba3adb8055f3580f403587d39976d59c53e5cbae4828a4f7dce0ffb4f6bde"+ "'", var15.equals("91fdd680c056064567107957319528cf926a1431a6f50b753622185e8cfb7ccbb8c5d5966378494298b3126750579d630aca3619df21e3307dc26f2c6ace0c824a90922c3205c9f25d0355dfbd4ce3a3618851766d453adf17c62330df7a29ad66f4cac6494d9038da22a98be04f4167d2f94e6b9748c29e1510a058333a5fb3ba3adb8055f3580f403587d39976d59c53e5cbae4828a4f7dce0ffb4f6bde"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1320826271L);
// 
//   }

  public void test481() {}
//   public void test481() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test481"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure();
//     int var9 = var1.nextInt((-15), 500);
//     var1.reSeed(4448708814L);
//     int var14 = var1.nextInt(1073741824, 2147483647);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var17 = var1.nextLong(5078045306L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 111);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1222826114);
// 
//   }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test482"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.lang.Throwable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    java.lang.Object[] var7 = new java.lang.Object[] { 'a'};
    org.apache.commons.math3.exception.MathIllegalStateException var8 = new org.apache.commons.math3.exception.MathIllegalStateException(var5, var7);
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException(var3, var4, var7);
    org.apache.commons.math3.exception.MathIllegalArgumentException var10 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, var7);
    org.apache.commons.math3.exception.MaxCountExceededException var11 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)0.9999991703434066d, var7);
    java.lang.Throwable[] var12 = var11.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test483"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.0d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test484() {}
//   public void test484() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test484"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(1.199456005038578d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test485"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(128.08767952512338d, 1.0229403758340696d, 0.02458361225088624d, 5215);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.1214876910397427E-215d);

  }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test486"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var3 = new double[] { 0.0d, 100.0d};
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var6 = var5.getNumElements();
    double[] var7 = var5.getInternalValues();
    double[] var10 = new double[] { 10.0d, 100.0d};
    double var11 = var4.mannWhitneyU(var7, var10);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    double var13 = var0.mannWhitneyU(var3, var7);
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    var14.contract();
    int var16 = var14.getExpansionMode();
    int var17 = var14.start();
    double[] var18 = var14.getElements();
    double var20 = var14.addElementRolling(5.65362408791435d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var14.discardFrontElements(5488);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 32.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);

  }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test487"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(5210, 1.9073489E-6f, 16.000002f, (-2));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test488"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(10.015471524400919d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test489"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(0.21182861996536173d, 64.23076980428634d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0032979186243917843d);

  }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test490"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("ae680aafce4678b563633337dcf0d94be00b43d269864cbbf08aaca8a573f7fc2cdc43b");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test491"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    java.lang.Class var3 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var4.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var4.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var7);
    int var9 = var6.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(50);
    double[] var13 = var12.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var13);
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var13);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var16 = var10.rank(var13);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test492() {}
//   public void test492() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test492"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextGamma(0.0d, 29.9749466411613d);
//     var1.reSeedSecure(10L);
//     long var10 = var1.nextSecureLong(10L, 10000000000L);
//     int var13 = var1.nextSecureInt(0, 10);
//     double var16 = var1.nextUniform(3.7625250955428156d, 5.381455886543763d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var20 = var1.nextHypergeometric((-721445887), 0, 1078421185);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 3042459200L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 5.083768293344218d);
// 
//   }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test493"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma((-0.9793091478686597d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2338.480079972439d);

  }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test494"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(6570264474L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6570264474L);

  }

  public void test495() {}
//   public void test495() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test495"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Number var1 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, var1, (java.lang.Number)2.7938323067283985E-7d, (java.lang.Number)0.723245967437971d);
//     java.lang.Number var5 = var4.getLo();
//     java.lang.Number var6 = var4.getLo();
//     java.lang.Throwable var7 = null;
//     var4.addSuppressed(var7);
// 
//   }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test496"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.9985483232309089d, (java.lang.Number)0.8413447340368079d, false);

  }

  public void test497() {}
//   public void test497() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test497"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getMean();
//     double var4 = var0.cumulativeProbability((-0.05782461145270825d), 31.98437118343895d);
//     double var5 = var0.getSupportUpperBound();
//     double var6 = var0.sample();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.5230558330643571d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.8714776225990565d));
// 
//   }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test498"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Object[] var6 = new java.lang.Object[] { 'a'};
    org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException(var4, var6);
    org.apache.commons.math3.exception.MathIllegalArgumentException var8 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, var6);
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, var6);
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, var6);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var0, var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test499"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(1.9073486E-6f, 3.402823E38f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.402823E38f);

  }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test500"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(10.042503014966304d, 1.6007479984283653E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.349586158054495E-6d);

  }

}
